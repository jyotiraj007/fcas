// Copyright (C) 2014 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// CF_CubicBezier.h

#ifndef CF_CUBIC_BEZIER_H
#define CF_CUBIC_BEZIER_H

#include "CF_CubicPoints.h"
#include "CF_ArrayList.h"
#include "CF_Vector2f.h"
#include "CF_QuadBezier.h"
#include "CF_Line2D.h"
#include "CF_QuadContour.h"
#include "CF_Stack.h"
#include "CF_Quadrilateral.h"

class  CF_CubicBezier
{
    public:

        enum Control { eCONTROL1 = 0, eCONTROL2, eSTART, eEND, eNONE };       // Must start with control: indexes m_Bars.

        /* Ctor */  CF_CubicBezier     ();
        /* Ctor */  CF_CubicBezier     (const CF_Vector2f& startPoint, const CF_Vector2f& endPoint, const CF_Vector2f& controlPoint1, const CF_Vector2f& controlPoint2);
        /* Ctor */  CF_CubicBezier     (const CF_CubicPoints& points);
        void        Init            (const CF_Vector2f& startPoint, const CF_Vector2f& endPoint, const CF_Vector2f& controlPoint1, const CF_Vector2f& controlPoint2);

        void        SetPoint        (Control control, const CF_Vector2f& point);
        CF_Vector2f GetPoint        (Control control);

        void        Evaluate        (float flatness = 0.05f);

        bool        Intersects      (CF_CubicBezier& other);
        void        GetIntersections(CF_CubicBezier& other,  CF_ArrayList<CF_Vector2f>& intersections);

        bool        Intersects      (CF_Line2D&      line);
        void        GetIntersections(CF_Line2D& line, CF_ArrayList<CF_Vector2f>& intersections);

        float       LeftExtent      ();
        float       RightExtent     ();
        float       TopExtent       ();
        float       BottomExtent    ();

        bool        LeftIsTangent   ();
        bool        RightIsTangent  ();
        bool        TopIsTangent    ();
        bool        BottomIsTangent ();


    protected:

        float                           TopHorizontalTangent    ();
        float                           BottomHorizontalTangent ();
        float                           RightVerticalTangent    ();
        float                           LeftVerticalTangent     ();

        bool                            QuadrilateralsIntersect (CF_CubicBezier& other, CF_ArrayList<int>& list1, CF_ArrayList<int>& list2);
        bool                            LineIntersects          (CF_Line2D& line, CF_ArrayList<int>& indexList);
        bool                            Split                   (CF_ArrayList<int>& indexList, float flatness = 0.05f);

        CF_Vector2f                     m_Control[4];

        CF_ArrayList<CF_Quadrilateral>  m_Quadrilaterals;
        int                             m_NumSegments;
        CF_ArrayList<CF_Vector2f>       m_Points;

        bool                            m_LeftIsTangent;
        bool                            m_RightIsTangent;
        bool                            m_TopIsTangent;
        bool                            m_BottomIsTangent;
};


inline bool CF_CubicBezier::LeftIsTangent  () { return m_LeftIsTangent;    };
inline bool CF_CubicBezier::RightIsTangent () { return m_RightIsTangent;   };
inline bool CF_CubicBezier::TopIsTangent   () { return m_TopIsTangent;     };
inline bool CF_CubicBezier::BottomIsTangent() { return m_BottomIsTangent;  };

#endif
