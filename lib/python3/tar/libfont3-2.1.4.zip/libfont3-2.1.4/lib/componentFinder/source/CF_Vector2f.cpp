// Copyright (C) 2014 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// CF_Vector2f.cpp

//lint -sem(CF_Vector2f::Set,initializer)

#include "CF_Vector2f.h"
#include "CF_MathUtilities.h"
#include <math.h>

/**
    Constructs CF_Vector2f and initializes coordinates to (0.0f,0.0f).
*/
CF_Vector2f::CF_Vector2f() : m_X(0.0), m_Y(0.0)
{
}

/**
    Copy constructor.
*/
CF_Vector2f::CF_Vector2f(const CF_Vector2f& other)
                : m_X(other.m_X),
                  m_Y(other.m_Y)
{
}

/**
    Constructs CF_Vector2f using coordinates.
    @param[in]     x   First coordinate
    @param[in]     y   Second coordinate.
*/
CF_Vector2f::CF_Vector2f(float x, float y)
                : m_X(x),
                  m_Y(y)
{
}

/**
    Subtracts one vector from the current vector.
    @param[in]     other Other vector
*/
CF_Vector2f CF_Vector2f::operator-(const CF_Vector2f& other) const
{
    return CF_Vector2f(m_X - other.m_X, m_Y - other.m_Y);
}

/**
    Adds one vector to the current vector.
    @param[in]     other Other vector
*/
CF_Vector2f CF_Vector2f::operator+=(const CF_Vector2f& other)
{
    m_X += other.m_X;
    m_Y += other.m_Y;
    return *this;
}

/**
    Adds one vector to the current vector.
    @param[in] other Other vector
*/
CF_Vector2f CF_Vector2f::operator+(const CF_Vector2f& other) const
{
    return CF_Vector2f(m_X + other.m_X, m_Y + other.m_Y);
}

bool CF_Vector2f::operator==(const CF_Vector2f& other) const
{
    bool equal = false;

    if ( (m_X == other.m_X) &&  //lint !e777
         (m_Y == other.m_Y))    //lint !e777
    {
        equal = true;
    }
    return equal;
}

/**
    Compares whether current vector is not equal to another vector.
    Vectors are equal if their coordinates are equal.
    @param[in]     other Other vector
    @return @b true if coordinate values of two vectors are equal.
*/
bool CF_Vector2f::operator!=(const CF_Vector2f& other) const
{
    bool notEqual = false;

    if ( (m_X != other.m_X) ||  //lint !e777
         (m_Y != other.m_Y))    //lint !e777
    {
        notEqual = true;
    }
    return notEqual;
}

/**
    Computes length of vector.
    @return square of the length of the vector.
*/
float CF_Vector2f::LengthSquared() const
{
    return  m_X * m_X + m_Y * m_Y;
}

/**
    Multiples a scalar times a vector.
    @param[in]  scale Scalar value
    @param[in]  other Other vector
    @return scaled CF_Vector2f.
*/
CF_Vector2f operator*(float scale, const CF_Vector2f& other)
{
    return CF_Vector2f(scale * other.m_X,
                    scale * other.m_Y );
}


void CF_Vector2f::FromFixed(long x, long y)
{
    float fx = CF_FixedToFloat((int)x);
    float fy = CF_FixedToFloat((int)y);

    fx += 0.5f;
    fy += 0.5f;

    m_X = (float)floor(fx);
    m_Y = (float)floor(fy);
}

/**
    Determines whether the vector is valid, i.e. the coordinates are
    valid floating point numbers.
    @return @b true if both coordinates are valid floating point numbers.
*/
bool CF_Vector2f::IsValid() const
{
    bool valid = true;

    if (    CF_IsNan(m_X) ||
            CF_IsNan(m_Y) ||
            CF_IsInf(m_X) ||
            CF_IsInf(m_Y) )
    {
        valid = false;
    }
    return valid;
}
