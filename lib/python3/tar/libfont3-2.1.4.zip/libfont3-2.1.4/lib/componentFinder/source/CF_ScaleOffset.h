// Copyright (C) 2016 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// CF_ScaleOffset.h

#ifndef CF_SCALE_OFFSET_H
#define CF_SCALE_OFFSET_H

#include <math.h>
#include <stdlib.h>

class CF_ScaleOffset
{
    public:
        float   m_ScaleX;
        float   m_ScaleY;
        int     m_OffsetX;
        int     m_OffsetY;

        /* CTOR */ CF_ScaleOffset   ();

        bool    IsTrueTypeCompatible();
        bool    operator == (const CF_ScaleOffset& other);
        bool    operator != (const CF_ScaleOffset& other);
};

inline CF_ScaleOffset::CF_ScaleOffset()
    :   m_ScaleX    (0.0f),
        m_ScaleY    (0.0f),
        m_OffsetX   (0),
        m_OffsetY   (0)
{
}

inline bool CF_ScaleOffset::operator != (const CF_ScaleOffset& other)
{
    float EPSILON = 0.1f;

    bool notEqual = false;

    if (fabs(m_ScaleX - other.m_ScaleX) > EPSILON ||
        fabs(m_ScaleY - other.m_ScaleY) > EPSILON ||
        abs(m_OffsetX - other.m_OffsetX) >= 2 ||
        abs(m_OffsetY - other.m_OffsetY) >= 2)
    {
        notEqual = true;
    }

    /*
    if (    (m_ScaleX   != other.m_ScaleX ) ||
            (m_ScaleY   != other.m_ScaleY ) ||
            (m_OffsetX  != other.m_OffsetX) ||
            (m_OffsetY  != other.m_OffsetY) )
    {
        notEqual = true;
    }
    */
    return notEqual;
}

inline bool CF_ScaleOffset::operator == (const CF_ScaleOffset& other)
{
    bool equal = false;

    if (    (m_ScaleX   == other.m_ScaleX ) &&
            (m_ScaleY   == other.m_ScaleY ) &&
            (m_OffsetX  == other.m_OffsetX) &&
            (m_OffsetY  == other.m_OffsetY) )
    {
        equal = true;
    }

    return equal;
}

inline bool CF_ScaleOffset::IsTrueTypeCompatible()
{
    bool compatible = false;

    if (    (m_ScaleX < 2.0f) &&
            (m_ScaleY < 2.0f)  )
    {
        compatible = true;
    }

    return compatible;
}

#endif

