// Copyright (C) 2014 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// CF_Line2D.cpp

#include "CF_Line2D.h"
#include "CF_ArrayList.h"

/**
    Constructs a degenerate line segment with start and end at the origin.
*/
CF_Line2D::CF_Line2D()
{
}

/**
    Constructs a line segment using start and end coordinates.
    @param[in]  start  Coordinate of start of line
    @param[in]  end    Coordinate of end of line
*/
CF_Line2D::CF_Line2D(const CF_Vector2f& start, const CF_Vector2f& end)
    : m_Start(start),
      m_End(end)
{
}

/**
    Returns the intersection point between two line segments. The intersection point
    may lie outside one or both line segments but will lie on the lines containing the 
    two line segments.
    @param[in]  other  Second line segment.
    @return Intersection point.
*/
CF_Vector2f CF_Line2D::Intersection(CF_Line2D& other)
{
    float m1;
    float m2;
    float c1;
    float c2;

    float startX = m_Start.X();
    float startY = m_Start.Y();
    float endX   = m_End.X();
    float endY   = m_End.Y();
    float otherStartX = other.m_Start.X();
    float otherStartY = other.m_Start.Y();
    float otherEndX   = other.m_End.X();
    float otherEndY   = other.m_End.Y();

    float deltaX = endX - startX;
    float deltaY = endY - startY;
    float otherDeltaX = otherEndX - otherStartX;
    float otherDeltaY = otherEndY - otherStartY;
    float x;
    float y;


    // If both are horizontal or both vertical.
    // Check for colinear and pick joining end.
    if (    ((deltaX == 0.0f) && (otherDeltaX == 0.0f)) ||
            ((deltaY == 0.0f) && (otherDeltaY == 0.0f)) )
    {
        if (    (m_End == other.m_Start) ||
                (m_End == other.m_End))
        {
            return m_End;
        }
        else if ((m_Start == other.m_Start) ||
                 (m_Start == other.m_End))
        {
            return m_Start;
        }
    }

    // Both vertical.
    if ((deltaX == 0.0f) && (otherDeltaX == 0.0f))
    {
        CF_ArrayList<float> list;
        list.Add(otherEndY);
        list.Add(startY);
        list.Add(endY);
        list.Add(otherStartY);
        list.Sort();
        
        return CF_Vector2f(startX, list[1] + ((list[2] - list[1]) / 2.0f));
    }

    // Both horizontal.
    if ((deltaY == 0.0f) && (otherDeltaY == 0.0f))
    {
        CF_ArrayList<float> list;
        list.Add(otherEndX);
        list.Add(startX);
        list.Add(endX);
        list.Add(otherStartX);
        list.Sort();
        
        return CF_Vector2f(list[1] + ((list[2] - list[1]) / 2.0f), startY);
    }


    if (deltaX == 0.0f)
    {
        // Solve other line at x = endX;
        m2 = otherDeltaY / otherDeltaX;     //lint !e414  by inspection this cannot be 0
        c2 = otherStartY - (m2 * otherStartX);

        x = endX;
        y = m2 * x + c2;

        return CF_Vector2f(x, y);
    }

    if (deltaY == 0.0)
    {
        // This is horizontal other is vertical.
        if (otherDeltaX == 0.0f)
        {
            x = otherEndX;
            y = endY;

            return CF_Vector2f(x, y);
        }
        else // Solve other line at y = endY;
        {
            m2 = otherDeltaY / otherDeltaX;
            c2 = otherStartY - (m2 * otherStartX);
            y = endY;
            x = (y - c2) / m2;      //lint !e414 (division by zero) - otherDeltaY cannot be zero, since deltaY and otherDeltaY both zero is handled above, and otherDeltaX=0 is checked @222

            return CF_Vector2f(x, y);
        }
    }

    if (otherDeltaX == 0.0f)
    {
        // Solve this line at x = otherEndX;
        m1 = deltaY / deltaX;
        c1 = startY - (m1 * startX);
        x = otherEndX;
        y = m1 * x + c1;

        return CF_Vector2f(x, y);
    }

    if (otherDeltaY == 0.0f)
    {
        m1 = deltaY / deltaX;
        c1 = startY - (m1 * startX);
        y = otherEndY;
        x = (y - c1) / m1;

        return CF_Vector2f(x, y);
    }

    m1 = deltaY / deltaX;
    c1 = startY - (m1 * startX);

    m2 = otherDeltaY / otherDeltaX;
    c2 = otherStartY - (m2 * otherStartX);

    // If the slopes are the same, i.e. paralel or co-linear
    // We're going to assume co-linear.
    if ((m2 - m1) == 0.0f)
    {
        if (    (m_End == other.m_Start) ||
                (m_End == other.m_End))
        {
            return m_End;
        }
        else if ((m_Start == other.m_Start) ||
                 (m_Start == other.m_End))
        {
            return m_Start;
        }
    }

    // Finaly the general case:
    x = -(c2 - c1) / (m2 - m1);
    y = ((c1 * m2) - (c2 * m1)) / (m2 - m1);

    return CF_Vector2f(x, y);
}

/**
    Determines if two line segments intersect.
    @return @b true if segments intersect.
*/
bool CF_Line2D::Intersects(const CF_Line2D& other) const
{
    float deltaX = m_End.X() - m_Start.X();
    float deltaY = m_End.Y() - m_Start.Y();
    float otherDeltaX = other.m_End.X() - other.m_Start.X();
    float otherDeltaY = other.m_End.Y() - other.m_Start.Y();

    float divisor = (-otherDeltaX * deltaY + deltaX * otherDeltaY);

    if (divisor != 0.0f)
    {
        float oneOverDivisor = 1.0f / divisor;

        float u = (-deltaY * (m_Start.X() - other.m_Start.X()) + deltaX * (m_Start.Y() - other.m_Start.Y())) * oneOverDivisor;

        if ((u < 0.0f) || (u > 1.0f)) return false;

        float v = ( otherDeltaX * (m_Start.Y() - other.m_Start.Y()) - otherDeltaY * (m_Start.X() - other.m_Start.X())) * oneOverDivisor;

        if ((v < 0.0f) || (v > 1.0f)) return false;

        return true;
    }
    else
    {
        // could be overlapping horizontal lines
        if ((deltaY == 0.0f) && (otherDeltaY == 0.0f) && (m_Start.Y() == other.m_Start.Y()))
        {
            if (m_Start.X() < m_End.X())
            {
                if (((other.m_Start.X() > m_Start.X()) && (other.m_Start.X() < m_End.X())) ||
                    ((other.m_End.X()   > m_Start.X()) && (other.m_End.X()   < m_End.X())))
                    return true;
            }
            else
            {
                if (((other.m_Start.X() > m_End.X()) && (other.m_Start.X() < m_Start.X())) ||
                    ((other.m_End.X()   > m_End.X()) && (other.m_End.X()   < m_Start.X())))
                    return true;
            }
        }
        // could be overlapping vertical lines
        else if ((deltaX == 0.0f) && (otherDeltaX == 0.0f) && (m_Start.X() == other.m_Start.X()))
        {
            if (m_Start.Y() < m_End.Y())
            {
                if (((other.m_Start.Y() > m_Start.Y()) && (other.m_Start.Y() < m_End.Y())) ||
                    ((other.m_End.Y()   > m_Start.Y()) && (other.m_End.Y()   < m_End.Y())))
                    return true;
            }
            else
            {
                if (((other.m_Start.Y() > m_End.Y()) && (other.m_Start.Y() < m_Start.Y())) ||
                    ((other.m_End.Y()   > m_End.Y()) && (other.m_End.Y()   < m_Start.Y())))
                    return true;
            }
        }
    }

    return false;
}

void CF_Line2D::GetIntersections(CF_Line2D& other, CF_ArrayList<CF_Vector2f>& intersections)
{
    if (this->Intersects(other))
    {
        CF_Vector2f intersection = this->Intersection(other);
        intersections.Add(intersection);
    }
}
/**
    Returns the start of the line segment.
    @return Start point.
*/
CF_Vector2f CF_Line2D::Start()const 
{
    return m_Start;
}

/**
    Returns the end of the line segment.
    @return End point.
*/
CF_Vector2f CF_Line2D::End()const
{
    return m_End;
}
