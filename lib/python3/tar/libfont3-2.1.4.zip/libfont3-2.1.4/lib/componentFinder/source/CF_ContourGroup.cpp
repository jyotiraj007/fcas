// Copyright (C) 2015 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// CF_ContourGroup.cpp

#include "CF_ContourGroup.h"
#include <stdlib.h>

CF_ContourGroup::CF_ContourGroup()
{
}

/*
void CF_QuadGlyph::Scale(float xScale, float yScale)
{
    CF_QuadContour* pContour = FirstContour();

    while (pContour)
    {
        pContour->Scale(xScale, yScale);
        pContour = NextContour();
    }
}
*/

void CF_ContourGroup::Clear()
{
    m_Contours.ResetIndex();
}

void CF_ContourGroup::AddContour(CF_QuadContour& contour)
{
    m_Contours.Add(contour);
}


CF_QuadContour& CF_ContourGroup::operator[](int index)
{
    return m_Contours[index];
}

CF_QuadContour* CF_ContourGroup::FirstContour()
{
    CF_QuadContour* pContour = NULL;

    m_Iterator = 0;

    if (m_Contours.NumElements() > 0)
    {
        pContour = &m_Contours[m_Iterator];
    }

    return pContour;
}

CF_QuadContour* CF_ContourGroup::NextContour()
{
    CF_QuadContour* pContour = NULL;

    m_Iterator++;

    if (m_Iterator < m_Contours.NumElements())
    {
        pContour = &m_Contours[m_Iterator];
    }

    return pContour;
}


bool CF_ContourGroup::operator==(CF_ContourGroup& other)
{
    if (m_Contours.NumElements() != other.m_Contours.NumElements())
    {
        return false;
    }

    CF_QuadContour* pContour = other.FirstContour();

    while (pContour)
    {
        int sequenceId = pContour->GetId();
        
        CF_QuadContour* pOtherContour = GetSequence(sequenceId);

        if (NULL == pOtherContour)
        {
            return false;
        }

        pContour = other.NextContour();
    }

    // Make sure the scaleOffset is the same for each contour.
    pContour = other.FirstContour();

    if (NULL == pContour)
        return false;

    int sequenceId  = pContour->GetId();

    CF_QuadContour* pOtherContour = GetSequence(sequenceId);

    CF_ScaleOffset lastScaleOffset  = pContour->GetScaleOffset(*pOtherContour); 
    CF_ScaleOffset currentScaleOffset;

    if (false == lastScaleOffset.IsTrueTypeCompatible())
    {
        return false;
    }

    pContour = other.NextContour();

    while (pContour)
    {
        sequenceId = pContour->GetId();

        pOtherContour = GetSequence(sequenceId);

        if (NULL != pOtherContour) 
        {
            currentScaleOffset = pContour->GetScaleOffset(*pOtherContour);

            if ( (currentScaleOffset != lastScaleOffset) ||
                 (false == currentScaleOffset.IsTrueTypeCompatible()) ) 
            {
                return false;
            }
            lastScaleOffset = currentScaleOffset;
        }
        else
        {
            return false;
        }

        pContour = other.NextContour();
    }

    return true;
}



CF_QuadContour* CF_ContourGroup::GetSequence(int sequenceId)
{
    CF_QuadContour* pContour = FirstContour();

    while (pContour)
    {
        if (    (pContour->Tag() == false) &&
                (pContour->GetId() == sequenceId))
        {
            return pContour;
        }
        pContour = NextContour();
    }

    return NULL;
}

void CF_ContourGroup::ClearTags()
{
    CF_QuadContour* pContour = FirstContour();

    while (pContour)
    {
        pContour->SetTag(false);

        pContour = NextContour();
    }
}
