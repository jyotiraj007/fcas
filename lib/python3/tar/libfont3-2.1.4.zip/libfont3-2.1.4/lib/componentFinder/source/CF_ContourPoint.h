// Copyright (C) 2015 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// ContourPoint.h

#ifndef CF_CONTOUR_POINT
#define CF_CONTOUR_POINT

#include "CF_Vector2f.h"

class CF_ContourPoint
{
    public:

        enum CF_PointType { ON_CURVE = 0, OFF_CURVE = 1 };

        /*  CTOR */ CF_ContourPoint    ();
        /*  CTOR */ CF_ContourPoint    (CF_PointType type, CF_Vector2f point);

        CF_PointType   m_Type;
        CF_Vector2f    m_Point;
};

#endif



