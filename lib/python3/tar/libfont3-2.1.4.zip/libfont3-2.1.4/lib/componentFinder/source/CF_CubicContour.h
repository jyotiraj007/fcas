// Copyright (C) 2015 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// CF_CubicContour.h

#ifndef CF_CUBIC_CONTOUR_H
#define CF_CUBIC_CONTOUR_H

#include "CF_Contour.h"

class   CF_Line2D;
class   CF_CubicBezier;
struct  CF_CubicPoints;


class CF_CubicContour : public CF_Contour
{
    public:
        /* CTOR */  CF_CubicContour();

        bool        GetFirstCubic   (CF_CubicPoints& points);
        bool        GetNextCubic    (CF_CubicPoints& points);

        bool        GetFirstLine    (CF_Line2D& line);
        bool        GetNextLine     (CF_Line2D& line);

        bool        Intersects      (CF_CubicContour& otherContour);

        bool        Intersects      (CF_Line2D& line);
        bool        Intersects      (CF_CubicBezier& cubic);

        void        GetIntersections(CF_CubicContour& otherContour, CF_ArrayList<CF_Vector2f>& intersections);

        void        GetIntersections(CF_Line2D& line,          CF_ArrayList<CF_Vector2f>& intersections);
        void        GetIntersections(CF_CubicBezier& cubic,    CF_ArrayList<CF_Vector2f>& intersections);

        bool        Contains(CF_Vector2f& point);
        bool        Contains(CF_CubicContour& other);

        bool        CheckWinding();
        bool        GetBounds(CF_BoundingBox& boundsBox);


    protected:

        // Book keeping for iterators.
        CF_Vector2f     m_Point[4];
        int             m_Index;
        int             m_CurrentPoint;

};

#endif

