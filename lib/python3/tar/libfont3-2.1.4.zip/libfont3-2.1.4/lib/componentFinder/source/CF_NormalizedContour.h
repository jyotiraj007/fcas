// Copyright (C) 2016 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// CF_NormalizedContour.h

#ifndef CF_NORMALIZED_CONTOUR_H
#define CF_NORMALIZED_CONTOUR_H

#include "CF_Contour.h"
#include "CF_ScaleOffset.h"
#include <stdlib.h>
#include <math.h>

class CF_NormalizedPoint
{
    public:

        CF_NormalizedPoint()
            :   m_Data(0)
        {};

        CF_NormalizedPoint(float x, float y)
        {
            m_Shorts.m_X = (short) floor(x);
            m_Shorts.m_Y = (short) floor(y);
        }

        operator int() { return m_Data; };

        bool operator ==(CF_NormalizedPoint& other)
        {
            bool equal = false;

            int epsilon = (int) (0x00007fff * EPSILON);  

            if (    ( abs(m_Shorts.m_X - other.m_Shorts.m_X) < epsilon) &&
                    ( abs(m_Shorts.m_Y - other.m_Shorts.m_Y) < epsilon)    )
            {
                equal = true;
            }

            return equal;
        }

        static void SetTolerance(float tolerance) { EPSILON = tolerance; };
        static float GetTolerance() { return    EPSILON; };

        union
        {
            int   m_Data;

            struct
            {
                short m_X;
                short m_Y;
            } m_Shorts;
        };

        static float EPSILON;
};


class CF_NormalizedContour
{
    public:
        /* CTOR */ CF_NormalizedContour();
        /* CTOR */ CF_NormalizedContour(CF_Contour& contour);


        CF_ArrayList<CF_NormalizedPoint>& GetOffsets();

    protected:

        CF_ArrayList<CF_NormalizedPoint> m_Points;
};

#endif
