// Copyright (C) 2016 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// CF_QuadPoints.h

#ifndef CF_QUAD_POINTS_H
#define CF_QUAD_POINTS_H

#include "CF_Vector2f.h"

struct CF_QuadPoints
{
    CF_QuadPoints() {};

    CF_QuadPoints(CF_Vector2f start, CF_Vector2f end, CF_Vector2f control)
        : m_Start   (start),
          m_End     (end),
          m_Control (control)
    {
    }

    void Set(CF_Vector2f start, CF_Vector2f end, CF_Vector2f control)
    {
        m_Start     = start;
        m_End       = end;
        m_Control   = control;
    }

    CF_Vector2f    m_Start;
    CF_Vector2f    m_End;
    CF_Vector2f    m_Control;
};


#endif

