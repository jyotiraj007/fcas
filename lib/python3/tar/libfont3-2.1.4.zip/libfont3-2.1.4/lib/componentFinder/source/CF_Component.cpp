// Copyright (C) 2016 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// CF_Component.cpp

#include "CF_Component.h"

CF_Component::CF_Component()
    :   m_GlyphId(-1),
        m_ScaleOffset()
{
}

CF_Component::CF_Component(int glyphId, CF_ScaleOffset scaleOffset)
    :   m_GlyphId(glyphId),
        m_ScaleOffset(scaleOffset)
{
}
