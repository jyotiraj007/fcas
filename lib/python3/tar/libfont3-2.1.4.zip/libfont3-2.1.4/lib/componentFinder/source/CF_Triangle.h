// Copyright (C) 2014 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// CF_Triangle.h

#ifndef CF_TRIANGLE_H
#define CF_TRIANGLE_H

#include "CF_Vector2f.h"
class CF_Line2D;

class CF_Triangle
{
    public:

        /* ctor */  CF_Triangle    ();
        /* ctor */  CF_Triangle    (const CF_Vector2f& vert0, const CF_Vector2f& vert1, const CF_Vector2f& vert2);

        void        Init        (const CF_Vector2f& vert0, const CF_Vector2f& vert1, const CF_Vector2f& vert2);

        bool        Intersects  (CF_Triangle& other);
        bool        Intersects  (CF_Line2D& other);

        CF_Vector2f    operator [] (int index) const;
        CF_Vector2f&   operator [] (int index);

    protected:

        CF_Vector2f     m_Vertices[3];
};

#endif // TRIANGLE_H
