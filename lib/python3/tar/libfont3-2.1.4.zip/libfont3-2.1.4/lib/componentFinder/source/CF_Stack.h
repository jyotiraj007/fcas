// Copyright (C) 2014 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// CF_Stack.h

#ifndef CF_STACK_H
#define CF_STACK_H

#include "CF_ArrayList.h"

template <class T> class CF_Stack
{
    public:
        /* Ctor */ CF_Stack    ();
        /* Dtor */~CF_Stack    ();

        void       Push     (T element);
        T          Pop      ();
        bool       IsEmpty  ();
        void       Reset    ();

        int        NumElements();
        T&         ElementAt(int index);

    protected:

        CF_ArrayList<T> m_Elements;

        int             m_StackIndex;
        int             m_StackHighWater;

        int             m_Interator;
};

template <class T>
CF_Stack<T>::CF_Stack()
{
    m_StackIndex = 0;
    m_StackHighWater = 0;
}

template <class T>
CF_Stack<T>::~CF_Stack()
{
    m_Elements.Clear();
}

template <class T>
void CF_Stack<T>::Reset()
{
    m_StackIndex = 0;
    m_StackHighWater = 0;
    m_Elements.Clear();
}

template <class T>
void CF_Stack<T>::Push(T element)
{
    // Does the array need to grow?
    if (m_StackIndex >= m_StackHighWater)
    {
        m_Elements.Add(element);
        m_StackHighWater++;
    }
    else
    {
       m_Elements[m_StackIndex] = element;
    }

    m_StackIndex++;
}

template <class T>
T CF_Stack<T>::Pop()
{
    T element;

    if (false == IsEmpty())
    {
        m_StackIndex--;
        element = m_Elements[m_StackIndex];
    }
    return element;
}

template <class T>
int CF_Stack<T>::NumElements()
{
    return m_StackIndex;
}

template <class T>
T& CF_Stack<T>::ElementAt(int index)
{
    return m_Elements[index];
}

template <class T>
bool CF_Stack<T>::IsEmpty()
{
    bool isEmpty = (m_StackIndex == 0);

    return isEmpty;
}

#endif
