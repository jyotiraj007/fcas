// Copyright (C) 2016 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// CF_IndexTable.h

#ifndef CF_INDEX_TABLE_H
#define CF_INDEX_TABLE_H

// Designed to work with a contiguous range of id's i.e. [65, 100].
// Uses simple offset from first glyph, i.e will store 65 in zero, etc.
// Size will be lastGlyph - firstGlyph, i.e will be wasteful for sparse list.
template<class T>
class CF_IndexTable
{
    public:

        /*  CTOR */     CF_IndexTable   ();
        /*  CTOR */     CF_IndexTable   (int firstIndex, int lastIndex);

        void            Init            (int firstIndex, int lastIndex);
        void            Clear           ();

        int             FirstIndex      ();
        int             LastIndex       ();

        int             Add             (T& element);
        T&              operator []     (int index);
        T&              Last            ();

    protected:

        bool            IsValidIndex(int idx);
        CF_ArrayList<T> m_Elements;

        int             m_FirstIndex;
        int             m_LastIndex;

        T               m_Sentry;
};


template<class T>
CF_IndexTable<T>::CF_IndexTable()
	: m_Elements()
{
    Init(-1, -1);
}

template<class T>
CF_IndexTable<T>::CF_IndexTable(int firstIndex, int lastIndex)
{
    Init(firstIndex, lastIndex);
}

template<class T>
void CF_IndexTable<T>::Init(int firstIndex, int lastIndex)
{
    m_FirstIndex = firstIndex;
    m_LastIndex  = lastIndex;

    int size = m_LastIndex - m_FirstIndex;

    m_Elements.SetNumElements(size + 1);
}

template<class T>
void CF_IndexTable<T>::Clear()
{
    m_FirstIndex = -1;
    m_LastIndex  = -1;

    m_Elements.Clear();
}


template<class T>
int CF_IndexTable<T>::FirstIndex()
{
    return m_FirstIndex;
}

template<class T>
int CF_IndexTable<T>::LastIndex()
{
    return m_LastIndex;
}


template<class T>
int CF_IndexTable<T>::Add(T& element)
{
    if (m_FirstIndex < 0)
    {
        m_FirstIndex = 0;
    }

    m_LastIndex++;

    m_Elements.Add();

    m_Elements[m_LastIndex - m_FirstIndex] = element;

    return m_LastIndex;
}

template<class T>
T& CF_IndexTable<T>::operator [] (int index)
{
    if (IsValidIndex(index))
    {
        return m_Elements[index - m_FirstIndex];
    }
    else
    {
        // printf("CF_IndexTable: Invalid glyphId.\n");
    }

    return m_Sentry;
}

template<class T>
T& CF_IndexTable<T>::Last()
{
    return operator [] (m_LastIndex);
}

template<class T>
bool CF_IndexTable<T>::IsValidIndex(int idx)
{
    bool validId = false;

    if (    (idx >= m_FirstIndex) && 
            (idx <= m_LastIndex))
    {
        validId = true;
    }

    return validId;
}



#endif
