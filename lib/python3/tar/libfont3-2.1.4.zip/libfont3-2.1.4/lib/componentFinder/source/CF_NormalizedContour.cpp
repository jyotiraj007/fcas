// Copyright (C) 2016 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// CF_NormalizedContour.cpp

#include "CF_NormalizedContour.h"
#include "CF_BoundingBox.h"


float CF_NormalizedPoint::EPSILON = 0.10f;


CF_NormalizedContour::CF_NormalizedContour()
{
    m_Points.Clear();
}

CF_ArrayList<CF_NormalizedPoint>& CF_NormalizedContour::GetOffsets()
{
    return m_Points;
}

CF_NormalizedContour::CF_NormalizedContour(CF_Contour& contour)
{
    CF_BoundingBox bounds;

    contour.GetPointBounds(bounds);

    // Normalize.
    float   dataWidth = (float) 0x00007fff;

    // Normalize in x.
    float   xScale = dataWidth / bounds.Width();

    // Normalize in y.
    float   yScale = dataWidth / bounds.Height();

    for (int i = 0; i < contour.NumPoints(); i++)
    {
        CF_ContourPoint& currPoint = contour.GetPoint(i);

        float x = currPoint.m_Point.X();
        float y = currPoint.m_Point.Y();

        x -= bounds.Left();
        y -= bounds.Bottom();

        x *= xScale;
        y *= yScale;

        m_Points.Add(CF_NormalizedPoint(x, y));
    }
}

