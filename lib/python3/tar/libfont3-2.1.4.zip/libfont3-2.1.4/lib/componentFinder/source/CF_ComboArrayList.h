// Copyright (C) 2016 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// CF_ComboArrayList.h

#ifndef CF_COMBO_ARRAY_LIST_H
#define CF_COMBO_ARRAY_LIST_H

#include "CF_ArrayList.h"

template <class T> 
class CF_ComboArrayList : public CF_ArrayList<T>
{
    public:

        int         NumCombos           ();
        void        GetCombo            (int index, CF_ArrayList<T>& sequence);

        bool        GetFirstPartition	(CF_ArrayList<CF_ArrayList<T> >& partition);
        bool        GetNextPartition	(CF_ArrayList<CF_ArrayList<T> >& partition);

    protected:

        int         NumElements         () const;
        T&          operator[]          (int index);
        const T&    operator[]          (int index) const;
        void        GetPartition(CF_ArrayList<CF_ArrayList<T> >& partition);

        int             m_NumCombinations;
        CF_ArrayList<T> m_Partitions;
        int             m_NumPartitions;
};

template <class T>
int CF_ComboArrayList<T>::NumElements() const
{
    return CF_ArrayList<CF_ArrayList<T> >::NumElements();
}

template <class T>
T& CF_ComboArrayList<T>::operator[](int index)
{
    return CF_ArrayList<CF_ArrayList<T> >::operator[](index);
}

template <class T>
const T& CF_ComboArrayList<T>::operator[] (int index) const
{
    return CF_ArrayList<CF_ArrayList<T> >::operator[](index);
}

template <class T>
void CF_ComboArrayList<T>::GetPartition(CF_ArrayList<CF_ArrayList<T> >& partition)
{
    partition.ResetIndex();

    int numGroups = 0;
    for (int i = 0; i < m_Partitions.NumElements(); i++)
    {
        if (m_Partitions[i] > numGroups)
        {
            numGroups = m_Partitions[i];
        }
    }

    numGroups++;

    CF_ArrayList<int> emptyList;

    for (int i = 0; i < numGroups; i++)
    {
        partition.Add(emptyList);
    }

    for (int i = 0; i < m_Partitions.NumElements(); i++)
    {
        int group = m_Partitions[i];
        partition[group].Add(operator[](i));
    }
}


template <class T> 
bool CF_ComboArrayList<T>::GetFirstPartition(CF_ArrayList<CF_ArrayList<T> >& partition)
{
    bool foundOne = false;

    m_Partitions.ResetIndex();

    int numElements = NumElements();


    if (numElements > 0)
    {
        foundOne = true;

        for (int i = 0; i < NumElements(); i++)
        {
            m_Partitions.Add(0);
        }

        GetPartition(partition);
    }

    return foundOne;
}


template <class T>
bool CF_ComboArrayList<T>::GetNextPartition(CF_ArrayList<CF_ArrayList<T> >& partition)
{
    bool foundPartition = false;

    unsigned int len = m_Partitions.NumElements();

    if (m_Partitions[len - 1] < len - 1)
    {
        bool finished = false;
        bool changed  = false;

        // Find the rightmost element no more than the other elements.
        for (int i = len - 1; !finished && !changed; i--)
        {
            int max = 0;
            // Find the highest element to the left of this one.
            for (int j = 0; j < i; j++)
            {
                if (m_Partitions[j] > max)
                {
                    max = m_Partitions[j];
                }
            }

            if (m_Partitions[i] <= max)
            {
                m_Partitions[i]++;
                changed = true;

                // Set the following elements to 0.
                for (int j = i + 1; j < len; j++)
                {
                    m_Partitions[j] = 0;
                }
            }
            finished = (i == 1);
        }
        GetPartition(partition);
        foundPartition = true;
    }

    return foundPartition;
}


template <class T>
int CF_ComboArrayList<T>::NumCombos()
{
    m_NumCombinations = pow(2.0f, NumElements());
    return m_NumCombinations;
}


template <class T>
void CF_ComboArrayList<T>::GetCombo(int index, CF_ArrayList<T>& sequence)
{
    sequence.ResetIndex();

    int current = 1;
    int num = 0;

    while (current < m_NumCombinations)
    {
        if (index & current)
        {
            sequence.Add(operator[](num));
        }

        num++;
        current <<= 1;
    }
}

#endif
