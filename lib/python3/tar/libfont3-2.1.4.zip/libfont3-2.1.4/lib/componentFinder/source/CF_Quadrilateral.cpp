// Copyright (C) 2014 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// CF_Quadrilateral.cpp

#include "CF_Quadrilateral.h"
#include "CF_Vector2f.h"
#include "CF_Line2D.h"
#include "CF_MathUtilities.h"


CF_Quadrilateral::CF_Quadrilateral()
{
}

CF_Quadrilateral::CF_Quadrilateral(const CF_Vector2f& vert0, const CF_Vector2f& vert1, const CF_Vector2f& vert2, const CF_Vector2f& vert3)
{
    Init(vert0, vert1, vert2, vert3);
}

void CF_Quadrilateral::Init(const CF_Vector2f& vert0, const CF_Vector2f& vert1, const CF_Vector2f& vert2, const CF_Vector2f& vert3)
{
    m_Vertices[0] = vert0;
    m_Vertices[1] = vert1;
    m_Vertices[2] = vert2;
    m_Vertices[3] = vert3;
}

CF_Vector2f CF_Quadrilateral::operator [](int index) const
{
    return m_Vertices[index];
}

CF_Vector2f& CF_Quadrilateral::operator [](int index) 
{
    return m_Vertices[index];
}

bool CF_Quadrilateral::Intersects(CF_Quadrilateral& other)
{
    CF_Vector2f normals[8];
    int index = 0;

    // Test along normal of each triangle side.
    for (int idx = 0; idx < 4; idx++)
    {
        int nextIdx = (idx + 1);
        if (nextIdx >= 4)
        {
            nextIdx = 0;
        }

        CF_Vector2f side   = m_Vertices[nextIdx] - m_Vertices[idx];
        normals[index++] = CF_Vector2f(-side.Y(), side.X());

        side   = other[nextIdx] - other[idx];
        normals[index++] = CF_Vector2f(-side.Y(), side.X());
    }

    for (int n = 0; n < 8; n++)
    {
        CF_Vector2f normal = normals[n];

        // Find projection of each point onto normal.
        // Vector from origin to point is same as point so use that.
        // Seed with first point.
        float quad1Max = normal.X() * m_Vertices[0].X() + normal.Y() * m_Vertices[0].Y();
        float quad1Min = quad1Max;

        // Same for other triangle.
        float quad2Max = normal.X() * other[0].X() + normal.Y() * other[0].Y();
        float quad2Min = quad2Max;

        for (int i = 1; i < 4; i++)
        {
            float dotProduct = normal.X() * m_Vertices[i].X() + normal.Y() * m_Vertices[i].Y();

            if (dotProduct > quad1Max)
            {
                quad1Max = dotProduct;
            }
            if (dotProduct < quad1Min)
            {
                quad1Min = dotProduct;
            }

            dotProduct = normal.X() * other[i].X() + normal.Y() * other[i].Y();

            if (dotProduct > quad2Max)
            {
                quad2Max = dotProduct;
            }
            if (dotProduct < quad2Min)
            {
                quad2Min = dotProduct;
            }
        }
        // Now test to see if disjoint along this axis.
        if ((quad2Max <= quad1Min) || (quad1Max <= quad2Min))
        {
            return false;
        }
    }

    return true;
}

bool CF_Quadrilateral::Intersects(CF_Line2D& line)
{
    CF_Vector2f normals[5];
    int index = 0;

    CF_Vector2f lineStart(line.Start());
    CF_Vector2f lineEnd(line.End());

    // Test along normal of each triangle side.
    for (int idx = 0; idx < 4; idx++)
    {
        int nextIdx = (idx + 1);
        if (nextIdx >= 4)
        {
            nextIdx = 0;
        }

        CF_Vector2f side   = m_Vertices[nextIdx] - m_Vertices[idx];
        normals[index++] = CF_Vector2f(-side.Y(), side.X());
    }
    // Test along normal of line.
    CF_Vector2f side = lineEnd - lineStart;
    normals[index++] = CF_Vector2f(-side.Y(), side.X());

    for (int n = 0; n < 5; n++)
    {
        CF_Vector2f normal = normals[n];

        // Dot product
        float lineMax = normal.X() * lineStart.X() + normal.Y() * lineStart.Y();
        float lineMin = normal.X() * lineEnd.X() + normal.Y() * lineEnd.Y();

        if (lineMax < lineMin)
        {
            CF_Swap(lineMax, lineMin);
        }
        // Find projection of each point onto normal.
        // Vector from origin to point is same as point so use that.
        // Seed with first point.
        float quad1Max = normal.X() * m_Vertices[0].X() + normal.Y() * m_Vertices[0].Y();
        float quad1Min = quad1Max;

        for (int i = 1; i < 4; i++)
        {
            float dotProduct = normal.X() * m_Vertices[i].X() + normal.Y() * m_Vertices[i].Y();

            if (dotProduct > quad1Max)
            {
                quad1Max = dotProduct;
            }
            if (dotProduct < quad1Min)
            {
                quad1Min = dotProduct;
            }
        }
        // Now test to see if disjoint along this axis.
        if ((lineMax <= quad1Min) || (quad1Max <= lineMin))
        {
            return false;
        }
    }

    return true;
}
