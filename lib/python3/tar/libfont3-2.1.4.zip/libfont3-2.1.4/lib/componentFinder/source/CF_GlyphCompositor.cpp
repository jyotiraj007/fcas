// Copyright (C) 2016 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// CF_GlyphCompositor.cpp

#include "CF_GlyphCompositor.h"
#include "CF_NormalizedContour.h"

#include "CF_ComboArrayList.h"


CF_GlyphCompositor::CF_GlyphCompositor() :
    m_FirstGroup(0),
    m_Verbose(false)
{
}


CF_GlyphCompositor::~CF_GlyphCompositor()
{
	CF_QuadGlyph::ClearHeap();
}


void CF_GlyphCompositor::Clear()
{
    m_Trie.Clear();
}

void CF_GlyphCompositor::AddGlyph(CF_QuadGlyph& quadGlyph)
{
    CF_Contour* pContour = quadGlyph.FirstContour();

    int numEmpty = 0;

    while (pContour)
    {
        CF_NormalizedContour nContour(*pContour);

        int sequenceId = m_Trie.AddSequence(nContour.GetOffsets());

        pContour->SetId(sequenceId);

        if (sequenceId == NO_SEQUENCE)
        {
            numEmpty++;
        }

        pContour = quadGlyph.NextContour();
    }
    for (int i = 0; i < numEmpty; i++)
    {
        quadGlyph.RemoveContour(NO_SEQUENCE);
    }
}


void CF_GlyphCompositor::AddGlyphs(CF_GlyphTable& glyphTable, float tolerance /* = 0.05f */, bool verbose /* = true */)
{
    m_Verbose = verbose;

    CF_NormalizedPoint::SetTolerance(tolerance);
    Clear();

    m_FirstGroup = glyphTable.LastIndex() + 1; // Any thing after this, we will have added, hence is a group. 

    for (int idx = glyphTable.FirstIndex(); idx <= glyphTable.LastIndex(); idx++)
    {
        AddGlyph(glyphTable[idx]);
    }
}

void CF_GlyphCompositor::Componentize(CF_GlyphTable& glyphTable)
{
    m_Trie.Clear(false); // Done with all except sequencecount so lets have the memory back.

    MakeGroupTrie(glyphTable);
}

void CF_GlyphCompositor::FindComponents(CF_GlyphTable& glyphTable, float tolerance /* = 0.05f */, bool verbose /* = true */)
{
    m_Verbose = verbose;

    if (m_Verbose)
    {
        printf("Glyph Table: %d to %d\n", glyphTable.FirstIndex(), glyphTable.LastIndex());
    }

    AddGlyphs(glyphTable, tolerance, verbose);
    Componentize(glyphTable);
}

void CF_GlyphCompositor::MakeGroupTrie(CF_GlyphTable& glyphTable)
{
    m_GroupTrie.Clear();

    CF_ArrayList<CF_ArrayList<int> > groups;
    CF_ArrayList<int>                numPoints;

    int last = glyphTable.LastIndex();

    for (int glyphId = glyphTable.FirstIndex(); glyphId <= last; glyphId++)
    {
        if (m_Verbose)
        {
            printf("Analysing GlyphId: %d \r", glyphId);
        }

        CF_QuadGlyph& glyph = glyphTable[glyphId];

        glyph.GetNestedContours(groups, numPoints);

        for (int i = 0; i < groups.NumElements(); i++)
        {
            CF_ArrayList<int>& currentGroup = groups[i];

            if (currentGroup.NumElements() > 0)
            {
                m_GroupTrie.AddSequence(currentGroup);
            }
        }
    }

    if (m_Verbose)
        printf("\n");

    last = glyphTable.LastIndex();

    for (int glyphId = glyphTable.FirstIndex(); glyphId <= last; glyphId++)
    {
        if (m_Verbose)
        {
            printf("Componentizing GlyphId: %d\r", glyphId);
        }

        CF_QuadGlyph& glyph = glyphTable[glyphId];

        if (false == glyph.IsComponent())
        {
            CF_ContourGroup contourGroup;

            GetGroups(glyph, groups);

            if (groups.NumElements() > 1) // Don't let glyph make a component of itself.
            {
				int neededGroups = groups.NumElements() + 1;

				// Glyph Table can be no bigger than 65k.
				if ((glyphTable.LastIndex() + neededGroups) < 65535)
				{
                for (int i = 0; i < groups.NumElements(); i++)
                {
                    contourGroup.Clear();
                    CF_ArrayList<int>& current = groups[i];

                    bool foundAll = GetGroup(glyphId, glyphTable, contourGroup, current);

                    CF_QuadGlyph group(contourGroup);

                    if (foundAll)
                    {
                        group.SetGlyphId(glyphId);
                        int groupId = CreateGroup(group, glyphTable);

                        CF_QuadGlyph newGroup = glyphTable[groupId];
                        glyph.AddComponent(newGroup);
                    }
                }
					// Now fix up any remaining contours for true type compatibility.
					if (glyph.HasComponents() &&
						glyph.HasContours())
					{
						CF_QuadGlyph contours(glyph.m_Contours);
						int groupId = CreateGroup(contours, glyphTable);
						CF_QuadGlyph group = glyphTable[groupId];

						glyph.AddComponent(group);
					}
				}
            }
        }
    }
    if (m_Verbose)
        printf("\n");
}

//
void CF_GlyphCompositor::GetGroups(CF_QuadGlyph& glyph, CF_ArrayList<CF_ArrayList<int> >& groups)
{
    const int minPoints = 4;

    CF_ArrayList<CF_ArrayList<int> > localGroups;
    CF_ArrayList<int>				 groupNumPoints;
    groups.ResetIndex();

    glyph.GetNestedContours(localGroups, groupNumPoints);

    for (int i = 0; i < localGroups.NumElements(); i++)
    {
        CF_ArrayList<int>& currentGroup = localGroups[i];

        if (currentGroup.NumElements() > 0)
        {
            int sequenceId = m_GroupTrie.FindSequence(currentGroup);

            int count = 0;
            int numPoints = 0;

            if (sequenceId != NO_SEQUENCE)
            {
                count	  = m_GroupTrie.SequenceCount(sequenceId);
                numPoints = groupNumPoints[i];
            }

            // If all have a count of one then this is a singleton glyph.
            if (count > 1 && numPoints > minPoints)
            {
                groups.Add(currentGroup);
            }
        }
    }
}


bool CF_GlyphCompositor::GetGroup(int glyphId, CF_GlyphTable& glyphTable, CF_ContourGroup& group, CF_ArrayList<int>& sequence)
{
    CF_QuadGlyph& glyph = glyphTable[glyphId];

    glyph.ClearTags(); // Avoid repeat contours.

    bool foundAll = true;
    group.Clear();

    for (int k = 0; k < sequence.NumElements(); k++)
    {
        CF_QuadContour* pContour = glyph.GetSequence(sequence[k]);

        if (pContour != NULL)
        {
            group.AddContour(*pContour);
            pContour->SetTag(true);
        }
        else
        {
            foundAll = false;
        }
    }
    glyph.ClearTags();
    group.ClearTags();

    return foundAll;
}


int CF_GlyphCompositor::CreateGroup(CF_QuadGlyph& group, CF_GlyphTable& glyphTable) // maybe make glyphtable a member variable.
{
    // Check if we already have it.
    int groupIndex = FindGroup(group, glyphTable);

    if (groupIndex == -1)
    {
        groupIndex = glyphTable.Add(group);

        CF_QuadGlyph& quadGlyph = glyphTable.Last();
        quadGlyph.SetIsComponent(true);
        quadGlyph.SetGlyphId(groupIndex);
    }
    else
    {
        CF_QuadGlyph& quadGlyph = glyphTable[groupIndex];
        quadGlyph.SetIsComponent(true);
    }

    return groupIndex;
}
// Return the index of the group glyph in the glyphTable, search the end only where we have created new groups.
int CF_GlyphCompositor::FindGroup(CF_QuadGlyph& group, CF_GlyphTable& glyphTable)
{
    int groupIndex = -1;

    for (int glyphId = 0; glyphId <= glyphTable.LastIndex(); glyphId++)
    {
        // Operator == has been overloaded for CF_QuadGlyph.
        if (    (false   == glyphTable[glyphId].HasComponents()) &&
                (glyphId != (int)group.GetGlyphId())            &&
                (glyphTable[glyphId] == group))    // Order matters here, because we check for scaling from/to < 2.0 per TrueType.
        {
            groupIndex = glyphId;
            break;
        }
    }

    return groupIndex;
}




int CF_GlyphCompositor::CalcSize(CF_GlyphTable& glyphTable)
{
    int size = 0;

    for (int i = glyphTable.FirstIndex(); i <= glyphTable.LastIndex(); i++)
    {
        // Operator == has been overloaded for CF_QuadGlyph.
        size += glyphTable[i].SizeBytes();
    }

    return size;
}
