// Copyright (C) 2015 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// CF_QuadGlyph.cpp

#include "CF_QuadGlyph.h"
#include "CF_BoundingBox.h"
#include <stdlib.h>

CF_QuadGlyph::CF_QuadGlyph()
: m_GlyphId((unsigned int)-1),
  m_IsComponent(false)
{
}

CF_QuadGlyph::CF_QuadGlyph(unsigned int glyphId)
: m_GlyphId(glyphId),
  m_IsComponent(false)
{
}

CF_QuadGlyph::CF_QuadGlyph(CF_LinkedList<CF_QuadContour>& contours)
: m_GlyphId((unsigned int)-1),
  m_IsComponent(false)
{
    CF_QuadContour* pContour = contours.First();

    while (pContour)
    {
        AddContour(*pContour);
        pContour = contours.Next();
    }
}


CF_QuadGlyph::CF_QuadGlyph(CF_ContourGroup& contourGroup)
    : m_GlyphId((unsigned int)-1),
    m_IsComponent(false)
{
    CF_QuadContour* pContour = contourGroup.FirstContour();

    while (pContour)
    {
        AddContour(*pContour);
        pContour = contourGroup.NextContour();
    }
}

void CF_QuadGlyph::SetGlyphId(unsigned int glyphId)
{
    m_GlyphId = glyphId;
}


unsigned int CF_QuadGlyph::GetGlyphId() const
{
    return m_GlyphId;
}


void CF_QuadGlyph::Scale(float xScale, float yScale)
{
    CF_QuadContour* pContour = FirstContour();

    while (pContour)
    {
        pContour->Scale(xScale, yScale);
        pContour = NextContour();
    }
}

void CF_QuadGlyph::SetIsComponent(bool isComponent)
{
    m_IsComponent = isComponent;
}

bool CF_QuadGlyph::IsComponent()
{
    return m_IsComponent;
}

void CF_QuadGlyph::Clear()
{
    m_Contours  .RemoveAll();
    m_Components.RemoveAll();
}

void CF_QuadGlyph::AddContour(CF_QuadContour& contour)
{
    m_Contours.Add(contour);
}


void CF_QuadGlyph::AddComponent(CF_Component& component)
{
    m_Components.Add(component);
}


CF_Component* CF_QuadGlyph::FirstComponent()
{
    return m_Components.First();
}

CF_Component* CF_QuadGlyph::NextComponent()
{
    return m_Components.Next();
}

bool CF_QuadGlyph::ContoursIntersect()
{
    CF_ListElem<CF_QuadContour>* pContour1 = m_Contours.GetFirstElement();

    while (pContour1)
    {
        CF_ListElem<CF_QuadContour>* pContour2 = m_Contours.GetNext(pContour1);

        while (pContour2)
        {
            if (pContour1->m_Data.Intersects(pContour2->m_Data))
            {
                return true;
            }
            pContour2 = m_Contours.GetNext(pContour2);
        }
        pContour1 = m_Contours.GetNext(pContour1);
    }
    return false;
}


void CF_QuadGlyph::GetNestedContours(CF_ArrayList<CF_ArrayList<int> >& contourGroups, CF_ArrayList<int>& counts)
{
    contourGroups.ResetIndex();
    counts.ResetIndex();

    CalcNesting();


    CF_ListElem<CF_QuadContour>* pOuterContour = m_Contours.GetFirstElement();

    while (pOuterContour)
    {
        if (pOuterContour->m_Data.GetNestingLevel() % 2 == 0)
        {
            CF_ArrayList<int> newList;
            newList.Add(pOuterContour->m_Data.GetId());

            int index = contourGroups.Add(newList);

            counts.Add(pOuterContour->m_Data.NumPoints());

            CF_ListElem<CF_QuadContour>* pInnerContour = m_Contours.GetFirstElement();

            while (pInnerContour)
            {
                if (pInnerContour->m_Data.GetNestingLevel() == (pOuterContour->m_Data.GetNestingLevel() + 1))
                {
                    if (pOuterContour->m_Data.Contains(pInnerContour->m_Data))
                    {
                        contourGroups[index].Add(pInnerContour->m_Data.GetId());
                        counts[index] += pInnerContour->m_Data.NumPoints();
                    }
                }

                pInnerContour = m_Contours.GetNext(pInnerContour);
            }
        }

        pOuterContour = m_Contours.GetNext(pOuterContour);
    }
}

void CF_QuadGlyph::CalcNesting()
{
    CF_QuadContour* pContour = FirstContour();

    while (pContour)
    {
        pContour->ClearNestingLevel();

        pContour = NextContour();
    }

    CF_ListElem<CF_QuadContour>* pCurrentContour = m_Contours.GetFirstElement();

    while (pCurrentContour)
    {
        CF_ListElem<CF_QuadContour>* pNextContour = m_Contours.GetNext(pCurrentContour);

        while (pNextContour)
        {
            if (pCurrentContour->m_Data.Contains(pNextContour->m_Data))
            {
                pNextContour->m_Data.IncNestingLevel();
            }

            if (pNextContour->m_Data.Contains(pCurrentContour->m_Data))
            {
                pCurrentContour->m_Data.IncNestingLevel();
            }

            pNextContour = m_Contours.GetNext(pNextContour);
        }
        pCurrentContour = m_Contours.GetNext(pCurrentContour);
    }
}


CF_QuadContour* CF_QuadGlyph::FirstContour()
{
    return m_Contours.First();
}

CF_QuadContour* CF_QuadGlyph::NextContour()
{
    return m_Contours.Next();
}


void CF_QuadGlyph::AddComponent(CF_QuadGlyph& glyph)
{
    CF_QuadContour* pOther = glyph.FirstContour();

    if (pOther)
    {
        CF_QuadContour* pThis  = GetSequence(pOther->GetId());

        if (pThis)
        {
            CF_ScaleOffset scaleOffset = pThis->GetScaleOffset(*pOther);

            CF_Component component(glyph.GetGlyphId(), scaleOffset);
            m_Components.Add(component);

            CF_QuadContour* pContour = glyph.FirstContour();

            while (pContour)
            {
                int sequenceId = pContour->GetId();

                RemoveContour(sequenceId);
                pContour = glyph.NextContour();
            }
        }
    }
}


bool CF_QuadGlyph::operator==(CF_QuadGlyph& other)
{
    if (NumContours() != other.NumContours())
    {
        return false;
    }

	ClearTags();
    CF_QuadContour* pOtherContour = other.FirstContour();

    while (pOtherContour)
    {
        int sequenceId = pOtherContour->GetId();

        CF_QuadContour* pContour = GetSequence(sequenceId);

        if (NULL == pContour)
        {
            return false;
        }
		pContour->SetTag(true);

        pOtherContour = other.NextContour();
    }

    // Make sure the scaleOffset is the same for each contour.
    pOtherContour = other.FirstContour();

	if (NULL == pOtherContour)
	{
		return false;
	}

	ClearTags();
    int sequenceId  = pOtherContour->GetId();

    CF_QuadContour* pContour = GetSequence(sequenceId);
	pContour->SetTag(true);

    CF_ScaleOffset lastScaleOffset  = pOtherContour->GetScaleOffset(*pContour); 
    CF_ScaleOffset currentScaleOffset;

    if (false == lastScaleOffset.IsTrueTypeCompatible())
    {
        return false;
    }

    pOtherContour = other.NextContour();

    while (pOtherContour)
    {
        sequenceId = pOtherContour->GetId();

        pContour = GetSequence(sequenceId);

        if (NULL != pContour) 
        {
			pContour->SetTag(true);
            currentScaleOffset = pOtherContour->GetScaleOffset(*pContour);

            if ( (currentScaleOffset != lastScaleOffset) ||
                 (false == currentScaleOffset.IsTrueTypeCompatible()) ) 
            {
                return false;
            }
            lastScaleOffset = currentScaleOffset;
        }
        else
        {
            return false;
        }

        pOtherContour = other.NextContour();
    }

    return true;
}

int CF_QuadGlyph::NumContours()
{
    return m_Contours.NumElements();
}

bool CF_QuadGlyph::HasComponents()
{
    return (false == m_Components.IsEmpty());
}

bool CF_QuadGlyph::HasContours()
{
    return (false == m_Contours.IsEmpty());
}

CF_QuadContour* CF_QuadGlyph::RemoveContour(int sequenceId)
{
    CF_QuadContour* pQuadContour = NULL;

    CF_ListElem<CF_QuadContour>* pContour = m_Contours.GetFirstElement();

    while (pContour)
    {
        if (pContour->m_Data.GetId() == sequenceId)
        {
            pQuadContour = &pContour->m_Data;
            m_Contours.Remove(pContour);
            break;
        }
        pContour = m_Contours.GetNextElement();
    }

    return pQuadContour;
}

int CF_QuadGlyph::NumPoints(int sequenceId)
{
    int numPoints = 0;

    CF_QuadContour* pContour = m_Contours.First();

    while (pContour)
    {
        if (pContour->GetId() == sequenceId)
        {
            numPoints = pContour->NumPoints();
            break;
        }
        pContour = m_Contours.Next();
    }

    return numPoints;
}

CF_QuadContour* CF_QuadGlyph::GetSequence(int sequenceId)
{
    CF_QuadContour* pContour = m_Contours.First();

    while (pContour)
    {
        if (    (pContour->Tag() == false) &&
                (pContour->GetId() == sequenceId))
        {
            return pContour;
        }
        pContour = m_Contours.Next();
    }

    return NULL;
}


bool CF_QuadGlyph::GetBounds(CF_BoundingBox& bounds)
{
    bool onCurveAtExtrema = true;

    bounds.Reset();

    CF_QuadContour* pContour = m_Contours.First();

    while (pContour)
    {
        onCurveAtExtrema &= pContour->GetBounds(bounds);
        pContour = m_Contours.Next();
    }

    return onCurveAtExtrema;
}

bool CF_QuadGlyph::Contains(CF_QuadGlyph& other)
{
    //bool contains = false;

    if (FirstContour() == NULL || other.FirstContour() == NULL)
    {
        return false;
    }

    if (NumContours() < other.NumContours())
    {
        return false;
    }

    CF_QuadContour* pContour = other.FirstContour();

    while (pContour)
    {
        int sequenceId = pContour->GetId();

        if (NULL == GetSequence(sequenceId))
        {
            return false;
        }

        pContour = other.NextContour();
    }

    return true;
}

void CF_QuadGlyph::ClearHeap()
{
    CF_LinkedList<CF_QuadContour>::ClearHeap();
    CF_LinkedList<CF_Component>::ClearHeap();
}


void CF_QuadGlyph::ClearTags()
{
    CF_QuadContour* pContour = m_Contours.First();

    while (pContour)
    {
        pContour->SetTag(false);

        pContour = m_Contours.Next();
    }
}

int CF_QuadGlyph::SizeBytes()
{
    int total = 0;

    CF_QuadContour* pContour = m_Contours.First();

    while (pContour)
    {
        total += pContour->SizeBytes();    
        pContour = m_Contours.Next();
    }

    CF_Component* pComponent = m_Components.First();

    while (pComponent)
    {
        total += sizeof(CF_Component);
        pComponent = m_Components.Next();
    }

    return total;
}
