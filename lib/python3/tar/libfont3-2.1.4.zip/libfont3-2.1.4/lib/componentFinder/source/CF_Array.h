// Copyright (C) 2014 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// CF_Array.h

#ifndef CF_ARRAY_H
#define CF_ARRAY_H

//lint -sem(Array::Clear,cleanup)

#include <string.h>

template <class T> class CF_Array
{
    enum { MINIMUM_SIZE  = 4 };

    public:

        /* Ctor */  CF_Array    ();
        /* Ctor */  CF_Array    (int initialSize);
        /* Ctor */  CF_Array    (const CF_Array& other);
        /* Dtor */ ~CF_Array    ();

        CF_Array&   operator=   (const CF_Array& other);
        CF_Array&   operator+=  (const CF_Array& other);

        int         NumElements () const;

        int         Add         (const T newElement);

        T&          operator[]  (int index);
        const T&    operator[]  (int index) const;

        bool        Contains    (const T& element) const;
        bool        Contains    (const CF_Array<T>& other) const;

        void        Clear       ();

    protected:

        bool        IsValidIndex    (int index) const;
        void        SetSize         (int size);

        void        Expand          ();

        T*          m_Data;

        int         m_CurrentSize;
        int         m_NumElements;
};

template <class T>
CF_Array<T>::CF_Array()
{
    m_CurrentSize   = 0;
    m_NumElements   = 0;
    m_Data = NULL;
}

template <class T>
CF_Array<T>::CF_Array(int initialSize)
{
    m_CurrentSize   = 0;
    m_NumElements   = 0;
    m_Data = NULL;
    SetSize(initialSize);
}

template <class T>
CF_Array<T>::CF_Array(const CF_Array& other)
{
    m_CurrentSize   = 0;
    m_NumElements   = 0;
    m_Data = NULL;

    int numElems = other.GetSize();
    for (int i = 0; i < numElems; i++)
    {
        Add(other[i]);
    }
}

template <class T>
CF_Array<T>& CF_Array<T>::operator=(const CF_Array& other)
{
    if (this != &other)
    {
        Clear();
        for (int i = 0; i < other.NumElements(); i++)
        {
            Add(other[i]);
        }
    }
    return *this;
}

template <class T>
CF_Array<T>& CF_Array<T>::operator+=(const CF_Array& other)
{
    if (this != &other)
    {
        for (int i = 0; i < other.NumElements(); i++)
        {
            Add(other[i]);
        }
    }
    return *this;
}

template <class T>
CF_Array<T>::~CF_Array()
{
    Clear();    //lint !e1551
}


template <class T>
int CF_Array<T>::Add(const T newElement)
{
    int index = m_NumElements;
    m_NumElements++;

    if (m_CurrentSize == 0)
    {
        SetSize(MINIMUM_SIZE);
    }

    while (index >= m_CurrentSize)
    {
        Expand();
    }

    if (index > m_NumElements)
    {
        m_NumElements = index;
    }

    operator[](index) = newElement;
    return index;
}

template <class T>
T& CF_Array<T>::operator[](int index)
{
    if (m_CurrentSize == 0)
    {
        SetSize(MINIMUM_SIZE);
    }

    while (index >= m_CurrentSize)
    {
        Expand();
    }

    if (index > m_NumElements)
    {
        m_NumElements = index;
    }

    return m_Data[index];
}

template <class T>
const T& CF_Array<T>::operator[](int index) const
{
    if ((IsValidIndex(index)) && (m_Data != NULL))
    {
        return m_Data[index];
    }

    return m_Data[0];
}

template <class T>
bool CF_Array<T>::Contains(const T& element) const
{
    for (int i = 0; i < NumElements(); i++) 
    {
        if (operator[](i) == element)
        {
            return true;
        }
    }
    return false;
}

template <class T>
bool CF_Array<T>::Contains(const CF_Array<T>& other) const
{
    bool contains = true;

    if (    (NumElements() == 0)        ||
            (other.NumElements() == 0)  ||
            (NumElements() <= other.NumElements()))
    {
        return false;
    }

    int i = 0;

    while (contains && i < other.NumElements())
    {
        contains = contains && Contains(other[i]);
        i++;
    }

    return contains;
}



template <class T>
int CF_Array<T>::NumElements() const
{
    return m_NumElements;
}

template <class T>
void CF_Array<T>::SetSize(int size)
{
    if (size < MINIMUM_SIZE)
    {
       size  = MINIMUM_SIZE;
    }

    m_CurrentSize = size;
    m_Data        = new T[m_CurrentSize];
}

template <class T>
void CF_Array<T>::Expand()
{
    // New array is twice as big.
    T* temp = new T[m_CurrentSize * 2];

    if (temp != NULL)
    {
        // Copy old data over.
        if ((m_Data != NULL) && (m_CurrentSize > 0))
        {
            memcpy(temp, m_Data, m_CurrentSize * sizeof(T));
        }

        // Delete old data.
        delete [] (T*) m_Data;

        // Fix up to point to new CF_Array.
        m_Data = temp;

        m_CurrentSize *= 2;
    }
    else
    {
        printf("Out of memory in CF_Array::Expand.\n");
    }
}

template <class T>
void CF_Array<T>::Clear()
{
    if (NULL != m_Data)
    {
        delete[] (T*) m_Data;
        m_Data = NULL;
    }

    m_CurrentSize = 0;
    m_NumElements = 0;
}

template <class T>
bool CF_Array<T>::IsValidIndex(int index) const
{
    bool valid = false;

    if ((index >= 0) &&
        (index < m_NumElements))
    {
        valid = true;
    }
    return valid;
}

#endif // CF_ARRAY_H
