// Copyright (C) 2014 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
/// \file CF_Vector2f.h

#ifndef CF_VECTOR2_F_H
#define CF_VECTOR2_F_H

class Vector2i;
class Vector2;

//! Provides 2D vector (float) operations
/*!
    Defines vector addition, subtraction, and comparison. Permits indexed access to vector components. 
    See also Vector2.
*/
class CF_Vector2f
{
   public:
        /* Ctor */      CF_Vector2f        ();
        /* Ctor */      CF_Vector2f        (float x, float y);
        /* Ctor */      CF_Vector2f        (const CF_Vector2f& other);

        const float&    operator[]          (int i) const;
        float&          operator[]          (int i);
        float           X                   () const;
        float           Y                   () const;
        CF_Vector2f     operator-           (const CF_Vector2f& other) const;
        CF_Vector2f     operator+           (const CF_Vector2f& other) const;
        CF_Vector2f     operator+=          (const CF_Vector2f& other);

        bool            operator==          (const CF_Vector2f& other) const;
        bool            operator!=          (const CF_Vector2f& other) const;

        float           LengthSquared       () const;

        friend
        CF_Vector2f     operator*           (float scale, const CF_Vector2f& other);

        void            FromFixed           (long x, long y);

        bool            IsValid             () const;

    protected:

        float           m_X;
        float           m_Y;
};


/**
    Access to coordinates.
    @param[in] i Coordinate index
    @return Coordinate value.
*/

inline const float& CF_Vector2f::operator[](int i) const
{
    if (i == 0)
        return m_X;
    else
        return m_Y;
}


inline float& CF_Vector2f::operator[](int i)
{
    if (i == 0)
        return m_X;
    else
        return m_Y;
}

inline float CF_Vector2f::X() const
{
    return m_X;
}

inline float CF_Vector2f::Y() const
{
    return m_Y;
}

#endif
