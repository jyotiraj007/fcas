// Copyright (C) 2014 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// CF_LinkedList.h
#ifndef CF_LINKED_LIST_H
#define CF_LINKED_LIST_H

#include <stdlib.h>
#include "CF_ArrayList.h"

// A linked list wherein all of the elements are stored on a CF_ArrayList that is shared amongst all lists of 
// the same type. i.e. All CF_LinkedList<int>'s elements will be stored on one static array.
// This simplifies use of the list, prevents heap fragmentation.
// Tear down of all lists<type> is by static member ClearHeap

// The elements of the linked list.
template<class Data>
class CF_ListElem
{
    public:

        CF_ListElem()
            : m_Next(NULL)
        {
        }

        CF_ListElem(const Data& data)
            :   m_Data(data),
                m_Next(NULL)
        {
        }

        Data            m_Data;   // The data we are storing on the list.
        CF_ListElem*    m_Next;   
};


template<class Data>
class CF_LinkedList
{
    public:

        /* Ctor */          CF_LinkedList();
        /* Ctor */          CF_LinkedList(CF_LinkedList& other);

        /* Dtor */         ~CF_LinkedList();


        void                Add             (const Data& data);

        void                Remove          (CF_ListElem<Data>* pElement);
        void                InsertAfter     (CF_ListElem<Data>* pElement, CF_ListElem<Data>* pNewElement);

        void                RemoveAll       ();
        int                 NumElements     ();

        // Iterators:
        Data*               First        ();
        Data*               Next         ();
        Data*               Last         ();

        CF_ListElem<Data>*  GetFirstElement ();
        CF_ListElem<Data>*  GetNextElement  ();
        CF_ListElem<Data>*  GetLastElement  ();
        CF_ListElem<Data>*  GetPrevious     (const CF_ListElem<Data>* pElement);
        CF_ListElem<Data>*  GetNext         (const CF_ListElem<Data>* pElement) const;

        CF_ListElem<Data>*  Find            (Data& data);

        bool                IsEmpty         () const;

        static void         ClearHeap       ();
        static void         PrintMem();

		void                FreePool		(); // Only use on program exit to avoid erroneous memory leak message.

    protected:

        CF_ListElem<Data>*  AllocElem       (const Data& data);

        CF_ListElem<Data>*  m_Head;
        CF_ListElem<Data>*  m_Tail;
        CF_ListElem<Data>*  m_Iterator;

        static CF_ArrayList<CF_ListElem<Data> > m_Elements;
};

template<class Data>
void CF_LinkedList<Data>::PrintMem()
{
    m_Elements.PrintMem();
}

template<class Data>
CF_ArrayList<CF_ListElem<Data> >  CF_LinkedList<Data>::m_Elements;


template<class Data>
void CF_LinkedList<Data>::ClearHeap()
{
	m_Elements.Clear();
}

template<class Data>
CF_LinkedList<Data>::CF_LinkedList()
{
    m_Head = NULL;
    m_Tail = NULL;
    m_Iterator = NULL;
}

template<class Data>
CF_LinkedList<Data>::CF_LinkedList(CF_LinkedList& other)
{
    m_Head = NULL;
    m_Tail = NULL;
    m_Iterator = NULL;

    Data* pElement = other.First();

    while (pElement)
    {
        Add(*pElement);
        pElement = other.Next();
    }
}

template<class Data>
CF_LinkedList<Data>::~CF_LinkedList()
{
}

// Only use on program exit to avoid erroneous memory leak message!
// This deletes pool memory for all lists of this template type.
template<class Data>
void CF_LinkedList<Data>::FreePool()
{
 	m_Elements.FreeAll();
}

template<class Data>
CF_ListElem<Data>* CF_LinkedList<Data>::AllocElem(const Data& data)
{
    CF_ListElem<Data> elem(data);
    m_Elements.Add(elem);
    return &m_Elements.Last();
}

template<class Data>
void CF_LinkedList<Data>::Add(const Data& data)
{
    CF_ListElem<Data>* pElement = AllocElem(data);

    if (NULL != pElement)
    {
        pElement->m_Next = NULL;

        // If empty set head.
        if (IsEmpty())
        {
            m_Head = pElement;
            m_Tail = pElement;
        }
        else // Add to the end.
        {
            if (m_Tail != NULL)
            {
                m_Tail->m_Next = pElement;
            }
            m_Tail = pElement;
        }
    }
}


template<class Data>
int CF_LinkedList<Data>::NumElements()
{
    int count = 0;

    CF_ListElem<Data>* pElement = GetFirstElement();

    while (pElement)
    {
        count++;
        pElement = GetNextElement();
    }

    return count;
}

template<class Data>
void CF_LinkedList<Data>::Remove(CF_ListElem<Data>* pElement)
{
    if (pElement)
    {
        CF_ListElem<Data>* pPrevious = GetPrevious(pElement);

        // If it's the only element, null out head and tail pointers.
        if (m_Head == m_Tail)
        {
            m_Head = NULL;
            m_Tail = NULL;
        }
        else if (pElement == m_Head)
        {
            m_Head = m_Head->m_Next;
        }
        else if (pElement == m_Tail)
        {
            m_Tail = pPrevious;
        }

        if (pPrevious)
        {
            pPrevious->m_Next = pElement->m_Next;
        }

        // No longer part of list so zero out pointer.
        pElement->m_Next = NULL;
    }
}

template<class Data>
void CF_LinkedList<Data>::InsertAfter(CF_ListElem<Data>* pElement, CF_ListElem<Data>* pNewElement)
{
    if ((pElement == NULL) || (pNewElement == NULL))
        return;

    if (m_Tail == pElement)
    {
        m_Tail = pNewElement;
    }
    pNewElement->m_Next = pElement->m_Next;
    pElement->m_Next = pNewElement;
}

template<class Data>
CF_ListElem<Data>* CF_LinkedList<Data>::GetNext(const CF_ListElem<Data>* pElement) const
{
    return pElement->m_Next;
}

template<class Data>
CF_ListElem<Data>*  CF_LinkedList<Data>::GetPrevious(const CF_ListElem<Data>* pElement)
{
    CF_ListElem<Data>* pCurrent  = m_Head;
    CF_ListElem<Data>* pPrevious = NULL;

    while (pCurrent)
    {
        if (pCurrent == pElement)
        {
            return pPrevious;
        }
        pPrevious = pCurrent;
        pCurrent = pCurrent->m_Next;
    }
    return NULL;
}



// operator == must be available on Data.
template<class Data>
CF_ListElem<Data>*  CF_LinkedList<Data>::Find(Data& data)
{
    CF_ListElem<Data>* pCurrent = m_Head;

    while (pCurrent)
    {
        if (pCurrent->m_Data == data)
        {
            return pCurrent;
        }
        pCurrent = pCurrent->m_Next;
    }
    return NULL;
}


template<class Data>
void CF_LinkedList<Data>::RemoveAll()
{
    CF_ListElem<Data>* pCurrent = m_Head;
    CF_ListElem<Data>* pLast    = m_Head;

    while (NULL != pCurrent)
    {
        pLast = pCurrent;
        pCurrent = pCurrent->m_Next;
        pLast->m_Next = NULL;
    }

    m_Head = NULL;
    m_Tail = NULL;
}

template<class Data>
Data* CF_LinkedList<Data>::First()
{
    Data* pData = NULL;

    m_Iterator = m_Head;

    if (NULL != m_Iterator)
    {
        pData = &m_Iterator->m_Data;
    }
    return pData;
}

template<class Data>
Data* CF_LinkedList<Data>::Last()
{
    Data* pData = NULL;
    m_Iterator = m_Tail;

    if (NULL != m_Iterator)
    {
        pData = &m_Iterator->m_Data;
    }
    return pData;
}

template<class Data>
Data* CF_LinkedList<Data>::Next()
{
    Data* pData = NULL;

    if (m_Iterator != m_Tail)
    {
       m_Iterator = m_Iterator->m_Next;
    }
    else
    {
        m_Iterator = NULL;
    }

    if (NULL != m_Iterator)
    {
        pData = &m_Iterator->m_Data;
    }

    return pData;
}

template<class Data>
CF_ListElem<Data>* CF_LinkedList<Data>::GetFirstElement()
{
    m_Iterator = m_Head;

    return m_Iterator;
}

template<class Data>
CF_ListElem<Data>* CF_LinkedList<Data>::GetLastElement()
{
    m_Iterator = m_Tail;

    return m_Iterator;
}

template<class Data>
CF_ListElem<Data>* CF_LinkedList<Data>::GetNextElement()
{
    if ((m_Iterator != m_Tail) && (m_Iterator != NULL))
    {
       m_Iterator = m_Iterator->m_Next;
    }
    else
    {
        m_Iterator = NULL;
    }
    return m_Iterator;
}

template<class Data>
bool CF_LinkedList<Data>::IsEmpty() const
{
   bool isEmpty = false;

   if (   (NULL == m_Head)
       && (NULL == m_Tail) )
   {
      isEmpty = true;
   }

   return isEmpty;
}

#endif
