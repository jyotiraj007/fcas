// Copyright (C) 2014 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// CF_Quadrilateral.h

#ifndef CF_QUADRILATERAL_H
#define CF_QUADRILATERAL_H

#include "CF_Vector2f.h"

class CF_Line2D;

class CF_Quadrilateral
{
    public:

        /* ctor */  CF_Quadrilateral();
        /* ctor */  CF_Quadrilateral(const CF_Vector2f& vert0, const CF_Vector2f& vert1, const CF_Vector2f& vert2, const CF_Vector2f& vert3);

        void        Init        (const CF_Vector2f& vert0, const CF_Vector2f& vert1, const CF_Vector2f& vert2, const CF_Vector2f& vert3);
        bool        Intersects  (CF_Quadrilateral& other);
        bool        Intersects  (CF_Line2D& line);

        CF_Vector2f    operator [] (int index) const;
        CF_Vector2f&   operator [] (int index);

    protected:

        CF_Vector2f     m_Vertices[4];
};

#endif // QUADRILATERAL_H
