// Copyright (C) 2015 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
/// \file CF_CubicGlyph.h
#ifndef CF_CUBIC_GLYPH_H
#define CF_CUBIC_GLYPH_H

#include "CF_CubicContour.h"
#include "CF_LinkedList.h"

class CF_BoundingBox;

class CF_CubicGlyph 
{
    public:

        /* CTOR */          CF_CubicGlyph       ();
        /* CTOR */          CF_CubicGlyph       (unsigned int glyphId);
        /* CTOR */          CF_CubicGlyph       (CF_LinkedList<CF_CubicContour>& contours);

        void                Clear               ();

		void				SetGlyphId			(unsigned int glyphId);
		unsigned int		GetGlyphId			() const;

        void                AddContour          (CF_CubicContour& contour);

		CF_CubicContour*	FirstContour		();
		CF_CubicContour*	NextContour			();

        int                 NumContours         ();

        bool                GetBounds           (CF_BoundingBox& bounds);

        bool                ContoursIntersect   ();

        static void         ClearHeap           ();

    protected:

        unsigned int        m_GlyphId;

        void                CalcNesting         ();

        CF_LinkedList<CF_CubicContour>   m_Contours;
};

#endif
