// Copyright (C) 2015 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// CF_CubicGlyph.cpp

#include "CF_CubicGlyph.h"
#include "CF_BoundingBox.h"

CF_CubicGlyph::CF_CubicGlyph()
    : m_GlyphId((unsigned int) -1)
{
}

CF_CubicGlyph::CF_CubicGlyph(unsigned int glyphId)
    : m_GlyphId(glyphId)
{
}


void CF_CubicGlyph::Clear()
{
    m_Contours.RemoveAll();
}

void CF_CubicGlyph::AddContour(CF_CubicContour& contour)
{
    m_Contours.Add(contour);

}

CF_CubicContour* CF_CubicGlyph::FirstContour()
{
    return m_Contours.First();
}

CF_CubicContour* CF_CubicGlyph::NextContour()
{
    return m_Contours.Next();
}


bool CF_CubicGlyph::ContoursIntersect()
{
    CF_ListElem<CF_CubicContour>* pContour1 = m_Contours.GetFirstElement();
    
    while (pContour1)
    {
        CF_ListElem<CF_CubicContour>* pContour2 = m_Contours.GetNext(pContour1);
        
        while (pContour2)
        {
            if (pContour1->m_Data.Intersects(pContour2->m_Data))
            {
                return true;
            }
            pContour2 = m_Contours.GetNext(pContour2);
        }
        pContour1 = m_Contours.GetNext(pContour1);
    }
    return false;

}

/*
void CF_CubicGlyph::CalcNesting()
{
    int numContours = m_Contours.NumElements();

    for (int i = 0; i < numContours; i++)
    {
        m_Contours[i].ClearNestingLevel();
    }

    for (int i = 0; i < numContours - 1; i++)
    {
        CF_CubicContour* pContour = m_pContours[i];

        for (int j = i + 1; j < numContours; j++)
        {
            CF_CubicContour* other = m_pContours[j];

            if (pContour->Contains(*other))
            {
                other->IncNestingLevel();
            }
            if (other->Contains(*pContour))
            {
                pContour->IncNestingLevel();
            }
        }
    }
}
*/

/*
bool CF_CubicGlyph::CheckWinding()
{
    bool windingOk = true;

    CalcNesting();

    for (int i = 0; i < m_pContours.NumElements(); i++)
    {
       windingOk &= m_pContours[i]->CheckWinding();
    }

    return windingOk;
}

*/
int CF_CubicGlyph::NumContours()
{
    return m_Contours.NumElements();
}


bool CF_CubicGlyph::GetBounds(CF_BoundingBox& bounds)
{
    bool onCurveAtExtrema = true;

    bounds.Reset();

    CF_CubicContour* pContour = m_Contours.First();

    while (pContour)
    {
        onCurveAtExtrema &= pContour->GetBounds(bounds);
        pContour = m_Contours.Next();
    }

    return onCurveAtExtrema;
}

void CF_CubicGlyph::ClearHeap()
{
    CF_LinkedList<CF_CubicContour>::ClearHeap();
}

void CF_CubicGlyph::SetGlyphId(unsigned int glyphId)
{
    m_GlyphId = glyphId;
}

unsigned int	CF_CubicGlyph::GetGlyphId() const
{
    return m_GlyphId;
}
