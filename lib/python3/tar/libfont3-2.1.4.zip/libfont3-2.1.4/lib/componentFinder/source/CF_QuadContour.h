// Copyright (C) 2015 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// CF_QuadContour.h

#ifndef CF_QUAD_CONTOUR_H
#define CF_QUAD_CONTOUR_H

#include "CF_Contour.h"

class  CF_Line2D;
class  CF_QuadBezier;
struct CF_QuadPoints;
class  CF_ScaleOffset;

class CF_QuadContour : public CF_Contour
{
    public:
        /* CTOR */      CF_QuadContour();

        bool            GetFirstQuad(CF_QuadPoints& points);
        bool            GetNextQuad (CF_QuadPoints& points);

        bool            GetFirstLine(CF_Line2D& line);
        bool            GetNextLine (CF_Line2D& line);

        bool            Intersects  (CF_QuadContour& otherContour);

        bool            Intersects  (CF_Line2D& line);
        bool            Intersects  (CF_QuadBezier& cubic);

        void            GetIntersections(CF_QuadContour& otherContour, CF_ArrayList<CF_Vector2f>& intersections);

        void            GetIntersections(CF_Line2D& line,      CF_ArrayList<CF_Vector2f>& intersections);
        void            GetIntersections(CF_QuadBezier& cubic, CF_ArrayList<CF_Vector2f>& intersections);

        bool            Contains(CF_Vector2f& point);
        bool            Contains(CF_QuadContour& other);

        bool            CheckWinding();

        bool            GetBounds       (CF_BoundingBox& boundsBox); // Bounds of the actual outline.

        void            SetTag  (bool value) { m_Tag = value; };
        bool            Tag     ()           { return m_Tag;  }

    protected:

        bool            IsSinglePoint(CF_BoundingBox& boundsBox);

        // Book keeping for iterators.
        CF_Vector2f     m_Point[3];
        int             m_Index;
        int             m_CurrentPoint;
        bool            m_Tag;
};

#endif

