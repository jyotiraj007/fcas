// Copyright (C) 2016 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// H_QuadPoints.h

#ifndef H_QUAD_POINTS_H
#define H_QUAD_POINTS_H

#include "H_Vector2f.h"

struct H_QuadPoints
{
    H_QuadPoints() {};

    H_QuadPoints(H_Vector2f start, H_Vector2f end, H_Vector2f control)
        : m_Start   (start),
          m_End     (end),
          m_Control (control)
    {
    }

    void Set(H_Vector2f start, H_Vector2f end, H_Vector2f control)
    {
        m_Start     = start;
        m_End       = end;
        m_Control   = control;
    }

    H_Vector2f    m_Start;
    H_Vector2f    m_End;
    H_Vector2f    m_Control;
};


#endif

