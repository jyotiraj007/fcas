// Copyright (C) 2016 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// H_Trie.h

#ifndef H_TRIE_H
#define H_TRIE_H

#include <stdio.h>
#include <limits.h>
#include "H_ArrayList.h"
#include "H_HashTable.h"


#define NO_SEQUENCE -1

template<class T>
class H_TrieElement
{
    public:
        /* CTOR */  H_TrieElement ();
        /* CTOR */  H_TrieElement (T& data, int sequenceNumber);

        H_TrieElement*     Find        (T& data);
        void                AddNext     (H_TrieElement* pNewElement);
        void                AddChild    (H_TrieElement* pNewElement);
        H_TrieElement*     Last        ();

        T                   m_Data;
        H_TrieElement<T>*  m_Next;
        H_TrieElement<T>*  m_Child;
        int                 m_SequenceNumber;

};

template<class T>
H_TrieElement<T>::H_TrieElement()
    :   m_Data          (),
        m_Next          (NULL),
        m_Child         (NULL),
        m_SequenceNumber(NO_SEQUENCE)
{
}

template<class T>
H_TrieElement<T>::H_TrieElement(T& data, int sequenceNumber)
    :   m_Data          (data),
        m_Next          (NULL),
        m_Child         (NULL),
        m_SequenceNumber(sequenceNumber)
{
}


template<class T>
H_TrieElement<T>* H_TrieElement<T>::Last()
{
    H_TrieElement<T>* pLast    = this;
    H_TrieElement<T>* pCurrent = this;

    while (pCurrent)
    {
        pLast    = pCurrent;
        pCurrent = pCurrent->m_Next;
    }

    return pLast;
}

template<class T>
void H_TrieElement<T>::AddNext(H_TrieElement* pNewElement)
{
    H_TrieElement<T>* pLast = Last();

    pLast->m_Next = pNewElement;
}

template<class T>
void H_TrieElement<T>::AddChild(H_TrieElement* pNewElement)
{
    if (NULL == m_Child)
    {
        m_Child = pNewElement;
    }
    else
    {
        m_Child->AddNext(pNewElement);
    }
}

template<class T>
H_TrieElement<T>* H_TrieElement<T>::Find(T& data)
{
    H_TrieElement<T>* pElement = this;

    while (pElement != NULL)
    {
        if (data == pElement->m_Data)
        {
            return pElement;
        }
        pElement = pElement->m_Next;
    }

    return pElement;
}

template<class T>
class H_Trie
{
    public:

        /* CTOR */          H_Trie         ();
        /* DTOR */         ~H_Trie         ();

        int                 AddSequence     (H_ArrayList<T>& sequence, int firstIndex = 0); // use first index to add suffixes: start adding at firstIndex.
        int                 FindSequence    (H_ArrayList<T>& sequence);

        int                 SequenceCount   (int sequenceId);
        int                 NumSequences    ();

        void                Clear           (bool clearSequenceCount = true);   // Might not need this either.
        bool                IsEmpty         ();
        int                 NumNodes        ();

        bool                AreEqual(H_TrieElement<T>* pOne, H_TrieElement<T>* pTwo);

        void                Reduce();

        H_TrieElement<T>*  m_Root;

    protected:

        int                 NewSequenceId();
        bool                FindSubSequence(H_TrieElement<T>* pElement, H_ArrayList<T>& subSequence);

        H_TrieElement<T>*  AllocElement(T& data, int sequenceNumber);

        int                 m_NumLevels;
        H_ArrayList<H_TrieElement<T> > m_Elems;

        int                 m_NumNodes;

        H_ArrayList<int>   m_SequenceCount;

        int                 m_CurrentSequence;

};

template<class T>
H_Trie<T>::H_Trie()
    :   m_Root              (NULL),
        m_NumLevels         (0),
        m_NumNodes          (0),
        m_CurrentSequence   (0)
{
    m_Root = new H_TrieElement<T>();
    m_SequenceCount.SetSentry(0);
}

template<class T>
H_Trie<T>::~H_Trie()
{
    delete m_Root;
}

template<class T>
void H_Trie<T>::Clear(bool clearSequenceCount /* = true */)
{
    m_Elems.Clear();

    m_Root->m_Child = NULL;
    m_Root->m_Next = NULL;
    m_CurrentSequence = 0;

    if (clearSequenceCount)
    {
        m_SequenceCount.Clear();
    }
}

template<class T>
int H_Trie<T>::NewSequenceId()
{
    int index = m_SequenceCount.Add();

    return index;
}

template<class T>
int H_Trie<T>::NumNodes()
{
    return m_NumNodes;
}

template<class T>
int H_Trie<T>::NumSequences()
{
    return m_SequenceCount.NumElements();
}

template<class T>
int H_Trie<T>::SequenceCount(int sequenceId)
{
    return m_SequenceCount[sequenceId];
}

template<class T>
bool H_Trie<T>::IsEmpty()
{
    bool isEmpty = false;

    if (m_Root == NULL)
    {
        isEmpty = true;
    }
    return isEmpty;
}

template<class T>
H_TrieElement<T>* H_Trie<T>::AllocElement(T& data, int sequenceNumber)
{
    m_NumNodes++;

    H_TrieElement<T> newElement(data, sequenceNumber);

    m_Elems.Add(newElement);
    H_TrieElement<T>* pElement = &m_Elems.Last();

    return pElement;
}

template<class T>
int H_Trie<T>::AddSequence(H_ArrayList<T>& sequence, int firstIndex /* = 0 */)
{
    (void) firstIndex;
    int sequenceId = NO_SEQUENCE;

    H_TrieElement<T>* pPrevNode = m_Root;
    H_TrieElement<T>* pCurrNode = m_Root->m_Child;

    int numElements = sequence.NumElements();

    for (int i = 0; i < numElements; i++)
    {
        bool endOfWord = (i == numElements - 1) ? true : false;

        H_TrieElement<T>* pMatch = NULL;

        if (NULL != pCurrNode)
        {
            pMatch = pCurrNode->Find(sequence[i]);
        }

        if (NULL == pMatch)
        {
            H_TrieElement<T>* pNewElement = NULL;

            if (endOfWord)
            {
                sequenceId = NewSequenceId();
                m_SequenceCount[sequenceId] = 1;
                pNewElement = AllocElement(sequence[i], sequenceId);
            }
            else
            {
                pNewElement = AllocElement(sequence[i], NO_SEQUENCE);
            }

            pPrevNode->AddChild(pNewElement);

            pPrevNode = pNewElement;
            pCurrNode = NULL;
        }
        else
        {
            pPrevNode = pMatch;
            pCurrNode = pMatch->m_Child;

            if (endOfWord)
            {
                sequenceId = pMatch->m_SequenceNumber;

                // End of our sequence but not at leaf node.
                // so we need to mark this node as being a valid sequence end.
                if (sequenceId == NO_SEQUENCE)
                {
                    sequenceId = NewSequenceId();
                    m_SequenceCount[sequenceId] = 1;
                }
                else
                {
                    m_SequenceCount[sequenceId]++;
                }
            }
        }
    }
    return sequenceId;
}


template<class T>
bool H_Trie<T>::AreEqual(H_TrieElement<T>* pOne, H_TrieElement<T>* pTwo)
{
    bool areEqual = true;

    if (pOne != NULL && pTwo != NULL)
    {
        if (pOne->m_Data != pTwo->m_Data)
        {
            return false;
        }
        else
        {
            if ((pOne->m_Next == NULL) == (pTwo->m_Next == NULL))
            {
                areEqual = AreEqual(pOne->m_Next, pTwo->m_Next);

                if (areEqual)
                {
                    if ((pOne->m_Child == NULL) == (pTwo->m_Child == NULL))
                    {
                        areEqual = AreEqual(pOne->m_Child, pTwo->m_Child);
                    }
                }
            }
            else
            {
                return false;
            }
        }
    }

    return areEqual;
}


template<class T>
int H_Trie<T>::FindSequence(H_ArrayList<T>& sequence)
{
    int i;

    H_TrieElement<T>* pLastNode = m_Root;
    H_TrieElement<T>* pCurrNode = m_Root->m_Child;

    int numElements = sequence.NumElements();

    for (i = 0; i < numElements; i++)
    {
        H_TrieElement<T>* pMatch = NULL;

        if (NULL != pCurrNode)
        {
            pMatch = pCurrNode->Find(sequence[i]);
        }

        if (pMatch)
        {
            pLastNode = pMatch;
            pCurrNode = pMatch->m_Child;
        }
        else
        {
            return NO_SEQUENCE;
        }
    }

    if ((i == numElements) && (pLastNode->m_SequenceNumber != NO_SEQUENCE))
    {
        return pLastNode->m_SequenceNumber;
    }

    return NO_SEQUENCE;
}

template<class T>
bool H_Trie<T>::FindSubSequence(H_TrieElement<T>* pElement, H_ArrayList<T>& subSequence)
{
   int i;

    H_TrieElement<T>* pLastNode = pElement;
    H_TrieElement<T>* pCurrNode = pElement->m_Child;

    int numElements = subSequence.NumElements();

    for (i = 0; i < numElements; i++)
    {
        H_TrieElement<T>* pMatch = NULL;

        if (NULL != pCurrNode)
        {
            pMatch = pCurrNode->Find(subSequence[i]);
        }

        if (pMatch)
        {
            pLastNode = pMatch;
            pCurrNode = pMatch->m_Child;
        }
        else
        {
            return false;
        }
    }

    if (i == numElements)
    {
        return true;
    }

    return false;
}

#endif
