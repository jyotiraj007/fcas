// Copyright (C) 2015 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
/// \file CubicContour.h

#ifndef H_CUBIC_CONTOUR_H
#define H_CUBIC_CONTOUR_H

#include "H_Contour.h"
class QuadContour;

#define DEFAULT_CUBIC_UNITS 1000

class H_CubicContour : public H_Contour
{
    public:
        /*  CTOR */     H_CubicContour(int designUnits = DEFAULT_CUBIC_UNITS);

		int             FirstOnCurve();
		int             NextOnCurve();

    protected:

		int m_CurrentIndex;
};

#endif

