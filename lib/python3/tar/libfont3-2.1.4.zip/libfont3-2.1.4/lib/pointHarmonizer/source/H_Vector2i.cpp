// Copyright (C) 2014 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// Vector2i.cpp

#include "H_Vector2i.h"
#include <math.h>


H_Vector2i::H_Vector2i(int x /* = 0 */, int y /* = 0 */)
{
    m_Vector[0] = x;
    m_Vector[1] = y;
}

H_Vector2i::H_Vector2i(H_Vector2f& other)
{
    H_Vector2f rounded = other.Rounded();

    m_Vector[0] = (int) rounded[0];
    m_Vector[1] = (int) rounded[1];
}

/**
    Computes length of vector.
    @return length of vector.
*/
float H_Vector2i::Length() const
{
    float length = (float)sqrt((float)(m_Vector[0] * m_Vector[0] + m_Vector[1] * m_Vector[1]));
    return length;
}

H_Vector2i H_Vector2i::operator-(const H_Vector2i& other) const
{
    return H_Vector2i(m_Vector[0] - other.m_Vector[0], m_Vector[1] - other.m_Vector[1]);
}
