// Copyright (C) 2016 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
/// \file Harmonizer.cpp

#include "Harmonizer.h"
#include "H_GlyphHarmonizer.h"

//#define HCOMP_DUMP
#ifdef HCOMP_DUMP

static void dumpHCubic(H_CubicGlyph* cubicGlyph)
{
    printf("\nCubic Glyph:\n");

    if (cubicGlyph->NumContours() == 0)
    {
        printf("   ---No Contours---\n\n");
        return;
    }

    H_CubicContour* contour = cubicGlyph->FirstContour();

    int totPts = 0, i = 0;

    while (contour)
    {
        int numPts = contour->NumPoints();

        totPts += numPts;

        printf("contour %d (%d pts)\n", i++, numPts);
        for (int j = 0; j < numPts; j++)
        {
            H_Vector2f point = contour->GetPoint(j).m_Point;
            printf("%f %f\n", point[0], point[1]);
        }

        contour = cubicGlyph->NextContour();
    }

    printf("num points: %d\n\n", totPts);
}

static char* TypeToString(H_ContourPoint::H_PointType type)
{
    switch (type)
    {
    case H_ContourPoint::H_PointType::ON_CURVE: return "ON_CURVE";
    case H_ContourPoint::H_PointType::OFF_CURVE: return "OFF_CURVE";
    default: return "<UNKNOWN?>";
    }
}

static void dumpHQuad(H_QuadGlyph* quadGlyph)
{
    printf("\nQuadContour:\n");
    printf("num contours: %d\n", quadGlyph->NumContours());

    H_QuadContour* pContour = quadGlyph->FirstContour();
    int contourIndex = 0;

    while (pContour)
    {
        printf("Contour %d:\n", contourIndex++);

        int contourNpts = pContour->NumPoints();

        for (int j = 0; j < contourNpts; j++)
        {
            H_ContourPoint point = pContour->GetPoint(j);
            printf("%f %f (%s)\n", (float)point.m_Point[0], (float)point.m_Point[1], TypeToString(point.m_Type));
        }

        pContour = quadGlyph->NextContour();
    }

    printf("\n");
}

#define DumpHQuad(q) dumpHQuad(q);
#define DumpHCubic(c) dumpHCubic(c);

#else
#define DumpHQuad(q)
#define DumpHCubic(c)
#endif

static Harmonizer_Error GlyphToQuadGlyph(Glyph* input, H_QuadGlyph& output)
{
    if (input->glyphType != eGlyph_TTF)
        return HARMONIZER_INVALID_PARAM;

    if (input->glyphOutline.numberOfComponents == 0)
        return HARMONIZER_SUCCESS;

    if ((input->glyphOutline.numberOfComponents > 1) ||
        (input->glyphOutline.component.type == eIsComposite))
    {
        // The glyphs must not be composites!
        return HARMONIZER_INVALID_PARAM;
    }

    Simple_Outline* quadOutline = &input->glyphOutline.component.outline;

    int np = quadOutline->np;
    float* x = quadOutline->x;
    float* y = quadOutline->y;
    Point_Type* types = quadOutline->types;

    if (np == 0 || x == NULL || y == NULL || types == NULL)
        return HARMONIZER_INVALID_PARAM;

    // First point must be a moveto
    if (types[0] != MOVE_TO)
        return HARMONIZER_INVALID_PARAM;

    H_QuadContour quadContour;

    for (int i = 0; i < np/*- 2 not expecting phantom pts*/; i++)
    {
        switch (types[i])
        {
        case MOVE_TO:
            if (i != 0)
            {
                if (quadContour.NumPoints() > 0)
                    output.AddContour(quadContour);
                quadContour.Clear();
            }
            quadContour.AddPoint(H_ContourPoint(H_ContourPoint::ON_CURVE, H_Vector2f(x[i], y[i])));
            break;
        case LINE_TO:
            quadContour.AddPoint(H_ContourPoint(H_ContourPoint::ON_CURVE, H_Vector2f(x[i], y[i])));
            break;
        case ON_CURVE:
            quadContour.AddPoint(H_ContourPoint(H_ContourPoint::ON_CURVE, H_Vector2f(x[i], y[i])));
            break;
        case OFF_CURVE:
            quadContour.AddPoint(H_ContourPoint(H_ContourPoint::OFF_CURVE, H_Vector2f(x[i], y[i])));
            break;
        }
    }

    // Add last contour
    if (quadContour.NumPoints() > 0)
        output.AddContour(quadContour);

    DumpHQuad(&output);

    return HARMONIZER_SUCCESS;
}

static Harmonizer_Error GlyphToCubicGlyph(Glyph* input, H_CubicGlyph& output)
{
    if (input->glyphType != eGlyph_CFF)
        return HARMONIZER_INVALID_PARAM;

    if (input->glyphOutline.numberOfComponents == 0)
        return HARMONIZER_SUCCESS;

    if ((input->glyphOutline.numberOfComponents > 1) ||
        (input->glyphOutline.component.type == eIsComposite))
    {
        // The glyphs must not be composites!
        return HARMONIZER_INVALID_PARAM;
    }

    Simple_Outline* cubicOutline = &input->glyphOutline.component.outline;

    int np = cubicOutline->np;
    float* x = cubicOutline->x;
    float* y = cubicOutline->y;
    Point_Type* types = cubicOutline->types;

    if (np == 0 || x == NULL || y == NULL || types == NULL)
        return HARMONIZER_INVALID_PARAM;

    // First point must be a moveto
    if (types[0] != MOVE_TO)
        return HARMONIZER_INVALID_PARAM;

    H_CubicContour cubicContour;

    for (int i = 0; i < np- 2 /*expecting phantom pts*/; i++)
    {
        switch (types[i])
        {
        case MOVE_TO:
            if (i != 0)
            {
                if (cubicContour.NumPoints() > 0)
                    output.AddContour(cubicContour);
                cubicContour.Clear();
            }
            cubicContour.AddPoint(H_ContourPoint(H_ContourPoint::ON_CURVE, H_Vector2f(x[i], y[i])));
            break;
        case LINE_TO:
            cubicContour.AddPoint(H_ContourPoint(H_ContourPoint::ON_CURVE, H_Vector2f(x[i], y[i])));
            break;
        case ON_CURVE:
            cubicContour.AddPoint(H_ContourPoint(H_ContourPoint::ON_CURVE, H_Vector2f(x[i], y[i])));
            break;
        case OFF_CURVE:
            cubicContour.AddPoint(H_ContourPoint(H_ContourPoint::OFF_CURVE, H_Vector2f(x[i], y[i])));
            break;
        }
    }

    // Add last contour
    if (cubicContour.NumPoints() > 0)
        output.AddContour(cubicContour);

    DumpHCubic(&output);

    return HARMONIZER_SUCCESS;
}

static bool IsClosed(H_QuadContour* contour)
{
    if (contour->NumPoints() == 1)
        return false;

    H_ContourPoint first = contour->GetPoint(0);
    H_ContourPoint last = contour->GetPoint(contour->NumPoints() - 1);

    if ((first.m_Point == last.m_Point) &&
        (last.m_Type != H_ContourPoint::OFF_CURVE))
    {
        return true;
    }

    return false;
}

static void computeBoundingBox(Glyph* quad)
{
    Simple_Outline *quadOutline = &quad->glyphOutline.component.outline;

    quad->glyphOutline.xMax = quad->glyphOutline.xMin = quadOutline->x[0];
    quad->glyphOutline.yMax = quad->glyphOutline.yMin = quadOutline->y[0];

    for (int j = 1; j < quadOutline->np; j++)
    {
        if (quadOutline->x[j] > quad->glyphOutline.xMax)
            quad->glyphOutline.xMax = quadOutline->x[j];
        if (quadOutline->x[j] < quad->glyphOutline.xMin)
            quad->glyphOutline.xMin = quadOutline->x[j];
        if (quadOutline->y[j] > quad->glyphOutline.yMax)
            quad->glyphOutline.yMax = quadOutline->y[j];
        if (quadOutline->y[j] < quad->glyphOutline.yMin)
            quad->glyphOutline.yMin = quadOutline->y[j];
    }
}

static Harmonizer_Error QuadGlyphToGlyph(H_QuadGlyph& input, Glyph* output)
{
    Simple_Outline* quadOutline = &output->glyphOutline.component.outline;

    // NOTE: this routine uses malloc/free to be consisent with conversion_allocateGlyphOutline/conversion_freeGlyphOutline

    // free existing memory
    free(quadOutline->endPtsOfContours);
    free(quadOutline->x);
    free(quadOutline->y);
    free(quadOutline->types);

    quadOutline->nc = (unsigned short)input.NumContours();

    int np = 0;

    H_QuadContour* pContour = input.FirstContour();

    while (pContour)
    {
        int contourNpts = pContour->NumPoints();

        if (contourNpts != 0)
        {
            if (IsClosed(pContour))
                contourNpts -= 1;

            np += contourNpts;
        }
        else
            quadOutline->nc--;

        pContour = input.NextContour();
    }


    if (quadOutline->nc == 0)
    {
        memset(quadOutline, 0, sizeof(Simple_Outline));
        output->glyphOutline.yMin = 0;
        output->glyphOutline.yMax = 0;
        output->glyphOutline.xMin = 0;
        output->glyphOutline.xMax = 0;

        return HARMONIZER_SUCCESS;
    }

    quadOutline->np = (unsigned short)np;

    quadOutline->endPtsOfContours = (unsigned short*)calloc(quadOutline->nc, sizeof(unsigned short));
    if (NULL == quadOutline->endPtsOfContours)
        return HARMONIZER_MEMORY;

    float* x = quadOutline->x = (float*)calloc(np, sizeof(float));
    if (NULL == x)
    {
        free(quadOutline->endPtsOfContours);
        return HARMONIZER_MEMORY;
    }

    float* y = quadOutline->y = (float*)calloc(np, sizeof(float));
    if (NULL == y)
    {
        free(x);
        free(quadOutline->endPtsOfContours);
        return HARMONIZER_MEMORY;
    }

    quadOutline->types = (Point_Type*)calloc(np, sizeof(Point_Type));
    if (NULL == quadOutline->types)
    {
        free(y);
        free(x);
        free(quadOutline->endPtsOfContours);
        return HARMONIZER_MEMORY;
    }

    unsigned short index = 0;
    int nContour = 0;

    pContour = input.FirstContour();

    while (pContour)
    {
        int nPts = pContour->NumPoints();

        if (nPts != 0)
        {
            if (IsClosed(pContour))
                nPts -= 1;

            for (int j = 0; j < nPts; j++)
            {
                H_ContourPoint point = pContour->GetPoint(j);
                x[index] = point.m_Point[0];
                y[index] = point.m_Point[1];

                Point_Type type;

                if (j == 0)
                    type = MOVE_TO;
                else if (point.m_Type == H_ContourPoint::OFF_CURVE)
                    type = OFF_CURVE;
                else
                {
                    H_ContourPoint prevPoint = pContour->GetPoint(j - 1);
                    if (prevPoint.m_Type == H_ContourPoint::OFF_CURVE)
                        type = ON_CURVE;
                    else
                        type = LINE_TO;
                }

                quadOutline->types[index++] = type;
            }
            quadOutline->endPtsOfContours[nContour++] = index - 1;
        }

        pContour = input.NextContour();
    }

    computeBoundingBox(output);

    //DumpQuad(&output); not implemented, see Conversion.cpp if needed.

    return HARMONIZER_SUCCESS;
}

static Harmonizer_Error harmonizeQuadsToQuads(Glyph* glyphs, int numGlyphs, int unitsPerEm,
                                              harmonizerParameters* params, bool verbose)
{
    Harmonizer_Error herr = HARMONIZER_INVALID_PARAM;

    // Create array of quad glyphs
    H_ArrayList<H_QuadGlyph> quadGlyphs;

    for (int i = 0; i < numGlyphs; i++)
    {
        H_QuadGlyph curGlyph;

        herr = GlyphToQuadGlyph(&glyphs[i], curGlyph);

        if (herr != HARMONIZER_SUCCESS)
        {
            // todo cleanup
            return herr;
        }

        quadGlyphs.Add(curGlyph);
    }


    // Call algorithm
    H_GlyphHarmonizer harmonizer;

    bool matched = false;

    matched = harmonizer.HarmonizeGlyph(quadGlyphs, unitsPerEm,
                                        params->noContorCheck ? true : false,
                                        params->noExtremaAdding ? true : false,
                                        params->noStartPointCheck ? true : false,
                                        verbose);

    // replace glyph data
    for (int i = 0; i < (int)numGlyphs; i++)
    {
        herr = QuadGlyphToGlyph(quadGlyphs[i], &glyphs[i]);
        if (herr != HARMONIZER_SUCCESS)
            break;
    }

    harmonizer.Clear();

    if ((herr == HARMONIZER_SUCCESS) && (false == matched))
        herr = HARMONIZER_FAILED_MATCH;

    return herr;
}

static Harmonizer_Error harmonizeQuadsToCubics(Glyph* glyphs, int numGlyphs, int unitsPerEm,
    harmonizerParameters* params, bool verbose)
{
    (void)glyphs, (void)numGlyphs, (void)unitsPerEm, (void)params, (void)verbose;

    return HARMONIZER_UNIMPLEMENTED;
}

static Harmonizer_Error harmonizeCubicsToQuads(Glyph* glyphs, int numGlyphs, int unitsPerEm,
    harmonizerParameters* params, bool verbose)
{
    (void)params;
    (void)unitsPerEm;
    (void)verbose;

    Harmonizer_Error herr = HARMONIZER_INVALID_PARAM;

    // Create array of cubic glyphs
    H_ArrayList<H_CubicGlyph> cubicGlyphs;

    for (int i = 0; i < numGlyphs; i++)
    {
        H_CubicGlyph curGlyph;

        herr = GlyphToCubicGlyph(&glyphs[i], curGlyph);

        if (herr != HARMONIZER_SUCCESS)
        {
            // todo cleanup
            return herr;
        }

        cubicGlyphs.Add(curGlyph);
    }

    // Create array of output quad glyphs, contours added by algorithm
    H_ArrayList<H_QuadGlyph> quadGlyphs;
    for (int i = 0; i < numGlyphs; i++)
    {
        H_QuadGlyph emptyGlyph;
        quadGlyphs.Add(emptyGlyph);
    }


    // Call algorithm
    H_GlyphHarmonizer harmonizer;

    H_GlyphHarmonizer::H_Result result = harmonizer.HarmonizeGlyph(cubicGlyphs, quadGlyphs);

    // replace glyph data
    for (int i = 0; i < (int)numGlyphs; i++)
    {
        herr = QuadGlyphToGlyph(quadGlyphs[i], &glyphs[i]);
        if (herr != HARMONIZER_SUCCESS)
            break;

        glyphs[i].glyphType = eGlyph_TTF;
    }

    for (int i = 0; i < (int)numGlyphs; i++)
        quadGlyphs[i].ClearHeap();
    quadGlyphs.Clear();
    harmonizer.Clear();

    if (herr == HARMONIZER_SUCCESS)
    {
        if (result == H_GlyphHarmonizer::eFAILED)
        {
            herr = HARMONIZER_FAILED_MATCH;
        }
        else if (result == H_GlyphHarmonizer::eINVALID_INPUT)
        {
            herr = HARMONIZER_INVALID_INPUT;
        }
    }

    return herr;
}

static Harmonizer_Error harmonizeCubicsToCubics(Glyph* glyphs, int numGlyphs, int unitsPerEm,
    harmonizerParameters* params, bool verbose)
{
#if 0
    (void)glyphs, (void)numGlyphs, (void)unitsPerEm, (void)params, (void)verbose;

    return HARMONIZER_UNIMPLEMENTED;
#else
    // temp - just do nothing
    (void)glyphs, (void)numGlyphs, (void)unitsPerEm, (void)params, (void)verbose;
    return HARMONIZER_SUCCESS;
#endif
}


extern "C" Harmonizer_Error harmonizer_harmonizeGlyphs(Glyph* glyphs, int numGlyphs, int unitsPerEm,
                                                       harmonizerParameters* params, int verbose)
{
    if (glyphs == NULL)
        return HARMONIZER_INVALID_PARAM;

    bool bverbose = (verbose) ? true : false;

    Harmonizer_Error herr = HARMONIZER_INVALID_PARAM;

    Glyph_Type inputType = glyphs[0].glyphType;
    Glyph_Type outputType = params->outputType;

    if (inputType == eGlyph_TTF)
    {
        if (outputType == eGlyph_TTF)
        {
            herr = harmonizeQuadsToQuads(glyphs, numGlyphs, unitsPerEm, params, bverbose);
        }
        else if (outputType == eGlyph_CFF)
        {
            herr = harmonizeQuadsToCubics(glyphs, numGlyphs, unitsPerEm, params, bverbose);
        }
    }
    else if (inputType == eGlyph_CFF)
    {
        if (outputType == eGlyph_TTF)
        {
            herr = harmonizeCubicsToQuads(glyphs, numGlyphs, unitsPerEm, params, bverbose);
        }
        else if (outputType == eGlyph_CFF)
        {
            herr = harmonizeCubicsToCubics(glyphs, numGlyphs, unitsPerEm, params, bverbose);
        }
    }

    H_LinkedList<H_ContourSection>::ClearHeap();
    H_LinkedList<H_OutlineSection>::ClearHeap();

    return herr;
}
