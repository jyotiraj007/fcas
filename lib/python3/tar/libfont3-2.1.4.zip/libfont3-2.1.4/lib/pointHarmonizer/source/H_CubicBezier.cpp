// Copyright (C) 2014 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// CubicBezier.cpp

#include "H_CubicBezier.h"
#include "H_Line2D.h"
#include "H_MathUtilities.h"
#include "H_Stack.h"


H_CubicBezier::H_CubicBezier()
:   m_NumSegments(0)
{
}

H_CubicBezier::H_CubicBezier(const H_Vector2f& startPoint, const H_Vector2f& endPoint, const H_Vector2f& controlPoint1, const H_Vector2f& controlPoint2, int numSegments /* = 10 */)
{
    Init(startPoint, endPoint, controlPoint1, controlPoint2, numSegments);
}

H_CubicBezier::H_CubicBezier(const H_CubicPoints& cubicPoints)
{
    Init(cubicPoints.m_Start, cubicPoints.m_End, cubicPoints.m_Control1, cubicPoints.m_Control2);
}

void H_CubicBezier::GetPoints(H_CubicPoints& points)
{
    points.m_Start    = m_Control[eSTART];
    points.m_End      = m_Control[eEND];
    points.m_Control1 = m_Control[eCONTROL1];
    points.m_Control2 = m_Control[eCONTROL2];
}

void H_CubicBezier::SetPoints(const H_CubicPoints& points)
{
    Init(points.m_Start, points.m_End, points.m_Control1, points.m_Control2);
}

void H_CubicBezier::Init(const H_Vector2f& startPoint, const H_Vector2f& endPoint, const H_Vector2f& controlPoint1, const H_Vector2f& controlPoint2, int numSegments /* = 10 */)
{
    m_Control[eSTART]    = startPoint;
    m_Control[eEND]      = endPoint;
    m_Control[eCONTROL1] = controlPoint1;
    m_Control[eCONTROL2] = controlPoint2;

    m_NumSegments = numSegments;

    if (ManhattenDistance(m_Control[eCONTROL1], m_Control[eSTART]) <= 1.0f)
    {
        m_Control[eCONTROL1] =  m_Control[eSTART];
    }

    if (ManhattenDistance(m_Control[eCONTROL2], m_Control[eEND]) <= 1.0f)
    {
        m_Control[eCONTROL2] =  m_Control[eEND];
    }
}


void H_CubicBezier::CreateSegments(float flatness)
{
    m_CurrentFlatness = flatness;
    H_Vector2f left;
    H_Vector2f right;
    H_Vector2f middle;

    H_Vector2f middleLeft;
    H_Vector2f middleRight;
    H_Vector2f middleMiddle;

    float len1;
    float len2;
    H_Vector2f distance1;
    H_Vector2f distance2;

    H_Stack<H_CubicPoints> stack;

    m_Points.ResetIndex();

    m_Points.Add(m_Control[eSTART]);
    m_NumSegments = 0;

    H_CubicPoints points;

    points.Set(m_Control[eSTART], m_Control[eEND], m_Control[eCONTROL1], m_Control[eCONTROL2]);

    stack.Push(points);

    while (false == stack.IsEmpty())
    {
        points = stack.Pop();

        // Find the mid curve point of these controls:
        left   = 0.5f * (points.m_Start    + points.m_Control1);
        right  = 0.5f * (points.m_End      + points.m_Control2);
        middle = 0.5f * (points.m_Control1 + points.m_Control2);

        middleLeft   = 0.5f * (left + middle);
        middleRight  = 0.5f * (right + middle);
        middleMiddle = 0.5f * (middleLeft + middleRight);

        // Evaluate their flatness:
        distance1 = middleLeft  - points.m_Control1;
        distance2 = middleRight - points.m_Control2;

        len1 = distance1.LengthSquared();
        len2 = distance2.LengthSquared();

        if (len1 < flatness && len2 < flatness)
        {
            m_Points.Add(middleMiddle);
        }
        else
        {
            H_CubicPoints cubicLeft(middleMiddle, points.m_End, middleRight, right);
            H_CubicPoints cubicRight(points.m_Start, middleMiddle, left, middleLeft);

            // Split in two and keep going:
            stack.Push(cubicLeft);
            stack.Push(cubicRight);
        }
    }
    m_Points.Add(m_Control[eEND]);
    m_NumSegments = m_Points.NumElements() - 1;
}

void H_CubicBezier::Evaluate(float flatness)
{
    CreateSegments(flatness);
    CreateNormals();
}


H_Vector2f H_CubicBezier::CalculatePoint(float t)
{
    H_Vector2f a = H_Interpolate(m_Control[eSTART],    m_Control[eCONTROL1], t);
    H_Vector2f b = H_Interpolate(m_Control[eCONTROL1], m_Control[eCONTROL2], t);
    H_Vector2f c = H_Interpolate(m_Control[eCONTROL2], m_Control[eEND],      t);

    H_Vector2f d = H_Interpolate(a, b, t);
    H_Vector2f e = H_Interpolate(b, c, t);

    H_Vector2f f = H_Interpolate(d, e, t);

    return f;
}


bool H_CubicBezier::FlatStart()
{
	bool flatStart = false;

	H_Line2D start(m_Control[eCONTROL1], m_Control[eSTART]);
    H_Line2D end  (m_Control[eCONTROL2], m_Control[eEND]);

    start.ExtendStart(10000.0f);

	if (end.Intersects(start))
	{
		flatStart = true;
	}
	return flatStart;
}


bool H_CubicBezier::Search(H_QuadContour& quadContour)
{
    m_Depth++;
    bool success = true;

    m_BestBeziers.Clear();
    m_BestAverage = H_FLOAT_MAX;

    m_EvalStack.Reset();
    H_Line2D startTangent = m_StartTangent;
    H_Line2D startTarget = startTangent;

    m_CheckDepth = 0;

    CheckRight(startTangent, startTarget, 0, m_Points.NumElements() - 1);

    int numBeziers = m_BestBeziers.NumElements();

    if (numBeziers > 0)
    {
        H_ContourPoint firstPoint(H_ContourPoint::ON_CURVE, m_BestBeziers[0].GetPoint(H_QuadBezier::eSTART));
        m_Results.Add(firstPoint);

        int i;
        // Emit the beziers to our contour.
        // All beziers have implicit on curve points, so just add controls.
        for (i = 0; i < numBeziers; i++)
        {
            H_QuadBezier& bezier = m_BestBeziers[i];
            H_ContourPoint point(H_ContourPoint::OFF_CURVE, bezier.GetPoint(H_QuadBezier::eCONTROL));
            m_Results.Add(point);
        }

        // Add last on curve point of beziers.
        H_ContourPoint lastPoint(H_ContourPoint::ON_CURVE, m_BestBeziers[i-1].GetPoint(H_QuadBezier::eEND));
        m_Results.Add(lastPoint);

		EmitResults(quadContour);
    }

    if (numBeziers == 0)
    {
		static int NUM_TRIES = 5;
		static float flatness[] = {0.005f, 0.0005f, 0.00005f, 0.000005f, 0.0000005f};

        // If we didn't find a solution, recurse after a different evaluation of this cubic.

		if (m_Depth < NUM_TRIES)
		{
			Evaluate(flatness[m_Depth]);

			// Limit by both recursion depth and number of elements so we don't take too long.
			if (m_Points.NumElements() < 60) 
			{
				success = Search(quadContour);
			}
			else
			{
				success = false;
			}
		}
		else
		{
			success = false;
		}
    }

    return success;
}

bool H_CubicBezier::CheckRight(H_Line2D& startTangent, H_Line2D& startTarget, int startIndex, int endIndex)
{
    m_CheckDepth++;

    bool foundSolution = false;

    int currentIndex = FindFirst(startTangent, startIndex, endIndex);

   // bool intersectsStartTarget  = true;

    while ((false == foundSolution) && (currentIndex > startIndex) && (currentIndex < endIndex))
    {
        H_Line2D currentTangent(m_AllTangents[currentIndex]);

        //bool intersectsStartTarget = currentTangent.Intersects(startTarget);

		// Find intersection with current startTarget:
		H_Vector2f startIntersection(currentTangent.Intersection(startTarget));

		currentTangent.Set(startIntersection, m_Points[currentIndex + 1]);
		currentTangent.ExtendEnd(currentTangent.Length()); // Double in length.

		H_Line2D currentTarget(startIntersection, m_Points[currentIndex]);
		currentTarget.ExtendEnd(currentTarget.Length());   // Double the length.
		// CurrentTarget is the overlap 
		currentTarget.Set(currentTarget.End(), currentTangent.End());

		m_EvalStack.Push(currentTangent);

		foundSolution = Score();

		if (false == foundSolution)
		{
			foundSolution = CheckRight(currentTangent, currentTarget, currentIndex + 1, endIndex);
		}

		m_EvalStack.Pop();

        --currentIndex;
    }

    return foundSolution;
}

bool H_CubicBezier::Score()
{
    int numTangents = m_EvalStack.NumElements();

	int numPoints = numTangents + 1;

	switch (m_Comparision)
	{
		case H_EQUALS:
			if (numPoints != m_NumPoints)
			{
				return false; 
			}
		break;

		case H_LESS_THAN:
			if (numPoints >= m_NumPoints)
			{
				return false; 
			}
		break;

		case H_ANY:
		break;
	}

    m_Tangents.ResetIndex();

    m_Tangents.Add(m_StartTangent);

    for (int i = 0; i < numTangents; i++)
    {
        H_Line2D currentTangent = m_EvalStack.ElementAt(i);
        currentTangent.Extend(10000.0f);
        m_Tangents.Add(currentTangent);
    }

    m_Tangents.Add(m_EndTangent);

    m_Intersections.ResetIndex();

    for (int i = 0; i < m_Tangents.NumElements()-1; i++)
    {
        H_Line2D& one = m_Tangents[i];
        H_Line2D& two = m_Tangents[i+1];

        if (false == one.Intersects(two))
        {
            return false;
        }

        H_Vector2f intersection = one.Intersection(two);
        m_Intersections.Add(intersection);
    }

    m_ControlPoints.ResetIndex();

    m_ControlPoints.Add(m_Control[eSTART]);

    for (int i = 0; i < m_Intersections.NumElements()-1; i++)
    {
        H_Vector2f rounded1 = m_Intersections[i].Rounded();
        H_Vector2f rounded2 = m_Intersections[i+1].Rounded();

        H_Vector2f midPoint = H_Interpolate(rounded1, rounded2, 0.5f);
        m_ControlPoints.Add(rounded1);
        m_ControlPoints.Add(midPoint);
    }

    m_ControlPoints.Add(m_Intersections[m_Intersections.NumElements()-1].Rounded());
    m_ControlPoints.Add(m_Control[eEND]);

    float averageDistance = 0.0f;
    m_Beziers.ResetIndex();

    for (int i = 0; i < m_ControlPoints.NumElements()-2; i+=2)
    {
        H_QuadBezier bezier;

        bezier.Init(m_ControlPoints[i], m_ControlPoints[i+2], m_ControlPoints[i+1]);

        m_Beziers.Add(bezier);
    }

    for (int i = 0; i < m_Beziers.NumElements(); i++)
    {
        H_QuadBezier& bezier = m_Beziers[i];
        bezier.Evaluate();

        float distance;

        if (WithinTolerance(bezier, distance))
        {
            averageDistance += distance;
        }
        else
        {
            return false;
        }
    }

    averageDistance /= (numTangents + 1);

    if (averageDistance < m_BestAverage)
    {
        m_BestAverage = averageDistance;

        m_BestBeziers = m_Beziers;

        m_FoundMatch = true;
    }

    return true;
}

// returns index of allTangent.
int H_CubicBezier::FindFirst(H_Line2D& startTangent, int startIndex, int endIndex)
{
    int currentIndex = startIndex;
    bool intersects = false;

    // First remove any non intersecting segs, usually parallel with tangent.
    while (intersects == false && currentIndex < endIndex)
    {
        H_Line2D currentLine = m_AllTangents[currentIndex];
        intersects = currentLine.Intersects(startTangent);
        currentIndex++;
    }

    // Now find furthest intersecting tangent.
    while (intersects && currentIndex < endIndex)
    {
        H_Line2D currentLine = m_AllTangents[currentIndex];
        intersects = currentLine.Intersects(startTangent);
        currentIndex++;
    }

    currentIndex -= 2;

    if (currentIndex < startIndex)
    {
        currentIndex = startIndex + 1;
    }

    return currentIndex;
}

void H_CubicBezier::EmitResults(H_QuadContour& quadContour)
{
	if (m_Backwards)
	{
		m_Results.Reverse();
		ReverseControlPoints(); // Reverse them back.
	}

	for (int i = 1; i < m_Results.NumElements(); i++)
	{
		quadContour.AddPoint(m_Results[i]);
	}
}

bool H_CubicBezier::Match(H_QuadContour& quadContour,  int numPoints,  float tolerance, H_Comparision comparision)
{
	m_Results.Clear();

	if (FlatStart())
	{
		m_Backwards = true;
		ReverseControlPoints();
	}
	else
	{
		m_Backwards = false;
	}

	Evaluate();
    m_Depth = -1;
    m_Tolerance = tolerance;
	m_Comparision = comparision;
	m_NumPoints = numPoints;

    m_StartTangent = H_Line2D(m_Control[eCONTROL1], m_Control[eSTART]);
    m_EndTangent   = H_Line2D(m_Control[eCONTROL2], m_Control[eEND]);

    // Check if start tangent has zero length.
    if (m_Control[eCONTROL1] == m_Control[eSTART])
    {
        m_StartTangent = H_Line2D(m_Points[1], m_Control[eSTART]);
    }
    // Check if end tangent has zero length.
    if (m_Control[eCONTROL2] ==  m_Control[eEND])
    {
        m_EndTangent = H_Line2D(m_Points[m_Points.NumElements() - 2], m_Control[eEND]);
    }

    m_StartTangent.ExtendStart(10000.0f);
    m_EndTangent.ExtendStart(10000.0f);


	if ((m_NumPoints == 1) || (m_Comparision == H_LESS_THAN) || m_Comparision == H_ANY)
    {
        // Try for single quad: got lucky or very small.
        if (m_StartTangent.Intersects(m_EndTangent))
        {
            float distance;
            H_QuadBezier startBezier;
            H_Vector2f midPoint = m_StartTangent.Intersection(m_EndTangent);
            midPoint = midPoint.Rounded();

            startBezier.Init(m_Control[eSTART], m_Control[eEND], midPoint);

            startBezier.Evaluate();

            if (WithinTolerance(startBezier, distance))
            {
                H_ContourPoint startPoint	(H_ContourPoint::ON_CURVE, m_Control[eSTART]);
                H_ContourPoint controlPoint	(H_ContourPoint::OFF_CURVE, midPoint);
                H_ContourPoint endPoint		(H_ContourPoint::ON_CURVE, m_Control[eEND]);

				m_Results.Add(startPoint);
                m_Results.Add(controlPoint);
                m_Results.Add(endPoint);

				EmitResults(quadContour);
                return true;
            }
        }
    }

	if (IsLinear())
	{
		int addPoints = 1;

		if (m_Comparision == H_EQUALS)
		{
			addPoints = numPoints;
		}

		H_Vector2f start = m_Control[eSTART];
		H_Vector2f end = m_Control[eEND];

		float step = 1.0f / ((float)addPoints + 1.0f);
		float t = step;

		H_ContourPoint startPoint(H_ContourPoint::ON_CURVE, m_Control[eSTART]);
		m_Results.Add(startPoint);

		for (int i = 0; i < addPoints; i++)
		{
			H_Vector2f position = H_Interpolate(start, end, t);

			H_ContourPoint newPoint(H_ContourPoint::OFF_CURVE, position);
			m_Results.Add(newPoint);

			t += step;
		}
		H_ContourPoint endPoint(H_ContourPoint::ON_CURVE, m_Control[eEND]);
		m_Results.Add(endPoint);

		EmitResults(quadContour);

		return true;
	}

    bool success = Search(quadContour);

    return success;
}

void H_CubicBezier::CreateNormals()
{
    m_NormalLines.Clear();
    m_MidPoints.Clear();

    int numSegments = m_Points.NumElements() - 1;

    for (int i = 0; i < numSegments; i++)
    {
        H_Line2D currentSegment(m_Points[i], m_Points[i+1]);
        // Create the normal to the segment:

        float xDelta = m_Points[i+1][0] - m_Points[i][0];
        float yDelta = m_Points[i+1][1] - m_Points[i][1];

        // Calc the unit normal vector.
        H_Vector2f normal(-yDelta, xDelta);
        normal.Normalize();
        normal = 4096.0f * normal;

        // Extend normal both ways.
        H_Vector2f midPoint = currentSegment.Interpolate(0.5f);
        H_Line2D normalLine(midPoint + normal, midPoint - normal);
        
        m_NormalLines.Add(normalLine);
        m_MidPoints.Add(midPoint);
    }

    m_AllTangents.Clear();

    for (int i = 0; i < m_Points.NumElements()-1; i++)
    {
        H_Line2D line(m_Points[i], m_Points[i+1]);
        line.Extend(10000.0f);
        m_AllTangents.Add(line);
    }
}


bool H_CubicBezier::WithinTolerance(H_QuadBezier& quad, float& distance)
{
    bool intersection;

    distance = (float)SplineDistance(quad, intersection, 0, m_Points.NumElements() - 1);

    if (distance < m_Tolerance)
    {
        return true;
    }
    else
    {
        return false;
    }
}

double H_CubicBezier::SplineDistance(H_QuadBezier& quad, bool& anyIntersections, int startIndex, int stopIndex)
{
    int numSegments = quad.NumCurvePoints() - 1;

    double largestDistance = 0.0f;
    anyIntersections = false; 

    int numIntersections = 0;
    int largestIntesected = startIndex;


    for (int i = 0; i < numSegments; i++)
    {
        double distance = H_FLOAT_MAX;
        bool   foundIntersection = false;

        H_Line2D segment(quad.GetCurvePoint(i), quad.GetCurvePoint(i+1));

        // Look for intersection with segment.
        for (int j = largestIntesected; j < stopIndex; j++)
        {
            if (m_NormalLines[j].Intersects(segment))
            {
                numIntersections++;
                anyIntersections = true;
                foundIntersection = true;

                largestIntesected = j;

                double currentDistance = segment.PointDistance(m_MidPoints[j]);

                // Get the smallest intersection.
                if (currentDistance < distance)
                {
                    distance = currentDistance;
                    if (distance < m_Tolerance)
                    {
                        break;
                    }
                }
            }
        }

        if (foundIntersection) // Avoid adding FLOAT_MAX if no intersection.
        {
            if (distance > largestDistance)
            {
                largestDistance = distance;

                if (largestDistance > m_Tolerance)
                {
                    return largestDistance;
                }
            }
        }
    }

    // Reject degenerate quads with low hit rate.
    float percentMatch = (float)numIntersections / (float)numSegments;

    if (percentMatch < 0.02f)
    {
        largestDistance = H_FLOAT_MAX;
    }

    return largestDistance;
}

bool H_CubicBezier::IsLinear(float tolerance)
{
	bool linearBezier = true;

	H_Vector2f firstPoint = m_Control[eSTART];
	H_Vector2f lastPoint = m_Control[eEND];

	H_Vector2f current = m_Control[eCONTROL1];

	H_Vector2f inVector(current - firstPoint);
	H_Vector2f outVector(current - lastPoint);

	bool areLinear;

	if (inVector.LengthSquared() != 0.0f && outVector.LengthSquared() != 0.0f)
	{
		areLinear = AreLinear(inVector, outVector, tolerance);

		if (false == areLinear)
		{
			linearBezier = false;
		}
	}

	current = m_Control[eCONTROL2];

	inVector  = H_Vector2f(current - firstPoint);
	outVector = H_Vector2f(current - lastPoint);

	if (inVector.LengthSquared() != 0.0f && outVector.LengthSquared() != 0.0f)
	{
		areLinear = AreLinear(inVector, outVector, tolerance);

		if (false == areLinear)
		{
			linearBezier = false;
		}
	}

	return linearBezier;
}

 
int H_CubicBezier::NumSegments()
{
    return m_NumSegments;
}

void H_CubicBezier::SetPoint(Control control, const H_Vector2f& point)
{
    m_Control[control] = point;
}

H_Vector2f H_CubicBezier::GetPoint(Control control)
{
    return m_Control[control];
}

void H_CubicBezier::ReverseControlPoints()
{
	H_Vector2f start		= m_Control[eSTART];
	H_Vector2f end			= m_Control[eEND];
	H_Vector2f control1		= m_Control[eCONTROL1];
	H_Vector2f control2		= m_Control[eCONTROL2];

	m_Control[eSTART]		= end;
	m_Control[eEND]			= start;
	m_Control[eCONTROL1]	= control2;
	m_Control[eCONTROL2]	= control1;
}
