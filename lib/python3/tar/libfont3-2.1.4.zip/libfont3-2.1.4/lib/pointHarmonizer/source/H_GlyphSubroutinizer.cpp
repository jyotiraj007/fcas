// Copyright (C) 2016 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// H_GlyphSubroutinizer.cpp

#include "H_GlyphSubroutinizer.h"
#include "H_NormalizedContour.h"

H_GlyphSubroutinizer::H_GlyphSubroutinizer() 
{
}

void H_GlyphSubroutinizer::Clear()
{
	m_Trie.Clear();
}

void H_GlyphSubroutinizer::AddGlyph(H_CubicGlyph& cubicGlyph)
{
	H_Contour* pContour = cubicGlyph.FirstContour();

    while (pContour)
    {
		H_OffsetContour offsetContour(*pContour);
		
		AddContour(offsetContour);

		// Do stuff!
		pContour = cubicGlyph.NextContour();
    }
}

// Add all suffixes of the contour to a trie.
void H_GlyphSubroutinizer::AddContour(H_OffsetContour& contour)
{
	m_Trie.Clear();

	int sequenceLength = contour.GetOffsets().NumElements();

	for (int firstIndex = 0; firstIndex < sequenceLength; firstIndex++)
	{
		m_Trie.AddSequence(contour.GetOffsets(), firstIndex);
	}
}


int H_GlyphSubroutinizer::Find(H_Offset offset)
{
	int index = 0;

	for (int i = 0; i < m_UniqueOffsets.NumElements(); i++)
	{
		if (offset.m_Data == m_UniqueOffsets[i])
		{
			return i;
		}
	}

	index = m_UniqueOffsets.Add(offset);

	return index;
}


void H_GlyphSubroutinizer::FindSubroutines(H_CubicTable& glyphTable, float tolerance /* = 0.05f */)
{
    H_NormalizedPoint::SetTolerance(tolerance);
    Clear();

	int maxOffset = 0;
	int numOffsets = 0;
	m_UniqueOffsets.Clear();

	for (int i = glyphTable.FirstIndex(); i <= glyphTable.LastIndex(); i++)
	{
		//printf("Processing Glyph: %d \r", i);


		H_CubicGlyph& cubicGlyph = glyphTable[i];

		H_Contour* pContour = cubicGlyph.FirstContour();

		while (pContour)
		{
			H_OffsetContour offsetContour(*pContour);

			H_ArrayList<H_Offset>& offsets = offsetContour.GetOffsets();

			for (int j = 0; j < offsets.NumElements(); j++)
			{
				H_Offset& offset = offsets[j];

				if (abs(offset.m_Shorts.m_X) > maxOffset)
				{
					maxOffset = abs(offset.m_Shorts.m_X);
				}

				if (abs(offset.m_Shorts.m_Y) > maxOffset)
				{
					maxOffset = abs(offset.m_Shorts.m_Y);
				}

				//Find(offset);
				numOffsets++;
			}

			pContour = cubicGlyph.NextContour();
		}
	}
	
	printf("Unique Offsets: %d\n", m_UniqueOffsets.NumElements());
	printf("NumOffsets:%d\n", numOffsets);
	printf("MaxOffset: %d\n", maxOffset);
}

int H_GlyphSubroutinizer::CalcSize(H_CubicTable& glyphTable)
{
	(void) glyphTable;
	return 10; // TODO: !
}