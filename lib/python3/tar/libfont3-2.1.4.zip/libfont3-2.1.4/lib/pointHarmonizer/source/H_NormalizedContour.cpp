// Copyright (C) 2016 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// H_NormalizedContour.cpp

#include "H_NormalizedContour.h"
#include "H_BoundingBox.h"


float H_NormalizedPoint::EPSILON = 0.10f;


H_NormalizedContour::H_NormalizedContour()
{
    m_Points.Clear();
}

H_ArrayList<H_NormalizedPoint>& H_NormalizedContour::GetOffsets()
{
    return m_Points;
}

H_NormalizedContour::H_NormalizedContour(H_Contour& contour)
{
    H_BoundingBox bounds;

    contour.GetPointBounds(bounds);

    // Normalize.
    float   dataWidth = (float) 0x00007fff;

    // Normalize in x.
    float   xScale = dataWidth / bounds.Width();

    // Normalize in y.
    float   yScale = dataWidth / bounds.Height();

    for (int i = 0; i < contour.NumPoints(); i++)
    {
        H_ContourPoint& currPoint = contour.GetPoint(i);

        float x = currPoint.m_Point.X();
        float y = currPoint.m_Point.Y();

        x -= bounds.Left();
        y -= bounds.Bottom();

        x *= xScale;
        y *= yScale;

        m_Points.Add(H_NormalizedPoint(x, y));
    }
}

