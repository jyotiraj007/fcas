// Copyright (C) 2015 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
/// \file H_QuadGlyph.h

#ifndef H_QUAD_GLYPH_H
#define H_QUAD_GLYPH_H

#include "H_QuadContour.h"
#include "H_Component.h"
#include "H_LinkedList.h"

class H_QuadGlyph
{
    public:

        /* CTOR */      H_QuadGlyph	();
        /* CTOR */      H_QuadGlyph (unsigned int glyphId);
        /* CTOR */      H_QuadGlyph	(H_LinkedList<H_QuadContour>& contours);
        /* CTOR */      //H_QuadGlyph	(H_QuadGlyph& other);

        void            Clear               ();

		void            Interpolate(H_QuadGlyph& A, H_QuadGlyph& B, float t);

        void            SetGlyphId          (unsigned int glyphId);
        unsigned int    GetGlyphId          () const;

        bool            HasContours         ();

        int             NumContours         ();
        void            AddContour          (H_QuadContour& contour);

        H_QuadContour*	FirstContour     ();
        H_QuadContour*	NextContour      ();

		H_QuadContour*	GetContour		(int index);

        bool            operator==       (H_QuadGlyph& other);

        void            CalcNesting();

        bool            GetBounds           (H_BoundingBox& bounds);
		H_Vector2f      GetBoundsOffset();

		void            SetBoundsOnContours();

		H_ScaleOffset   GetScaleOffset(H_QuadGlyph& other);

        bool            Contains            (H_QuadGlyph& other);
        void            ClearTags           ();

        int             SizeBytes           ();

        void            Scale               (float xScale, float yScale);

        static void     ClearHeap           ();

        int             NumPoints(int sequenceId);

		H_LinkedList<H_QuadContour>& Contours();

		void           FindExtrema();
		void		   FindAngles();
		void           FindPositions();
		void           FindDirections();

		void           CheckWinding();
		void		   CreateUnMatchedSections();
		void           AddMissingExtrema();
		void           RemoveRedundantPoints();
		void           RemoveLinearBeziers();

		void           MakePoints();
		void           FindFirstPoints();
		void           ReOrderPoints();

		void           FindScaledBounds(H_ScaleOffset& scaleOffset);

		bool           IsValid();

		void           NumberContours();
		void           LabelIndices();

    protected:

        H_QuadContour* GetSequence         (int sequenceId);
        H_QuadContour* RemoveContour       (int sequenceId);

        unsigned int             m_GlyphId;

        H_LinkedList<H_QuadContour>   m_Contours;

        friend class H_GlyphCompositor;
        friend class H_BezierView;
};

#endif
