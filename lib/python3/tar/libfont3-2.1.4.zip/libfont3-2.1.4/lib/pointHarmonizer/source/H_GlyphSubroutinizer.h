// Copyright (C) 2016 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// H_GlyphSubroutinizer.h

#ifndef H_GLYPH_SUBROUTINIZER
#define H_GLYPH_SUBROUTINIZER

#include "H_Trie.h"
#include "H_QuadGlyph.h"
#include "H_CubicGlyph.h"
#include "H_OffsetContour.h"
#include "H_IndexTable.h"
#include "H_Array.h"


typedef H_IndexTable<H_CubicGlyph>    H_CubicTable;


class H_GlyphSubroutinizer
{
    public:

		/* CTOR */  H_GlyphSubroutinizer();
        void        Clear				();


        void        FindSubroutines(H_CubicTable& glyphTable, float tolerance = 0.05f);


        int         CalcSize(H_CubicTable& glyphTable);

    protected:

        void        AddGlyph        (H_CubicGlyph&		cubicGlyph);
		void		AddContour		(H_OffsetContour&	contour);

		H_Trie<H_Offset>        m_Trie;


		int                      Find(H_Offset offset);

		H_ArrayList<H_Offset>  m_UniqueOffsets;
		
};

#endif
