// Copyright (C) 2016 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
/// \file Harmonizer.h

#ifndef __HARMONIZER_H__
#define __HARMONIZER_H__

#ifdef __cplusplus
extern "C" {
#endif

#include "../../conversion/source/Conversion.h"

typedef enum
{
    HARMONIZER_SUCCESS = 0,
    HARMONIZER_FAILED_MATCH,
    HARMONIZER_INVALID_INPUT,
    HARMONIZER_INVALID_PARAM,
    HARMONIZER_MEMORY,
    HARMONIZER_UNIMPLEMENTED
} Harmonizer_Error;


typedef struct
{
    int noContorCheck;      // skip check of the order of the contours (i.e. you know that they are in the right order)
    int noExtremaAdding;    // do not add missing extrema points to contours
    int noStartPointCheck;  // do not adjust starting points of contours
    Glyph_Type outputType;  // type of output glyphs
} harmonizerParameters;


//
// Harmonizes a set of (quad) glyphs.
//
// @param[inout]    glyphs                  pointer to array of Glyph objects (updated in place)
// @param[in]       numGlyphs               number of glyphs in the array
// @param[in]       unitsPerEm              units per em of fonts
// @param[in]       params                  parameters controlling the algoritm
// @param[in]       verbose                 1 (true) to have algorithm print transcript to console
//
//  The glyphs are modified in place.
//
Harmonizer_Error harmonizer_harmonizeGlyphs(Glyph* glyphs, int numGlyphs, int unitsPerEm,
                                            harmonizerParameters* params, int verbose);

#ifdef __cplusplus
}
#endif


#endif // __HARMONIZER_H__
