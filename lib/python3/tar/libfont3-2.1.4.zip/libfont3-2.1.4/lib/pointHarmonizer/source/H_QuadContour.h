// Copyright (C) 2015 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// H_QuadContour.h

#ifndef H_QUAD_CONTOUR_H
#define H_QUAD_CONTOUR_H

#include "H_Contour.h"
#include "H_BoundingBox.h"
#include "H_ContourSection.h"
#include "H_LinkedList.h"
#include "H_OutlineSection.h"
#include "H_OrientedMinimumBoundingBox.h"



class  H_Line2D;
class  H_QuadBezier;
struct H_QuadPoints;
class  H_ScaleOffset;
class H_OrientedMinimumBoundingBox;


class H_QuadContour : public H_Contour
{
    public:
        /* CTOR */      H_QuadContour();
		/* CTOR */		H_QuadContour(const H_QuadContour& other);

		H_QuadContour&  operator =  (const H_QuadContour& other);

        bool            GetFirstQuad(H_QuadPoints& points, int fromIdx, int toIdx);
		bool            GetNextQuad	(H_QuadPoints& points);

        bool            GetFirstLine(H_Line2D& line, int fromIdx, int toIdx);
        bool            GetNextLine (H_Line2D& line);

        bool            Intersects  (H_QuadContour& otherContour);

        bool            Intersects  (H_Line2D& line);
        bool            Intersects  (H_QuadBezier& quad);

        void            GetIntersections(H_Line2D& line,      H_ArrayList<H_Vector2f>& intersections);
        void            GetIntersections(H_QuadBezier& cubic, H_ArrayList<H_Vector2f>& intersections);

        bool            Contains(H_Vector2f& point);
        bool            Contains(H_QuadContour& other);

        bool            GetBounds       (H_BoundingBox& boundsBox); // Bounds of the actual outline.

		void 			CheckWinding	();

		H_BoundingBox&  GetScaledBounds(); 

		void            SetScaledBounds(H_ScaleOffset& scaleOffset);

        void            SetTag  (bool value) { m_Tag = value; };
        bool            Tag     ()           { return m_Tag;  }

		int             FindBestMatch	(H_ContourPoint* pPoint, bool useIndex = true);
		int             LastIndex();

		int             FirstExtremaIdx();
		int             NextExtremaIdx();

		int             FirstOnCurveIdx();
		int             NextOnCurveIdx();

		H_ContourPoint*	GetFirstExtrema();
		H_ContourPoint* GetNextExtrema(H_ContourPoint* pCurrent);

		H_OutlineSection* FirstOutlineSection();
		H_OutlineSection* NextOutlineSection();

		H_ListElem<H_OutlineSection>*	SplitAt				(H_OutlineSection& section, int index); 
		H_ListElem<H_OutlineSection>*	AddStartLine		(H_OutlineSection& section);
		H_ListElem<H_OutlineSection>*	AddEndLine			(H_OutlineSection& section);
		H_ListElem<H_OutlineSection>*	SplitSingleBezier	(H_OutlineSection& section, float distance);
		H_ListElem<H_OutlineSection>*	SplitLineSegment	(H_OutlineSection& section, float distance);
		H_ListElem<H_OutlineSection>*	SplitBezierSection	(H_OutlineSection& section, float distance);

		H_ListElem<H_OutlineSection>*	CreateExtrema       (H_OutlineSection& section);
		H_ListElem<H_OutlineSection>*	SplitAtInflection   (H_OutlineSection& section);

		int             NumOnCurve();
		void			FindPositions();
		void            AddMissingExtrema   (); // Detect sections with no on curve point at curve extrema, and add them.
		void            RemoveLinearBezier();
		void            RemoveRedundantPoints();
		void            ReNumberPoints();

		void       ClearMatchedExtrema();
		void       AddMatchedExtrema(int index);

		void       CreateSections		();
		void       MakePoints			();

		H_LinkedList<H_OutlineSection>*  GetOutlineSections();

		bool             Matches(H_QuadContour* pOther);

		float           Distance(H_QuadContour* pOther);
		float           ShortestDistance(H_Vector2f& point);

		bool            IsValid();

		void            SetNumber(int number);
		int				GetNumber();

		H_Vector2f      GetAveragePoint();

        static bool     m_Verbose;

		void            CreateHarmoneousSections(); // Split into sections just using on curve points.

		void			SetGlyphBounds(H_BoundingBox& bounds);
		H_BoundingBox&	GetGlyphBounds();

		void			CreateUnMatchedSections();

    protected:

		int             FirstOnCurve();
		int             NextOnCurve();


		void            MatchSameAngle      (H_QuadContour* pOther); // Match smooth points with same bearing angle.
        bool            IsSinglePoint(H_BoundingBox& boundsBox);

		H_BoundingBox   m_ScaledBounds;      // Bounds normalized to glyph bounding box.

		H_BoundingBox   m_GlyphBounds;

        // Book keeping for iterators.
        H_Vector2f		m_Point[3];
        int             m_Index;
        int             m_CurrentPoint;
		int             m_LastPoint;
        bool            m_Tag;

		//bb temp.
		public: 
		H_LinkedList<H_ContourSection> m_Sections;
		H_LinkedList<H_OutlineSection> m_OutlineSections;

		H_ArrayList<Pair>	m_MatchingIndecesA;
		H_ArrayList<Pair>	m_MatchingIndecesB;

		H_ArrayList<int>  m_MatchedExtrema;
		H_BoundingBox     m_Bounds;

		int m_CurrentIndex;

		bool m_Matches;
		int		m_Number;
};

#endif

