// Copyright (C) 2014 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
/// \file H_Line2D.h

#ifndef H_LINE_2D_H
#define H_LINE_2D_H

#include "H_Vector2f.h"
#include "H_Vector2i.h"
#include "H_ArrayList.h"

class H_Line2D
{
    public:
                    H_Line2D		();
                    H_Line2D		(const H_Vector2f& start, const H_Vector2f& end);

		void		Set				(const H_Vector2f& start, const H_Vector2f& end);

        bool        Intersects      (const H_Line2D& other) const;
        H_Vector2f	Intersection	(H_Line2D& other);

		H_Vector2f	Interpolate		(float t);

        H_Line2D	NormalAt		(H_Vector2f point);

		bool		IsLeft			(H_Vector2f& point);

        void        GetIntersections(H_Line2D& other, H_ArrayList<H_Vector2f>& intersections);

		float		PointDistance	(const H_Vector2f& point);

		void		Extend			(float length);
		void        ExtendEnd		();
		void		ExtendEnd		(float length);
		void        ExtendStart		();
		void		ExtendStart		(float length);

		void        SetLength		(float length);

		float       Length			() const;
        H_Vector2f    Start         () const;
        H_Vector2f    End           () const;

		H_Vector2i    NearestPoint();

    protected:

        H_Vector2f    m_Start;
        H_Vector2f    m_End;
};


#endif
