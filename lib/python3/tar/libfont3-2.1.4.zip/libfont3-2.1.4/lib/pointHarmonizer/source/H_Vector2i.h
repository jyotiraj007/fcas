// Copyright (C) 2015 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
/// \file Vector2i.h

#ifndef VECTOR2_I_H
#define VECTOR2_I_H

#include "H_Vector2f.h"

class H_Vector2i
{
    public:
        /* CTOR */  H_Vector2i	(int x = 0, int y = 0);
        /* CTOR */  H_Vector2i	(H_Vector2f& other);

        const int&  operator[]  (int i) const;
        int&        operator[]  (int i);

        H_Vector2i    operator-   (const H_Vector2i& other) const;

        float       Length      () const;

    protected:

        int         m_Vector[2];
};


/**
    Access to coordinates.
    @param[in] i Coordinate index
    @return Coordinate value.
*/
inline const int& H_Vector2i::operator[](int i) const
{
    return m_Vector[i];
}

/**
    Access to coordinates.
    @param[in] i Coordinate index
    @return Coordinate value.
*/
inline int& H_Vector2i::operator[](int i)
{
    return m_Vector[i]; 
}

#endif 
