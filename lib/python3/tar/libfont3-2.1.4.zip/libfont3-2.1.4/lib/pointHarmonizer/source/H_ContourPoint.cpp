// Copyright (C) 2015 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// H_ContourPoint.cpp

#include "H_ContourPoint.h"
#include "H_MathUtilities.h"

#include <math.h>

/* CTOR */ H_ContourPoint::H_ContourPoint()
	:	m_Type		(),
		m_Point		(),
		m_IsExtremum(false),
		m_Smooth	(false),
		m_ExtremaType(E_NONE),
		m_Angle		(0.0f),
		m_InVector  (H_Vector2f(0.0f, 0.0f)),
		m_OutVector (H_Vector2f(0.0f, 0.0f)),
		m_NormalX(0.0f),
		m_NormalY(0.0f),
        m_Index(-9),
		m_NormalizedIndex(0.0f),
        m_PathLength(0.0f),
		m_FlatExtrema(false)
{
}

/* CTOR */ H_ContourPoint::H_ContourPoint(H_PointType type, H_Vector2f point)
	: 
	m_Type		(type),
	m_Point		(point),
	m_IsExtremum(false),
	m_Smooth	(false),
	m_ExtremaType(E_NONE),
	m_Angle		(0.0f),
	m_InVector  (H_Vector2f(0.0f, 0.0f)),
	m_OutVector (H_Vector2f(0.0f, 0.0f)),
	m_NormalX(0.0f),
	m_NormalY(0.0f),
    m_Index(-7),
	m_NormalizedIndex(0.0f),
	m_PathLength(0.0f),
	m_FlatExtrema(false)
{
}

int H_ContourPoint::ScoreMatch(H_ContourPoint& other, bool useIndex /* = true */)
{
	int points = 0;
	
	if (m_ExtremaType != other.m_ExtremaType)
	{
		points += 100;
	}

	points += (int) fabs(m_Angle - other.m_Angle);
	points += (int) fabs(AngleBetween(m_OutVector, other.m_OutVector));
	points += (int) fabs(AngleBetween(m_InVector, other.m_InVector));

	points += (int) (fabs(m_NormalX - other.m_NormalX) * 100.0f);
	points += (int) (fabs(m_NormalY - other.m_NormalY) * 100.0f);

	//points += fabs(PointDistance(m_Point, other.m_Point));

	if (useIndex)
	{
		points += (int) fabs(m_NormalizedIndex - other.m_NormalizedIndex);
	}

	return points;
}


int H_ContourPoint::ScoreOnCurve(H_ContourPoint& other, bool useIndex /* = true */)
{
	int points = 0;
	
	if (m_ExtremaType != other.m_ExtremaType)
	{
		points += 100;
	}

	points += (int) fabs(m_Angle - other.m_Angle);
	points += (int) fabs(AngleBetween(m_OutVector, other.m_OutVector));
	points += (int) fabs(AngleBetween(m_InVector, other.m_InVector));

	// For on curve points we care about distance more than for scoring extrema.
	points += (int) (fabs(m_NormalX - other.m_NormalX) * 300.0f);
	points += (int) (fabs(m_NormalY - other.m_NormalY) * 300.0f);

	//points += fabs(PointDistance(m_Point, other.m_Point));

	if (useIndex)
	{
		points += (int) fabs(m_NormalizedIndex - other.m_NormalizedIndex);
	}

	return points;
}


bool H_ContourPoint::operator ==(const H_ContourPoint& other) const 
{
	bool same = false;

	if (	(m_Type				== other.m_Type				) &&
			(m_Point			== other.m_Point			) &&
			(m_IsExtremum		== other.m_IsExtremum		) &&
			(m_ExtremaType		== other.m_ExtremaType		) &&
			(m_Smooth           == other.m_Smooth           ) &&
			(m_Angle			== other.m_Angle			) &&
			(m_InVector		    == other.m_InVector		    ) &&
			(m_OutVector		== other.m_OutVector		) &&
			(m_NormalX			== other.m_NormalX			) &&
			(m_NormalY			== other.m_NormalY			) &&
			(m_Index			== other.m_Index			) &&
			(m_NormalizedIndex  == other.m_NormalizedIndex	) &&
			(m_FlatExtrema      == other.m_FlatExtrema      ) )
	{
		same = true;
	}
	return same;
}


bool H_ContourPoint::SortOnY(H_ContourPoint& a, H_ContourPoint& b)
{
    return a.m_Point.Y() < b.m_Point.Y();
}

void H_ContourPoint::Print()
{
	if (m_Type == ON_CURVE)
	{
		printf("ON (");
	}
	else
	{
		printf("OFF (");
	}

	m_Point.Print();

	printf(")\n");
}


bool H_ContourPoint::IsValid()
{
	return (m_Point.IsValid() && m_Point.IsInteger());
}

void H_ContourPoint::CalcDirection(H_ContourPoint& previous, H_ContourPoint& next)
{
	m_OutVector = next.m_Point - m_Point;
	m_InVector  = m_Point - previous.m_Point;
}
