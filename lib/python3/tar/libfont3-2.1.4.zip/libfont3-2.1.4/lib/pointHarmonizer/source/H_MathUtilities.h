// Copyright (C) 2014 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// MathUtilities.h

#ifndef H_MATH_UTILITIES_H
#define H_MATH_UTILITIES_H

#include <math.h>
#include "H_Vector2f.h"
#include "H_Line2D.h"

static const double H_PI		 = 3.14159265;
static const float  H_FLOAT_MAX  = 3.4e+038f;
static const float  H_FLOAT_MIN  = -3.4e+037f;
static const int    H_MAX_INT	 = 0x7FFFFFFF;
static const int    H_MIN_INT	 = 0xFFFFFFFF;
static const float  H_COLINEAR   = 7.0f;


static inline double H_ToRadians(double degrees)
{
    return degrees * (H_PI / 180);
}

static inline double H_ToDegrees(double radians)
{
    return radians * (180.0 / H_PI);
}

static inline bool H_IsNan(double x)
{
    return x != x;  //lint !e777
}

static inline bool H_IsInf(double x)
{
    return !H_IsNan(x) && H_IsNan(x - x);
}

static inline bool H_IsNam(float x)
{
    return x != x;
}

static inline bool H_IsInf(float x)
{
    return !H_IsNan(x) && H_IsNan(x - x);
}

static inline float H_Clamp(float& value, float low, float high)
{
    if (value < low)
    {
        value = low;
    }
    if (value > high)
    {
        value = high;
    }
    return value;
}

static inline double H_Clamp(double& value, double low, double high)
{
    if (value < low)
    {
        value = low;
    }
    if (value > high)
    {
        value = high;
    }
    return value;
}

static inline void H_Clamp(int& value, int low, int high)
{
    if (value < low)
    {
        value = low;
    }
    if (value > high)
    {
        value = high;
    }
}

// Convert 16:16 Fixed Point to float.
static inline float H_FixedToFloat(int fixed)
{
    return (float) fixed / 65536.0f;
}

static inline int H_FloatToFixed(float val)
{
    float shifted = val * 65536.0f;
    return (int) shifted;
}


static inline H_Vector2f H_Interpolate(H_Vector2f& a, H_Vector2f& b, float t)
{
    H_Vector2f result;

    result[0] = a[0] + (b[0] - a[0]) * t;
    result[1] = a[1] + (b[1] - a[1]) * t;

    return result;
}

static inline bool H_Same(float one, float two, float epsilon)
{
	bool same = false;

	if (fabs(two - one) < epsilon)
	{
		same = true;
	}

	return same;
}


/*
// Actually twice triangle area, but we're just looking for the sign.
static inline float TriangleArea(H_Vector2f v1, H_Vector2f v2, H_Vector2f v3)
{
    return (v3[0] * v2[1] - v2[0] * v3[1]) - (v3[0] * v1[1] - v1[0] * v3[1]) + (v2[0] * v1[1] - v1[0] * v2[1]);
}
*/

static inline void H_Swap(int& a, int& b)
{
    int temp = a;
    a = b;
    b = temp;
}

static inline void H_Swap(float& a, float& b)
{
    float temp = a;
    a = b;
    b = temp;
}

static inline float H_F_MIN(float a, float b)
{
    return (a < b ? a : b);
}

static inline float H_F_MAX(float a, float b)
{
    return (a > b ? a : b);
}



#endif
