// Copyright (C) 2015 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// BresenhamLine.cpp

#include "H_BresenhamLine.h"
#include "H_MathUtilities.h"
#include <stdlib.h>
#include <math.h>

H_BresenhamLine::H_BresenhamLine()
    :   m_Start(H_Vector2i()),
        m_End(H_Vector2i())
{
}

H_BresenhamLine::H_BresenhamLine(const H_Vector2i& start, const H_Vector2i& end)
    :   m_Start(start),
        m_End(end)
{
}

bool H_BresenhamLine::FirstPoint(H_Vector2i& point)
{
    // Copy off our points, we're going to mess with them.
    int startX;
    int startY;
    int endX;
    int endY;

    startX  = m_Start[0];
    endX = m_End[0];

    startY  = m_Start[1];
    endY = m_End[1];

    // Is our line y major?
    m_yMajor = (abs(endY - startY) > abs(endX - startX));

    // If so swap x and y's: we'll fix up before we emit a point.
    if (m_yMajor)
    {
        H_Swap(startX, startY);
        H_Swap(endX, endY);
    }

    // Make sure we're moving positive in x.
    if (startX > endX)
    {
        H_Swap(startX, endX);
        H_Swap(startY, endY);
    }

    m_LastX = endX;
    m_DeltaX = (float)(endX - startX);
    m_DeltaY = (float)abs(endY - startY);

    m_Error = m_DeltaX / 2.0f;

    m_yStep = 1;

    if (startY > endY)
    {
        m_yStep = -1;
    }

    m_CurrentY = startY;
    m_CurrentX = startX;


    // Swap x and y's back if necessary.
    if (m_yMajor)
    {
        point[0] = m_CurrentY;
        point[1] = m_CurrentX;
    }
    else
    {
        point[0] = m_CurrentX;
        point[1] = m_CurrentY;
    }

    return true;
}

bool H_BresenhamLine::NextPoint(H_Vector2i& point)
{
    bool newPoint = false;

    ++m_CurrentX;

    if (m_CurrentX <= m_LastX)
    {
        m_Error -= m_DeltaY;

        // When we've eaten up deltaX of deltaY's 
        // step in y and start again.
        if (m_Error < 0.0f)
        {
            m_CurrentY += m_yStep;
            m_Error += m_DeltaX;
        }

        // Fix up if we swapped x and y's.
        if (m_yMajor)
        {
            point[0] = m_CurrentY;
            point[1] = m_CurrentX;
        }
        else
        {
            point[0] = m_CurrentX;
            point[1] = m_CurrentY;
        }
        newPoint = true;
    }

    return newPoint;
}

float H_BresenhamLine::Length() const
{
    float length;
    H_Vector2i lineVec = m_End - m_Start;
    length = lineVec.Length();
    return length;
}
