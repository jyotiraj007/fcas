// Copyright (C) 2016 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// H_Contour.h

#ifndef H_CONTOUR_H
#define H_CONTOUR_H

#include "H_ContourPoint.h"
#include "H_ArrayList.h"
#include "H_ScaleOffset.h"

enum H_Handedness { eH_CW, eH_CCW };
class H_BoundingBox;

class H_Contour
{
    public:

        /* CTOR */          H_Contour          ();
        /* CTOR */          H_Contour          (const H_Contour& other);

        void                Clear               ();
        void                AddPoint            (const H_ContourPoint& point);

        int                 NumPoints           ();
        H_ContourPoint&		GetPoint            (int index);

        void                Reverse             ();

        H_Handedness		GetHandedness       ();

        void                ClearNestingLevel   ();
        int                 GetNestingLevel     ();
        void                IncNestingLevel     ();

        void                SetId               (int id);
        int                 GetId               ();

        void                GetPointBounds      (H_BoundingBox& boundsBox);
		void				FindExtrema			();
		void                FindFlatExtrema		();
		void                FindDirections		();
		void                FindAngles			();
		void                FindPositions		();

		int                 FindFirstPoint		();

		int                 FirstPointIndex();

		void                SetFirstPoint	(int index);
		void                ReOrder();

        void                Scale              (float xScale, float yScale);
        void                Offset             (float x, float y);

        int                 SizeBytes       ();

		void                LabelIndices();

    protected:


        H_ArrayList<H_ContourPoint>		m_Points;

        int								m_Id;
        int								m_NestingLevel;
		int								m_FirstPoint;
};

#endif
