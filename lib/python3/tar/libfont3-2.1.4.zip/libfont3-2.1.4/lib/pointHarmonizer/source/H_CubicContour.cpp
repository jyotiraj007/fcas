// Copyright (C) 2015 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// CubicContour.cpp

#include "H_CubicContour.h"
#include "H_CubicBezier.h"


H_CubicContour::H_CubicContour(int designUnits)
    : H_Contour()
{
    (void)designUnits;
}


int H_CubicContour::FirstOnCurve()
{
	m_CurrentIndex = 0;

	return NextOnCurve();
}

int H_CubicContour::NextOnCurve()
{
	int index = -1;

	while (m_CurrentIndex < m_Points.NumElements())
	{
		if (m_Points[m_CurrentIndex].m_Type == H_ContourPoint::ON_CURVE)
		{
			index = m_CurrentIndex;
			m_CurrentIndex++;
			break;
		}
		m_CurrentIndex++;
	}

	return index;
}

