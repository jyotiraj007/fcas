// Copyright (C) 2016 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// H_ComboArrayList.h

#ifndef H_COMBO_ARRAY_LIST_H
#define H_COMBO_ARRAY_LIST_H

#include "H_ArrayList.h"

template <class T> 
class H_ComboArrayList : public H_ArrayList<T>
{
    public:

        int         NumCombos           ();
        void        GetCombo            (int index, H_ArrayList<T>& sequence);

    protected:

        int             m_NumCombinations;
};


template <class T>
int H_ComboArrayList<T>::NumCombos()
{
    m_NumCombinations = pow(2.0f, H_ArrayList<T>::NumElements());
    return m_NumCombinations;
}


template <class T>
void H_ComboArrayList<T>::GetCombo(int index, H_ArrayList<T>& sequence)
{
    sequence.ResetIndex();

    int current = 1;
    int num = 0;
 
    while (current < m_NumCombinations)
    {
        if (index & current)
        {
            sequence.Add(H_ArrayList<T>::operator[](num));
        }

        num++;
        current <<= 1;
    }
}

#endif
