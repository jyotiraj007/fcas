// Copyright (C) 2016 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// H_HashTable.h

#ifndef H_HASH_TABLE
#define H_HASH_TABLE


template<class T>
class H_HashTable
{
    public:
        enum   { NUM_BUCKETS = 256 };


        /* CTOR */      H_HashTable   ();

        void            Add (unsigned long value, T element);
        void            Find(unsigned long value, H_ArrayList<T>& elements);

    protected:

        unsigned char   Hash        (unsigned long value);

        H_ArrayList<T>    m_Buckets[NUM_BUCKETS];
};

template<class T>
H_HashTable<T>::H_HashTable()
{
}

template<class T>
void H_HashTable<T>::Add(unsigned long value, T element)
{
    unsigned char bucket = Hash(value);

    m_Buckets[bucket].Add(element);
}

template<class T>
unsigned char H_HashTable<T>::Hash(unsigned long value)
{
    unsigned char hash = 137;

    unsigned char b1 = (unsigned char) (value >> 0 ); 
    unsigned char b2 = (unsigned char) (value >> 8 );
    unsigned char b3 = (unsigned char) (value >> 16);
    unsigned char b4 = (unsigned char) (value >> 24);

    hash = ((hash << 3) + hash);
    hash += b1; 
    hash = ((hash << 3) + hash); 
    hash += b2; 
    hash = ((hash << 3) + hash); 
    hash += b3; 
    hash = ((hash << 3) + hash); 
    hash += b4; 

    return hash;
}

template<class T>
void H_HashTable<T>::Find(unsigned long value, H_ArrayList<T>& elements)
{
    elements.Clear();

    unsigned char bucket = Hash(value);

    for (int i = 0; i < m_Buckets[bucket].NumElements(); i++)
    {
        if (m_Buckets[bucket][i]->m_Data == (int)value)
        {
            elements.Add(m_Buckets[bucket][i]);
        }
    }
}


#endif
