// Copyright (C) 2014 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
/// \file CubicBezier.h

#ifndef H_CUBIC_BEZIER_H
#define H_CUBIC_BEZIER_H

#include "H_ArrayList.h"
#include "H_Vector2f.h"
#include "H_QuadBezier.h"
#include "H_Line2D.h"
#include "H_QuadContour.h"
#include "H_Stack.h"
#include "H_CubicPoints.h"



class  H_CubicBezier
{
    public:

	enum H_Comparision { H_EQUALS = 0, H_LESS_THAN, H_ANY };

    enum Control { eCONTROL1 = 0, eCONTROL2, eSTART, eEND, eNONE };       // Must start with control: indexes m_Bars.

        /* Ctor */  H_CubicBezier ();
        /* Ctor */  H_CubicBezier (const H_Vector2f& startPoint, const H_Vector2f& endPoint, const H_Vector2f& controlPoint1, const H_Vector2f& controlPoint2, int numSegments = 10);
        /* Ctor */  H_CubicBezier (const H_CubicPoints& cubicPoints);
        void        Init        (const H_Vector2f& startPoint, const H_Vector2f& endPoint, const H_Vector2f& controlPoint1, const H_Vector2f& controlPoint2, int numSegments = 10);

        void        SetPoint    (Control control, const H_Vector2f& point);
        H_Vector2f  GetPoint    (Control control);

        void        GetPoints  (H_CubicPoints& points);
        void        SetPoints  (const H_CubicPoints& points);

        bool        Match       (H_QuadContour& quadContour,  int numPoints,  float tolerance, H_Comparision comparision = H_EQUALS);

        int         NumSegments ();

        void        CreateSegments  (float flatness = 0.05f);
        void        Evaluate        (float flatness = 0.05f);

    protected:

		void           ReverseControlPoints();
		bool FlatStart();

        bool            Search          (H_QuadContour& quadContour);
        bool            Score           ();
        bool            CheckRight      (H_Line2D& startTangent, H_Line2D& startTarget, int startIndex, int endIndex);
        int             FindFirst       (H_Line2D& startTangent, int startIndex, int endIndex);


        bool            WithinTolerance (H_QuadBezier& quad, float& distance);
        double          SplineDistance  (H_QuadBezier& quad, bool& anyIntersections, int startIndex, int stopIndex);
        bool            IsLinear        (float tolerance = 1.5f);

        H_Vector2f        CalculatePoint  (float t);

        H_ArrayList<H_QuadBezier>   m_Beziers;
        H_ArrayList<H_Line2D>       m_Tangents;
        H_ArrayList<H_Vector2f>     m_Intersections;
        H_ArrayList<H_Vector2f>     m_ControlPoints;

        float                   m_BestAverage;
        H_ArrayList<H_QuadBezier>   m_BestBeziers;
        bool                    m_FoundMatch;
        H_Line2D                  m_StartTangent;
        H_Line2D                  m_EndTangent;
        H_ArrayList<H_Line2D>       m_AllTangents;
        
        float                   m_CurrentFlatness;
        void                    CreateNormals();
        H_ArrayList<H_Line2D>       m_NormalLines; // Normals to this cubics segments;
        H_ArrayList<H_Vector2f>     m_MidPoints;

        H_Stack<H_Line2D>       m_EvalStack;
        H_Vector2f            m_Control[4];

        int                 m_NumSegments;
        H_ArrayList<H_Vector2f> m_Points;

        float               m_Tolerance;
        int                 m_Depth;
        int                 m_CheckDepth;

		H_Comparision       m_Comparision;
		int                 m_NumPoints;

		void                EmitResults(H_QuadContour& quadContour);
		H_ArrayList<H_ContourPoint> m_Results;
		bool                m_Backwards;
};

#endif
