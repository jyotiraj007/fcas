// Copyright (C) 2014 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// H_LinkedList.h
#ifndef H_LINKED_LIST_H
#define H_LINKED_LIST_H

#include <stdlib.h>
#include "H_ArrayList.h"

// A linked list wherein all of the elements are stored on a H_ArrayList that is shared amongst all lists of 
// the same type. i.e. All H_LinkedList<int>'s elements will be stored on one static array.
// This simplifies use of the list, prevents heap fragmentation.
// Tear down of all lists<type> is by static member ClearHeap

// The elements of the linked list.
template<class Data>
class H_ListElem
{
    public:

        H_ListElem()
            : m_Next(NULL)
        {
        }

        H_ListElem(const Data& data)
            :   m_Data(data),
                m_Next(NULL)
        {
        }

        Data            m_Data;   // The data we are storing on the list.
        H_ListElem*    m_Next;   
};


template<class Data>
class H_LinkedList
{
    public:

        /* Ctor */          H_LinkedList();
        /* Ctor */          H_LinkedList(const H_LinkedList& other);

        /* Dtor */         ~H_LinkedList();


		H_LinkedList&       operator =      (const H_LinkedList& other);
        void                Add             (const Data& data);
		void                Add				(H_ListElem<Data>* pElement);

        void                Remove          (H_ListElem<Data>* pElement);
        void                InsertAfter     (H_ListElem<Data>* pElement, H_ListElem<Data>* pNewElement);

        void                RemoveAll       ();
        int                 NumElements     ();

        // Iterators:
        Data*               First        ();
        Data*               Next         ();
        Data*               Last         ();

        const Data*			First        () const;
        const Data*			Next         () const;
        const Data*			Last         () const;

        H_ListElem<Data>*  GetFirstElement ();
        H_ListElem<Data>*  GetNextElement  ();
        H_ListElem<Data>*  GetLastElement  ();
        H_ListElem<Data>*  GetPrevious     (const H_ListElem<Data>* pElement);
        H_ListElem<Data>*  GetNext         (const H_ListElem<Data>* pElement) const;

        H_ListElem<Data>*  Find            (Data& data);

        bool                IsEmpty         () const;

        static void         ClearHeap       ();
        static void         PrintMem();

		void                FreePool		(); // Only use on program exit to avoid erroneous memory leak message.

        H_ListElem<Data>*  AllocElem       (const Data& data);

    protected:

        H_ListElem<Data>*  m_Head;
        H_ListElem<Data>*  m_Tail;
        mutable H_ListElem<Data>*  m_Iterator;

        static H_ArrayList<H_ListElem<Data> > m_Elements;
};

template<class Data>
void H_LinkedList<Data>::PrintMem()
{
    m_Elements.PrintMem();
}

template<class Data>
H_ArrayList<H_ListElem<Data> >  H_LinkedList<Data>::m_Elements;


template<class Data>
void H_LinkedList<Data>::ClearHeap()
{
	m_Elements.Clear();
}

template<class Data>
H_LinkedList<Data>::H_LinkedList()
{
    m_Head = NULL;
    m_Tail = NULL;
    m_Iterator = NULL;
}

template<class Data>
H_LinkedList<Data>::H_LinkedList(const H_LinkedList& other)
{
    m_Head = NULL;
    m_Tail = NULL;
    m_Iterator = NULL;

    const Data* pElement = other.First();

    while (pElement)
    {
        Add(*pElement);
        pElement = other.Next();
    }
}

template<class Data>
H_LinkedList<Data>& H_LinkedList<Data>::operator=(const H_LinkedList& other)
{
    m_Head = NULL;
    m_Tail = NULL;
    m_Iterator = NULL;

    const Data* pElement = other.First();

    while (pElement)
    {
        Add(*pElement);
        pElement = other.Next();
    }
	return *this;
}

template<class Data>
H_LinkedList<Data>::~H_LinkedList()
{
}

// Only use on program exit to avoid erroneous memory leak message!
// This deletes pool memory for all lists of this template type.
template<class Data>
void H_LinkedList<Data>::FreePool()
{
 	m_Elements.FreeAll();
}

template<class Data>
H_ListElem<Data>* H_LinkedList<Data>::AllocElem(const Data& data)
{
    H_ListElem<Data> elem(data);
    m_Elements.Add(elem);
    return &m_Elements.Last();
}

template<class Data>
void H_LinkedList<Data>::Add(H_ListElem<Data>* pElement)
{
	if (NULL != pElement)
    {
        pElement->m_Next = NULL;

        // If empty set head.
        if (IsEmpty())
        {
            m_Head = pElement;
            m_Tail = pElement;
        }
        else // Add to the end.
        {
            if (m_Tail != NULL)
            {
                m_Tail->m_Next = pElement;
            }
            m_Tail = pElement;
        }
    }
}

template<class Data>
void H_LinkedList<Data>::Add(const Data& data)
{
    H_ListElem<Data>* pElement = AllocElem(data);

	Add(pElement);
 
}


template<class Data>
int H_LinkedList<Data>::NumElements()
{
    int count = 0;

    H_ListElem<Data>* pElement = GetFirstElement();

    while (pElement)
    {
        count++;
        pElement = GetNextElement();
    }

    return count;
}

template<class Data>
void H_LinkedList<Data>::Remove(H_ListElem<Data>* pElement)
{
    if (pElement)
    {
        H_ListElem<Data>* pPrevious = GetPrevious(pElement);

        // If it's the only element, null out head and tail pointers.
        if (m_Head == m_Tail)
        {
            m_Head = NULL;
            m_Tail = NULL;
        }
        else if (pElement == m_Head)
        {
            m_Head = m_Head->m_Next;
        }
        else if (pElement == m_Tail)
        {
            m_Tail = pPrevious;
        }

        if (pPrevious)
        {
            pPrevious->m_Next = pElement->m_Next;
        }

        // No longer part of list so zero out pointer.
        pElement->m_Next = NULL;
    }
}

template<class Data>
void H_LinkedList<Data>::InsertAfter(H_ListElem<Data>* pElement, H_ListElem<Data>* pNewElement)
{
    if ((pElement == NULL) || (pNewElement == NULL))
        return;

    if (m_Tail == pElement)
    {
        m_Tail = pNewElement;
    }
    pNewElement->m_Next = pElement->m_Next;
    pElement->m_Next = pNewElement;
}

template<class Data>
H_ListElem<Data>* H_LinkedList<Data>::GetNext(const H_ListElem<Data>* pElement) const
{
    return pElement->m_Next;
}

template<class Data>
H_ListElem<Data>*  H_LinkedList<Data>::GetPrevious(const H_ListElem<Data>* pElement)
{
    H_ListElem<Data>* pCurrent  = m_Head;
    H_ListElem<Data>* pPrevious = NULL;

    while (pCurrent)
    {
        if (pCurrent == pElement)
        {
            return pPrevious;
        }
        pPrevious = pCurrent;
        pCurrent = pCurrent->m_Next;
    }
    return NULL;
}



// operator == must be available on Data.
template<class Data>
H_ListElem<Data>*  H_LinkedList<Data>::Find(Data& data)
{
    H_ListElem<Data>* pCurrent = m_Head;

    while (pCurrent)
    {
        if (pCurrent->m_Data == data)
        {
            return pCurrent;
        }
        pCurrent = pCurrent->m_Next;
    }
    return NULL;
}


template<class Data>
void H_LinkedList<Data>::RemoveAll()
{
    H_ListElem<Data>* pCurrent = m_Head;
    H_ListElem<Data>* pLast    = m_Head;

    while (NULL != pCurrent)
    {
        pLast = pCurrent;
        pCurrent = pCurrent->m_Next;
        pLast->m_Next = NULL;
    }

    m_Head = NULL;
    m_Tail = NULL;
}


template<class Data>
Data* H_LinkedList<Data>::First()
{
    Data* pData = NULL;

    m_Iterator = m_Head;

    if (NULL != m_Iterator)
    {
        pData = &m_Iterator->m_Data;
    }
    return pData;
}

template<class Data>
Data* H_LinkedList<Data>::Last()
{
    Data* pData = NULL;
    m_Iterator = m_Tail;

    if (NULL != m_Iterator)
    {
        pData = &m_Iterator->m_Data;
    }
    return pData;
}

template<class Data>
Data* H_LinkedList<Data>::Next()
{
    Data* pData = NULL;

    if (m_Iterator != m_Tail)
    {
       m_Iterator = m_Iterator->m_Next;
    }
    else
    {
        m_Iterator = NULL;
    }

    if (NULL != m_Iterator)
    {
        pData = &m_Iterator->m_Data;
    }

    return pData;
}


template<class Data>
const Data* H_LinkedList<Data>::First()  const
{
    Data* pData = NULL;

    m_Iterator = m_Head;

    if (NULL != m_Iterator)
    {
        pData = &m_Iterator->m_Data;
    }
    return pData;
}

template<class Data>
const Data* H_LinkedList<Data>::Last()  const
{
    Data* pData = NULL;
    m_Iterator = m_Tail;

    if (NULL != m_Iterator)
    {
        pData = &m_Iterator->m_Data;
    }
    return pData;
}

template<class Data>
const Data* H_LinkedList<Data>::Next() const
{
    Data* pData = NULL;

    if (m_Iterator != m_Tail)
    {
       m_Iterator = m_Iterator->m_Next;
    }
    else
    {
        m_Iterator = NULL;
    }

    if (NULL != m_Iterator)
    {
        pData = &m_Iterator->m_Data;
    }

    return pData;
}

template<class Data>
H_ListElem<Data>* H_LinkedList<Data>::GetFirstElement()
{
    m_Iterator = m_Head;

    return m_Iterator;
}

template<class Data>
H_ListElem<Data>* H_LinkedList<Data>::GetLastElement()
{
    m_Iterator = m_Tail;

    return m_Iterator;
}

template<class Data>
H_ListElem<Data>* H_LinkedList<Data>::GetNextElement()
{
    if ((m_Iterator != m_Tail) && (m_Iterator != NULL))
    {
       m_Iterator = m_Iterator->m_Next;
    }
    else
    {
        m_Iterator = NULL;
    }
    return m_Iterator;
}

template<class Data>
bool H_LinkedList<Data>::IsEmpty() const
{
   bool isEmpty = false;

   if (   (NULL == m_Head)
       && (NULL == m_Tail) )
   {
      isEmpty = true;
   }

   return isEmpty;
}

#endif
