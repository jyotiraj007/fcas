// Copyright (C) 2014 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// H_QuadBezier.h

#ifndef H_QUAD_BEZIER_H
#define H_QUAD_BEZIER_H

#include "H_QuadPoints.h"
#include "H_ArrayList.h"
#include "H_Vector2f.h"
#include "H_Stack.h"
#include "H_Triangle.h"
#include "H_Line2D.h"

class H_CubicContour;


class  H_QuadBezier
{
    public:

        enum Control		{ eSTART = 0, eEND, eCONTROL };
		enum TangentType	{ eHORIZONTAL = 0, eVERTICAL, eANGLE };

        /* Ctor */  H_QuadBezier		();
        /* Ctor */  H_QuadBezier        (const H_Vector2f& startPoint, const H_Vector2f& endPoint, const H_Vector2f& controlPoint);
        /* Ctor */  H_QuadBezier         (H_QuadPoints& quadPoints);
        void        Init                (const H_Vector2f& startPoint, const H_Vector2f& endPoint, const H_Vector2f& controlPoint);

        void        SetPoint            (Control control, const H_Vector2f& point);
        H_Vector2f  GetPoint            (Control control);
        void        Evaluate1            (float flatness = 0.01f);
        void        Evaluate            (float flatness = 0.01f);
		float       PathLength			();

        int         IndexAt             (float position);

        void        SplitAt             (float position, H_QuadPoints& a, H_QuadPoints& b);


        bool        Intersects          (H_QuadBezier& other);
        void        GetIntersections    (H_QuadBezier& other, H_ArrayList<H_Vector2f>& intersections);

        bool        Intersects          (H_Line2D& line);
        void        GetIntersections    (H_Line2D& line, H_ArrayList<H_Vector2f>& intersections);

        float       LeftExtent          ();
        float       RightExtent         ();
        float       TopExtent           ();
        float       BottomExtent        ();

        bool        LeftIsTangent       ();
        bool        RightIsTangent      ();
        bool        TopIsTangent        ();
        bool        BottomIsTangent     ();

		int         NumCurvePoints		();
		H_Vector2f  GetCurvePoint		(int index);

		H_Line2D    GetStartTangent		();
		H_Line2D    GetEndTangent		();

    protected:

		H_Vector2f  PointAt				(float t);
        float       HorizontalTangent   ();
        float       VerticalTangent     ();

        bool        TrianglesIntersect  (H_QuadBezier& other, H_ArrayList<int>& list1, H_ArrayList<int>& list2);
        bool        LineIntersects      (H_Line2D& line, H_ArrayList<int>& indexList);
        bool        Split               (H_ArrayList<int>& indexList, float flatness = 0.01f);

        H_ArrayList<H_Triangle>			m_Triangles;
        H_ArrayList<H_Vector2f>         m_Points;
        H_Vector2f                      m_Control[3];

        bool                            m_LeftIsTangent;
        bool                            m_RightIsTangent;
        bool                            m_TopIsTangent;
        bool                            m_BottomIsTangent;
};


inline bool H_QuadBezier::LeftIsTangent  () { return m_LeftIsTangent;    };
inline bool H_QuadBezier::RightIsTangent () { return m_RightIsTangent;   };
inline bool H_QuadBezier::TopIsTangent   () { return m_TopIsTangent;     };
inline bool H_QuadBezier::BottomIsTangent() { return m_BottomIsTangent;  };



#endif
