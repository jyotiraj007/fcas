// Copyright (C) 2016 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// H_Component.h

#ifndef H_COMPONENT_H
#define H_COMPONENT_H

#include "H_Vector2f.h"
#include "H_ScaleOffset.h"

class H_Component
{
    public:

        /* CTOR */  H_Component   ();
        /* CTOR */  H_Component   (int glyphId, H_ScaleOffset scaleOffset);

        int         m_GlyphId;

        H_ScaleOffset m_ScaleOffset;
};

#endif

