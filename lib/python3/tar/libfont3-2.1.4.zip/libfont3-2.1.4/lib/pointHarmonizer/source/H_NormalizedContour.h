// Copyright (C) 2016 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// H_NormalizedContour.h

#ifndef H_NORMALIZED_CONTOUR_H
#define H_NORMALIZED_CONTOUR_H

#include "H_Contour.h"
#include "H_ScaleOffset.h"
#include <stdlib.h>
#include <math.h>

class H_NormalizedPoint
{
    public:

        H_NormalizedPoint()
            :   m_Data(0)
        {};

        H_NormalizedPoint(float x, float y)
        {
            m_Shorts.m_X = (short) floor(x);
            m_Shorts.m_Y = (short) floor(y);
        }

        operator int() { return m_Data; };

        bool operator ==(H_NormalizedPoint& other)
        {
            bool equal = false;

            int epsilon = (int) (0x00007fff * EPSILON);  

            if (    ( abs(m_Shorts.m_X - other.m_Shorts.m_X) < epsilon) &&
                    ( abs(m_Shorts.m_Y - other.m_Shorts.m_Y) < epsilon)    )
            {
                equal = true;
            }

            return equal;
        }

        static void SetTolerance(float tolerance) { EPSILON = tolerance; };
        static float GetTolerance() { return    EPSILON; };

        union
        {
            int   m_Data;

            struct
            {
                short m_X;
                short m_Y;
            } m_Shorts;
        };

        static float EPSILON;
};


class H_NormalizedContour
{
    public:
        /* CTOR */ H_NormalizedContour();
        /* CTOR */ H_NormalizedContour(H_Contour& contour);


        H_ArrayList<H_NormalizedPoint>& GetOffsets();

    protected:

        H_ArrayList<H_NormalizedPoint> m_Points;
};

#endif
