// Copyright (C) 2016 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// H_BoundingBox.h

#ifndef H_BOUNDING_BOX_H
#define H_BOUNDING_BOX_H

#include "H_Vector2f.h"
#include "H_MathUtilities.h"
#include "H_ScaleOffset.h"
#include <float.h>

class H_BoundingBox
{
    public:
        /* CTOR */  H_BoundingBox ();

        void        Reset       ();
        bool        Expand      (const H_Vector2f& point);
        bool        ExpandLeft  (float x);
        bool        ExpandRight (float x);
        bool        ExpandTop   (float y);
        bool        ExpandBottom(float y);

        float       Left        ();
        float       Right       ();
        float       Bottom      ();
        float       Top         ();

        float       Width       ();
        float       Height      ();

		void		Scale		(float xScale, float yScale);


		H_ScaleOffset	GetScaleOffset	(H_BoundingBox& other);
		float			Distance		(H_BoundingBox& other);
		void			Center			(H_Vector2f& center);
		void			Offset			(float x, float y);

		void            ApplyScaleOffset(H_ScaleOffset& scaleOffset);

    protected:

        float   m_Left;
        float   m_Right;
        float   m_Top;
        float   m_Bottom;
};

// Implementation:
inline H_BoundingBox::H_BoundingBox() 
    : m_Left    (+FLT_MAX),
      m_Right   (-FLT_MAX),
      m_Top     (-FLT_MAX),
      m_Bottom  (+FLT_MAX)
{
};

inline void H_BoundingBox::Reset()
{
    m_Left   = +FLT_MAX;
    m_Right  = -FLT_MAX;
    m_Top    = -FLT_MAX;
    m_Bottom = +FLT_MAX;
};


inline void H_BoundingBox::Center(H_Vector2f& center)
{
	float x = (m_Left + m_Right) / 2.0f;
	float y = (m_Top + m_Bottom) / 2.0f;

	center = H_Vector2f(x, y);
}


inline void H_BoundingBox::Offset(float x, float y)
{
	m_Left	+= x;
	m_Right += x;

	m_Top	 += y;
	m_Bottom += y;
}

// return average distance between for corners and center.
inline float H_BoundingBox::Distance(H_BoundingBox& other)
{
	H_Vector2f otherCenter;
	H_Vector2f center;

	other.Center(otherCenter);
	Center(center);

	float distance = PointDistance(center, otherCenter);

	H_Vector2f lowerLeft	(Left	(),	Bottom	());
	H_Vector2f lowerRight	(Right	(),	Bottom	());
	H_Vector2f upperLeft	(Left	(),	Top		());
	H_Vector2f upperRight	(Right	(),	Top		());

	H_Vector2f otherLowerLeft	(other.Left	(),	other.Bottom());
	H_Vector2f otherLowerRight	(other.Right(),	other.Bottom());
	H_Vector2f otherUpperLeft	(other.Left	(),	other.Top	());
	H_Vector2f otherUpperRight	(other.Right(),	other.Top	());

	distance += PointDistance(lowerLeft, otherLowerLeft);
	distance += PointDistance(lowerRight, otherLowerRight);
	distance += PointDistance(upperLeft, otherUpperLeft);
	distance += PointDistance(upperRight, otherUpperRight);

	distance /= 4.0f;

	return distance;
}

inline bool H_BoundingBox::ExpandLeft(float x)
{
    bool expanded = false;

    if (x < m_Left)
    {
        m_Left = x;
        expanded = true;
    }

    return expanded;
}

inline bool H_BoundingBox::ExpandRight(float x)
{
    bool expanded = false;

    if (x > m_Right)
    {
        m_Right = x;
        expanded = true;
    }

    return expanded;
}

inline bool H_BoundingBox::ExpandBottom(float y)
{
    bool expanded = false;

    if (y < m_Bottom)
    {
        m_Bottom = y;
        expanded = true;
    }

    return expanded;
}

inline bool H_BoundingBox::ExpandTop(float y)
{
    bool expanded = false;

    if (y > m_Top)
    {
        m_Top = y;
        expanded = true;
    }

    return expanded;
}


inline bool H_BoundingBox::Expand(const H_Vector2f& point)
{
    bool expanded = false;

    expanded |= ExpandLeft  (point.X());
    expanded |= ExpandRight (point.X());
    expanded |= ExpandTop   (point.Y());
    expanded |= ExpandBottom(point.Y());

    return expanded;
}

inline float H_BoundingBox::Left  () { return m_Left;   };
inline float H_BoundingBox::Right () { return m_Right;  };
inline float H_BoundingBox::Top   () { return m_Top;    };
inline float H_BoundingBox::Bottom() { return m_Bottom; };

inline float H_BoundingBox::Width () { return m_Right - m_Left;   };
inline float H_BoundingBox::Height() { return m_Top   - m_Bottom; };



inline void H_BoundingBox::Scale(float xScale, float yScale)
{
    m_Left   *= xScale;
    m_Right  *= xScale;
    m_Top    *= yScale;
    m_Bottom *= yScale;
}

inline void H_BoundingBox::ApplyScaleOffset(H_ScaleOffset& scaleOffset)
{
	Scale(scaleOffset.m_ScaleX, scaleOffset.m_ScaleY);

	Offset((float) scaleOffset.m_OffsetX, (float) scaleOffset.m_OffsetY);
}


// Returns the scale offset to change other into this.
inline H_ScaleOffset H_BoundingBox::GetScaleOffset(H_BoundingBox& other)
{
    H_ScaleOffset scaleOffset;

    scaleOffset.m_ScaleX = 1.0f;
    scaleOffset.m_ScaleY = 1.0f;

    // Careful with single point contours:
    if (other.Width() != 0.0f)
    {
        scaleOffset.m_ScaleX = Width() / other.Width();
    }

    if (other.Height() != 0.0f)
    {
        scaleOffset.m_ScaleY = Height() / other.Height();
    }

    H_BoundingBox scaled = other;
    scaled.Scale(scaleOffset.m_ScaleX, scaleOffset.m_ScaleY);

    scaleOffset.m_OffsetX = (int)((Left()   - scaled.Left())  + 0.5f);
    scaleOffset.m_OffsetY = (int)((Bottom() - scaled.Bottom()) + 0.5f);

    return scaleOffset;
}


#endif
