// Copyright (C) 2016 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// H_Component.cpp

#include "H_Component.h"

H_Component::H_Component()
    :   m_GlyphId(-1),
        m_ScaleOffset()
{
}

H_Component::H_Component(int glyphId, H_ScaleOffset scaleOffset)
    :   m_GlyphId(glyphId),
        m_ScaleOffset(scaleOffset)
{
}
