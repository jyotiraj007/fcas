// Copyright (C) 2016 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// H_GlyphHarmonizer.cpp

#include "H_GlyphHarmonizer.h"
#include "H_BoundingBox.h"
#include "H_CompositQuadBezier.h"
#include "H_CubicBezier.h"


H_GlyphHarmonizer::H_GlyphHarmonizer() 
	: m_DebugLevel(14),
	m_Verbose(false)
{
}


H_GlyphHarmonizer::~H_GlyphHarmonizer()
{
	H_QuadGlyph::ClearHeap();
}


void H_GlyphHarmonizer::Clear()
{
}

bool H_GlyphHarmonizer::CheckEqualContours(H_ArrayList<H_QuadGlyph>& glyphs)
{
	int numContours = glyphs.First().NumContours();

	bool sameNumber = true;

	for (int i = 1; i < glyphs.NumElements(); i++)
	{
		if (glyphs[i].NumContours() != numContours)
		{
			sameNumber = false;
			break;
		}
	}

	return sameNumber;
}

bool H_GlyphHarmonizer::CheckHarmoneous(H_ArrayList<H_QuadGlyph>& glyphs)
{
	int numContours = glyphs[0].NumContours();

	bool contoursSame = true;

	for (int i = 0; i < numContours; i++)
	{
		H_ArrayList<H_QuadContour*> contours;

		for (int j = 0; j < glyphs.NumElements(); j++)
		{
			H_QuadContour* pContour = glyphs[j].GetContour(i);
			if (pContour)
			{
				contours.Add(pContour);
			}
		}

		bool same = true;
		int numOnCurve = contours.First()->NumOnCurve();

		for (int k = 1; k < contours.NumElements(); k++)
		{
			if (contours[k]->NumOnCurve() != numOnCurve)
			{
				same = false;
				break;
			}
		}

		if (false == same)
		{
			contoursSame = false;
			break;
		}
	}

	return contoursSame;
}

// Harmonizes the cubic glyph array into a quad array
// Assumes:
// The glyphs already have correct contour ordering,
// The contours already have coherent start points.
// The contours have the same number of on curve points accross the set.
H_GlyphHarmonizer::H_Result H_GlyphHarmonizer::HarmonizeGlyph(H_ArrayList<H_CubicGlyph>& inputGlyphs, H_ArrayList<H_QuadGlyph>& outputGlyphs)
{
	H_Result result = eSUCCESS;
	int numContours = inputGlyphs[0].NumContours();

	int numGlyphs = inputGlyphs.NumElements();

	outputGlyphs.Clear();
	outputGlyphs.SetNumElements(numGlyphs);

	for (int i = 0; i < numContours; i++)
	{
		H_ArrayList<H_CubicContour*> cubicContours;

		for (int j = 0; j < numGlyphs; j++)
		{
			H_CubicContour* pContour = inputGlyphs[j].GetContour(i);
			if (pContour)
			{
				cubicContours.Add(pContour);
			}
		}
		H_ArrayList<H_QuadContour> quadContours;
		H_Result converted = ConvertContourSet(cubicContours, quadContours);

		AddContour(outputGlyphs, quadContours);

		if (converted != eSUCCESS)
		{
			result = converted;
		}
	}

	return result;
}

void H_GlyphHarmonizer::AddContour(H_ArrayList<H_QuadGlyph>& outputGlyphs, H_ArrayList<H_QuadContour>& quadContours)
{
	for (int i = 0; i < outputGlyphs.NumElements(); i++)
	{
		outputGlyphs[i].AddContour(quadContours[i]);
	}
}

H_GlyphHarmonizer::H_Result H_GlyphHarmonizer::ConvertContourSet(H_ArrayList<H_CubicContour*>& cubicContours, H_ArrayList<H_QuadContour>& quadContours)
{
	H_Result result = eSUCCESS;
	// Input contours have the same number of on curve points.
	H_CubicContour* pFirst = cubicContours.First();
	int numContours = cubicContours.NumElements();
	quadContours.SetNumElements(numContours);

	bool samePoints = true;

	int numPoints = cubicContours[0]->NumPoints();

	for (int i = 1; i < numContours; i++)
	{
		if (cubicContours[i]->NumPoints() != numPoints)
		{
			samePoints = false;
		}
	}

	int startIndex	= pFirst->FirstOnCurve();

	for (int i = 0; i < numContours; i++)
	{
		H_ContourPoint point = cubicContours[i]->GetPoint(startIndex);
		quadContours[i].AddPoint(point);
	}

	if (false == samePoints)
	{
		// Add a single (start) point so Harmonizer doesn't crash and return;
		return eINVALID_INPUT;
	}

	int endIndex = pFirst->NextOnCurve();

	while (endIndex != -1)
	{
		//  Check for line segment.
		if (endIndex == startIndex + 1)
		{
			// Just add it the output:
			for (int i = 0; i < numContours; i++)
			{
				H_ContourPoint point = cubicContours[i]->GetPoint(endIndex);
				quadContours[i].AddPoint(point);
			}
		}
		else if ((endIndex - startIndex) == 3) // We're expecting a cubic.
		{
			int largest = 0;
			bool foundAll = true;

			for (int i = 0; i < numContours; i++)
			{
				H_ContourPoint point0 = cubicContours[i]->GetPoint(startIndex + 0);
				H_ContourPoint point1 = cubicContours[i]->GetPoint(startIndex + 1);
				H_ContourPoint point2 = cubicContours[i]->GetPoint(startIndex + 2);
				H_ContourPoint point3 = cubicContours[i]->GetPoint(startIndex + 3);

				H_Vector2f p0 = point0.m_Point;
				H_Vector2f p1 = point1.m_Point;
				H_Vector2f p2 = point2.m_Point;
				H_Vector2f p3 = point3.m_Point;

				H_CubicBezier cubic(p0, p3, p1, p2);

				H_QuadContour matchedPoints;

				if (false == cubic.Match(matchedPoints, 0, 1.0f, H_CubicBezier::H_ANY))
				{
					foundAll = false;
					result = eFAILED;
				}

				int numOffCurve = matchedPoints.NumPoints() - 1;

				if (numOffCurve > largest)
				{
					largest = numOffCurve;
				}
			}

			if (foundAll)
			{
				for (int i = 0; i < numContours; i++)
				{
					H_ContourPoint point0 = cubicContours[i]->GetPoint(startIndex + 0);
					H_ContourPoint point1 = cubicContours[i]->GetPoint(startIndex + 1);
					H_ContourPoint point2 = cubicContours[i]->GetPoint(startIndex + 2);
					H_ContourPoint point3 = cubicContours[i]->GetPoint(startIndex + 3);

					H_Vector2f p0 = point0.m_Point;
					H_Vector2f p1 = point1.m_Point;
					H_Vector2f p2 = point2.m_Point;
					H_Vector2f p3 = point3.m_Point;

					H_CubicBezier cubic(p0, p3, p1, p2);

					H_QuadContour matchedPoints;
						
					if (false == cubic.Match(matchedPoints, largest, 1.0f, H_CubicBezier::H_EQUALS))
					{
						result = eFAILED;
					}

					for (int j = 0; j < matchedPoints.NumPoints(); j++)
					{
						quadContours[i].AddPoint(matchedPoints.GetPoint(j));
					}
				} 
			}
		}

		startIndex = endIndex;
		endIndex = pFirst->NextOnCurve();
	}

	return result;
}

void H_GlyphHarmonizer::CreateHarmoneousSections(H_ArrayList<H_QuadContour*>& contours)
{
	for (int i = 0; i < contours.NumElements(); i++)
	{
		contours[i]->CreateHarmoneousSections();
	}
}

bool H_GlyphHarmonizer::HarmonizeGlyph(H_ArrayList<H_QuadGlyph>& glyphs, int fontUnits,
									   bool skipContourCheck, bool dontAddExtrema, bool skipStartPointCheck, bool verbose)
{
	bool match = true;
	m_Verbose = verbose;
	
	if (m_Verbose) printf("\n\nHarmonizing %d glyphs\n", glyphs.NumElements());

	H_OutlineSection::SetSmallLine(fontUnits / 15);

	H_LinkedList<H_ContourSection>::ClearHeap();
	H_LinkedList<H_OutlineSection>::ClearHeap();

	if (false == CheckEqualContours(glyphs))
	{
		if (m_Verbose) printf("Unequal Number of contours.\n");
		return false;
	}

	if (glyphs.NumElements() > 0)
	{
		if (false == skipContourCheck)
		{
			SortContours(glyphs);
		}

		// Must do this first because we're storing index later on.
		for (int i = 0; i < glyphs.NumElements(); i++)
		{
			H_QuadGlyph& current = glyphs[i];

			current.IsValid();
			current.RemoveRedundantPoints();
			//current.CheckWinding();				current.IsValid();
			current.FindExtrema();				current.IsValid();

			current.CreateUnMatchedSections();  current.IsValid();

			if (false == dontAddExtrema)
			{
				current.AddMissingExtrema();
				current.IsValid();
			}

			current.RemoveLinearBeziers();		current.IsValid();
			current.MakePoints();				current.IsValid();

			current.FindExtrema();				current.IsValid();
			current.FindDirections();			current.IsValid();
			current.FindAngles();				current.IsValid();
			current.FindPositions();			current.IsValid();
		}

		if (false == skipStartPointCheck)
		{
			MatchFirstPoints(glyphs);
		}

		LabelIndices(glyphs);
		match = MatchPoints(glyphs);
	}

	return match;
}

bool H_GlyphHarmonizer::MatchPoints(H_ArrayList<H_QuadGlyph>& glyphs)
{
	bool match = true;
	int numContours = glyphs[0].NumContours();

	for (int i = 0; i < numContours; i++)
	{
		H_ArrayList<H_QuadContour*> contours;

		for (int j = 0; j < glyphs.NumElements(); j++)
		{
			H_QuadContour* pContour = glyphs[j].GetContour(i);
			if (pContour)
			{
				contours.Add(pContour);
			}
		}

		if (m_Verbose) printf("Harmonizing contour %d\n", i);
		bool contourMatch = MatchPoints(contours, i);
		if (false == contourMatch)
			match = false;
	}

    return match;
}

void H_GlyphHarmonizer::SetDebugLevel(int level)
{
	m_DebugLevel = level;
}

bool H_GlyphHarmonizer::MatchPoints(H_ArrayList<H_QuadContour*>& contours, int contourNumber)
{
	bool matched = true;

	if (m_Verbose) printf("Contour Number: %d\r", contourNumber);

	//CheckPointers(contours);

	if (m_DebugLevel >= 0)	{ MatchContourExtrema	(contours); }; //CheckPointers(contours);}
	if (m_DebugLevel >= 1)	{ MatchSectionExtrema	(contours);	}; //CheckPointers(contours); }
	if (m_DebugLevel >= 2)	{ MatchSectionOnCurve 	(contours);	}; //CheckPointers(contours); }

	//if (m_DebugLevel >= 3)	{ MatchFlatExtrema		(contours);	}; //CheckPointers(contours); }

	if (m_DebugLevel >= 5)	{ RemoveDegeneratePoints(contours);	}; //CheckPointers(contours); }
	if (m_DebugLevel >= 6)	{ CheckBeziers			(contours);	}; //CheckPointers(contours); }
	if (m_DebugLevel >= 7)	{ CollapseStartLines	(contours);	}; //CheckPointers(contours); }
	if (m_DebugLevel >= 8)	{ CollapseEndLines		(contours);	}; //CheckPointers(contours); }
	if (m_DebugLevel >= 9)	{ ReflowInflections		(contours);	}; //CheckPointers(contours); }
	if (m_DebugLevel >= 10)	{ ReflowSmoothPoints	(contours);	}; //CheckPointers(contours); }
	if (m_DebugLevel >= 11)	{ SplitAtKinkPoints		(contours); }; //CheckPointers(contours); }// Splits at on curve points (not just kinks).
	if (m_DebugLevel >= 12)  { MatchSingleBezier		(contours);	}; //CheckPointers(contours); }
	if (m_DebugLevel >= 13) { MatchLineSegment		(contours);	}; //CheckPointers(contours); }
	if (m_DebugLevel >= 14) { MatchBezierToBezier	(contours);	}; //CheckPointers(contours); }

	MakePoints			(contours);

	matched = CheckMatch(contours);

	if (matched)
	{
		if (m_Verbose) printf("Contours Matched.\n");
	}
	else
	{
		if (m_Verbose) printf("Failed to match contours!\n");
	}

	return matched;
}

bool H_GlyphHarmonizer::AreValid(H_ArrayList<H_QuadContour*>& contours)
{
	bool areValid = true;

	for (int i = 0; i < contours.NumElements(); i++)
	{
		areValid &= contours[i]->IsValid();
	}

	return areValid;
}

bool H_GlyphHarmonizer::CheckMatch(H_ArrayList<H_QuadContour*>& contours)
{
	bool matches = true;

	for (int i = 0; i < contours.NumElements(); i++)
	{
		int next = i + 1;
		if (next >= contours.NumElements())
		{
			next = 0;
		}

		if (false == contours[i]->Matches(contours[next]))
		{
			matches = false;
		}
	}


	return matches;
}

bool H_GlyphHarmonizer::CountToEnd(H_ArrayList<H_ListElem<H_OutlineSection>* >& elementPointers)
{
	bool samePointers = true;

	H_ArrayList<int> numSections;

	for (int i = 0; i < elementPointers.NumElements(); i++)
	{
		H_ListElem<H_OutlineSection>* pSection = elementPointers[i];

		int count = 0;

		while (pSection)
		{
			count++;
			pSection = pSection->m_Next;
		}

		numSections.Add(count);
	}

	if (false == numSections.AllSame())
	{
		samePointers = false;
	}

	return samePointers;
}

bool H_GlyphHarmonizer::CheckPointers(H_ArrayList<H_QuadContour*>& contours)
{
	bool samePointers = true;

	H_ArrayList<int> numSections;

	for (int i = 0; i < contours.NumElements(); i++)
	{
		H_LinkedList<H_OutlineSection>* pOutlineSections = contours[i]->GetOutlineSections();
		H_ListElem<H_OutlineSection>* pSection = pOutlineSections->GetFirstElement();

		int count = 0;

		while (pSection)
		{
			count++;

			if (false == pSection->m_Data.IsValid())
			{
			//	printf("Invalid Section.\n");
			}

			pSection = pOutlineSections->GetNextElement();
		}

		numSections.Add(count);
	}

	if (false == numSections.AllSame())
	{
		samePointers = false;
	}

	return samePointers;
}

void H_GlyphHarmonizer::MatchSectionExtrema(H_ArrayList<H_QuadContour*>& contours)
{
	// Create array of all first elements;
	H_ArrayList<H_ListElem<H_OutlineSection>* > elementPointers;

	for (int i = 0; i < contours.NumElements(); i++)
	{
		H_LinkedList<H_OutlineSection>* pOutlineSections = contours[i]->GetOutlineSections();
		elementPointers.Add(pOutlineSections->GetFirstElement());
	}

	while (elementPointers[0]) // Should all have the same number of sections. Assert?
	{
		H_ArrayList<H_OutlineSection*> sectionPointers;

		for (int i = 0; i < contours.NumElements(); i++)
		{
			sectionPointers.Add(&elementPointers[i]->m_Data);
		}

		// Create arrays with diffe
		H_ArrayList<int> numExtrema;

		for (int i = 0; i < contours.NumElements(); i++)
		{
			H_OutlineSection* pCurrentSection = sectionPointers[i];
			numExtrema.Add(pCurrentSection->NumExtrema());
		}

		H_ArrayList<int> sortedIndeces;
		numExtrema.SortedOrder(sortedIndeces);

		int smallestIndex = sortedIndeces[0];

		// Do they all have unmatched extrema.
		if (numExtrema[smallestIndex] > 0)
		{
			if (m_Verbose) printf("Matching section extrema\n");

			H_ArrayList<int> splitIndices;

			for (int j = 0; j < contours.NumElements(); j++)
			{
				int splitIndex;

				if (j != smallestIndex)
				{
					splitIndex = sectionPointers[smallestIndex]->BestMatch(sectionPointers[j]);
				}
				else
				{
					splitIndex = sectionPointers[j]->FirstExtrema();
				}

				splitIndices.Add(splitIndex);
			}

			int noIndex = -1;

			if (-1 == splitIndices.Find(noIndex))
			{
				for (int k = 0; k < contours.NumElements(); k++)
				{
					elementPointers[k] = contours[k]->SplitAt(*sectionPointers[k], splitIndices[k]);
				}
			}
		}

		for (int i = 0; i < elementPointers.NumElements(); i++)
		{
			elementPointers[i] = elementPointers[i]->m_Next;
		}
	}
}

void H_GlyphHarmonizer::MatchSectionOnCurve(H_ArrayList<H_QuadContour*>& contours)
{
	// Create array of all first elements;
	H_ArrayList<H_ListElem<H_OutlineSection>* > elementPointers;

	for (int i = 0; i < contours.NumElements(); i++)
	{
		H_LinkedList<H_OutlineSection>* pOutlineSections = contours[i]->GetOutlineSections();
		elementPointers.Add(pOutlineSections->GetFirstElement());
	}

	while (elementPointers[0]) // Should all have the same number of sections. Assert?
	{
		H_ArrayList<H_OutlineSection*> sectionPointers;

		for (int i = 0; i < contours.NumElements(); i++)
		{
			sectionPointers.Add(&elementPointers[i]->m_Data);
		}

		// Create arrays with diffe
		H_ArrayList<int> numOnCurve;

		for (int i = 0; i < contours.NumElements(); i++)
		{
			H_OutlineSection* pCurrentSection = sectionPointers[i];
			numOnCurve.Add(pCurrentSection->NumOnCurve());
		}

		H_ArrayList<int> sortedIndeces;
		numOnCurve.SortedOrder(sortedIndeces);

		int smallestIndex = sortedIndeces[0];

		// Do they all have unmatched extrema.
		if (numOnCurve[smallestIndex] > 0)
		{
			if (m_Verbose) printf("Matching section on curve\n");

			H_ArrayList<int> splitIndices;

			for (int j = 0; j < contours.NumElements(); j++)
			{
				int splitIndex;

				if (j != smallestIndex)
				{
					splitIndex = sectionPointers[smallestIndex]->BestOnCurveMatch(sectionPointers[j]);
				}
				else
				{
					splitIndex = sectionPointers[j]->FirstOnCurve();
				}

				splitIndices.Add(splitIndex);
			}

			int noIndex = -1;

			// If they match all the way accross:
			if (-1 == splitIndices.Find(noIndex))
			{
				for (int k = 0; k < contours.NumElements(); k++)
				{
					elementPointers[k] = contours[k]->SplitAt(*sectionPointers[k], splitIndices[k]);
				}
			}
		}

		for (int i = 0; i < elementPointers.NumElements(); i++)
		{
			elementPointers[i] = elementPointers[i]->m_Next;
		}
	}
}



void H_GlyphHarmonizer::MatchFlatExtrema(H_ArrayList<H_QuadContour*>& contours)
{
	// Create array of all first elements;
	H_ArrayList<H_ListElem<H_OutlineSection>* > elementPointers;

	for (int i = 0; i < contours.NumElements(); i++)
	{
		H_LinkedList<H_OutlineSection>* pOutlineSections = contours[i]->GetOutlineSections();
		elementPointers.Add(pOutlineSections->GetFirstElement());
	}

	while (elementPointers[0]) // Should all have the same number of sections. Assert?
	{
		H_ArrayList<H_OutlineSection*> sectionPointers;

		for (int i = 0; i < contours.NumElements(); i++)
		{
			sectionPointers.Add(&elementPointers[i]->m_Data);
		}

		// Create arrays with diffe
		H_ArrayList<H_OutlineSection*> flatAtEndList;
		H_ArrayList<int>			   floatAtEndListIndeces;

		H_ArrayList<H_OutlineSection*> notFlatAtEndList;
		H_ArrayList<int>			   notFlatAtEndListIndeces;

		for (int i = 0; i < contours.NumElements(); i++)
		{
			H_OutlineSection* pCurrentSection = sectionPointers[i];

			if (pCurrentSection->FlatExtremaAtEnd())
			{
				flatAtEndList.Add(pCurrentSection);
				floatAtEndListIndeces.Add(i);
			}
			else
			{
				notFlatAtEndList.Add(pCurrentSection);
				notFlatAtEndListIndeces.Add(i);
			}
		}

		if (flatAtEndList.NumElements() > 0)// && notFlatAtEndList.NumElements() > 0)
		{
			if (m_Verbose) printf("Flat extrema.\n");
			printf("Flat extrema at end.\n");
			for (int j = 0; j < flatAtEndList.NumElements(); j++)
			{
				int index = floatAtEndListIndeces[j];
				H_ListElem<H_OutlineSection>* pElem = contours[index]->SplitAt(*flatAtEndList[j], flatAtEndList[j]->NumPoints() - 2);
				if (pElem == NULL)
					printf("null split.");
				if (pElem->m_Next == NULL)
					printf("null split2.");
				elementPointers[index] = pElem;
			}

			for (int j = 0; j < notFlatAtEndList.NumElements(); j++)
			{
				int index = notFlatAtEndListIndeces[j];
				H_ListElem<H_OutlineSection>* pElem= contours[index]->AddEndLine(*notFlatAtEndList[j]);
				if (pElem == NULL)
					printf("null endLine.");
				if (pElem->m_Next == NULL)
					printf("null split2.");
				elementPointers[index] = pElem;
			}

			for (int i = 0; i < elementPointers.NumElements(); i++)
			{
				elementPointers[i] = elementPointers[i]->m_Next;
			}
		}

		if (false == CheckPointers(contours))
			printf("Bad pointers.");

		for (int i = 0; i < elementPointers.NumElements(); i++)
		{
			elementPointers[i] = elementPointers[i]->m_Next;
		}
	}
}

void H_GlyphHarmonizer::RemoveDegeneratePoints(H_ArrayList<H_QuadContour*>& contours)
{
	// Create array of all first elements;
	H_ArrayList<H_ListElem<H_OutlineSection>* > elementPointers;

	for (int i = 0; i < contours.NumElements(); i++)
	{
		H_LinkedList<H_OutlineSection>* pOutlineSections = contours[i]->GetOutlineSections();
		elementPointers.Add(pOutlineSections->GetFirstElement());
	}

	while (elementPointers[0]) // Should all have the same number of sections. Assert?
	{
		H_ArrayList<H_OutlineSection*> sectionPointers;

		for (int i = 0; i < contours.NumElements(); i++)
		{
			sectionPointers.Add(&elementPointers[i]->m_Data);
		}

		for (int i = 0; i < contours.NumElements(); i++)
		{
			H_OutlineSection* pCurrentSection = sectionPointers[i];

			if (pCurrentSection->DegenerateStartLine())
			{
				if (m_Verbose) printf("Removing degenerate start line. \n");
				pCurrentSection->RemoveStartLine();
			}

			if (pCurrentSection->DegenerateEndLine())
			{
				if (m_Verbose) printf("Removing degenerate end line. \n");
				pCurrentSection->RemoveEndLine();
			}

			if (pCurrentSection->IsLinear())
			{
				if (m_Verbose) printf("Removing Linear Bezier. \n");
				pCurrentSection->RemoveLinearBezier();
			}
		}

		for (int i = 0; i < elementPointers.NumElements(); i++)
		{
			elementPointers[i] = elementPointers[i]->m_Next;
		}
	}
}


void H_GlyphHarmonizer::CheckBeziers(H_ArrayList<H_QuadContour*>& contours)
{
	// Create array of all first elements;
	H_ArrayList<H_ListElem<H_OutlineSection>* > elementPointers;

	for (int i = 0; i < contours.NumElements(); i++)
	{
		H_LinkedList<H_OutlineSection>* pOutlineSections = contours[i]->GetOutlineSections();
		elementPointers.Add(pOutlineSections->GetFirstElement());
	}

	while (elementPointers[0]) // Should all have the same number of sections. Assert?
	{
		H_ArrayList<H_OutlineSection*> sectionPointers;

		for (int i = 0; i < contours.NumElements(); i++)
		{
			sectionPointers.Add(&elementPointers[i]->m_Data);
		}

		H_ArrayList<H_OutlineSection*> offCurveOnlyList;
		H_ArrayList<int>			   offCurveOnlyIndeces;
		H_ArrayList<int>               numOffCurveList;

		int largest = H_MIN_INT;

		for (int i = 0; i < contours.NumElements(); i++)
		{
			H_OutlineSection* pCurrentSection = sectionPointers[i];

			if (pCurrentSection->OffCurveOnly())
			{
				offCurveOnlyList.Add(pCurrentSection);
				offCurveOnlyIndeces.Add(i);

				int numOffCurve = pCurrentSection->NumOffCurve();

				if (numOffCurve > largest)
				{
					largest = numOffCurve;
				}

				numOffCurveList.Add(numOffCurve);
			}
		}

		int numOffCurveOnly = offCurveOnlyList.NumElements();

		int reflowLargest = H_MIN_INT;

		// Reflow hoping for less points.
		for (int j = 0; j < numOffCurveOnly; j++)
		{
			int numPoints = LowestPoints(offCurveOnlyList[j]);

			if (numPoints > reflowLargest)
			{
				reflowLargest = numPoints;
			}
		}

		if (reflowLargest < largest)
		{
			for (int j = 0; j < numOffCurveOnly; j++)
			{
				int numPoints = offCurveOnlyList[j]->NumOffCurve();

				if (numPoints > reflowLargest)
				{
					ReflowBezier(offCurveOnlyList[j], H_EQUALS, reflowLargest);
				}
			}
		}

		for (int i = 0; i < elementPointers.NumElements(); i++)
		{
			elementPointers[i] = elementPointers[i]->m_Next;
		}
	}
}


void H_GlyphHarmonizer::CollapseStartLines(H_ArrayList<H_QuadContour*>& contours)
{
	// Create array of all first elements;
	H_ArrayList<H_ListElem<H_OutlineSection>* > elementPointers;

	for (int i = 0; i < contours.NumElements(); i++)
	{
		H_LinkedList<H_OutlineSection>* pOutlineSections = contours[i]->GetOutlineSections();
		elementPointers.Add(pOutlineSections->GetFirstElement());
	}

	while (elementPointers[0]) // Should all have the same number of sections. Assert?
	{
		H_ArrayList<H_OutlineSection*> sectionPointers;

		for (int i = 0; i < contours.NumElements(); i++)
		{
			sectionPointers.Add(&elementPointers[i]->m_Data);
		}

		// Create arrays with diffe
		H_ArrayList<H_OutlineSection*> lineAtStartList;
		H_ArrayList<int>			   lineAtStartListIndeces;

		H_ArrayList<H_OutlineSection*> noLineAtStartList;
		H_ArrayList<int>			   noLineAtStartListIndeces;

		for (int i = 0; i < contours.NumElements(); i++)
		{
			H_OutlineSection* pCurrentSection = sectionPointers[i];

			if (pCurrentSection->SmallLineAtStart())
			{
				lineAtStartList.Add(pCurrentSection);
				lineAtStartListIndeces.Add(i);
			}
			else
			{
				noLineAtStartList.Add(pCurrentSection);
				noLineAtStartListIndeces.Add(i);
			}
		}

		if (lineAtStartList.NumElements() > 0)
		{
			if (m_Verbose) printf("Adding Start Line.\n");
			for (int j = 0; j < lineAtStartList.NumElements(); j++)
			{
				int index = lineAtStartListIndeces[j];
				elementPointers[index] = contours[index]->SplitAt(*lineAtStartList[j], 1);
			}

			for (int j = 0; j < noLineAtStartList.NumElements(); j++)
			{
				int index = noLineAtStartListIndeces[j];
				elementPointers[index] = contours[index]->AddStartLine(*noLineAtStartList[j]);
			}
		}
		else
		{
			for (int i = 0; i < elementPointers.NumElements(); i++)
			{
				elementPointers[i] = elementPointers[i]->m_Next;
			}
		}
	}
}

void H_GlyphHarmonizer::CollapseEndLines(H_ArrayList<H_QuadContour*>& contours)
{
	// Create array of all first elements;
	H_ArrayList<H_ListElem<H_OutlineSection>* > elementPointers;

	for (int i = 0; i < contours.NumElements(); i++)
	{
		H_LinkedList<H_OutlineSection>* pOutlineSections = contours[i]->GetOutlineSections();
		elementPointers.Add(pOutlineSections->GetFirstElement());
	}

	while (elementPointers[0]) // Should all have the same number of sections. Assert?
	{
		H_ArrayList<H_OutlineSection*> sectionPointers;

		for (int i = 0; i < contours.NumElements(); i++)
		{
			sectionPointers.Add(&elementPointers[i]->m_Data);
		}

		// Create arrays with diffe
		H_ArrayList<H_OutlineSection*> lineAtEndList;
		H_ArrayList<int>			   lineAtEndListIndeces;

		H_ArrayList<H_OutlineSection*> noLineAtEndList;
		H_ArrayList<int>			   noLineAtEndListIndeces;

		for (int i = 0; i < contours.NumElements(); i++)
		{
			H_OutlineSection* pCurrentSection = sectionPointers[i];

			if (pCurrentSection->SmallLineAtEnd())
			{
				lineAtEndList.Add(pCurrentSection);
				lineAtEndListIndeces.Add(i);
			}
			else
			{
				noLineAtEndList.Add(pCurrentSection);
				noLineAtEndListIndeces.Add(i);
			}
		}

		if (lineAtEndList.NumElements() > 0)
		{
			if (m_Verbose) printf("Adding End Line.\n");
			for (int j = 0; j < lineAtEndList.NumElements(); j++)
			{
				int index = lineAtEndListIndeces[j];
				elementPointers[index] = contours[index]->SplitAt(*lineAtEndList[j], lineAtEndList[j]->NumPoints() - 2);
			}
			 
			for (int j = 0; j < noLineAtEndList.NumElements(); j++)
			{
				int index = noLineAtEndListIndeces[j];
				elementPointers[index] = contours[index]->AddEndLine(*noLineAtEndList[j]);
			}
		}
		else
		{
			for (int i = 0; i < elementPointers.NumElements(); i++)
			{
				elementPointers[i] = elementPointers[i]->m_Next;
			}
		}
	}
}


void H_GlyphHarmonizer::SplitAtKinks(H_ArrayList<H_QuadContour*>& contours)
{
	// Create array of all first elements;
	H_ArrayList<H_ListElem<H_OutlineSection>* > elementPointers;

	for (int i = 0; i < contours.NumElements(); i++)
	{
		H_LinkedList<H_OutlineSection>* pOutlineSections = contours[i]->GetOutlineSections();
		elementPointers.Add(pOutlineSections->GetFirstElement());
	}

	while (elementPointers[0]) // Should all have the same number of sections. Assert?
	{
		H_ArrayList<H_OutlineSection*> sectionPointers;

		for (int i = 0; i < contours.NumElements(); i++)
		{
			sectionPointers.Add(&elementPointers[i]->m_Data);
		}

		// Create arrays with diffe
		H_ArrayList<H_OutlineSection*> implicitOnlyList;
		H_ArrayList<int>			   implicitOnlyIndeces;

		H_ArrayList<H_OutlineSection*> onCurveList;
		H_ArrayList<int>			   onCurveIndeces;

		H_ArrayList<H_OutlineSection*> lineList;
		H_ArrayList<int>               lineIndeces;

		for (int i = 0; i < contours.NumElements(); i++)
		{
			H_OutlineSection* pCurrentSection = sectionPointers[i];

			//if (pCurrentSection->ImplicitOnly())
			if (pCurrentSection->OffCurveOnly())
			{
				implicitOnlyList.Add(pCurrentSection);
				implicitOnlyIndeces.Add(i);
			}
			else if (pCurrentSection->LineSegment())
			{
				lineList.Add(pCurrentSection);
				lineIndeces.Add(i);
			}
			else if (pCurrentSection->NumOnCurve() > 0)
			{
				onCurveList.Add(pCurrentSection);
				onCurveIndeces.Add(i);
			}
		}

		int numOnCurve  = onCurveList		.NumElements();
		int numImplicit = implicitOnlyList	.NumElements();
		int numLines    = lineList			.NumElements();

		if (numImplicit > 0 && numOnCurve > 0)
		{
			float totalDistance = 0.0f;

			for (int j = 0; j < numOnCurve; j++)
			{
				totalDistance += onCurveList[j]->PathLengthToFirstOnCurve();
			}
			
			float averageDistance = totalDistance / numOnCurve;

			if (averageDistance > 0.000001f) // Sometimes we've added a duplicate point to match to small line segments.
			{
				if (m_Verbose) printf("Reflowing Kink Point\n");
				for (int j = 0; j < numImplicit; j++)
				{
					int index = implicitOnlyIndeces[j];
					elementPointers[index] = contours[index]->SplitBezierSection(*implicitOnlyList[j], averageDistance);
				}

				for (int j = 0; j < numLines; j++)
				{
					int index = lineIndeces[j];
					elementPointers[index] = contours[index]->SplitLineSegment(*lineList[j], averageDistance);
				}

				for (int j = 0; j < numOnCurve; j++)
				{
					int index = onCurveIndeces[j];
					elementPointers[index] = contours[index]->SplitAt(*onCurveList[j], onCurveList[j]->FirstOnCurve());
				}
			}
		}

		for (int i = 0; i < elementPointers.NumElements(); i++)
		{
			elementPointers[i] = elementPointers[i]->m_Next;
		}
	}
}

void H_GlyphHarmonizer::ReflowSmoothPoints(H_ArrayList<H_QuadContour*>& contours)
{
	// These don't depend on each other, loop over everyone and reflow away any 'smooth' points.
	for (int i = 0; i < contours.NumElements(); i++)
	{
		H_LinkedList<H_OutlineSection>* pOutlineSections = contours[i]->GetOutlineSections();

		H_ListElem<H_OutlineSection>* pCurrent = pOutlineSections->GetFirstElement();

		while (pCurrent)
		{
			H_OutlineSection* pCurrentSection = &pCurrent->m_Data;

			if (pCurrentSection->SmoothPointsOnly())
			{
				if (m_Verbose) printf("Reflowed smooth point\n");
				ReflowBezier(pCurrentSection, H_ANY);
			}
			else if (pCurrentSection->LineAtStart()) // Reflow the portions of the section that are bezier.
			{
				H_OutlineSection bezierPart; // Create a temp section with no line.
				
				for (int j = 1; j < pCurrentSection->NumPoints(); j++)
				{
					bezierPart.AddPoint(pCurrentSection->GetPoint(j));
				}

				if (bezierPart.SmoothPointsOnly())
				{
					if (ReflowBezier(&bezierPart, H_ANY))
					{
						H_OutlineSection temp;
						temp.AddPoint(pCurrentSection->GetPoint(0));

						for (int j = 0; j < bezierPart.NumPoints(); j++)
						{
							temp.AddPoint(bezierPart.GetPoint(j));
						}

						*pCurrentSection = temp;
					}
				}
			}
			else if (pCurrentSection->LineAtEnd())
			{
				H_OutlineSection bezierPart; // Create a temp section with no line.
				
				int lastIndex = pCurrentSection->NumPoints() - 1;
				for (int j = 0; j < lastIndex; j++)
				{
					bezierPart.AddPoint(pCurrentSection->GetPoint(j));
				}

				if (bezierPart.SmoothPointsOnly())
				{
					if (ReflowBezier(&bezierPart, H_ANY))
					{
						H_OutlineSection temp;

						for (int j = 0; j < bezierPart.NumPoints(); j++)
						{
							temp.AddPoint(bezierPart.GetPoint(j));
						}

						temp.AddPoint(pCurrentSection->GetPoint(lastIndex));

						*pCurrentSection = temp;
					}
				}
			}

			pCurrent = pCurrent->m_Next;
		}
	}
}


void H_GlyphHarmonizer::ReflowInflections(H_ArrayList<H_QuadContour*>& contours)
{
	// Create array of all first elements;
	H_ArrayList<H_ListElem<H_OutlineSection>* > elementPointers;

	for (int i = 0; i < contours.NumElements(); i++)
	{
		H_LinkedList<H_OutlineSection>* pOutlineSections = contours[i]->GetOutlineSections();
		elementPointers.Add(pOutlineSections->GetFirstElement());
	}

	while (elementPointers[0]) // Should all have the same number of sections. Assert?
	{
		H_ArrayList<H_OutlineSection*> sectionPointers;

		int numContours = contours.NumElements();

		for (int i = 0; i < numContours; i++)
		{
			sectionPointers.Add(&elementPointers[i]->m_Data);
		}

		// Create arrays with diffe
		H_ArrayList<H_OutlineSection*> inflectionList;
		H_ArrayList<int>			   inflectionIndices;

		H_ArrayList<H_OutlineSection*> othersList;
		H_ArrayList<int>			   othersIndices;

		for (int i = 0; i < numContours; i++)
		{
			H_OutlineSection* pCurrentSection = sectionPointers[i];

			if (pCurrentSection->HasInflection())
			{
				inflectionList.Add(pCurrentSection);
				inflectionIndices.Add(i);
			}
		}

		int numInflections = inflectionList.NumElements();

		if (numInflections == numContours)
		{
			if (m_Verbose) printf("Split Inflection.\n");

			for (int i = 0; i < numInflections; i++)
			{
				if (inflectionList[i]->MiddleLine())
				{
					inflectionList[i]->ReflowLineInflection();
				}
				else
				{
					ReflowBezier(inflectionList[i], H_ANY);
				}
				
			}
		}
		for (int i = 0; i < elementPointers.NumElements(); i++)
		{
			elementPointers[i] = elementPointers[i]->m_Next;
		}
	}
}



void H_GlyphHarmonizer::SplitAtKinkPoints(H_ArrayList<H_QuadContour*>& contours)
{
	// Create array of all first elements;
	H_ArrayList<H_ListElem<H_OutlineSection>* > elementPointers;

	for (int i = 0; i < contours.NumElements(); i++)
	{
		H_LinkedList<H_OutlineSection>* pOutlineSections = contours[i]->GetOutlineSections();
		elementPointers.Add(pOutlineSections->GetFirstElement());
	}

	while (elementPointers[0]) // Should all have the same number of sections. Assert?
	{
 		H_ArrayList<H_OutlineSection*> sectionPointers;

		for (int i = 0; i < contours.NumElements(); i++)
		{
			sectionPointers.Add(&elementPointers[i]->m_Data);
		}

		// Create arrays with diffe
		H_ArrayList<H_OutlineSection*> implicitOnlyList;
		H_ArrayList<int>			   implicitOnlyIndeces;

		H_ArrayList<H_OutlineSection*> onCurveList;
		H_ArrayList<int>			   onCurveIndeces;

		H_ArrayList<H_OutlineSection*> lineList;
		H_ArrayList<int>               lineIndeces;


		for (int i = 0; i < contours.NumElements(); i++)
		{
			H_OutlineSection* pCurrentSection = sectionPointers[i];

			if (pCurrentSection->OffCurveOnly())
			{
				implicitOnlyList.Add(pCurrentSection);
				implicitOnlyIndeces.Add(i);
			}
			else if (pCurrentSection->LineSegment())
			{
				lineList.Add(pCurrentSection);
				lineIndeces.Add(i);
			}
			else if (pCurrentSection->NumOnCurve() > 0)
			{
				onCurveList.Add(pCurrentSection);
				onCurveIndeces.Add(i);
			}
		}

		int numOnCurve  = onCurveList		.NumElements();
		int numImplicit = implicitOnlyList	.NumElements();
		int numLines    = lineList			.NumElements();

		int total = numOnCurve + numImplicit + numLines;

		if (numImplicit > 0 && numOnCurve > 0)
		{
			if (total == contours.NumElements())
			{
				float totalDistance = 0.0f;

				for (int j = 0; j < numOnCurve; j++)
				{
					totalDistance += onCurveList[j]->PathLengthToFirstOnCurve();
				}

				float averageDistance = totalDistance / numOnCurve;

				if (averageDistance > 0.000001f) // Sometimes we've added a duplicate point to match to small line segments.
				{
					if (m_Verbose) printf("Reflowing Kink Point\n");
					for (int j = 0; j < numImplicit; j++)
					{
						int index = implicitOnlyIndeces[j];
						elementPointers[index] = contours[index]->SplitBezierSection(*implicitOnlyList[j], averageDistance);
					}

					for (int j = 0; j < numLines; j++)
					{
						int index = lineIndeces[j];
						elementPointers[index] = contours[index]->SplitLineSegment(*lineList[j], averageDistance);
					}

					for (int j = 0; j < numOnCurve; j++)
					{
						int index = onCurveIndeces[j];
						elementPointers[index] = contours[index]->SplitAt(*onCurveList[j], onCurveList[j]->FirstOnCurve());
					}
				}
			}
		}

		for (int i = 0; i < elementPointers.NumElements(); i++)
		{
			elementPointers[i] = elementPointers[i]->m_Next;
		}
	}
}


void H_GlyphHarmonizer::MatchSingleBezier(H_ArrayList<H_QuadContour*>& contours)
{
	// Create array of all first elements;
	H_ArrayList<H_ListElem<H_OutlineSection>* > elementPointers;

	for (int i = 0; i < contours.NumElements(); i++)
	{
		H_LinkedList<H_OutlineSection>* pOutlineSections = contours[i]->GetOutlineSections();
		elementPointers.Add(pOutlineSections->GetFirstElement());
	}

	while (elementPointers[0]) // Should all have the same number of sections. Assert?
	{
		H_ArrayList<H_OutlineSection*> sectionPointers;

		for (int i = 0; i < contours.NumElements(); i++)
		{
			sectionPointers.Add(&elementPointers[i]->m_Data);
		}

		// Create arrays with diffe
		H_ArrayList<H_OutlineSection*> singleBezierList;
		H_ArrayList<int>			   singleBezierIndeces;

		H_ArrayList<H_OutlineSection*> onCurveList;
		H_ArrayList<int>			   onCurveIndeces;

		bool allSingleOrOnCurve = true;

		for (int i = 0; i < contours.NumElements(); i++)
		{
			H_OutlineSection* pCurrentSection = sectionPointers[i];

			if (pCurrentSection->SingleBezier())
			{
				singleBezierList.Add(pCurrentSection);
				singleBezierIndeces.Add(i);
			}
			else if (pCurrentSection->NumOnCurve() > 0)
			{
				onCurveList.Add(pCurrentSection);
				onCurveIndeces.Add(i);
			}
			else
			{
				allSingleOrOnCurve = false;
			}
		}

		int curveSections = onCurveList.NumElements();
		int bezierSections = singleBezierList.NumElements();

		if (true == allSingleOrOnCurve && curveSections > 0 && bezierSections > 0)
		{ 
			if (m_Verbose) printf("Matching single bezier.\n");

			float totalDistance = 0.0f;

			for (int j = 0; j < curveSections; j++)
			{
				totalDistance += onCurveList[j]->PathLengthToFirstOnCurve();
			}
			
			float averageDistance = totalDistance / curveSections;

			for (int j = 0; j < curveSections; j++)
			{
				int index = onCurveIndeces[j];
				int splitIndex = onCurveList[j]->FirstOnCurve();
				elementPointers[index] = contours[index]->SplitAt(*onCurveList[j], splitIndex);
			}

			for (int j = 0; j < bezierSections; j++)
			{
				int index = singleBezierIndeces[j];
				elementPointers[index] = contours[index]->SplitSingleBezier(*singleBezierList[j], averageDistance);
			}
		}
		else
		{
			for (int i = 0; i < elementPointers.NumElements(); i++)
			{
				elementPointers[i] = elementPointers[i]->m_Next;
			}
		}
	}
}

void H_GlyphHarmonizer::MatchLineSegment(H_ArrayList<H_QuadContour*>& contours)
{
	// Create array of all first elements;
	H_ArrayList<H_ListElem<H_OutlineSection>* > elementPointers;

	for (int i = 0; i < contours.NumElements(); i++)
	{
		H_LinkedList<H_OutlineSection>* pOutlineSections = contours[i]->GetOutlineSections();
		elementPointers.Add(pOutlineSections->GetFirstElement());
	}

	while (elementPointers[0]) // Should all have the same number of sections. Assert?
	{
		H_ArrayList<H_OutlineSection*> sectionPointers;

		for (int i = 0; i < contours.NumElements(); i++)
		{
			sectionPointers.Add(&elementPointers[i]->m_Data);
		}

		// Create arrays with diffe
		H_ArrayList<H_OutlineSection*> lineSegmentList;
		H_ArrayList<int>			   lineSegmentIndeces;

		H_ArrayList<H_OutlineSection*> onCurveList;
		H_ArrayList<int>			   onCurveIndeces;

		bool allLineOrOnCurve = true;

		for (int i = 0; i < contours.NumElements(); i++)
		{
			H_OutlineSection* pCurrentSection = sectionPointers[i];

			if (pCurrentSection->LineSegment())
			{
				lineSegmentList.Add(pCurrentSection);
				lineSegmentIndeces.Add(i);
			}
			else if (pCurrentSection->NumOnCurve() > 0)
			{
				onCurveList.Add(pCurrentSection);
				onCurveIndeces.Add(i);
			}
			else
			{
				allLineOrOnCurve = false;
			}
		}

		int curveSections = onCurveList.NumElements();
		int lineSections  =  lineSegmentList.NumElements();

		if (true == allLineOrOnCurve && curveSections > 0 && lineSections > 0)
		{ 
			if (m_Verbose) printf("Matching line section.\n");

			float totalDistance = 0.0f;

			for (int j = 0; j < curveSections; j++)
			{
				totalDistance += onCurveList[j]->PathLengthToFirstOnCurve();
			}
			
			float averageDistance = totalDistance / curveSections;

			for (int j = 0; j < curveSections; j++)
			{
				int index = onCurveIndeces[j];
				int splitIndex = onCurveList[j]->FirstOnCurve();
				elementPointers[index] = contours[index]->SplitAt(*onCurveList[j], splitIndex);
			}

			for (int j = 0; j < lineSections; j++)
			{
				int index = lineSegmentIndeces[j];
				elementPointers[index] = contours[index]->SplitLineSegment(*lineSegmentList[j], averageDistance);
			}
		}
		else
		{
			for (int i = 0; i < elementPointers.NumElements(); i++)
			{
				elementPointers[i] = elementPointers[i]->m_Next;
			}
		}
	}
}





void H_GlyphHarmonizer::MatchBezierToBezier(H_ArrayList<H_QuadContour*>& contours)
{
	// Create array of all first elements;
	H_ArrayList<H_ListElem<H_OutlineSection>* > elementPointers;

	for (int i = 0; i < contours.NumElements(); i++)
	{
		H_LinkedList<H_OutlineSection>* pOutlineSections = contours[i]->GetOutlineSections();
		elementPointers.Add(pOutlineSections->GetFirstElement());
	}

	while (elementPointers[0]) // Should all have the same number of sections. Assert?
	{

		H_ArrayList<H_OutlineSection*> sectionPointers;

		for (int i = 0; i < contours.NumElements(); i++)
		{
			sectionPointers.Add(&elementPointers[i]->m_Data);
		}

		// Create arrays with diffe

		H_ArrayList<H_OutlineSection*> lineSegmentList;
		H_ArrayList<int>			   lineSegmentIndeces;

		H_ArrayList<H_OutlineSection*> offCurveOnlyList;
		H_ArrayList<int>			   offCurveOnlyIndeces;

		for (int i = 0; i < contours.NumElements(); i++)
		{
			H_OutlineSection* pCurrentSection = sectionPointers[i];

			if (pCurrentSection->OffCurveOnly())
			{
				offCurveOnlyList.Add(pCurrentSection);
				offCurveOnlyIndeces.Add(i);
			}
			else if (pCurrentSection->LineSegment())
			{
				lineSegmentList.Add(pCurrentSection);
				lineSegmentIndeces.Add(i);
			}
		}

		int numOffCurveOnly = offCurveOnlyList.NumElements();
		int numLineSegments = lineSegmentList.NumElements();


		if ((numOffCurveOnly + numLineSegments == contours.NumElements()) &&
			(numOffCurveOnly > 0))
		{
			H_ArrayList<int> numOffCurveList;

			// Calc max points.
			int maxPoints = -1;

			for (int i = 0; i < numOffCurveOnly; i++)
			{
				int numOffCurve = offCurveOnlyList[i]->NumOffCurve();
				numOffCurveList.Add(numOffCurve);

				if (numOffCurve > maxPoints)
				{
					maxPoints = numOffCurve;
				}
			}

			// Add in zero for lines to force reflow with curves.
			for (int i = 0; i < numLineSegments; i++)
			{
				numOffCurveList.Add(0);
			}

			// Check for same number of points.
			if (false == numOffCurveList.AllSame())
			{
				if (m_Verbose) printf("Reflowing  Bezier(s) to %d\n", maxPoints);

				// ReflowBezier might be forced to use more than maxPoints.
				// this will make us go back over same set and reflow to new maxPoints.

				for (int j = 0; j < numOffCurveOnly; j++)
				{
					int numOff = offCurveOnlyList[j]->NumOffCurve();
					if (numOff != maxPoints)
					{
						bool success = ReflowBezier(offCurveOnlyList[j], H_EQUALS, maxPoints);
						(void)success;
						int numOff2 = offCurveOnlyList[j]->NumOffCurve();
						if (numOff2 != maxPoints)
						{
							ReflowBezier(offCurveOnlyList[j], H_EQUALS, maxPoints);

							if (offCurveOnlyList[j]->NumOffCurve() != maxPoints)
							{
								if (m_Verbose) printf("Failed to reflow.\n");
							}
						}
					}
				}

				for (int j = 0; j < numLineSegments; j++)
				{
					LineToBezier(lineSegmentList[j], maxPoints);
				}
			}
		}

		for (int i = 0; i < elementPointers.NumElements(); i++)
		{
			elementPointers[i] = elementPointers[i]->m_Next;
		}
	}
}

bool H_GlyphHarmonizer::CheckPoints(H_ArrayList<H_ContourPoint>& points)
{
	bool isValid = true;

	for (int i = 0; i < points.NumElements(); i++)
	{
		isValid &= points[i].IsValid();
	}

	return isValid;
}

int H_GlyphHarmonizer::LowestPoints(H_OutlineSection* pSection)
{
	int lowest = H_MAX_INT;
	H_ArrayList<H_ContourPoint> contourPoints;
	pSection->ResolvePoints(contourPoints);

	H_CompositQuadBezier compositBezier(contourPoints);

	H_ArrayList<H_ContourPoint> newPoints;

	if (true == compositBezier.Match(newPoints, lowest, 1.0f, H_ANY))
	{
		lowest = newPoints.NumElements() - 2;
	}

	return lowest;
}

bool H_GlyphHarmonizer::ReflowBezier(H_OutlineSection* pSection, H_Comparision comparision, int numPoints)
{
	bool success = false;

	if (	(numPoints == 1)				&&
			(comparision == H_LESS_THAN))
	{
		return false;
	}

	H_ArrayList<H_ContourPoint> contourPoints;
	pSection->ResolvePoints(contourPoints);

	H_CompositQuadBezier compositBezier(contourPoints);

	H_ArrayList<H_ContourPoint> newPoints;

	if (compositBezier.Match(newPoints, numPoints, 1.0f, comparision))
	{
		success = true;

		pSection->ClearPoints();

		for (int i = 0; i < newPoints.NumElements(); i++)
		{
			pSection->AddPoint(newPoints[i]);
		}
	}
	else
	{
		if (m_Verbose) printf("Failed to reflow %d points.\n", numPoints);
	}

	return success;
}

void H_GlyphHarmonizer::LineToBezier(H_OutlineSection* pSection, int numPoints)
{
	H_ContourPoint startPoint = pSection->GetPoint(0);
	H_ContourPoint endPoint = pSection->GetPoint(1);

	H_Vector2f start = startPoint.m_Point;
	H_Vector2f end   = endPoint.m_Point;

	float step = 1.0f / ((float) numPoints + 1.0f);
	float t    = step;

	pSection->ClearPoints();

	pSection->AddPoint(startPoint);

	for (int i = 0; i < numPoints; i++)
	{
		H_Vector2f position = H_Interpolate(start, end, t);
		H_ContourPoint newPoint;
		newPoint.m_Point = position;
		newPoint.m_Type = H_ContourPoint::OFF_CURVE;

		pSection->AddPoint(newPoint);
		t += step;
	}

	pSection->AddPoint(endPoint);
}


void H_GlyphHarmonizer::MatchContourExtrema(H_ArrayList<H_QuadContour*>& contours)
{
	// Array of matched indeces for each contour. N.B not same as in matchFirstPoint.
	H_ArrayList <H_ArrayList<int> > matches;

	// Initialize matches to have numcontours empty arrays.
	for (int i = 0; i < contours.NumElements(); i++)
	{
		H_ArrayList<int> emptyArray;
		matches.Add(emptyArray);
	}

	H_QuadContour* pFirstContour = contours.First();

	int otherIndex = -1;

	H_ContourPoint* pThisExtrema = pFirstContour->GetFirstExtrema();

	while (pThisExtrema)
	{
		int thisIndex = pThisExtrema->m_Index;

		H_ArrayList<int> match;

		match.Add(thisIndex);

		for (int i = 1; i < contours.NumElements(); i++)
		{
			H_QuadContour* pCurrentContour = contours[i];

			otherIndex = pCurrentContour->FindBestMatch(pThisExtrema);

			if (otherIndex >= 0)
			{
				H_ContourPoint& point = pCurrentContour->GetPoint(otherIndex);

				if (thisIndex == pFirstContour->FindBestMatch(&point))
				{
					match.Add(otherIndex);
				}
			}
		}

		if (match.NumElements() == contours.NumElements())
		{
			//	matches.Add(match);
			for (int j = 0; j < contours.NumElements(); j++)
			{
				matches[j].Add(match[j]);
			}
		}

		pThisExtrema = pFirstContour->GetNextExtrema(pThisExtrema);
	}


	// We now have a list of indeces of matched pairs for each contour.
	// Matched indeces may contain out of order indeces.
	// Find longest increasing subsequence for each and flip those
	// indeces positive.
	for (int i = 0; i < contours.NumElements(); i++)
	{
		H_ArrayList<int> orderIndeces;

		H_ArrayList<int>& currentArray = matches[i];

		currentArray.GetLongestIncreasingSubsequence(orderIndeces);

		// InOrder indeces get flipped negative.
		for (int j = 0; j < orderIndeces.NumElements(); j++)
		{
			currentArray[orderIndeces[j]] *= -1;
		}
	}

	int numMatches = matches[0].NumElements();
	int numContours = contours.NumElements();

	for (int i = 0; i < numMatches; i++)
	{
		bool valid = true;

		// Check for any invalid indeces in this set.
		for (int j = 0; j < numContours; j++)
		{
			if (matches[j][i] > 0)
			{
				valid = false;
				break;
			}
		}

		// Invalidate accross the set. (> 0 is invalid).
		if (false == valid)
		{
			for (int j = 0; j < numContours; j++)
			{
				matches[j][i] = 1;
			}
		}
	}
	
	for (int i = 0; i < contours.NumElements(); i++)
	{
		H_ArrayList<int>& currentIndeces = matches[i];
		H_QuadContour* pCurrentContour = contours[i];

		pCurrentContour->ClearMatchedExtrema();

		for (int j = 0; j < currentIndeces.NumElements(); j++)
		{
			int currentIndex = currentIndeces[j];
			
			if (currentIndex <= 0)
			{
				pCurrentContour->AddMatchedExtrema(-currentIndex);
			}
		}
		pCurrentContour->CreateSections();
	}
}

void H_GlyphHarmonizer::LabelIndices(H_ArrayList<H_QuadGlyph>& glyphs)
{
	for (int i = 0; i < glyphs.NumElements(); i++)
	{
		glyphs[i].LabelIndices();
	}
}

void H_GlyphHarmonizer::MatchFirstPoints(H_ArrayList<H_QuadGlyph>& glyphs)
{
	if (glyphs.NumElements() > 0)
	{
		int numContours = glyphs[0].NumContours();

		for (int i = 0; i < numContours; i++)
		{
			H_ArrayList<H_QuadContour> contours;

			for (int j = 0; j < glyphs.NumElements(); j++)
			{
				H_QuadContour* pContour = glyphs[j].GetContour(i);
				if (pContour)
				{
					contours.Add(*pContour);
				}
			}
			H_ArrayList<int> firstPoints;
			MatchFirstPoints(contours, firstPoints);

			for (int j = 0; j < glyphs.NumElements(); j++)
			{
				H_QuadContour* pContour = glyphs[j].GetContour(i);

				if (pContour)
				{
					pContour->SetFirstPoint(firstPoints[j]);
				}
			}
		}
	}
}

void H_GlyphHarmonizer::MatchFirstPoints(H_ArrayList<H_QuadContour>& contours, H_ArrayList<int>& firstPoints)
{
	H_ArrayList <H_ArrayList<int> > matches;

	H_QuadContour& firstContour = contours.First();

	int otherIndex = -1;

	H_ContourPoint* pThisExtrema = firstContour.GetFirstExtrema();

	while (pThisExtrema)
	{
		int thisIndex = pThisExtrema->m_Index;

		H_ArrayList<int> match;

		match.Add(thisIndex);

		for (int i = 1; i < contours.NumElements(); i++)
		{
			H_QuadContour& currentContour = contours[i];

			otherIndex = currentContour.FindBestMatch(pThisExtrema, false);

			if (otherIndex >= 0)
			{
				H_ContourPoint& point = currentContour.GetPoint(otherIndex);

				if (thisIndex == firstContour.FindBestMatch(&point, false))
				{
					match.Add(otherIndex);
				}
			}
		}

		if (match.NumElements() == contours.NumElements())
		{
			matches.Add(match);
		}

		pThisExtrema = firstContour.GetNextExtrema(pThisExtrema);
	}

	float lowestY = H_FLOAT_MAX;
	float lowestX = H_FLOAT_MAX;

	int   lowestIndex = 0;

	// Now look for lower left corner.
    for (int i = 0; i < matches.NumElements(); i++)
    {
		int index = matches[i][0];

		H_ContourPoint& currentPoint = firstContour.GetPoint(index);

		float currentX = currentPoint.m_Point.X();
		float currentY = currentPoint.m_Point.Y();

		// Favor lowest.
		if (currentY < lowestY)
		{
			lowestIndex = i;
			lowestY = currentY;
			lowestX = currentX;
		}
		else if (currentY == lowestY)
		{
			// Favor left at same Y.
			if (currentX < lowestX)
			{
				lowestIndex = i;
				lowestY = currentY;
				lowestX = currentX;
			}
		}
    }

	firstPoints.Clear();

	for (int i = 0; i < contours.NumElements(); i++)
	{
		firstPoints.Add(matches[lowestIndex][i]);
	}
}


void H_GlyphHarmonizer::SortContoursGenetic(H_ArrayList<H_QuadGlyph>& glyphs)
{
	for (int i = 0; i < glyphs.NumElements(); i++)
	{
		glyphs[i].CalcNesting();
		glyphs[i].NumberContours();
	}

	int numContours = glyphs.First().NumContours();

	H_LinkedList<H_QuadContour>& A_Contours = glyphs.First().Contours();

	// Calc and store average points for first glyph
	H_ArrayList<H_ContourData> A_AveragePoints;

	H_QuadContour* pContour = A_Contours.First();

	while (pContour)
	{
		H_ContourData data(pContour->GetNestingLevel(), pContour->GetAveragePoint());
		A_AveragePoints.Add(data);

		pContour = A_Contours.Next();
	}
	

	// Match each of the others to the first.
	for (int i = 1; i < glyphs.NumElements(); i++)
	{
		H_ArrayList<int> order(numContours);    // Results. Indices into B_Contours.
		H_LinkedList<int> contours;				// Pool of contours, we'll remove them as we find results.

		for (int j = 0; j < numContours; j++)
		{
			contours.Add(j);
		}

		H_QuadGlyph& currentGlyph = glyphs[i];

		H_LinkedList<H_QuadContour>& B_Contours = currentGlyph.Contours();
		H_ArrayList<H_ContourData> B_AveragePoints;

		// Get B's average points.
		pContour = B_Contours.First();

		while (pContour)
		{
			H_ContourData data(pContour->GetNestingLevel(), pContour->GetAveragePoint());
			B_AveragePoints.Add(data);

			pContour = B_Contours.Next();
		}
		int count = 0;

		while (count < numContours)
		{
			H_ArrayList<int> array1;
			H_ArrayList<int> array2;
			H_ArrayList<int> array3;

			// Initialize first array.
			int* pData = contours.First();

			while (pData)
			{
				array1.Add(*pData);

				pData = contours.Next();
			}

			for (int j = 0; j < array1.NumElements(); j++)
			{
				int closestIndex = ClosestPoint(A_AveragePoints[array1[j]], B_AveragePoints);

				array2.Add(closestIndex);
			}

			// Populate third array.
			for (int j = 0; j < array2.NumElements(); j++)
			{
				int closestIndex = ClosestPoint(B_AveragePoints[array2[j]], A_AveragePoints);

				array3.Add(closestIndex);
			}

			if (array1 == array3) // Overloaded.
			{
				for (int j = 0; j < array1.NumElements(); j++)
				{
					int index = array1[j];

					H_ListElem<int>* pElement = contours.Find(index);
					contours.Remove(pElement);
					order[index] = array2[j];
					count++;
				}
			}
			else
			{
				// Add the furthest wrong one.
				int furthestIndex = -1;
				float furthestDistance = 0.0f;

				for (int j = 0; j < array1.NumElements(); j++)
				{
					if (array1[j] != array3[j])
					{
						H_Vector2f& A_Point = A_AveragePoints[array1[j]].m_AveragePoint;
						H_Vector2f& B_Point = B_AveragePoints[array2[j]].m_AveragePoint;

						float distance = PointDistance(A_Point, B_Point);

						if (distance > furthestDistance)
						{
							furthestDistance = distance;
							furthestIndex = j;
						}
					}
				}

				int index1 = array1[furthestIndex];
				int index2 = array2[furthestIndex];

				H_ListElem<int>* pElement = contours.Find(index1);
				contours.Remove(pElement);
				order[index1] = array2[furthestIndex];

				A_AveragePoints[index1].m_Selected = true;
				B_AveragePoints[index2].m_Selected = true;
				count++;
			}
		}

		// Move glyph B's contours over to temp storage.
		H_LinkedList<H_QuadContour> localList;

		H_ListElem<H_QuadContour>* pCurrent = B_Contours.GetFirstElement();

		while (pCurrent)
		{
			B_Contours.Remove(pCurrent);
			localList.Add(pCurrent);
			pCurrent = B_Contours.GetFirstElement();
		}

		for (int j = 0; j < order.NumElements(); j++)
		{
			int contourNumber = order[j];

			H_ListElem<H_QuadContour>* pQuadContour = FindContour(localList, contourNumber);

			localList.Remove(pQuadContour);

			B_Contours.Add(pQuadContour);
		}
	}
}

H_ListElem<H_QuadContour>* H_GlyphHarmonizer::FindContour(H_LinkedList<H_QuadContour>& list, int number)
{
	H_ListElem<H_QuadContour>* pContour = list.GetFirstElement();
	H_ListElem<H_QuadContour>* pFoundContour = NULL;

	while (pContour)
	{
		if (pContour->m_Data.GetNumber() == number)
		{
			pFoundContour = pContour;
			break;
		}
		pContour = list.GetNextElement();
	}

	return pFoundContour;
}


void H_GlyphHarmonizer::SortContours(H_ArrayList<H_QuadGlyph>& glyphs)
{
	for (int i = 0; i < glyphs.NumElements(); i++)
	{
		glyphs[i].CalcNesting();
		glyphs[i].NumberContours();
		glyphs[i].SetBoundsOnContours();
	}

	// Match each of the others to the next.
	for (int i = 0; i < glyphs.NumElements() - 1; i++)
	{
		H_QuadGlyph& currentGlyph = glyphs[i];

		H_ScaleOffset scaleOffset;
	
		currentGlyph.FindScaledBounds(scaleOffset); // No scale but populates bounds.

		H_QuadGlyph& nextGlyph = glyphs[i + 1];

		scaleOffset = currentGlyph.GetScaleOffset(nextGlyph);

		nextGlyph.FindScaledBounds(scaleOffset); // Scale current to first.

		H_QuadGlyph temp;

		// Move glyph B's contours over to temp storage.
		H_LinkedList<H_QuadContour> localList;

		H_LinkedList<H_QuadContour>& contours = nextGlyph.Contours();

		H_ListElem<H_QuadContour>* pCurrent = contours.GetFirstElement();

		while (pCurrent)
		{
			contours.Remove(pCurrent);
			localList.Add(pCurrent);
			pCurrent = contours.GetFirstElement();
		}

		// nextGlyph is now 'empty'.
		// Add contours back in the correct order.
		H_QuadContour* pContour = currentGlyph.FirstContour();

		while (pContour)
		{
			H_QuadContour* pBestContour = BestFit(*pContour, localList);

			if (pBestContour != NULL)
			{
				nextGlyph.AddContour(*pBestContour);
			}
			pContour = currentGlyph.NextContour();
		}
	}
}



void H_GlyphHarmonizer::MakePoints(H_ArrayList<H_QuadContour*>& contours)
{
	for (int i = 0; i < contours.NumElements(); i++)
	{
		contours[i]->MakePoints();
	}
}

int H_GlyphHarmonizer::ClosestPoint(H_ContourData& point, H_ArrayList<H_ContourData>& list)
{
	float bestDistance = FLT_MAX;
	int   closestIndex = -1;

	for (int i = 0; i < list.NumElements(); i++)
	{
		if (list[i].m_Selected == false)
		{
			if (point.m_NestingLevel == list[i].m_NestingLevel)
			{
				float distance = PointDistance(point.m_AveragePoint, list[i].m_AveragePoint);

				if (distance < bestDistance)
				{
					bestDistance = distance;
					closestIndex = i;
				}
			}
		}
	}

	return closestIndex;
}

H_QuadContour* H_GlyphHarmonizer::Closest(H_QuadContour* pContour, H_LinkedList<H_QuadContour>& localList)
{
	float bestDistance = FLT_MAX;
	H_QuadContour* pClosestContour = NULL;

	H_QuadContour* pCurrentContour = localList.First();

	H_Vector2f averagePoint = pContour->GetAveragePoint();

	while (pCurrentContour)
	{
		H_Vector2f currentPoint = pCurrentContour->GetAveragePoint();

		float distance = PointDistance(currentPoint, averagePoint);

		if (	(distance < bestDistance) &&
				(pContour->GetNestingLevel() == pCurrentContour->GetNestingLevel()))
		{
			bestDistance = distance;
			pClosestContour = pCurrentContour;
		}

		pCurrentContour = localList.Next();
	}

	return pClosestContour;
}


H_QuadContour* H_GlyphHarmonizer::BestFit(H_QuadContour& contour, H_LinkedList<H_QuadContour>& localList)
{
	const float WEIGHT = 30.0f;
	float bestDistance = FLT_MAX;

	H_BoundingBox& contourBounds = contour.GetScaledBounds();
	H_BoundingBox& contourGlyphBounds = contour.GetGlyphBounds();

	H_ListElem<H_QuadContour>* pBestFit = NULL;
	H_ListElem<H_QuadContour>* pCurrentContour = localList.GetFirstElement();

	// Normalize contour width and height
	float contourWidth  = contourBounds.Width() / contourGlyphBounds.Width();
	float contourHeight = contourBounds.Height() / contourGlyphBounds.Height();

	while (pCurrentContour)
	{
		H_BoundingBox& currentBounds = pCurrentContour->m_Data.GetScaledBounds();

		float distance = currentBounds.Distance(contourBounds);

		H_BoundingBox& currentGlyphBounds	= pCurrentContour->m_Data.GetGlyphBounds();

		// Normalize current's width and height.
		float currentWidth  = currentBounds.Width() / currentGlyphBounds.Width();
		float currentHeight = currentBounds.Height() / currentGlyphBounds.Height();

        float xDistance = (float)fabs(currentWidth - contourWidth);
        float yDistance = (float)fabs(currentHeight - contourHeight);
		
		distance += xDistance * WEIGHT;
		distance += yDistance * WEIGHT;

		if (	(distance < bestDistance) &&
				(contour.GetNestingLevel() == pCurrentContour->m_Data.GetNestingLevel()))
		{
			bestDistance = distance;
			pBestFit = pCurrentContour;
		}

		pCurrentContour = localList.GetNextElement();
	}

	localList.Remove(pBestFit);

	return &pBestFit->m_Data;
}



