// Copyright (C) 2014 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// H_Quadrilateral.h

#ifndef H_QUADRILATERAL_H
#define H_QUADRILATERAL_H

#include "H_Vector2f.h"

class H_Line2D;

class H_Quadrilateral
{
    public:

        /* ctor */  H_Quadrilateral();
        /* ctor */  H_Quadrilateral(const H_Vector2f& vert0, const H_Vector2f& vert1, const H_Vector2f& vert2, const H_Vector2f& vert3);

        void        Init        (const H_Vector2f& vert0, const H_Vector2f& vert1, const H_Vector2f& vert2, const H_Vector2f& vert3);
        bool        Intersects  (H_Quadrilateral& other);
        bool        Intersects  (H_Line2D& line);

        H_Vector2f    operator [] (int index) const;
        H_Vector2f&   operator [] (int index);

    protected:

        H_Vector2f     m_Vertices[4];
};

#endif // QUADRILATERAL_H
