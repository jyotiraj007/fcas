// Copyright (C) 2014 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// H_Triangle.h

#ifndef H_TRIANGLE_H
#define H_TRIANGLE_H

#include "H_Vector2f.h"
class H_Line2D;

class H_Triangle
{
    public:

        /* ctor */  H_Triangle    ();
        /* ctor */  H_Triangle    (const H_Vector2f& vert0, const H_Vector2f& vert1, const H_Vector2f& vert2);

        void        Init        (const H_Vector2f& vert0, const H_Vector2f& vert1, const H_Vector2f& vert2);

        bool        Intersects  (H_Triangle& other);
        bool        Intersects  (H_Line2D& other);

        H_Vector2f    operator [] (int index) const;
        H_Vector2f&   operator [] (int index);

    protected:

        H_Vector2f     m_Vertices[3];
};

#endif // TRIANGLE_H
