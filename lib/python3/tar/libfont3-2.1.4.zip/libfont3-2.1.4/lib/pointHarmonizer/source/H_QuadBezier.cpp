// Copyright (C) 2014 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// H_QuadBezier.cpp

#include "H_QuadBezier.h"
#include "H_Line2D.h"
#include "H_Stack.h"
#include "H_CubicContour.h"
#include "H_Triangle.h"
#include "H_MathUtilities.h"
#include <math.h>

H_QuadBezier::H_QuadBezier()
{
}

H_QuadBezier::H_QuadBezier(const H_Vector2f& startPoint, const H_Vector2f& endPoint, const H_Vector2f& controlPoint)
{
    Init(startPoint, endPoint, controlPoint);
}

H_QuadBezier::H_QuadBezier(H_QuadPoints& quadPoints)
{
    Init(quadPoints.m_Start, quadPoints.m_End, quadPoints.m_Control);
}

void H_QuadBezier::Init(const H_Vector2f& startPoint, const H_Vector2f& endPoint, const H_Vector2f& controlPoint)
{
    m_Control[eSTART]   = startPoint;
    m_Control[eEND]     = endPoint;
    m_Control[eCONTROL] = controlPoint;
}

H_Line2D H_QuadBezier::GetStartTangent()
{
	return H_Line2D(m_Control[eSTART], m_Control[eCONTROL]);
}

H_Line2D H_QuadBezier::GetEndTangent()
{
	return H_Line2D(m_Control[eEND], m_Control[eCONTROL]);
}

void H_QuadBezier::Evaluate1(float flatness)
{
	m_Points.Clear();

	float delta = flatness;

	float t = delta;

	m_Points.Add(m_Control[eSTART]);

	while (t < 1.0f)
	{
		H_Vector2f currentPoint = PointAt(t);
		m_Points.Add(currentPoint);
		t += delta;
	}

	m_Points.Add(m_Control[eEND]);
}

H_Vector2f H_QuadBezier::PointAt(float t)
{
	// Find the mid curve point of these controls:
    H_Vector2f left   = (1.0f - t) * m_Control[eSTART]   + (t * m_Control[eCONTROL]);
	H_Vector2f right  = (1.0f - t) * m_Control[eCONTROL] + (t * m_Control[eEND]);

	H_Vector2f point  = (1.0f - t) * left + (t * right);

	return point;
}

void H_QuadBezier::Evaluate(float flatness)
{
    H_Vector2f left;
    H_Vector2f right;
    H_Vector2f middle;

    H_Stack<H_QuadPoints> stack;
    m_Points.Clear();

    m_Points.Add(m_Control[eSTART]);

    H_QuadPoints points;

    points.Set(m_Control[eSTART], m_Control[eEND], m_Control[eCONTROL]);

    stack.Push(points);

    while (false == stack.IsEmpty())
    {
        points = stack.Pop();

        // Find the mid curve point of these controls:
        left   = 0.5f * (points.m_Start + points.m_Control);
        right  = 0.5f * (points.m_End   + points.m_Control);
        middle = 0.5f * (left + right);

        // Make sure we don't recurse for ever or return Nan's etc.
        if (middle.IsValid())
        {
            // Evaluate their flatness:
            H_Vector2f distance(middle - points.m_Control);
            float len = distance.LengthSquared();

            if (len < flatness)
            {
                m_Points.Add(middle);
            }
            else
            {
                H_QuadPoints quadLeft(middle, points.m_End, right);
                H_QuadPoints quadRight(points.m_Start, middle, left);;

                // Split in two and keep going:
                stack.Push(quadLeft);
                stack.Push(quadRight);
            }
        }
    }
    m_Points.Add(m_Control[eEND]);
}


void H_QuadBezier::SplitAt(float position, H_QuadPoints& a, H_QuadPoints& b)
{
    int splitIndex = IndexAt(position);

    H_Vector2f pointA = m_Points[splitIndex - 1];
    H_Vector2f pointB = m_Points[splitIndex];

    H_Vector2f midPoint = H_Interpolate(pointA, pointB, 0.5f);

    H_Line2D lineSegment(pointA, pointB);
    lineSegment.Extend(10000);
    H_Line2D startVector(m_Control[eSTART], m_Control[eCONTROL]);
    H_Line2D endVector   (m_Control[eEND],  m_Control[eCONTROL]);

    H_Vector2f control1 = lineSegment.Intersection(startVector);
    H_Vector2f control2 = lineSegment.Intersection(endVector);

    a.m_Start = m_Control[eSTART];
    a.m_Control = control1;
    a.m_End    = midPoint;

    b.m_Start = midPoint;
    b.m_Control = control2;
    b.m_End = m_Control[eEND];

}

int H_QuadBezier::NumCurvePoints()
{
	return m_Points.NumElements();
}

H_Vector2f H_QuadBezier::GetCurvePoint(int index)
{
	return m_Points[index];
}


int H_QuadBezier::IndexAt(float position)
{
    Evaluate();

    float totalPath = PathLength();

	float pathLength = 0.0f;

    int i;

	for (i = 0; i < m_Points.NumElements() - 1; i++)
	{
		H_Vector2f& currentPoint = m_Points[i];
		H_Vector2f& nextPoint	 = m_Points[i + 1];

		H_Vector2f vector = nextPoint - currentPoint;

		float length = vector.Length();

		pathLength += length;

        float currentPosition = pathLength / totalPath;

        if (currentPosition >= position)
        {
            break;
        }
	}

    return i + 1;
}

float H_QuadBezier::PathLength()
{
	Evaluate();

	float pathLength = 0.0f;

	for (int i = 0; i < m_Points.NumElements() - 1; i++)
	{
		H_Vector2f& currentPoint = m_Points[i];
		H_Vector2f& nextPoint	 = m_Points[i + 1];

		H_Vector2f vector = nextPoint - currentPoint;

		float length = vector.Length();

		pathLength += length;
	}

	return pathLength;
}

bool H_QuadBezier::Split(H_ArrayList<int>& indexList, float flatness /* = 0.01f */)
{
    bool flatEnough = true;

    H_Vector2f left;
    H_Vector2f right;
    H_Vector2f middle;

    H_ArrayList<H_Triangle> source = m_Triangles;

    m_Triangles.Clear();

    for (int i = 0; i < indexList.NumElements(); i++)
    {
        int index = indexList[i];
        H_Triangle& triangle = source[index];

        // Find the mid curve point of these controls:
        left   = 0.5f * (triangle[0] + triangle[1]);
        right  = 0.5f * (triangle[2] + triangle[1]);
        middle = 0.5f * (left + right);

        H_Vector2f distance(middle - triangle[1]);
        float len = distance.LengthSquared();
    
        if (len < flatness)
        {
            m_Triangles.Add(triangle);
        }
        else
        {
            flatEnough = false;
            m_Triangles.Add(H_Triangle(triangle[0], left, middle));
            m_Triangles.Add(H_Triangle(middle, right, triangle[2]));   
        }
    }

    return flatEnough;
}

void H_QuadBezier::SetPoint(Control control, const H_Vector2f& point)
{
    m_Control[control] = point;
}

H_Vector2f H_QuadBezier::GetPoint(Control control)
{
    return m_Control[control];
}

bool H_QuadBezier::TrianglesIntersect(H_QuadBezier& other, H_ArrayList<int>& list1, H_ArrayList<int>& list2)
{
    bool foundIntersection = false;
    list1.ResetIndex();
    list2.ResetIndex();

    for (int i = 0; i < m_Triangles.NumElements(); i++)
    {
        for (int j = 0; j < other.m_Triangles.NumElements(); j++)
        {
            if (m_Triangles[i].Intersects(other.m_Triangles[j]))
            {
                foundIntersection = true;
                list1.AddUnique(i);
                list2.AddUnique(j);
            }
        }
    }
    return foundIntersection;
}

bool H_QuadBezier::Intersects(H_QuadBezier& other)
{
    // Initialize with single triangle that is our control points.
    m_Triangles.Clear();
    m_Triangles.Add(H_Triangle(m_Control[eSTART], m_Control[eCONTROL], m_Control[eEND]));

    other.m_Triangles.Clear();
    other.m_Triangles.Add(H_Triangle(other.m_Control[eSTART], other.m_Control[eCONTROL], other.m_Control[eEND]));

    H_ArrayList<int> indexList1;
    H_ArrayList<int> indexList2;

    bool flatEnough = false;

    while (!flatEnough)
    {
        if (TrianglesIntersect(other, indexList1, indexList2))
        {
            // Split the ones that intersected.
            bool thisFlatEnough  = Split(indexList1);
            bool otherFlatEnough = other.Split(indexList2);

            flatEnough = thisFlatEnough && otherFlatEnough;  // Avoid && sort circuiting by using above temporaries.
        }
        else
        {   // If none intersected then the neither do the two quads.
            return false;
        }
    }
    return true;
}

void H_QuadBezier::GetIntersections(H_QuadBezier& other, H_ArrayList<H_Vector2f>& intersections)
{
    if (Intersects(other))
    {
        // We still intersect at our flatness criteria.
        // Work out the intersections.
        for (int i = 0; i < m_Triangles.NumElements(); i++)
        {
            for (int j = 0; j < other.m_Triangles.NumElements(); j++)
            {
                H_Line2D line1(m_Triangles[i][0], m_Triangles[i][2]);
                H_Line2D line2(other.m_Triangles[j][0], other.m_Triangles[j][2]);

                if (line1.Intersects(line2))
                {
                    H_Vector2f intersection = line1.Intersection(line2);
                    intersections.Add(intersection);
                }
            }
        }
    }
}

bool H_QuadBezier::LineIntersects(H_Line2D& line, H_ArrayList<int>& indexList)
{
    bool foundIntersection = false;
    indexList.ResetIndex();

    for (int i = 0; i < m_Triangles.NumElements(); i++)
    {
        if (m_Triangles[i].Intersects(line))
        {
            foundIntersection = true;
            indexList.AddUnique(i);
        }
    }
    return foundIntersection;
}

bool H_QuadBezier::Intersects(H_Line2D& line)
{
    // Initialize with single triangle that is our control points.
    m_Triangles.Clear();
    m_Triangles.Add(H_Triangle(m_Control[eSTART], m_Control[eCONTROL], m_Control[eEND]));

    H_ArrayList<int> indexList;

    bool flatEnough = false;

    while (!flatEnough)
    {
        if (LineIntersects(line, indexList))
        {
            // Split the ones that intersected.
            flatEnough = Split(indexList);
        }
        else
        {   // If none intersected then the neither do the two quads.
            return false;
        }
    }
    return true;
}

void H_QuadBezier::GetIntersections(H_Line2D& line, H_ArrayList<H_Vector2f>& intersections)
{
    if (Intersects(line))
    {
        // We still intersect at our flatness criteria.
        // Work out the intersections.
        for (int i = 0; i < m_Triangles.NumElements(); i++)
        {
            H_Line2D thisLine(m_Triangles[i][0], m_Triangles[i][2]);

            if (thisLine.Intersects(line))
            {
                H_Vector2f intersection = thisLine.Intersection(line);
                intersections.Add(intersection);
            }
        }
    }
}


float H_QuadBezier::HorizontalTangent()
{
    const float EPSILON = 1e-2f;

    float start   = m_Control[eSTART]  .Y();
    float control = m_Control[eCONTROL].Y();
    float end     = m_Control[eEND]    .Y();

    float left;
    float right;
    float middle;

    float side = 1.0f;

    if (control < end)
    {
        side = -1.0f;
    }

    int count = 20; // Fail safe to avoid infinite loop. Don't expect to loop more than ~7 times.

    while (count)
    {
        // Find the mid curve point of these controls:
        left   = 0.5f * (start + control);
        right  = 0.5f * (end   + control);
        middle = 0.5f * (left  + right);

        float difference = left - right;
        if (fabs(difference) < EPSILON)
        {
            return middle;
        }
        else
        {
            if (difference * side < 0.0f)
            {
                start    = middle;
                control  = right;
            }
            else
            {
                end     = middle;
                control = left;
            }
        }
        count--;
    }

    return m_Control[eSTART].Y();
}

float H_QuadBezier::VerticalTangent()
{
    const float EPSILON = 1e-2f;

    float start   = m_Control[eSTART]  .X();
    float control = m_Control[eCONTROL].X();
    float end     = m_Control[eEND]    .X();

    float left;
    float right;
    float middle;

    float side = -1.0f;

    if (control < end)
    {
        side = 1.0f;
    }

    int count = 20; // Fail safe to avoid infinite loop. Don't expect to loop more than ~7 times.

    while (count)
    {
        // Find the mid curve point of these controls:
        left   = 0.5f * (start + control);
        right  = 0.5f * (end   + control);
        middle = 0.5f * (left + right);

        float difference = left - right;
        if (fabs(difference) < EPSILON)
        {
            return middle;
        }
        else
        {
            if (difference * side > 0.0f)
            {
                start   = middle;
                control = right;
            }
            else
            {
                end     = middle;
                control = left;
            }
        }
        count--;
    }
    return m_Control[eSTART].X();
}


float H_QuadBezier::LeftExtent()
{
    m_LeftIsTangent = false;

    float left = m_Control[eSTART].X();

    if (m_Control[eEND].X() < left)
    {
        left = m_Control[eEND].X();
    }

    if (m_Control[eCONTROL].X() < left)
    {
        left = VerticalTangent();
        m_LeftIsTangent = true;
    }

    return left;
}

float H_QuadBezier::RightExtent()
{
    m_RightIsTangent = false;

    float right = m_Control[eSTART].X();

    if (m_Control[eEND].X() > right)
    {
        right = m_Control[eEND].X();
    }

    if (m_Control[eCONTROL].X() > right)
    {
        right = VerticalTangent();
        m_RightIsTangent = true;
    }

    return right;
}

float H_QuadBezier::TopExtent()
{
    m_TopIsTangent = false;

    float top = m_Control[eSTART].Y();

    if (m_Control[eEND].Y() > top)
    {
        top = m_Control[eEND].Y();
    }

    if (m_Control[eCONTROL].Y() > top)
    {
        top = HorizontalTangent();
        m_TopIsTangent = true;
    }

    return top;
}

float H_QuadBezier::BottomExtent()
{
    m_BottomIsTangent = false;

    float bottom = m_Control[eSTART].Y();

    if (m_Control[eEND].Y() < bottom)
    {
        bottom = m_Control[eEND].Y();
    }

    if (m_Control[eCONTROL].Y() < bottom)
    {
        bottom = HorizontalTangent();
        m_BottomIsTangent = true;
    }

    return bottom;
}

