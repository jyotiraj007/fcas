/* Copyright (C) 1989, 1990, 1991, 1992, 1993, 1994, 1995, 1996
 * all rights reserved, by Bayer Corp., Agfa Division, Wilmington, MA.
 *
 * This software is furnished under a license and may be used and
 * copied only in accordance with the terms of such license and with
 * the inclusion of the above copyright notice. This software or any
 * other copies thereof may not be provided or otherwise made
 * available to any other person except as allowed under license. No
 * title to and ownership of the software is hereby transferred.
 *
 * This information in this software is subject to change without notice
 */
/* $Header:   I:\bull\c_exprss\src\ahuff.h_v   1.1   14 May 1997 17:18:30   MARTIN  $ */
/* $Log:   I:\bull\c_exprss\src\ahuff.h_v  $
 * 
 *    Rev 1.1   14 May 1997 17:18:30   MARTIN
 * 
 * Renamed MEMORY.H to MTXMEM.H.
 * 
 *    Rev 1.0   17 Dec 1996 16:31:50   MARTIN
 * Initial revision.
   
      Rev 1.1   24 Apr 1996 15:46:58   MARTIN
   
   Fixed header.
   
      Rev 1.0   24 Apr 1996 10:50:02   LISA
   Initial revision.
*/
#include "mtxmem.h"

/*
 * File:                        AHUFF.H
 * Author:                        Sampo Kaasila
 * First Version:                February 6, 1996
 * First Memory Version :        September 30, 1996 (Sampo)    .
 * First pure ANSI C version:    October 28, 1996  (Sampo).
 */
#ifdef __cplusplus
extern "C" {
#endif

extern long MTX_AHUFF_BitsUsed( register long x );


/* This struct is only for internal use by AHUFF */
typedef struct {
    short up;
    short left;
    short right;
    short code; /* < 0 for internal node, == code otherwise */
    long weight;
} nodeType;


typedef struct {
    /* private */
    nodeType *tree;
    short *symbolIndex;
    long bitCount, bitCount2;
    long range;
    
    BITIO *bio;
    MTX_MemHandler *mem;

    int maxSymbol;
    
    
    long countA;
    long countB;
    long sym_count;
    /* public */
    /* No public fields! */
} AHUFF;

    
/* Public Interface */
short MTX_AHUFF_ReadSymbol( AHUFF *t );
long MTX_AHUFF_WriteSymbolCost( AHUFF *t, short symbol ); /* returns 16.16 bit cost */
void MTX_AHUFF_WriteSymbol( AHUFF *t, short symbol ); 

/* Constructor */
AHUFF *MTX_AHUFF_Create( MTX_MemHandler *mem, BITIO *bio, short range );        /* [0 .. range-1] */
/* Destructor */
void MTX_AHUFF_Destroy( AHUFF *t );

#ifdef __cplusplus
}
#endif
