/* Copyright (C) 1989, 1990, 1991, 1992, 1993, 1994, 1995, 1996
 * all rights reserved, by Bayer Corp., Agfa Division, Wilmington, MA.
 *
 * This software is furnished under a license and may be used and
 * copied only in accordance with the terms of such license and with
 * the inclusion of the above copyright notice. This software or any
 * other copies thereof may not be provided or otherwise made
 * available to any other person except as allowed under license. No
 * title to and ownership of the software is hereby transferred.
 *
 * This information in this software is subject to change without notice
 */
/* $Header:   I:\bull\c_exprss\src\config.h_v   1.7   16 May 1997 10:25:44   MARTIN  $ */
/* $Log:   I:\bull\c_exprss\src\config.h_v  $
 * 
 *              04 Apr 2014            hadleyj
 *
 * DEBUG -> MTX_DEBUG; BIG_ENDIAN -> MTX_BIG_ENDIAN to avoid conflicts.
 *
 *    Rev 1.7   16 May 1997 10:25:44   MARTIN
 * 
 * Added BIT16 define. Removed SUN reference.
 * 
 *    Rev 1.6   14 May 1997 16:56:50   MARTIN
 * 
 * Added support for SUN platform.
 * 
 *    Rev 1.5   30 Apr 1997 11:07:24   MARTIN
 * 
 * Added undefine for FAR if 32-bit.
 * 
 *    Rev 1.4   29 Apr 1997 14:40:18   MARTIN
 * 
 * Added undefine for huge if 32-bit version.
 * 
 *    Rev 1.3   17 Jan 1997 12:19:28   MARTIN
 * Added HARD_DISK_ON define, modified comments for COMPRESS_ON and DECOMPRESS
 * 
 *    Rev 1.2   16 Jan 1997 15:53:30   MARTIN
 * 
 * Added #ifndef _MAX_PATH.
 * 
 *    Rev 1.1   09 Jan 1997 16:19:26   MARTIN
 * 
 * Added SUBSET_ON define.
 * 
 *    Rev 1.0   17 Dec 1996 16:31:58   MARTIN
 * Initial revision.
 * 
 *    Rev 1.6   09 Oct 1996 16:07:18   MARTIN
 * 
 * Modifications for memory based version.
 * 
 *    Rev 1.5   09 Oct 1996 14:03:16   MARTIN
 * 
 * Modifications made by Sampo for the Mac platform.
 * 
 *    Rev 1.4   27 Aug 1996 09:34:34   AL
 * Version 3 format: store hdmx and VDMX if they grow by 50%
 * 
 *    Rev 1.3   19 Aug 1996 15:12:42   MARTIN
 * 
 * Added format1 and format2 defines.
 * 
 *    Rev 1.2   22 May 1996 15:49:20   MARTIN
 * 
 * Added ENABLE_DISPLAY definition.
 * 
 *    Rev 1.1   24 Apr 1996 15:47:54   MARTIN
 * 
 * Fixed header.
 * 
 *    Rev 1.0   24 Apr 1996 10:50:44   LISA
 * Initial revision.
*/

/*
 * File:							CONFIG.H
 * Author:							Sampo Kaasila
 * First Version:					February 6, 1996
 * First pure ANSI C version:		October 28, 1996  (Sampo).
 */

/* Before compiling the code please decide if the following defines */
/* should be enabled. */

/* 1: Define for a Mac, and comment out on a PC */
/* #define MTX_BIG_ENDIAN */
/* 2: Enable for compression, comment out for no compression */
#define COMPRESS_ON
/* 2: Enable for decompression, comment out for no decompression */
#define DECOMPRESS_ON
/* 4: For a debug build enable debug */
/*#define MTX_DEBUG */
/* 5: Enable for MACINTOSH */
/* #define MACINTOSH */
/* 6: For displays of error codes to standard output enable ENABLE_DISPLAY */
/*#define ENABLE_DISPLAY*/
/* 7: Comment out SUBSET_ON if no subsetting */
/*#define SUBSET_ON */
/* 8: Comment out HARD_DISK_ON if no disk i/o */
#define HARD_DISK_ON
/* 9: Comment out BIT16 if 32-bit application, enable for 16-bit applications */
/*#define BIT16*/

#ifdef MTX_DEBUG	/* if debug, turn on compression and decompression */
#define COMPRESS_ON
#define DECOMPRESS_ON
#endif


/*#define VERBOSE */

#ifndef false
#define false 0
#endif

#ifndef true
#define true 1
#endif


#ifndef MTX_DEBUG
#undef assert
#define assert(test) NULL
#define NO_ASSERTS
#endif

#ifndef _MAX_PATH
#ifdef _WINDOWS
#define _MAX_PATH        128 /* max length of pathname (incl null) */
#else
#define _MAX_PATH        65  /* max length of pathname (incl null) */
#endif /* _WINDOWS */

#ifdef MACINTOSH
#define _MAX_PATH 256
#endif
#endif  /* _MAX_PATH */

#ifndef BIT16
#define __huge   /* undefine the type huge */
#define FAR      /* undefine the type FAR  */
#endif

#ifdef SUN
#define const  /* const has no meaning on some SUN stations */
#endif

#define format1   1
#define format2   2
#define format3   3
#define currentformat format3
