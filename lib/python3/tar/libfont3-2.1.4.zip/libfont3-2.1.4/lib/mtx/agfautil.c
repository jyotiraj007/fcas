/* Copyright (C) 1989, 1990, 1991, 1992, 1993, 1994, 1995, 1996
 * all rights reserved, by Bayer Corp., Agfa Division, Wilmington, MA.
 *
 * This software is furnished under a license and may be used and
 * copied only in accordance with the terms of such license and with
 * the inclusion of the above copyright notice. This software or any
 * other copies thereof may not be provided or otherwise made
 * available to any other person except as allowed under license. No
 * title to and ownership of the software is hereby transferred.
 *
 * This information in this software is subject to change without notice
 */
/* $Header:   I:\bull\c_exprss\src\agfautil.c_v   1.0   29 Apr 1997 15:48:42   MARTIN  $ */
/* $Log:   I:\bull\c_exprss\src\agfautil.c_v  $
 * 
 *              04 Apr 2014            hadleyj
 * Replaced contents of memcpyHuge with call to plain memcpy.
 *
 *    Rev 1.0   29 Apr 1997 15:48:42   MARTIN
 * Initial revision.
 */
#include "agfaconfig.h"
#include "agfautil.h"
#include <string.h>

/* ----------------------------- memcpyHuge ----------------------------------- */

void * memcpyHuge(void* dest, void* src, unsigned long size) {
    /* It was probably necessary in 1994 to have a "Huge" version
     * of this for 32-bit, but nowadays plain memcpy does just fine.
     */
    return memcpy(dest, src, size);
}
