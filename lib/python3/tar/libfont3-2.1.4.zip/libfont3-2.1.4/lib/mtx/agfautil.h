/* Copyright (C) 1989, 1990, 1991, 1992, 1993, 1994, 1995, 1996
 * all rights reserved, by Bayer Corp., Agfa Division, Wilmington, MA.
 *
 * This software is furnished under a license and may be used and
 * copied only in accordance with the terms of such license and with
 * the inclusion of the above copyright notice. This software or any
 * other copies thereof may not be provided or otherwise made
 * available to any other person except as allowed under license. No
 * title to and ownership of the software is hereby transferred.
 *
 * This information in this software is subject to change without notice
 */
/* $Header:   I:\bull\c_exprss\src\agfautil.h_v   1.0   29 Apr 1997 15:49:48   MARTIN  $ */
/* $Log:   I:\bull\c_exprss\src\agfautil.h_v  $
 * 
 *    Rev 1.0   29 Apr 1997 15:49:48   MARTIN
 * Initial revision.
 */
void *memcpyHuge( void *, void *, unsigned long );

