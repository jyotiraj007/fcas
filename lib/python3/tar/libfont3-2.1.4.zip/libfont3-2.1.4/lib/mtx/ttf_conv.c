/* Copyright (C) 1989, 1990, 1991, 1992, 1993, 1994, 1995, 1996
 * all rights reserved, by Bayer Corp., Agfa Division, Wilmington, MA.
 *
 * This software is furnished under a license and may be used and
 * copied only in accordance with the terms of such license and with
 * the inclusion of the above copyright notice. This software or any
 * other copies thereof may not be provided or otherwise made
 * available to any other person except as allowed under license. No
 * title to and ownership of the software is hereby transferred.
 *
 * This information in this software is subject to change without notice
 */
/* $Header:   I:\bull\c_exprss\src\ttf_conv.c_v   1.11   14 Oct 1998 11:20:12   MARTIN  $ */
/* $Log:   I:\bull\c_exprss\src\ttf_conv.c_v  $
 * 
 *               28 Aug 2014            taylorb recover from errors involving hdmx, vdmx tables
 *
 *               04 Apr 2014            hadleyj
 *
 * DEBUG -> MTX_DEBUG, BIG_ENDIAN -> MTX_BIG_ENDIAN
 *
 *    Rev 1.11   14 Oct 1998 11:20:12   MARTIN
 * Modifications by Microsoft for 64-bit port.
 * 
 *    Rev 1.10   17 Oct 1997 10:59:34   MARTIN
 * Fixed sign problem with yMinRatio calculation in previous
 * bug fix.
 * 
 *    Rev 1.9   17 Oct 1997 09:59:24   MARTIN
 * Removed floating point from ConvertVDMXTable and 
 * ConvertHdmxTable (by Microsoft). Rounding bug fix in new code.
 * 
 *    Rev 1.8   22 May 1997 11:14:28   MARTIN
 * 
 * Added conditional compile for realloc function.
 * 
 *    Rev 1.7   14 May 1997 16:54:02   MARTIN
 * Removed compiler warnings.
 * 
 *    Rev 1.6   30 Apr 1997 11:06:50   MARTIN
 * 
 * Changed order of realloc arguments.
 * 
 *    Rev 1.5   29 Apr 1997 14:34:42   MARTIN
 * 
 * Removed global constants, made them local.Moved glyph related
 * functions to new source file glyph.c.
 * 
 *    Rev 1.4   24 Mar 1997 14:23:10   MARTIN
 * 
 * Removed Rev 1.3 changes due to optimization issues. Added
 * function is_TTF_Test.
 * 
 *    Rev 1.3   04 Feb 1997 10:53:54   MARTIN
 * Added calls to memmove to solve porting problems to Sun workstations.
 * Memmove will handle pointers that are not longword aligned.
 * 
 *    Rev 1.2   13 Jan 1997 17:54:08   MARTIN
 * 
 * In AllocateTTFSpace, using user's realloc function not MTX's.
 * 
 *    Rev 1.1   30 Dec 1996 11:42:56   MARTIN
 * Fix for dangling pointer error from MTX_mem_CloseMemory.
 * Using caller's memory routines at top level, instead of MTX's.
 * 
 *    Rev 1.0   17 Dec 1996 16:32:06   MARTIN
 * Initial revision.
   
      Rev 1.9   09 Oct 1996 16:07:00   MARTIN
   
   Modifications for memory based version.
   
      Rev 1.8   09 Oct 1996 14:01:40   MARTIN
   
   Modifications made by Sampo for the Mac platform.
   
      Rev 1.7   27 Aug 1996 09:33:52   AL
   Version 3 format: store hdmx and VDMX if they grow by 50%
   
      Rev 1.4   22 May 1996 15:51:00   MARTIN
   
   Fixed VDMX long word alignment bug.
   
      Rev 1.3   20 May 1996 15:09:56   MARTIN
   
   Replaced error messages with error codes.
   
      Rev 1.2   02 May 1996 16:55:38   MARTIN
   In ParseCode, replaced array argument with pointer argument to resolve null
   
      Rev 1.1   24 Apr 1996 15:51:12   MARTIN
   
   Fixed header.
   
      Rev 1.0   24 Apr 1996 10:54:56   LISA
   Initial revision.
*/

/*
 * File:                                  ttf_conv.cp
 * Author:                                Sampo Kaasila
 * First Version:                         February 6, 1996
 * First memory based version:            September 27, 1996 (Sampo)
 * Automatic memory reallocation:         October 2, 1996 (Sampo)
 * First pure ANSI C version:             October 28, 1996  (Sampo).
 * Bounds checking on all reads in the
 * TrueType data structure for increased
 * robustness. All C-structs defining
 * the TrueType fileformat were removed
 * for increased portability.
 * The subsetter code was also removed
 * since we now totally rely on the
 * Microsoft subsetting code:             November 18, 1996 (Sampo).
 * Remove the use of setjmp and longjmp.  August 6, 2014 (Taylor)
 */
#ifdef _WINDOWS
#include <windows.h>
#endif
 
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <assert.h>
#include <string.h>

#include "agfaconfig.h"
#include "sfnt.h"
#include "ttf_conv.h"
#include "glyph.h"
#include "mtxmem.h"
#include "agfautil.h"
#include "errcodes.h"



/* Here we have both big and little endian versions of SWAPENDS. */
/* These routines are needed since the TrueType format is Big-Endian native. */
#ifdef MTX_BIG_ENDIAN

#define SWAPENDS_16( w )  (w)
#define SWAPENDS_U16( w ) (w)
#define SWAPENDS_32( w )  (w)
#define SWAPENDS_U32( w ) (w)

#else
static short SWAPENDS_16( register short w )
{
    register unsigned char /* b0, */ b1;
    
    /* b0 = (char)w; */
    b1 = (char)(w >> 8);
    
    /* w = b0; */
    w <<= 8;
    w |= b1;
    
    return w; /*****/
}

static unsigned short SWAPENDS_U16( register unsigned short w )
{
    register unsigned char /* b0, */ b1;
    
    /* b0 = (char)w; */
    b1 = (char)(w >> 8);
    
    /* w = b0; */
    w <<= 8;
    w |= b1;
    
    return w; /*****/
}


static int32_t SWAPENDS_32( register int32_t ww )
{
    register uint16_t w0, w1;
    
    w0 = (int16_t)ww;
    w1 = (int16_t)(ww >> 16);
    w0 = SWAPENDS_U16( w0 );
    w1 = SWAPENDS_U16( w1 );
    
    ww = w0;
    ww <<= 16;
    ww |= w1;
    
    return ww; /*****/
}

static uint32_t SWAPENDS_U32( register uint32_t ww )
{
    register uint16_t w0, w1;
    
    w0 = (int16_t)ww;
    w1 = (int16_t)(ww >> 16);
    w0 = SWAPENDS_U16( w0 );
    w1 = SWAPENDS_U16( w1 );
    
    ww = w0;
    ww <<= 16;
    ww |= w1;
    
    return ww; /*****/
}
#endif

/* Reads a word and increments the pointer */
/* It works for both big and little endian machines */
static short READWORD_INC( char * *pRef )
{
    short x;
    register char *p = *pRef;
    
    x = (short)((((short)*p) << 8) | *(unsigned char *)(p+1));

    *pRef += 2;
    return x; /*****/
}

/* Writes a word and increments the pointer */
/* It works for both big and little endian machines */
static void WRITEWORD_INC( char * *pRef, short x )
{
    register char *p = *pRef;
    *p++ = (char)((unsigned short)x >> 8);
    *p++ = (char)x;
    *pRef = p;
}


/* Writes a long and increments the pointer */
/* It works for both big and little endian machines */
static void WRITELONG_INC( char * *p, long x )
{
    short w0, w1;
    
    w0 = (short)x;
    w1 = (short)(x >> 16);

    WRITEWORD_INC( p, w1 );
    WRITEWORD_INC( p, w0 );
}

/*
const unsigned char flipSignCode        = 250;
const unsigned char Hop3Code            = 251; * A,X1,A,X2,A -> A,X1,Hop3Code,X2 - >A,X1,A,X2,A *
const unsigned char Hop4Code            = 252; * A,X1,A,X2,A,X3,A -> A,X1,Hop4Code,X2,X3 - >A,X1,A,X2,A,X3,A *
const unsigned char wordCode            = 253;
const unsigned char oneMoreByteCode2    = 254;
const unsigned char oneMoreByteCode1    = 255;

const short lowestUCode = 253; * wordCode *

const short lowestCode  = 250; * flipSignCode *
*/

static int CheckReadBoundsForTable( TTF_Converter *t, char *readStart, long byteCount )
{
    if ( ((char __huge *)readStart+byteCount) > t->tableEnd || readStart < t->tableStart ) {
        SETLASTERROR( t->mem->env, ERR_OutOfBoundsRead_In_InputFont )
    }
    return 0;
}

static int CheckReadBoundsForData( TTF_Converter *t, char *readStart, long byteCount, char *dataStart, long datalength )
{
    if ( ((char __huge *)readStart+byteCount) > ((char __huge *)dataStart+datalength) || readStart < dataStart ) {
        SETLASTERROR( t->mem->env, ERR_OutOfBoundsRead_In_InputFont )
    }
    return 0;
}

/* Returns the offset for the table with the tag <tag> */
static long GetTableOffset( char *sfnt, sfnt_TableTag tag )
{
    register long offset, i, numOffsets;
    
    assert( sfnt != NULL );
    
    offset = 0;
    numOffsets = SWAPENDS_U16( GET_sfnt_numOffsets( sfnt ) );
    for ( i = 0; i < numOffsets; i++ ) {
        if ( SWAPENDS_32( GET_sfnt_table_tag( sfnt, i ) ) == tag ) {
            offset = SWAPENDS_U32( GET_sfnt_table_offset( sfnt, i ) );
            break; /******/
        }
    }
    return offset; /******/
}

/* Returns a pointer to the table with the tag <tag> */
static char __huge *GetTablePtr( char *sfnt, sfnt_TableTag tag )
{
    register unsigned long offset;

    assert( sfnt != NULL );
    offset = GetTableOffset( sfnt, tag );
    return ((char __huge *)sfnt + offset); /******/
}

/* Returns the length of the table with the tag <tag> */
/* returns zero it the table does not exist */
static long GetTableLength( char *sfnt, sfnt_TableTag tag )
{
    register long length, i, numOffsets;
    
    assert( sfnt != NULL );
    length = 0;
    numOffsets = SWAPENDS_U16( GET_sfnt_numOffsets( sfnt ) );
    for ( i = 0; i < numOffsets; i++ ) {
        if ( SWAPENDS_32( GET_sfnt_table_tag( sfnt, i ) ) == tag ) {
            length = SWAPENDS_U32( GET_sfnt_table_length( sfnt, i ) );
            break; /******/
        }
    }
    return length; /******/
}


/* Returns number of glyphs in the sfnt file */
static long GetNumberOfGlyphs( char *sfnt )
{
    long    numEntries;
    char    *profile;
    
    profile = GetTablePtr( sfnt, tag_MaxProfile );
    /* We do not need to check for out of bounds read since we have already
      checked that the maxp table is big enough and inside the input data */
    /* numEntries = SWAPENDS_U16( profile->numGlyphs ); */
    numEntries = SWAPENDS_U16( GET_maxp_numGlyphs( profile ) );
    return numEntries; /*****/
}


/* Returns the metrics for the glyph with glyph index <glyphIndex> */
static int GetMetrics( TTF_Converter *t, char *sfnt, unsigned short glyphIndex, short *aw, short *lsb )
{
    char                    *hmtx;
    unsigned short           numEntries;
    short                   *lsbLoc;
    char                    *sfntHorizontalHeader;
    long                     horMetricsLength;

    horMetricsLength = GetTableLength( sfnt, tag_HorizontalMetrics );
    if ( horMetricsLength == 0 ) {
        SETLASTERROR( t->mem->env, ERR_hmtx_table_gone_or_to_short )
    }
    hmtx = GetTablePtr( sfnt, tag_HorizontalMetrics );
    sfntHorizontalHeader = GetTablePtr(sfnt,tag_HoriHeader);
    /* We do not need to check for out of bounds read since we have already
       checked that the hhea table is big enough and inside the input data */
    numEntries = SWAPENDS_U16( GET_hhea_numberOf_LongHorMetrics(sfntHorizontalHeader) );
    
    if ( glyphIndex >= numEntries ) {
        CheckReadBoundsForData( t, (char *)GET_hmtx_advanceWidth_Ptr( hmtx, (numEntries - 1)), 2, hmtx, horMetricsLength ); /*aw */
        *aw  = SWAPENDS_U16( *GET_hmtx_advanceWidth_Ptr( hmtx, (numEntries - 1) ) );
        lsbLoc = (short *)GET_hmtx_FirstSoloLsb_Ptr( hmtx, numEntries );
        lsbLoc += glyphIndex - numEntries;
        CheckReadBoundsForData( t, (char *)lsbLoc, 2, hmtx, horMetricsLength ); /* lsb */
        *lsb = SWAPENDS_16( *lsbLoc );
    } else {
        CheckReadBoundsForData( t, (char *)GET_hmtx_advanceWidth_Ptr( hmtx, glyphIndex ), 2+2, hmtx, horMetricsLength ); /* aw, lsb */
        *aw  = SWAPENDS_U16( *GET_hmtx_advanceWidth_Ptr( hmtx, glyphIndex ) );
        *lsb = SWAPENDS_16( *GET_hmtx_leftSideBearing_Ptr( hmtx, glyphIndex ) );
    }
    return 0;
}


/* Returns a pointer to the glyph with glyp index <glyphIndex> */
static char *GetSpline( char *sfnt, unsigned short glyphIndex, long *length )
{
    uint32_t       *longIndexToLoc;
    unsigned short      *shortIndexToLoc;
    char                *glyphData;
    int32_t              glyphDataOffset, glyphDataLength;
    char                *head = GetTablePtr( sfnt, tag_FontHeader );
    
    longIndexToLoc  = (uint32_t *)GetTablePtr( sfnt, tag_IndexToLoc );
    if ( SWAPENDS_16( GET_head_indexToLocFormat( head ) ) == SHORT_INDEX_TO_LOC_FORMAT ) {
        shortIndexToLoc = (unsigned short *)longIndexToLoc;
        glyphDataOffset = SWAPENDS_U16(shortIndexToLoc[glyphIndex]);
        glyphDataLength = SWAPENDS_U16(shortIndexToLoc[glyphIndex + 1]) - glyphDataOffset;
        glyphDataOffset *= 2L;
        glyphDataLength *= 2L;
    } else {
        glyphDataOffset = SWAPENDS_U32(longIndexToLoc[glyphIndex]);
        glyphDataLength = SWAPENDS_U32(longIndexToLoc[glyphIndex+1]) - glyphDataOffset;
    }

    glyphData = GetTablePtr( sfnt, tag_GlyphData );
    if ( length != NULL ) {
        *length = glyphDataLength;
    }
    
    /* sfnt_GetMetrics( sfntH, glyphIndex, &wStuff->glyph->advanceWidth, &wStuff->glyph->leftSideBearing ); */
    return (char __huge *)glyphData+glyphDataOffset; /*****/
}

static int AllocateTTFSpace( TTF_Converter *t, char * *destSfnt, long pos, long byteCount, long *maxOutSize )
{
    char * newDestSfnt;
    byteCount += 4; /* Always keep a 4 byte margin to allow for the zero padding */
    if ( pos + byteCount > *maxOutSize ) {
        *maxOutSize = pos + byteCount + (*maxOutSize>>1) + 2; /* Allocate memory in exponentially increasing steps */
        /* This function is called during both compression and decompression path */
        /* All work must be done in MTX memory, _not_ in user space - VL 20090914 */ 
        newDestSfnt = (char *)MTX_mem_realloc( t->mem, *destSfnt, *maxOutSize ); /* VL */
        CHECKLASTERROR(t->mem->env);
        if (newDestSfnt == NULL) SETLASTERROR( t->mem->env, ERR_no_more_memory );
        if ( *destSfnt == t->ttf ) {
            t->ttf        = newDestSfnt;
            t->ttfSize    = *maxOutSize;
        } else if ( *destSfnt == (char *)t->ctfData.ctf1 ) {
            t->ctfData.ctf1        = (unsigned char *)newDestSfnt;
            t->ctfData.ctfSize1    = *maxOutSize;
        } else {
            assert( false );
        }
        *destSfnt = newDestSfnt;
    }
    return 0;
}




/* Writes out the 'loca' table appropriately using short or long formats */
/* It saves the format picked into t->indexToLocFormat so */
/* that it can be later set correctly in the 'head' table */
static long Write_loca_Table( TTF_Converter *t, long posTable[], long numEntries, char * *destSfnt, long pos, long *maxOutSize )
{
    char *start, *p; /* Only assign these after AllocateSpace has been invoked */
    long i, maxVal;
    
    maxVal = posTable[numEntries-1];
    for ( i = numEntries-2; i >= 0; i-- ) {
        if ( posTable[i] > maxVal ) {
            maxVal = posTable[i];
        }
    }
    if ( maxVal <= 0x0000ffff * 2L ) {
        AllocateTTFSpace( t, destSfnt, pos, numEntries * 2, maxOutSize );
        CHECKLASTERROR(t->mem->env);
        start = p = &(*destSfnt)[pos];
        /* Do short format */
        for ( i = 0; i < numEntries; i++ ) {
            unsigned short value;
            assert( ( posTable[i] & 1 ) == 0 ); /* make sure it is word aligned */
            value = (unsigned short)(posTable[i] / 2);
            WRITEWORD_INC( &p, value );
        }
        t->indexToLocFormat = 0;
        assert( p - start == numEntries * 2 );
    } else {
        AllocateTTFSpace( t, destSfnt, pos, numEntries * 4, maxOutSize );
        CHECKLASTERROR(t->mem->env);
        start = p = &(*destSfnt)[pos];
        /* Do long format */
        for ( i = 0; i < numEntries; i++ ) {
            long value;
            assert( ( posTable[i] & 1 ) == 0 ); /* make sure it is word aligned */
            value = posTable[i];
            WRITELONG_INC( &p, value );
        }
        t->indexToLocFormat = 1;
        assert( p - start == numEntries * 4 );
    }
    return (long)(p - start); /*****/
}


/* Converts the glyph table both ways between ttf and ctf formats */
static long ConvertGlyphTable( TTF_Converter *t, int TTF_To_CTF, char *inFont, long posTable[], char * *destSfnt, long pos1, long *maxOutSize )
{
    char *spline, *glyphDataIn;
    unsigned short glyphIndex;
    Glyph *glyph;
    long numEntries, thisLength, oldLength;
    long startPos, outPos, bytesRead, totalBytesRead;
    
    numEntries       = GetNumberOfGlyphs( inFont );
    glyphDataIn      = GetTablePtr( inFont, tag_GlyphData );
    startPos         = pos1;
    outPos           = pos1;
    totalBytesRead   = 0;
    for ( glyphIndex = 0; glyphIndex < (unsigned short)numEntries; glyphIndex++ ) {
        posTable[ glyphIndex ] = outPos - startPos;
        
        if ( TTF_To_CTF ) {
            spline = GetSpline( inFont, glyphIndex, &oldLength );
        } else {
            /* at this point we have no 'loca' table */
            /* spline = t->GetSpline( inFont, glyphIndex, &oldLength ); */
            spline        = glyphDataIn + totalBytesRead;
            oldLength     = 0;
        }
        CheckReadBoundsForTable( t, spline, oldLength ); /* >= tableStart && < tableEnd */
        CHECKLASTERROR(t->mem->env);
        
        assert( spline != NULL );
        assert( spline >= inFont );
        glyph = MTX_Glyph_Create( t->mem, (char)TTF_To_CTF, spline,
                            oldLength, 0 ,0 , &bytesRead , &t->ctfData, spline, oldLength != 0 ? (spline+oldLength) : t->tableEnd );
 
        thisLength         = 0;
        totalBytesRead    += bytesRead;
#ifdef DECOMPRESS_ON
        if ( bytesRead > 2 ) {
            thisLength = MTX_Glyph_WriteTTFSpline( glyph, destSfnt, outPos, maxOutSize ); /* Write to outPos, use as tmp memory */
            /* We need to do this here since the glyph object can not access these fields */
            if ( TTF_To_CTF ) {
                t->ctfData.ctf1     = (unsigned char *)*destSfnt;
                t->ctfData.ctfSize1 = *maxOutSize;
            } else if ( (*destSfnt) == (char *)t->ctfData.ctf1 ) {
                t->ttf        = *destSfnt;
                t->ttfSize    = *maxOutSize;
            }
        }
#endif

        if ( TTF_To_CTF ) {
            /* UNDO and go to CTTF intstead */
            /*assert( bytesRead == thisLength ); */
#ifdef COMPRESS_ON
            if (glyph)
            {
                thisLength = MTX_Glyph_WriteCTFSpline( glyph, destSfnt, outPos, maxOutSize );
                /* We need to do this here since the glyph object can not access these fields */
                t->ctfData.ctf1      = (unsigned char *)*destSfnt;
                t->ctfData.ctfSize1  = *maxOutSize;
            }
            else
                t->mem->env = 0; /* clear any error and continue */
#endif
            outPos += thisLength;
        } else {
            outPos += thisLength;
            if ( outPos & 1 ) { /* Odd offset */
                (*destSfnt)[outPos++] = 0; /* Zero Pad */
            }
        }
        MTX_Glyph_Destroy( glyph );
    }
    posTable[ glyphIndex ] = outPos - startPos;
    assert( totalBytesRead > 0 );

    return outPos - startPos; /*****/
}




/* Converts the cvt table both ways between ttf and cvt formats */
static long ConvertCvtTable( TTF_Converter *t, int TTF_To_CTF, char *cvtIn, long lengthIn, char * *destSfnt, long pos, long *maxOutSize  )
{
    long j, k, dx, length;
    short x, *cvt0;
    char *p0;
    
    cvt0 = (short *)(p0 = cvtIn); /* These pointers do not get reallocated */
    
    x = 0;
    if ( TTF_To_CTF ) {
        char *cvtOut, *p1; /* Only assign these pointers after AllocateTTFSpace has been invoked */
        k = lengthIn/2;
        
        /* Check all entries */
        CheckReadBoundsForTable( t, (char *)&cvt0[0], 2 * k );
#ifdef COMPRESS_ON
        AllocateTTFSpace( t, destSfnt, pos, 2 + k*3, maxOutSize ); /* Allocate for worst case scenario */
        CHECKLASTERROR(t->mem->env);
        p1 = cvtOut = &(*destSfnt)[pos];
        
        WRITEWORD_INC( &p1, (short)k );
        for ( j = 0; j < k; j++ ) {
            dx = SWAPENDS_16(cvt0[j]) - x;
            x = (short)(x+dx);
            assert( x == SWAPENDS_16(cvt0[j]) );
            WriteCVTShort( (unsigned char **)&p1, (short)dx );
        }
        length = (long)(p1 - cvtOut);
#endif
    } else {
#ifdef DECOMPRESS_ON
        short *cvt1; /* Only assign this pointer after AllocateTTFSpace has been invoked */
        k = READWORD_INC( &p0 );
        length = k * sizeof( short );
        AllocateTTFSpace( t, destSfnt, pos, length, maxOutSize );
        CHECKLASTERROR(t->mem->env);
        cvt1 = (short *)&(*destSfnt)[pos];

        for ( j = 0; j < k; j++ ) {
            dx = ReadCVTShort( (unsigned char **)&p0 );
            x = (short)(x+dx);
            cvt1[j] = SWAPENDS_16(x);
        }
#endif
    }
    return length; /*****/
}



/* Set bit to 1 */
static void SetBitToOne( unsigned char *base, long bitOffset )
{
    long bitNumber = bitOffset % 8;
    base += bitOffset / 8;
    *base |= (1U << bitNumber);
}

/* Set bit to 0 */
static void SetBitToZero( unsigned char *base, long bitOffset )
{
    long bitNumber = bitOffset % 8;
    base += bitOffset / 8;
    *base &= ~(1U << bitNumber);
}

/* Read a bit */
static short ReadBit( unsigned char *base, long bitOffset )
{
    long bitNumber = bitOffset % 8;
    base += bitOffset / 8;
    return (short)((*base & (1U << bitNumber) ) ? 1 : 0); /*****/
}

/* Read an hdmx value in the ctf format */
static short ReadHdmxValue( unsigned char *base, long *bitOffset )
{
    short value, bit;
    
    for ( value = 0;; value++ ) {
        /*        assert( value < 16 );  this assert is not valid? */
        bit = ReadBit( base, (*bitOffset)++ );
        if ( bit == 0 ) {
            if ( value == 0 ) break; /******/
            bit = ReadBit( base, (*bitOffset)++ );
            if ( bit ) value = (short)-value;
            break; /******/
        }
    }
    return value; /*****/
}

#ifdef COMPRESS_ON
/* Write an hdmx value in the ctf format */
static void WriteHdmxValue( short value, unsigned char *base, long *bitOffset )
{
    if ( value == 0 ) {
        SetBitToZero( base, (*bitOffset)++ );
    } else {
        short i, absValue = value;
    
        if ( absValue < 0 ) absValue = (short)-absValue;
        for ( i = 0; i < absValue; i++ ) {
            SetBitToOne( base, (*bitOffset)++ );
        }
        SetBitToZero( base, (*bitOffset)++ );
        if ( value > 0 ) {
            SetBitToZero( base, (*bitOffset)++ );
        } else {
            SetBitToOne( base, (*bitOffset)++ );
        }
    }
}
#endif /* COMPRESS_ON */


/* Converts the VDMX table both ways between the ttf and ctf format */
/* Returns lengthOut */
static long ConvertVDMXTable( TTF_Converter *t, int TTF_To_CTF, char *VDMXIn, long lengthIn, char * *destSfnt, long pos, long *maxOutSize, long *assertlen )
{
    unsigned short i; 
    long k;
    uint16 numRatios, offsetValue;
    uint16 ppem;
    int16 yMax, yMin;
    uint16 Predicted_ppem;
    int16 Predicted_yMax, Predicted_yMin;
    int16 ppemError, yMaxError, yMinError;
    long yMaxMultiplier, yMinMultiplier;
    long bitOffset, length = 0;
    short numGroupRecs;
    unsigned short version;
    /* Harmless pointers relalated to VDMXIn */
    char *p, *pIn;
    /* Pointers that we need to be careful with since we may reallocate the memory they point at ! */
    char *VDMXOut;
    char *groups; 
    char *pOut;                /* Never used at all when going from CTF to TTF format */
    unsigned char *base;    /* Only used for input when going from CTF to TTF format */
    
    AllocateTTFSpace( t, destSfnt, pos, lengthIn, maxOutSize );
    CHECKLASTERROR(t->mem->env);
    VDMXOut = &(*destSfnt)[pos];
    /* Initial Copy */
    CheckReadBoundsForTable( t, (char *)VDMXIn, lengthIn);
    memcpyHuge( VDMXOut, VDMXIn, lengthIn );

    if (!TTF_To_CTF){
                version = *((unsigned short*)VDMXIn);
                version = SWAPENDS_U16( version );
        /* check to see if we have special version number */
        if (version > 0xFFF0) {
            /* the data is in regular VDMX format, we do not need to convert, just return */
            version = (unsigned short)(0xFFFF - version);
            version = SWAPENDS_U16( version );
            *((unsigned short*)VDMXOut) = version;
            return (lengthIn); /*****/
        }
    }
    p = VDMXIn; p += 2 * sizeof( uint16 );
    CheckReadBoundsForTable( t, p, 2); /* numRatios */
    numRatios = READWORD_INC( &p );
    
    {
        char *offset; /* Harmless pointer relalated to VDMXIn */
        
        offset  = VDMXIn;
        offset += sfnt_vdmxFormatSize + (numRatios-1) * sfnt_vdmxRatio_Size;
        assert( sfnt_vdmxFormatSize == 10 );
        assert( sfnt_vdmxRatio_Size == 4 );

        p = offset;
        CheckReadBoundsForTable( t, p, 2);
        offsetValue = READWORD_INC( &p );

        pOut = (char __huge *)VDMXOut + offsetValue;
        pIn  = (char __huge *)VDMXIn  + offsetValue;
        p      = offset;
    }
    for ( i = 0; i < numRatios; i++ ) {
        CheckReadBoundsForTable( t, p, 2);
        offsetValue = READWORD_INC( &p );
        if ( TTF_To_CTF ) {
#ifdef COMPRESS_ON
            long yMaxRatio, yMinRatio; /* 16.16 fixpoint */
            
            yMaxRatio = yMinRatio = 0;
            groups = (VDMXIn + offsetValue);
            CheckReadBoundsForTable( t, (char *)GET_vdmxGroup_recs_Ptr( groups ), vdmxGroupSize ); /* groups->recs */
            numGroupRecs = SWAPENDS_U16(*GET_vdmxGroup_recs_Ptr( groups ));
            /* Check all entries */
            CheckReadBoundsForTable( t, (char *)GET_vdmxGroup_entry_yPelHeight_Ptr( groups, 0 ), vdmxTableSize * numGroupRecs); /* yPelHeight, yMax, yMin */
            for ( k = 0; k < numGroupRecs; k++ ) {
                ppem = SWAPENDS_U16(*GET_vdmxGroup_entry_yPelHeight_Ptr( groups, k ));
                yMax = SWAPENDS_16(*GET_vdmxGroup_entry_yMax_Ptr( groups, k ));
                yMin = SWAPENDS_16(*GET_vdmxGroup_entry_yMin_Ptr( groups, k ));
                yMaxRatio += (((long)yMax << 16)+(long)ppem/2)/ ppem; /* 16.16 */
                yMinRatio += (((long)yMin << 16)-(long)ppem/2)/ ppem;
            }
            yMaxRatio = (yMaxRatio+(long)numGroupRecs/2)/ numGroupRecs;
            yMinRatio = (yMinRatio-(long)numGroupRecs/2)/ numGroupRecs;
            yMaxMultiplier = (long)((yMaxRatio + 16) >> 5); /* convert to 21.11 */
            yMinMultiplier = (long)((-yMinRatio + 16) >> 5);
            
            WRITEWORD_INC( &pOut, numGroupRecs );
            WRITEWORD_INC( &pOut, (short)yMaxMultiplier );
            WRITEWORD_INC( &pOut, (short)yMinMultiplier );
            base = (unsigned char *)pOut;
#endif
        } else {
#ifdef DECOMPRESS_ON
            groups = (VDMXOut + offsetValue);

            numGroupRecs    = READWORD_INC( &pIn ); /* groups->recs */
            *GET_vdmxGroup_recs_Ptr( groups )    = SWAPENDS_16( numGroupRecs );
            /* groups->startSize; DownStream in the code */
            /* groups->endSize;   DownStream in the code */
            yMaxMultiplier    = READWORD_INC( &pIn );
            yMinMultiplier    = READWORD_INC( &pIn );
            base = (unsigned char *)pIn;
            length = (long)((char __huge *)GET_vdmxGroup_entry_yPelHeight_Ptr( groups, numGroupRecs ) - (char __huge *)VDMXOut);
            AllocateTTFSpace( t, destSfnt, pos, length, maxOutSize );
            CHECKLASTERROR(t->mem->env);
            /* Reset pointers dependent on destSfnt */
            VDMXOut = &(*destSfnt)[pos];
            groups = (VDMXOut + offsetValue);
#endif
        }
        

        
        bitOffset = 0;
        Predicted_ppem = 8;
        for ( k = 0; k < numGroupRecs; k++ ) {
            if ( TTF_To_CTF ) {
                long newLength;
#ifdef COMPRESS_ON
                /* We have already bounds-checked this data  */
                ppem = SWAPENDS_U16(*GET_vdmxGroup_entry_yPelHeight_Ptr( groups, k ));
                yMax = SWAPENDS_16(*GET_vdmxGroup_entry_yMax_Ptr( groups, k ));
                yMin = SWAPENDS_16(*GET_vdmxGroup_entry_yMin_Ptr( groups, k ));
                
                /* Predicted_ppem; */
                Predicted_yMax = (short)((ppem * yMaxMultiplier + 1024L + 0) / 2048L);
                Predicted_yMin = (short)((ppem * yMinMultiplier + 1024L - 0) / 2048L);
                Predicted_yMin = (short)-Predicted_yMin;
                
                ppemError = (short)(ppem - Predicted_ppem);
                yMaxError = (short)(yMax - Predicted_yMax);
                yMinError = (short)(yMin - Predicted_yMin);
                
                newLength = (long)((char *)base + (bitOffset + abs(ppemError)+abs(yMaxError)+abs(yMinError)+6 + 7)/8  - VDMXOut);
                if ( newLength > lengthIn ){ /* Changed trigger from roughly 150% to 100% --- Sampo Oct 1, 1996 */
                    /* we have a problem, set version to 0xFFFF-real version and just copy data */
                    /* I wonder if we ever get here (seems unlikely) ???? ---Sampo Oct 1, 1996 */
                    
                    #if defined(MTX_DEBUG) && !defined(_WINDOWS)
                        printf("Bailing out of hdmx code\n");
                    #endif
                    memcpyHuge((char *)VDMXOut,(char *)VDMXIn,lengthIn);
                    version = *((unsigned short*)VDMXOut);
                    version = (unsigned short)SWAPENDS_U16( version );
                    version = (unsigned short)(0xFFFF - version);
                    version = SWAPENDS_U16( version );
                    *((unsigned short*)VDMXOut) = version;
                    return (lengthIn); /*****/
                } else {
                    /* We know that we already have lengthIn bytes available so we are OK here */
                    WriteHdmxValue( ppemError, base, &bitOffset );
                    WriteHdmxValue( yMaxError, base, &bitOffset );
                    WriteHdmxValue( yMinError, base, &bitOffset );
                }
#endif
            } else {
#ifdef DECOMPRESS_ON
                ppemError = ReadHdmxValue( base, &bitOffset );
                yMaxError = ReadHdmxValue( base, &bitOffset );
                yMinError = ReadHdmxValue( base, &bitOffset );

                ppem = (unsigned short)(Predicted_ppem + ppemError);
                Predicted_yMax = (short)((ppem * yMaxMultiplier + 1024L + 0) / 2048L);
                Predicted_yMin = (short)((ppem * yMinMultiplier + 1024L - 0) / 2048L);
                Predicted_yMin = (short)(-Predicted_yMin);
                yMax = (short)(Predicted_yMax + yMaxError);
                yMin = (short)(Predicted_yMin + yMinError);

                *GET_vdmxGroup_entry_yPelHeight_Ptr( groups, k )    = SWAPENDS_U16(ppem);
                *GET_vdmxGroup_entry_yMax_Ptr( groups, k ) = SWAPENDS_16(yMax);
                *GET_vdmxGroup_entry_yMin_Ptr( groups, k ) = SWAPENDS_16(yMin);
                if ( k == 0 ) {
                    *GET_vdmxGroup_startSize_Ptr( groups ) = (uint8)ppem; /* uint8, no swapping needed */
                } else if ( k == (long)SWAPENDS_U16(*GET_vdmxGroup_recs_Ptr( groups ))-1 ) {
                    *GET_vdmxGroup_endSize_Ptr( groups ) = (uint8)ppem; /* uint8, no swapping needed */
                }
#endif /* DECOMPRESS_ON */
            }
            Predicted_ppem = (short)(ppem + 1);
        }
        if ( TTF_To_CTF ) {
            while ( bitOffset & 7 ) SetBitToZero( base, bitOffset++ );
            assert( (bitOffset & 7) == 0 );
            pOut = (char __huge *)base + (bitOffset + 7)/8;
        } else {
            pIn = (char __huge *)base + (bitOffset + 7)/8;
            length = (long)((char __huge *)GET_vdmxGroup_entry_yPelHeight_Ptr( groups, numGroupRecs ) - (char __huge *)VDMXOut);
        }
    }
    
    if ( TTF_To_CTF ) {
        length = (long)((char __huge *)pOut - (char __huge *)VDMXOut);
        *assertlen = length;  /* length of the data, this is used only for the assert check upon return */
    } else {
        *assertlen = length;  /* exclude the pad bytes, this is used only for the assert check upon return */
        while ( length & 3 ) VDMXOut[length++] = 0; /* long word align */
    }

    return length; /******/
}



/* These two data structures are used for the ctf format */
#ifdef OLD
    typedef struct {
        uint8 ppem;
        uint8 maxWidth;
    } ctf_devMetricSubRecordType;

    typedef struct {
        int16                        version;
        int16                        numRecords;
        int32                        recordSize;
        ctf_devMetricSubRecordType    subRecord[1]; /* Really numRecords long */
        /* Here we have bit encoded values for all the device delta advance width values */
    } ctf_devMetricRecordType;
#endif /* OLD */

#define GET_ctf_hdmx_version_Ptr( ctf_devMetrics )    ((int16 *)((char __huge *)(ctf_devMetrics) + 0))
#define GET_ctf_hdmx_numRecords_Ptr( ctf_devMetrics )    ((int16 *)((char __huge *)(ctf_devMetrics) + 2))
#define GET_ctf_hdmx_recordSize_Ptr( ctf_devMetrics )    ((int32 *)((char __huge *)(ctf_devMetrics) + 4))
#define GET_ctf_hdmx_ppem_Ptr( ctf_devMetrics, i )    ((uint8 *)((char __huge *)(ctf_devMetrics) + 8 + (i) * 2 ))
#define GET_ctf_hdmx_maxWidth_Ptr( ctf_devMetrics, i )    ((uint8 *)((char __huge *)(ctf_devMetrics) + 8 + (i) * 2 + 1 ))


static uint32 CalcTableCheckSum( uint32 *table, uint32 length )
{
    uint32 sum = 0L;
    uint32 *endPtr = (uint32 __huge *)table + ((length+3) & ~3) / sizeof( uint32 );
    
    while ( table < endPtr ) {
        sum += SWAPENDS_U32(*table++);
    }
    return sum; /******/
}

static uint32 CalcFontCheckSum( uint32 *sfnt, uint32 length )
{
    uint32 sum = 0L;
    uint32 *endPtr = (uint32 __huge *)sfnt + ((length+3) & ~3) / sizeof( uint32 );
    
    while ( sfnt < endPtr ) {
        sum += SWAPENDS_U32(*sfnt++);
    }
    return 0xB1B0AFBA - sum; /******/
}


/* Converts the hdmx table both ways between the ttf and the ctf format */
#ifdef COMPRESS_ON
static long ConvertHdmxTable( TTF_Converter *t, int TTF_To_CTF, char *inFont, char *hdmxIn, long lengthIn, char * *destSfnt, long pos, long *maxOutSize )
#else
static long ConvertHdmxTable( TTF_Converter *t, int TTF_To_CTF, char *inFont, char *hdmxIn, long lengthIn, char * *destSfnt, long pos, long *maxOutSize)
#endif
{
    long numEntries;
    unsigned short glyphIndex;
    short *awArray, aw, lsb, ppem;
    unsigned short unitsPerEm;
    short recordNumber;
    //    double scale, idealAW;
    long rounded_TT_AW;
    long bitOffset = 0;
    long ctfHeaderSize, length;
    /* Pointers that we need to be careful with since we may reallocate the memory they point at ! */
    char                     *hdmxOut = &(*destSfnt)[pos];
    char                    *devMetrics;
    char                    *ctf_devMetrics;
    

    if ( TTF_To_CTF ) {
        /* We do not need to check for out of bounds read since we have already
          checked that the head table is big enough and inside the input data */
        unitsPerEm        = SWAPENDS_U16( GET_head_unitsPerEm( GetTablePtr( t->ttf, tag_FontHeader ) ) );
        devMetrics        = hdmxIn;
        ctf_devMetrics    = hdmxOut;
    } else {
        unitsPerEm        = SWAPENDS_U16(GET_head_unitsPerEm( GetTablePtr( (char *)t->ctfData.ctf1, tag_FontHeader ) ) );
        devMetrics        = hdmxOut;
        ctf_devMetrics    = hdmxIn;
        if (SWAPENDS_U16((unsigned short)*GET_ctf_hdmx_version_Ptr( ctf_devMetrics )) > 0xFFF0) {
            /* just do a straight copy and return */
            AllocateTTFSpace( t, destSfnt, pos, lengthIn, maxOutSize );
            CHECKLASTERROR(t->mem->env);
            /* Update dependencies on destSfnt */
            hdmxOut            = &(*destSfnt)[pos];
            devMetrics        = hdmxOut;
            
            memcpyHuge((char *)hdmxOut, (char *)hdmxIn, lengthIn);
            
            *GET_hdmx_version_Ptr( devMetrics ) = (short)(0xFFFF - SWAPENDS_16(*GET_ctf_hdmx_version_Ptr( ctf_devMetrics )));
            *GET_hdmx_version_Ptr( devMetrics ) = SWAPENDS_16(*GET_hdmx_version_Ptr( devMetrics ));
            return (lengthIn); /*****/
        }
    }
    numEntries    = GetNumberOfGlyphs( inFont );
    awArray        = (short *)MTX_mem_malloc( t->mem, sizeof( short ) * numEntries );
    CHECKLASTERROR(t->mem->env);
    
    for ( glyphIndex = 0; glyphIndex < (unsigned short)numEntries; glyphIndex++ ) {
        GetMetrics( t, inFont, glyphIndex, &aw, &lsb );
        CHECKLASTERROR(t->mem->env);
        awArray[ glyphIndex ] = aw;
    }


    if ( TTF_To_CTF ) {
        CheckReadBoundsForTable( t, devMetrics, sfnt_devMetricsSize );
        CHECKLASTERROR(t->mem->env);
        *GET_ctf_hdmx_version_Ptr( ctf_devMetrics )        = *GET_hdmx_version_Ptr( devMetrics );
        *GET_ctf_hdmx_numRecords_Ptr( ctf_devMetrics )    = *GET_hdmx_numRecords_Ptr( devMetrics );
        *GET_ctf_hdmx_recordSize_Ptr( ctf_devMetrics )    = *GET_hdmx_recordSize_Ptr( devMetrics );
        ctfHeaderSize = 8 + SWAPENDS_16(*GET_hdmx_numRecords_Ptr( devMetrics )) * 2;
        AllocateTTFSpace( t, destSfnt, pos, ctfHeaderSize, maxOutSize );
        CHECKLASTERROR(t->mem->env);
        /* Update dependencies on destSfnt */
        hdmxOut            = &(*destSfnt)[pos];
        ctf_devMetrics    = hdmxOut;
    } else {
        length = 8 + SWAPENDS_16(*GET_ctf_hdmx_numRecords_Ptr( ctf_devMetrics )) * SWAPENDS_32(*GET_ctf_hdmx_recordSize_Ptr( ctf_devMetrics ));
        AllocateTTFSpace( t, destSfnt, pos, length, maxOutSize );
        CHECKLASTERROR(t->mem->env);
        /* Update dependencies on destSfnt */
        hdmxOut            = &(*destSfnt)[pos];
        devMetrics        = hdmxOut;
        
        *GET_hdmx_version_Ptr( devMetrics )    = *GET_ctf_hdmx_version_Ptr( ctf_devMetrics );
        *GET_hdmx_numRecords_Ptr( devMetrics ) = *GET_ctf_hdmx_numRecords_Ptr( ctf_devMetrics );
        *GET_hdmx_recordSize_Ptr( devMetrics ) = *GET_ctf_hdmx_recordSize_Ptr( ctf_devMetrics );
        ctfHeaderSize = 8 + SWAPENDS_16(*GET_hdmx_numRecords_Ptr( devMetrics )) * 2;
    }
    /*assert( unitsPerEm == 2048 ); */
    
    for ( recordNumber = 0; recordNumber < SWAPENDS_16(*GET_hdmx_numRecords_Ptr( devMetrics )); recordNumber++ ) {
        char *devSubRecord; /* This is never reallocated ! */
        if ( TTF_To_CTF ) {
            devSubRecord = ((char __huge *)hdmxIn + 8 + recordNumber * SWAPENDS_32(*GET_hdmx_recordSize_Ptr( devMetrics )) );
            CheckReadBoundsForTable( t, devSubRecord, 2 ); /* ppem, maxWidth */
            CHECKLASTERROR(t->mem->env);
            *GET_ctf_hdmx_ppem_Ptr( ctf_devMetrics, recordNumber )        = *GET_hdmxSubRecord_ppem_Ptr( devSubRecord );        /* uint8 */
            *GET_ctf_hdmx_maxWidth_Ptr( ctf_devMetrics, recordNumber )    = *GET_hdmxSubRecord_maxWidth_Ptr( devSubRecord );    /* uint8 */
        } else {
            devSubRecord = ((char __huge *)hdmxOut + 8 + recordNumber * SWAPENDS_32(*GET_hdmx_recordSize_Ptr( devMetrics )) );
            *GET_hdmxSubRecord_ppem_Ptr( devSubRecord )        = *GET_ctf_hdmx_ppem_Ptr( ctf_devMetrics, recordNumber );        /* uint8 */
            *GET_hdmxSubRecord_maxWidth_Ptr( devSubRecord )    = *GET_ctf_hdmx_maxWidth_Ptr( ctf_devMetrics, recordNumber );    /* uint8 */
        }
        ppem  = *GET_hdmxSubRecord_ppem_Ptr( devSubRecord ); /* uint8 */
        //        scale = (double)ppem / (double)unitsPerEm;
        
        if ( TTF_To_CTF ) {
            /* Check all entries */
            CheckReadBoundsForTable( t, (char *)GET_hdmxSubRecord_width_Ptr( devSubRecord, 0 ), 1*numEntries );
            CHECKLASTERROR(t->mem->env);
        }
        for ( glyphIndex = 0; glyphIndex < (unsigned short)numEntries; glyphIndex++ ) {
            //            idealAW = scale * (double)awArray[ glyphIndex ];
            rounded_TT_AW = ((((long)64 * (long)ppem * (long)awArray[ glyphIndex ])+(long)unitsPerEm/2) / (long)unitsPerEm);
            rounded_TT_AW += 32;
            rounded_TT_AW /= 64;
            if ( TTF_To_CTF ) {
                long newSize;
#ifdef COMPRESS_ON
                short deltaAW = (short)(*GET_hdmxSubRecord_width_Ptr( devSubRecord, glyphIndex ) - rounded_TT_AW); /* widths is uint8 */
                newSize = ctfHeaderSize + (bitOffset+abs(deltaAW)+2+7)/8;
                if ( newSize > lengthIn ) { /* Changed from roughly > 150% to > 100% ---Sampo Oct 1, 1996 */
                    /* we have a problem, set version to 0xFFFF-real version and just copy data */
                    /* I wonder if we ever get here (seems unlikely) ???? ---Sampo Oct 1, 1996 */
                    #if defined(MTX_DEBUG) && !defined(_WINDOWS)
                        printf("Bailing out of hdmx code\n");
                    #endif
                    AllocateTTFSpace( t, destSfnt, pos, lengthIn, maxOutSize );
                    CHECKLASTERROR(t->mem->env);
                    /* Update dependencies on destSfnt */
                    hdmxOut         = &(*destSfnt)[pos];
                    ctf_devMetrics    = hdmxOut;

                    memcpyHuge((char *)hdmxOut,(char *)hdmxIn,lengthIn);
                    *GET_ctf_hdmx_version_Ptr( ctf_devMetrics ) = (short)(0xFFFF - SWAPENDS_16(*GET_hdmx_version_Ptr( devMetrics )));
                    *GET_ctf_hdmx_version_Ptr( ctf_devMetrics ) = SWAPENDS_16(*GET_ctf_hdmx_version_Ptr( ctf_devMetrics ));
                    MTX_mem_free( t->mem,awArray);
                    return (lengthIn); /*****/
                } else {
                    AllocateTTFSpace( t, destSfnt, pos, newSize, maxOutSize );
                    CHECKLASTERROR(t->mem->env);
                    /* Update dependencies on destSfnt */
                    hdmxOut         = &(*destSfnt)[pos];
                    ctf_devMetrics    = hdmxOut;
                    WriteHdmxValue( deltaAW, (unsigned char __huge *)hdmxOut + ctfHeaderSize, &bitOffset );
                }
#endif
            } else {
#ifdef DECOMPRESS_ON
                *GET_hdmxSubRecord_width_Ptr( devSubRecord, glyphIndex ) = (unsigned char)(rounded_TT_AW + ReadHdmxValue( (unsigned char __huge *)hdmxIn + ctfHeaderSize, &bitOffset )); /* widths is uint8 */
#endif
            }
        }

        if ( !TTF_To_CTF ) {
            char *p = (char *)GET_hdmxSubRecord_width_Ptr( devSubRecord, numEntries );

            while ( ((p - t->ttf) & 3) != 0 ) {
                *p++ = 0; /* pad with zeroes to long word align */
            }
        }

    }
    
    MTX_mem_free( t->mem, awArray );
    
    length = lengthIn;
    if ( TTF_To_CTF ) {
        while ( bitOffset & 7 ) SetBitToZero( (unsigned char __huge *)hdmxOut + ctfHeaderSize, bitOffset++ );
        length = ctfHeaderSize + (bitOffset+7)/8;
    } else {
        length = 8 + SWAPENDS_16(*GET_hdmx_numRecords_Ptr( devMetrics )) * SWAPENDS_32(*GET_hdmx_recordSize_Ptr( devMetrics ));
    }
    return length; /*****/
}




/* The method to do the big conversion between TTF and CTF */
static int Convert_FONT( TTF_Converter *t, int TTF_To_CTF  )
{
    long i, j, pos, oldPos, headerSize;
    const long zero = 0L;
    long maxOutSize, inSize;
    /* Harmless pointers */
    long *posTable;
    char *sfnt0;
    /* Pointer  which may be reallocated */
    char *sfnt1;
    long assertlen;  /* len used in assert checking */
    
    if ( TTF_To_CTF ) {
        sfnt0 = t->ttf; /* TTF -> CTF */
        sfnt1 = (char *)t->ctfData.ctf1;
        inSize        = t->ttfSize;
        maxOutSize = t->ctfData.ctfSize1;
    } else {
        sfnt0 = (char *)t->ctfData.ctf1; /* CTF -> TTF */
        sfnt1      = t->ttf;
        inSize     = t->ctfData.ctfSize1;
        maxOutSize = t->ttfSize;
    }
    
    
    /* Do some sanity checking on the data */
    if ( SWAPENDS_U16(GET_sfnt_numOffsets( sfnt0 )) * (unsigned long)DirectoryEntrySize >= (unsigned long)inSize/2 ) {
        SETLASTERROR( t->mem->env, ERR_Convert_FONT_too_many_tables )
    }
    for ( i = 0; i < (long)SWAPENDS_U16(GET_sfnt_numOffsets( sfnt0 )); i++ ) {
        unsigned long length = SWAPENDS_U32(GET_sfnt_table_length( sfnt0, i ));
        if ( length != 0 ) {
            unsigned long offset = SWAPENDS_U32(GET_sfnt_table_offset( sfnt0, i ));
            if ( offset >= (unsigned long)inSize ) {
                SETLASTERROR( t->mem->env, ERR_Convert_FONT_table_outside )
            }
            if ( offset + length > (unsigned long)inSize ) {
                SETLASTERROR( t->mem->env, ERR_Convert_FONT_table_end_outside )
            }
        }
    }
    /* Now we know all font tables are inside the font. This means that we do not
       need to check the result of GetTablePtr, since we know that all tables
       are inside the font */
    /* tag_FontHeader 'head' table is 54 bytes long */
    if ( GetTableLength( sfnt0, tag_FontHeader ) < 54 )
        SETLASTERROR( t->mem->env, ERR_head_table_gone_or_to_short );
    {
        char *head = GetTablePtr( sfnt0, tag_FontHeader );
        if ( SWAPENDS_U32(GET_head_magicNumber( head )) != 0x5F0F3CF5 )
            SETLASTERROR( t->mem->env, ERR_Convert_FONT_bad_magic );
        if ( SWAPENDS_16(GET_head_glyphDataFormat( head )) != 0 )
            SETLASTERROR( t->mem->env, ERR_Convert_FONT_unknown_glyphDataFormat );
    }
    /* tag_HoriHeader 'hhea' table is 36 bytes long */
    if ( GetTableLength( sfnt0, tag_HoriHeader ) < 36 )
        SETLASTERROR( t->mem->env, ERR_hhea_table_gone_or_to_short );
    /* tag_MaxProfile 'maxp' table is 32 bytes long */
    if ( GetTableLength( sfnt0, tag_MaxProfile ) < 32 ) {
        /* For fonts with CFF outlines 'maxp' is only 6 bytes long - VL */
        if (!(SWAPENDS_32(GET_sfnt_fontVersion( sfnt0 )) == tag_OpenTypeCFF) &&
             (GetTableLength( sfnt0, tag_MaxProfile ) == 6) )       /* VL */
            SETLASTERROR( t->mem->env, ERR_maxp_table_gone_or_to_short );
    }
    /* if we have a 'glyf' table then we need a 'loca' table */
    if ( TTF_To_CTF && GetTableLength( sfnt0, tag_GlyphData ) > 0 && GetTableLength( sfnt0, tag_IndexToLoc ) == 0 ) {
        SETLASTERROR( t->mem->env, ERR_loca_table_gone_or_to_short )
    }
    
    /* Ok the input data seems valid if we get this far, so start the process */
    pos = headerSize = OFFSETTABLESIZE + (SWAPENDS_U16(GET_sfnt_numOffsets( sfnt0 )) * DirectoryEntrySize ); /* Header */
    AllocateTTFSpace( t, &sfnt1, 0, headerSize, &maxOutSize );
    memcpyHuge( (char *)(sfnt1), (char *)sfnt0, headerSize );

    posTable = (long *)MTX_mem_malloc( t->mem, sizeof( long ) * (GetNumberOfGlyphs( sfnt0 ) + 1) );
    CHECKLASTERROR(t->mem->env);
    
    for ( i = 0; i < (long)SWAPENDS_U16(GET_sfnt_numOffsets( sfnt0 )); i++ ) {
        short repeatTable;
        long myTag = SWAPENDS_32(GET_sfnt_table_tag( sfnt0, i ));

        oldPos = pos;
        /*assert( pos+(long)SWAPENDS(GET_sfnt_table_length( sfnt0, i ))+4 < maxOutSize ); */
        
        SET_sfnt_table_length( sfnt1, i, GET_sfnt_table_length( sfnt0, i ) );
        SET_sfnt_table_offset( sfnt1, i, SWAPENDS_32(pos) );
        /* Tolerate zero length tables */
        if ( TTF_To_CTF ) {
            if ( GET_sfnt_table_length( sfnt1, i ) == 0 ) continue; /******/
        } else if ( myTag != tag_IndexToLoc ) {
            /* The length of tag_IndexToLoc table in CTF is zero and we need to process it */
            if ( GET_sfnt_table_length( sfnt1, i ) == 0 ) continue; /******/
        }
        /* Scan for different name tags pointing at the same table */
        if ( GET_sfnt_table_length( sfnt1, i ) != 0 ) {
            repeatTable = false;
            for ( j = 0; j < i; j++ ) { 
                if ( GET_sfnt_table_length( sfnt0, j ) == 0 ) continue; /******/
                if ( GET_sfnt_table_offset( sfnt0, j ) == GET_sfnt_table_offset( sfnt0, i ) ) {
                    repeatTable = true;
                    /* If there is a match just copy these 3 fields, and then skip the table */
                    SET_sfnt_table_checkSum(    sfnt1,    i, GET_sfnt_table_checkSum( sfnt1, j ) );
                    SET_sfnt_table_offset(      sfnt1,    i, GET_sfnt_table_offset( sfnt1, j ) );
                    SET_sfnt_table_length(      sfnt1,    i, GET_sfnt_table_length( sfnt1, j ) );
                    break; /******/
                }
            }
            if ( repeatTable ) continue; /******/
        }
            
        t->tableStart     = (char *)&sfnt0[SWAPENDS_U32(GET_sfnt_table_offset( sfnt0, i ))];
        t->tableEnd       = (char __huge *)t->tableStart + SWAPENDS_U32(GET_sfnt_table_length( sfnt0, i ));

        switch( myTag ) {
            long theLength;
            case tag_GlyphData:
                theLength = ConvertGlyphTable( t, TTF_To_CTF, sfnt0, posTable,
                                                              &sfnt1, pos, &maxOutSize );
                CHECKLASTERROR(t->mem->env);
                pos += theLength;
                SET_sfnt_table_length( sfnt1, i, SWAPENDS_32(theLength) );
                if ( TTF_To_CTF ) {
                    t->ctfData.ctf1        = (unsigned char *)sfnt1;
                    t->ctfData.ctfSize1    = maxOutSize;
                } else {
                    t->ttf        = sfnt1;
                    t->ttfSize    = maxOutSize;
                }
                break; /******/
                
            case tag_IndexToLoc:
                if ( !TTF_To_CTF ) assert( GET_sfnt_table_length( sfnt0, i ) == 0 );
                SET_sfnt_table_offset( sfnt1, i, 0 ); /* set to zero length, not needed */
                SET_sfnt_table_length( sfnt1, i, 0 ); /* set to zero length, not needed */
                break; /*****/

            case tag_ControlValue:
                theLength = ConvertCvtTable( t, TTF_To_CTF, &sfnt0[SWAPENDS_U32(GET_sfnt_table_offset( sfnt0, i ))], SWAPENDS_U32(GET_sfnt_table_length( sfnt0, i )),
                                             &sfnt1, pos, &maxOutSize );
                pos += theLength;
                SET_sfnt_table_length( sfnt1, i, SWAPENDS_32(theLength) );
                break; /******/
            case tag_HoriDeviceMetrics:
                theLength = ConvertHdmxTable( t, TTF_To_CTF, sfnt0, &sfnt0[SWAPENDS_U32(GET_sfnt_table_offset( sfnt0, i ))], SWAPENDS_U32(GET_sfnt_table_length( sfnt0, i )),
                                              &sfnt1, pos, &maxOutSize );
                if (theLength == 0)
                {
                    /* recover from error in optional table */
                    t->mem->env = 0;  /* clear error */
                    SET_sfnt_table_checkSum( sfnt1, i, 0 );
                }
                pos += theLength;
                SET_sfnt_table_length( sfnt1, i, SWAPENDS_32(theLength) );
                break; /******/
                
            case tag_VertDeviceMetrics:
                theLength = ConvertVDMXTable( t, TTF_To_CTF, &sfnt0[SWAPENDS_U32(GET_sfnt_table_offset( sfnt0, i ))], SWAPENDS_U32(GET_sfnt_table_length( sfnt0, i )),
                                               &sfnt1, pos, &maxOutSize, &assertlen );
#ifdef MTX_DEBUG
                /* Assert that we can get back the TTF version from the CTF version */
                if ( TTF_To_CTF ) {
                    char *vdmx, *oldVDMX;
                    long loop, lengthOut;
                    
                    oldVDMX = &sfnt0[SWAPENDS_U32(GET_sfnt_table_offset( sfnt0, i ))];
                    vdmx = &sfnt1[pos + SWAPENDS_U32(GET_sfnt_table_length( sfnt1, i  ))];

                    /* De-compress into the output sfnt and see if we get the same thing back */
                    t->tableStart     = (char *)&sfnt1[pos];
                    t->tableEnd        = (char __huge *)t->tableStart + SWAPENDS_U32(GET_sfnt_table_length( sfnt1, i  ));
                    lengthOut = ConvertVDMXTable( t, !TTF_To_CTF, &sfnt1[pos], SWAPENDS_U32(GET_sfnt_table_length( sfnt1, i  )), &sfnt1, pos + SWAPENDS_U32(GET_sfnt_table_length( sfnt1, i  )), &maxOutSize, &assertlen );
                    
                    assert( ((lengthOut+3)&~3) == (((long)SWAPENDS_U32(GET_sfnt_table_length( sfnt0, i ))+3)&~3) ); /* assert that long aligned lengths match */
                    for ( loop = 0; loop < assertlen; loop++ ) {
                        assert( vdmx[loop] == oldVDMX[loop] );
                    }
                }
#endif  
                pos += theLength;
                if (theLength == 0)
                {
                    /* recover from error in optional table */
                    t->mem->env = 0;  /* clear error */
                    SET_sfnt_table_checkSum( sfnt1, i, 0 );
                }
                SET_sfnt_table_length( sfnt1, i, SWAPENDS_32(theLength) );
                break; /******/
            default:
                AllocateTTFSpace( t, &sfnt1, pos, SWAPENDS_U32(GET_sfnt_table_length( sfnt0, i )), &maxOutSize );
                CHECKLASTERROR(t->mem->env);
                memcpyHuge( (char *)&sfnt1[pos], (char *)&sfnt0[SWAPENDS_U32(GET_sfnt_table_offset( sfnt0, i ))], SWAPENDS_U32(GET_sfnt_table_length( sfnt0, i )) );
                pos += SWAPENDS_U32(GET_sfnt_table_length( sfnt0, i ));
                break; /******/
        }
        memcpyHuge( (char *)&sfnt1[pos], (char *)&zero, 4 );    /* Zero Pad */
        pos += 3; pos &= ~3;                                /* Long Word Align */
        
        if ( !TTF_To_CTF && myTag != tag_IndexToLoc && myTag != tag_FontHeader ) {
            /* CTF to TTF, and we do IndexToLoc, and the FontHeader later */
            SET_sfnt_table_checkSum( sfnt1, i, SWAPENDS_U32(CalcTableCheckSum( (uint32 *)&sfnt1[oldPos], SWAPENDS_U32( GET_sfnt_table_length( sfnt1, i  ) ) ) ) );
        }
        assert( pos < maxOutSize );
    }
    if ( TTF_To_CTF ) {
        t->ctfData.ctfSize1 = pos;
    } else {
        /* CTF to TTF */
        /* Add loca table */
        for ( i = 0; i < (long)SWAPENDS_U16( GET_sfnt_numOffsets(sfnt1) ); i++ ) {
            if ( SWAPENDS_32( GET_sfnt_table_tag( sfnt1, i ) ) == tag_IndexToLoc ) { 
                SET_sfnt_table_offset( sfnt1, i, SWAPENDS_32(pos) );
                SET_sfnt_table_length( sfnt1, i, SWAPENDS_32(Write_loca_Table( t, posTable, GetNumberOfGlyphs( sfnt0 ) + 1 , &sfnt1, pos, &maxOutSize) ) );
                oldPos = pos;
                pos += SWAPENDS_U32( GET_sfnt_table_length( sfnt1, i ) );
                memcpyHuge( (char *)&sfnt1[pos], (char *)&zero, 4 );    /* Zero Pad */
                pos += 3; pos &= ~3;                                /* Long Word Align */
                assert( pos < maxOutSize );
                SET_sfnt_table_checkSum( sfnt1, i, SWAPENDS_U32(CalcTableCheckSum( (uint32 *)&sfnt1[oldPos], SWAPENDS_U32(GET_sfnt_table_length( sfnt1, i )) ) ) );
                break;/******/
            }
        }
        t->ttfSize = pos;
        for ( i = 0; i < (long)SWAPENDS_U16( GET_sfnt_numOffsets(sfnt1) ); i++ ) {
            if ( SWAPENDS_32( GET_sfnt_table_tag( sfnt1, i ) ) == tag_FontHeader ) {
                char *head = (char *)&sfnt1[ SWAPENDS_U32(GET_sfnt_table_offset( sfnt1, i )) ];

                if ( 0 != GetTableLength(sfnt0, tag_GlyphData) )
                    SET_head_indexToLocFormat( head, SWAPENDS_16(t->indexToLocFormat) ); /* Set by Write_loca_Table, and it may have changed, so write it out */

                SET_head_checkSumAdjustment( head, 0 );
                SET_sfnt_table_checkSum( sfnt1, i, SWAPENDS_U32(CalcTableCheckSum( (uint32 *)head, SWAPENDS_U32(GET_sfnt_table_length( sfnt1, i )) ) ) );
                SET_head_checkSumAdjustment( head, SWAPENDS_U32( CalcFontCheckSum( (uint32 *)sfnt1, t->ttfSize ) ) );
                break; /******/
            }
        }
    }

    MTX_mem_free( t->mem, posTable );
    return 0;
}

#define not_valid_TTF 0
#define valid_TTF     1

/*  Checks that the data represents a TTF font, it returns either valid_TTF (true), or not_valid_TTF( false) */
int is_TTF_Test( unsigned char *t, long dataSize  )
{
    long i;
    //const long zero = 0L;
    long inSize;
    char *sfnt0;
    
    sfnt0 = (char *)t; 
    inSize = dataSize;
    
    /* Do some sanity checking on the data */
    if ( SWAPENDS_U16(GET_sfnt_numOffsets( sfnt0 )) * (unsigned long)DirectoryEntrySize >= (unsigned long)inSize/2 ) {
        return (not_valid_TTF);
    }
    for ( i = 0; i < (long)SWAPENDS_U16(GET_sfnt_numOffsets( sfnt0 )); i++ ) {
        unsigned long length = SWAPENDS_U32(GET_sfnt_table_length( sfnt0, i ));
        if ( length != 0 ) {
            unsigned long offset = SWAPENDS_U32(GET_sfnt_table_offset( sfnt0, i ));
            if ( offset >= (unsigned long)inSize ) {
                return (not_valid_TTF);
            }
            if ( offset + length > (unsigned long)inSize ) {
                return (not_valid_TTF);
            }
        }
    }
    /* Now we know all font tables are inside the font. This means that we do not
       need to check the result of GetTablePtr, since we know that all tables
       are inside the font */
    /* tag_FontHeader 'head' table is 54 bytes long */
    if ( GetTableLength( sfnt0, tag_FontHeader ) < 54 )
        return (not_valid_TTF);
    {
        char *head = GetTablePtr( sfnt0, tag_FontHeader );
        if ( SWAPENDS_U32(GET_head_magicNumber( head )) != 0x5F0F3CF5 )
            return (not_valid_TTF);
        if ( SWAPENDS_16(GET_head_glyphDataFormat( head )) != 0 )
            return (not_valid_TTF);
    }
    /* tag_HoriHeader 'hhea' table is 36 bytes long */
    if ( GetTableLength( sfnt0, tag_HoriHeader ) < 36 )
        return (not_valid_TTF);
    /* tag_MaxProfile 'maxp' table is 32 bytes long */
    if ( GetTableLength( sfnt0, tag_MaxProfile ) < 32 )
        /* For fonts with CFF outlines 'maxp' is only 6 bytes long - VL */
        if (!(SWAPENDS_32(GET_sfnt_fontVersion( sfnt0 )) == tag_OpenTypeCFF) &&
             (GetTableLength( sfnt0, tag_MaxProfile ) == 6) )       /* VL */
            return (not_valid_TTF);
    /* if we have a 'glyf' table then we need a 'loca' table */
    if ( GetTableLength( sfnt0, tag_GlyphData ) > 0 && GetTableLength( sfnt0, tag_IndexToLoc ) == 0 ) {
        return (not_valid_TTF);
    }
    return (valid_TTF);
}


/* Returns the TTF file size */
long MTX_TTC_GetTTFSize( TTF_Converter *t )
{
    return t->ttfSize; /*****/
}

#ifdef COMPRESS_ON
/* Converts the TTF file to three CTF memory pointers */
/* in, rest, data, code */
int MTX_TTC_TTF_To_CTF( TTF_Converter *t, unsigned char *ttfData, long ttfSize,
                             unsigned char * *ctf1, long *size1,
                             unsigned char * *ctf2, long *size2,
                             unsigned char * *ctf3, long *size3 )
{
    t->ttf                    = (char *)ttfData;
    t->ttfSize                = ttfSize;

    t->ctfData.ctf2Index       = 0;
    t->ctfData.ctfSize2        = 1024;
    t->ctfData.ctf2            = (unsigned char *)MTX_mem_malloc( t->mem, sizeof( char ) * t->ctfData.ctfSize2 );
    CHECKLASTERROR(t->mem->env);
    
    t->ctfData.ctf3Index       = 0;
    t->ctfData.ctfSize3        = 1024;
    t->ctfData.ctf3            = (unsigned char *)MTX_mem_malloc( t->mem, sizeof( char ) * t->ctfData.ctfSize3 );
    CHECKLASTERROR(t->mem->env);
    
    assert( t->ctfData.ctf1 == NULL );
    
    /* Allocate Memory */
    t->ctfData.ctfSize1 = t->ttfSize; /* Reduced to 100% of ttfSize instead of 150% Oct 2, 1996 -- Sampo */
    /* This just ensures that we do not grab too much memory and it also */
    /* ensures that most fonts will go through this code without requring the */
    /* memory to be reallocated. If this should be necessary everything is still OK */
    /* since the reallocation is automatic, and we can even set ctfSize to 1, and this */
    /* code will still work ! */
    /* Oct 2, 1996 ---Sampo */
    t->ctfData.ctf1 = (unsigned char *)MTX_mem_malloc( t->mem, sizeof( char ) * t->ctfData.ctfSize1 );
    CHECKLASTERROR(t->mem->env);

    Convert_FONT( t, true ); /* Do the work */
    CHECKLASTERROR(t->mem->env);
    
    /* Realloc to free excess memory */
    *size1   = t->ctfData.ctfSize1;
    *ctf1    = (unsigned char *)MTX_mem_realloc( t->mem, t->ctfData.ctf1, *size1 );
    CHECKLASTERROR(t->mem->env);
    /* Realloc to free excess memory */
    *size2   = t->ctfData.ctf2Index;
    *ctf2    = (unsigned char *)MTX_mem_realloc( t->mem, t->ctfData.ctf2, *size2 );
    CHECKLASTERROR(t->mem->env);
    /* Realloc to free excess memory */
    *size3   = t->ctfData.ctf3Index;
    *ctf3    = (unsigned char *)MTX_mem_realloc( t->mem, t->ctfData.ctf3, *size3 );
    CHECKLASTERROR(t->mem->env);
    return 0;
}

#endif /* COMPRESS_ON */


#ifdef DECOMPRESS_ON

/* Returns a pointer to the ttf in memory */
unsigned char *MTX_TTC_CTF_To_TTF( TTF_Converter *t, unsigned char *ctf1, long size1,
                                unsigned char *ctf2, long size2,
                                unsigned char *ctf3, long size3, long *ttSize)


{
    t->ctfData.ctf1         = ctf1;
    t->ctfData.ctfSize1     = size1;
    t->ctfData.ctf2         = ctf2;
    t->ctfData.ctfSize2     = size2;
    t->ctfData.ctf3         = ctf3;
    t->ctfData.ctfSize3     = size3;
    t->ctfData.ctf2Index     = 0;
    t->ctfData.ctf3Index     = 0;
    
    /* DeAllocate Memory */
    if ( t->ttf != NULL ) MTX_mem_free( t->mem, t->ttf );
    t->ttf = NULL;
    
    /* t->ttfSize = t->ctfSize + t->ctfSize; */
    /* t->ttfSize *= 3; */
    /* Old bogus allocation removed on Oct 2, 1996 ---Sampo */
    
    /* Allocate Memory */
    /* A least mean square linear approximation is */
    /* -6021.61 +  1.2486 * size1 + 1.74507 * size2 + 0.726595 * size3 */
    /* This was computed with some old Type Solutions matrix math code written by me. */
    /* We use the following overestimation instead which gives results bigger than the actual */
    /* ttf Size for all 40 test case. */
    /* 0 + 1.5 * size1 + 2 * size2 + 1 * size3 */
    /* This just ensures that we do not grab too much memory and it also */
    /* ensures that most fonts will go through this code without requring the */
    /* memory to be reallocated. If this should be necessary everything is still OK */
    /* since the reallocation is automatic, and we can even set ttfSize to 1, and this */
    /* code will still work ! */
    /* Oct 2, 1996 ---Sampo */
    t->ttfSize = size1 + (size1>>1) + size2 + size2 + size3;
    /* All work must be done in MTX memory, _not_ in user space - VL 20090914 */ 
    t->ttf = (char *)MTX_mem_malloc( t->mem, sizeof( char ) * t->ttfSize ); /* VL */
    CHECKLASTERROR(t->mem->env);
    if (t->ttf == NULL) SETLASTERROR( t->mem->env, ERR_no_more_memory );

#ifdef COMMENT
/* Oct 2, 1996 ---Sampo */
/* Here are the numbers for the 40 test cases */
Input size: 40 5
Input matrix:
constant size1 size2 size3 ttfSize
1 1353852 0 0  1685588
1 25576 8424 5239  44360
1 88072 40 30  88504
1 61844 40 30  62276
1 70868 15958 11053  107820
1 41676 0 0  49428
1 83200 32683 54914  192260
1 35976 11288 11971  68448
1 28992 21954 15013  83260
1 76736 3482 2982  101232
1 28980 9365 6725  52876
1 28660 10926 8027  55532
1 31532 8772 7203  56020
1 29612 9482 7414  52712
1 23708 9459 6821  44388
1 20248 14093 5326  43964
1 15656 13744 5340  39316
1 24632 7991 4566  42692
1 25668 12833 10634  64516
1 34292 12774 6985  71052
1 34304 17195 10846  76480
1 26860 9357 5820  55864
1 31296 10313 6903  53748
1 32208 11031 7731  56056
1 35420 7644 7150  58496
1 33480 7281 8127  55960
1 19248 6723 7830  38852
1 35572 7184 8604  60612
1 32176 11682 9635  60152
1 28024 12095 7761  54944
1 34532 7591 7707  56008
1 24892 6999 6610  44216
1 30508 7123 6694  51604
1 30008 15711 9287  62032
1 37328 10592 7468  64812
1 36256 13199 9878  68180
1 29212 19933 11734  69264
1 22296 9875 7545  45700
1 19412 6898 5201  36704
1 25144 13048 9461  54576

...
Projecting into the base function plane.
....

   
Reduced matrix:
1          0          0          0          -6021.61   
0          1          0          0          1.2486     
0          0          1          0          1.74507    
0          0          0          1          0.726595  
 
Error 0 = 1191.99   
Error 1 = -59.664   
Error 2 = -15532.6  
Error 3 = -9012.32  
Error 4 = -10523    
Error 5 = 3413.01   
Error 6 = -2536.21  
Error 7 = 1153.59   
Error 8 = 3862.56   
Error 9 = 3198.1    
Error 10 = 1484.27   
Error 11 = 869.742   
Error 12 = 2129.37   
Error 13 = -173.638  
Error 14 = -654.905  
Error 15 = -3759.15  
Error 16 = -2074.73  
Error 17 = 695.628   
Error 18 = 8367.46   
Error 19 = 6889.86   
Error 20 = 1782.53   
Error 21 = 7790.83   
Error 22 = -2319.14  
Error 23 = -3004.45  
Error 24 = 1757.76   
Error 25 = 1567.62   
Error 26 = 3419.23   
Error 27 = 3430.24   
Error 28 = -1387.97  
Error 29 = -770.864  
Error 30 = 66.2949   
Error 31 = 2140.94   
Error 32 = 2239.39   
Error 33 = -3579.05  
Error 34 = 315.91    
Error 35 = -1278.09  
Error 36 = -4498.83  
Error 37 = 1168.11   
Error 38 = 2671.29   
Error 39 = -441.165  

#endif /* COMMENT */
    
    Convert_FONT( t, false ); /*** Do the work ***/
    CHECKLASTERROR(t->mem->env);
        
    /* free excess memory */
    *ttSize = t->ttfSize;
    /* All work must be done in MTX memory, _not_ in user space. However, the final result has */
    /* to be returned to the caller in user space so that the MTX memory can be closed properly */
    /* VL - 20090916 */ 
    t->ttf = (char *)MTX_mem_realloc_in_user_space( t->mem, t->ttf, sizeof( char ) * t->ttfSize ); /* VL */
    CHECKLASTERROR(t->mem->env);

    if (t->ttf == NULL) SETLASTERROR( t->mem->env, ERR_no_more_memory );
    return (unsigned char *)t->ttf; /******/
}


#endif /* DECOMPRESS_ON */



/* Constructor */
TTF_Converter *MTX_TTC_Create( MTX_MemHandler *mem, short version )
{
    register TTF_Converter *t   = (TTF_Converter *)MTX_mem_malloc( mem, sizeof( TTF_Converter ) );
    CHECKLASTERROR(mem->env);
    t->mem                      = mem;
    
    InitCoordEncoding();
    t->ttf                      = NULL;
    t->ttfSize                  = 0;
    t->ctfData.ctf1             = NULL;
    t->ctfData.ctfSize1         = 0;
    t->ctfData.ctf2             = NULL;
    t->ctfData.ctfSize2         = 0;
    t->ctfData.ctf3             = NULL;
    t->ctfData.ctfSize3         = 0;
    t->convertFormat            = version;

    return t; /******/
}

/* Destructor */
void MTX_TTC__Destroy( TTF_Converter *t )
{
    MTX_mem_free( t->mem, t );
}
