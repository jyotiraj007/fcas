/* Copyright (C) 1989, 1990, 1991, 1992, 1993, 1994, 1995, 1996
 * all rights reserved, by Bayer Corp., Agfa Division, Wilmington, MA.
 *
 * This software is furnished under a license and may be used and
 * copied only in accordance with the terms of such license and with
 * the inclusion of the above copyright notice. This software or any
 * other copies thereof may not be provided or otherwise made
 * available to any other person except as allowed under license. No
 * title to and ownership of the software is hereby transferred.
 *
 * This information in this software is subject to change without notice
 */
/* $Header:   I:\bull\c_exprss\src\agfawrap.c_v   1.5   14 May 1997 17:17:12   MARTIN  $ */
/* $Log:   I:\bull\c_exprss\src\agfawrap.c_v  $
 * 
 *              04 Apr 2014            hadleyj
 *
 * Removed FAR declarations because we are not going to support Windows 16-bit.
 *
 *
 *              04 Apr 2014            hadleyj
 *
 * Initialize ierrorNumber in several places to keep the compiler happy.
 * 
 *    Rev 1.5   14 May 1997 17:17:12   MARTIN
 * 
 * Renamed MEMORY.H to MTXMEM.H.
 * 
 *    Rev 1.4   29 Apr 1997 14:34:02   MARTIN
 * 
 * Added _WINDOWS references and FAR declarations to support
 * 16-bit version.
 * 
 *    Rev 1.3   24 Mar 1997 11:25:34   MARTIN
 * 
 * Modified "wrapper" routines to return errcodes. Added Agfa_IS_MTX_Data.
 * 
 *    Rev 1.2   17 Jan 1997 12:21:16   MARTIN
 * 
 * Added HARD_DISK_ON conditional code.
 * 
 *    Rev 1.1   16 Jan 1997 15:50:28   MARTIN
 * 
 * Modifications to COMPRESS_ON and DECOMPRESS_ON conditional code.
 * 
 *    Rev 1.0   17 Dec 1996 16:31:24   MARTIN
 * Initial revision.
   
      Rev 1.6   09 Oct 1996 16:04:28   MARTIN
   
   Modifications for memory based version.
   
      Rev 1.5   08 Aug 1996 10:35:28   AL
   Added Exception handlers for system errors
   
      Rev 1.4   22 May 1996 15:47:56   MARTIN
   
   Added conditional compile around display_message routine.
   
      Rev 1.3   20 May 1996 15:10:32   MARTIN
   
   Replaced error messages with error codes.
   
      Rev 1.2   17 May 1996 09:12:12   MARTIN
   Made variable name changes.
   
      Rev 1.1   15 May 1996 17:38:54   MARTIN
   Added temporary file path name to arguments.
   
      Rev 1.0   13 May 1996 11:32:12   MARTIN
   Initial revision.
 */

/*
 * File:                            AGFAWRAP.C
 * Author:                            Paul Linnerud of Microsoft
 * Revised by:                      Sara Martin
 * First Version:                    May 13, 1996
 * First pure ANSI C version:        October 28, 1996  (Sampo).
 * Added a memory based interface
 * directly in AGFAWRAP.c with
 * optional auto deletion of the
 * input data.                        Nov 18, 1996 (Sampo).
 * Remove the use of setjmp and longjmp. August 6, 2014 (Taylor)
 */
#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#ifdef _WINDOWS
#include <windows.h>
#endif /* _WINDOWS */

#include "agfaconfig.h"
#include "agfacomp.h"
#include "mtxmem.h"
#include "errcodes.h"

#include "agfawrap.h"

#ifdef ENABLE_DISPLAY
void displayMessage (const int ierrorNumber);
#endif

/* Returns true if it seems like we have Agfa MicroType Express compressed data */
int Agfa_IS_MTX_Data( unsigned char *packed_Data, long packedDataSize )
{
    return( MTX_IS_MTX_Data( packed_Data, packedDataSize ) ); /******/
}

#ifdef COMPRESS_ON
#ifdef HARD_DISK_ON
int AgfaPack_TTF_File(
    char* szFontName,          /* Original TTF font file name */
    char* szComprName,         /* Name of output compressed file */
    long* plFontSize,          /* Size of TTF file */
    long* plComprSize,         /* Size of resultant compressed file */
    long  lcopyLimit,          /* If non-zero, maximum copy distance to use */
    MTX_MALLOCPTR mptr,        /* Pointer to a malloc function */
    MTX_REALLOCPTR rptr,    /* Pointer to a realloc function */
    MTX_FREEPTR fptr )        /* Pointer to a free function */
{
    MTX_MemHandler *mem = MTX_mem_Create(mptr, rptr, fptr);
    int ierrorNumber = 0;

    
    *plComprSize = 0;
    if ( mem == NULL ) {
        ierrorNumber = ERR_mem_Create_Failed;
    }
    /* try */
    if ( mem != NULL && (ierrorNumber = GETLASTERROR(mem->env)) == 0 ) {
        AGFACOMP *acomp;
        acomp = MTX_AGFACOMP_Create(mem);
        if(lcopyLimit)        
               MTX_AGFACOMP_SetMaxCopyDistance( acomp, lcopyLimit );
        *plComprSize = MTX_AGFACOMP_Pack_TTF_File( acomp, szFontName, szComprName);        
        *plFontSize = MTX_AGFACOMP_GetTTFSize( acomp );
        ierrorNumber = mem->env;
        if (ierrorNumber != 0)
            MTX_mem_FreeAllMemory( acomp->mem );
        else
            MTX_AGFACOMP_Destroy( acomp );
        MTX_mem_CloseMemory(mem);
        MTX_mem_Destroy( mem );
    }
    /* catch(const int ierrorNumber) */
    else {
        if ( mem != NULL ) {
            MTX_mem_FreeAllMemory(mem);
            MTX_mem_Destroy( mem );
        }
#ifdef ENABLE_DISPLAY
        displayMessage( ierrorNumber );
#else
        ierrorNumber;     /* user defined error handling goes here */
#endif
    }
    return ierrorNumber; /*****/
}
#endif /*HARD_DISK_ON */

int AgfaPack_TTF_InMemory(
    unsigned char *ttf_In,    /* The pointer to the TTF data */
    long size_In,            /* Size of ttf_In */
    short free_Ttf_In,        /* If true we will always fptr( ttf_In ) */
    unsigned char **packed_DataHandle, /* *packed_DataHandle is set to point at the compressed data */
    long *plComprSize,         /* Size of resultant compressed file */
    long  lcopyLimit,          /* If non-zero, maximum copy distance to use */
    MTX_MALLOCPTR mptr,        /* Pointer to a malloc function */
    MTX_REALLOCPTR rptr,    /* Pointer to a realloc function */
    MTX_FREEPTR fptr )        /* Pointer to a free function */
{
    MTX_MemHandler *mem = MTX_mem_Create(mptr, rptr, fptr);
    int ierrorNumber = 0;
    int freeCode = free_Ttf_In ? USE_EXTERNAL_FREE : FREE_HAS_BEEN_CALLED;

    
    *plComprSize = 0;
    if ( mem == NULL ) {
        ierrorNumber = ERR_mem_Create_Failed;
    }
    /* try */
    if ( mem != NULL && (ierrorNumber = GETLASTERROR(mem->env)) == 0 ) {
        AGFACOMP *acomp;
        acomp = MTX_AGFACOMP_Create(mem);
        if(lcopyLimit)        
               MTX_AGFACOMP_SetMaxCopyDistance( acomp, lcopyLimit );
               
        *packed_DataHandle = MTX_AGFACOMP_Pack_TTF_InMemory( acomp, ttf_In, size_In, &freeCode, plComprSize );
    
        ierrorNumber = mem->env;
        if (ierrorNumber != 0)
            MTX_mem_FreeAllMemory( acomp->mem );
        else
            MTX_AGFACOMP_Destroy( acomp );
        MTX_mem_CloseMemory(mem);
        MTX_mem_Destroy( mem );
    }
    /* catch(const int ierrorNumber) */
    else {
        if ( mem != NULL ) {
            MTX_mem_FreeAllMemory(mem);
            MTX_mem_Destroy( mem );
        }
        if ( freeCode != FREE_HAS_BEEN_CALLED ) {
            fptr( ttf_In );
            freeCode = FREE_HAS_BEEN_CALLED;
        }
#ifdef ENABLE_DISPLAY
        displayMessage( ierrorNumber );
#else
        ierrorNumber;     /* user defined error handling goes here */
#endif
    }
    assert( freeCode == FREE_HAS_BEEN_CALLED );
    return ierrorNumber; /*****/
}
#endif /*COMPRESS_ON */

#ifdef DECOMPRESS_ON
#ifdef HARD_DISK_ON
int AgfaUnPack_TTF_File(
    char* szComprName,         /* Name of compressed file */
    char* szOutFile,        /* Name of output TTF font file */
    long* plOutSize,          /* Size of resultant TTF font file */
    MTX_MALLOCPTR mptr,        /* Pointer to a malloc function */
    MTX_REALLOCPTR rptr,    /* Pointer to a realloc function */
    MTX_FREEPTR fptr )        /* Pointer to a free function */
{
    MTX_MemHandler *mem = MTX_mem_Create(mptr, rptr, fptr);
    int ierrorNumber = 0;
    
    *plOutSize = 0;
    if ( mem == NULL ) {
        ierrorNumber = ERR_mem_Create_Failed;
    }
    /* try */
    if ( mem != NULL && (ierrorNumber = GETLASTERROR(mem->env)) == 0 ) {
        AGFACOMP *acomp;
        acomp = MTX_AGFACOMP_Create( mem );
        *plOutSize = MTX_AGFACOMP_UnPack_TTF_File( acomp, szComprName, szOutFile);
        ierrorNumber = mem->env;
        if (ierrorNumber != 0)
            MTX_mem_FreeAllMemory( acomp->mem );
        else
            MTX_AGFACOMP_Destroy( acomp );
        MTX_mem_CloseMemory( mem );
        MTX_mem_Destroy( mem );
    }
    /* catch(const int ierrorNumber) */
    else {
        if ( mem != NULL ) {
            MTX_mem_FreeAllMemory( mem );
            MTX_mem_Destroy( mem );
        }
#ifdef ENABLE_DISPLAY
        displayMessage( ierrorNumber );
#else
        ierrorNumber;     /* user defined error handling goes here */
#endif
    }
    return ierrorNumber; /*****/
}
#endif /*HARD_DISK_ON */

int AgfaUnPack_TTF_InMemory(
    unsigned char *packed_Data,        /* The pointer to the compressed data */
    long size_In,                    /* The size of the compressed data */
    short free_Packed_Data,            /* if true we will free up the packed_Data memory */
    unsigned char **ttfDataHandle,     /* *ttfDataHandle is set to point at the expanded TTF data */
    long* plOutSize,                   /* Size of resultant TTF font file */
    MTX_MALLOCPTR mptr,                /* Pointer to a malloc function */
    MTX_REALLOCPTR rptr,            /* Pointer to a realloc function */
    MTX_FREEPTR fptr )                /* Pointer to a free function */
{
    MTX_MemHandler *mem = MTX_mem_Create(mptr, rptr, fptr);
    int ierrorNumber = 0;
    int freeCode = free_Packed_Data ? USE_EXTERNAL_FREE : FREE_HAS_BEEN_CALLED;
    
    *plOutSize = 0;
    if ( mem == NULL ) {
        ierrorNumber = ERR_mem_Create_Failed;
    }
    /* try */
    if ( mem != NULL && (ierrorNumber = GETLASTERROR(mem->env)) == 0 ) {
        AGFACOMP *acomp;
        acomp = MTX_AGFACOMP_Create( mem );
        
        *ttfDataHandle = MTX_AGFACOMP_UnPack_TTF_InMemory( acomp, packed_Data, size_In, &freeCode, plOutSize );
        
                
        ierrorNumber = mem->env;
        if (ierrorNumber != 0)
            MTX_mem_FreeAllMemory( acomp->mem );
        else
            MTX_AGFACOMP_Destroy( acomp );
        MTX_mem_CloseMemory( mem );
        MTX_mem_Destroy( mem );
    }
    /* catch(const int ierrorNumber) */
    else {
        if ( mem != NULL ) {
            MTX_mem_FreeAllMemory( mem );
            MTX_mem_Destroy( mem );
        }
        if ( freeCode != FREE_HAS_BEEN_CALLED ) {
            fptr( packed_Data );
            freeCode = FREE_HAS_BEEN_CALLED;
        }
#ifdef ENABLE_DISPLAY
        displayMessage( ierrorNumber );
#else
        ierrorNumber;     /* user defined error handling goes here */
#endif
    }
    assert( freeCode == FREE_HAS_BEEN_CALLED );
    return ierrorNumber; /*****/
}
#endif /*DECOMPRESS_ON */

#ifdef ENABLE_DISPLAY
void displayMessage (const int ierrorNumber)
{
    printf("\n*****ERROR*****ALERT*****ERROR*****ALERT*****\n");
    printf(  "** THE CODE ENCOUNTERED AN ERROR CONDITION **\n");
    printf(  "The Error Exception is = \"%d\"\n", ierrorNumber );
    printf(  "*****ERROR*****ALERT*****ERROR*****ALERT*****\n");
}
#endif
/* end AGFAWRAP.CPP*/


