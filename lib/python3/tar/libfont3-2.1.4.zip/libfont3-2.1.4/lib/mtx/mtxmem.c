/* Copyright (C) 1989, 1990, 1991, 1992, 1993, 1994, 1995, 1996
 * all rights reserved, by Bayer Corp., Agfa Division, Wilmington, MA.
 *
 * This software is furnished under a license and may be used and
 * copied only in accordance with the terms of such license and with
 * the inclusion of the above copyright notice. This software or any
 * other copies thereof may not be provided or otherwise made
 * available to any other person except as allowed under license. No    
 * title to and ownership of the software is hereby transferred.
 *
 * This information in this software is subject to change without notice
 */
/* $Header:   I:\bull\c_exprss\src\mtxmem.c_v   1.1   22 May 1997 11:12:52   MARTIN  $ */
/* $Log:   I:\bull\c_exprss\src\mtxmem.c_v  $
 * 
 *    Rev 1.1   22 May 1997 11:12:52   MARTIN
 * 
 * Added conditional compile for realloc function.
 * 
 *    Rev 1.0   14 May 1997 17:20:46   MARTIN
 * Initial revision.
 * 
 *    Rev 1.2   30 Apr 1997 11:06:16   MARTIN
 * 
 * Changed order of realloc arguments.
 * 
 *    Rev 1.1   29 Apr 1997 14:17:20   MARTIN
 * 
 * Added references to mem_struct.
 * 
 *    Rev 1.0   17 Dec 1996 16:31:38   MARTIN
 * Initial revision.
   
      Rev 1.4   09 Oct 1996 16:03:48   MARTIN
   
   Modifications for memory based version.
   
      Rev 1.3   09 Oct 1996 14:02:14   MARTIN
   
   Modifications made by Sampo for the Mac platform.
   
      Rev 1.2   20 May 1996 15:09:02   MARTIN
   
   Replaced error messages with error codes.
   
      Rev 1.1   24 Apr 1996 15:49:38   MARTIN
   
   Fixed header.
   
      Rev 1.0   24 Apr 1996 10:53:50   LISA
   Initial revision.
*/

/*
 * File:                        MEMORY.CPP
 * Author:                        Sampo Kaasila
 * First Version:                March 8, 1996
 * Added mem_realloc:            September 29, 1996  (Sampo)
 * First pure ANSI C version:     October 28, 1996  (Sampo).
 * Remove the use of setjmp and longjmp. August 6, 2014 (Taylor)
 */
 
#ifdef _WINDOWS
#include <windows.h>
#endif
#include <stdio.h>
#include <assert.h>
#include "agfaconfig.h"
#include "agfawrap.h"
#include "mtxmem.h"
#include "errcodes.h"

/* Only define this for debugging purposes, never define in a final release */
/*#define CHECK_OVERWRITES   */
const long overWriteExtraSpace        = sizeof(long) + sizeof(long) + sizeof(char); /* 4-byte Stamp, length, data, 1-byte Stamp */
const long overWriteOffsetToData    = sizeof(long) + sizeof(long); /* 4-byte Stamp, length */

static int NoMoreMemory( MTX_MemHandler *t )
{
    SETLASTERROR( t->env, ERR_no_more_memory );
}

#ifdef CHECK_OVERWRITES
static void validateAllMemory( MTX_MemHandler *t )
{
    register long i, limit;
    register mem_struct *pointers = t->mem_pointers;
    void *object;

    limit = t->mem_maxPointers;
    for ( i = 0; i < limit; i++ ) {
        if ( (object = pointers[i].pointermem) != NULL ) {
            if ( ((long *)object)[0] != 0x12345678 ) SETLASTERROR( t->env, ERR_array_start_thrashed );
            if ( ((unsigned char *)object)[((long *)object)[1]-1] != 0xa5 ) SETLASTERROR( t->env, ERR_array_end_thrashed );
        }
    }
}
#endif


void *MTX_mem_malloc(MTX_MemHandler *t, unsigned long size)
{
    register long i, limit;
    void *babyObject;
    register mem_struct *pointers;
    
    if ( size == 0 ) return NULL; /****** Added September 23, 1996 ---Sampo */
    
    t->mem_numNewCalls++;
    #ifdef CHECK_OVERWRITES
        size += overWriteExtraSpace;
        babyObject = t->malloc( size );
        ((long *)babyObject)[0] = 0x12345678;
        ((long *)babyObject)[1] = size;
        ((unsigned char *)babyObject)[size-1] = 0xa5;
    #else
        babyObject = t->malloc( size );
    #endif /* CHECK_OVERWRITES */
    if ( babyObject == NULL ) NoMoreMemory(t);
    CHECKLASTERROR(t->env);
    if ( t->mem_numPointers >= t->mem_maxPointers ) {
        long oldMaxPointers = t->mem_maxPointers;
        /* We need to allocate more space for pointers */ 
        t->mem_maxPointers = t->mem_maxPointers + t->mem_maxPointers/4 + 128;
        if ( t->mem_pointers != NULL ) {
#ifdef BIT16
            t->mem_pointers = (mem_struct*)t->realloc( t->mem_pointers, t->mem_maxPointers * sizeof( mem_struct), oldMaxPointers * sizeof( mem_struct) );
#else
            t->mem_pointers = (mem_struct*)t->realloc( t->mem_pointers, t->mem_maxPointers * sizeof( mem_struct) );
#endif
        } else { 
            t->mem_pointers = (mem_struct*)t->malloc( t->mem_maxPointers * sizeof( mem_struct) );
        }
        if ( t->mem_pointers == NULL ) NoMoreMemory(t);
        CHECKLASTERROR(t->env);
        /* Zero out the new entries; */
        for ( i = oldMaxPointers; i < t->mem_maxPointers; i++ ) {
            t->mem_pointers[i].pointermem = NULL;
            t->mem_pointers[i].pointersize = 0;
        }
    }
    /* OK, now we have a space to store the pointers, so go find it ! */
    limit = t->mem_maxPointers;
    pointers = t->mem_pointers;
    for ( i = 0; i < limit; i++ ) {
        if ( pointers[i].pointermem == NULL ) {
            pointers[i].pointermem = babyObject;
            pointers[i].pointersize = size;
            /*callNumber[i] = t->mem_numPointers; */
            t->mem_numPointers++;
            #ifdef CHECK_OVERWRITES
                validateAllMemory(t);
                return (void *)((char *)babyObject + overWriteOffsetToData); /******/
            #else
                return babyObject; /******/
            #endif
        }
    }
    SETLASTERROR( t->env, ERR_new_logical );
    //return NULL; /*****/
}

/* Added September 29, 1996 Sampo */
void *MTX_mem_realloc(MTX_MemHandler *t, void *p, unsigned long size)
{
    register long i, limit;
    register mem_struct *pointers = t->mem_pointers;
    void *new_p;

    if ( p == NULL ) {
        return MTX_mem_malloc( t, size ); /******/
    }
    if ( size == 0 ) {
        MTX_mem_free( t, p );
        return NULL; /****** Added October 7, 1996 ---Sampo */
    }
    
    #ifdef CHECK_OVERWRITES
        size += overWriteExtraSpace;
        p = (void *)((char *)p - overWriteOffsetToData);
    #endif
    /* See if we can find it */
    limit = t->mem_maxPointers;
    for ( i = 0; i < limit; i++ ) {
        if ( pointers[i].pointermem == p ) {
            #ifdef CHECK_OVERWRITES
                if ( ((long *)p)[0] != 0x12345678 ) SETLASTERROR( t->env, ERR_array_start_thrashed );
                if ( ((unsigned char *)p)[((long *)p)[1]-1] != 0xa5 ) SETLASTERROR( t->env, ERR_array_end_thrashed );
            #endif
#ifdef BIT16
            new_p = t->realloc( p, size, pointers[i].pointersize );
#else
            new_p = t->realloc( p, size );
#endif
            if ( new_p == NULL ) SETLASTERROR( t->env, ERR_realloc_failed );
            pointers[i].pointermem = new_p;
            pointers[i].pointersize = size;
            #ifdef CHECK_OVERWRITES
                if ( ((long *)new_p)[0] != 0x12345678 ) SETLASTERROR( t->env, ERR_array_start_thrashed );
                ((long *)new_p)[1]            = size;
                ((unsigned char *)new_p)[size-1]        = 0xa5;
                validateAllMemory(t);
                return (void *)((char *)new_p + overWriteOffsetToData); /******/
            #else
                return new_p; /******/
            #endif
        }
    }
    SETLASTERROR( t->env, ERR_realloc_bad_pointer );
    //return NULL; /******/
}


/* Added September 16, 2009 - VL */
/* This is a modified version of MTX_mem_realloc that reallocates memory in user space */
/* and removes the pointer from the MTX memory pool to prevent dangling pointer error  */
/* when MTX_mem_CloseMemory is called. This is only needed to allocate a memory buffer */
/* for font data that is to be returned to a caller */
/* VL - 20090916 */
void *MTX_mem_realloc_in_user_space(MTX_MemHandler *t, void *p, unsigned long size)
{
    register long i, limit;
    register mem_struct *pointers = t->mem_pointers;
    void *new_p;

    if ( p == NULL ) {
        /* Unlike the original version of MTX_mem_realloc, if this function is */
        /* called with NULL pointer it will simply return the same NULL back.  */
        return NULL; /*** VL ***/
    }
    if ( size == 0 ) {
        MTX_mem_free( t, p );
        return NULL; /****** Added October 7, 1996 ---Sampo */
    }
    
    #ifdef CHECK_OVERWRITES
        size += overWriteExtraSpace;
        p = (void *)((char *)p - overWriteOffsetToData);
    #endif
    /* See if we can find it */
    limit = t->mem_maxPointers;
    for ( i = 0; i < limit; i++ ) {
        if ( pointers[i].pointermem == p ) {
            #ifdef CHECK_OVERWRITES
                if ( ((long *)p)[0] != 0x12345678 ) SETLASTERROR( t->env, ERR_array_start_thrashed );
                if ( ((unsigned char *)p)[((long *)p)[1]-1] != 0xa5 ) SETLASTERROR( t->env, ERR_array_end_thrashed );
            #endif
#ifdef BIT16
            new_p = t->realloc( p, size, pointers[i].pointersize );
#else
            new_p = t->realloc( p, size );
#endif
            if ( new_p == NULL ) SETLASTERROR( t->env, ERR_realloc_failed );
            /* At this point we have a new memory array allocated in user space, */
            /* now we need to cleen up the MTX_mem_handler records VL - 20090916 */
            pointers[i].pointermem = NULL;
            pointers[i].pointersize = 0;
            t->mem_numPointers--;
            #ifdef CHECK_OVERWRITES
                if ( ((long *)new_p)[0] != 0x12345678 ) SETLASTERROR( t->env, ERR_array_start_thrashed );
                ((long *)new_p)[1]            = size;
                ((unsigned char *)new_p)[size-1]        = 0xa5;
                validateAllMemory(t);
                return (void *)((char *)new_p + overWriteOffsetToData); /******/
            #else
                return new_p; /******/
            #endif
        }
    }
    SETLASTERROR( t->env, ERR_realloc_bad_pointer );
    //return NULL; /******/
}


int MTX_mem_free(MTX_MemHandler *t, void *deadObject)
{
    register long i, limit;
    register mem_struct *pointers = t->mem_pointers;
    if ( deadObject == NULL ) return 0; /*****/ /* This is OK by definition */
    #ifdef CHECK_OVERWRITES
        deadObject = (void *)((char *)deadObject - overWriteOffsetToData);
    #endif
    /* See if we can find it */
    limit = t->mem_maxPointers;
    for ( i = 0; i < limit; i++ ) {
        if ( pointers[i].pointermem == deadObject ) {
            #ifdef CHECK_OVERWRITES
                if ( ((long *)deadObject)[0] != 0x12345678 ) SETLASTERROR( t->env, ERR_array_start_thrashed );
                if ( ((unsigned char *)deadObject)[((long *)deadObject)[1]-1] != 0xa5 ) SETLASTERROR( t->env, ERR_array_end_thrashed );
                validateAllMemory(t);
            #endif
            t->free( deadObject );
            pointers[i].pointermem = NULL;
            pointers[i].pointersize = 0;
            t->mem_numPointers--;
            return 0; /******/
        }
    }
    SETLASTERROR( t->env, ERR_delete_bad_pointer );
}



/* Call mem_FreeAllMemory insted on an abnormal (exception) exit */
void MTX_mem_FreeAllMemory( MTX_MemHandler *t )
{
    register long i;

    if ( t->mem_pointers != NULL ) {
        for ( i = 0; i < t->mem_maxPointers; i++ ) {
            if ( t->mem_pointers[i].pointermem != NULL ) {
                #ifdef CHECK_OVERWRITES
                    void *deadObject = t->mem_pointers[i].pointermem;
                    if ( ((long *)deadObject)[0] != 0x12345678 ) printf("%s\n", "ERR_array_start_thrashed ");
                    if ( ((unsigned char *)deadObject)[((long *)deadObject)[1]-1] != 0xa5 ) printf("%s\n", "ERR_array_end_thrashed ");
                #endif
                t->free( t->mem_pointers[i].pointermem );
                t->mem_pointers[i].pointermem = NULL;
                t->mem_pointers[i].pointermem = 0;
                t->mem_numPointers--; 
            }
        }
        t->free( t->mem_pointers );  t->mem_pointers = NULL;
    }
}

/* Call mem_CloseMemory on normal exit */
int MTX_mem_CloseMemory( MTX_MemHandler *t )
{
    /*register long i; */
    /*cout << "t->mem_maxPointers = " << t->mem_maxPointers << endl; */
    /*cout << "t->mem_numPointers = " << t->mem_numPointers << endl; */
    /*cout << "t->mem_numNewCalls = " << t->mem_numNewCalls << endl; */
    /*for ( i = 0; i < t->mem_maxPointers; i++ ) { */
    /*    if ( t->mem_pointers[i] != NULL ) { */
    /*        cout << i << ":" << callNumber[i] << endl; */
    /*    } */
    /*} */

    if ( t->mem_numPointers != 0 ) SETLASTERROR( t->env, ERR_mem_dangling_pointers );
    if ( t->mem_pointers != NULL  ) t->free( t->mem_pointers ); t->mem_pointers = NULL;
    return 0;
}


MTX_MemHandler *MTX_mem_Create(MTX_MALLOCPTR mptr, MTX_REALLOCPTR rptr, MTX_FREEPTR fptr)
{
    MTX_MemHandler *t;
    unsigned long templong;

    templong = sizeof(MTX_MemHandler);
    t = (MTX_MemHandler *)mptr( templong );
    if ( t == NULL ) return NULL; /*****/
    
    t->mem_pointers        = NULL;
    t->mem_maxPointers    = 0;
    t->mem_numPointers     = 0; /* Number of non-zero pointers */
    t->mem_numNewCalls    = 0;

    assert( mptr != NULL && rptr != NULL && fptr != NULL );
    t->malloc            = mptr;
    t->realloc            = rptr;
    t->free                = fptr;
    t->env              = 0;
    return t; /******/
}

void MTX_mem_Destroy(MTX_MemHandler *t)
{
    assert ( t != NULL );
    t->free( t );
}

