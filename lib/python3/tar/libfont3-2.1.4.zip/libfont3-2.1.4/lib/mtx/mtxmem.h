/* Copyright (C) 1989, 1990, 1991, 1992, 1993, 1994, 1995, 1996
 * all rights reserved, by Bayer Corp., Agfa Division, Wilmington, MA.
 *
 * This software is furnished under a license and may be used and
 * copied only in accordance with the terms of such license and with
 * the inclusion of the above copyright notice. This software or any
 * other copies thereof may not be provided or otherwise made
 * available to any other person except as allowed under license. No
 * title to and ownership of the software is hereby transferred.
 *
 * This information in this software is subject to change without notice
 */
/* $Header:   I:\bull\c_exprss\src\mtxmem.h_v   1.1   22 May 1997 11:11:12   MARTIN  $ */
/* $Log:   I:\bull\c_exprss\src\mtxmem.h_v  $
 * 
 *    Rev 1.1   22 May 1997 11:11:12   MARTIN
 * Added conditional compile for MTX_MEMPTRs.
 * 
 *    Rev 1.0   14 May 1997 17:21:48   MARTIN
 * Initial revision.
 * 
 *    Rev 1.1   29 Apr 1997 14:37:14   MARTIN
 * 
 * Added mem_struct. Changed size_t to unsigned long. Added
 * typedefs for MTX_MALLOCPTR, MTX_REALLOCPTR, and MTX_FREEPTR.
 * 
 *    Rev 1.0   17 Dec 1996 16:31:42   MARTIN
 * Initial revision.
   
      Rev 1.2   09 Oct 1996 16:04:08   MARTIN
   
   Modifications for memory based version.
   
      Rev 1.1   24 Apr 1996 15:49:58   MARTIN
   
   Fixed header.
   
      Rev 1.0   24 Apr 1996 10:54:04   LISA
   Initial revision.
*/

/*
 * File:                        MEMORY.HPP
 * Author:                        Sampo Kaasila
 * First Version:                March 8, 1996
 * Added mem_realloc:            September 29, 1996  (Sampo)
 * First pure ANSI C version:     October 28, 1996  (Sampo).
 * Remove the use of setjmp and longjmp. August 6, 2014 (Taylor)
 */

#ifndef MEMORY_HPP
#define MEMORY_HPP

#ifdef __cplusplus
extern "C" {
#endif

/* error checking macros */
#define GETLASTERROR(x) (x)
#define SETLASTERROR(env, code) {env = code; return 0;}
#define CHECKLASTERROR(env)     { if(env) return 0; }

typedef struct {
    /* private */ 
    void *pointermem;
    long pointersize;
} mem_struct;

#ifndef MTX_MEMPTR
#define MTX_MEMPTR
#ifdef BIT16  /* for 16-bit applications */
typedef void *(*MTX_MALLOCPTR)(unsigned long);
typedef void *(*MTX_REALLOCPTR)(void *, unsigned long, unsigned long);
typedef void (*MTX_FREEPTR)(void *);
#else         /* for 32-bit applications */
typedef void *(*MTX_MALLOCPTR)(size_t);
typedef void *(*MTX_REALLOCPTR)(void *, size_t);
typedef void (*MTX_FREEPTR)(void *);
#endif /* BIT16 */
#endif /* MTX_MEMPTR */

typedef struct {
    /* private */
    mem_struct *mem_pointers;
    long mem_maxPointers;
    long mem_numPointers; /* Number of non-zero pointers */
    long mem_numNewCalls;

    MTX_MALLOCPTR    malloc;
    MTX_REALLOCPTR    realloc;
    MTX_FREEPTR        free;
    
    /* public */
    int env;
} MTX_MemHandler;

/* public interface routines */
/* Call mem_CloseMemory on normal exit */
int MTX_mem_CloseMemory( MTX_MemHandler *t ); /*  Frees internal memory and for debugging purposes */
/* Call mem_FreeAllMemory insted on an abnormal (exception) exit */
void MTX_mem_FreeAllMemory( MTX_MemHandler *t ); /* Always call if the code throws an exception */


void *MTX_mem_malloc(MTX_MemHandler *t, unsigned long size);
void *MTX_mem_realloc(MTX_MemHandler *t, void *p, unsigned long size);
void *MTX_mem_realloc_in_user_space(MTX_MemHandler *t, void *p, unsigned long size); /* VL - 20090916 */
int   MTX_mem_free(MTX_MemHandler *t, void *deadObject);

MTX_MemHandler *MTX_mem_Create(MTX_MALLOCPTR mptr, MTX_REALLOCPTR rptr, MTX_FREEPTR fptr);
void MTX_mem_Destroy(MTX_MemHandler *t);


#ifdef __cplusplus
}
#endif

#endif /* MEMORY_HPP */
