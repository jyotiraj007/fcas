// Copyright (C) 2014 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
/// \file ConversionLibPort.h

#ifndef CONVERSION_LIB_PORT_H
#define CONVERSION_LIB_PORT_H


/*****************************************************************************
 *
 *  Include the system header files that are needed by the base library.
 *
 *  There are environments where the contents of these files are put in
 *  other files.  If necessary, MODIFY the include statements so that the
 *  appropriate files are included.
 *
 ****************************************************************************/
#include <stdarg.h>     /* Variable argument macro definitions */
#include <stddef.h>     /* Common Definitions and Types: NULL, size_t, etc. */
#include <stdlib.h>     /* General Utilities: memory management */
#include <stdio.h>      /* Input/output: FILE, fopen() ... fclose() */
#include <string.h>     /* String handling and memcpy(), memset() */
#include <limits.h>     /* Sizes of integer types */
#include <assert.h>     /* Diagnostics: assert macro */

#define DEFAULT_QUAD_UNITS 2048
#define DEFAULT_CUBIC_UNITS 1000
#define ROUND_TRIP 1

#endif // CONVERSION_LIB_PORT_H
