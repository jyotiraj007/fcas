// Copyright (C) 2014 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
/// \file Vector2f.h

#ifndef VECTOR2_F_H
#define VECTOR2_F_H

class Vector2i;
class Vector2;

//! Provides 2D vector (float) operations
/*!
    Defines vector addition, subtraction, and comparison. Permits indexed access to vector components. 
    See also Vector2.
*/
class Vector2f
{
   public:
        /* Ctor */      Vector2f        ();
        /* Ctor */      Vector2f        (float x, float y);
        /* Ctor */      Vector2f        (const Vector2f& other);
        /* Ctor */      Vector2f        (const Vector2i& other);
        /* Ctor */      Vector2f        (const Vector2& otherDouble);

        void            FromFixed       (int x, int y); // Fixed point 16:16.
        const float&    operator[]      (int i) const;
        float&          operator[]      (int i);
        void            Set             (float x, float y);
        Vector2f        operator-       (const Vector2f& other) const;
        Vector2f        operator+       (const Vector2f& other) const;
        Vector2f        operator-=      (const Vector2f& other);
        Vector2f        operator+=      (const Vector2f& other);
        Vector2f        operator*=      (float scale);
        float           Length          () const;
        float           LengthSquared   () const;
        void            Normalize       ();
        bool            operator==      (const Vector2f& other) const;
        bool            operator!=      (const Vector2f& other) const;

        Vector2f        Rounded         () const;

        friend
        Vector2f        operator*       (float scale, const Vector2f& other);

        friend
        float           DotProduct      (const Vector2f& one, const Vector2f& two);

        friend 
        float           CrossProduct    (const Vector2f& one, const Vector2f& two);

        friend
        float           Distance        (const Vector2f& one, const Vector2f& two);

        friend
        float           ManhattenDistance(const Vector2f& one, const Vector2f& two);

        bool            IsValid    () const;

        void            Print       ();

    protected:

        float           m_X;
        float           m_Y;
};


/**
    Access to coordinates.
    @param[in] i Coordinate index
    @return Coordinate value.
*/
inline const float& Vector2f::operator[](int i) const
{
    if (i == 0)
        return m_X;
    else
        return m_Y;
}

/**
    Access to coordinates.
    @param[in] i Coordinate index
    @return Coordinate value.
*/
inline float& Vector2f::operator[](int i)
{
    if (i == 0)
        return m_X;
    else
        return m_Y;
}

/**
    Computes length of vector.
    @return square of the length of the vector.
*/
inline float Vector2f::LengthSquared() const
{
    return  m_X * m_X + m_Y * m_Y;
}


#endif
