// Copyright (C) 2015 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// QuadContour.cpp

#include "QuadPoints.h"
#include "QuadContour.h"
#include "QuadBezier.h"
#include "MathUtilities.h"
#include "CubicContour.h"
#include "CompositQuadBezier.h"

QuadContour::QuadContour(int designUnits /* = DEFAULT_QUAD_UNITS */)
: Contour(designUnits),
    m_Stripped(false)
{
}

bool QuadContour::Match(CubicContour& cubicContour, float tolerance)
{
    bool success = true; 

    FindExtrema();

    int numPoints = m_Points.NumElements();

    // If output contour has different design units adjust size 
    // before converting.
    ScaleTo(cubicContour.GetDesignUnits());

    // tolerance may need fixing up due to scaling.
    tolerance *= m_Scale;

    // Make sure we write out single points.
    if (numPoints == 1)
    {
        cubicContour.AddPoint(m_Points[0]);
        return true;
    }

    CompositQuadBezier quad;

    Vector2f points[3];

    int index = 0;

    for (int i = 0; i < numPoints; i++)
    {
        ContourPoint& currentPoint = m_Points[i];

        switch (currentPoint.m_Type)
        {
            case ContourPoint::MOVE_TO:
                if (quad.NumComponents() > 0)
                {
                    quad.Match(cubicContour, tolerance);
                    quad.Clear();
                }

                points[0] = currentPoint.m_Point;
                cubicContour.AddPoint(currentPoint);
                index = 1;
            break;

            case ContourPoint::LINE_TO:
                points[index] = currentPoint.m_Point;
                points[0] = points[1];
                cubicContour.AddPoint(currentPoint, true);
                index = 1;

                if (quad.NumComponents() > 0)
                {
                    quad.Match(cubicContour, tolerance);
                    quad.Clear();
                }
            break;

            case ContourPoint::OFF_CURVE:

                // Handle two off curves in a row with implicit mid point.
                if (index == 2)
                {
                    Vector2f midPoint = Interpolate(points[1], currentPoint.m_Point, 0.5f);

                    QuadPoints quadPoint(points[0], midPoint, points[1]);
                    quad.AddQuad(quadPoint);

                    points[0] = midPoint;
                    points[1] = currentPoint.m_Point;
                    index = 2;
                }
                else
                {
                    points[index++] = currentPoint.m_Point;
                }
            break;

            case ContourPoint::ON_CURVE:

                points[index] = currentPoint.m_Point;
                QuadPoints quadPoint(points[0], points[2], points[1]);
                quad.AddQuad(quadPoint);

                if (currentPoint.m_IsExtremum)
                {
                    success &= quad.Match(cubicContour, tolerance);
                    quad.Clear();
                }

                points[0] = points[2];
                index = 1;
            break;
        }
    }

    cubicContour.Reverse();

    return success;
}

bool QuadContour::Match(QuadContour& quadContour, float tolerance)
{
    bool success = true; 


    //StripImplicitMidPoints();

    FindExtrema(false); 

    int numPoints = m_Points.NumElements();

    // If output contour has different design units adjust size 
    // before converting.
    ScaleTo(quadContour.GetDesignUnits());

    // tolerance may need fixing up due to scaling.
    tolerance *= m_Scale;

    // Make sure we write out single points.
    if (numPoints == 1)
    {
        quadContour.AddPoint(m_Points[0]);
        return true;
    }

    CompositQuadBezier quad;

    Vector2f points[3];

    int index = 0;

    for (int i = 0; i < numPoints; i++)
    {
        ContourPoint& currentPoint = m_Points[i];

        switch (currentPoint.m_Type)
        {
            case ContourPoint::MOVE_TO:
                if (quad.NumComponents() > 0)
                {
                    quad.Match(quadContour, tolerance);
                    quad.Clear();
                }

                points[0] = currentPoint.m_Point;
                quadContour.AddPoint(currentPoint);
                index = 1;
            break;

            case ContourPoint::LINE_TO:
                if (quad.NumComponents() > 0)
                {
                    quad.Match(quadContour, tolerance);
                    quad.Clear();
                }

                points[index] = currentPoint.m_Point;
                points[0] = points[1];
                quadContour.AddPoint(currentPoint, true);
                index = 1;

            break;

            case ContourPoint::OFF_CURVE:

                // Handle two off curves in a row with implicit mid point.
                if (index == 2)
                {
                    Vector2f midPoint = Interpolate(points[1], currentPoint.m_Point, 0.5f);

                    QuadPoints quadPoint(points[0], midPoint, points[1]);
                    quad.AddQuad(quadPoint);

                    points[0] = midPoint;
                    points[1] = currentPoint.m_Point;
                    index = 2;
                }
                else
                {
                    points[index++] = currentPoint.m_Point;
                }
            break;

            case ContourPoint::ON_CURVE:

                points[index] = currentPoint.m_Point;
                QuadPoints quadPoint(points[0], points[2], points[1]);
                quad.AddQuad(quadPoint);

                if (currentPoint.m_IsExtremum)
                {
                    success &= quad.Match(quadContour, tolerance);
                    quad.Clear();
                }

                points[0] = points[2];
                index = 1;
            break;
        }
    }

    if (quad.NumComponents() > 0)
    {
        quad.Match(quadContour, tolerance);
        quad.Clear();
    }
    return success;
}


void QuadContour::EmitAnyQuads()
{
    const float EPSILON = 0.1f;

    int numQuads = m_CurrentRun.NumElements();

    if (numQuads > 0)
    {
        int i; // Needed outside of loop.

        for (i = 0; i < numQuads - 1; i++)
        {
            QuadPoints& one = m_CurrentRun[i];
            QuadPoints& two = m_CurrentRun[i + 1];

            Vector2f midPoint = Interpolate(one.m_Control, two.m_Control, 0.5f);

            Vector2f delta = midPoint - one.m_End;

            if (delta.Length() < EPSILON)
            {
                m_NewPoints.Add(ContourPoint(ContourPoint::OFF_CURVE, one.m_Control));
            }
            else
            {
                m_NewPoints.Add(ContourPoint(ContourPoint::OFF_CURVE, one.m_Control));
                m_NewPoints.Add(ContourPoint(ContourPoint::ON_CURVE,  one.m_End));
            }
        }

        QuadPoints last = m_CurrentRun.Last();
        m_NewPoints.Add(ContourPoint(ContourPoint::OFF_CURVE, last.m_Control));
        m_NewPoints.Add(ContourPoint(ContourPoint::ON_CURVE,  last.m_End));
    }

    m_CurrentRun.Clear();
}

void QuadContour::StripImplicitMidPoints()
{
    if (false == m_Stripped)
    {
        m_Stripped = true;
        Vector2f points[3];

        int index = 0;

        m_NewPoints.Clear();
        m_CurrentRun.Clear();

        for (int i = 0; i < m_Points.NumElements(); i++)
        {
            ContourPoint& currentPoint = m_Points[i];

            switch (currentPoint.m_Type)
            {
                case ContourPoint::MOVE_TO:
                    EmitAnyQuads();
                    m_NewPoints.Add(currentPoint);
                    points[0] = currentPoint.m_Point;
                    index = 1;
                break;

                case ContourPoint::LINE_TO:
                    EmitAnyQuads();
                    points[0] = currentPoint.m_Point;
                    m_NewPoints.Add(currentPoint);
                    index = 1;
                break;

                case ContourPoint::OFF_CURVE:
                        points[index++] = currentPoint.m_Point;
                break;

                case ContourPoint::ON_CURVE:

                    points[index] = currentPoint.m_Point;
                    QuadPoints quadPoint(points[0], points[2], points[1]);
                    m_CurrentRun.Add(quadPoint);

                    points[0] = points[2];
                    index = 1;
                break;
            }
        }
        EmitAnyQuads();

        m_Points = m_NewPoints;
    }
}


