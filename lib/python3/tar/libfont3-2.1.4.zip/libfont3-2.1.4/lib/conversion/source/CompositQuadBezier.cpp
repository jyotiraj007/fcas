// Copyright (C) 2015 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// CompositQuadBezier.cpp

#include "CompositQuadBezier.h"
#include "QuadBezier.h"
#include "BresenhamLine.h"
#include "CubicBezier.h"
#include "MathUtilities.h"

CompositQuadBezier::CompositQuadBezier()
{
}

void CompositQuadBezier::AddQuad(QuadPoints& points)
{
    m_QuadPoints.Add(points);
}

void CompositQuadBezier::Clear()
{
    m_QuadPoints.Clear();
    m_Points.Clear();
}

int CompositQuadBezier::NumComponents()
{
    return m_QuadPoints.NumElements();
}


void CompositQuadBezier::Evaluate(float flatness)
{
    CreateSegments(flatness);
    CreateNormals();
    CreateTangents();
}

void CompositQuadBezier::CreateSegments(float flatness)
{
    m_CurrentFlatness = flatness;

    int numQuads = m_QuadPoints.NumElements();
    m_Points.Clear();

    Vector2f last;

    for (int i = 0; i < numQuads; i++)
    {
        QuadPoints points = m_QuadPoints[i];
        QuadBezier bezier(points);
        bezier.Evaluate(flatness);
        m_MidPoint = bezier.m_Points.NumElements();

        // Add each bezier's points. Don't duplicate first/last point.
        for (int j = 0; j < bezier.m_Points.NumElements() - 1; j++)
        {
            m_Points.Add(bezier.m_Points[j]);
        }
        last = bezier.m_Points.Last();
    }
    m_Points.Add(last);

    QuadPoints firstQuad = m_QuadPoints.First();
    QuadPoints lastQuad  = m_QuadPoints.Last();

    m_StartTangent = Line2D(firstQuad.m_Control, firstQuad.m_Start);
    m_EndTangent   = Line2D(lastQuad.m_Control, lastQuad.m_End);
}


bool CompositQuadBezier::Match(QuadContour& quadContour, float tolerance)
{
    m_Depth = 0;
    m_Tolerance = tolerance;

    int numQuads = m_QuadPoints.NumElements();

    if (numQuads == 0)
    {
        return false;
    }

    if (numQuads == 1)
    {
        QuadPoints quad = m_QuadPoints.First();

        ContourPoint controlPoint(ContourPoint::OFF_CURVE, quad.m_Control);
        ContourPoint endPoint(ContourPoint::ON_CURVE, quad.m_End);
        quadContour.AddPoint(controlPoint, true);
        quadContour.AddPoint(endPoint, true);
        return true;
    }

    QuadPoints firstQuad = m_QuadPoints.First();
    QuadPoints lastQuad  = m_QuadPoints.Last();

    Evaluate(0.5f);

    m_Control[eSTART] = firstQuad.m_Start;
    m_Control[eEND]   = lastQuad.m_End;

    // Check for linear cubic by comparing to line from start to end.
    if (IsLinear(m_Tolerance * 0.25f))
    {
        ContourPoint lineEnd(ContourPoint::LINE_TO, m_Control[eEND]);
        quadContour.AddPoint(lineEnd, true);
        return true;
    }

    m_StartTangent.ExtendStart(10000.0);
    m_EndTangent.ExtendStart(10000.0);


    if (m_Control[eSTART] != m_Control[eEND])
    {
        // Try for single quad: got lucky or very small.
        if (m_StartTangent.SegsIntersect(m_EndTangent))
        {
            float distance;
            QuadBezier startBezier;
            Vector2f midPoint = m_StartTangent.Intersects(m_EndTangent);
            midPoint = midPoint.Rounded();

            startBezier.SetPoints(m_Control[eSTART], m_Control[eEND], midPoint);

            startBezier.Evaluate();

            if (WithinTolerance(startBezier, distance))
            {
                ContourPoint controlPoint(ContourPoint::OFF_CURVE, midPoint);
                ContourPoint endPoint(ContourPoint::ON_CURVE, m_Control[eEND]);
                quadContour.AddPoint(controlPoint, true);
                quadContour.AddPoint(endPoint, true);
                return true;
            }
        }
    }

    bool success = Search(quadContour);

    if (false == success)
    {
        CompositQuadBezier one;
        CompositQuadBezier two;

        int half = numQuads / 2;

        int i;

        for (i = 0; i < half; i++)
        {
            one.AddQuad(m_QuadPoints[i]);
        }

        for (; i < numQuads; i++)
        {
            two.AddQuad(m_QuadPoints[i]);
        }

        /*success=*/one.Match(quadContour, tolerance);
        success = two.Match(quadContour, tolerance);
    }

    return success;
}

bool CompositQuadBezier::Search(QuadContour& quadContour)
{
    m_Depth++;
    bool success = true;

    m_BestBeziers.Clear();
    m_BestAverage = FLOAT_MAX;

    m_EvalStack.Reset();
    Line2D startTangent = m_StartTangent;
    Line2D startTarget = startTangent;

    m_CheckDepth = 0;

    CheckRight(startTangent, startTarget, 0, m_Points.NumElements() - 1);

    int numBeziers = m_BestBeziers.NumElements();

    if (numBeziers > 0)
    {
        int i;
        // Emit the beziers to our contour.
        // All beziers have implicit on curve points, so just add controls.
        for (i = 0; i < numBeziers; i++)
        {
            QuadBezier& bezier = m_BestBeziers[i];
            ContourPoint point(ContourPoint::OFF_CURVE, bezier.GetPoint(QuadBezier::eCONTROL));
            quadContour.AddPoint(point, true);
        }

        // Add last on curve point of beziers.
        ContourPoint lastPoint(ContourPoint::ON_CURVE, m_BestBeziers[i-1].GetPoint(QuadBezier::eEND));
        quadContour.AddPoint(lastPoint, true);
    }

    if (numBeziers == 0)
    {
        // If we didn't find a solution, recurse after a tighter evaluation of this cubic.
        Evaluate(m_CurrentFlatness / 10);

        // Limit by both recursion depth and number of elements so we don't take too long.
        // If we return false, Match will split the cubic which usually has better results.
        if ((m_Points.NumElements() < 60) && (m_Depth < 5))
        {
            success = Search(quadContour);
        }
        else
        {
            success = false;
        }
    }

    return success;
}

bool CompositQuadBezier::CheckRight(Line2D& startTangent, Line2D& startTarget, int startIndex, int endIndex)
{
    m_CheckDepth++;

    bool foundSolution = false;

    if (m_CheckDepth < 15000)
    {
        int currentIndex = FindFirst(startTangent, startIndex, endIndex);

        bool intersectsStartTarget  = true;

        while ((false == foundSolution) && (currentIndex > startIndex) && (currentIndex < endIndex) && intersectsStartTarget)
        {
            Line2D currentTangent(m_AllTangents[currentIndex]);

            intersectsStartTarget = currentTangent.SegsIntersect(startTarget);

            if (intersectsStartTarget)
            {

                // Find intersection with current startTarget:
                Vector2f startIntersection(currentTangent.Intersects(startTarget));

                currentTangent.Set(startIntersection, m_Points[currentIndex + 1]);
                currentTangent.ExtendEnd(); // Double in length.

                Line2D currentTarget(startIntersection, m_Points[currentIndex]);
                currentTarget.ExtendEnd();   // Double the length.
                // CurrentTarget is the overlap 
                currentTarget.Set(currentTarget.End(), currentTangent.End());

                m_EvalStack.Push(currentTangent);

                if (currentTarget.SegsIntersect(m_EndTangent))
                {
                    foundSolution = Score();
                }
                else
                {
                    foundSolution = CheckRight(currentTangent, currentTarget, currentIndex+2, endIndex);
                }

                m_EvalStack.Pop();
            }

            --currentIndex;
        }
    }
    return foundSolution;
}

int CompositQuadBezier::FindFirst(Line2D& startTangent, int startIndex, int endIndex)
{
    int currentIndex = startIndex;
    bool intersects = false;

    // First remove any non intersecting segs, usually parallel with tangent.
    while (intersects == false && currentIndex < endIndex)
    {
        Line2D currentLine = m_AllTangents[currentIndex];
        intersects = currentLine.SegsIntersect(startTangent);
        currentIndex++;
    }

    // Now find furthest intersecting tangent.
    while (intersects && currentIndex < endIndex)
    {
        Line2D currentLine = m_AllTangents[currentIndex];
        intersects = currentLine.SegsIntersect(startTangent);
        currentIndex++;
    }

    currentIndex -= 2;

    if (currentIndex < startIndex)
    {
        currentIndex = startIndex + 1;
    }

    return currentIndex;
}

bool CompositQuadBezier::Score()
{
    int numTangents = m_EvalStack.NumElements();

    int numBeziers = numTangents + 1;

    if (numBeziers > m_QuadPoints.NumElements())
    {
        return false;
    }

    m_Tangents.ResetIndex();

    m_Tangents.Add(m_StartTangent);

    for (int i = 0; i < numTangents; i++)
    {
        Line2D currentTangent = m_EvalStack.ElementAt(i);
        currentTangent.Extend(10000.0f);
        m_Tangents.Add(currentTangent);
    }

    m_Tangents.Add(m_EndTangent);

    m_Intersections.ResetIndex();

    for (int i = 0; i < m_Tangents.NumElements()-1; i++)
    {
        Line2D& one = m_Tangents[i];
        Line2D& two = m_Tangents[i+1];

        if (false == one.SegsIntersect(two))
        {
            return false;
        }

        Vector2f intersection = one.Intersects(two);
        m_Intersections.Add(intersection);
    }

    m_ControlPoints.ResetIndex();

    m_ControlPoints.Add(m_Control[eSTART]);

    for (int i = 0; i < m_Intersections.NumElements()-1; i++)
    {
        Vector2f rounded1 = m_Intersections[i].Rounded();
        Vector2f rounded2 = m_Intersections[i+1].Rounded();

        Vector2f midPoint = Interpolate(rounded1, rounded2, 0.5f);
        m_ControlPoints.Add(rounded1);
        m_ControlPoints.Add(midPoint);
    }

    m_ControlPoints.Add(m_Intersections[m_Intersections.NumElements()-1].Rounded());
    m_ControlPoints.Add(m_Control[eEND]);

    float averageDistance = 0.0f;
    m_Beziers.ResetIndex();

    for (int i = 0; i < m_ControlPoints.NumElements()-2; i+=2)
    {
        QuadBezier bezier;

        bezier.SetPoints(m_ControlPoints[i], m_ControlPoints[i+2], m_ControlPoints[i+1]);

        m_Beziers.Add(bezier);
    }

    for (int i = 0; i < m_Beziers.NumElements(); i++)
    {
        QuadBezier& bezier = m_Beziers[i];
        bezier.Evaluate();

        float distance;

        if (WithinTolerance(bezier, distance))
        {
            averageDistance += distance;
        }
        else
        {
            return false;
        }
    }

    averageDistance /= (numTangents + 1);

    if (averageDistance < m_BestAverage)
    {
        m_BestAverage = averageDistance;

        m_BestBeziers = m_Beziers;

        m_FoundMatch = true;
    }

    return true;
}

bool CompositQuadBezier::WithinTolerance(QuadBezier& quad, float& distance)
{
    bool intersection;

    distance = (float)SplineDistance(quad, intersection, 0, m_Points.NumElements() - 1);

    if (distance < m_Tolerance)
    {
        return true;
    }
    else
    {
        return false;
    }
}


double CompositQuadBezier::SplineDistance(QuadBezier& quad, bool& anyIntersections, int startIndex, int stopIndex)
{
    int numSegments = quad.m_Points.NumElements() - 1;

    double largestDistance = 0.0f;
    anyIntersections = false; 

    int numIntersections = 0;

    (void)startIndex;

    for (int j = 0; j < stopIndex; j++)
    {
        double distance = FLOAT_MAX;
        bool   foundIntersection = false;

        // Look for intersection with segment.
        for (int i = 0; i < numSegments; i++)
        {
            Line2D segment(quad.m_Points[i], quad.m_Points[i+1]);

            if (m_NormalLines[j].SegsIntersect(segment))
            {
                numIntersections++;
                anyIntersections = true;
                foundIntersection = true;

                double currentDistance = segment.PointDistance(m_MidPoints[j]);

                // Get the smallest intersection.
                if (currentDistance < distance)
                {
                    distance = currentDistance;
                    if (distance < m_Tolerance)
                    {
                        break;
                    }
                }
            }
        }

        if (foundIntersection) // Avoid adding FLOAT_MAX if no intersection.
        {
            if (distance > largestDistance)
            {
                largestDistance = distance;

                if (largestDistance > m_Tolerance)
                {
                    return largestDistance;
                }
            }
        }
    }

    // Reject degenerate quads with low hit rate.
    float percentMatch = (float)numIntersections / (float)numSegments;

    if (percentMatch < 0.02f)
    {
        largestDistance = FLOAT_MAX;
    }

    return largestDistance;
}


bool CompositQuadBezier::Match(CubicContour& contour, float tolerance)
{
    int numQuads = m_QuadPoints.NumElements();

    QuadPoints first = m_QuadPoints.First();
    QuadPoints last  = m_QuadPoints.Last();

    if (numQuads == 1)
    {
        QuadBezier bezier(first);

        bezier.Match(contour, tolerance);
        return true;
    }

    m_Tolerance = tolerance;
    Evaluate();

    if (IsLinear(m_Tolerance) * 0.5f)
    {
        contour.AddPoint(ContourPoint(ContourPoint::LINE_TO, last.m_End));
        return true;
    }

    Vector2f intersection = m_StartTangent.Intersects(m_EndTangent);

    intersection = intersection.Rounded();

    // Separate x and y components.
    BresenhamLine startTangent(first.m_Control, intersection);
    BresenhamLine endTangent  (intersection, last.m_Control);

    // Check for general unhappiness:
    if (    (first.m_Start != last.m_End)      &&     // Loop: no extrema.    
            (first.m_Start != first.m_Control) &&     // Degenerate first quad.
            (last.m_Control != last.m_End)     &&     // Degenerate last quad.
            intersection.IsValid()             &&     // Nan's in result.
            (startTangent.Length() < 500)      &&     // Parallel or nearly parallel will create too long tangents.
            (endTangent.Length()   < 500) )
    {
        CubicPoints bestPoints;
        float       smallest = FLOAT_MAX;

        CubicBezier cubic;
        cubic.SetPoint(CubicBezier::eSTART, first.m_Start);
        cubic.SetPoint(CubicBezier::eEND,   last.m_End);

        // Store the end handle results in an array and reuse.
        ArrayList<Vector2i> endHandleList;

        Vector2i point;
        bool newEndHandle = endTangent.FirstPoint(point);

        while (newEndHandle)
        {
            endHandleList.Add(point);
            newEndHandle = endTangent.NextPoint(point);
        }

        int endMax = endHandleList.NumElements() - 1; 

        ArrayList<Vector2i> startHandleList;

        // Store the start handle results in an array.
        bool newStartHandle = startTangent.FirstPoint(point);

        while (newStartHandle)
        {
            startHandleList.Add(point);
            newStartHandle = startTangent.NextPoint(point);
        }

        int startIndex = 0;
        int startMax = startHandleList.NumElements();

        bool anyThisHandle;

        Vector2i& startHandle = point;
        Vector2i& endHandle   = point;

        // Walk each line testing as control point for cubic.
        while (startIndex < startMax)
        {
            startHandle = startHandleList[startIndex];

            anyThisHandle = false;
            cubic.SetPoint(CubicBezier::eCONTROL1, startHandle);

            int endIndex = 1;

            while (endIndex < endMax)
            {
                endHandle = endHandleList[endIndex];
                cubic.SetPoint(CubicBezier::eCONTROL2, endHandle);

                float distance = (float) SplineDistance(cubic);

                if (distance < smallest)
                {
                    CubicPoints points;
                    cubic.GetPoints(points);

                    // Don't add degenerate points.
                    if (    (points.m_Control1 != points.m_Control2) &&
                            (points.m_Start    != points.m_Control1) &&
                            (points.m_End      != points.m_Control2) )
                    {
                        smallest = distance;
                        bestPoints = points;
                        if (smallest < m_Tolerance)
                        {
                            anyThisHandle = true;
                            break;
                        }
                    }
                }

                int add = 6;
                if (distance < m_Tolerance * 2)
                {
                    add = 1;
                }

                endIndex += add;
            }

            if (false == anyThisHandle)
            {
                startIndex += 6;
            }
            startIndex += 1;
        }

        if (smallest < m_Tolerance)
        {
            contour.AddPoint(ContourPoint(ContourPoint::OFF_CURVE, bestPoints.m_Control1));
            contour.AddPoint(ContourPoint(ContourPoint::OFF_CURVE, bestPoints.m_Control2));
            contour.AddPoint(ContourPoint(ContourPoint::ON_CURVE,  bestPoints.m_End));
            return true;

        }
    }

    // Didn't work: split in two and try the two halves.
    int half = numQuads / 2;

    if (numQuads > 2)
    {
        QuadPoints midQuad = m_QuadPoints[half];

        if (ManhattenDistance(first.m_Start, midQuad.m_Start) < (ManhattenDistance(midQuad.m_Start, last.m_End) - 10))
        {
            half++;
        }
    }

    CompositQuadBezier leftSide;
    CompositQuadBezier rightSide;

    for (int i = 0; i < half; i++)
    {
        leftSide.AddQuad(m_QuadPoints[i]);
    }

    for (int j = half; j < numQuads; j++)
    {
        rightSide.AddQuad(m_QuadPoints[j]);
    }

    // Try with first half, then second. Note recursive.
    leftSide.Match(contour, tolerance);
    rightSide.Match(contour, tolerance);

    // Recursion ends when numQuads == 1.
    // We always return a cubic for that at top of method.
    // Hence we should never get here...
    return true;
}

double CompositQuadBezier::MiddleDistance(CubicBezier& cubic)
{
    int stopIndex   = m_Points.NumElements();

    double distance = FLOAT_MAX;

    Line2D segment;
    cubic.GetCenterSegment(segment);

    // Look for intersection with segment.
    for (int j = 0; j < stopIndex; j++)
    {
        if (segment.SegsIntersect(m_NormalLines[j]))
        {
            double currentDistance = segment.PointDistance(m_MidPoints[j]);

            // Get the smallest intersection.
            if (currentDistance < distance)
            {
                if (distance < m_Tolerance)
                {
                    return currentDistance;
                }
                distance = currentDistance;
            }
        }
    }
 
    return distance;
}

bool CompositQuadBezier::IsLinear(float tolerance)
{
    bool foundIntersection = false;

    Vector2f first(m_Points.First());
    Vector2f last (m_Points.Last());

    if (first == last)
    {
        return false;
    }

    Line2D line(first, last);

    // Look for intersection with segment.
    for (int j = 0; j < m_NormalLines.NumElements(); j++)
    {
        if (m_NormalLines[j].SegsIntersect(line))
        {
            foundIntersection = true;
            double currentDistance = line.PointDistance(m_MidPoints[j]);

            if (currentDistance > tolerance)
            {
                return false;
            }
        }
    }

    // Only return true if we actually found an intersection to calc a distance from.
    return foundIntersection;
}

void CompositQuadBezier::CreateNormals()
{
    m_NormalLines.Clear();
    m_MidPoints.Clear();

    int numSegments = m_Points.NumElements() - 1;

    for (int i = 0; i < numSegments; i++)
    {
        Line2D currentSegment(m_Points[i], m_Points[i+1]);
        // Create the normal to the segment:

        double xDelta = m_Points[i+1][0] - m_Points[i][0];
        double yDelta = m_Points[i+1][1] - m_Points[i][1];

        // Calc the unit normal vector.
        Vector2 normal(-yDelta, xDelta);
        normal.Normalize();
        normal = 4096.0 * normal;

        // Extend normal both ways.
        Vector2 midPoint = currentSegment.Interpolate(0.5f);
        Line2D normalLine(midPoint + normal, midPoint - normal);
        
        m_NormalLines.Add(normalLine);
        m_MidPoints.Add(midPoint);
    }
}

void CompositQuadBezier::CreateTangents()
{
    m_AllTangents.Clear();

    for (int i = 0; i < m_Points.NumElements()-1; i++)
    {
        Line2D line(m_Points[i], m_Points[i+1]);
        line.Extend(10000.0f);
        m_AllTangents.Add(line);
    }
}

double CompositQuadBezier::SplineDistance(CubicBezier& cubic)
{
    // Usually worse fit at the middle so check that first.
    // Note we don't CreateSegments unless this fails.
    double middleDist = MiddleDistance(cubic);

    if (middleDist > m_Tolerance)
    {
        return middleDist;
    }

    cubic.CreateSegments();
    int numSegments = cubic.m_Points.NumElements() - 1;

    double largestDistance = 0.0f;
    bool anyIntersections = false;

    int stopIndex = m_Points.NumElements();
    int largestIntesected = 0;

    for (int i = 0; i < numSegments; i++)
    {
        double distance = FLOAT_MAX;
        bool   foundIntersection = false;

        Line2D segment(cubic.m_Points[i], cubic.m_Points[i+1]);

        // Look for intersection with segment.
        for (int j = largestIntesected; j < stopIndex; j++)
        {
            //if (m_NormalLines[j].SegsIntersect(segment))
            if (segment.SegsIntersect(m_NormalLines[j]))
            {
                anyIntersections  = true;
                foundIntersection = true;

                largestIntesected = j;

                double currentDistance = segment.PointDistance(m_MidPoints[j]);

                // Get the smallest intersection.
                if (currentDistance < distance)
                {
                    distance = currentDistance;
                    if (distance < m_Tolerance)
                    {
                        break;
                    }
                }
            }
        }

        if (foundIntersection) // Avoid adding FLOAT_MAX if no intersection.
        {
            if (distance > largestDistance)
            {
                largestDistance = distance;

                if (largestDistance > m_Tolerance)
                {
                    return largestDistance;
                }
            }
        }
    }

    if (false == anyIntersections)
    {
        largestDistance = FLOAT_MAX;
    }

    return largestDistance;
}

