// Copyright (C) 2014 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// QuadBezier.cpp

#include "QuadBezier.h"
#include "Stack.h"
#include "ContourPoint.h"
#include "CubicContour.h"

QuadBezier::QuadBezier()
{
}

void QuadBezier::Clear()
{
    m_Control[eSTART]   = Vector2f(0.0f, 0.0f);
    m_Control[eEND]     = Vector2f(0.0f, 0.0f);
    m_Control[eCONTROL] = Vector2f(0.0f, 0.0f);

    m_Points.Clear();
}

QuadBezier::QuadBezier(const Vector2f& startPoint, const Vector2f& endPoint, const Vector2f& controlPoint)
{
    Init(startPoint, endPoint, controlPoint);
}

QuadBezier::QuadBezier(QuadPoints& points)
{
    Init(points.m_Start, points.m_End, points.m_Control);
}

void QuadBezier::Init(const Vector2f& startPoint, const Vector2f& endPoint, const Vector2f& controlPoint)
{
    m_Control[eSTART]   = startPoint;
    m_Control[eEND]     = endPoint;
    m_Control[eCONTROL] = controlPoint;
}

QuadBezier& QuadBezier::operator=(const QuadBezier& other)
{
    if (this != &other)
    {
        m_Points.Clear();
        m_Points = other.m_Points;

        m_Control[eSTART]   = other.m_Control[eSTART];
        m_Control[eEND]     = other.m_Control[eEND]; 
        m_Control[eCONTROL] = other.m_Control[eCONTROL];
    }
    return *this;
}

int QuadBezier::NeededDepth(float flatness)
{
    Vector2f left;
    Vector2f right;
    Vector2f middle;

    Vector2f    start   = m_Control[eSTART];
    Vector2f    control = m_Control[eCONTROL];
    Vector2f    end     = m_Control[eEND];

    int depth = 0;

    for (;;)
    {
        // Find the mid curve point of these controls:
        left   = 0.5f * (start + control);
        right  = 0.5f * (end   + control);
        middle = 0.5f * (left + right);

        // Evaluate their flatness:
        Vector2f distance(middle - control);
        float len = distance.LengthSquared();

        if (len < flatness)
        {
            depth = depth == 0 ? 1 : depth;
            return depth;
        }
        else
        {
            start = middle;
            control = right;
            depth++;
        }
    }
    //depth = depth == 0 ? 1 : depth;
    //return depth;
}


void QuadBezier::FastEvaluate(float flatness)
{
    int depth = NeededDepth(flatness);
    
    m_Points.Clear();

    static bool once = true;
    if (once)
    {
        printf("Using Experimental QuadBezier::Evaluate\n");
        once = false;
    }
    static Vector2f* bufOne = new Vector2f[(1 << (9 + 1)) + 1];
    static Vector2f* bufTwo = new Vector2f[(1 << (9 + 1)) + 1];

    Vector2f* front = bufOne;
    Vector2f* back =  bufTwo;
    Vector2f* pTemp;

    bufTwo[0] = m_Control[eSTART];
    bufTwo[1] = m_Control[eCONTROL];
    bufTwo[2] = m_Control[eEND];

    
    int currentDepth = 0;
    int numSets = 1;

    Vector2f start;
    Vector2f control;
    Vector2f end;

    Vector2f left;
    Vector2f right;
    Vector2f middle;

    int index = 0;

    while (currentDepth < depth)
    {
        index = 0;
        for (int i = 0; i < numSets; i++)
        {
            start   = back[i*2];
            control = back[i*2 + 1];
            end     = back[i*2 + 2];

            // Find the mid curve point of these controls:
            left   = 0.5f * (start + control);
            right  = 0.5f * (end   + control);
            middle = 0.5f * (left  + right);

            front[index++] = start;
            front[index++] = left;
            front[index++] = middle;
            front[index++] = right;
        }
        front[index++] = end;

        numSets *= 2;
        currentDepth++;
        pTemp = front;
        front = back;
        back = pTemp;
    }

    m_Points.Add(back[0]);
    for (int i = 0; i < numSets; i++)
    {
        start   = back[i*2];
        control = back[i*2 + 1];
        end     = back[i*2 + 2];

        // Find the mid curve point of these controls:
        left   = 0.5f * (start + control);
        right  = 0.5f * (end   + control);
        middle = 0.5f * (left  + right);
        m_Points.Add(middle);
    }
    m_Points.Add(back[index - 1]);
}

void QuadBezier::Evaluate(float flatness)
{
    Vector2f left;
    Vector2f right;
    Vector2f middle;

    Stack<QuadPoints> stack;
    m_Points.Clear();

    m_Points.Add(m_Control[eSTART]);

    QuadPoints points;

    points.Set(m_Control[eSTART], m_Control[eEND], m_Control[eCONTROL]);

    stack.Push(points);

    while (false == stack.IsEmpty())
    {
        points = stack.Pop();

        // Find the mid curve point of these controls:
        left   = 0.5f * (points.m_Start + points.m_Control);
        right  = 0.5f * (points.m_End   + points.m_Control);
        middle = 0.5f * (left + right);

        // Make sure we don't recurse for ever or return Nan's etc.
        if (middle.IsValid())
        {
            // Evaluate their flatness:
            Vector2f distance(middle - points.m_Control);
            float len = distance.LengthSquared();

            if (len < flatness)
            {
                m_Points.Add(middle);
            }
            else
            {
                QuadPoints quadLeft;
                QuadPoints quadRight;

                // Split in two and keep going:
                quadLeft.Set(middle, points.m_End, right);
                stack.Push(quadLeft);

                quadRight.Set(points.m_Start, middle, left);
                stack.Push(quadRight);
            }
        }
    }
    m_Points.Add(m_Control[eEND]);
}


Vector2f QuadBezier::CalculatePoint(float t)
{
    // Interpolate to get two subsequent points.
    Vector2f a = Interpolate(m_Control[eSTART], m_Control[eCONTROL], t);
    Vector2f b = Interpolate(m_Control[eCONTROL], m_Control[eEND], t);
    
    // Interpolate these to get result.
    Vector2f c = Interpolate(a, b, t);

    return c;
}


Vector2f QuadBezier::Interpolate(Vector2f& a, Vector2f& b, float t)
{

    float x = a[0] + (b[0] - a[0]) * t;
    float y = a[1] + (b[1] - a[1]) * t;

    return Vector2f(x, y);
}



void QuadBezier::SetPoint(Control control, const Vector2f& point)
{
    m_Control[control] = point;
}

void QuadBezier::SetPoints(const Vector2f& startPoint, const Vector2f& endPoint, const Vector2f& controlPoint)
{
    m_Control[eSTART]    = startPoint;
    m_Control[eEND]      = endPoint;
    m_Control[eCONTROL]  = controlPoint;
}

Vector2f QuadBezier::GetPoint(Control control)
{
    return m_Control[control];
}


bool QuadBezier::Match(CubicContour& cubicContour, float tolerance)
{
    (void) tolerance;
    bool success = false;

    // Stupid small.
    if (ManhattenDistance(m_Control[eSTART], m_Control[eEND]) <= 3.0f)
    {
        cubicContour.AddPoint(ContourPoint(ContourPoint::LINE_TO,  m_Control[eEND]), true);
        return true;
    }

    // Degenerate control: actually a line.
    if (    (m_Control[eSTART] == m_Control[eCONTROL]) ||
            (m_Control[eEND]   == m_Control[eCONTROL]))
    {
        cubicContour.AddPoint(ContourPoint(ContourPoint::LINE_TO,  m_Control[eEND]), true);
        return true;
    }

    // Horiz or vertical line.
    if (    ((m_Control[eSTART][0] == m_Control[eCONTROL][0]) && (m_Control[eSTART][0] == m_Control[eEND][0])) ||
            ((m_Control[eSTART][1] == m_Control[eCONTROL][1]) && (m_Control[eSTART][1] == m_Control[eEND][1])) )
    {
        cubicContour.AddPoint(ContourPoint(ContourPoint::LINE_TO, m_Control[eEND]), true);
        return true;
    }

    float twoThirds = 2.0f / 3.0f;
    Vector2f control1 = m_Control[eSTART] + twoThirds * (m_Control[eCONTROL] - m_Control[eSTART]);
    Vector2f control2 = m_Control[eEND]   + twoThirds * (m_Control[eCONTROL] - m_Control[eEND]);

    control1 = control1.Rounded();
    control2 = control2.Rounded();

    if ((control1.IsValid()) && control2.IsValid())
    {
        ContourPoint contourControl1(ContourPoint::OFF_CURVE, control1); 
        ContourPoint contourControl2(ContourPoint::OFF_CURVE, control2);
        ContourPoint contourEnd     (ContourPoint::ON_CURVE,  m_Control[eEND]);

        cubicContour.AddPoint(contourControl1);
        cubicContour.AddPoint(contourControl2);
        cubicContour.AddPoint(contourEnd);

        success = true;
    }

    return success;
}
