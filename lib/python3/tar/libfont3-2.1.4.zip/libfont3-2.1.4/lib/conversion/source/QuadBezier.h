// Copyright (C) 2014 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
/// \file QuadBezier.h

#ifndef QUAD_BEZIER_H
#define QUAD_BEZIER_H

#include "QuadPoints.h"
#include "ArrayList.h"
#include "Vector2f.h"

class CubicContour;

class  QuadBezier
{
    public:

        enum Control { eSTART = 0, eEND, eCONTROL };
        /* Ctor */  QuadBezier  ();
        /* Ctor */  QuadBezier  (const Vector2f& startPoint, const Vector2f& endPoint, const Vector2f& controlPoint);
        /* Ctor */  QuadBezier  (QuadPoints& points);
        void        Init        (const Vector2f& startPoint, const Vector2f& endPoint, const Vector2f& controlPoint);

        void        Clear       ();
        QuadBezier& operator=    (const QuadBezier& other);
        

        void        SetPoint    (Control control, const Vector2f& point);
        void        SetPoints   (const Vector2f& startPoint, const Vector2f& endPoint, const Vector2f& controlPoint);
        Vector2f    GetPoint    (Control control);

        void        Evaluate    (float flatness = 0.01f);
        void        FastEvaluate(float flatness = 0.01f);

        bool        Match       (CubicContour& cubicContour, float tolerance);

    protected:

        int         NeededDepth (float flatness);

        Vector2f                CalculatePoint  (float t);

        Vector2f                Interpolate     (Vector2f& a, Vector2f& b, float t);

        ArrayList<Vector2f>     m_Points;

        Vector2f                m_Control[3];

        friend class CubicBezier;
        friend class CompositQuadBezier;
        friend class DynamicQuad;
};

#endif
