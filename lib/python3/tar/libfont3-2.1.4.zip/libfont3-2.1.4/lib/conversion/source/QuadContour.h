// Copyright (C) 2015 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
/// \file QuadContour.h

#ifndef QUAD_CONTOUR_H
#define QUAD_CONTOUR_H

#include "Contour.h"
#include "QuadPoints.h"
class CubicContour;

class QuadContour : public Contour
{
    public:
        /*  CTOR */     QuadContour(int designUnits = DEFAULT_QUAD_UNITS);

        bool            Match       (CubicContour& cubicContour, float tolerance);
        bool            Match       (QuadContour& quadContour, float tolerance);

        void            StripImplicitMidPoints();

        void            EmitAnyQuads();

    protected:

        bool                    m_Stripped;
        ArrayList<QuadPoints>   m_CurrentRun;
        ArrayList<ContourPoint> m_NewPoints;

};

#endif

