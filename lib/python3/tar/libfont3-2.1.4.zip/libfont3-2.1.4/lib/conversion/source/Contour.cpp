// Copyright (C) 2015 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// Contour.cpp

#include "Contour.h"
#include "MathUtilities.h"
#include <stdio.h>

Contour::Contour()
        : m_DesignUnits(DEFAULT_QUAD_UNITS),
          m_Scale(1.0f),
          m_Changed(true)
{
    Clear();
}

Contour::Contour(int designUnits)
: m_DesignUnits(designUnits), m_Scale(1.0f)
{
    Clear();
}

void Contour::AddPoint(const ContourPoint& point, bool stripDuplicates /* = false */)
{
    m_Changed = true;

    // Assure that incoming points are integer.
    ContourPoint newPoint = point;
    newPoint.m_Point = newPoint.m_Point.Rounded();

    if (stripDuplicates)
    {
        // Different go ahead and add it.
        if (newPoint.m_Point != m_LastPoint)
        {
            m_Points.Add(newPoint);
            m_LastPoint = newPoint.m_Point;
        }
        else
        {
            // Same position. Make sure we add a on curve point if needed.
            if ((newPoint.m_Type == ContourPoint::ON_CURVE) &&
                (m_Points.Last().m_Type == ContourPoint::OFF_CURVE))
            {
                m_Points.Last().m_Type = ContourPoint::ON_CURVE;
            }
        }
    }
    else
    {
        m_Points.Add(newPoint);
        m_LastPoint = newPoint.m_Point;
    }
}


void Contour::Clear()
{
    m_Points.Clear();
    m_LastPoint = Vector2f(0.0f, 0.0f);
} 


int Contour::NumPoints()
{
    return m_Points.NumElements();
}

ContourPoint& Contour::GetPoint(int index)
{
    return m_Points[index];
}

void Contour::SetDesignUnits(int designUnits)
{
    m_DesignUnits = designUnits;
}

int Contour::GetDesignUnits()
{
    return m_DesignUnits;
}

void Contour::ScaleTo(int newUnits)
{
    m_Scale = (float) newUnits / (float) m_DesignUnits;

    if (m_Scale != 1.0f)
    {
        int numPoints = m_Points.NumElements();

        for (int i = 0; i < numPoints; i++)
        {
            m_Points[i].m_Point *= m_Scale;
            m_Points[i].m_Point = m_Points[i].m_Point.Rounded();
        }
    }

    m_DesignUnits = newUnits;
}

bool Contour::IsClosed()
{
    if (m_Points.NumElements() == 1)
        return false;

    if ((m_Points[0].m_Point == m_Points[m_Points.NumElements() - 1].m_Point) &&
        (m_Points[m_Points.NumElements() - 1].m_Type != ContourPoint::OFF_CURVE))
    {
        return true;
    }

    return false;
}


bool Contour::OffIntegerPoints()
{
    bool  offInteger = false;

    int numPoints = m_Points.NumElements();

    for (int i = 0; i < numPoints; i++)
    {
        Vector2f point = m_Points[i].m_Point;
        Vector2f rounded = point.Rounded();

        if (rounded != point)
        {
            printf("Off-Integer point %d (%f, %f)\n", i, point[0], point[1]);
            offInteger = true;
        }
    }

    return offInteger;
}

bool Contour::DuplicatePoints()
{
    bool duplicatePoints = false;

    int numPoints = m_Points.NumElements();


    for (int i = 0; i < numPoints - 1; i++)
    {
        Vector2f one = m_Points[i].m_Point;
        Vector2f two = m_Points[i+1].m_Point;

        if (m_Points[i].m_Point == m_Points[i+1].m_Point)
        {
            printf("Duplicate Points: %d %d\n", i, i+1);
            duplicatePoints = true;
        }
    }

    return duplicatePoints;
}

bool Contour::InvalidPoints()
{
    bool invalidPoints = false;

    int numPoints = m_Points.NumElements();

    for (int i = 0; i < numPoints; i++)
    {
        if (false == m_Points[i].m_Point.IsValid())
        {
            printf("Invalid point: %d \n", i);
            invalidPoints = true;
        }
    }

    return invalidPoints;
}

void Contour::PrintToFile(FILE* pFile)
{
    int numPoints = m_Points.NumElements();

    for (int i = 0; i < numPoints; i++)
    {
        m_Points[i].PrintToFile(pFile);
    }
}

/*
    If findAll is false just mark points with kinks.
*/
void Contour::FindExtrema(bool findAll /* = true */)
{
    ArrayList<ContourPoint*> m_CurvePoints;

    for (int i = 0; i < m_Points.NumElements(); i++)
    {
        ContourPoint& currentPoint = m_Points[i];

        m_CurvePoints.Add(&currentPoint);
    }

    int numPoints = m_CurvePoints.NumElements();

    for (int currIndex = 0; currIndex < numPoints; currIndex++)
    {
        int prevIndex = currIndex - 1;
        if (prevIndex < 0)
        {
            prevIndex = numPoints - 1;
        }

        int nextIndex = currIndex + 1;
        if (nextIndex >= numPoints)
        {
            nextIndex = 0;
        }

        ContourPoint* previousPoint = m_CurvePoints[prevIndex];
        ContourPoint* currentPoint  = m_CurvePoints[currIndex];
        ContourPoint* nextPoint     = m_CurvePoints[nextIndex];

        // If the points are
        bool areLinear = Linear(previousPoint->m_Point, currentPoint->m_Point, nextPoint->m_Point);
        bool isExtremum = false;

        if (findAll)
        {
            if ( (   m_CurvePoints[prevIndex]->m_Type == ContourPoint::LINE_TO   ) ||
                 (   m_CurvePoints[currIndex]->m_Type == ContourPoint::LINE_TO   ) ||
                 (   m_CurvePoints[nextIndex]->m_Type == ContourPoint::LINE_TO   ) ||
                 (   false == areLinear                                          ) ||
                 (  (currentPoint->m_Point[0] >= previousPoint->m_Point[0]) && (currentPoint->m_Point[0] >= nextPoint->m_Point[0])) ||
                 (  (currentPoint->m_Point[0] <= previousPoint->m_Point[0]) && (currentPoint->m_Point[0] <= nextPoint->m_Point[0])) ||
                 (  (currentPoint->m_Point[1] >= previousPoint->m_Point[1]) && (currentPoint->m_Point[1] >= nextPoint->m_Point[1])) ||
                 (  (currentPoint->m_Point[1] <= previousPoint->m_Point[1]) && (currentPoint->m_Point[1] <= nextPoint->m_Point[1])) ) 
            {
                isExtremum = true;
            }
        }
        else
        {
            if (false == areLinear)
            {
                isExtremum = true;
            }
        }

        currentPoint->m_IsExtremum = isExtremum;
    }
}

void Contour::Reverse()
{
    ArrayList<ContourPoint> reversedPoints;

    int numPoints = m_Points.NumElements();

    if (numPoints != 0)
    {
        // Initial MOVE_TO is same for both.
        reversedPoints.Add(m_Points[0]);

        ContourPoint lastPoint = m_Points[numPoints - 1];

        // Work backwards, one in from the last point.
        for (int i = numPoints - 2; i >= 0; i--)
        {
            ContourPoint& currentPoint = m_Points[i];
            ContourPoint point;

            switch (currentPoint.m_Type)
            {
                case ContourPoint::MOVE_TO:
                case ContourPoint::LINE_TO:

                    if (lastPoint.m_Type == ContourPoint::LINE_TO)
                    {
                        point.m_Type = ContourPoint::LINE_TO;
                        point.m_Point = currentPoint.m_Point;
                        reversedPoints.Add(point);
                    }
                    else
                    {
                        point.m_Type = ContourPoint::ON_CURVE;
                        point.m_Point = currentPoint.m_Point;
                        reversedPoints.Add(point);
                    }
                break;
                case ContourPoint::ON_CURVE:
                    if (lastPoint.m_Type == ContourPoint::LINE_TO)
                    {
                        point.m_Type = ContourPoint::LINE_TO;
                        point.m_Point = currentPoint.m_Point;
                        reversedPoints.Add(point);
                    }
                    else
                    {
                        reversedPoints.Add(currentPoint);
                    }
                break;
                case ContourPoint::OFF_CURVE:
                    reversedPoints.Add(currentPoint);
                break;
            }

            lastPoint = currentPoint;
        }

        m_Points = reversedPoints;
    }
}
