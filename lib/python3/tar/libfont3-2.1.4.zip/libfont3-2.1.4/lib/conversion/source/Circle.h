// Copyright (C) 2014 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
/// \file Circle.h

#ifndef CIRCLE_H
#define CIRCLE_H

#include "Vector2.h"

class Line2D;

//! Describes a circle in 2D space
/*!
    Provides methods to determine if the circle intersects with a line segment. 
    See also Vector2 and Line2D.
*/
class Circle
{
    public:
        /* Ctor */ Circle       ();
        /* Ctor */ Circle       (const Vector2& center, double radius);

        bool       IsInside     (const Vector2& point);
        bool       Intersects   (const Line2D& line);
        Vector2    Center       () const;
        double     Radius       () const;
        double     RadiusSquared() const;

    protected:

        Vector2     m_Center;
        double      m_Radius;
        double      m_RadiusSquared;
};

#endif
