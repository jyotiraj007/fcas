// Copyright (C) 2015 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
/// \file CompositCubicBezier.h

#ifndef COMPOSIT_CUBIC_BEZIER_H
#define COMPOSIT_CUBIC_BEZIER_H

#include "CubicBezier.h"
#include "ArrayList.h"
#include "CubicContour.h"


class CompositCubicBezier : public CubicBezier
{
    public:
        /* CTOR */ CompositCubicBezier  ();
        void       AddCubic             (Vector2f startPoint, Vector2f endPoint, Vector2f controlPoint1, Vector2f controlPoint2);
        void       AddCubic             (const CubicPoints& points);

        void       Evaluate             ();

        void       Clear                ();
        int        NumComponents        ();

        bool       Match               (CubicContour& contour, float tolerance);

    protected:

        CubicPoints     MergeTwo       (CubicPoints& one, CubicPoints& two);
        float           Distance       (CubicPoints& one, CubicPoints& two, CubicPoints& both);
        double          SplineDistance (CubicBezier& cubic);
        double          MiddleDistance (CubicBezier& cubic);


        ArrayList<CubicPoints> m_CubicPoints;

};

#endif
