#ifndef DEFINES_H
#define DEFINES_H

#define DEFAULT_QUAD_UNITS 1000
#define DEFAULT_CUBIC_UNITS 1000
//#define ROUND_TRIP 1

//#define NEW_ALG
 

#endif

