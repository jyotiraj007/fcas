#ifndef QUAD_POINTS_H
#define QUAD_POINTS_H

#include "Vector2f.h"

struct QuadPoints
{
    QuadPoints() {};

    QuadPoints(const Vector2f& start, const Vector2f& end, const Vector2f& control)
        : m_Start   (start),
          m_End     (end),
          m_Control (control)
    {
    }

    void Set(const Vector2f& start, const Vector2f& end, const Vector2f& control)
    {
        m_Start     = start;
        m_End       = end;
        m_Control   = control;
    }

    Vector2f    m_Start;
    Vector2f    m_End;
    Vector2f    m_Control;
};


#endif

