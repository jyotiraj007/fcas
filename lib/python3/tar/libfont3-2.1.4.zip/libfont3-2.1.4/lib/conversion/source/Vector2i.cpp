// Copyright (C) 2014 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// Vector2i.cpp

#include "Vector2i.h"
#include <math.h>


Vector2i::Vector2i(int x /* = 0 */, int y /* = 0 */)
{
    m_Vector[0] = x;
    m_Vector[1] = y;
}

Vector2i::Vector2i(Vector2f& other)
{
    Vector2f rounded = other.Rounded();

    m_Vector[0] = (int) rounded[0];
    m_Vector[1] = (int) rounded[1];
}

/**
    Computes length of vector.
    @return length of vector.
*/
float Vector2i::Length() const
{
    float length = (float)sqrt((float)(m_Vector[0] * m_Vector[0] + m_Vector[1] * m_Vector[1]));
    return length;
}

Vector2i Vector2i::operator-(const Vector2i& other) const
{
    return Vector2i(m_Vector[0] - other.m_Vector[0], m_Vector[1] - other.m_Vector[1]);
}
