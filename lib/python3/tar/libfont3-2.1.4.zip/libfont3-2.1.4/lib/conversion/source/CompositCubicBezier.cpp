// Copyright (C) 2015 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// CompositCubicBezier.cpp

#include "CubicBezier.h"
#include "CompositCubicBezier.h"
#include "MathUtilities.h"
#include "BresenhamLine.h"

CompositCubicBezier::CompositCubicBezier()
{
}

void CompositCubicBezier::AddCubic(Vector2f startPoint, Vector2f endPoint, Vector2f controlPoint1, Vector2f controlPoint2)
{
    CubicPoints points(startPoint, endPoint, controlPoint1, controlPoint2);

    m_CubicPoints.Add(points);
}

void CompositCubicBezier::AddCubic(const CubicPoints& points)
{
    m_CubicPoints.Add(points);
}


void CompositCubicBezier::Evaluate()
{
    int numCubics = m_CubicPoints.NumElements();
    m_Points.Clear();
    m_NumSegments = 0;

    for (int i = 0; i < numCubics; i++)
    {
        CubicPoints points = m_CubicPoints[i];
        CubicBezier bezier(points.m_Start, points.m_End, points.m_Control1, points.m_Control2);
        bezier.Evaluate();

        m_Points += bezier.m_Points;
        m_NumSegments += bezier.m_NumSegments;
    }

    m_Control[eSTART]    = m_CubicPoints[0].m_Start;
    m_Control[eCONTROL1] = m_CubicPoints[0].m_Control1;
    m_Control[eCONTROL2] = m_CubicPoints[numCubics - 1].m_Control2;
    m_Control[eEND]      = m_CubicPoints[numCubics - 1].m_End;
}

void CompositCubicBezier::Clear()
{
    m_CubicPoints.Clear();
    m_Points.Clear();
}

int CompositCubicBezier::NumComponents()
{
    return m_CubicPoints.NumElements();
}


bool CompositCubicBezier::Match(CubicContour& contour, float tolerance)
{
    int numCubics = m_CubicPoints.NumElements();

    CubicPoints first = m_CubicPoints.First();

    if (numCubics == 1)
    {
        if (first.IsLinear(tolerance * 2))
        {
            contour.AddPoint(ContourPoint(ContourPoint::LINE_TO, first.m_End));
        }
        else
        {
            contour.AddPoint(ContourPoint(ContourPoint::OFF_CURVE, first.m_Control1));
            contour.AddPoint(ContourPoint(ContourPoint::OFF_CURVE, first.m_Control2));
            contour.AddPoint(ContourPoint(ContourPoint::ON_CURVE,  first.m_End));
        }

        return true;
    }

    CubicPoints last  = m_CubicPoints.Last();

    m_Tolerance = tolerance;
    Evaluate();
    CreateNormals();

    m_StartTangent = Line2D(first.m_Control1, first.m_Start);
    m_EndTangent   = Line2D(last.m_Control2, last.m_End);

    Vector2f intersection = m_StartTangent.Intersects(m_EndTangent);

    intersection = intersection.Rounded();

    // Separate x and y components.
    BresenhamLine startTangent(first.m_Start, intersection);  //bb m_control1
    BresenhamLine endTangent  (intersection, last.m_End);     //bb m_Control2

    // Check for general unhappiness:
    if (    (first.m_Start != last.m_End)       &&     // Loop: no extrema.    
            (first.m_Start != first.m_Control1) &&     // Degenerate first quad.
            (last.m_Control2 != last.m_End)     &&     // Degenerate last quad.
            intersection.IsValid()              &&     // Nan's in result.
            (startTangent.Length() < 500)       &&     // Parallel or nearly parallel will create too long tangents.
            (endTangent.Length()   < 500) )
    {
        CubicPoints bestPoints;
        float       smallest = FLOAT_MAX;

        CubicBezier cubic;
        cubic.SetPoint(CubicBezier::eSTART, first.m_Start);
        cubic.SetPoint(CubicBezier::eEND,   last.m_End);

        // Store the end handle results in an array and reuse.
        ArrayList<Vector2i> endHandleList;

        Vector2i point;
        bool newEndHandle = endTangent.FirstPoint(point);

        while (newEndHandle)
        {
            endHandleList.Add(point);
            newEndHandle = endTangent.NextPoint(point);
        }

        int endMax = endHandleList.NumElements() - 1; 

        ArrayList<Vector2i> startHandleList;

        // Store the start handle results in an array.
        bool newStartHandle = startTangent.FirstPoint(point);

        while (newStartHandle)
        {
            startHandleList.Add(point);
            newStartHandle = startTangent.NextPoint(point);
        }

        int startIndex = 0;
        int startMax = startHandleList.NumElements();

        bool anyThisHandle;

        Vector2i& startHandle = point;
        Vector2i& endHandle   = point;

        // Walk each line testing as control point for cubic.
        while (startIndex < startMax)
        {
            startHandle = startHandleList[startIndex];

            anyThisHandle = false;
            cubic.SetPoint(CubicBezier::eCONTROL1, startHandle);

            int endIndex = 1;

            while (endIndex < endMax)
            {
                endHandle = endHandleList[endIndex];
                cubic.SetPoint(CubicBezier::eCONTROL2, endHandle);

                float distance = (float) SplineDistance(cubic);

                if (distance < smallest)
                {
                    CubicPoints points;
                    cubic.GetPoints(points);

                    // Don't add degenerate points.
                    if (    (points.m_Control1 != points.m_Control2) &&
                            (points.m_Start    != points.m_Control1) &&
                            (points.m_End      != points.m_Control2) )
                    {
                        smallest = distance;
                        bestPoints = points;
                        if (smallest < m_Tolerance)
                        {
                            anyThisHandle = true;
                            break;
                        }
                    }
                }

                int add = 6;
                if (distance < m_Tolerance * 2)
                {
                    add = 1;
                }

                endIndex += add;
            }

            if (false == anyThisHandle)
            {
                startIndex += 6;
            }
            startIndex += 1;
        }

        if (smallest < m_Tolerance)
        {
            contour.AddPoint(ContourPoint(ContourPoint::OFF_CURVE, bestPoints.m_Control1));
            contour.AddPoint(ContourPoint(ContourPoint::OFF_CURVE, bestPoints.m_Control2));
            contour.AddPoint(ContourPoint(ContourPoint::ON_CURVE,  bestPoints.m_End));
            return true;

        }
    }

    // Didn't work: split in two and try the two halves.
    int half = numCubics / 2;

    if (numCubics > 2)
    {
        CubicPoints midCubic = m_CubicPoints[half];

        if (ManhattenDistance(first.m_Start, midCubic.m_Start) < (ManhattenDistance(midCubic.m_Start, last.m_End) - 10))
        {
            half++;
        }
    }

    CompositCubicBezier leftSide;
    CompositCubicBezier rightSide;

    for (int i = 0; i < half; i++)
    {
        leftSide.AddCubic(m_CubicPoints[i]);
    }

    for (int j = half; j < numCubics; j++)
    {
        rightSide.AddCubic(m_CubicPoints[j]);
    }

    // Try with first half, then second. Note recursive.
    leftSide.Match(contour, tolerance);
    rightSide.Match(contour, tolerance);

    // Recursion ends when numQuads == 1.
    // We always return a cubic for that at top of method.
    // Hence we should never get here...
    return true;
}

double CompositCubicBezier::SplineDistance(CubicBezier& cubic)
{
    // Usually worse fit at the middle so check that first.
    // Note we don't CreateSegments unless this fails.
    double middleDist = MiddleDistance(cubic);

    int numIntersections = 0;

    if (middleDist > m_Tolerance)
    {
        return middleDist;
    }

    cubic.CreateSegments();
    int numSegments = cubic.m_Points.NumElements() - 1;

    double largestDistance = 0.0f;

    int stopIndex = m_Points.NumElements();
    int largestIntesected = 0;

    // Look for intersection with segment.
    for (int j = 0; j < stopIndex; j++)
    {
        double distance = FLOAT_MAX;
        bool   foundIntersection = false;

        for (int i = largestIntesected; i < numSegments; i++)
        {
            Line2D segment(cubic.m_Points[i], cubic.m_Points[i+1]);

            if (segment.SegsIntersect(m_NormalLines[j]))
            {
                numIntersections++;
                foundIntersection = true;

                largestIntesected = i;

                double currentDistance = segment.PointDistance(m_MidPoints[j]);

                // Get the smallest intersection.
                if (currentDistance < distance)
                {
                    distance = currentDistance;
                    if (distance < m_Tolerance)
                    {
                        break;
                    }
                }
            }
        }

        if (foundIntersection) // Avoid adding FLOAT_MAX if no intersection.
        {
            if (distance > largestDistance)
            {
                largestDistance = distance;

                if (largestDistance > m_Tolerance)
                {
                    return largestDistance;
                }
            }
        }
    }


    // Reject degenerate quads with low hit rate.
    float percentMatch = (float)numIntersections / (float)stopIndex;

    if (percentMatch < 0.5f)
    {
        largestDistance = FLOAT_MAX;
    }

    return largestDistance;
}


double CompositCubicBezier::MiddleDistance(CubicBezier& cubic)
{
    int stopIndex   = m_Points.NumElements();

    double distance = FLOAT_MAX;

    Line2D segment;
    cubic.GetCenterSegment(segment);

    // Look for intersection with segment.
    for (int j = 0; j < stopIndex; j++)
    {
        if (segment.SegsIntersect(m_NormalLines[j]))
        {
            double currentDistance = segment.PointDistance(m_MidPoints[j]);

            // Get the smallest intersection.
            if (currentDistance < distance)
            {
                if (distance < m_Tolerance)
                {
                    return currentDistance;
                }
                distance = currentDistance;
            }
        }
    }
 
    return distance;
}
