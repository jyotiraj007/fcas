// Copyright (C) 2014 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// LinkedList.h

#ifndef LINKED_LIST_H
#define LINKED_LIST_H

#include <stddef.h>

// The elements of the linked list.
// This element can be stored on numList number of lists at the same time,
// hence has multiple next pointers.
template<class Data, int numLists>
class Element
{
    public:
        Element(const Data& data)
            : m_Data(data)
        {
            // Initialize all the next pointers.
            for (int i = 0; i < numLists; i++)
            {
                m_Next[i] = NULL;
            }
        }

        Data        m_Data;             // The data we are storing on the list.
        Element*    m_Next[numLists];   // Array of next pointers.
};

/*
 A linked list class that supports many lists referencing the same nodes.
 i.e the nodes have multiple next pointers
 Example:

      enum { LIST_1 = 0, LIST_2 = 1 };

      MultiLinkedList<int, 2> m_List1(LIST_1);  // List of ints, 2 possible lists(2 next pointers), this will use the zeroeth next pointer.
      MultiLinkedList<int, 2> m_List2(LIST_2);  // List of ints, 2 possible lists(2 next pointers), this will use the [1] next pointer.

      // Create some elements:
      // ints with 2 next pointers.
      Element<int, 2>* elem1 = new Element<int, 2>(17);
      Element<int, 2>* elem2 = new Element<int, 2>(22);
      Element<int, 2>* elem3 = new Element<int, 2>(12);

      // Add the 3 elems to list 1.
      m_List1.Add(elem1); 
      m_List1.Add(elem2); 
      m_List1.Add(elem3); 

      // Add same 3 to list 2.
      m_List2.Add(elem1); 
      m_List2.Add(elem2); 
      m_List2.Add(elem3); 

      // Remove an elem from list 1.
      // We can do this because the lists are independent.
      // and list 2 will still contain the three elements.
      m_List1.Remove(elem2);
*/

template<class Data, int numLists>
class MultiLinkedList
{
    public:

        /* Ctor */          MultiLinkedList();
        /* Ctor */          MultiLinkedList(int listIndex);   // listIndex must be less than numLists.
        /* Dtor */         ~MultiLinkedList();

        void                Add             (Element<Data, numLists>* pElement);
        void                Remove          (Element<Data, numLists>* pElement);
        Element<Data, numLists>* RemoveFirst();
        void                InsertAfter     (Element<Data, numLists>* pElement, Element<Data, numLists>* pNewElement);

        Element<Data, numLists>*
                            GetPrevious     (const Element<Data, numLists>* pElement);
        Element<Data, numLists>*
                            GetNext         (const Element<Data, numLists>* pElement) const;

        void                RemoveAll       ();

        // Iterators:
        Data*               GetFirst        ();
        Data*               GetNext         ();
        Data*               GetLast         ();

        Element<Data, numLists>*    GetFirstElement ();
        Element<Data, numLists>*    GetNextElement  ();
        Element<Data, numLists>*    GetLastElement  ();

        bool                IsEmpty         () const;

    protected:

        Element<Data, numLists>*   m_Head;
        Element<Data, numLists>*   m_Tail;
        Element<Data, numLists>*   m_Iterator;
        int                        m_ListIdx;
};

template<class Data, int numLists>
MultiLinkedList<Data, numLists>::MultiLinkedList()
{
   m_Head    = NULL;
   m_Tail    = NULL;
   m_ListIdx = 0;
}


template<class Data, int numLists>
MultiLinkedList<Data, numLists>::MultiLinkedList(int listIndex)
{
   m_Head    = NULL;
   m_Tail    = NULL;
   m_ListIdx = listIndex;
}

template<class Data, int numLists>
MultiLinkedList<Data, numLists>::~MultiLinkedList()
{
}

template<class Data, int numLists>
void MultiLinkedList<Data, numLists>::Add(Element<Data, numLists>* pElement)
{
    if (NULL != pElement)
    {
        pElement->m_Next[m_ListIdx] = NULL;

        // If empty set head.
        if (IsEmpty())
        {
            m_Head = pElement;
            m_Tail = pElement;
        }
        else // Add to the end.
        {
            if (m_Tail != NULL)
                m_Tail->m_Next[m_ListIdx] = pElement;
            m_Tail                        = pElement;
        }
    }
}

template<class Data, int numLists>
void MultiLinkedList<Data, numLists>::Remove(Element<Data, numLists>* pElement)
{
    if (pElement)
    {
        Element<Data, numLists>* pPrevious = GetPrevious(pElement);

        // If it's the only element, null out head and tail pointers.
        if (m_Head == m_Tail)
        {
            m_Head = NULL;
            m_Tail = NULL;
        }
        else if (pElement == m_Head)
        {
            m_Head = m_Head->m_Next[m_ListIdx];
        }
        else if (pElement == m_Tail)
        {
            m_Tail = pPrevious;
        }

        if (pPrevious)
        {
            pPrevious->m_Next[m_ListIdx] = pElement->m_Next[m_ListIdx];
        }

        // No longer part of list so zero out pointer.
        pElement->m_Next[m_ListIdx] = NULL;
    }
}

template<class Data, int numLists>
Element<Data, numLists>* MultiLinkedList<Data, numLists>::RemoveFirst()
{
    Element<Data, numLists>* pElement = GetFirstElement();

    Remove(pElement);

    return pElement;
}

template<class Data, int numLists>
void MultiLinkedList<Data, numLists>::InsertAfter(Element<Data, numLists>* pElement, Element<Data, numLists>* pNewElement)
{
    if ((pElement == NULL) || (pNewElement == NULL))
        return;

    if (m_Tail == pElement)
    {
        m_Tail = pNewElement;
    }
    pNewElement->m_Next[m_ListIdx] = pElement->m_Next[m_ListIdx];
    pElement->m_Next[m_ListIdx]    = pNewElement;
}

template<class Data, int numLists>
Element<Data, numLists>*  MultiLinkedList<Data, numLists>::GetNext(const Element<Data, numLists>* pElement) const
{
    return pElement->m_Next[m_ListIdx];
}

template<class Data, int numLists>
Element<Data, numLists>*  MultiLinkedList<Data, numLists>::GetPrevious(const Element<Data, numLists>* pElement)
{
    Element<Data, numLists>* pCurrent  = m_Head;
    Element<Data, numLists>* pPrevious = NULL;

    while (pCurrent)
    {
        if (pCurrent == pElement)
        {
            return pPrevious;
        }
        pPrevious = pCurrent;
        pCurrent = pCurrent->m_Next[m_ListIdx];
    }
    return NULL;
}

template<class Data, int numLists>
void MultiLinkedList<Data, numLists>::RemoveAll()
{
    Element<Data, numLists>* pCurrent = m_Head;
    Element<Data, numLists>* pLast    = m_Head;

    while (NULL != pCurrent)
    {
        pLast = pCurrent;
        pCurrent = pCurrent->m_Next[m_ListIdx];
        pLast->m_Next[m_ListIdx] = NULL;
    }

    m_Head = NULL;
    m_Tail = NULL;
}

template<class Data, int numLists>
Data* MultiLinkedList<Data, numLists>::GetFirst()
{
    Data* pData = NULL;

    m_Iterator = m_Head;

    if (NULL != m_Iterator)
    {
        pData = &m_Iterator->m_Data;
    }
    return pData;
}

template<class Data, int numLists>
Data* MultiLinkedList<Data, numLists>::GetLast()
{
    Data* pData = NULL;
    m_Iterator = m_Tail;

    if (NULL != m_Iterator)
    {
        pData = &m_Iterator->m_Data;
    }
    return pData;
}

template<class Data, int numLists>
Data* MultiLinkedList<Data, numLists>::GetNext()
{
    Data* pData = NULL;

    if (m_Iterator != m_Tail)
    {
       m_Iterator = m_Iterator->m_Next[m_ListIdx];
    }
    else
    {
        m_Iterator = NULL;
    }

    if (NULL != m_Iterator)
    {
        pData = &m_Iterator->m_Data;
    }

    return pData;
}

template<class Data, int numLists>
Element<Data, numLists>* MultiLinkedList<Data, numLists>::GetFirstElement()
{
    m_Iterator = m_Head;

    return m_Iterator;
}

template<class Data, int numLists>
Element<Data, numLists>* MultiLinkedList<Data, numLists>::GetLastElement()
{
    m_Iterator = m_Tail;

    return m_Iterator;
}

template<class Data, int numLists>
Element<Data, numLists>* MultiLinkedList<Data, numLists>::GetNextElement()
{
    if ((m_Iterator != m_Tail) && (m_Iterator != NULL))
    {
       m_Iterator = m_Iterator->m_Next[m_ListIdx];
    }
    else
    {
        m_Iterator = NULL;
    }
    return m_Iterator;
}

template<class Data, int numLists>
bool MultiLinkedList<Data, numLists>::IsEmpty() const
{
   bool isEmpty = false;

   if (   (NULL == m_Head)
       && (NULL == m_Tail) )
   {
      isEmpty = true;
   }

   return isEmpty;
}

#endif
