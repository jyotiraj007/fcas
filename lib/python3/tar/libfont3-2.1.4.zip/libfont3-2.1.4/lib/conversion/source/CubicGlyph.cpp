// Copyright (C) 2015 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// CubicGlyph.cpp

#include "CubicGlyph.h"

CubicGlyph::CubicGlyph(int designUnits /* = DEFAULT_CUBIC_UNITS */)
: m_DesignUnits(designUnits)
{
}

void CubicGlyph::Clear()
{
    m_Contours.Clear();
}

void CubicGlyph::AddContour(CubicContour& contour)
{
    contour.SetDesignUnits(m_DesignUnits);
    m_Contours.Add(contour);
}

int CubicGlyph::NumContours()
{
    return m_Contours.NumElements();
}

CubicContour& CubicGlyph::GetContour(int index)
{
    return m_Contours[index];
}

bool CubicGlyph::Match(QuadGlyph& glyph, float tolerance)
{
    bool success = true;
    int numContours = m_Contours.NumElements();

    for (int i = 0; i < numContours; i++)
    {
        QuadContour quadContour(glyph.GetDesignUnits());
        success &= m_Contours[i].Match(quadContour, tolerance);
        glyph.AddContour(quadContour);
    }
    return success;
}

bool CubicGlyph::Match(CubicGlyph& glyph, float tolerance, bool preserveExtrema /* = false */)
{
    bool success = true;
    int numContours = m_Contours.NumElements();

    for (int i = 0; i < numContours; i++)
    {
        CubicContour cubicContour(glyph.GetDesignUnits());
        success &= m_Contours[i].Match(cubicContour, tolerance, preserveExtrema);
        glyph.AddContour(cubicContour);
    }
    return success;
}


int CubicGlyph::GetDesignUnits()
{
    return m_DesignUnits;
}

bool CubicGlyph::DuplicatePoints()
{
    bool duplicatePoints = false;
    int numContours = m_Contours.NumElements();

    for (int i = 0; i < numContours; i++)
    {
        duplicatePoints |= m_Contours[i].DuplicatePoints();
    }

    return duplicatePoints;
}

bool CubicGlyph::InvalidPoints()
{
    bool invalidPoints = false;
    int numContours = m_Contours.NumElements();

    for (int i = 0; i < numContours; i++)
    {
        invalidPoints |= m_Contours[i].InvalidPoints();
    }

    return invalidPoints;
}

bool CubicGlyph::NonIntegerPoints()
{
    bool nonIntegerPoints = false;
    int numContours = m_Contours.NumElements();

    for (int i = 0; i < numContours; i++)
    {
        nonIntegerPoints |= m_Contours[i].OffIntegerPoints();
    }

    return nonIntegerPoints;
}

void CubicGlyph::PrintToFile(FILE* pFile)
{
    int numContours = m_Contours.NumElements();

    for (int i = 0; i < numContours; i++)
    {
        fprintf(pFile, "Contour %d: \n", i);
        m_Contours[i].PrintToFile(pFile);
    }
}