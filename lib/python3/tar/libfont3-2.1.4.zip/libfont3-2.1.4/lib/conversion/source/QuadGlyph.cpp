// Copyright (C) 2015 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// QuadGlyph.cpp

#include "QuadGlyph.h"
#include "CubicContour.h"
#include "CubicGlyph.h"
#include <stdio.h>

QuadGlyph::QuadGlyph(int designUnits /* = DEFAULT_QUAD_UNITS */)
: m_DesignUnits(designUnits)
{
}

void QuadGlyph::Clear()
{
    m_Contours.Clear();
}

void QuadGlyph::AddContour(QuadContour& contour)
{
    contour.SetDesignUnits(m_DesignUnits);
    m_Contours.Add(contour);
}

int QuadGlyph::NumContours()
{
    return m_Contours.NumElements();
}

QuadContour& QuadGlyph::GetContour(int index)
{
    return m_Contours[index];
}

int QuadGlyph::GetDesignUnits()
{
    return m_DesignUnits;
}

bool QuadGlyph::Match(CubicGlyph& cubicGlyph, float tolerance)
{
    bool success = true;

    int numContours = m_Contours.NumElements();

    for (int i = 0; i < numContours; i++)
    {
        CubicContour cubicContour(cubicGlyph.GetDesignUnits());
        success &= m_Contours[i].Match(cubicContour, tolerance);
        cubicGlyph.AddContour(cubicContour);
    }

    return success;
}

bool QuadGlyph::Match(QuadGlyph& quadGlyph, float tolerance)
{
    bool success = true;

    int numContours = m_Contours.NumElements();

    for (int i = 0; i < numContours; i++)
    {
        QuadContour quadContour(quadGlyph.GetDesignUnits());
        success &= m_Contours[i].Match(quadContour, tolerance);
        quadGlyph.AddContour(quadContour);
    }

    return success;
}

bool QuadGlyph::DuplicatePoints()
{
    bool duplicatePoints = false;
    int numContours = m_Contours.NumElements();

    for (int i = 0; i < numContours; i++)
    {
        duplicatePoints |= m_Contours[i].DuplicatePoints();
    }

    return duplicatePoints;
}

bool QuadGlyph::InvalidPoints()
{
    bool invalidPoints = false;
    int numContours = m_Contours.NumElements();

    for (int i = 0; i < numContours; i++)
    {
        invalidPoints |= m_Contours[i].InvalidPoints();
    }

    return invalidPoints;
}

bool QuadGlyph::NonIntegerPoints()
{
    bool nonIntegerPoints = false;
    int numContours = m_Contours.NumElements();

    for (int i = 0; i < numContours; i++)
    {
        nonIntegerPoints |= m_Contours[i].OffIntegerPoints();
    }

    return nonIntegerPoints;
}

void QuadGlyph::PrintToFile(FILE* pFile)
{
    int numContours = m_Contours.NumElements();

    for (int i = 0; i < numContours; i++)
    {
        fprintf(pFile, "Contour %d: \n", i);
        m_Contours[i].PrintToFile(pFile);
    }
}