// Copyright (C) 2014 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
/// \file Vector2.h

#ifndef VECTOR2_H
#define VECTOR2_H


class Vector2f;

//! Provides 2D vector operations
/*!
    Defines vector addition, subtraction, and comparison. Permits indexed access to vector components. 
    See also Vector2f.
*/
class Vector2
{
   public:
        /* Ctor */      Vector2     ();
        /* Ctor */      Vector2     (double x, double y);
        /* Ctor */      Vector2     (const Vector2& other);
        /* Ctor */      Vector2     (const Vector2f& other);

        const double&   operator[] (int i) const;
        double&         operator[] (int i);

        double          X          () const;
        double          Y          () const;
        void            Set        (double x, double y);
        Vector2         operator-  (const Vector2& other) const;
        Vector2         operator+  (const Vector2& other) const;
        Vector2         operator-= (const Vector2& other);
        Vector2         operator+= (const Vector2& other);
        double          Length     () const;
        double          LengthSquared() const;
        void            Normalize  ();
        bool            operator== (const Vector2& other) const;
        bool            operator!= (const Vector2& other) const;

        friend 
        Vector2         operator*  (double scale, const Vector2& vector);

        friend
        double          DotProduct (const Vector2& one, const Vector2& two);

        friend
        double          AngleBetween(const Vector2& one, const Vector2& two);

        friend
        double          Tau        (const Vector2& one, const Vector2& two);

        bool            IsValid    () const;

    protected:

        double            m_Vector[2];
};

inline double Vector2::X() const
{
    return m_Vector[0];
}

inline double Vector2::Y() const
{
    return m_Vector[1];
}

/**
    Access to coordinates.
    @param[in] i Coordinate index
    @return Coordinate value.
*/
inline const double& Vector2::operator[](int i) const
{
    return m_Vector[i];
}

/**
    Access to coordinates.
    @param[in] i Coordinate index
    @return Coordinate value.
*/
inline double& Vector2::operator[](int i)
{
    return m_Vector[i]; //lint !e1536
}

#endif
