// Copyright (C) 2015 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
/// \file QuadGlyph.h

#ifndef QUAD_GLYPH_H
#define QUAD_GLYPH_H

#include "QuadContour.h"
#include <stdio.h>

class CubicGlyph;


class QuadGlyph
{
    public:

        /* CTOR */      QuadGlyph    (int designUnits = DEFAULT_QUAD_UNITS);

        void            Clear        ();
        void            AddContour   (QuadContour& contour);

        int             NumContours  ();
        QuadContour&    GetContour   (int index);
        bool            Match        (CubicGlyph& cubicGlyph, float tolerance);
        bool            Match        (QuadGlyph&  quadGlyph, float tolerance);

        bool            DuplicatePoints ();
        bool            InvalidPoints   ();
        bool            NonIntegerPoints();
        int             GetDesignUnits  ();

        void            PrintToFile     (FILE* pFile);

    protected:

        ArrayList<QuadContour>  m_Contours;
        int                     m_DesignUnits;
};

#endif
