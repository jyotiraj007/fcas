// Copyright (C) 2014, 2015 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// decode_api.h


// The point of this header is to disambiguate the Brotli decode.h which is
// included below from other headers named decode.h

#include "decode.h"
