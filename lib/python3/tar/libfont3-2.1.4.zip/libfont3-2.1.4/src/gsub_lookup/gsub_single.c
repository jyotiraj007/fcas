// Copyright (C) 2014 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// gsub_single.c

#include "gsub_lookup/gsub_single.h"
#include "common_table.h"
#include "utils.h"

// private functions for FORMAT 1
static LF_ERROR singleSubst_readFormat1(gsub_single_substitution* table, LF_STREAM* stream);
static ULONG    singleSubst_sizeFormat1(gsub_single_substitution* table);
//static void     singleSubst_buildFormat1(gsub_single_substitution* table, LF_STREAM* stream);
static LF_ERROR singleSubst_remapFormat1(gsub_single_substitution* ss, LF_MAP* remap);
static LF_ERROR singleSubst_keepGlyphsFormat1(gsub_single_substitution* ss, GlyphList* keepList);

// private functions for FORMAT 2
static LF_ERROR singleSubst_readFormat2(gsub_single_substitution* table, LF_STREAM* stream);
static LF_ERROR singleSubst_remapFormat2(gsub_single_substitution* ss, LF_MAP* remap);
static ULONG    singleSubst_sizeFormat2(gsub_single_substitution* table);
static void     singleSubst_buildFormat2(gsub_single_substitution* table, LF_STREAM* stream);
static LF_ERROR singleSubst_removeGlyphFormat2(gsub_single_substitution* ss, GlyphID glyphid);
static LF_ERROR singleSubst_keepGlyphsFormat2(gsub_single_substitution* ss, GlyphList* keepList);

static USHORT    singleSubst_calcFormat(gsub_single_substitution* ss, SHORT* deltaValue);

/* ============================================================================
    @brief
        create a new instance of a single substitution subtable and return
        it back to the caller.  the instance will use the stream to
        construct the instance.

    @param
        stream        = pointer to the stream

    @returns
        subtable    = the new instance of the subtable

============================================================================ */
TABLE_HANDLE GSUB_readSingleSubst(LF_STREAM* stream)
{
    LF_ERROR    error;
    size_t        curOffset, newOffset, baseOffset;

    gsub_single_substitution* ss = (gsub_single_substitution*)calloc(1, sizeof(gsub_single_substitution));
    if (ss == NULL)
    {
        DEBUG_LOG_ERROR("failed to allocate memory for single substitution");
        return NULL;
    }

    baseOffset = STREAM_streamPos(stream);

    ss->SubstFormat = STREAM_readUShort(stream);             // get the substitution format

    newOffset = STREAM_readUShort(stream) + baseOffset;      // get the coverage offset
    curOffset = STREAM_streamPos(stream);                    // save the current offset

    STREAM_streamSeek(stream, newOffset);                    // seek to the coverage table
    error = Coverage_readTable(&ss->Coverage, stream);       // read in the coverage table
    if (error != LF_ERROR_OK)                                // valid coverage table?
    {
        if (error != LF_EMPTY_TABLE)
        {
             DEBUG_LOG_STATUS("failed to read single substitution coverage", error);
              goto Fail;
        }
    }

    STREAM_streamSeek(stream, curOffset);                    // return to substitute table

    switch (ss->SubstFormat)
    {
    case 1:        error = singleSubst_readFormat1(ss, stream);        break;
    case 2:        error = singleSubst_readFormat2(ss, stream);        break;
    default:       error = LF_BAD_FORMAT;                              break;
    }

    if (error == LF_ERROR_OK)
        return (TABLE_HANDLE)ss;

    DEBUG_LOG_STATUS("failed to read single substitution format", error);

Fail:
    GSUB_freeSingleSubst(ss);
    return NULL;
}


/* ----------------------------------------------------------------------------
    @summary
        Format 1 calculates the indices of the output glyphs, which are not 
        explicitly defined in the subtable. To calculate an output glyph index, 
        Format 1 adds a constant delta value to the input glyph index. For 
        the substitutions to occur properly, the glyph indices in the input 
        and output ranges must be in the same order. This format does not use 
        the Coverage Index that is returned from the Coverage table.

        The SingleSubstFormat1 subtable begins with a format identifier 
        (SubstFormat) of 1. An offset references a Coverage table that 
        specifies the indices of the input glyphs. DeltaGlyphID is the 
        constant value added to each input glyph index to calculate the 
        index of the corresponding output glyph.

        The coverage table has already been read in from the stream
        before this function is called.

    @param
        ss            :    pointer to the single substitution structure, which
                           will become populated from the stream

        stream        :    pointer to the stream

    @return
        LF_ERROR_OK   :    success reading the single substitution

    @notes
        Format 1 is converted over to format 2 because it is a simpler
        format to operate and manipulate because it deals with absolute
        values, rather than calculated deltas.

        the build() process needs to determine if format 1 can be
        written out.

---------------------------------------------------------------------------- */
static LF_ERROR    singleSubst_readFormat1(gsub_single_substitution* ss, LF_STREAM* stream)
{
    USHORT  glyph;
    USHORT  coverageGlyph;
    USHORT  n, count;
    SHORT   delta;

    count = (USHORT)Coverage_getCoverageCount(&ss->Coverage);            // how many in the coverage table
    delta = STREAM_readShort(stream);                                    // get the delta value to apply to coverage

    vector_init(&ss->format.f2.Substitute, count, sizeof(ULONG));

    // loop through the coverage
    for (n = 0; n < count; n++)
    {
        Coverage_getCoverageAt(&ss->Coverage, n, &coverageGlyph);        // get the glyph offset from coverage table

        // conversion to format 2
        glyph = coverageGlyph + delta;                                   // apply the delta to the glyph

        vector_push_back(&ss->format.f2.Substitute, (void*)(intptr_t)glyph);
    }

    // we are going to force format 2 on everyone.
    ss->SubstFormat = 2;

    return LF_ERROR_OK;
}


/* ----------------------------------------------------------------------------
    @summary
        Format 2 is more flexible than Format 1, but requires more space. It
        provides an array of output glyph indices (Substitute) explicitly
        matched to the input glyph indices specified in the Coverage table.

        The SingleSubstFormat2 subtable specifies a format identifier
        (SubstFormat), an offset to a Coverage table that defines the input
        glyph indices, a count of output glyph indices in the Substitute
        array (GlyphCount), and a list of the output glyph indices in the
        Substitute array (Substitute).

        The Substitute array must contain the same number of glyph indices
        as the Coverage table. To locate the corresponding output glyph
        index in the Substitute array, this format uses the Coverage Index
        returned from the Coverage table.

    @param
        ss      :       pointer to the single substitution structure, which
                        will become populated from the stream

        stream  :       pointer to the stream

    @return
        LF_ERROR_OK :   success reading the single substitution

---------------------------------------------------------------------------- */
static LF_ERROR    singleSubst_readFormat2(gsub_single_substitution* ss, LF_STREAM* stream)
{
    USHORT      count, n;
    LF_ERROR    error;

    gsub_single_substitution_2* ssf2 = &ss->format.f2;

    count = STREAM_readUShort(stream);
    error = vector_init(&ssf2->Substitute, count, sizeof(ULONG));

    if (error != LF_ERROR_OK)
    {
        return error;
    }

    for ( n = 0; n < count; n++ )
    {
        GlyphID glyphid = STREAM_readUShort(stream);

        vector_push_back(&ssf2->Substitute, (void*)(intptr_t)glyphid);
    }

    return LF_ERROR_OK;
}



/* ============================================================================
    @brief
        free the resources that were allocated by the single substitution
        table.  This will free up the coverage table associated with this
        subtable.

    @param
        ss        = pointer to the glyph single substitution structure

============================================================================ */
void GSUB_freeSingleSubst(gsub_single_substitution* ss)
{
    if (ss)
    {
        switch ( ss->SubstFormat)
        {
        case 1:                                                break;
        case 2:    vector_delete(&ss->format.f2.Substitute);   break;
        default:                                               break;
        }

        Coverage_deleteTable(&ss->Coverage);
    }
    FREE(ss);
}


/* ----------------------------------------------------------------------------
    @summary
        calculates the single substitution format 1 and returns the value.

    @param
        table    :    pointer to the single substitution table

    @return
        size of format 1 structure.

---------------------------------------------------------------------------- */
static ULONG singleSubst_sizeFormat1(gsub_single_substitution* table)
{
    return sizeof(table->format.f1.DeltaGlyphID);
}


/* ----------------------------------------------------------------------------
    @brief
        calculate the size of the single substitution table and return
        it.

        format 2 is a dynamic array using the glyph count as the array
        size of glyph IDs.  all of the elements are uint16 in size.

    @param
        table    = pointer to the single substitution table

    @return
        ULONG size of single substitution format=2 chunk in bytes
---------------------------------------------------------------------------- */
static ULONG singleSubst_sizeFormat2(gsub_single_substitution* table)
{
    USHORT    count = UTILS_getCount(&table->format.f2.Substitute);        // how many glyphs in substitution
    ULONG    table_size = sizeof(USHORT) + sizeof(GlyphID) * count;        // calculate the size of the structure

    return    table_size;
}


/* ============================================================================
    @brief
        return the size in bytes of the substitution subtable.

    @param
        table    = pointer to the substitution table

    @return
        size in bytes of the substitution table
============================================================================ */
size_t GSUB_getSingleSubstitutionSize(gsub_single_substitution* table)
{
    size_t tableSize = 0;
    USHORT format;
    SHORT  delta;

    Coverage_getTableSize(&table->Coverage, &tableSize);    // get the coverage table size

    format = singleSubst_calcFormat(table, &delta);


    tableSize += sizeof(OFFSET);                            // CoverageTable OFFSET
    tableSize += sizeof(table->SubstFormat);                // Format size

    switch (format)
    {
    case 1:        tableSize += singleSubst_sizeFormat1(table);        break;
    case 2:        tableSize += singleSubst_sizeFormat2(table);        break;
    default:                                                           break;
    }

    return tableSize;
}


/* ----------------------------------------------------------------------------
    @brief
        streams out format 2 of the single substitution subtable

    @param
        table   = pointer to the substitution table
        stream  = pointer to the stream that is used
---------------------------------------------------------------------------- */
static void singleSubst_buildFormat2(gsub_single_substitution* table, LF_STREAM* stream)
{
    USHORT n, count;

    count = UTILS_getCount(&table->format.f2.Substitute);

    STREAM_writeUShort(stream, (USHORT)count);

    for (n = 0; n < count; n++)
    {
        USHORT glyphid = (USHORT)(intptr_t)vector_at(&table->format.f2.Substitute, n);
        STREAM_writeUShort(stream, glyphid);
    }
}


/* ============================================================================
    @brief
        build a single substitution table and store it in the stream.

        this function parses the single substitution structure, table and
        converts it to the open type format and saves it to the stream.

    @param
        table    = pointer to the single substitution structure
        stream   = pointer to the stream.

    @returns
        ULONG    = the position in the stream

============================================================================ */
size_t GSUB_buildSingleSubstitution(gsub_single_substitution* table, LF_STREAM* stream)
{
    size_t    tableStart = STREAM_streamPos(stream);
    size_t    coverageOffset;
    SHORT    delta;
    USHORT    format;

    format = singleSubst_calcFormat(table, &delta);

    //    if (format == 1)
    //        table->format.f1.DeltaGlyphID = delta;

    STREAM_writeUShort(stream, format);        // save the single format

    coverageOffset = STREAM_streamPos(stream);            // get the coverage offset
    STREAM_writeUShort(stream, 0);                        // coverage offset placeholder

    switch (format)
    {
    case 1:
        STREAM_writeShort(stream, delta);
        break;

    case 2:
        singleSubst_buildFormat2(table, stream);
        break;

    default:
        break;
    }

    Coverage_buildCoverage(&table->Coverage, stream, (ULONG)coverageOffset, (ULONG)tableStart);

    return STREAM_streamPos(stream);
}


/* ============================================================================
    @summary
        remove the glyphID from the substitution and coverage.  if the
        glyph id exists within the coverage table, we will remove it
        from the system

    @param
        ss                :    pointer to the single substitution structure
        glyphid           :    the glyphid to remove

    @output
        LF_ERROR_OK       :    removed the glyph
        LF_BAD_FORMAT     :    unrecognized format for single substitution
        LF_EMPTY_TABLE    :    rule is empty.

============================================================================ */
LF_ERROR GSUB_removeGlyphIndex(gsub_single_substitution* ss, GlyphID glyphid)
{
    LF_ERROR    error;
    ULONG        index = 0;

    switch (ss->SubstFormat)
    {
    case 1:        error = Coverage_removeGlyphIndex(&ss->Coverage, glyphid, &index);        break;
    case 2:        error = singleSubst_removeGlyphFormat2(ss, glyphid);                      break;
    default:       error = LF_BAD_FORMAT;                                                    break;
    }

    return error;
}


/* ----------------------------------------------------------------------------
    @summary
        remove a glyph from format 2 Substitution array.  The Substitute
        array must contain the same number of glyph indices as the
        Coverage table.  To locate the corresponding output glyph index in
        the substitute array, this format uses the Coverage Index returned
        from the Coverage Table.

    @param
        ss        :    pointer to the single substitution structure
        glyphid   :    the glyphid to remove

    @output
        LF_ERROR_OK       :    removed the glyph
        LF_NOT_COVERED    :    glyphid not covered in the rule.
        LF_EMPTY_TABLE    :    coverage / substitution is empty

---------------------------------------------------------------------------- */
static LF_ERROR singleSubst_removeGlyphFormat2(gsub_single_substitution* ss, GlyphID glyphid)
{
    LF_ERROR    error;
    ULONG        index;

    // find/remove the glyphid in the coverage table...
    error = Coverage_removeGlyphIndex(&ss->Coverage, glyphid, &index);

    if ( error == LF_ERROR_OK)
    {
        // remove the glyph from the substitution using the same coverage index,
        // which will keep the 2 files in sync
        error = vector_erase(&ss->format.f2.Substitute, index);
        if (ss->format.f2.Substitute.count == 0)
        {
            error = LF_EMPTY_TABLE;
        }
    }

    return error;
}

#ifdef LF_OT_DUMP

static void singleSubst_dumpFormat1(gsub_single_substitution* ss)
{
    Coverage_dumpTable(&ss->Coverage);
    XML_DATA_NODE("DeltaGlyph", ss->format.f1.DeltaGlyphID);
}


static void singleSubst_dumpFormat2(gsub_single_substitution* ss)
{
    ULONG i;

    Coverage_dumpTable(&ss->Coverage);

    for (i = 0; i < ss->format.f2.Substitute.count; i++)
    {
        GlyphID glyphid = (GlyphID)(long)vector_at(&ss->format.f2.Substitute, i);
        XML_DATA_NODE("gid", glyphid);
    }
}


/* ============================================================================
    @desc:
        dump the single substitution structure to the log stream.

    @param:
        ss = pointer to the single substitution stream.

============================================================================ */
void GSUB_dumpSingleSubst(gsub_single_substitution* ss)
{
    XML_START("GSUBSingle");

    if (Coverage_getCoverageCount(&ss->Coverage) == 0)
    {
        XML_COMMENT("Coverage table is empty ", 0);
    }
    else
    {
        switch(ss->SubstFormat)
        {
        case 1:        singleSubst_dumpFormat1(ss);            break;
        case 2:        singleSubst_dumpFormat2(ss);            break;
        default:    break;
        }
    }
    XML_END("GSUBSingle")
}
#endif


/* ----------------------------------------------------------------------------
    @summary
        remap the single substitution format 1.

    @param:
        ss      :    pointer to the single substitution structure
        remap   :    pointer to the map collection that holds the
                     glyph ids and their remapping.

    @return
        LF_ERROR_OK :    substitution completed successfully.

---------------------------------------------------------------------------- */
static LF_ERROR singleSubst_remapFormat1(gsub_single_substitution* ss, LF_MAP* remap)
{
    gsub_single_substitution_1* f1 = &ss->format.f1;
    GlyphID    coverageID;
    GlyphID    substID;
    GlyphID    single;
    SHORT     delta;

    Coverage_getCoverageAt(&ss->Coverage, 0, &coverageID);        // get old coverage id
    substID = coverageID + f1->DeltaGlyphID;                      // get delta glyph applied to coverage

    Coverage_remapAll(&ss->Coverage, remap);
    single = (GlyphID)(intptr_t)map_at(remap, (void*)(intptr_t)substID);
    Coverage_getCoverageAt(&ss->Coverage, 0, &coverageID);        // new coverage id

    delta = coverageID - single;
    f1->DeltaGlyphID = delta;

    return LF_ERROR_OK;
}


/* ----------------------------------------------------------------------------
    @summary
        remap the single substitution format 2.

    @param:
        ss       :    pointer to the single substitution structure
        remap    :    pointer to the map collection that holds the
                      glyph ids and their remapping.

    @return
        LF_ERROR_OK        :    substitution completed successfully.

---------------------------------------------------------------------------- */
static LF_ERROR singleSubst_remapFormat2(gsub_single_substitution* ss, LF_MAP* remap)
{
    gsub_single_substitution_2* f2 = &ss->format.f2;
    ULONG n;

    Coverage_remapAll(&ss->Coverage, remap);

    for (n = 0; n < f2->Substitute.count; n++)
    {

        GlyphID id = (GlyphID)(intptr_t)vector_at(&f2->Substitute, n);
        GlyphID newGlyph;
        LF_ERROR error = Common_remapGlyph(remap, id, &newGlyph);
        vector_set_data(&f2->Substitute, n, (void*)(intptr_t)newGlyph);

        if (error != LF_ERROR_OK)
        {
            DEBUG_LOG_VALUE("failed remapping occurred", id);
        }
    }

    return LF_ERROR_OK;
}


/* ============================================================================
    @summary
        remap the single glyphs using the remap table.

    @param:
        ss       :    pointer to the single substitution structure
        remap    :    pointer to the map collection that holds the
                      glyph ids and their remapping.

    @return
        LF_ERROR_OK        :    substitution completed successfully.

============================================================================ */
LF_ERROR GSUB_remapSingleSubstGlyphs(gsub_single_substitution* ss, LF_MAP* remap)
{
    LF_ERROR error = LF_ERROR_OK;

    switch (ss->SubstFormat)
    {
    case 1:        error = singleSubst_remapFormat1(ss, remap);        break;
    case 2:        error = singleSubst_remapFormat2(ss, remap);        break;
    default:       error = LF_BAD_FORMAT;                              break;
    }
    return error;
}


/* ============================================================================
    @summary
        go through the rules and generate the keep list using the
        pass single substitution rule.

    @param
        ss              :    pointer to single substitution
        keepList        :    pointer to the keep list

    @return
        LF_ERROR_OK       :    nothing was done to the keep list
        LF_ADDED_GLYPH    :    rule added some glyphs to the keep list

============================================================================ */
LF_ERROR GSUB_keepSingleSubstGlyphs(gsub_single_substitution* ss, GlyphList* keepList)
{
    LF_ERROR error;

    switch (ss->SubstFormat)
    {
    case 1:        error = singleSubst_keepGlyphsFormat1(ss, keepList);            break;
    case 2:        error = singleSubst_keepGlyphsFormat2(ss, keepList);            break;
    default:       error = LF_BAD_FORMAT;                                          break;
    }

    return error;
}


/* ----------------------------------------------------------------------------
    @summary
        process single substitution format 1 and add glyphs to the keep
        list.

    @param
        ss              :    pointer to single substitution table
        keepList        :    pointer to the keep list

    @return
        LF_ERROR_OK       :    nothing was done to the keep list
        LF_ADDED_GLYPH    :    rule added some glyphs to the keep list

---------------------------------------------------------------------------- */
static LF_ERROR singleSubst_keepGlyphsFormat1(gsub_single_substitution* ss, GlyphList* keepList)
{
    USHORT   count, i;
    LF_ERROR status, error;
    SHORT    delta;
    USHORT   added = 0;
    status = LF_ERROR_OK;

    count = (USHORT)Coverage_getCoverageCount(&ss->Coverage);
    delta = ss->format.f1.DeltaGlyphID;

    for ( i = 0; i < count; i++ )
    {
        GlyphID coverageID;

        error = Coverage_getCoverageAt(&ss->Coverage, i, &coverageID);

        if (error == LF_ERROR_OK)
        {
            if (Keep_coverageExists(keepList, coverageID) == LF_ERROR_OK)
            {
                error = Keep_addGlyph(keepList, (coverageID + delta));
                if (error == LF_ADDED_GLYPH)
                {
                    status = error;
                    added++;
                }
            }
        }
    }
    if (added)
    {
        status = LF_ADDED_GLYPH;
#if _DEBUG
        DEBUG_LOG_VALUE("Added keepGlyphs ", added);
#endif
    }
    return status;
}


/* ----------------------------------------------------------------------------
    @summary
        process single substitution format 2 and add glyphs to the keep
        list.

    @param
        ss              :    pointer to single substitution table
        keepList        :    pointer to the keep list

    @return
        LF_ERROR_OK     :    nothing was done to the keep list
        LF_ADDED_GLYPH  :    rule added some glyphs to the keep list

---------------------------------------------------------------------------- */
static LF_ERROR singleSubst_keepGlyphsFormat2(gsub_single_substitution* ss, GlyphList* keepList)
{
    USHORT        count, i;
    LF_ERROR    status, error;
    USHORT        added = 0;

    status = LF_ERROR_OK;

    count = (USHORT)Coverage_getCoverageCount(&ss->Coverage);

    for ( i = 0; i < count; i++ )
    {
        GlyphID coverageID;

        error = Coverage_getCoverageAt(&ss->Coverage, i, &coverageID);

        if (error == LF_ERROR_OK)
        {
            if (Keep_coverageExists(keepList, coverageID) == LF_ERROR_OK)
            {
                GlyphID glyph = (GlyphID)(intptr_t)vector_at(&ss->format.f2.Substitute, i);
                error = Keep_addGlyph(keepList, glyph);
                if (error == LF_ADDED_GLYPH)
                {
                    status = error;
                    added++;
                }
            }
        }
    }

    if (added)
    {
        status = LF_ADDED_GLYPH;
#if _DEBUG
        DEBUG_LOG_VALUE("Added keepGlyphs ", added);
#endif
    }
    return status;
}




/* ----------------------------------------------------------------------------
    @summary
        calculate the best GSUB single substitution format.  the table is
        read in and converted to a format 2 (easier to work with) and this
        function will examine the table and determine the best way to
        build the format.  it will choose format 1 if a delta conversion is
        possible, otherwise format 2 is used.

    @param
        ss            :    pointer to the single substitution table
        deltaValue    :    pointer to the calculated deltaValue.  this will
                           be undefined if format 2 is chosen.

    @return
        the format that was chosen, being either 1, or 2.

---------------------------------------------------------------------------- */
static USHORT singleSubst_calcFormat(gsub_single_substitution* ss, SHORT* deltaValue)
{
    size_t  coverageCount, n;
    SHORT   delta  = 0;
    USHORT  format = 1;                // assume we will change to format 1
    GlyphID coverageGlyph;
    GlyphID substGlyph;

    // Format 1 is always produced in the case the original table had a problem
    if (ss->Coverage.isAscending == FALSE)
    {
        size_t ignore;
        Coverage_getTableSize(&ss->Coverage, &ignore);
        *deltaValue = ss->Coverage.build_1.GlyphCount;
        return 1;
    }

    // we know we read in as a format 2, so we can make some
    // good assumptions and parse the table and determine if
    // it can use format 1.
    coverageCount = Coverage_getCoverageCount(&ss->Coverage);

    if (coverageCount > 1)
    {
        Coverage_getCoverageAt(&ss->Coverage, 0, &coverageGlyph);
        substGlyph = (GlyphID)(intptr_t)vector_at(&ss->format.f2.Substitute, 0);
        delta = substGlyph - coverageGlyph;

        for (n = 1; n < coverageCount; n++)
        {
            SHORT temp;
            Coverage_getCoverageAt(&ss->Coverage, (USHORT)n, &coverageGlyph);
            substGlyph = (GlyphID)(intptr_t)vector_at(&ss->format.f2.Substitute, n);

            temp = substGlyph - coverageGlyph;
            if (temp != delta)
            {
                return 2;            // must be format 2
            }
        }

        if (format == 1)
        {
            *deltaValue = delta;
            return 1;                // format 1
        }
    }
    else
    {
        // Coverage count is only one glyph, so use format 1
        Coverage_getCoverageAt(&ss->Coverage, 0, &coverageGlyph);
        substGlyph = (GlyphID)(intptr_t)vector_at(&ss->format.f2.Substitute, 0);
        delta = substGlyph - coverageGlyph;
        *deltaValue = delta;
        return 1;
    }

    return 2;                        // format 2
}
