// Copyright (C) 2014 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// gsub_chaining_context.c

#include <memory.h>
#include "utils.h"
#include "coverage_table.h"
#include "gsub_lookup/gsub_chaining_context.h"
#include "chain_set.h"
#include "chain_class_set.h"

static LF_ERROR chainContextSubst_readFormat1(gsub_chain_context_format1* ccf1, LF_STREAM* stream);
static size_t   chainContextSubst_buildFormat1(gsub_chain_context_format1* ccf1, LF_STREAM* stream);
static size_t   chainContextSubst_sizeFormat1(gsub_chain_context_format1* ccf1);
static void     chainContextSubst_freeFormat1(gsub_chain_context_format1* ccf1);
static LF_ERROR chainContextSubst_removeFormat1(gsub_chain_context_format1* ccf1, GlyphID glyphid);
static LF_ERROR chainContextSubst_removeLookupIndexFormat1(gsub_chain_context_format1* ccf1, USHORT lookupIndex, SHORT deltaIndex);
static LF_ERROR chainContextSubst_pruneLookupRecordsFormat1(gsub_chain_context_format1* csf1);
static LF_ERROR chainContextSubst_cleanupLookupsFormat1(gsub_chain_context_format1* ccf1, TABLE_HANDLE hLookup);
static LF_ERROR chainContextSubst_collectGlyphsFormat1(GlyphList* keepList, TABLE_HANDLE hTable, gsub_chain_context_format1* ccf1);

static LF_ERROR chainContextSubst_readFormat2(gsub_chain_context_format2* ccf2, LF_STREAM* stream);
static size_t   chainContextSubst_buildFormat2(gsub_chain_context_format2* ccf2, LF_STREAM* stream);
static size_t   chainContextSubst_sizeFormat2(gsub_chain_context_format2* ccf2);
static void     chainContextSubst_freeFormat2(gsub_chain_context_format2* ccf2);
static LF_ERROR chainContextSubst_removeFormat2(gsub_chain_context_format2* ccf2, GlyphID glyphid);
static LF_ERROR chainContextSubst_removeLookupIndexFormat2(gsub_chain_context_format2* ccf2, USHORT lookupIndex, SHORT deltaIndex);
static LF_ERROR chainContextSubst_pruneLookupRecordsFormat2(gsub_chain_context_format2* csf2);
static LF_ERROR chainContextSubst_cleanupLookupsFormat2(gsub_chain_context_format2* ccf2, TABLE_HANDLE hLookup);
static LF_ERROR chainContextSubst_collectGlyphsFormat2(GlyphList* keepList, TABLE_HANDLE hTable, gsub_chain_context_format2* ccf2);

static LF_ERROR chainContextSubst_readFormat3(gsub_chain_context_format3* ccf3, LF_STREAM* stream);
static size_t   chainContextSubst_buildFormat3(gsub_chain_context_format3* ccf3, LF_STREAM* stream);
static size_t   chainContextSubst_sizeFormat3(gsub_chain_context_format3* ccf3);
static void     chainContextSubst_freeFormat3(gsub_chain_context_format3* ccf3);
static LF_ERROR chainContextSubst_removeFormat3(gsub_chain_context_format3* ccf3, GlyphID glyphid);
static LF_ERROR chainContextSubst_removeLookupIndexFormat3(gsub_chain_context_format3* f3, USHORT lookupIndex, SHORT deltaIndex);
static LF_ERROR chainContextSubst_pruneLookupRecordsFormat3(gsub_chain_context_format3* csf3);
static LF_ERROR chainContextSubst_cleanupLookupsFormat3(gsub_chain_context_format3* ccf3, TABLE_HANDLE hLookup);
static LF_ERROR chainContextSubst_collectGlyphsFormat3(GlyphList* keepList, TABLE_HANDLE hTable, gsub_chain_context_format3* ccf3);

#ifdef LF_OT_DUMP
static void     chainContextSubst_dumpFormat1(gsub_chain_context_format1* ccsf1);
static void     chainContextSubst_dumpFormat2(gsub_chain_context_format2* csf2);
static void     chainContextSubst_dumpFormat3(gsub_chain_context_format3* ccsf3);
#endif


TABLE_HANDLE GSUB_readChainContextSubst(LF_STREAM* stream)
{
    LF_ERROR error = LF_EMPTY_TABLE;
    gsub_chain_context_substitution* ccs = (gsub_chain_context_substitution*)malloc(sizeof(gsub_chain_context_substitution));

    if (!ccs)
        goto readContextFailure;

    memset(ccs, 0, sizeof(gsub_chain_context_substitution));
//    GSUB_initBase(lfFont, (TABLE_HANDLE)ccs);

    ccs->SubstFormat = STREAM_readUShort(stream);
    switch (ccs->SubstFormat)
    {
    case 1:        error = chainContextSubst_readFormat1(&ccs->ccs.ccf1, stream);        break;
    case 2:        error = chainContextSubst_readFormat2(&ccs->ccs.ccf2, stream);        break;
    case 3:        error = chainContextSubst_readFormat3(&ccs->ccs.ccf3, stream);        break;
    default:    break;
    }

    if (error != LF_ERROR_OK)
        goto Fail1;

    return (TABLE_HANDLE)ccs;

Fail1:
    DEBUG_LOG_ERROR("Problem reading Chained Context Substitution");
    FREE(ccs);

readContextFailure:
    return NULL;
}


size_t GSUB_buildChainContextSubst(gsub_chain_context_substitution* ccs, LF_STREAM* stream)
{
    size_t ret = 0;

    ASSERT(ccs);
    ASSERT(stream);

    STREAM_writeUShort(stream, ccs->SubstFormat);

    switch (ccs->SubstFormat)
    {
    case 1:        ret = chainContextSubst_buildFormat1(&ccs->ccs.ccf1, stream);    break;
    case 2:        ret = chainContextSubst_buildFormat2(&ccs->ccs.ccf2, stream);    break;
    case 3:        ret = chainContextSubst_buildFormat3(&ccs->ccs.ccf3, stream);    break;
    default:    break;
    }
    return ret;
}



size_t GSUB_sizeChainContextSubst(gsub_chain_context_substitution* ccs)
{
    size_t size = 0;

    ASSERT(ccs);

    size = sizeof(ccs->SubstFormat);

    switch (ccs->SubstFormat)
    {
    case 1:        size += chainContextSubst_sizeFormat1(&ccs->ccs.ccf1);    break;
    case 2:        size += chainContextSubst_sizeFormat2(&ccs->ccs.ccf2);    break;
    case 3:        size += chainContextSubst_sizeFormat3(&ccs->ccs.ccf3);    break;
    default:    break;
    }

    return size;
}



void GSUB_freeChainContextSubst(gsub_chain_context_substitution* ccs)
{
    ASSERT(ccs);

    switch (ccs->SubstFormat)
    {
    case 1:        chainContextSubst_freeFormat1(&ccs->ccs.ccf1);    break;
    case 2:        chainContextSubst_freeFormat2(&ccs->ccs.ccf2);    break;
    case 3:        chainContextSubst_freeFormat3(&ccs->ccs.ccf3);    break;
    default:    break;
    }

    FREE(ccs);
}



LF_ERROR GSUB_removeChainContextSubst(gsub_chain_context_substitution* ccs, GlyphID glyphid)
{
    LF_ERROR error = LF_ERROR_OK;

    ASSERT(ccs);

    switch (ccs->SubstFormat)
    {
    case 1:        error = chainContextSubst_removeFormat1(&ccs->ccs.ccf1, glyphid);    break;
    case 2:        error = chainContextSubst_removeFormat2(&ccs->ccs.ccf2, glyphid);    break;
    case 3:        error = chainContextSubst_removeFormat3(&ccs->ccs.ccf3, glyphid);    break;
    default:    break;
    }

#if _DEBUG
    if (error == LF_EMPTY_TABLE)
    {
        DEBUG_LOG_VALUE("Empty Lookup table: ", ccs->Base.prevLookupIndex);
    }

#endif

    return error;
}



/* ****************************************************************************

    FORMAT 1

**************************************************************************** */
static LF_ERROR    chainContextSubst_readFormat1(gsub_chain_context_format1* ccf1, LF_STREAM* stream)
{
    LF_ERROR  error;
    USHORT    count;
    size_t     curOffset, newOffset, baseOffset;

    // read Coverage
    baseOffset = STREAM_streamPos(stream) - sizeof(USHORT);            // base offset - SubstFormat
    newOffset = STREAM_readOffset(stream) + baseOffset;                // Coverage OFFSET
    curOffset = STREAM_streamPos(stream);
    STREAM_streamSeek(stream, newOffset);

    error = Coverage_readTable(&ccf1->Coverage, stream);
    if (error != LF_ERROR_OK)
    {
        if  (error != LF_EMPTY_TABLE)
        {
            DEBUG_LOG_ERROR("Problem reading coverage table");
            return error;
        }
    }

    STREAM_streamSeek(stream, curOffset);

    count = ccf1->ChainSubRuleSetCount = STREAM_readUShort(stream);
    error = vector_init(&ccf1->ChainSubRuleSet, count, sizeof(ULONG));
    if (error != LF_ERROR_OK)
    {
        DEBUG_LOG_ERROR("failed to create SubRuleSet");
        goto Fail1;
    }


    error = ChainSets_readRuleSets(&ccf1->ChainSubRuleSet, count, stream, (ULONG)baseOffset);
    if (error != LF_ERROR_OK)
    {
        DEBUG_LOG_ERROR("failed to read ChainSubRuleSet");
        goto Fail1;
    }

    return error;

Fail1:
    chainContextSubst_freeFormat1(ccf1);
    return error;
}








/*
    @summary
        read ChainContextSubstFormat1

*/

static size_t chainContextSubst_buildFormat1(gsub_chain_context_format1* ccf1, LF_STREAM* stream)
{
    size_t        baseOffset, curOffset;
    size_t        coverageOffset, arrayOffset, offset;
    USHORT       n, count;



    baseOffset = STREAM_streamPos(stream) - sizeof(USHORT);           // start if table minus the SubstFormat
    coverageOffset = STREAM_streamPos(stream);                        // store off the Coverage OFFSET.
    STREAM_writeOffset(stream, 0);                                    // placeholder value for coverage offset

    count = UTILS_getCount(&ccf1->ChainSubRuleSet);
    STREAM_writeUShort(stream, count);                                // ChainSubRuleSetCount

    arrayOffset = Common_buildEmptyArray(stream, count);              // placeholder array

    Coverage_buildCoverage(&ccf1->Coverage, stream, (ULONG)coverageOffset, (ULONG)baseOffset);


    for (n = 0; n < count; n++)
    {
        chain_set* cs = (chain_set*)vector_at(&ccf1->ChainSubRuleSet, n);

        // update offset array
        curOffset = STREAM_streamPos(stream);
        offset = curOffset - baseOffset;
        STREAM_streamSeek(stream, arrayOffset);
        STREAM_writeOffset(stream, (OFFSET)offset);
        arrayOffset += sizeof(OFFSET);

        STREAM_streamSeek(stream, curOffset);

        ChainSet_buildRuleSet(cs, stream);
    }

    return STREAM_streamPos(stream);
}



static size_t chainContextSubst_sizeFormat1(gsub_chain_context_format1* ccf1)
{
    size_t size = 0;
    size_t coverageSize;

    //LF_ERROR error;

    /*error = */Coverage_getTableSize(&ccf1->Coverage, &coverageSize);  // always returns ok
    size += coverageSize;
    size += sizeof(OFFSET);                                    // sizeof Coverage Offset
    size += sizeof(USHORT);                                    // ChainSubRuleSetCount
    size += sizeof(OFFSET) * ccf1->ChainSubRuleSet.count;      // ChainSubRuleSet[ChainSubRuleSetCount]

    size += ChainSets_sizeRuleSets(&ccf1->ChainSubRuleSet);

    return size;
}



static void    chainContextSubst_freeFormat1(gsub_chain_context_format1* ccf1)
{
    Coverage_deleteTable(&ccf1->Coverage);
    ChainSets_freeRuleSets(&ccf1->ChainSubRuleSet);
}




/* ----------------------------------------------------------------------------
    @description
        remove a glyph from format 1.  remove the glyph from coverage
        and if it is found, we can remove the associated set.  The number
        of ChainSets match the coverage index.  So if there is a coverage
        glyph at index 2, we must remove ChainSubRuleSet[2] as well.

        other cleanup would be in the Lookahead, and Backtrack sequences
        as well.

---------------------------------------------------------------------------- */
static LF_ERROR    chainContextSubst_removeFormat1(gsub_chain_context_format1* ccf1, GlyphID glyphid)
{
    LF_ERROR    error;
    ULONG        coverageIndex;

    // 1rst step, remove coverage match ups with the Sub-rule sets ...
    error = Coverage_removeGlyphIndex(&ccf1->Coverage, glyphid, &coverageIndex);
    if (error == LF_EMPTY_TABLE)
    {
        return error;
    }

    // According to the rules, The number of SubRuleSet tables-must be equal to GlyphCount
    // in the Coverage Table.
    if ( error == LF_ERROR_OK)
    {
        // Top level pruning of the rules - match Coverage index to SubRuleSets index.
        // find the SubRuleSet that matches coverage index
        chain_set* cs = (chain_set*)vector_at(&ccf1->ChainSubRuleSet, coverageIndex);

        ChainSet_freeRuleSet(cs);
        FREE(cs);
        vector_erase(&ccf1->ChainSubRuleSet, coverageIndex);

        ccf1->ChainSubRuleSetCount = UTILS_getCount(&ccf1->ChainSubRuleSet);
    }

    // 2nd Stage, now search all SubRuleSets and remove any SubRules
    // that contain the glyph as they are no longer relevant if one
    // of the sequences has been removed.
    error = ChainSets_pruneRuleSets(&ccf1->ChainSubRuleSet, &ccf1->Coverage, glyphid);

    return error;
}











/* ****************************************************************************

    FORMAT 2


**************************************************************************** */




/* ----------------------------------------------------------------------------
    @summary
        This format describes a class-based chaining context substitution

    @description
        A specific integer, called a class value, must be assigned to each
        glyph component in all context glyph sequences.  Contexts are then 
        defined as sequences of glyph class values.  More than one context 
        may be defined at a time.

        To chain contexts, three classes are used in the glyph ClassDef table:
            Backtrack ClassDef
            Input ClassDef
            Lookahead ClassDef

        The coverage table lists indices for the complete set of unique glyphs
        (not glyph classes) that may appear as the first glyph of any class-
        based context.  In other words, the Coverage table contains the list
        of glyph indices for all the glyphs in all classes that may be first
        in any of the context class sequences.  For example, if the contexts 
        begin with Class 1 or Class 2 glyph, then the Coverage table will list
        the indices of all Class 1 and Class 2 glyphs.



        The ChainSubClassSet
---------------------------------------------------------------------------- */
static LF_ERROR    chainContextSubst_readFormat2(gsub_chain_context_format2* ccf2, LF_STREAM* stream)
{
    LF_ERROR            error;
    USHORT              count;
    size_t               curOffset, newOffset, baseOffset;
    ULONG               backtrackOffset, inputOffset, lookaheadOffset;

    baseOffset = STREAM_streamPos(stream) - sizeof(USHORT);
    
    // Coverage
    newOffset = STREAM_readUShort(stream) + baseOffset;
    curOffset = STREAM_streamPos(stream);
    STREAM_streamSeek(stream, newOffset);
    error = Coverage_readTable(&ccf2->Coverage, stream);
    STREAM_streamSeek(stream, curOffset);

    // Offsets
    backtrackOffset        = STREAM_readOffset(stream);
    inputOffset            = STREAM_readOffset(stream);
    lookaheadOffset        = STREAM_readOffset(stream);


      /* `ChainSubClassSetCount' is the upper limit for input class values,
     thus we read it now to make an additional safety check. No limit
     is known or needed for the other two class definitions          */
    count = ccf2->ChainSubClassSetCnt = STREAM_readUShort(stream);

    error = ClassDef_readEmptyOrClassDefinition(&ccf2->BacktrackClassDef, MAX_CLASSDEF, backtrackOffset, (ULONG)baseOffset, stream);
    if (error != LF_ERROR_OK)
    {
        DEBUG_LOG_ERROR("problem reading Backtrack ClassDef");
        goto Fail1;
    }

    error = ClassDef_readEmptyOrClassDefinition(&ccf2->InputClassDef, count, inputOffset, (ULONG)baseOffset, stream);
    if (error != LF_ERROR_OK)
    {
        DEBUG_LOG_ERROR("problem reading Input ClassDef");
        goto Fail1;
    }

    error = ClassDef_readEmptyOrClassDefinition(&ccf2->LookaheadClassDef, MAX_CLASSDEF, lookaheadOffset, (ULONG)baseOffset, stream);
    if (error != LF_ERROR_OK)
    {
        DEBUG_LOG_ERROR("problem reading Lookahead ClassDef");
        goto Fail1;
    }

    error = ChainClassSets_readSets(&ccf2->InputClassDef, 
                                    &ccf2->BacktrackClassDef, 
                                    &ccf2->LookaheadClassDef, 
                                    &ccf2->ChainSubClassSet, count, stream, (ULONG)baseOffset);

    if (error != LF_ERROR_OK)
        goto Fail1;

    return LF_ERROR_OK;

Fail1:
    chainContextSubst_freeFormat2(ccf2);
    return error;
}



static size_t    chainContextSubst_buildFormat2(gsub_chain_context_format2* ccf2, LF_STREAM* stream)
{
    size_t    baseOffset, coverageOffset, arrayOffset;
    size_t    BacktrackOffset, InputClassOffset, LookaheadOffset;
    USHORT   count;


    baseOffset = STREAM_streamPos(stream) - sizeof(USHORT);           // start of Substitution table

    coverageOffset = STREAM_streamPos(stream);
    STREAM_writeOffset(stream, 0);                                    // placeholder value for coverage offset

    BacktrackOffset = STREAM_streamPos(stream);                       // BacktrackOffset Offset position
    STREAM_writeOffset(stream, 0);                                    // placeholder value for BacktrackOffset offset

    InputClassOffset = STREAM_streamPos(stream);                      // InputClassOffset Offset position
    STREAM_writeOffset(stream, 0);                                    // placeholder value for InputClassOffset offset

    LookaheadOffset = STREAM_streamPos(stream);                       // LookaheadOffset Offset position
    STREAM_writeOffset(stream, 0);                                    // placeholder value for LookaheadOffset offset

    count = UTILS_getCount(&ccf2->ChainSubClassSet);
    STREAM_writeUShort(stream, count);                                // ChainSubClassSetCnt
    arrayOffset = Common_buildEmptyArray(stream, count);

    Coverage_buildCoverage(&ccf2->Coverage, stream, (ULONG)coverageOffset, (ULONG)baseOffset);
    Common_buildClassDef(&ccf2->BacktrackClassDef, stream, (ULONG)BacktrackOffset, (ULONG)baseOffset);
    Common_buildClassDef(&ccf2->InputClassDef, stream, (ULONG)InputClassOffset, (ULONG)baseOffset);
    Common_buildClassDef(&ccf2->LookaheadClassDef, stream, (ULONG)LookaheadOffset, (ULONG)baseOffset);

    // build the chain class sets, and offset array to each table ...
    ChainClassSets_buildSets(&ccf2->ChainSubClassSet, stream, (ULONG)arrayOffset, (ULONG)baseOffset);

    return STREAM_streamPos(stream);
}



static size_t chainContextSubst_sizeFormat2(gsub_chain_context_format2* ccf2)
{
    size_t size = 0, coverageSize, classSize;

    size += sizeof(OFFSET);                // Coverage OFFSET
    size += sizeof(OFFSET);                // BacktrackClassDef OFFSET
    size += sizeof(OFFSET);                // InputClassDef OFFSET
    size += sizeof(OFFSET);                // LookaheadClassDef OFFSET

    size += sizeof(USHORT);                // ChainSubClassSetCnt

    size += sizeof(OFFSET) * ccf2->ChainSubClassSet.count;        // Offset array for ChainSubClassSetCnt]
    size += ChainClassSets_sizeSets(&ccf2->ChainSubClassSet);     // ChainSubClassSet[ChainSubClassSetCnt]

    Coverage_getTableSize(&ccf2->Coverage, &coverageSize);
    size += coverageSize;

    ClassDef_getTableSize(&ccf2->BacktrackClassDef, &classSize);
    size += classSize;

    ClassDef_getTableSize(&ccf2->InputClassDef, &classSize);
    size += classSize;

    ClassDef_getTableSize(&ccf2->LookaheadClassDef, &classSize);
    size += classSize;

    return size;
}



static void    chainContextSubst_freeFormat2(gsub_chain_context_format2* ccf2)
{
    Coverage_deleteTable(&ccf2->Coverage);

    ClassDef_freeTable(&ccf2->BacktrackClassDef);
    ClassDef_freeTable(&ccf2->InputClassDef);
    ClassDef_freeTable(&ccf2->LookaheadClassDef);

    ChainClassSets_freeSets(&ccf2->ChainSubClassSet);
}




/*
    @description
        This first will attempt to remove from the coverage table.  if the coverage
        table removes a glyph and it is not empty we can conclude that the context
        sequence is no longer possible and we can delete this gsubtable rule.

        if the coverage index still has a sequence, we need to clean up the classes
        and remove any classes that may have gone missing.  According to the rules
        of this format, the ChainSubClassRule tables are in order of 

*/
static LF_ERROR    chainContextSubst_removeFormat2(gsub_chain_context_format2* ccf2, GlyphID glyphid)
{
    LF_ERROR    error;
    ULONG        coverageIndex;
    USHORT        removeSet;

    // 1rst stage, remove coverage match ups with the subrule sets.
    error = Coverage_removeGlyphIndex(&ccf2->Coverage, glyphid, &coverageIndex);

    if (error == LF_EMPTY_TABLE)
    {
        // no coverage, this subrule can be removed
        return error;
    }

    error = ClassDef_removeGlyph(&ccf2->BacktrackClassDef, glyphid, &removeSet);
    if (error == LF_EMPTY_TABLE)
    {
//        DEBUG_LOG("BacktrackClassDef is empty");
    }

    error = ClassDef_removeGlyph(&ccf2->LookaheadClassDef, glyphid, &removeSet);
    if (error == LF_EMPTY_TABLE)
    {
//        DEBUG_LOG("LookaheadClassDef is empty");
    }

    error = ClassDef_removeGlyph(&ccf2->InputClassDef, glyphid, &removeSet);
    if (error == LF_EMPTY_TABLE)
    {
        DEBUG_LOG("InputClassDef is empty, eliminating the subtable");
        return error;
    }

    return error;
}




/* ****************************************************************************

    FORMAT 3

**************************************************************************** */
static LF_ERROR    chainContextSubst_readFormat3(gsub_chain_context_format3* ccf3, LF_STREAM* stream)
{
    LF_ERROR    error;
    size_t        baseOffset;
    USHORT        count;


    ASSERT(ccf3);
    ASSERT(stream);

    baseOffset = STREAM_streamPos(stream) - sizeof(USHORT);            // account for the format identifier
    
    count = ccf3->BacktrackGlyphCount = STREAM_readUShort(stream);
    error = Coverage_readArray(&ccf3->BacktrackGlyphCoverage, count, stream, (ULONG)baseOffset);
    if (error != LF_ERROR_OK)
        goto Fail1;


    count = ccf3->InputGlyphCount = STREAM_readUShort(stream);
    error = Coverage_readArray(&ccf3->InputGlyphCoverage, count, stream, (ULONG)baseOffset);
    if (error != LF_ERROR_OK)
        goto Fail1;

    count = ccf3->LookaheadGlyphCount = STREAM_readUShort(stream);
    error = Coverage_readArray(&ccf3->LookaheadGlyphCoverage, count, stream, (ULONG)baseOffset);
    if (error != LF_ERROR_OK)
        goto Fail1;


    count = ccf3->SubstCount = STREAM_readUShort(stream);
    error = Common_readSubstLookupRecords(&ccf3->SubstLookupRecord, count, stream);
    if (error != LF_ERROR_OK)
        goto Fail1;

    return error;

Fail1:
    DEBUG_LOG_ERROR("Problem occurred reading in Chained Context Format 3");
    chainContextSubst_freeFormat3(ccf3);
    return error;
}



static size_t    chainContextSubst_buildFormat3(gsub_chain_context_format3* ccf3, LF_STREAM* stream)
{
    USHORT   count;
    size_t    baseOffset;
    size_t    BacktrackOffset, InputClassOffset, LookaheadOffset;

    baseOffset = STREAM_streamPos(stream) - sizeof(USHORT);       // start of Substitution table

    count = UTILS_getCount(&ccf3->BacktrackGlyphCoverage);
    STREAM_writeUShort(stream, count);                            // BacktrackGlyphCount
    BacktrackOffset = Common_buildEmptyArray(stream, count);      // Coverage[BacktrackGlyphCount] Array of Offsets

    count = UTILS_getCount(&ccf3->InputGlyphCoverage);
    STREAM_writeUShort(stream, count);                            // InputGlyphCount
    InputClassOffset = Common_buildEmptyArray(stream, count);     // Coverage[InputGlyphCount] Array of Offsets

    count = UTILS_getCount(&ccf3->LookaheadGlyphCoverage);
    STREAM_writeUShort(stream, count);                            // LookaheadGlyphCount
    LookaheadOffset = Common_buildEmptyArray(stream, count);      // Coverage[LookaheadGlyphCount] Array of Offsets

    count = UTILS_getCount(&ccf3->SubstLookupRecord);
    STREAM_writeUShort(stream, count);
    Common_buildSubstLookupRecords(&ccf3->SubstLookupRecord, stream);

    Coverage_buildTables(&ccf3->BacktrackGlyphCoverage, stream, (ULONG)baseOffset, (ULONG)BacktrackOffset);
    Coverage_buildTables(&ccf3->InputGlyphCoverage, stream, (ULONG)baseOffset, (ULONG)InputClassOffset);
    Coverage_buildTables(&ccf3->LookaheadGlyphCoverage, stream, (ULONG)baseOffset, (ULONG)LookaheadOffset);

    return STREAM_streamPos(stream);
}



static size_t chainContextSubst_sizeFormat3(gsub_chain_context_format3* ccf3)
{
    size_t size = 0;
                                                                    
    size += sizeof(USHORT);                                         // BacktrackGlyphCount
    size += sizeof(OFFSET) * ccf3->BacktrackGlyphCoverage.count;    // Coverage[BacktrackGlyphCount]

    size += sizeof(USHORT);                                         // InputGlyphCount
    size += sizeof(OFFSET) * ccf3->InputGlyphCoverage.count;        // Coverage[InputGlyphCount]

    size += sizeof(USHORT);                                         // LookaheadGlyphCount
    size += sizeof(OFFSET) * ccf3->LookaheadGlyphCoverage.count;    // Coverage[LookaheadGlyphCount]

    size += sizeof(USHORT);                                         // SubstCount
    size += Common_sizeSubstLookupRecords(&ccf3->SubstLookupRecord);

    size += Coverage_sizeCoverages(&ccf3->BacktrackGlyphCoverage);
    size += Coverage_sizeCoverages(&ccf3->InputGlyphCoverage);
    size += Coverage_sizeCoverages(&ccf3->LookaheadGlyphCoverage);

    return size;
}



static void    chainContextSubst_freeFormat3(gsub_chain_context_format3* ccf3)
{
    Coverage_deleteCoverageTables(&ccf3->BacktrackGlyphCoverage);
    Coverage_deleteCoverageTables(&ccf3->InputGlyphCoverage);
    Coverage_deleteCoverageTables(&ccf3->LookaheadGlyphCoverage);
    Common_freeSubstLookupRecords(&ccf3->SubstLookupRecord);
}



/* ----------------------------------------------------------------------------
    @description
        Checks if the coverage table for input is empty, and if it
        is, the entire subrule is eliminated.  

        it will also prune the backtrack and lookahead coverages as 
        well.

---------------------------------------------------------------------------- */
static LF_ERROR    chainContextSubst_removeFormat3(gsub_chain_context_format3* ccf3, GlyphID glyphid)
{
    LF_ERROR error;

    error = Coverage_removeCoveragesGlyphIndex(&ccf3->BacktrackGlyphCoverage, glyphid);
    if (error == LF_EMPTY_TABLE)
    {
        DEBUG_LOG("backtrack emptied, context not possible");
        return LF_EMPTY_TABLE;
    }

    error = Coverage_removeCoveragesGlyphIndex(&ccf3->LookaheadGlyphCoverage, glyphid);
    if (error == LF_EMPTY_TABLE)
    {
        DEBUG_LOG("lookahead emptied, context not possible");
        return LF_EMPTY_TABLE;
    }

    error = Coverage_removeCoveragesGlyphIndex(&ccf3->InputGlyphCoverage, glyphid);
    if (error == LF_EMPTY_TABLE)
    {
        // the input coverage is empty, so there
        DEBUG_LOG("input empty, context not possible");
        return LF_EMPTY_TABLE;
    }

    return LF_ERROR_OK;
}

static LF_ERROR chainContextSubst_removeLookupIndexFormat1(gsub_chain_context_format1* ccf1, USHORT lookupIndex, SHORT deltaIndex)
{
    ChainSets_removeLookupRecordIndex(&ccf1->ChainSubRuleSet, lookupIndex, deltaIndex);
    return LF_ERROR_OK;
}

static LF_ERROR chainContextSubst_removeLookupIndexFormat2(gsub_chain_context_format2* ccf2, USHORT lookupIndex, SHORT deltaIndex)
{
    return ChainClassSets_removeLookupRecordIndex(&ccf2->ChainSubClassSet, lookupIndex, deltaIndex);
}

static LF_ERROR chainContextSubst_removeLookupIndexFormat3(gsub_chain_context_format3* f3, USHORT lookupIndex, SHORT deltaIndex)
{
    LF_ERROR error = Common_removeLookupListIndex(&f3->SubstLookupRecord, lookupIndex, deltaIndex);
    return error;
}

LF_ERROR GSUB_removeChainContextSubstLookupIndex(gsub_chain_context_substitution* ccs, USHORT refIndex, SHORT deltaIndex)
{
    ASSERT(ccs);

    switch (ccs->SubstFormat)
    {
    case 1:        chainContextSubst_removeLookupIndexFormat1(&ccs->ccs.ccf1, refIndex, deltaIndex);    break;
    case 2:        chainContextSubst_removeLookupIndexFormat2(&ccs->ccs.ccf2, refIndex, deltaIndex);    break;
    case 3:        chainContextSubst_removeLookupIndexFormat3(&ccs->ccs.ccf3, refIndex, deltaIndex);    break;
    default:    break;
    }

    return LF_ERROR_OK;
}

/* ****************************************************************************


    PRUNE CHAIN CONTEXT RECORDS


**************************************************************************** */
static LF_ERROR chainContextSubst_pruneLookupRecordsFormat1(gsub_chain_context_format1* csf1)
{
    UNUSED(csf1)

    return LF_ERROR_OK;
}



static LF_ERROR chainContextSubst_pruneLookupRecordsFormat2(gsub_chain_context_format2* csf2)
{
    LF_ERROR        error = LF_ERROR_OK;


    error = ChainClassSets_validClassRules(&csf2->ChainSubClassSet);

    if (error != LF_EMPTY_TABLE)
    {
        context_classes    f2;

        memset(&f2, 0, sizeof(context_classes));
        f2.Backtrack    = &csf2->BacktrackClassDef;
        f2.Input        = &csf2->InputClassDef;
        f2.LookAhead    = &csf2->LookaheadClassDef;
        f2.Coverage     = &csf2->Coverage;


        error = ChainClassSets_pruneLookupRecords(&csf2->ChainSubClassSet, &f2);
        if (error == LF_EMPTY_TABLE)
            return LF_EMPTY_TABLE;

        // after pruning is complete, there may be some unused classes lying about,
        // so this method will remove them from the ClassDef structures if they
        // exist, or rather don't exist in the ClassRules.
        ChainClassSets_removeUnusedClasses(&csf2->ChainSubClassSet, &f2);


        // if there is nothing is the input class definition, then all of the
        // sequences have no possible context for matching.  Therefore we
        // can eliminate this rule.
        if(ClassDef_isTableEmpty(&csf2->InputClassDef))
            return LF_EMPTY_TABLE;


        // check if final cleanup cleared the coverage table?
        if (Coverage_getCoverageCount(&csf2->Coverage) == 0)
            return LF_EMPTY_TABLE;


    }
    return error;
}



static LF_ERROR chainContextSubst_pruneLookupRecordsFormat3(gsub_chain_context_format3* csf3)
{
    UNUSED(csf3);
    return LF_ERROR_OK;
}

LF_ERROR GSUB_pruneChainContextSubstLookupRecords(gsub_chain_context_substitution* ccs)
{
    LF_ERROR error = LF_ERROR_OK;

    switch(ccs->SubstFormat)
    {
    case 1:        error = chainContextSubst_pruneLookupRecordsFormat1(&ccs->ccs.ccf1);        break;
    case 2:        error = chainContextSubst_pruneLookupRecordsFormat2(&ccs->ccs.ccf2);        break;
    case 3:        error = chainContextSubst_pruneLookupRecordsFormat3(&ccs->ccs.ccf3);        break;
    default:       error = LF_BAD_FORMAT;                                                      break;
    }

    return error;
}

#ifdef LF_OT_DUMP
static void chainContextSubst_dumpFormat1(gsub_chain_context_format1* ccsf1)
{
    XML_START("ChainContextFormat1");
    XML_DATA_NODE("SubstFormat", 1);

    Coverage_dumpTable(&ccsf1->Coverage);

    ChainClassSets_dumpSets(&ccsf1->ChainSubRuleSet);

    XML_END("ChainContextFormat1");
}

static void chainContextSubst_dumpFormat2(gsub_chain_context_format2* ccsf2)
{
    XML_START("ChainContextFormat2");
    XML_DATA_NODE("SubstFormat", 2);

    Coverage_dumpTable(&ccsf2->Coverage);

    XML_START("BacktrackClassDef");
    ClassDef_dump(&ccsf2->BacktrackClassDef);
    XML_END("BacktrackClassDef");

    XML_START("InputClassDef");
    ClassDef_dump(&ccsf2->InputClassDef);
    XML_END("InputClassDef");

    XML_START("LookaheadClassDef");
    ClassDef_dump(&ccsf2->LookaheadClassDef);
    XML_END("LookaheadClassDef");

    XML_START("ChainSubClassSet");
    ChainClassSets_dumpSets(&ccsf2->ChainSubClassSet);
    XML_END("ChainSubClassSet");

    XML_END("ChainContextFormat2");
}

static void chainContextSubst_dumpFormat3(gsub_chain_context_format3* ccsf3)
{
    XML_START("ChainContextFormat1");

    XML_START("BacktrackCoverages");
    Coverage_dumpTables(&ccsf3->BacktrackGlyphCoverage);
    XML_END("BacktrackCoverages");

    XML_START("InputCoverages");
    Coverage_dumpTables(&ccsf3->InputGlyphCoverage);
    XML_END("InputCoverages");

    XML_START("LookaheadCoverages");
    Coverage_dumpTables(&ccsf3->LookaheadGlyphCoverage);
    XML_END("LookaheadCoverages");

    Common_dumpSubstLookupRecords(&ccsf3->SubstLookupRecord);

    XML_END("ChainContextFormat1");
}
#endif

static LF_ERROR chainContextSubst_remapGlyphsFormat1(gsub_chain_context_format1* csf1, LF_MAP* remap)
{
    LF_ERROR error = LF_ERROR_OK;
    
    error = Coverage_remapAll(&csf1->Coverage, remap);
    error = ChainSet_remapRulesSets(&csf1->ChainSubRuleSet, remap);

    return error;
}


static LF_ERROR chainContextSubst_remapGlyphsFormat2(gsub_chain_context_format2* csf2, LF_MAP* remap)
{
    LF_ERROR error = LF_ERROR_OK;

    error = Coverage_remapAll(&csf2->Coverage, remap);    

    ClassDef_remapGlyphs(&csf2->BacktrackClassDef, remap);
    ClassDef_remapGlyphs(&csf2->InputClassDef, remap);
    ClassDef_remapGlyphs(&csf2->LookaheadClassDef, remap);

    return error;
}



static LF_ERROR chainContextSubst_remapGlyphsFormat3(gsub_chain_context_format3* csf3, LF_MAP* remap)
{
    LF_ERROR error = LF_ERROR_OK;

    Coverage_remapTables(&csf3->BacktrackGlyphCoverage, remap);
    Coverage_remapTables(&csf3->InputGlyphCoverage, remap);
    Coverage_remapTables(&csf3->LookaheadGlyphCoverage, remap);

    return error;
}


LF_ERROR GSUB_remapChainContextGlyphs(gsub_chain_context_substitution* ccs, LF_MAP* remap)
{
    LF_ERROR error = LF_ERROR_OK;

    switch(ccs->SubstFormat)
    {
    case 1:        error = chainContextSubst_remapGlyphsFormat1(&ccs->ccs.ccf1, remap);        break;
    case 2:        error = chainContextSubst_remapGlyphsFormat2(&ccs->ccs.ccf2, remap);        break;
    case 3:        error = chainContextSubst_remapGlyphsFormat3(&ccs->ccs.ccf3, remap);        break;
    default:       error = LF_BAD_FORMAT;                                                      break;
    }

    return error;
}

#ifdef LF_OT_DUMP
void GSUB_dumpChainContext(gsub_chain_context_substitution* ccs)
{
    switch(ccs->SubstFormat)
    {
    case 1:        chainContextSubst_dumpFormat1(&ccs->ccs.ccf1);        break;
    case 2:        chainContextSubst_dumpFormat2(&ccs->ccs.ccf2);        break;
    case 3:        chainContextSubst_dumpFormat3(&ccs->ccs.ccf3);        break;
    default:                                                             break;
    }
}
#endif


LF_ERROR GSUB_cleanupChainContextLookups(gsub_chain_context_substitution* ccs, TABLE_HANDLE hLookup)
{
    LF_ERROR    error;

    switch(ccs->SubstFormat)
    {
    case 1:        error = chainContextSubst_cleanupLookupsFormat1(&ccs->ccs.ccf1, hLookup);        break;
    case 2:        error = chainContextSubst_cleanupLookupsFormat2(&ccs->ccs.ccf2, hLookup);        break;
    case 3:        error = chainContextSubst_cleanupLookupsFormat3(&ccs->ccs.ccf3, hLookup);        break;
    default:       error = LF_BAD_FORMAT;                                                           break;
    }

    return error;
}



static LF_ERROR chainContextSubst_cleanupLookupsFormat1(gsub_chain_context_format1* ccf1, TABLE_HANDLE hLookup)
{

    LF_ERROR    error = ChainSets_cleanupLookups(&ccf1->ChainSubRuleSet, hLookup);
    return error;
}

static LF_ERROR chainContextSubst_cleanupLookupsFormat2(gsub_chain_context_format2* ccf2, TABLE_HANDLE hLookup)
{
    LF_ERROR    error = LF_ERROR_OK;
    error = ChainClassSets_cleanupLookups(&ccf2->ChainSubClassSet, hLookup);
    return error;
}

static LF_ERROR chainContextSubst_cleanupLookupsFormat3(gsub_chain_context_format3* ccf3, TABLE_HANDLE hLookup)
{
    LF_ERROR    error = LF_ERROR_OK;

    Common_cleanupLookups(&ccf3->SubstLookupRecord, hLookup);    

    return error;
}





/* ============================================================================
    @summary
        collect all of the glyphs the chain context lookup records 
        would contain.


============================================================================ */
LF_ERROR GSUB_collectChainContextGlyphs(GlyphList* keepList, TABLE_HANDLE hTable, gsub_chain_context_substitution* ccs)
{
    LF_ERROR    error = LF_BAD_FORMAT;

    switch(ccs->SubstFormat)
    {
    case 1:        error = chainContextSubst_collectGlyphsFormat1(keepList, hTable, &ccs->ccs.ccf1);        break;
    case 2:        error = chainContextSubst_collectGlyphsFormat2(keepList, hTable, &ccs->ccs.ccf2);        break;
    case 3:        error = chainContextSubst_collectGlyphsFormat3(keepList, hTable, &ccs->ccs.ccf3);        break;
    default:       error = LF_BAD_FORMAT;                                                               break;
    }

    return error;
}



static LF_ERROR chainContextSubst_collectGlyphsFormat1(GlyphList* keepList, TABLE_HANDLE hTable, gsub_chain_context_format1* ccf1)
{
    LF_ERROR error = LF_ERROR_OK;

    error = ChainSets_collectGlyphs(&ccf1->ChainSubRuleSet, keepList, hTable);

    return error;
}


static LF_ERROR chainContextSubst_collectGlyphsFormat2(GlyphList* keepList, TABLE_HANDLE hTable, gsub_chain_context_format2* ccf2)
{
    LF_ERROR    error = LF_ERROR_OK;
    context_classes    classes;
    classes.Backtrack = &ccf2->BacktrackClassDef;
    classes.Input = &ccf2->InputClassDef;
    classes.LookAhead = &ccf2->LookaheadClassDef;
    classes.Coverage = &ccf2->Coverage;
    classes.validClasses = NULL;                        // not needed
    classes.totalClasses = 0;                           // not needed

    error = ChainClassSets_collectGlyphs(&ccf2->ChainSubClassSet, &classes, keepList, hTable);

    return error;
}


static LF_ERROR chainContextSubst_collectGlyphsFormat3(GlyphList* keepList, TABLE_HANDLE hTable, gsub_chain_context_format3* ccf3)
{
    LF_ERROR    error = LF_ERROR_OK;
    error = Coverages_existsInKeepList(&ccf3->BacktrackGlyphCoverage, keepList);
    if (error == LF_NOT_COVERED)
        return LF_ERROR_OK;

    error = Coverages_existsInKeepList(&ccf3->LookaheadGlyphCoverage, keepList);
    if (error == LF_NOT_COVERED)
        return LF_ERROR_OK;

    error = Coverages_existsInKeepList(&ccf3->InputGlyphCoverage, keepList);
    if (error != LF_ERROR_OK)
        return LF_ERROR_OK;

    error = Common_collectLookupRecordGlyphs(&ccf3->SubstLookupRecord, keepList, hTable);

    return error;
}


