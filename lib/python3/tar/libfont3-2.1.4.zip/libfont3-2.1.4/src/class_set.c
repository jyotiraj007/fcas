// Copyright (C) 2014 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// class_set.c

#include <stdlib.h>

#include "classdef.h"
#include "utils.h"
#include "stream.h"
#include "class_set.h"
#include "class_rule.h"

#include "coverage_table.h"

static class_set* classset_GetClassSet(LF_VECTOR* classsets, USHORT classvalue);

#ifdef LF_OT_DUMP
/* ==================================================================
    @summary
        dump the class sets to the xml stream.

    @param
        css        :    pointer to collection of class sets

================================================================== */
void ClassSets_dumpClassSets(LF_VECTOR* css)
{
    size_t i;
    XML_START("ClassSets");
    for (i = 0; i < css->count; i++)
    {
        //lint -size(a, 2049)
        char msg[2048];
        //lint -size(a, 0)
        class_set* crs = (class_set*)vector_at(css, i);

        sprintf(msg, "ClassSet %lu of %lu", (unsigned long)i, (unsigned long)css->count);
        XML_COMMENT_INDEX("ClassSet", (int)i, (int)(css->count -1));

        ClassSet_dumpClassSet(crs);
    }
    XML_END("ClassSets");
}
#endif


/* ==================================================================
    @summary
        validate the sub class sets and return whether they
        are valid or not.

    @param
        css        :    pointer to the class set structures.

    @return
        LF_EMPTY_TABLE     :    no class sets are valid or have class
                                rules associated
        LF_ERROR_OK        :    some class sets are valid

================================================================== */
LF_ERROR ClassSets_validClassRules(LF_VECTOR* css)
{
    USHORT      n, count;
    LF_ERROR    error;

    count = UTILS_getCount(css);

    for ( n = 0; n < count; n++ )
    {
        class_set* cs = (class_set*)vector_at(css, n);
        error = ClassSet_validClassRules(cs);

        if (error == LF_ERROR_OK)
            return error;
    }

    return LF_EMPTY_TABLE;
}

LF_ERROR ClassSets_readClassSets(LF_VECTOR* css, class_def* cd, USHORT count, LF_STREAM* stream, ULONG baseOffset)
{
    USHORT      n;
    size_t      newOffset, curOffset;
    LF_ERROR    error;
    ULONG       maxclassvalue = ClassDef_getMaxClass(cd);

    error = vector_init(css, maxclassvalue+1, sizeof(ULONG));
    if (error != LF_ERROR_OK)
        return error;

    // this will create a placeholder array for class sets based on the
    // number of classes defined in the class definition.
    for (n = 0; n <= maxclassvalue; n++)
        vector_push_back(css, NULL);

    for (n = 0; n < count; n++)
    {
        class_set* cs = (class_set*)calloc(1, sizeof(class_set));
        if (NULL == cs)
        {
            DEBUG_LOG_ERROR("failed to allocate ClassSet structure");
            error = LF_OUT_OF_MEMORY;
            goto Fail1;
        }

        newOffset = STREAM_readUShort(stream) + baseOffset;
        curOffset = STREAM_streamPos(stream);

        if ( newOffset != baseOffset)                            // not a NULL offset?
        {
            cs->InputClass = n;
            STREAM_streamSeek(stream, newOffset);

            error = ClassSet_readClassSet(cd, cs, stream);
            if (error != LF_ERROR_OK)
            {
                DEBUG_LOG_ERROR("failed to read in ClassSet");
                free(cs);
                goto Fail1;
            }
        }
        else
        {
            // push an Empty ClassSet onto the vector
            cs->InputClass = n;
            cs->ClassRuleCount = 0;
            cs->ClassRules = NULL;
        }

        vector_set_data(css, n, cs);
        STREAM_streamSeek(stream, curOffset);

    }
    return LF_ERROR_OK;

Fail1:
    return error;
}

void ClassSet_freeClassSet(class_set* scs)
{
    if (scs && scs->ClassRules)
    {
        size_t count = scs->ClassRules->count;
        ULONG n;

        for (n = 0; n < count; n++)
        {
            class_rule* scr = (class_rule*)vector_at(scs->ClassRules, n);
            ClassRule_freeRule(scr);
            FREE(scr);
        }

        vector_delete(scs->ClassRules);
        FREE(scs->ClassRules);
    }
}

/* ============================================================================
    @desc
        read in the class set from the stream

    @param
        cd          :           pointer to the class definition structure
        scs         :           pointer to the class set structure that
                                will be populated.
        stream      :           pointer to the stream.


    @notes
        A ContextSubstFormat2 subtable also defines an array of offsets to 
        the SubClassSet tables (SubClassSet) and a count of the SubClassSet 
        tables (SubClassSetCnt). The array contains one offset for each class 
        (including Class 0) in the ClassDef table. In the array, the class 
        value defines an offset's index position, and the SubClassSet offsets 
        are ordered by ascending class value (from 0 to SubClassSetCnt - 1).

        For example, the first SubClassSet listed in the array contains all 
        contexts beginning with Class 0 glyphs, the second SubClassSet contains 
        all contexts beginning with Class 1 glyphs, and so on. If no contexts 
        begin with a particular class (that is, if a SubClassSet contains no 
        SubClassRule tables), then the offset to that particular SubClassSet 
        in the SubClassSet array will be set to NULL.

    ============================================================================ */
LF_ERROR ClassSet_readClassSet(class_def* cd, class_set* scs, LF_STREAM* stream)
{
    LF_ERROR            error;
    USHORT              n, count;
    size_t              curOffset, newOffset, baseOffset;
    class_rule*         scr = NULL;

    ASSERT(scs);
    ASSERT(cd);
    ASSERT(stream);

    baseOffset = STREAM_streamPos(stream);
    count = scs->ClassRuleCount = STREAM_readUShort(stream);          // how many sub rules are in the set.
    scs->ClassRules = vector_create(count, sizeof(ULONG));            // create a vector array to hold SubClassRules

    // loop through the sub-rules in the set
    for ( n = 0; n < count; n++)
    {
        // read the offset in ...
        newOffset = STREAM_readUShort(stream);

        if (newOffset == 0)
        {
            // if the OFFSET is 0, then we have a empty class set with no rules.
            scr = NULL;
        }
        else
        {
            // create a structure to hold the sub-rule
            scr = (class_rule*)calloc(1, sizeof(class_rule));
            if (!scr)
            {
                DEBUG_LOG_ERROR("unable to allocate a class_rule structure");
                goto Fail1;
            }

            newOffset += baseOffset;
            curOffset = STREAM_streamPos(stream);
            STREAM_streamSeek(stream, newOffset);

            error = ClassRule_readRule(cd, scr, stream);                // read in subtable
            if (error != LF_ERROR_OK)
            {
                free(scr);
                DEBUG_LOG_ERROR("failed to read in class rule");
                goto Fail1;                                             // problem reading subtable, so bail
            }

            scr->InputClass = scs->InputClass;

            STREAM_streamSeek(stream, curOffset);
        }
        vector_push_back(scs->ClassRules, scr);
    }
    return LF_ERROR_OK;

Fail1:
    // failed allocate a class_rule
    ClassSet_freeClassSet(scs);
    return LF_OUT_OF_MEMORY;
}

size_t ClassSet_sizeClassSet(class_set* scs)
{
    size_t size = 0;
    USHORT n;

    // size  = sizeof(USHORT);                      // sizeof ClassRuleCount.
    if (!scs)
    {
        // size += sizeof(OFFSET);
        return size;                                // Don't add to size if no class rules exist
    }
    else if (scs->ClassRules == NULL)
    {
        // size += sizeof(OFFSET);
        return size;
    }
    else
    {
        size = sizeof(USHORT);                      // sizeof ClassRuleCount
        size += (sizeof(OFFSET) * scs->ClassRules->count);

        for (n = 0; n < scs->ClassRules->count; n++)
        {
            class_rule* cr = (class_rule*)vector_at(scs->ClassRules, n);
            if (cr)
                size += ClassRule_sizeRule(cr);
        }
    }
    return size;
}

/* ============================================================================

    @description
        remove a glyph from the class definition table.  given a class_def structure,
        go through the class structure and remove the passed glyph id.  if the 
        glyph exists, the removeSet variable will be defined and a status will 
        be returned.

        if the status returned is EMPTY_TABLE, then we can remove class set
        from the ClassSet collection.

        NOTE, this does NOT remove the reference to the ClassSet.  it simply
        frees the sets and it will not be NULL.  This is important as if class
        2 is freed in a collection that contains 5 class sets.  we want to 
        maintain the ordering, otherwise we need to remap all of the classes
        in this subtable.

    @param
        cd = pointer to the class definition that we want to remove.
        ClassSet = pointer to the collection of class_set structures.
        glyphid = id of the glyph we want to remove.


    @return
        LF_ERROR_OK = the glyph was removed, and the class association
                      is still defined in other glyphs.

        LF_NOT_COVERED = the glyph wasn't found in the class definition

        LF_EMPTY_TABLE = the glyph was removed and the class associated
            with the glyph is no longer defined.  the associated class
            that was removed has freed the class set in the ClassSet
            array.

============================================================================ */
LF_ERROR ClassSet_removeGlyphFromClass(class_def* cd, LF_VECTOR* ClassSet, GlyphID glyphid)
{
    USHORT removeSet = 0;
    LF_ERROR error = ClassDef_removeGlyph(cd, glyphid, &removeSet);

    if (error == LF_EMPTY_TABLE && removeSet != 0)
    {
        // we can remove a set from the system
        size_t count = ClassSet->count;

        if (removeSet < count)
        {
            class_set* scs = (class_set*)vector_at(ClassSet, removeSet);

            // get rid of the subclass rules
            ClassSet_freeClassSet(scs);
        }
    }
    return error;
}

/* ----------------------------------------------------------------------------
    @description
        find the maximum number of classes that are available.

        search all of the ClassDef classes and determine if they are empty
        or referenced in the class definition.  If they are found to 
        be NOT COVERED, we want to clean up the rules using the class 
        reference that is empty.

        search the subclass set, and search each of the rules for the 
        class reference that is empty.  if we find a rule, we can remove
        it from the collection.

---------------------------------------------------------------------------- */
LF_ERROR ClassSet_pruneEmptyClasses(class_def* classes, LF_VECTOR* classSets)
{
    ULONG j, maxClass;
    USHORT classref;

    // first part ... check for empty/undefined classes.  if you find some
    // then we prune out the lookup records.
    maxClass = ClassDef_getMaxClass(classes);
    for (classref = 1; classref <= maxClass; classref++)
    {
        // determine if the class is referenced in the class_def structure.
        LF_ERROR error = ClassDef_isClassFormatReferenced(classes, classref);
        if ( error == LF_NOT_COVERED)
        {
            // since the class is not referenced in the class_def, we can go through
            // and examine all of the ClassRules.  if the Class Rule contains an
            // unreferenced class id, we can remove that class rule from the class
            // set.
            ULONG classSetIndex = 0;

            while ( classSetIndex < classSets->count )
            {
                class_set* scs = (class_set*)vector_at(classSets, classSetIndex);
                if (scs && scs->ClassRules != NULL)
                {
                    j = 0;
                    while (j < scs->ClassRules->count)
                    {
                        class_rule* scr = (class_rule*)vector_at(scs->ClassRules, j);
                        if(scr)
                        {
                            LF_ERROR status = ClassRule_isClassReferenced(scr, classref, scr->InputClass);

                            if (status == LF_NOT_COVERED)
                            {
                                ClassRule_freeRule(scr);
                                vector_erase(scs->ClassRules, j);
                                free(scr);
                            }
                            else
                            {
                                j++;
                            }
                        }
                        else
                        {
                            // found a NULL rule, so remove it from the class set.
                            vector_erase(scs->ClassRules, j);
                        }
                    }
                }
                classSetIndex++;
            }

//            if (classSets->count == 0)
//            {
                // TODO: nothing relevant left
//                DEBUG_LOG("no sub class rules left");
//            }
        }
    }
    return LF_ERROR_OK;
}

/* ============================================================================
    @description
        Some of the classes are associated with coverage tables, so we need to
        do a cleanup here as well.  once all of the rules have been cleaned up
        and pruned, we can go in and look for any classes that are no longer
        referenced, but have left some coverage glyphs lying around.

    @param
        classes = pointer to the class definition.
        classSets = pointer to the class sets that hold all of the rules.
        coverage = pointer to the associated coverage table that is connected to
                   classes and rules.

    @return
        always returns OK.

============================================================================ */
LF_ERROR ClassSet_cleanupCoverageClasses(class_def* classes, LF_VECTOR* classSets, coverage_table* coverage)
{
    ULONG j, maxClass;
    USHORT classref;

    maxClass = ClassDef_getMaxClass(classes);

    for (classref = 1; classref <= maxClass; classref++)
    {
        LF_ERROR ref = ClassDef_isClassReferenced(classes, classref);
        if (ref == LF_ERROR_OK)
        {
            // this class is referenced and defined, so we need to check if any of 
            // the rules use it
            class_set* scs = classset_GetClassSet(classSets, classref);

            if (scs && scs->ClassRules && !scs->ClassRules->count)
            {
                // there are no rules for this class, so we can clean up the coverage
                LF_VECTOR* v = ClassDef_getGlyphsByClass(classes, classref);

                if (v)
                {
                    for (j = 0; j < v->count; j++)
                    {
                        USHORT glyph = (USHORT)(intptr_t)vector_at(v, j);
                        ULONG index = 0;
                        Coverage_removeGlyphIndex(coverage, glyph, &index);
                        ClassSet_removeGlyphFromClass(classes, classSets, glyph);
                    }

                    // cleanup
                    vector_delete(v);
                    FREE(v);
                }
            }
        }
    }
    return LF_ERROR_OK;
}

/* ============================================================================
    @description
        stream the class set and build the offset array that is
        associated with the class sets.

        The stream needs to be pointing to the start of where the
        class sets will be written too.

    @param
        sets = pointer to class sets stored in vector collection
        stream = pointer to the stream
        arrayStreamOffset = stream offset that holds the OFFSET array

============================================================================ */
LF_ERROR ClassSet_buildClassSets(LF_VECTOR* sets, LONG baseOffset, LONG classSetArrayOffset, LF_STREAM* stream)
{
    ULONG   n;
    size_t    curOffset = 0;
    size_t    offset = 0;
    LONG    offsetArray = classSetArrayOffset;

    for ( n = 0; n < sets->count; n++)
    {
        class_set* scs = (class_set*)vector_at(sets, n);

        curOffset = STREAM_streamPos(stream);               // get our current stream position
        offset = curOffset - baseOffset;                    // calculate the offset
        STREAM_streamSeek(stream, offsetArray);             // seek out the set offset table

        if (!scs)
        {
            STREAM_writeOffset(stream, 0);                  // write out a zero in the offset field if no rule
        }
        else if(scs->ClassRules)
        {
            STREAM_writeOffset(stream, (OFFSET)offset);     // write the offset into the set offset 
        }
        else
        {
            STREAM_writeOffset(stream, 0);                  // write out a zero in the offset field if no rule
        }

        offsetArray += sizeof(OFFSET);                      // increment to the next offset in the array.

        STREAM_streamSeek(stream, curOffset);               // go back to stream current position

        if (scs)
            ClassSet_buildClassSet(scs, stream);
    }

    return LF_ERROR_OK;
}

/* ============================================================================
    @description
        build up the class set into the stream.

        given a pointer to a class set structure, build it out to the
        stream and return status.

    @param
        scs = pointer to class set structure
        stream = pointer to the stream
============================================================================ */
LF_ERROR ClassSet_buildClassSet(class_set* scs, LF_STREAM* stream)
{
    size_t count, n;
    size_t baseOffset = STREAM_streamPos(stream);
    size_t curOffset = 0;
    size_t index;

    ASSERT(scs);
    ASSERT(stream);

    if (scs->ClassRules)
    {
        count = scs->ClassRules->count;

        // Build SubClassSet
        STREAM_writeUShort(stream, (USHORT)count);
        index = STREAM_streamPos(stream);

        for ( n = 0; n < count; n++)
        {
            STREAM_writeUShort(stream, 0);
        }

        for ( n = 0; n < count; n++)
        {
            class_rule* scr = (class_rule*)vector_at(scs->ClassRules, n);

            if (scr)
            {
                OFFSET offset;

                // Update the SubRuleSet OFFSET Array
                offset = (USHORT)(STREAM_streamPos(stream) - baseOffset);            // calculate the OFFSET from the start of SubClassSet
                curOffset = STREAM_streamPos(stream);
                STREAM_streamSeek(stream, index);
                STREAM_writeOffset(stream, offset);
                index += sizeof(OFFSET);
                STREAM_streamSeek(stream, curOffset);
                ClassRule_buildRule(scr, stream);
            }
        }
    }
    else
    {
//        In this case a 0 is written out in the offset table, but nothing needs to be written out in the subclass set
//        STREAM_writeUShort(stream, 0);
//        STREAM_writeOffset(stream, (USHORT)(STREAM_streamPos(stream) - baseOffset));
    }
    return LF_ERROR_OK;
}

#ifdef LF_OT_DUMP
void ClassSet_dumpClassSet(class_set* cs)
{
    size_t i, count;

    XML_START("ClassSet");
    if (cs && cs->ClassRules)
    {
        count = cs->ClassRules->count;

        XML_START("ClassRules");
        for (i = 0; i < count; i++)
        {
            class_rule* cr = (class_rule*)vector_at(cs->ClassRules, i);
            XML_START_COMMENT("ClassRule", (int)i, (int)count - 1);
            ClassRule_dumpRule(cr);
            XML_END("ClassRule");
        }
        XML_END("ClassRules");
    }
    else
    {
        XML_COMMENT("ClassRules not found (empty)", 0);
    }
    XML_END("ClassSet");
}
#endif

/* ============================================================================
    @desc
        validate the class rule set and return if there are any
        class rules, or if the table is empty.

    @param
        cs      :   pointer to the class set

    @return
        LF_ERROR_OK     :   the class set contains valid class rules
        LF_EMPTY_TABLE  :   the class set is empty.
============================================================================ */
LF_ERROR ClassSet_validClassRules(class_set* cs)
{
    USHORT n;

    if (cs && cs->ClassRules)
    {
        for (n = 0; n < cs->ClassRules->count; n++)
        {
            void* cr = vector_at(cs->ClassRules, n);
            if (cr)
                return LF_ERROR_OK;
        }
    }

    return LF_EMPTY_TABLE;
}

LF_ERROR ClassSet_cleanupLookups(class_set* cs, TABLE_HANDLE hLookup)
{
    LF_ERROR error = LF_ERROR_OK;

    if (cs->ClassRules)
    {
        ULONG i;
        size_t count = cs->ClassRules->count;

        for (i = 0; i < count; i++)
        {
            class_rule* cr = (class_rule*)vector_at(cs->ClassRules, i);
            if (cr != NULL)
            {
                ClassRule_cleanupLookups(cr, hLookup);
            }
        }
    }
    return error;
}

LF_ERROR ClassSet_collectGlyphs(class_set* cs, GlyphList* keepList, TABLE_HANDLE hTable, class_def* classdef)
{
    LF_ERROR error = LF_ERROR_OK;

    if (cs && cs->ClassRules)
    {
        ULONG i;

        for (i = 0; i < cs->ClassRules->count; i++)
        {
            class_rule* cr = (class_rule*)vector_at(cs->ClassRules, i);
            if (cr != NULL)
            {
                LF_ERROR status = ClassRule_collectGlyphs(cr, keepList, hTable, classdef);
                if (status == LF_ADDED_GLYPH)
                {
                    error = status;
                }
            }
        }
    }
    return error;
}

static class_set* classset_GetClassSet(LF_VECTOR* classsets, USHORT classvalue)
{
    class_set* scs = NULL;

    if (classvalue < classsets->count)
    {
        scs = (class_set*)vector_at(classsets, classvalue);
    }
#if _DEBUG
    else
    {
        DEBUG_LOG_ERROR("class value exceeds class set bounds");
    }
#endif
    return scs;
}
