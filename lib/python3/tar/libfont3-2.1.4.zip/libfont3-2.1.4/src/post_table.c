// Copyright (C) 2014, 2015 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// post_table.c

#include "post_table.h"
#include "utils.h"

#define POST_MARK_REMOVED 0xFFFFFFFF

static char* const macGlyphName[] = {
    ".notdef",      // 0
    "null",         // 1
    "CR",           // 2
    "space",        // 3
    "exclam",       // 4
    "quotedbl",     // 5
    "numbersign",   // 6
    "dollar",       // 7
    "percent",      // 8
    "ampersand",    // 9
    "quotesingle",  // 10
    "parenleft",    // 11
    "parenright",   // 12
    "asterisk",     // 13
    "plus",         // 14
    "comma",        // 15
    "hyphen",       // 16
    "period",       // 17
    "slash",        // 18
    "zero",         // 19
    "one",          // 20
    "two",          // 21
    "three",        // 22
    "four",         // 23
    "five",         // 24
    "six",          // 25
    "seven",        // 26
    "eight",        // 27
    "nine",         // 28
    "colon",        // 29
    "semicolon",    // 30
    "less",         // 31
    "equal",        // 32
    "greater",      // 33
    "question",     // 34
    "at",           // 35
    "A",            // 36
    "B",            // 37
    "C",            // 38
    "D",            // 39
    "E",            // 40
    "F",            // 41
    "G",            // 42
    "H",            // 43
    "I",            // 44
    "J",            // 45
    "K",            // 46
    "L",            // 47
    "M",            // 48
    "N",            // 49
    "O",            // 50
    "P",            // 51
    "Q",            // 52
    "R",            // 53
    "S",            // 54
    "T",            // 55
    "U",            // 56
    "V",            // 57
    "W",            // 58
    "X",            // 59
    "Y",            // 60
    "Z",            // 61
    "bracketleft",  // 62
    "backslash",    // 63
    "bracketright", // 64
    "asciicircum",  // 65
    "underscore",   // 66
    "grave",        // 67
    "a",            // 68
    "b",            // 69
    "c",            // 70
    "d",            // 71
    "e",            // 72
    "f",            // 73
    "g",            // 74
    "h",            // 75
    "i",            // 76
    "j",            // 77
    "k",            // 78
    "l",            // 79
    "m",            // 80
    "n",            // 81
    "o",            // 82
    "p",            // 83
    "q",            // 84
    "r",            // 85
    "s",            // 86
    "t",            // 87
    "u",            // 88
    "v",            // 89
    "w",            // 90
    "x",            // 91
    "y",            // 92
    "z",            // 93
    "braceleft",    // 94
    "bar",          // 95
    "braceright",   // 96
    "asciitilde",   // 97
    "Adieresis",    // 98
    "Aring",        // 99
    "Ccedilla",     // 100
    "Eacute",       // 101
    "Ntilde",       // 102
    "Odieresis",    // 103
    "Udieresis",    // 104
    "aacute",       // 105
    "agrave",       // 106
    "acircumflex",  // 107
    "adieresis",    // 108
    "atilde",       // 109
    "aring",        // 110
    "ccedilla",     // 111
    "eacute",       // 112
    "egrave",       // 113
    "ecircumflex",  // 114
    "edieresis",    // 115
    "iacute",       // 116
    "igrave",       // 117
    "icircumflex",  // 118
    "idieresis",    // 119
    "ntilde",       // 120
    "oacute",       // 121
    "ograve",       // 122
    "ocircumflex",  // 123
    "odieresis",    // 124
    "otilde",       // 125
    "uacute",       // 126
    "ugrave",       // 127
    "ucircumflex",  // 128
    "udieresis",    // 129
    "dagger",       // 130
    "degree",       // 131
    "cent",         // 132
    "sterling",     // 133
    "section",      // 134
    "bullet",       // 135
    "paragraph",    // 136
    "germandbls",   // 137
    "registered",   // 138
    "copyright",    // 139
    "trademark",    // 140
    "acute",        // 141
    "dieresis",     // 142
    "notequal",     // 143
    "AE",           // 144
    "Oslash",       // 145
    "infinity",     // 146
    "plusminus",    // 147
    "lessequal",    // 148
    "greaterequal", // 149
    "yen",          // 150
    "mu",           // 151
    "partialdiff",  // 152
    "summation",    // 153
    "product",      // 154
    "pi",           // 155
    "integral'",    // 156
    "ordfeminine",  // 157
    "ordmasculine", // 158
    "Omega",        // 159
    "ae",           // 160
    "oslash",       // 161
    "questiondown", // 162
    "exclamdown",   // 163
    "logicalnot",   // 164
    "radical",      // 165
    "florin",       // 166
    "approxequal",  // 167
    "increment",    // 168
    "guillemotleft",// 169
    "guillemotright",//170
    "ellipsis",     // 171
    "nbspace",      // 172
    "Agrave",       // 173
    "Atilde",       // 174
    "Otilde",       // 175
    "OE",           // 176
    "oe",           // 177
    "endash",       // 178
    "emdash",       // 179
    "quotedblleft", // 180
    "quotedblright",// 181
    "quoteleft",    // 182
    "quoteright",   // 183
    "divide",       // 184
    "lozenge",      // 185
    "ydieresis",    // 186
    "Ydieresis",    // 187
    "fraction",     // 188
    "currency",     // 189
    "guilsinglleft",// 190
    "guilsinglright",//191
    "fi",           // 192
    "fl",           // 193
    "daggerdbl",    // 194
    "middot",       // 195
    "quotesinglbase",//196
    "quotedblbase", // 197
    "perthousand",  // 198
    "Acircumflex",  // 199
    "Ecircumflex",  // 200
    "Aacute",       // 201
    "Edieresis",    // 202
    "Egrave",       // 203
    "Iacute",       // 204
    "Icircumflex",  // 205
    "Idieresis",    // 206
    "Igrave",       // 207
    "Oacute",       // 208
    "Ocircumflex",  // 209
    "apple",        // 210
    "Ograve",       // 211
    "Uacute",       // 212
    "Ucircumflex",  // 213
    "Ugrave",       // 214
    "dotlessi",     // 215
    "circumflex",   // 216
    "tilde",        // 217
    "overscore",    // 218
    "breve",        // 219
    "dotaccent",    // 220
    "ring",         // 221
    "cedilla",      // 222
    "hungarumlaut", // 223
    "ogonek",       // 224
    "caron",        // 225
    "Lslash",       // 226
    "lslash",       // 227
    "Scaron",       // 228
    "scaron",       // 229
    "Zcaron",       // 230
    "zcaron",       // 231
    "brokenbar",    // 232
    "Eth",          // 233
    "eth",          // 234
    "Yacute",       // 235
    "yacute",       // 236
    "Thorn",        // 237
    "thorn",        // 238
    "minus",        // 239
    "multiply",     // 240
    "onesuperior",  // 241
    "twosuperior",  // 242
    "threesuperior",// 243
    "onehalf",      // 244
    "onequarter",   // 245
    "threequarters",// 246
    "franc",        // 247
    "Gbreve",       // 248
    "gbreve",       // 249
    "Idot",         // 250
    "Scedilla",     // 251
    "scedilla",     // 252
    "Cacute",       // 253
    "cacute",       // 254
    "Ccaron",       // 255
    "ccaron",       // 256
    "dcroat"        // 257
};

LF_ERROR POST_readTable(LF_FONT* lfFont, const sfnt_table_record* record, LF_STREAM* stream)
{
    if(STREAM_streamSeek(stream, record->offset) == 0)
    {
        post_table* table = (post_table*)malloc(sizeof(post_table));
        if(table == NULL)
            return LF_OUT_OF_MEMORY;

        // read the whole table as before - this buffer will be used to write the table
        table->length = record->length;
        table->data = STREAM_readChunk(stream, table->length);

        // reset
        STREAM_streamSeek(stream, record->offset);

        // read the common info
        table->Version = STREAM_readFixed(stream);
        table->italicAngle = STREAM_readFixed(stream);
        table->underlinePosition = STREAM_readFWord(stream);
        table->underlineThickness = STREAM_readFWord(stream);
        table->isFixedPitch = STREAM_readULong(stream);
        table->minMemType42 = STREAM_readULong(stream);
        table->maxMemType42 = STREAM_readULong(stream);
        table->minMemType1 = STREAM_readULong(stream);
        table->maxMemType1 = STREAM_readULong(stream);

        table->namesParsed = FALSE;
        table->subsetted = FALSE;
        table->calculatedSizeVersion = 0;
        table->calculatedTableSize = 0;
        table->calculatedNumGlyphs = 0;

        LF_ERROR error = vector_init(&table->removedGIDs, 32, 32);
        if (error != LF_ERROR_OK)
        {
            free(table);
            return error;
        }

        if (table->Version == 0x00010000)
        {
            ASSERT(table->Version != 0x00010000); // temp to see if there are any
        }

        map_insert(&lfFont->table_map, (void*)(intptr_t)record->tag, table);

        return LF_ERROR_OK;
    }

    return LF_INVALID_OFFSET;
}

static void POST_applySubset(post_table* table)
{
    if (table->subsetted == FALSE)
    {
        for (size_t i = 0; i < table->removedGIDs.count; ++i)
        {
            GlyphID gidToRemove = (GlyphID)(intptr_t)vector_at(&table->removedGIDs, i);

            vector_set_data(&table->glyphNameIndex, gidToRemove, (void*)(intptr_t)POST_MARK_REMOVED);
        }

        table->subsetted = TRUE;
    }
}

static LF_ERROR POST_parseNames(post_table* table)
{
    if (table->Version != 0x00020000)
        return LF_UNSUPPORTED;

    LF_STREAM stream;

    STREAM_initMemStream(&stream, table->data, table->length);

    size_t namesStart = 2 * sizeof(FIXED) + 2 * sizeof(FWORD) + 5 * sizeof(ULONG); // skip the v1 info

    STREAM_streamSeek(&stream, namesStart);

    USHORT numGlyphs = STREAM_readUShort(&stream);

    LF_ERROR error = vector_init(&table->glyphNameIndex, numGlyphs, 4);
    if (LF_ERROR_OK != error)
        return LF_OUT_OF_MEMORY;

    error = vector_init(&table->names, numGlyphs, 4);
    if (LF_ERROR_OK != error)
        return LF_OUT_OF_MEMORY;

    // read the indexes
    for (USHORT i = 0; i < numGlyphs; i++)
        vector_push_back(&table->glyphNameIndex, (void*)(intptr_t)STREAM_readUShort(&stream));

    // read the Pascal names
    while (STREAM_streamPos(&stream) < table->length)
    {
        BYTE length = STREAM_readByte(&stream);
        vector_push_back(&table->names, STREAM_readString(&stream, length));
    }

    table->namesParsed = TRUE;

    return LF_ERROR_OK;
}

static LF_ERROR POST_internalGetSize(post_table* table, ULONG requestedVersion, ULONG* actualVersion, size_t* tableSize, size_t* numGlyphs)
{
    LF_ERROR error = LF_ERROR_OK;

    if ((table->calculatedTableSize != 0) && (table->calculatedSizeVersion == requestedVersion))
    {
        *tableSize = table->calculatedTableSize;
        *numGlyphs = table->calculatedNumGlyphs;
        *actualVersion = requestedVersion;
    }
    else
    {
        *tableSize = sizeof(FIXED) * 2 + sizeof(FWORD) * 2 + sizeof(ULONG) * 5;  // = 32
        *numGlyphs = 0;
        *actualVersion = requestedVersion;

        if (requestedVersion == 0x00020000)
        {
            if (table->Version == 0x00030000)
            {
                // if the original version is 3, the output will also be version 3
                table->calculatedTableSize = *tableSize;
                table->calculatedSizeVersion = 0x00030000;
                table->calculatedNumGlyphs = 0;
                *actualVersion = 0x00030000;
            }
            else
            {
                // if orig version is 2, then the names will be present (and possibly subsetted) in the names vector
                if (FALSE == table->namesParsed)
                    error = POST_parseNames(table);

                if (error == LF_ERROR_OK)
                {
                    POST_applySubset(table);

                    *actualVersion = 0x00020000;

                    *tableSize += sizeof(USHORT);                               // numberOfGlyphs

                    for (size_t i = 0; i < table->glyphNameIndex.count; ++i)
                    {
                        ULONG nameIndex = (ULONG)(intptr_t)vector_at(&table->glyphNameIndex, i);

                        if (nameIndex != POST_MARK_REMOVED)
                        {
                            (*numGlyphs)++;

                            if (nameIndex > 257)
                            {
                                CHAR* name = (CHAR*)vector_at(&table->names, nameIndex - 258);
                                *tableSize += strlen((const char*)name) + 1;
                            }
                        }
                    }

                    *tableSize += *numGlyphs * sizeof(USHORT); // glyphNameIndex[numGlyphs]

                    table->calculatedTableSize = *tableSize;
                    table->calculatedSizeVersion = requestedVersion;
                    table->calculatedNumGlyphs = *numGlyphs;
                }
            }
        }
        else if (requestedVersion != 0x00030000)
        {
            DEBUG_LOG_ERROR("POST_getTableSize - unsupported table version");
            error = LF_INVALID_PARAM;
        }
    }

    return error;
}

ULONG POST_getVersion(const LF_FONT* lfFont)
{
    post_table* table = (post_table*)map_at(&lfFont->table_map, (void*)TAG_POST);
    if (table == NULL)
        return 0xFFFFFFFF;

    return table->Version;
}

LF_ERROR POST_getTableSize(const LF_FONT* lfFont, ULONG version, size_t* tableSize)
{
    *tableSize = 0;

    post_table* table = (post_table*)map_at(&lfFont->table_map, (void*)TAG_POST);
    if(table == NULL)
        return LF_EMPTY_TABLE;

    if (version == 0x00000000)
        version = table->Version;               // preserve original version

    if (lfFont->fontType == eLF_CFF_FONT)
        version = 0x00030000;                   // CFFs must be written with version 3

    size_t numGlyphs;
    ULONG actual;
    return POST_internalGetSize(table, version, &actual, tableSize, &numGlyphs);
}

static BYTE* POST_buildTable(post_table* table, ULONG version, size_t* tableSize)
{
    size_t numGlyphs;
    ULONG actual;
    LF_ERROR error = POST_internalGetSize(table, version, &actual, tableSize, &numGlyphs);

    if (error != LF_ERROR_OK)
        return NULL;

    size_t paddedSize = *tableSize;
    BYTE* tableData = UTILS_AllocTable(&paddedSize);

    if (tableData == NULL)
        return NULL;

    LF_STREAM stream;

    STREAM_initMemStream(&stream, tableData, *tableSize);

    STREAM_writeFixed(&stream, actual);
    STREAM_writeFixed(&stream, table->italicAngle);
    STREAM_writeFWord(&stream, table->underlinePosition);
    STREAM_writeFWord(&stream, table->underlineThickness);
    STREAM_writeULong(&stream, table->isFixedPitch);
    STREAM_writeULong(&stream, table->minMemType42);
    STREAM_writeULong(&stream, table->maxMemType42);
    STREAM_writeULong(&stream, table->minMemType1);
    STREAM_writeULong(&stream, table->maxMemType1);

    if (actual == 0x00020000)
    {
        size_t pascalDataSize = *tableSize - (32 + sizeof(USHORT) * (numGlyphs + 1));
        
        if (0 == pascalDataSize)      // silence xcode analyzer
        {
            free(tableData);
            return NULL;
        }

        BYTE* pascalData = (BYTE*)calloc(1, pascalDataSize);
        if (pascalData == NULL)
        {
            free(tableData);
            return NULL;
        }

        LF_STREAM pascalNamesStream;
        STREAM_initMemStream(&pascalNamesStream, pascalData, pascalDataSize);

        // write number of glyphs
        STREAM_writeUShort(&stream, (USHORT)numGlyphs);

        size_t i;
        USHORT newNameIndex = 258;

        // glyph name indexes
        for (i = 0; i < table->glyphNameIndex.count; i++)
        {
            ULONG nameIndex = (ULONG)(intptr_t)vector_at(&table->glyphNameIndex, i);

            if (nameIndex != POST_MARK_REMOVED)
            {
                if (nameIndex < 258)
                {
                    STREAM_writeUShort(&stream, (USHORT)nameIndex);
                }
                else
                {
                    STREAM_writeUShort(&stream, (USHORT)newNameIndex++);

                    // write out names in PASCAL format
                    CHAR* name = (CHAR*)vector_at(&table->names, nameIndex - 258);
                    BYTE len = (BYTE)strlen((const char*)name);
                    STREAM_writeByte(&pascalNamesStream, len);
                    STREAM_writeChunk(&pascalNamesStream, (BYTE*)name, len);
                }
            }
        }

        STREAM_writeChunk(&stream, (BYTE*)pascalData, pascalDataSize);
        free(pascalData);
    }

    return tableData;
}

LF_ERROR POST_writeTable(const LF_FONT* lfFont, ULONG version, sfnt_table_record* record, LF_STREAM* stream)
{
    size_t table_size = 0;
    //ULONG padLen = 0;
    BYTE* tableData;
    post_table* table = (post_table*)map_at(&lfFont->table_map, (void*)TAG_POST);

    if (table == NULL)
        return LF_TABLE_MISSING;

    if (!((version == 0x00000000) || (version == 0x00020000) || (version == 0x00030000)))
    {
        DEBUG_LOG_ERROR("POST_writeTable -- unsupported table version");
        return LF_INVALID_PARAM;
    }

    if (version == 0x00000000)
        version = table->Version;               // preserve original version

    if (lfFont->fontType == eLF_CFF_FONT)
        version = 0x00030000;                   // CFFs must be written with version 3

    tableData = POST_buildTable(table, version, &table_size);
    if(tableData == NULL)
        return LF_OUT_OF_MEMORY;

    //UTILS_PadTable(&tableData, table_size, &padLen);

    record->checkSum = UTILS_CalcTableChecksum(tableData, table_size);
    record->length = (ULONG)table_size;
    record->offset = (ULONG)STREAM_streamPos(stream);

    STREAM_writeChunk(stream, tableData, (table_size + 3) & ~3);
    free(tableData);

    return LF_ERROR_OK;
}

LF_ERROR POST_freeTable(const LF_FONT* lfFont)
{
    post_table* table = (post_table*)map_at(&lfFont->table_map, (void*)TAG_POST);

    if(table)
    {
        if ((table->namesParsed && table->Version == 0x00020000))
        {
            if (vector_size(&table->names) > 0)
            {
                size_t i, count = vector_size(&table->names);

                for (i = 0; i < count; i++)
                    free(vector_at(&table->names, i));
            }

            vector_free(&table->glyphNameIndex);
            vector_free(&table->names);
        }

        vector_free(&table->removedGIDs);

        free(table->data);
        free(table);
    }

    return LF_ERROR_OK;
}

LF_ERROR POST_removeGlyph(const LF_FONT* lfFont, GlyphID index)
{
    post_table* table = (post_table*)map_at(&lfFont->table_map, (void*)TAG_POST);

    if (table == NULL)
        return LF_TABLE_MISSING;

    table->calculatedTableSize = 0;

    // We only need to know which glyphs are removed if writing to version 2; which we don't
    // know until write time, so just keep a list of the removed ids.
    return vector_push_back(&table->removedGIDs, (void*)(intptr_t)index);
}

CHAR* POST_getGlyfNameFromIndex(const LF_FONT* lfFont, GlyphID index)
{
    post_table* table = (post_table*)map_at(&lfFont->table_map, (void*)TAG_POST);

    if (table)
    {
        if (table->Version == 0x00010000)
        {
            return (CHAR*)macGlyphName[index];
        }
        else if (table->Version == 0x00020000)
        {
            if (FALSE == table->namesParsed)
            {
                LF_ERROR error = POST_parseNames(table);
                if (error != LF_ERROR_OK)
                {
                    DEBUG_LOG_ERROR("POST_getGlyfNameFromIndex - failed parsing names");
                    return NULL;
                }
                POST_applySubset(table);
            }

            USHORT nameIndex = (USHORT)(intptr_t)vector_at(&table->glyphNameIndex, index);

            if ((index == 0) || (nameIndex > 0))
            {
                if (nameIndex >= 258)
                {
                    return (CHAR*)vector_at(&table->names, nameIndex - 258);
                }
                else
                {
                    return (CHAR*)macGlyphName[nameIndex];
                }
            }
        }
    }

    return NULL;
}
