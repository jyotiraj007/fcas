// Copyright (C) 2014, 2016, 2017 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
/// \file lf_core.c

#include <stdio.h>
#include <memory.h>
#include <math.h>
#include <ctype.h>
#include "lf_core.h"
#include "stream.h"
#include "sfnt_core.h"
#include "woff_core.h"
#include "woff2_core.h"
#include "eot_core.h"
#include "table_tags.h"
#include "cencode.h"
#include "svg_core.h"
#include "maxp_table.h"
#include "utils.h"
#include "os2_table.h"

static boolean  LF_alwaysRetained(ULONG tag);
static LF_ERROR LF_checkGlyphTable(LF_FONT* lfFont, LF_FONT_TYPE type, const LF_WRITE_PARAMS *params);
static void fixupNameString(char *str);

/**
 * @defgroup CORE Core Library
 * @brief Core library API Functions
 * @{
 */

/**
    Gets the version string for the LibFont library.
    @param[out] version
    @note The version string is typedef'd to be a character string of fixed length. 
    Use this string to record the library version in log messages or other output. 
    @see VERSION_STRING, LIBFONT_VERSION
*/
void LF_getVersion(VERSION_STRING version)
{
    const char *changelist = "$Change: 134720 $";
    memset(version,0,sizeof(VERSION_STRING));
    strncpy(version,LIBFONT_VERSION, sizeof(VERSION_STRING));
    version[strlen(LIBFONT_VERSION)] = 0;   // silence VS2015 analyzer warning
    strncat(version,".",1);
    strncat(version,&changelist[9],6);
}

/**
Gets the string for a LibFont error code.
@param[in] error error code
@note: The returned string is just the string literal of the error code.
@see LF_ERROR
*/
char* LF_getErrorMessage(LF_ERROR error)
{
    return UTILS_getErrorMessage(error);
}

/**
    Creates an empty LF_FONT data structure.
    This function allocates memory for the LF_FONT and initializes it.
    @note This function must be used to create a LF_FONT for use in other API functions.
    @see LF_destroyFont
*/
LF_FONT* LF_createFont()
{
    LF_FONT* lfFont = (LF_FONT*)calloc(1, sizeof(LF_FONT));
    if (lfFont != NULL)
    {
        LF_ERROR error = LF_initFont(lfFont);
        if (error != LF_ERROR_OK)
        {
            free(lfFont);
            lfFont = NULL;
        }
    }

    return lfFont;
}

/**
    Initialize an empty LF_FONT data structure. This called by LF_createFont. You would
    not normally call this function except to initialize an existing LF_FONT. In that
    case you must free it with LF_freeFont first.
    @param[in] lfFont parent class
    @see LF_freeFont
*/
LF_ERROR LF_initFont(LF_FONT* lfFont)
{
    if (lfFont == NULL) return LF_INVALID_PARAM;

    map_init(&lfFont->table_map, integer_compare);

    lfFont->fontType = eLF_UNDETERMINED;
    lfFont->origType = eLF_UNDETERMINED;
    lfFont->origFlavor = SIG_UNKONWN;

    lfFont->fontData = NULL;
    lfFont->fontSize = 0;
    lfFont->ownFontData = FALSE;

    lfFont->woffInfo.metaData = NULL;
    lfFont->woffInfo.metaDataLen = 0;
    lfFont->woffInfo.metaDataOrigLen = 0;
    lfFont->woffInfo.privateData = NULL;
    lfFont->woffInfo.privateDataLen = 0;

    memset(&lfFont->builtParams, 0, sizeof(LF_WRITE_PARAMS));
    lfFont->builtSFNT = NULL;
    lfFont->builtSFNTSize = 0;
    lfFont->builtSFNTOffsetTable = NULL;

    lfFont->isSubsetted = FALSE;
    lfFont->isRefitted = FALSE;

    return LF_ERROR_OK;
}   /*lint !e429*/

/**
    Get the type of font accessed via a LF_STREAM.
    @param[in] lfFont parent class
    @param[in] stream input stream
    @param[out] type returns font type following read
    @see LF_FONT_TYPE
*/
static LF_ERROR LF_getFontType(LF_STREAM* stream, LF_FONT_TYPE *type, ULONG* flavor)
{
    size_t currentStreamPos = STREAM_streamPos(stream);
    FIXED fontSignature;
    STREAM_streamSeek(stream, 0);
    fontSignature = STREAM_readFixed(stream);
    STREAM_streamSeek(stream, currentStreamPos);

    *flavor = fontSignature;

    if (fontSignature == SIG_VERSION1 || fontSignature == SIG_VERSION2 ||
        fontSignature == SIG_TRUETYPE)
    {
        *type = eLF_SFNT_FONT;

        return LF_ERROR_OK;
    }
    else if (fontSignature == SIG_CFF)
    {
        *type = eLF_CFF_FONT;
        return LF_ERROR_OK;
    }
    else if (fontSignature == SIG_WOFF)
    {
        *type = eLF_WOFF_FONT;

        STREAM_streamSeek(stream, 4); // position stream to read font flavor
        *flavor = STREAM_readULong(stream);
        STREAM_streamSeek(stream, currentStreamPos);

        return LF_ERROR_OK;
    }
    else if (fontSignature == SIG_WOFF2)
    {
        *type = eLF_WOFF2_FONT;

        STREAM_streamSeek(stream, 4); // position stream to read font flavor
        *flavor = STREAM_readULong(stream);
        STREAM_streamSeek(stream, currentStreamPos);
        return LF_ERROR_OK;
    }
    else
    {
        USHORT eotSignature;

        STREAM_streamSeek(stream, 34); // position stream to read EOT magic number
        eotSignature = STREAM_readUShort(stream);
        eotSignature = SWAP_USHORT(eotSignature);  // stream is really little-endian
        STREAM_streamSeek(stream, currentStreamPos);

        if (eotSignature == 0x504C)  // EOT magic number
        {
            *type = eLF_EOT_FONT;

            STREAM_streamSeek(stream, 8); // position stream to read EOT version
            *flavor = STREAM_readULong(stream);
            *flavor = SWAP_ULONG((*flavor));  // stream is really little-endian
            STREAM_streamSeek(stream, currentStreamPos);

            return LF_ERROR_OK;
        }
    }

    *type = eLF_UNDETERMINED;
    *flavor = SIG_UNKONWN;

    return LF_BAD_FORMAT;
}

/**
    Reads a font from a memory buffer.
    @param[in] lfFont parent class
    @param[in] fontData input font memory buffer
    @param[in] fontSize size of input buffer
    @param[in] keepFlags 32-bit flags to indicate what information to keep
    @param[out] origType returns font type following read
    @see LF_readFontFromFile, LF_writeFontToMemory, LF_FONT_TYPE
*/
LF_ERROR LF_readFontFromMemory(LF_FONT* lfFont, BYTE* fontData, ULONG fontSize, int keepFlags, LF_FONT_TYPE* origType)
{
    LF_STREAM stream;
    LF_ERROR error;

    if ((lfFont == NULL) || (fontData == NULL) || (origType == NULL))
        return LF_INVALID_PARAM;

    *origType = eLF_UNDETERMINED;

    STREAM_initMemStream(&stream, fontData, fontSize);

    error = LF_getFontType(&stream, &lfFont->fontType, &lfFont->origFlavor);
    if(error == LF_ERROR_OK)
    {
        *origType = lfFont->fontType;
        lfFont->origType = lfFont->fontType;

        if (lfFont->fontType == eLF_SFNT_FONT || lfFont->fontType == eLF_CFF_FONT)
        {
            if ((lfFont->fontData) && (lfFont->ownFontData == TRUE))
                free(lfFont->fontData);

            lfFont->fontData = fontData;
            lfFont->fontSize = fontSize;

            error = SFNT_readOffsetTable(lfFont, &stream, keepFlags);
        } // sfnt font
        else if(lfFont->fontType == eLF_WOFF_FONT)
        {
            error = WOFF_readOffsetTable(lfFont, &stream, keepFlags);
            if(error == LF_ERROR_OK)
            {
                error = WOFF_getData(lfFont, &stream);
                if(error == LF_ERROR_OK)
                    error = WOFF_to_SFNT(lfFont, &stream);
                if (error != LF_ERROR_OK)
                    WOFF_destroyOffsetTable(lfFont);
            }
        }
        else if(lfFont->fontType == eLF_EOT_FONT)
        {
            error = EOT_readOffsetTable(lfFont, &stream, keepFlags);
            if(error == LF_ERROR_OK)
                error = EOT_to_SFNT(lfFont, keepFlags);
        }
        else if(lfFont->fontType == eLF_WOFF2_FONT)
        {
            error = WOFF2_readOffsetTable(lfFont, &stream, keepFlags);
            if(error == LF_ERROR_OK)
            {
                error = WOFF2_getData(lfFont, &stream);
                if(error == LF_ERROR_OK)
                    error = WOFF2_to_SFNT(lfFont, &stream);
            }
        }
        else
        {
            error = LF_INVALID_TYPE;
        }

        // if the client has allocated the data, and the font is a ttf (sfnt), we store the pointer at lfFont->fontData, otherwise libfont has allocated the data
        if ((error == LF_ERROR_OK) && (lfFont->ownFontData == FALSE) && (*origType != eLF_SFNT_FONT) && (*origType != eLF_CFF_FONT))
            lfFont->ownFontData = TRUE;
    }

    return error;
}

/**
    Reads a font from a file.
    @param[in] lfFont parent class
    @param[in] filePath input font file path
    @param[in] keepFlags 32-bit flags to indicate what information to keep
    @see LF_readFontFromMemory, LF_writeFontToFile
*/
LF_ERROR LF_readFontFromFile(LF_FONT* lfFont, const char* filePath, int keepFlags)
{
    LF_ERROR error = LF_FILE_OPEN_FAIL;
    FILE* file = NULL;

    if (lfFont == NULL) return LF_INVALID_PARAM;

    if (filePath)
        file = fopen(filePath, "rb");

    if(file)
    {
        ULONG fontSize;
        BYTE* fontData;
        size_t numRead;
        LF_FONT_TYPE srcFontType;

        if (lfFont->fontSize)
            LF_freeFont(lfFont);

        fseek(file, 0, SEEK_END);
        fontSize = (ULONG)ftell(file);
        fseek(file, 0, SEEK_SET);
        fontData = (BYTE*)malloc(fontSize);

        if(NULL == fontData)
        {
            fclose(file);
            return LF_OUT_OF_MEMORY;
        }

        lfFont->ownFontData = TRUE;

        numRead = fread(fontData, 1, fontSize, file);
        fclose(file);

        if(numRead != fontSize)
        {
            free(fontData);
            return LF_FILE_OPEN_FAIL;
        }

#ifdef LF_LOGGING
        UTILS_openLog((char*)filePath);
#endif
#ifdef LF_OT_DUMP
        UTILS_openXML((char*)filePath);
#endif

        error = LF_readFontFromMemory(lfFont, fontData, fontSize, keepFlags, &srcFontType);
        if(LF_ERROR_OK == error)
        {
            if (srcFontType != eLF_SFNT_FONT && srcFontType != eLF_CFF_FONT)
                free(fontData);
        }
        else
        {
            if(lfFont->fontData == NULL)
                free(fontData);
        }
    }

    return error;
}

/**
Determine if a given table is in a font.
@param[in] lfFont parent class
@param[in] tag table tag
@param[out] hasTable will be set to TRUE if the table is in the font, FALSE if not
@note Table tags are four characters encoded in an unsigned long.
For example, the name table tag is 0x6E616D65. See table_tags.h
@see lf_core.h, table_tags.h
*/
LF_ERROR LF_hasTable(LF_FONT* lfFont, ULONG tag, boolean* hasTable)
{
    if ((lfFont == NULL) || (hasTable == NULL))
        return LF_INVALID_PARAM;

    *hasTable = SFNT_tableInOffsetTable(lfFont, tag);

    return LF_ERROR_OK;
}

/**
Get the type of font and its flavor
@param[in] lfFont parent class
@param[out] type returns font type
@param[out] flavor returns font signature
@see LF_FONT_TYPE
*/
LF_ERROR LF_getFontInfo(LF_FONT* lfFont, LF_FONT_TYPE* type, ULONG* flavor)
{
    if (lfFont == NULL)
        return LF_INVALID_PARAM;

    if (type != NULL)
        *type = lfFont->origType;

    if (flavor != NULL)
        *flavor = lfFont->origFlavor;

    return LF_ERROR_OK;
}

/**
    Remove a font table based on its tag.
    @param[in] lfFont parent class
    @param[in] tag table tag
    @note Table tags are four characters encoded in an unsigned long.
    For example, the name table tag is 0x6E616D65. See table_tags.h
    Required tables cannot be removed. See lf_core.h for the list of
    required tables. The cvt, fpgm, and prep tables can be removed via
    LF_removeHints.
    @see lf_core.h, table_tags.h, LF_removeHints
*/
LF_ERROR LF_removeTable(LF_FONT* lfFont, ULONG tag)
{
    if(lfFont == NULL)
        return LF_INVALID_PARAM;

    // Do not allow removal of required tables. fpgm, cvt, and prep can be removed via LF_removeHints.
    if(TRUE == LF_alwaysRetained(tag))
        return LF_INVALID_PARAM;

    return SFNT_removeTable(lfFont, tag);
}

/**
    Remove font hints prior to output.
    @param[in] lfFont parent class
    @note In this version of the software, this function will succeed only when called
    after calling LF_subsetFont.
*/
LF_ERROR LF_removeHints(LF_FONT* lfFont)
{
    if(lfFont == NULL)
        return LF_INVALID_PARAM;

    return SFNT_removeHints(lfFont);
}

/**
    Obfuscate the name table data prior to output of the font.
    @param[in] lfFont parent class
    @note In this version of the software, this function will succeed only when called
    after calling LF_subsetFont.
*/
LF_ERROR LF_obfuscateFont(LF_FONT* lfFont)
{
    if(lfFont == NULL)
        return LF_INVALID_PARAM;

    return SFNT_obfuscateFont(lfFont);
}

/**
    Gets the 3,1, US English (0x409) name string from the font's name table.
    @param[in] lfFont font object
    @param[in] nameID nameID the name string to get
    @param[out] name pointer to buffer that will be allocated by the function and will be
                filled with the name string (two bytes per character)
    @param[out] length length of the buffer (not length of string)
    @note The caller must free the returned buffer. The buffer is not null terminated
    @returns LF_INVALID_TYPE if the string is not present in the font
*/
LF_ERROR LF_getNameString(LF_FONT* lfFont, USHORT nameID, BYTE** name, USHORT* length)
{
    if (lfFont == NULL)
        return LF_INVALID_PARAM;

    return SFNT_getNameString(lfFont, FALSE, nameID, name, length);
}

/**
    Updates or inserts the 3, 1, US English (0x409) name string for the given name ID in the font's
    name table.
    @param[in] lfFont font object
    @param[in] nameID nameID the name string to replace or insert
    @param[in] buffer buffer containing the new string (two bytes per character)
    @param[in] length length of the buffer (not length of string)
    @note Passing a NULL buffer will result in the string being removed from the name table.
*/
LF_ERROR LF_setNameString(LF_FONT* lfFont, USHORT nameID, const BYTE *buffer, USHORT length)
{
    if (lfFont == NULL)
        return LF_INVALID_PARAM;

    return SFNT_setNameString(lfFont, FALSE, nameID, buffer, length);
}

/**
Gets the 1,0,English (0) name string from the font's name table.
@param[in] lfFont font object
@param[in] nameID nameID the name string to get
@param[out] name pointer to buffer that will be allocated by the function and will be
filled with the name string (two bytes per character)
@param[out] length length of the buffer (not length of string)
@note The caller must free the returned buffer. The buffer is not null terminated
@returns LF_INVALID_TYPE if the string is not present in the font
*/
LF_ERROR LF_getMacNameString(LF_FONT* lfFont, USHORT nameID, BYTE** name, USHORT* length)
{
    if (lfFont == NULL)
        return LF_INVALID_PARAM;

    return SFNT_getNameString(lfFont, TRUE, nameID, name, length);
}

/**
Updates or inserts the 1,0,English (0) name string for the given name ID in the font's
name table.
@param[in] lfFont font object
@param[in] nameID nameID the name string to replace or insert
@param[in] buffer buffer containing the new string (two bytes per character)
@param[in] length length of the buffer (not length of string)
@note Passing a NULL buffer will result in the string being removed from the name table.
*/
LF_ERROR LF_setMacNameString(LF_FONT* lfFont, USHORT nameID, const BYTE *buffer, USHORT length)
{
    if (lfFont == NULL)
        return LF_INVALID_PARAM;

    return SFNT_setNameString(lfFont, TRUE, nameID, buffer, length);
}

/**
    Gets the glyph ID for the Unicode, if it is present in a 3,10 or 3,1 cmap encoding in the font.
    @param[in] lfFont font object
    @param[in] unicode Unicode for which to get the glyph ID.
    @param[out] glyphID glyph ID for the Unicode or 0 if the font does not contain the Unicode.
    @returns LF_ERROR_OK on success. LF_UNSUPPORTED if the font does not have a 3,10 or 3,1 encoding.
*/
LF_ERROR LF_getGlyphID(LF_FONT* lfFont, ULONG unicode, GlyphID* glyphID)
{
    if ((lfFont == NULL) || (glyphID == NULL))
        return LF_INVALID_PARAM;

    return SFNT_getGlyphID(lfFont, unicode, glyphID);
}

/**
Gets the achVendID from the OS/2 table
@param[in] lfFont font object
@param[inout] achVendID filled with the font's vendor ID
@returns LF_ERROR_OK on success.
*/
LF_ERROR LF_getVendorID(LF_FONT* lfFont, CHAR achVendID[4])
{
    if (lfFont == NULL)
        return LF_INVALID_PARAM;

    return SFNT_getVendorID(lfFont, achVendID);
}

/**
Gets the fsType field from the OS/2 table.
@param[in] lfFont font object
@param[out] fsType filled with the font's fsType flags
@returns LF_ERROR_OK on success.
@note Caller is responsible for interpreting the flags.
*/
LF_ERROR LF_getEmbedding(LF_FONT* lfFont, USHORT* embedding)
{
    if (lfFont == NULL)
        return LF_INVALID_PARAM;

    return SFNT_getFsType(lfFont, embedding);
}

/**
Sets the fsType flags into the OS/2 table.
@param[in] lfFont font object
@param[in] desired fsType flag(s)
@returns LF_ERROR_OK on success.
@note Passed in flags are checked for validity.
*/
LF_ERROR LF_setEmbedding(LF_FONT* lfFont, USHORT embedding)
{
    if (lfFont == NULL)
        return LF_INVALID_PARAM;

    return SFNT_setFsType(lfFont, embedding);
}

/**
Gets the fsSelection flags from the OS/2 table.
@param[in] lfFont font object
@param[out] font's fsSelection flags
@returns LF_ERROR_OK on success.
*/
LF_ERROR LF_getFontSelection(LF_FONT* lfFont, USHORT* selection)
{
    if (lfFont == NULL)
        return LF_INVALID_PARAM;

    return SFNT_getFsSelection(lfFont, selection);
}

/**
Sets the fsSelection flags into the OS/2 table.
@param[in] lfFont font object
@param[in] desired fsSelection flag(s)
@returns LF_ERROR_OK on success.
@note Passed in flags are checked for validity.
*/
LF_ERROR LF_setFontSelection(LF_FONT* lfFont, USHORT selection)
{
    if (lfFont == NULL)
        return LF_INVALID_PARAM;

    return SFNT_setFsSelection(lfFont, selection);
}

/**
Gets the usWeightClass value from the OS/2 table.
@param[in] lfFont font object
@param[out] font's fsSelection flags
@returns LF_ERROR_OK on success.
*/
LF_ERROR LF_getWeightClass(LF_FONT* lfFont, USHORT* usWeightClass)
{
    if (lfFont == NULL)
        return LF_INVALID_PARAM;

    return SFNT_getUsWeightClass(lfFont, usWeightClass);
}

/**
Sets the usWeightClass value into the OS/2 table.
@param[in] lfFont font object
@param[in] desired usWeightClass value
@returns LF_ERROR_OK on success.
@note Passed in value is checked for validity (must be 1 - 1000).
*/
LF_ERROR LF_setWeightClass(LF_FONT* lfFont, USHORT usWeightClass)
{
    if (lfFont == NULL)
        return LF_INVALID_PARAM;

    return SFNT_setUsWeightClass(lfFont, usWeightClass);
}

/**
Gets the macStyle flags from the head table.
@param[in] lfFont font object
@param[out] macStyle flags
@returns LF_ERROR_OK on success.
*/
LF_ERROR LF_getMacStyle(LF_FONT* lfFont, USHORT* macStyle)
{
    if (lfFont == NULL)
        return LF_INVALID_PARAM;

    return SFNT_getMacStyle(lfFont, macStyle);
}

/**
Sets the macStyle flags into the head table.
@param[in] lfFont font object
@param[in] desired macStyle flags
@returns LF_ERROR_OK on success.
@note Passed in flags are checked for validity.
*/
LF_ERROR LF_setMacStyle(LF_FONT* lfFont, USHORT macStyle)
{
    if (lfFont == NULL)
        return LF_INVALID_PARAM;

    return SFNT_setMacStyle(lfFont, macStyle);
}

/**
Specifies meta data to use with WOFF and WOFF2 output.
@param[in] lfFont parent class
@param[in] metaDataPath path to file containing meta data to include in output
@note No validation of the meta data occurs.
*/
LF_ERROR LF_setMetaData(LF_FONT* lfFont, const char* metaDataPath)
{
    FILE* file;
    ULONG fileLength;

    if (metaDataPath == NULL)
        return LF_ERROR_OK;

    if (lfFont == NULL)
        return LF_INVALID_PARAM;

    // any existing data is discarded
    if (lfFont->woffInfo.metaData != NULL)
    {
        free(lfFont->woffInfo.metaData);
        lfFont->woffInfo.metaData = NULL;
        lfFont->woffInfo.metaDataLen = 0;
        lfFont->woffInfo.metaDataOrigLen = 0;
        lfFont->woffInfo.metatDataCompression = eUNSET;
    }

    if ((strncmp(metaDataPath, "NULL", 4) != 0) && (strncmp(metaDataPath, "null", 4) != 0))
    {
        file = fopen(metaDataPath, "rb");

        if (file == NULL)
            return LF_FILE_OPEN_FAIL;

        fseek(file, 0, SEEK_END);
        fileLength = (ULONG)ftell(file);
        fseek(file, 0, SEEK_SET);
        lfFont->woffInfo.metaData = (BYTE*)malloc(fileLength);

        if (lfFont->woffInfo.metaData == NULL)
        {
            fclose(file);
            return LF_OUT_OF_MEMORY;
        }

        fread(lfFont->woffInfo.metaData, fileLength, 1, file);
        fclose(file);

        lfFont->woffInfo.metaDataOrigLen = fileLength;
        lfFont->woffInfo.metatDataCompression = eUNCOMPRESSED;
    }

    return LF_ERROR_OK;
}

/**
Clears meta data.
@param[in] lfFont parent class
*/
LF_ERROR LF_clearMetaData(LF_FONT* lfFont)
{
    if (lfFont == NULL)
        return LF_INVALID_PARAM;

    // any existing data is discarded
    if (lfFont->woffInfo.metaData != NULL)
    {
        free(lfFont->woffInfo.metaData);
        lfFont->woffInfo.metaData = NULL;
        lfFont->woffInfo.metaDataLen = 0;
        lfFont->woffInfo.metaDataOrigLen = 0;
    }
    return LF_ERROR_OK;

}

/**
    Specifies private data to use with WOFF and WOFF2 output.
    @param[in] lfFont parent class
    @param[in] privateDataPath path to file containing private data to include in output
    @note No validation of the private data occurs.
*/
LF_ERROR LF_setPrivateData(LF_FONT* lfFont, const char* privateDataPath)
{
    FILE* file;
    ULONG fileLength;

    if (privateDataPath == NULL)
        return LF_ERROR_OK;

    if(lfFont == NULL)
        return LF_INVALID_PARAM;

    // any existing data is discarded
    if(lfFont->woffInfo.privateData != NULL)
    {
        free(lfFont->woffInfo.privateData);
        lfFont->woffInfo.privateData = NULL;
        lfFont->woffInfo.privateDataLen = 0;
    }

    if ((strncmp(privateDataPath, "NULL", 4) != 0) && (strncmp(privateDataPath, "null", 4) != 0))
    {
        file = fopen(privateDataPath, "rb");

        if(file == NULL)
            return LF_FILE_OPEN_FAIL;

        fseek(file, 0, SEEK_END);
        fileLength = (ULONG)ftell(file);
        fseek(file, 0, SEEK_SET);
        lfFont->woffInfo.privateData = (BYTE*)malloc(fileLength);

        if(lfFont->woffInfo.privateData == NULL)
        {
            fclose(file);
            return LF_OUT_OF_MEMORY;
        }

        fread(lfFont->woffInfo.privateData, fileLength, 1, file);
        fclose(file);

        lfFont->woffInfo.privateDataLen = fileLength;
    }

    return LF_ERROR_OK;
}

/**
Clears private data
@param[in] lfFont parent class
*/
LF_ERROR LF_clearPrivateData(LF_FONT* lfFont)
{
    if (lfFont == NULL)
        return LF_INVALID_PARAM;

    // any existing data is discarded
    if (lfFont->woffInfo.privateData != NULL)
    {
        free(lfFont->woffInfo.privateData);
        lfFont->woffInfo.privateData = NULL;
        lfFont->woffInfo.privateDataLen = 0;
    }

    return LF_ERROR_OK;
}

/**
Writes metadata to a file.
@param[in] lfFont parent class
@param[in] dataPath path to file to output
@note No validation of the meta data occurs.
*/
LF_ERROR LF_writeMetaDataFile(LF_FONT* lfFont, const char* dataPath)
{
    FILE* file;
    size_t nWrote;
    BYTE *data, *uncompressedData;
    ULONG dataLength, uncompressedDataLength;

    if (lfFont == NULL)
        return LF_INVALID_PARAM;

    if (lfFont->woffInfo.metaData == NULL || lfFont->woffInfo.metaDataLen == 0)
        return LF_ERROR_OK;  // nothing to write

    data = lfFont->woffInfo.metaData;
    dataLength = lfFont->woffInfo.metaDataLen;

    // uncompress as needed
    if (lfFont->woffInfo.metatDataCompression == eUNCOMPRESSED)
    {
        uncompressedData = data;
        uncompressedDataLength = dataLength;
    }
    else if (lfFont->woffInfo.metatDataCompression == eWOFF)
    {
        uncompressedDataLength = dataLength * 3;

        uncompressedData = (BYTE *)malloc(uncompressedDataLength);
        if (uncompressedData == NULL)
            return LF_OUT_OF_MEMORY;

        WOFF_decompress(data, dataLength, uncompressedData, &uncompressedDataLength);
    }
    else if (lfFont->woffInfo.metatDataCompression == eWOFF2)
    {
        size_t uncompLen = dataLength * 3;

        uncompressedData = (BYTE *)malloc(uncompLen);
        if (uncompressedData == NULL)
            return LF_OUT_OF_MEMORY;

        if (FALSE == WOFF2_decompress(data, dataLength, uncompressedData, &uncompLen))
        {
            free(uncompressedData);
            return LF_COMPRESSION;
        }

        uncompressedDataLength = (ULONG)uncompLen;
    }
    else
        return LF_INVALID_PARAM;

    // write the uncompressed data
    file = fopen(dataPath, "wb");

    if (file == NULL)
    {
        free(uncompressedData);
        return LF_FILE_OPEN_FAIL;
    }

    nWrote = fwrite((const void*)uncompressedData, (size_t)uncompressedDataLength, 1, file);

    if (nWrote != 1)
    {
        fclose(file);
        free(uncompressedData);
        return LF_FILE_OPEN_WRITE;
    }

    fclose(file);
    if (lfFont->woffInfo.metatDataCompression != eUNCOMPRESSED)
        free(uncompressedData);
    return LF_ERROR_OK;
}


/**
Writes private data to a file.
@param[in] lfFont parent class
@param[in] dataPath path to file to output
@note No validation of the private data occurs. Private data is not compressed.
*/
LF_ERROR LF_writePrivateDataFile(LF_FONT* lfFont, const char* dataPath)
{
    FILE* file;
    size_t nWrote;
    BYTE *data;
    ULONG dataLength;

    if (lfFont == NULL)
        return LF_INVALID_PARAM;

    if (lfFont->woffInfo.privateData == NULL || lfFont->woffInfo.privateDataLen == 0)
        return LF_ERROR_OK;  // nothing to write

    data = lfFont->woffInfo.privateData;
    dataLength = lfFont->woffInfo.privateDataLen;

    // write the uncompressed data
    file = fopen(dataPath, "wb");

    if (file == NULL)
    {
        return LF_FILE_OPEN_FAIL;
    }

    nWrote = fwrite((const void*)data, (size_t)dataLength, 1, file);

    if (nWrote != 1)
    {
        fclose(file);
        return LF_FILE_OPEN_WRITE;
    }

    fclose(file);
    return LF_ERROR_OK;
}

/**
Returns the number of glyphs in the font
@param[in] lfFont parent class
@param[out] numGlyphs number of glyphs in the font
*/
LF_ERROR LF_getNumberGlyphs(LF_FONT* lfFont, USHORT* numGlyphs)
{
    if ((lfFont == NULL) || (numGlyphs == NULL))
        return LF_INVALID_PARAM;

    if (FALSE == SFNT_tablesUnpacked(lfFont))
    {
        LF_ERROR error = SFNT_unpackTables(lfFont);
        if (error != LF_ERROR_OK)
            return error;
    }

    *numGlyphs = MAXP_getNumGlyphs(lfFont);
    return LF_ERROR_OK;
}

/**
    Calculate the maximum size needed to hold the output font
    based on the font type.
    @param[in] lfFont parent class
    @param[in] type type of font file to write
    @param[in] params write parameters to use when calculating size
    @param[out] size size of memory buffer allocated
    @see LF_FONT_TYPE, LF_writeFontToMemory
*/
LF_ERROR LF_getMaxFontSize(LF_FONT* lfFont, LF_FONT_TYPE type, LF_WRITE_PARAMS *params, size_t* size)
{
    if ((NULL == lfFont) || (params == NULL) || (NULL == size))
        return LF_INVALID_PARAM;
    if (type == eLF_UNDETERMINED)
        return LF_INVALID_PARAM;

    *size = 0;

    LF_ERROR error = LF_checkGlyphTable(lfFont, type, params);
    if (error != LF_ERROR_OK)
        return error;

    switch(type)
    {
        case eLF_SFNT_FONT:
        case eLF_CFF_FONT:
            error = SFNT_getSFNTSize(lfFont, params, size); // uncompressed size of all the tables plus header and offset table
            break;
        case eLF_WOFF_FONT:
            error = WOFF_getMaxSize(lfFont, params, size);
            break;
        case eLF_WOFF2_FONT:
            error = WOFF2_getMaxSize(lfFont, params, size);
            break;
        case eLF_EOT_FONT:
            error = EOT_getMaxSize(lfFont, params, size);
            break;
        case eLF_SVG_FONT:
            error = SVG_getMaxSize(lfFont, params, size);
            break;
        case eLF_UNDETERMINED:
        default:
            error = LF_UNSUPPORTED;
    }

    return error;
}

/**
    Retrieves the default write params
    @param[inout] params params object class
    @return error if object passed in is NULL
*/
LF_ERROR LF_defaultWriteParams(LF_WRITE_PARAMS *params)
{
    if (params == NULL)
        return LF_INVALID_PARAM;

    params->sfnt_ttf = FALSE;
    params->sfnt_cff = FALSE;
    params->conversionTolerance = 0.5f;
    params->postTableVersion = 0x00030000;
    params->woffCompressionLevel = 9;
    params->woffMinTableSize = 0;
    params->woff2CompressionLevel = 6;
    params->svgID[0] = 0;  //initialize as null terminated string

    //future use
    //params->unitsPerEm = USE_DEFAULT_DESIGN_UNITS;

    return LF_ERROR_OK;
}

/**
    Writes LF_FONT to a memory buffer of a specified size. Use LF_getMaxFontSize
    to get the max font size. Allocate fontBuf to be this size. The function
    returns the actual size in *size.
    @note Writes the font into fontBuf and writes the actual length to *size.
    @param[in] lfFont parent class
    @param[in] type type of font file to write
    @param[in] params parameters to control the write process
    @param[in] fontBuf memory buffer to contain the font
    @param[inout] size on input, size available at fontBuf, updated with actual size of font
    @return error if size passed in is not long enough
    @see LF_FONT_TYPE, LF_getMaxFontSize, LF_defaultWriteParams
*/
LF_ERROR LF_writeFontToMemory(LF_FONT* lfFont, LF_FONT_TYPE type, LF_WRITE_PARAMS *params, BYTE* fontBuf, size_t* size)
{
    if ((lfFont == NULL) || (params == NULL) || (fontBuf == NULL) || (size == NULL))
        return LF_INVALID_PARAM;
    if (type == eLF_UNDETERMINED)
        return LF_INVALID_PARAM;

    LF_ERROR error = LF_checkGlyphTable(lfFont, type, params);
    if (error != LF_ERROR_OK)
        return error;

    error = SFNT_constructSFNT(lfFont, params);
    if (error != LF_ERROR_OK)
        return error;

    LF_STREAM stream;
    STREAM_initMemStream(&stream, fontBuf, *size);

    switch(type)
    {
        case eLF_SFNT_FONT:
        case eLF_CFF_FONT:
            error = SFNT_writeToStream(lfFont, params, &stream);
            break;
        case eLF_WOFF_FONT:
            error = WOFF_writeToStream(lfFont, params, &stream);
            break;
        case eLF_WOFF2_FONT:
            error = WOFF2_writeToStream(lfFont, params, &stream);
            break;
        case eLF_EOT_FONT:
            error = EOT_writeToStream(lfFont, params, &stream);
            break;
        case eLF_SVG_FONT:
            *size = 0;
            error = SVG_writeToStream(lfFont, params, &stream, size);
            break;
        default:
            error = LF_INVALID_PARAM;
    }

    if (error == LF_ERROR_OK)
        *size = STREAM_streamPos(&stream);

    return error;
}

/**
    Writes LF_FONT to a file.
    @param[in] lfFont parent class
    @param[in] filePath output font file path
    @param[in] type type of font file to write
    @param[in] params parameters controlling the write process
    @see LF_FONT_TYPE, LF_WRITE_PARAMS, LF_defaultWriteParams
*/
LF_ERROR LF_writeFontToFile(LF_FONT* lfFont, const char* filePath, LF_FONT_TYPE type, LF_WRITE_PARAMS *params)
{
    if ((lfFont == NULL) || (filePath == NULL) || (params == NULL))
        return LF_INVALID_PARAM;
    if (type == eLF_UNDETERMINED)
        return LF_INVALID_PARAM;

    LF_ERROR error = LF_checkGlyphTable(lfFont, type, params);
    if (error != LF_ERROR_OK)
        return error;

    error = SFNT_constructSFNT(lfFont, params);
    if (error != LF_ERROR_OK)
        return error;

    FILE *file = fopen(filePath, "wb");
    if (file == NULL)
        return LF_FILE_OPEN_WRITE;

    LF_STREAM stream;
    STREAM_initFileStream(&stream, file);

    if (type == eLF_SFNT_FONT || type == eLF_CFF_FONT)
    {
        error = SFNT_writeToStream(lfFont, params, &stream);
    }
    else if(type == eLF_WOFF_FONT)
    {
        error = WOFF_writeToStream(lfFont, params, &stream);
    }
    else if(type == eLF_WOFF2_FONT)
    {
        error = WOFF2_writeToStream(lfFont, params, &stream);
    }
    else if(type == eLF_EOT_FONT)
    {
        error = EOT_writeToStream(lfFont, params, &stream);
    }
    else // (type == eLF_SVG_FONT)
    {
        size_t size = 0;
        error = SVG_writeToStream(lfFont, params, &stream, &size);
    }

    fclose(file);

    if (error != LF_ERROR_OK)
        remove(filePath);

    return error;
}

/**
Writes a sample CSS file.
@param[in] lfFont parent class
@param[in] baseName name of font to put into the CSS file
@param[in] fontTypes an array of 6 LF_FONT_TYPE's; set each element to an LF_FONT_TYPE to be be represented in the CSS file, set unsued entries to eLF_UNDETERMINED
@param[in] svgID optional svgID, can be NULL, should be set if SVG included in fontTypes
@param[in] filePath full path to output CSS file
@see LF_FONT_TYPE
@note CFF (eLF_CFF_FONT) is not considered a webfont type
*/
LF_ERROR LF_writeCSSFile(LF_FONT* lfFont, const char* baseName, LF_FONT_TYPE fontTypes[6], const char*svgID, const char* filePath)
{
    if (lfFont == NULL)
        return LF_INVALID_PARAM;
    if (baseName == NULL)
        return LF_INVALID_PARAM;
    if (filePath == NULL)
        return LF_INVALID_PARAM;

    boolean hasTTF, hasEOT, hasWOFF, hasWOFF2, hasSVG, hasOTF;
    hasTTF = hasEOT = hasWOFF = hasWOFF2 = hasSVG = hasOTF = FALSE;

    for (int i = 0; i < 6; i++)
    {
        if (fontTypes[i] == eLF_SFNT_FONT)
            hasTTF = TRUE;
        else if (fontTypes[i] == eLF_EOT_FONT)
            hasEOT = TRUE;
        else if (fontTypes[i] == eLF_WOFF_FONT)
            hasWOFF = TRUE;
        else if (fontTypes[i] == eLF_WOFF2_FONT)
            hasWOFF2 = TRUE;
        else if (fontTypes[i] == eLF_SVG_FONT)
            hasSVG = TRUE;
        else if (fontTypes[i] == eLF_CFF_FONT)
            hasOTF = TRUE;
    }

   char* justBase = (char*)baseName;

    // get Family name
    BYTE* nameStrWide;
    USHORT wideLen;

    LF_ERROR error = SFNT_getNameString(lfFont, FALSE, 1, &nameStrWide, &wideLen);
    if (error != LF_ERROR_OK)
    {
        return error;
    }

    char* familyName = (char*)calloc((wideLen >> 1) + 1, sizeof(char));
    if (familyName == NULL)
    {
        free(nameStrWide);
        return error;
    }

    BYTE* src = nameStrWide;
    char* dest = familyName;
    for (int i = 0; i < wideLen >> 1; i++)
    {
        *dest++ = *src++;
        src++;
    }
    fixupNameString(familyName);
    free(nameStrWide);

    // get SubFamily name
    error = SFNT_getNameString(lfFont, FALSE, 2, &nameStrWide, &wideLen);
    if (error != LF_ERROR_OK)
    {
        free(familyName);
        return error;
    }

    char* subFamilyName = (char*)calloc((wideLen >> 1) + 1, sizeof(char));
    if (subFamilyName == NULL)
    {
        free(familyName);
        free(nameStrWide);
        return error;
    }

    src = nameStrWide;
    dest = subFamilyName;
    for (int i = 0; i < wideLen >> 1; i++)
    {
        *dest++ = *src++;
        src++;
    }
    fixupNameString(subFamilyName);

    free(nameStrWide);

    // Get weight. see here: http://www.w3schools.com/cssref/pr_font_weight.asp
    char weight[10];
    USHORT weightClass;
    error = OS2_getWeightClass(lfFont, &weightClass);
    if (error != LF_ERROR_OK)
    {
        free(subFamilyName);
        free(familyName);
        return error;
    }

    if (weightClass == 400)
        strcpy(weight, "normal");
    else if (weightClass == 700)
        strcpy(weight, "bold");
    else
    {
        UTILS_snprintf(weight, 10, "%d", weightClass);
    }

    // get style. See here http://www.w3schools.com/cssref/pr_font_font-style.asp
    char style[10];
    USHORT fsSelection;
    error = OS2_getFsSelection(lfFont, &fsSelection);
    if (error != LF_ERROR_OK)
    {
        free(subFamilyName);
        free(familyName);
        return error;
    }

    if ((fsSelection & 0x0200) != 0) // bit 9
        strcpy(style, "oblique");
    else if ((fsSelection & 0x0001) != 0) // bit 1
        strcpy(style, "italic");
    else
        strcpy(style, "normal");

    // write file
    FILE *file = fopen(filePath, "wb");
    if (file == NULL)
    {
        free(subFamilyName);
        free(familyName);
        return LF_FILE_OPEN_WRITE;
    }

    if (strnlen(familyName,256) > 0)
    {
        fprintf(file, "@font-face {\n");
        fprintf(file, "    font-family: \'%s%s\';\n", familyName, subFamilyName);
    }
    else /* handle obfuscated fonts */
    {
        /* use postscript name as backup for family subfamily combo */
        error = SFNT_getNameString(lfFont, FALSE, 6, &nameStrWide, &wideLen);
        if (error != LF_ERROR_OK)
        {
            return error;
        }

        char* psName = (char*)calloc((wideLen >> 1) + 1, sizeof(char));
        if (psName == NULL)
        {
            free(nameStrWide);
            return error;
        }

        src = nameStrWide;
        dest = psName;
        for (int i = 0; i < wideLen >> 1; i++)
        {
            *dest++ = *src++;
            src++;
        }
        free(nameStrWide);

        fprintf(file, "@font-face {\n");
        fprintf(file, "    font-family: \'%s\';\n", psName);

        free(psName);
    }

    int numNonEot = 0;
    if (hasTTF == TRUE)
        numNonEot++;
    if (hasWOFF == TRUE)
        numNonEot++;
    if (hasWOFF2 == TRUE)
        numNonEot++;
    if (hasSVG == TRUE)
        numNonEot++;
    if (hasOTF == TRUE)
        numNonEot++;

    if (hasEOT == TRUE)
    {
        fprintf(file, "    src: url(\'%s.eot\');\n", justBase);
        fprintf(file, "    src: url(\'%s.eot?#iefix\') format('eot')%s\n", justBase, (numNonEot == 0) ? ";" : ",");
    }
    if (numNonEot != 0)
    {
        boolean first = TRUE;

        if (hasEOT == FALSE)
            fprintf(file, "    src: ");
        else
            fprintf(file, "         ");

        if (hasWOFF2 == TRUE)
        {
            numNonEot--;
            fprintf(file, "url(\'%s.woff2') format('woff2')%s\n", justBase, (numNonEot == 0) ? ";" : ",");
            first = FALSE;
        }
        if (hasWOFF == TRUE)
        {
            numNonEot--;
            if (first == FALSE)
                fprintf(file, "         ");
            fprintf(file, "url(\'%s.woff') format('woff')%s\n", justBase, (numNonEot == 0) ? ";" : ",");
            first = FALSE;
        }
        if (hasTTF == TRUE)
        {
            numNonEot--;
            if (first == FALSE)
                fprintf(file, "         ");
            fprintf(file, "url(\'%s.ttf') format(\'truetype\')%s\n", justBase, (numNonEot == 0) ? ";" : ",");
            first = FALSE;
        }
        if (hasOTF == TRUE)
        {
            numNonEot--;
            if (first == FALSE)
                fprintf(file, "         ");
            fprintf(file, "url(\'%s.otf') format(\'opentype\')%s\n", justBase, (numNonEot == 0) ? ";" : ",");
            first = FALSE;
        }
        if (hasSVG == TRUE)
        {
            char locID[65];
            memset(locID, 0, 65);

            if ((svgID != NULL) && strlen(svgID) > 0)
                strncpy(locID, svgID, 64);
            else
            {
                BYTE* fullNameStrWide;
                USHORT fullNameWideLen;
                error = SFNT_getNameString(lfFont, FALSE, 4, &fullNameStrWide, &fullNameWideLen);
                if (error != LF_ERROR_OK)
                {
                    free(familyName);
                    free(subFamilyName);
                    fclose(file);
                    return error;
                }

                char* fullName = (char*)calloc((fullNameWideLen >> 1) + 1, sizeof(char));
                if (fullName == NULL)
                {
                    free(familyName);
                    free(subFamilyName);
                    fclose(file);
                    return error;
                }

                src = fullNameStrWide;
                dest = fullName;
                for (int i = 0; i < fullNameWideLen >> 1; i++)
                {
                    *dest++ = *src++;
                    src++;
                }

                strncpy(locID, fullName, 64);
                DEBUG_LOG_WARNING("using family name for svgid");

                free(fullName);
                free(fullNameStrWide);
            }

            numNonEot--;
            if (first == FALSE)
                fprintf(file, "         ");
            fprintf(file, "url(\'%s.svg#%s\') format(\'svg\')%s\n", justBase, locID, (numNonEot == 0) ? ";" : ",");
        }
    }

    fprintf(file, "    font-weight: %s;\n", weight);
    fprintf(file, "    font-style: %s;\n", style);
    fprintf(file, "}\n");

    fclose(file);

    free(familyName);
    free(subFamilyName);

    return LF_ERROR_OK;
}

/**
Gets the data for a glyph.
@param[in] lfFont parent class
@param[in] index index of glyph to retrive
@param[out] glyphData handle to a LF_GLYPH which is created and filled in
@see LF_GLYPH, LF_freeGlyph
@note the returned glyph object must be freed with LF_freeGlyph
*/
LF_API LF_ERROR LF_getGlyph(LF_FONT* lfFont, GlyphID index, LF_GLYPH** glyphData)
{
    if ((NULL == lfFont) || (NULL == glyphData))
        return LF_INVALID_PARAM;

    return SFNT_getGlyph(lfFont, index, glyphData);
}

/**
Frees the data for a glyph.
@param[in] glyphData LF_GLYPH object to free
@see LF_GLYPH, LF_getGlyph
*/
LF_API LF_ERROR LF_freeGlyph(LF_GLYPH* glyphData)
{
    if (NULL == glyphData)
        return LF_INVALID_PARAM;

    return SFNT_freeGlyph(glyphData);
}

/**
Replaces glyph data in the font
@param[in] lfFont parent class
@param[in] index index of glyph to replace
@param[out] glyphData pointer to user-filled glyph data object
@see LF_GLYPH, LF_freeGlyph
@note The client is responsible for creating, filling, and releasing
the memory of the glyphData object. If malloc/free are used and the
client is using the same heap as LibFont, then LF_freeGlyph may be
used to free the glyph data. This function is not intended to insert
or append a glyph into a font.
*/
LF_API LF_ERROR LF_setGlyph(LF_FONT* lfFont, GlyphID index, LF_GLYPH* glyphData)
{
    if ((NULL == lfFont) || (NULL == glyphData))
        return LF_INVALID_PARAM;

    return SFNT_setGlyph(lfFont, index, glyphData);
}

/**
Update the tables in a font which may be affected by modified glyph data.
@param[in] lfFont parent class
@see LF_GLYPH, LF_setGlyph
@note This function recalculates tables which may be affected by a change
to glyph data.
*/
LF_API LF_ERROR LF_updateFont(LF_FONT* lfFont)
{
    if (NULL == lfFont)
        return LF_INVALID_PARAM;

    return SFNT_updateFont(lfFont);
}

/**
    Frees the internal data for an LF_FONT.
    @note This function does not free lfFont itself. That way it can be reused.
    Use LF_destroyFont to free the LF_FONT and its contents.
    @param[in] lfFont parent class
    @see LF_destroyFont
*/
LF_ERROR LF_freeFont(LF_FONT* lfFont)
{
    if (lfFont == NULL)
        return LF_INVALID_PARAM;

    if(lfFont->ownFontData == TRUE)
        free(lfFont->fontData);

    lfFont->fontData = NULL;
    lfFont->fontSize = 0;
    lfFont->ownFontData = FALSE;

    free(lfFont->woffInfo.metaData);
    free(lfFont->woffInfo.privateData);

    SFNT_clearSFNT(lfFont);

    lfFont->isSubsetted = FALSE;
    lfFont->isRefitted = FALSE;
    lfFont->obfuscateOnWrite = FALSE;
    lfFont->origType = eLF_UNDETERMINED;
    lfFont->origFlavor = SIG_UNKONWN;

    if(lfFont->fontType == eLF_UNDETERMINED)
        return LF_ERROR_OK;

    memset(&lfFont->woffInfo, 0, sizeof(woff_info));

    if (lfFont->fontType == eLF_SFNT_FONT || lfFont->fontType == eLF_CFF_FONT)
        return SFNT_freeFont(lfFont);

    return LF_ERROR_OK;
}

/**
    Destroys an LF_FONT data structure and frees all of its internal members.
    @note This function must be used to destroy an LF_FONT when it is no longer needed.
    @param[in] lfFont parent class
    @see LF_createFont
*/
LF_ERROR LF_destroyFont(LF_FONT* lfFont)
{
    if (lfFont == NULL)
        return LF_INVALID_PARAM;

    LF_freeFont(lfFont);

    free(lfFont);

#ifdef LF_LOGGING
    UTILS_closeLog();
#endif
#ifdef LF_OT_DUMP
    UTILS_closeXML();
#endif

    return LF_ERROR_OK;
}



// Base64 support

/**
    Calculate the maximum size needed to encode a file using Base64 encoding.
    Value will be written to *size.
    @param[in] filePath path to input file
    @param[out] size needed to encode input file
    @see LF_convertFileToBase64
*/
LF_ERROR LF_getMaxBase64SizeForFile(const char* filePath, size_t* size)
{
    FILE* fp;
    size_t fileSize;

    if(size == NULL)
        return LF_INVALID_PARAM;

    *size = 0;

    if(filePath == NULL)
        return LF_INVALID_PARAM;

    fp = fopen(filePath, "rb");
    if(fp == NULL)
        return LF_FILE_OPEN_FAIL;

    fseek(fp, 0, SEEK_END);
    fileSize = ftell(fp);
    fclose(fp);

    *size =  LF_getMaxBase64Size(fileSize);

    return LF_ERROR_OK;
}

/**
    Calculate the maximum size needed to encode a base64 stream given an original
    stream of length srcSize.
    @param[in] srcSize length of original stream
    @return size needed to encode input stream
    @see LF_convertToBase64
*/
size_t LF_getMaxBase64Size(size_t srcSize)
{
    size_t x = (size_t)(4 * ceil((double)srcSize / 3) + 1/*null char*/);

    // The libb64 implementation we use adds a newline every 72 characters, so we need to account for that.
    return (x + x / 72);
}

/**
    Save a file as Base64 encoded.
    @param[in] filePath path to input file
    @param[in] outputPath path to output file
*/
LF_ERROR LF_convertFileToBase64(const char* filePath, const char* outputPath)
{
    FILE* inFile, *outFile;
    size_t srcLen, remaining;
    const size_t readChunkSize = 65536;
    char* inBuf, *outBuf, *outBufPtr;
    int numEncoded;
    base64_encodestate encState;

    if(filePath == NULL)
        return LF_INVALID_PARAM;
    if(outputPath == NULL)
        return LF_INVALID_PARAM;

    inFile = fopen(filePath, "rb");
    if(inFile == NULL)
        return LF_FILE_OPEN_FAIL;

    outFile = fopen(outputPath, "wb");
    if(outFile == NULL)
    {
        fclose(inFile);
        return LF_FILE_OPEN_WRITE;
    }

    fseek(inFile, 0, SEEK_END);
    srcLen = ftell(inFile);
    fseek(inFile, 0, SEEK_SET);

    inBuf = (char*)malloc(readChunkSize);
    if(inBuf == NULL)
    {
        fclose(inFile);
        fclose(outFile);
        return LF_OUT_OF_MEMORY;
    }

    outBuf = (char*)malloc(srcLen * 2);
    if(outBuf == NULL)
    {
        free(inBuf);
        fclose(inFile);
        fclose(outFile);
        return LF_OUT_OF_MEMORY;
    }

    memset(&encState, 0, sizeof(base64_encodestate));
    base64_init_encodestate(&encState);

    remaining = srcLen;
    outBufPtr = outBuf;

    do
    {
        size_t numToRead, numRead;

        numToRead = (remaining >= readChunkSize) ? readChunkSize : remaining;

        numRead = fread(inBuf, 1, numToRead, inFile);
        if(numRead != numToRead)
        {
            free(inBuf);
            free(outBuf);
            fclose(inFile);
            fclose(outFile);
            return LF_BAD_FORMAT;
        }

        numEncoded = base64_encode_block((const char*)inBuf, (int)numToRead, outBufPtr, &encState);

        remaining -= numToRead;
        outBufPtr += numEncoded;
    }
    while (remaining > 0);

    fclose(inFile);

    numEncoded = base64_encode_blockend(outBufPtr, &encState);
    outBufPtr += numEncoded;

    fwrite(outBuf, 1, (outBufPtr-outBuf), outFile);
    fclose(outFile);

    free(inBuf);
    free(outBuf);

    return LF_ERROR_OK;
}

/**
    Convert a set of bytes to be Base64 encoded. The input is stored in inputBuf and the
    output is stored in outputBuf. On input *size has the available memory at outputBuf,
    on output *size is updated to the actual length.
    @param[in] inputBuf input buffer
    @param[in] srcSize size of input buffer
    @param[in] outputBuf output buffer
    @param[in] size actual size used to do Base64 encoding
    @note The output buffer must be large enough to hold the Base64 output.
    Use LF_getMaxBase64Size to determine the size.
    @see LF_getMaxBase64Size
*/
LF_ERROR LF_convertToBase64(const BYTE* inputBuf, size_t srcSize, BYTE* outputBuf, size_t* size)
{
    char* temp;
    int encodedLen, numEncoded;
    base64_encodestate encState;

    if((inputBuf == NULL) || (srcSize == 0))
        return LF_INVALID_PARAM;
    if((outputBuf == NULL) || (size == NULL) || (*size == 0))
        return LF_INVALID_PARAM;

    // This currently allocates a temp buffer into which the encoded string is written.
    // We could trust that *size is sufficient, which would speed things up, but would overwrite
    // memory if *size were too small since there are no checks for this condition in the b64 library code.

    temp = (char*)malloc(srcSize * 2 + 4);
    if(temp == NULL)
        return LF_OUT_OF_MEMORY;

    base64_init_encodestate(&encState);
    numEncoded = base64_encode_block((const char*)inputBuf, (int)srcSize, temp, &encState);

    if((size_t)numEncoded > *size)
    {
        free(temp);
        return LF_INVALID_PARAM;
    }

    encodedLen = numEncoded;
    numEncoded = base64_encode_blockend(temp+numEncoded, &encState);
    encodedLen += numEncoded;

    if((size_t)encodedLen > *size)
    {
        free(temp);
        return LF_INVALID_PARAM;
    }

    memcpy(outputBuf, temp, encodedLen);
    *size = encodedLen;

    free(temp);

    return LF_ERROR_OK;
}


/** @} */ // end of LF_FONT group

//private


// checks that the required glyph table(s) (CFF or glyf/loca) is/are present and creates it/them if not.
static LF_ERROR LF_checkGlyphTable(LF_FONT* lfFont, LF_FONT_TYPE type, const LF_WRITE_PARAMS *params)
{
    return SFNT_checkGlyphTable(lfFont, type, params);
}

static boolean LF_alwaysRetained(ULONG tag)
{
    switch(tag)
    {
        case TAG_CMAP:
        case TAG_GASP:
        case TAG_GLYF:
        case TAG_CFF:
        case TAG_HEAD:
        case TAG_HHEA:
        case TAG_HMTX:
        case TAG_LOCA:
        case TAG_MAXP:
        case TAG_OS2:
        case TAG_POST:
        case TAG_VHEA:
        case TAG_VMTX:
        case TAG_CVT:
        case TAG_FPGM:
        case TAG_PREP:
        case TAG_NAME:
            return TRUE;
        default:
            return FALSE;
    }
}

boolean LF_retainTable(ULONG tag, int flags)
{
    boolean retVal = FALSE;
    if(flags == LF_KEEP_ALL_TABLES)
    {
        retVal = TRUE;
    }
    else if (flags == LF_KEEP_ALL_EXCEPT_DSIG)
    {
        retVal = (tag == TAG_DSIG) ? FALSE : TRUE;
    }
    else if(TRUE == LF_alwaysRetained(tag))
    {
        retVal = TRUE;
    }
    else if(((tag == TAG_HDMX) || (tag == TAG_VDMX)) && ((flags & LF_KEEP_DEVICE_METRICS_TABLES) != 0))
    {
        retVal = TRUE;
    }
    else if((tag == TAG_KERN) && ((flags & LF_KEEP_KERN_TABLE) != 0))
    {
        retVal = TRUE;
    }
    else if ((tag == TAG_LTSH) && ((flags & LF_KEEP_LTSH_TABLE) != 0))
    {
        retVal = TRUE;
    }
    else if(((tag == TAG_GDEF) || (tag == TAG_GSUB) || (tag == TAG_GPOS)) && ((flags & LF_KEEP_OPENTYPE_TABLES) != 0))
    {
        retVal = TRUE;
    }
    else if (((flags & LF_KEEP_EMBEDDED_BITMAP_TABLES) != 0) && ((tag == TAG_EBLC) || (tag == TAG_EBDT) || (tag == TAG_EBSC)))
    {
        retVal = TRUE;
    }
    else if (((flags & LF_KEEP_COLOR_BITMAP_TABLES) != 0) && ((tag == TAG_CBDT) || (tag == TAG_CBLC) || (tag == TAG_SBIX) ||
                                                              (tag == TAG_COLR) || (tag == TAG_CPAL)))
    {
        retVal = TRUE;
    }
    else if (((flags & LF_KEEP_VARIATIONS_TABLES) != 0) && ((tag == TAG_FVAR) || (tag == TAG_GVAR) || (tag == TAG_AVAR) ||
                                                            (tag == TAG_CVAR) || (tag == TAG_HVAR) || (tag == TAG_MVAR) ||
                                                            (tag == TAG_VVAR) || (tag == TAG_STAT) || (tag == TAG_FMTX)))
    {
        retVal = TRUE;
    }

    //printf("%s\t%c%c%c%c\n", (retVal) ? "keeping " : "dropping", (tag>>24)&0xFF, (tag>>16)&0xff, (tag>>8)&0xff, tag&0xff);


    return retVal;
}

/* ==================================================================
    @desc:
        This is a simply method to determine whether all of the
        opentype tables have been unpacked.  it goes by a simple
        rule currently in-place that if a subset occurs, then the
        TAG_MAXP table must be stored in the lfFont->table_map.

        otherwise the font would have failed to unpack.

    @param:
        lfFont      :   pointer to the lfFont structure.

    TODO:
        if we want to expand on the unpacking method, we probably
        should do a better method for checking this, but currently
        this is only for vertical alignment and possibly hinting.

================================================================== */
boolean LF_isUnpacked(LF_FONT* lfFont)
{
    if (LF_getTable(void, lfFont, TAG_MAXP) != NULL)
        return TRUE;

    return FALSE;
}

static void fixupNameString(char *str)
{
    // make lowercase (_strlwr is not standard)
    char *p = str;

    while (*p)
    {
        *p = (char)tolower(*p);
        p++;
    }

    size_t len = strlen(str);

    // replace spaces invalid characters
    for (size_t i = 0; i < len; i++)
    {
        if (str[i] == 0x20 || str[i] < 33 || str[i] > 126)
            str[i] = '_';
    }
}
