// Copyright (C) 2016 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// ebdt_table.c

#include "ebdt_table.h"
#include "eblc_table.h"
#include "maxp_table.h"
#include "keep_table.h"
#include "table_tags.h"
#include "utils.h"

static LF_ERROR EBDT_checkSupport(boolean isColor, USHORT indexFormat, USHORT imageFormat);
static LF_ERROR EBDT_readGlyph(LF_STREAM* stream, USHORT imageFormat,ULONG offset, ULONG imageSize, bitmap_glyph** glyph);
static void EBDT_freeGlyphMap(LF_MAP* glyphMap);

LF_ERROR EBDT_readTable(LF_FONT* lfFont, const sfnt_table_record* record, LF_STREAM* stream)
{
    if (record->length == 0)
        return LF_BAD_FORMAT;

    if (STREAM_streamSeek(stream, record->offset) != 0)
        return LF_INVALID_OFFSET;

    // EBLC must have been read in
    eblc_table* eblc = (eblc_table*)map_at(&lfFont->table_map, (void*)TAG_EBLC);
    if (eblc == NULL)
        return LF_BAD_FORMAT;

    ebdt_table* table = (ebdt_table*)calloc(1, sizeof(ebdt_table));
    if (table == NULL)
        return LF_OUT_OF_MEMORY;

    LF_ERROR error = EBDT_parseTable(table, eblc, record, stream);

    if (error != LF_ERROR_OK)
    {
        return error;
    }

    map_insert(&lfFont->table_map, (void*)(intptr_t)record->tag, table);

    return LF_ERROR_OK;
}

// Parse the EBDT or CBDT table. This function will reject (LF_BAD_FORMAT) any combination of
// index format and image format that doesn't make sense. It will return LF_BAD_FORMAT for any
// image format 3 (since it is obsolete) and LF_UNSUPPORTED for any image format 4 (not supported by MSFT).
// It will return LF_UNSUPPORTED for any combination of index format and image format for which
// we have not seen or created an example.
LF_ERROR EBDT_parseTable(embedded_data_table* table, embedded_loc_table* locTable, const sfnt_table_record* record, LF_STREAM* stream)
{
    boolean isColor = (record->tag == TAG_CBLC) ? TRUE : FALSE;

    // Read the version.
    table->version = STREAM_readFixed(stream);      // version  (should be 0x00020000 for EBDT; 0x00030000 for CBDT)

    // Read the bitmap data.

    ULONG numStrikes = locTable->numSizes;

    LF_ERROR error = vector_init(&table->strikeGlyphMaps, numStrikes, 4);

    if (error != LF_ERROR_OK)
    {
        free(table);
        return error;
    }

    for (ULONG i = 0; i < numStrikes; i++)
    {
        LF_MAP* glyphMap = map_create(integer_compare);

        if (glyphMap == NULL)
        {
            EBDT_internalFree(table);
            return LF_OUT_OF_MEMORY;
        }

        bitmap_size_table* strike = (bitmap_size_table*)vector_at(&locTable->bitmapSizeTables, i);

        size_t numSubTables = vector_size(&strike->indexSubTableArray);

        for (size_t j = 0; j < numSubTables; j++)
        {
            index_subtable* subTable = (index_subtable*)vector_at(&strike->indexSubTableArray, j);

            if ((subTable->header.imageFormat == 8) || (subTable->header.imageFormat == 9))
                table->hasComponents = TRUE;

            error = EBDT_checkSupport(isColor, subTable->header.indexFormat, subTable->header.imageFormat);
            if (error != LF_ERROR_OK)
            {
                EBDT_freeGlyphMap(glyphMap);
                EBDT_internalFree(table);
                return error;
            }

            if ((1 == subTable->header.indexFormat) ||
                (2 == subTable->header.indexFormat) ||
                (3 == subTable->header.indexFormat))
            {
                bitmap_glyph* glyph = NULL;

                for (USHORT k = subTable->firstGlyphIndex; k <= subTable->lastGlyphIndex; k++)
                {
                    index_glyph_info* igi = (index_glyph_info*)map_at(&subTable->glyphMap, (void*)(intptr_t)k);
                    if (igi == NULL)
                    {
                        EBDT_freeGlyphMap(glyphMap);
                        EBDT_internalFree(table);
                        return LF_BAD_FORMAT;
                    }

                    ULONG glyphOffset = record->offset + subTable->header.imageDataOffset + igi->offset;

                    error = EBDT_readGlyph(stream, subTable->header.imageFormat, glyphOffset, igi->len, &glyph);

                    if (error == LF_ERROR_OK)
                    {
                        map_insert(glyphMap, (void*)(intptr_t)k, glyph);
                    }
                }
            }
            else if ((4 == subTable->header.indexFormat) ||
                     (5 == subTable->header.indexFormat))
            {
                LF_MAP_ITER* mapIter = map_begin(&subTable->glyphMap);
                if (mapIter != NULL)
                {
                    rb_tree_node* node = map_next(mapIter);

                    while (node && (error == LF_ERROR_OK))
                    {
                        bitmap_glyph* glyph = NULL;

                        GlyphID gid = (GlyphID)(intptr_t)node->key;
                        index_glyph_info* igi = node->data;

                        ULONG glyphOffset = record->offset + subTable->header.imageDataOffset + igi->offset;

                        error = EBDT_readGlyph(stream, subTable->header.imageFormat, glyphOffset, igi->len, &glyph);

                        if (error == LF_ERROR_OK)
                        {
                            map_insert(glyphMap, (void*)(intptr_t)gid, glyph);
                        }

                        node = map_next(mapIter);
                    }

                    map_free_iter(mapIter);
                }
                else
                {
                    error = LF_OUT_OF_MEMORY;
                }
            }
            else
                error = LF_BAD_FORMAT;

            if (error != LF_ERROR_OK)
            {
                EBDT_freeGlyphMap(glyphMap);
                EBDT_internalFree(table);
                return error;
            }
        }

        error = vector_push_back(&table->strikeGlyphMaps, glyphMap);
        if (error != LF_ERROR_OK)
        {
            EBDT_freeGlyphMap(glyphMap);
            EBDT_internalFree(table);
            return error;
        }
    }

    return LF_ERROR_OK;
}

static LF_ERROR EBDT_checkSupport(boolean isColor, USHORT indexFormat, USHORT imageFormat)
{
    if (3 == imageFormat)
        return LF_BAD_FORMAT;   // Format 3 is obsolete
    if (4 == imageFormat)
        return LF_UNSUPPORTED;  // Format 4 is not supported by MSFT, so we don't support it
    if (((19 == imageFormat) || (5 == imageFormat)) && ((1 == indexFormat) || (3 == indexFormat) || (4 == indexFormat)))
        return LF_BAD_FORMAT;   // These are not compatible
    if (isColor && (imageFormat < 17))
        return LF_UNSUPPORTED;  // While technically allowed, we haven't seen any CBDT tables with binary data so we don't support it.

    // Below are not supported since we do not have an example for testing purposees.
    if ((1 == indexFormat) && ((1 == imageFormat) || (2 == imageFormat) || (8 == imageFormat) || (9 == imageFormat) || (18 == imageFormat)))
        return LF_UNSUPPORTED;
    if ((2 == indexFormat) && (isColor || (1 == imageFormat) || (2 == imageFormat) || (6 == imageFormat) || (7 == imageFormat)))
        return LF_UNSUPPORTED;
    if ((3 == indexFormat) && ((6 == imageFormat) || (7 == imageFormat) || (8 == imageFormat) || (9 == imageFormat)))
        return LF_UNSUPPORTED;
    if ((4 == indexFormat) && (isColor || (2 == imageFormat) || (7 == imageFormat) || (8 == imageFormat) || (9 == imageFormat)))
        return LF_UNSUPPORTED;
    if ((5 == indexFormat) && (isColor || (1 == imageFormat) || (2 == imageFormat) || (6 == imageFormat) || (8 == imageFormat) || (9 == imageFormat)))
        return LF_UNSUPPORTED;

    return LF_ERROR_OK;
}

static LF_ERROR EBDT_readGlyph(LF_STREAM* stream, USHORT imageFormat,
                               ULONG offset, ULONG imageSize, bitmap_glyph** glyph)
{
    if (0 != STREAM_streamSeek(stream, offset))
        return LF_INVALID_OFFSET;

    *glyph = (bitmap_glyph*)calloc(1, sizeof(bitmap_glyph));
    if (*glyph == NULL)
        return LF_OUT_OF_MEMORY;

    LF_ERROR error = LF_ERROR_OK;

    bitmap_glyph* g = *glyph;

    g->format = imageFormat;

    if (17 == imageFormat)
    {
        g->glyph.fmt17.glyphMetrics.height = STREAM_readByte(stream);
        g->glyph.fmt17.glyphMetrics.width = STREAM_readByte(stream);
        g->glyph.fmt17.glyphMetrics.BearingX = STREAM_readByte(stream);
        g->glyph.fmt17.glyphMetrics.BearingY = STREAM_readByte(stream);
        g->glyph.fmt17.glyphMetrics.Advance = STREAM_readByte(stream);
        g->glyph.fmt17.dataLen = STREAM_readULong(stream);
        g->glyph.fmt17.data = STREAM_readChunk(stream, g->glyph.fmt17.dataLen);
        if (g->glyph.fmt17.data == NULL)
            error = LF_OUT_OF_MEMORY;
    }
    else if (18 == imageFormat)
    {
        g->glyph.fmt18.glyphMetrics.height = STREAM_readByte(stream);
        g->glyph.fmt18.glyphMetrics.width = STREAM_readByte(stream);
        g->glyph.fmt18.glyphMetrics.horiBearingX = STREAM_readByte(stream);
        g->glyph.fmt18.glyphMetrics.horiBearingY = STREAM_readByte(stream);
        g->glyph.fmt18.glyphMetrics.horiAdvance = STREAM_readByte(stream);
        g->glyph.fmt18.glyphMetrics.vertBearingX = STREAM_readByte(stream);
        g->glyph.fmt18.glyphMetrics.vertBearingY = STREAM_readByte(stream);
        g->glyph.fmt18.glyphMetrics.vertAdvance = STREAM_readByte(stream);
        g->glyph.fmt18.dataLen = STREAM_readULong(stream);
        g->glyph.fmt18.data = STREAM_readChunk(stream, g->glyph.fmt18.dataLen);
        if (g->glyph.fmt18.data == NULL)
            error = LF_OUT_OF_MEMORY;
    }
    else if (19 == imageFormat)
    {
        g->glyph.fmt19.dataLen = STREAM_readULong(stream);
        g->glyph.fmt19.data = STREAM_readChunk(stream, g->glyph.fmt19.dataLen);
        if (g->glyph.fmt19.data == NULL)
            error = LF_OUT_OF_MEMORY;
    }
    else if (1 == imageFormat)
    {
        g->glyph.fmt1.smallMetrics.height = STREAM_readByte(stream);
        g->glyph.fmt1.smallMetrics.width = STREAM_readByte(stream);
        g->glyph.fmt1.smallMetrics.BearingX = STREAM_readByte(stream);
        g->glyph.fmt1.smallMetrics.BearingY = STREAM_readByte(stream);
        g->glyph.fmt1.smallMetrics.Advance = STREAM_readByte(stream);

        if (imageSize > (5 * sizeof(BYTE)))
        {
            g->glyph.fmt1.dataSize = imageSize - (5 * sizeof(BYTE));
            g->glyph.fmt1.data = STREAM_readChunk(stream, g->glyph.fmt1.dataSize);

            if (g->glyph.fmt1.data == NULL)
                error = LF_OUT_OF_MEMORY;
        }
    }
    else if (2 == imageFormat)
    {
        g->glyph.fmt2.smallMetrics.height = STREAM_readByte(stream);
        g->glyph.fmt2.smallMetrics.width = STREAM_readByte(stream);
        g->glyph.fmt2.smallMetrics.BearingX = STREAM_readByte(stream);
        g->glyph.fmt2.smallMetrics.BearingY = STREAM_readByte(stream);
        g->glyph.fmt2.smallMetrics.Advance = STREAM_readByte(stream);

        if (imageSize > (5 * sizeof(BYTE)))
        {
            g->glyph.fmt2.dataSize = imageSize - (5 * sizeof(BYTE));
            g->glyph.fmt2.data = STREAM_readChunk(stream, g->glyph.fmt2.dataSize);

            if (g->glyph.fmt2.data == NULL)
                error = LF_OUT_OF_MEMORY;
        }
    }
    else if (5 == imageFormat)
    {
        if (imageSize != 0)
        {
            g->glyph.fmt5.dataSize = imageSize;
            g->glyph.fmt5.data = STREAM_readChunk(stream, g->glyph.fmt5.dataSize);

            if (g->glyph.fmt5.data == NULL)
                error = LF_OUT_OF_MEMORY;
        }
    }
    else if (6 == imageFormat)
    {
        g->glyph.fmt6.bigMetrics.height = STREAM_readByte(stream);
        g->glyph.fmt6.bigMetrics.width = STREAM_readByte(stream);
        g->glyph.fmt6.bigMetrics.horiBearingX = STREAM_readByte(stream);
        g->glyph.fmt6.bigMetrics.horiBearingY = STREAM_readByte(stream);
        g->glyph.fmt6.bigMetrics.horiAdvance = STREAM_readByte(stream);
        g->glyph.fmt6.bigMetrics.vertBearingX = STREAM_readByte(stream);
        g->glyph.fmt6.bigMetrics.vertBearingY = STREAM_readByte(stream);
        g->glyph.fmt6.bigMetrics.vertAdvance = STREAM_readByte(stream);

        if (imageSize > (8 * sizeof(BYTE)))
        {
            g->glyph.fmt6.dataSize = imageSize - (8 * sizeof(BYTE));
            g->glyph.fmt6.data = STREAM_readChunk(stream, g->glyph.fmt6.dataSize);

            if (g->glyph.fmt6.data == NULL)
                error = LF_OUT_OF_MEMORY;
        }
    }
    else if (7 == imageFormat)
    {
        g->glyph.fmt7.bigMetrics.height = STREAM_readByte(stream);
        g->glyph.fmt7.bigMetrics.width = STREAM_readByte(stream);
        g->glyph.fmt7.bigMetrics.horiBearingX = STREAM_readByte(stream);
        g->glyph.fmt7.bigMetrics.horiBearingY = STREAM_readByte(stream);
        g->glyph.fmt7.bigMetrics.horiAdvance = STREAM_readByte(stream);
        g->glyph.fmt7.bigMetrics.vertBearingX = STREAM_readByte(stream);
        g->glyph.fmt7.bigMetrics.vertBearingY = STREAM_readByte(stream);
        g->glyph.fmt7.bigMetrics.vertAdvance = STREAM_readByte(stream);

        if (imageSize > (8 * sizeof(BYTE)))
        {
            g->glyph.fmt7.dataSize = imageSize - (8 * sizeof(BYTE));
            g->glyph.fmt7.data = STREAM_readChunk(stream, g->glyph.fmt7.dataSize);

            if (g->glyph.fmt7.data == NULL)
                error = LF_OUT_OF_MEMORY;
        }
    }
    else if (8 == imageFormat)
    {
        g->glyph.fmt8.smallMetrics.height = STREAM_readByte(stream);
        g->glyph.fmt8.smallMetrics.width = STREAM_readByte(stream);
        g->glyph.fmt8.smallMetrics.BearingX = STREAM_readByte(stream);
        g->glyph.fmt8.smallMetrics.BearingY = STREAM_readByte(stream);
        g->glyph.fmt8.smallMetrics.Advance = STREAM_readByte(stream);
        g->glyph.fmt8.pad = STREAM_readByte(stream);
        g->glyph.fmt8.numComponents = STREAM_readUShort(stream);

        error = vector_init(&g->glyph.fmt8.compArray, g->glyph.fmt8.numComponents, 4);

        if (error == LF_ERROR_OK)
        {
            for (USHORT i = 0; (i < g->glyph.fmt8.numComponents) && (error == LF_ERROR_OK); i++)
            {
                ebdt_component* comp = (ebdt_component*)calloc(1, sizeof(ebdt_component));

                if (comp != NULL)
                {
                    comp->glyphCode = STREAM_readUShort(stream);
                    comp->xOffset = STREAM_readByte(stream);
                    comp->yOffset = STREAM_readByte(stream);

                    error = vector_push_back(&g->glyph.fmt8.compArray, comp);
                }
                else
                {
                    for (size_t j = 0; j < vector_size(&g->glyph.fmt8.compArray); j++)
                        free(vector_at(&g->glyph.fmt8.compArray, j));
                    vector_free(&g->glyph.fmt8.compArray);
                    error = LF_OUT_OF_MEMORY;
                }
            }
        }
    }
    else if (9 == imageFormat)
    {
        g->glyph.fmt9.bigMetrics.height = STREAM_readByte(stream);
        g->glyph.fmt9.bigMetrics.width = STREAM_readByte(stream);
        g->glyph.fmt9.bigMetrics.horiBearingX = STREAM_readByte(stream);
        g->glyph.fmt9.bigMetrics.horiBearingY = STREAM_readByte(stream);
        g->glyph.fmt9.bigMetrics.horiAdvance = STREAM_readByte(stream);
        g->glyph.fmt9.bigMetrics.vertBearingX = STREAM_readByte(stream);
        g->glyph.fmt9.bigMetrics.vertBearingY = STREAM_readByte(stream);
        g->glyph.fmt9.bigMetrics.vertAdvance = STREAM_readByte(stream);

        g->glyph.fmt9.numComponents = STREAM_readUShort(stream);

        error = vector_init(&g->glyph.fmt9.compArray, g->glyph.fmt9.numComponents, 4);

        if (error == LF_ERROR_OK)
        {
            for (USHORT i = 0; (i < g->glyph.fmt9.numComponents) && (error == LF_ERROR_OK); i++)
            {
                ebdt_component* comp = (ebdt_component*)calloc(1, sizeof(ebdt_component));

                if (comp != NULL)
                {
                    comp->glyphCode = STREAM_readUShort(stream);
                    comp->xOffset = STREAM_readByte(stream);
                    comp->yOffset = STREAM_readByte(stream);

                    error = vector_push_back(&g->glyph.fmt9.compArray, comp);
                }
                else
                {
                    for (size_t j = 0; j < vector_size(&g->glyph.fmt9.compArray); j++)
                        free(vector_at(&g->glyph.fmt9.compArray, j));
                    vector_free(&g->glyph.fmt9.compArray);
                    error = LF_OUT_OF_MEMORY;
                }
            }
        }
    }
    else
        error = LF_UNSUPPORTED;

    if (error != LF_ERROR_OK)
    {
        free(*glyph);
        *glyph = NULL;
    }

    return error;
}

void EBDT_freeGlyph(bitmap_glyph* glyph)
{
    if (17 == glyph->format)
    {
        free(glyph->glyph.fmt17.data);
    }
    else if (18 == glyph->format)
    {
        free(glyph->glyph.fmt18.data);
    }
    else if (19 == glyph->format)
    {
        free(glyph->glyph.fmt19.data);
    }
    else if (1 == glyph->format)
    {
        free(glyph->glyph.fmt1.data);
    }
    else if (2 == glyph->format)
    {
        free(glyph->glyph.fmt2.data);
    }
    else if (5 == glyph->format)
    {
        free(glyph->glyph.fmt5.data);
    }
    else if (6 == glyph->format)
    {
        free(glyph->glyph.fmt6.data);
    }
    else if (7 == glyph->format)
    {
        free(glyph->glyph.fmt7.data);
    }
    else if (8 == glyph->format)
    {
        for (size_t i = 0; i < glyph->glyph.fmt8.compArray.count; i++)
            free(vector_at(&glyph->glyph.fmt8.compArray, i));
        vector_free(&glyph->glyph.fmt8.compArray);
    }
    else if (9 == glyph->format)
    {
        for (size_t i = 0; i < glyph->glyph.fmt9.compArray.count; i++)
            free(vector_at(&glyph->glyph.fmt9.compArray, i));
        vector_free(&glyph->glyph.fmt9.compArray);
    }

    free(glyph);
}

LF_ERROR EBDT_keepGlyphs(const LF_FONT* lfFont, GlyphList* keepList)
{
    ebdt_table* table = (ebdt_table*)map_at(&lfFont->table_map, (void*)TAG_EBDT);

    if (table->hasComponents == FALSE)
        return LF_ERROR_OK;

    ULONG numKeepGlyphs;
    GlyphID* glyphList = Keep_getSortedGlyphIDList(keepList, &numKeepGlyphs);
    if (glyphList == NULL)
        return LF_OUT_OF_MEMORY;

    // Loop over strikes
    size_t numStrikes = vector_size(&table->strikeGlyphMaps);

    for (size_t i = 0; i < numStrikes; i++)
    {
        LF_MAP* glyphMap = (LF_MAP*)vector_at(&table->strikeGlyphMaps, i);

        if (map_empty(glyphMap))
            continue;

        GlyphID *gidPtr = glyphList;

        // loop over kept glyphs
        for (ULONG j = 0; j < numKeepGlyphs; j++, gidPtr++)
        {
            bitmap_glyph* glyph = (bitmap_glyph*)map_at(glyphMap, (void*)(intptr_t)(*gidPtr));

            if ((glyph != NULL) && ((9 == glyph->format) || (8 == glyph->format)))
            {
                // Add components of glyphs to keep list
                size_t numComps;
                
                if (9 == glyph->format)
                    numComps = vector_size(&glyph->glyph.fmt9.compArray);
                else
                    numComps = vector_size(&glyph->glyph.fmt8.compArray);

                for (size_t k = 0; k < numComps; k++)
                {
                    ebdt_component* comp;

                    if (9 == glyph->format)
                        comp = (ebdt_component*)vector_at(&glyph->glyph.fmt9.compArray, k);
                    else
                        comp = (ebdt_component*)vector_at(&glyph->glyph.fmt8.compArray, k);

                    LF_ERROR status = Keep_addGlyph(keepList, comp->glyphCode);
                    if ((status != LF_ADDED_GLYPH) && (status != LF_ERROR_OK))
                    {
                        free(glyphList);
                        return status;
                    }

                    bitmap_glyph* compGlyph = (bitmap_glyph*)map_at(glyphMap, (void*)(intptr_t)comp->glyphCode);
                    if ((9 == compGlyph->format) || (8 == compGlyph->format))
                    {
                        free(glyphList);
                        return LF_UNSUPPORTED;  // recursive components not supported yet
                    }
                }
            }
        }
    }

    free(glyphList);

    return LF_ERROR_OK;
}

LF_ERROR EBDT_internalRemoveGlyph(embedded_data_table* table, ULONG index)
{
    if (table == NULL)
        return LF_TABLE_MISSING;

    size_t numStrikes = vector_size(&table->strikeGlyphMaps);

    for (size_t i = 0; i < numStrikes; i++)
    {
        LF_MAP* glyphMap = (LF_MAP*)vector_at(&table->strikeGlyphMaps, i);

        bitmap_glyph* glyph = map_at(glyphMap, (void*)(intptr_t)index);

        if (glyph != NULL)
        {
            EBDT_freeGlyph(glyph);
            map_erase(glyphMap, (void*)(intptr_t)index);
        }
    }

    return LF_ERROR_OK;
}

LF_ERROR EBDT_removeGlyph(LF_FONT* lfFont, ULONG index)
{
    ebdt_table* table = (ebdt_table*)map_at(&lfFont->table_map, (void*)TAG_EBDT);

    return EBDT_internalRemoveGlyph(table, index);
}

LF_ERROR EBDT_internalIsTableEmpty(embedded_data_table* table)
{
    if (table == NULL)
        return LF_TABLE_MISSING;

    size_t numStrikes = vector_size(&table->strikeGlyphMaps);

    for (size_t i = 0; i < numStrikes; i++)
    {
        LF_MAP* glyphMap = (LF_MAP*)vector_at(&table->strikeGlyphMaps, i);

        if (0 != map_size(glyphMap))
            return LF_ERROR_OK;
    }

    return LF_EMPTY_TABLE;
}

LF_ERROR EBDT_isTableEmpty(LF_FONT* lfFont)
{
    ebdt_table* table = (ebdt_table*)map_at(&lfFont->table_map, (void*)TAG_EBDT);

    return EBDT_internalIsTableEmpty(table);
}

LF_ERROR EBDT_internalRemap(LF_FONT* lfFont, embedded_data_table* table, LF_MAP *remap)
{
    if (table != NULL)
    {
        USHORT numOrigGlyphs = MAXP_getNumGlyphs(lfFont);
        USHORT numRemaining = (USHORT)map_size(remap);

        size_t numStrikes = vector_size(&table->strikeGlyphMaps);

        for (size_t i = 0; i < numStrikes; i++)
        {
            LF_MAP* glyphMap = (LF_MAP*)vector_at(&table->strikeGlyphMaps, i);

            LF_MAP_ITER* mapIter = map_begin(glyphMap);
            if (mapIter != NULL)
            {
                rb_tree_node* node = map_next(mapIter);

                while (node)
                {
                    node->key = map_at(remap, node->key);
                    node = map_next(mapIter);
                }
            }
            else
            {
                return LF_OUT_OF_MEMORY;
            }

            map_free_iter(mapIter);
        }

        // Remap components
        if (TRUE == table->hasComponents)
        {
            for (size_t i = 0; i < numStrikes; i++)
            {
                LF_MAP* glyphMap = (LF_MAP*)vector_at(&table->strikeGlyphMaps, i);

                LF_MAP_ITER* mapIter = map_begin(glyphMap);
                if (mapIter != NULL)
                {
                    rb_tree_node* node = map_next(mapIter);

                    while (node)
                    {
                        bitmap_glyph* glyph = (bitmap_glyph*)node->data;

                        if ((9 == glyph->format) || (8 == glyph->format))
                        {
                            size_t numComps;

                            if (9 == glyph->format)
                                numComps = vector_size(&glyph->glyph.fmt9.compArray);
                            else
                                numComps = vector_size(&glyph->glyph.fmt8.compArray);

                            for (size_t j = 0; j < numComps; j++)
                            {
                                ebdt_component* comp;

                                if (9 == glyph->format)
                                    comp = (ebdt_component*)vector_at(&glyph->glyph.fmt9.compArray, j);
                                else
                                    comp = (ebdt_component*)vector_at(&glyph->glyph.fmt8.compArray, j);

                                if (comp->glyphCode >= numOrigGlyphs)
                                {
                                    comp->glyphCode = numRemaining + (comp->glyphCode - numOrigGlyphs);
                                }
                                else
                                {
                                    comp->glyphCode = (USHORT)(intptr_t)map_at(remap, (void*)(intptr_t)comp->glyphCode);
                                }
                            }
                        }

                        node = map_next(mapIter);
                    }
                }
                else
                {
                    return LF_OUT_OF_MEMORY;
                }

                map_free_iter(mapIter);
            }
        }
    }

    return LF_ERROR_OK;
}

LF_ERROR EBDT_remapTable(LF_FONT* lfFont, LF_MAP *remap)
{
    ebdt_table* table = (ebdt_table*)map_at(&lfFont->table_map, (void*)TAG_EBDT);

    return EBDT_internalRemap(lfFont, table, remap);
}

LF_ERROR EBDT_internalCount(embedded_data_table* table, USHORT* numGlyphs)
{
    *numGlyphs = 0;
    if (table == NULL)
        return LF_EMPTY_TABLE;

    size_t numStrikes = vector_size(&table->strikeGlyphMaps);

    if (numStrikes != 0)
    {
        // Assuming that all strikes have the same number of glyphs
        LF_MAP* glyphMap = (LF_MAP*)vector_at(&table->strikeGlyphMaps, 0);

        *numGlyphs = (USHORT)map_size(glyphMap);
    }

    return LF_ERROR_OK;
}

LF_ERROR EBDT_getCount(LF_FONT* lfFont, USHORT* numGlyphs)
{
    ebdt_table* table = (ebdt_table*)map_at(&lfFont->table_map, (void*)TAG_EBDT);

    return EBDT_internalCount(table, numGlyphs);
}

LF_ERROR EBDT_internalGetSize(embedded_data_table* table, size_t* tableSize)
{
    *tableSize = 0;

    if (table == NULL)
        return LF_EMPTY_TABLE;

    *tableSize += sizeof(FIXED);        // version

    size_t numStrikes = vector_size(&table->strikeGlyphMaps);

    for (size_t i = 0; i < numStrikes; i++)
    {
        LF_MAP* glyphMap = (LF_MAP*)vector_at(&table->strikeGlyphMaps, i);

        LF_MAP_ITER* mapIter = map_begin(glyphMap);
        if (mapIter != NULL)
        {
            rb_tree_node* node = map_next(mapIter);

            while (node)
            {
                bitmap_glyph* glyph = (bitmap_glyph*)node->data;

                switch (glyph->format)
                {
                case 1:
                    *tableSize += sizeofSmallGMs;
                    *tableSize += glyph->glyph.fmt1.dataSize;
                    break;
                case 2:
                    *tableSize += sizeofSmallGMs;
                    *tableSize += glyph->glyph.fmt2.dataSize;
                    break;
                case 5:
                    *tableSize += glyph->glyph.fmt5.dataSize;
                    break;
                case 6:
                    *tableSize += sizeofBigGMs;
                    *tableSize += glyph->glyph.fmt6.dataSize;
                    break;
                case 7:
                    *tableSize += sizeofBigGMs;
                    *tableSize += glyph->glyph.fmt7.dataSize;
                    break;
                case 8:
                    *tableSize += sizeofSmallGMs;
                    *tableSize += sizeof(BYTE);     // pad
                    *tableSize += sizeof(USHORT);   // num components
                    *tableSize += glyph->glyph.fmt8.numComponents * sizeofEbdtComponent; // components
                    break;
                case 9:
                    *tableSize += sizeofBigGMs;
                    *tableSize += sizeof(USHORT);   // num components
                    *tableSize += glyph->glyph.fmt9.numComponents * sizeofEbdtComponent; // components
                    break;
                case 17:
                    *tableSize += sizeofSmallGMs;
                    *tableSize += sizeof(ULONG);    // data length
                    *tableSize += glyph->glyph.fmt17.dataLen;   // raw PNG data
                    break;
                case 18:
                    *tableSize += sizeofBigGMs;
                    *tableSize += sizeof(ULONG);    // data length
                    *tableSize += glyph->glyph.fmt18.dataLen;   // raw PNG data
                    break;
                case 19:
                    *tableSize += sizeof(ULONG);    // data length
                    *tableSize += glyph->glyph.fmt19.dataLen;   // raw PNG data
                    break;
                default:
                    map_free_iter(mapIter);
                    return LF_BAD_FORMAT;
                }

                node = map_next(mapIter);
            }
        }
        else
        {
            return LF_OUT_OF_MEMORY;
        }

        map_free_iter(mapIter);
    }

    return LF_ERROR_OK;
}

LF_ERROR EBDT_getTableSize(LF_FONT* lfFont, size_t* tableSize)
{
    ebdt_table* table = (ebdt_table*)map_at(&lfFont->table_map, (void*)TAG_EBDT);

    return EBDT_internalGetSize(table, tableSize);
}

LF_ERROR EBDT_buildTable(embedded_data_table* table, ULONG version, BYTE** tableData, size_t* tableSize)
{
    *tableData = NULL;
    *tableSize = 0;

    LF_ERROR error = EBDT_internalGetSize(table, tableSize);
    if (error != LF_ERROR_OK)
        return error;

    size_t paddedSize = *tableSize;
    *tableData = UTILS_AllocTable(&paddedSize);

    if (*tableData == NULL)
    {
        DEBUG_LOG_ERROR("allocation failure in EBDT_buildTable");
        return LF_OUT_OF_MEMORY;
    }

    LF_STREAM stream;
    STREAM_initMemStream(&stream, *tableData, *tableSize);

    STREAM_writeFixed(&stream, version); // Version

    size_t numStrikes = vector_size(&table->strikeGlyphMaps);

    for (size_t i = 0; i < numStrikes; i++)
    {
        LF_MAP* glyphMap = (LF_MAP*)vector_at(&table->strikeGlyphMaps, i);

        LF_MAP_ITER* mapIter = map_begin(glyphMap);
        if (mapIter != NULL)
        {
            rb_tree_node* node = map_next(mapIter);

            while (node)
            {
                bitmap_glyph* glyph = (bitmap_glyph*)node->data;

                switch (glyph->format)
                {
                case 17:
                    STREAM_writeByte(&stream, glyph->glyph.fmt17.glyphMetrics.height);
                    STREAM_writeByte(&stream, glyph->glyph.fmt17.glyphMetrics.width);
                    STREAM_writeByte(&stream, glyph->glyph.fmt17.glyphMetrics.BearingX);
                    STREAM_writeByte(&stream, glyph->glyph.fmt17.glyphMetrics.BearingY);
                    STREAM_writeByte(&stream, glyph->glyph.fmt17.glyphMetrics.Advance);
                    STREAM_writeULong(&stream, glyph->glyph.fmt17.dataLen);
                    STREAM_writeChunk(&stream, glyph->glyph.fmt17.data, glyph->glyph.fmt17.dataLen);
                    break;
                case 18:
                    STREAM_writeByte(&stream, glyph->glyph.fmt18.glyphMetrics.height);
                    STREAM_writeByte(&stream, glyph->glyph.fmt18.glyphMetrics.width);
                    STREAM_writeByte(&stream, glyph->glyph.fmt18.glyphMetrics.horiBearingX);
                    STREAM_writeByte(&stream, glyph->glyph.fmt18.glyphMetrics.horiBearingY);
                    STREAM_writeByte(&stream, glyph->glyph.fmt18.glyphMetrics.horiAdvance);
                    STREAM_writeByte(&stream, glyph->glyph.fmt18.glyphMetrics.vertBearingX);
                    STREAM_writeByte(&stream, glyph->glyph.fmt18.glyphMetrics.vertBearingY);
                    STREAM_writeByte(&stream, glyph->glyph.fmt18.glyphMetrics.vertAdvance);
                    STREAM_writeULong(&stream, glyph->glyph.fmt18.dataLen);
                    STREAM_writeChunk(&stream, glyph->glyph.fmt18.data, glyph->glyph.fmt18.dataLen);
                    break;
                case 19:
                    STREAM_writeULong(&stream, glyph->glyph.fmt19.dataLen);
                    STREAM_writeChunk(&stream, glyph->glyph.fmt19.data, glyph->glyph.fmt19.dataLen);
                    break;
                case 1:
                    STREAM_writeByte(&stream, glyph->glyph.fmt1.smallMetrics.height);
                    STREAM_writeByte(&stream, glyph->glyph.fmt1.smallMetrics.width);
                    STREAM_writeByte(&stream, glyph->glyph.fmt1.smallMetrics.BearingX);
                    STREAM_writeByte(&stream, glyph->glyph.fmt1.smallMetrics.BearingY);
                    STREAM_writeByte(&stream, glyph->glyph.fmt1.smallMetrics.Advance);
                    STREAM_writeChunk(&stream, glyph->glyph.fmt1.data, glyph->glyph.fmt1.dataSize);
                    break;
                case 2:
                    STREAM_writeByte(&stream, glyph->glyph.fmt2.smallMetrics.height);
                    STREAM_writeByte(&stream, glyph->glyph.fmt2.smallMetrics.width);
                    STREAM_writeByte(&stream, glyph->glyph.fmt2.smallMetrics.BearingX);
                    STREAM_writeByte(&stream, glyph->glyph.fmt2.smallMetrics.BearingY);
                    STREAM_writeByte(&stream, glyph->glyph.fmt2.smallMetrics.Advance);
                    STREAM_writeChunk(&stream, glyph->glyph.fmt2.data, glyph->glyph.fmt2.dataSize);
                    break;
                case 5:
                    STREAM_writeChunk(&stream, glyph->glyph.fmt5.data, glyph->glyph.fmt5.dataSize);
                    break;
                case 6:
                    STREAM_writeByte(&stream, glyph->glyph.fmt6.bigMetrics.height);
                    STREAM_writeByte(&stream, glyph->glyph.fmt6.bigMetrics.width);
                    STREAM_writeByte(&stream, glyph->glyph.fmt6.bigMetrics.horiBearingX);
                    STREAM_writeByte(&stream, glyph->glyph.fmt6.bigMetrics.horiBearingY);
                    STREAM_writeByte(&stream, glyph->glyph.fmt6.bigMetrics.horiAdvance);
                    STREAM_writeByte(&stream, glyph->glyph.fmt6.bigMetrics.vertBearingX);
                    STREAM_writeByte(&stream, glyph->glyph.fmt6.bigMetrics.vertBearingY);
                    STREAM_writeByte(&stream, glyph->glyph.fmt6.bigMetrics.vertAdvance);
                    STREAM_writeChunk(&stream, glyph->glyph.fmt6.data, glyph->glyph.fmt6.dataSize);
                    break;
                case 7:
                    STREAM_writeByte(&stream, glyph->glyph.fmt7.bigMetrics.height);
                    STREAM_writeByte(&stream, glyph->glyph.fmt7.bigMetrics.width);
                    STREAM_writeByte(&stream, glyph->glyph.fmt7.bigMetrics.horiBearingX);
                    STREAM_writeByte(&stream, glyph->glyph.fmt7.bigMetrics.horiBearingY);
                    STREAM_writeByte(&stream, glyph->glyph.fmt7.bigMetrics.horiAdvance);
                    STREAM_writeByte(&stream, glyph->glyph.fmt7.bigMetrics.vertBearingX);
                    STREAM_writeByte(&stream, glyph->glyph.fmt7.bigMetrics.vertBearingY);
                    STREAM_writeByte(&stream, glyph->glyph.fmt7.bigMetrics.vertAdvance);
                    STREAM_writeChunk(&stream, glyph->glyph.fmt7.data, glyph->glyph.fmt7.dataSize);
                    break;
                case 8:
                    STREAM_writeByte(&stream, glyph->glyph.fmt8.smallMetrics.height);
                    STREAM_writeByte(&stream, glyph->glyph.fmt8.smallMetrics.width);
                    STREAM_writeByte(&stream, glyph->glyph.fmt8.smallMetrics.BearingX);
                    STREAM_writeByte(&stream, glyph->glyph.fmt8.smallMetrics.BearingY);
                    STREAM_writeByte(&stream, glyph->glyph.fmt8.smallMetrics.Advance);
                    STREAM_writeByte(&stream, 0x00);    // pad
                    STREAM_writeUShort(&stream, glyph->glyph.fmt8.numComponents);  // num comp

                    for (size_t j = 0; j < vector_size(&glyph->glyph.fmt8.compArray); j++)
                    {
                        ebdt_component* comp = (ebdt_component*)vector_at(&glyph->glyph.fmt8.compArray, j);
                        STREAM_writeUShort(&stream, comp->glyphCode);
                        STREAM_writeByte(&stream, comp->xOffset);
                        STREAM_writeByte(&stream, comp->yOffset);
                    }
                    break;
                case 9:
                    STREAM_writeByte(&stream, glyph->glyph.fmt9.bigMetrics.height);
                    STREAM_writeByte(&stream, glyph->glyph.fmt9.bigMetrics.width);
                    STREAM_writeByte(&stream, glyph->glyph.fmt9.bigMetrics.horiBearingX);
                    STREAM_writeByte(&stream, glyph->glyph.fmt9.bigMetrics.horiBearingY);
                    STREAM_writeByte(&stream, glyph->glyph.fmt9.bigMetrics.horiAdvance);
                    STREAM_writeByte(&stream, glyph->glyph.fmt9.bigMetrics.vertBearingX);
                    STREAM_writeByte(&stream, glyph->glyph.fmt9.bigMetrics.vertBearingY);
                    STREAM_writeByte(&stream, glyph->glyph.fmt9.bigMetrics.vertAdvance);
                    STREAM_writeUShort(&stream, glyph->glyph.fmt9.numComponents);  // num comp
                    for (size_t j = 0; j < vector_size(&glyph->glyph.fmt9.compArray); j++)
                    {
                        ebdt_component* comp = (ebdt_component*)vector_at(&glyph->glyph.fmt9.compArray, j);
                        STREAM_writeUShort(&stream, comp->glyphCode);
                        STREAM_writeByte(&stream, comp->xOffset);
                        STREAM_writeByte(&stream, comp->yOffset);
                    }
                    break;
                default:
                    error = LF_BAD_FORMAT;
                    break;
                }

                if (error != LF_ERROR_OK)
                {
                    map_free_iter(mapIter);
                    free(*tableData);
                    return error;
                }

                node = map_next(mapIter);
            }

            map_free_iter(mapIter);
        }
        else
        {
            free(*tableData);
            return LF_OUT_OF_MEMORY;
        }
    }

    return LF_ERROR_OK;
}

LF_ERROR EBDT_writeTable(LF_FONT* lfFont, sfnt_table_record* record, LF_STREAM* stream)
{
    size_t tableSize;
    BYTE* tableData;

    ebdt_table* table = (ebdt_table*)map_at(&lfFont->table_map, (void*)TAG_EBDT);
    if (table == NULL)
        return LF_TABLE_MISSING;

    LF_ERROR error = EBDT_buildTable(table, 0x00020000, &tableData, &tableSize);
    if (error != LF_ERROR_OK)
        return error;

    record->checkSum = UTILS_CalcTableChecksum(tableData, tableSize);
    record->length = (ULONG)tableSize;
    record->offset = (ULONG)STREAM_streamPos(stream);

    STREAM_writeChunk(stream, tableData, (tableSize + 3) & ~3);
    free(tableData);

    return LF_ERROR_OK;
}

static void EBDT_freeGlyphMap(LF_MAP* glyphMap)
{
    LF_MAP_ITER* mapIter = map_begin(glyphMap);

    if (mapIter != NULL)
    {
        rb_tree_node* node = map_next(mapIter);

        while (node)
        {
            bitmap_glyph* glyph = node->data;

            EBDT_freeGlyph(glyph);

            node = map_next(mapIter);
        }

        map_free_iter(mapIter);
    }
    else
    {
        DEBUG_LOG_ERROR("allocation failure in EBDT_freeGlyphMap"); // There will be memory leaks
    }

    map_clear(glyphMap);
    free(glyphMap);
}

LF_ERROR EBDT_internalFree(embedded_data_table* table)
{
    if (table != NULL)
    {
        for (size_t i = 0; i < table->strikeGlyphMaps.count; i++)
        {
            LF_MAP* glyphMap = (LF_MAP*)vector_at(&table->strikeGlyphMaps, i);
            EBDT_freeGlyphMap(glyphMap);
        }

        vector_free(&table->strikeGlyphMaps);
        free(table);
    }

    return LF_ERROR_OK;
}

LF_ERROR EBDT_freeTable(LF_FONT* lfFont)
{
    ebdt_table* table = (ebdt_table*)map_at(&lfFont->table_map, (void*)TAG_EBDT);

    return EBDT_internalFree(table);
}
