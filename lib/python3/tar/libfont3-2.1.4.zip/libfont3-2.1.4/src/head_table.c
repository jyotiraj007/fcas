// Copyright (C) 2014 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// head_table.c

#include <stdlib.h>
#include "head_table.h"
#include "utils.h"

USHORT HEAD_getUnitsPerEM(LF_FONT* lfFont)
{
    head_table* table = (head_table*)map_at(&lfFont->table_map, (void*)TAG_HEAD);
    return (table ? table->unitsPerEm : 0);
}

LF_ERROR HEAD_setUnitsPerEM(LF_FONT* lfFont, USHORT unitsPerEm)
{
    head_table* table = (head_table*)map_at(&lfFont->table_map, (void*)TAG_HEAD);

    if (table == NULL)
        return LF_TABLE_MISSING;

    table->unitsPerEm = unitsPerEm;

    return LF_ERROR_OK;
}

LF_ERROR HEAD_getFontRevision(LF_FONT* lfFont, FIXED* revision)
{
    head_table* table = (head_table*)map_at(&lfFont->table_map, (void*)TAG_HEAD);
    if (table == NULL)
        return LF_TABLE_MISSING;

    *revision = table->fontRevision;

    return LF_ERROR_OK;
}

LF_ERROR HEAD_setFontRevision(LF_FONT* lfFont, FIXED revision)
{
    head_table* table = (head_table*)map_at(&lfFont->table_map, (void*)TAG_HEAD);
    if (table == NULL)
        return LF_TABLE_MISSING;

    table->fontRevision = revision;

    return LF_ERROR_OK;
}

LF_ERROR HEAD_setCreated(LF_FONT* lfFont, LONGDATETIME created)
{
    head_table* table = (head_table*)map_at(&lfFont->table_map, (void*)TAG_HEAD);
    if (table == NULL)
        return LF_TABLE_MISSING;

    table->created = created;

    return LF_ERROR_OK;
}

LF_ERROR HEAD_setModified(LF_FONT* lfFont, LONGDATETIME modified)
{
    head_table* table = (head_table*)map_at(&lfFont->table_map, (void*)TAG_HEAD);
    if (table == NULL)
        return LF_TABLE_MISSING;

    table->modified = modified;

    return LF_ERROR_OK;
}

SHORT HEAD_getLocFormat(LF_FONT* lfFont)
{
    head_table* table = (head_table*)map_at(&lfFont->table_map, (void*)TAG_HEAD);
    return (table ? table->indexToLocFormat : -1);
}

void HEAD_setLocFormat(LF_FONT* lfFont, SHORT format)
{
    head_table* table = (head_table*)map_at(&lfFont->table_map, (void*)TAG_HEAD);
    if(table)
        table->indexToLocFormat = format;
}

ULONG HEAD_getChecksumAdjustment(LF_FONT* lfFont)
{
    head_table* table = (head_table*)map_at(&lfFont->table_map, (void*)TAG_HEAD);
    return (table ? table->checkSumAdjustment : 0);
}

SHORT HEAD_getGlyphDataFormat(LF_FONT* lfFont)
{
    head_table* table = (head_table*)map_at(&lfFont->table_map, (void*)TAG_HEAD);
    return (table ? table->glyphDataFormat : -1);
}

LF_ERROR HEAD_setBoundingBox(LF_FONT* lfFont, SHORT xMin, SHORT yMin, SHORT xMax, SHORT yMax)
{
    head_table* table = (head_table*)map_at(&lfFont->table_map, (void*)TAG_HEAD);

    if(table == NULL)
        return LF_EMPTY_TABLE;

    table->xMin = xMin;
    table->yMin = yMin;
    table->xMax = xMax;
    table->yMax = yMax;

    return LF_ERROR_OK;
}

LF_ERROR HEAD_setUnhinted(LF_FONT* lfFont)
{
    head_table* table = (head_table*)map_at(&lfFont->table_map, (void*)TAG_HEAD);
    if (table == NULL)
        return LF_EMPTY_TABLE;

    // Clear bits 2 and 4 (0001 0100 = x14)
    table->flags &= ~0x0014;

    return LF_ERROR_OK;
}

LF_ERROR HEAD_getMacStyle(LF_FONT* lfFont, USHORT* macStyle)
{
    if (macStyle == NULL)
        return LF_INVALID_PARAM;

    head_table* table = (head_table*)map_at(&lfFont->table_map, (void*)TAG_HEAD);
    if (table == NULL)
        return LF_EMPTY_TABLE;

    *macStyle = table->macStyle;

    return LF_ERROR_OK;
}

LF_ERROR HEAD_setMacStyle(LF_FONT* lfFont, USHORT macStyle)
{
    head_table* table = (head_table*)map_at(&lfFont->table_map, (void*)TAG_HEAD);
    if (table == NULL)
        return LF_EMPTY_TABLE;

    if ((macStyle & 0xFF80) != 0)
        return LF_INVALID_PARAM;

    table->macStyle = macStyle;

    return LF_ERROR_OK;
}

LF_ERROR HEAD_readTable(LF_FONT* lfFont, const sfnt_table_record* record, LF_STREAM* stream)
{
    if(STREAM_streamSeek(stream, record->offset) == 0)
    {
        head_table* table = (head_table*)malloc(sizeof(head_table));

        if(table == NULL)
            return LF_OUT_OF_MEMORY;

        table->version = STREAM_readFixed(stream);
        table->fontRevision = STREAM_readFixed(stream);
        table->checkSumAdjustment = STREAM_readULong(stream);
        table->magicNumber = STREAM_readULong(stream);
        table->flags = STREAM_readUShort(stream);
        table->unitsPerEm = STREAM_readUShort(stream);
        table->created = STREAM_readLongDateTime(stream);
        table->modified = STREAM_readLongDateTime(stream);
        table->xMin = STREAM_readShort(stream);
        table->yMin = STREAM_readShort(stream);
        table->xMax = STREAM_readShort(stream);
        table->yMax = STREAM_readShort(stream);
        table->macStyle = STREAM_readUShort(stream);
        table->lowestRecPPEM = STREAM_readUShort(stream);
        table->fontDirectionHint = STREAM_readShort(stream);
        table->indexToLocFormat = STREAM_readShort(stream);
        table->glyphDataFormat = STREAM_readShort(stream);

        map_insert(&lfFont->table_map, (void*)(intptr_t)record->tag, table);

        return LF_ERROR_OK;
    }

    return LF_INVALID_OFFSET;
}

LF_ERROR HEAD_getTableSize(LF_FONT* lfFont, size_t* tableSize)
{
    head_table* table = (head_table*)map_at(&lfFont->table_map, (void*)TAG_HEAD);

    if(table != NULL)
    {
        *tableSize = HEAD_TABLE_SIZE;   //sizeof(head_table);
        return LF_ERROR_OK;
    }
    else
    {
        *tableSize = 0;
        return LF_EMPTY_TABLE;
    }
}

LF_ERROR HEAD_writeTable(LF_FONT* lfFont, sfnt_table_record* record, LF_STREAM* stream)
{
    head_table* table = (head_table*)map_at(&lfFont->table_map, (void*)TAG_HEAD);
    size_t padLen = HEAD_TABLE_SIZE; // updated below
    BYTE* padTable;
    LF_STREAM localStream;

    if(table == NULL)
        return LF_EMPTY_TABLE;

    padTable = UTILS_AllocTable(&padLen);
    if(padTable == NULL)
        return LF_OUT_OF_MEMORY;

    STREAM_initMemStream(&localStream, padTable, padLen);

    STREAM_writeFixed(&localStream, table->version);
    STREAM_writeFixed(&localStream, table->fontRevision);
    STREAM_writeULong(&localStream, table->checkSumAdjustment);
    STREAM_writeULong(&localStream, table->magicNumber);
    STREAM_writeUShort(&localStream, table->flags);
    STREAM_writeUShort(&localStream, table->unitsPerEm);
    STREAM_writeLongDateTime(&localStream, table->created);
    STREAM_writeLongDateTime(&localStream, table->modified);
    STREAM_writeShort(&localStream, table->xMin);
    STREAM_writeShort(&localStream, table->yMin);
    STREAM_writeShort(&localStream, table->xMax);
    STREAM_writeShort(&localStream, table->yMax);
    STREAM_writeUShort(&localStream, table->macStyle);
    STREAM_writeUShort(&localStream, table->lowestRecPPEM);
    STREAM_writeShort(&localStream, table->fontDirectionHint);
    STREAM_writeShort(&localStream, table->indexToLocFormat);
    STREAM_writeShort(&localStream, table->glyphDataFormat);

    record->checkSum = UTILS_CalcTableChecksum(padTable, HEAD_TABLE_SIZE);
    // adjust checksum for checkSumAdjustment
    record->checkSum -= table->checkSumAdjustment;
    record->length = HEAD_TABLE_SIZE; //sizeof(head_table);
    record->offset = (ULONG)STREAM_streamPos(stream);

    STREAM_streamSeek(stream, record->offset);
    STREAM_writeChunk(stream, padTable, padLen);
    free(padTable);

    return LF_ERROR_OK;
}

LF_ERROR HEAD_freeTable(LF_FONT* lfFont)
{
    head_table* table = (head_table*)map_at(&lfFont->table_map, (void*)TAG_HEAD);
    free(table);
    return LF_ERROR_OK;
}
