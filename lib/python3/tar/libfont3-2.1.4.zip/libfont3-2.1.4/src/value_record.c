// Copyright (C) 2014 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// value_record.c

#include "value_record.h"
#include "utils.h"

ULONG getValueRecordSize(USHORT format)
{
    ULONG bitMask = XPLACEMENT;
    ULONG valueSize = 0;

    while(bitMask <= YADVDEVICE)
    {
        if(format & bitMask)
        {
            valueSize += sizeof(USHORT);
        }

        bitMask = bitMask << 1;
    }

    return valueSize;
}

void readValueRecord(USHORT format, ValueRecord* record, LF_STREAM* stream)
{
    if (format == 0)
        return;

    ULONG bitMask = XPLACEMENT;
    SHORT* valuePtr = &record->XPlacement;

    while(bitMask <= YADVDEVICE)
    {
        if(format & bitMask)
        {
            *valuePtr = STREAM_readUShort(stream);
        }

        valuePtr++;
        bitMask = bitMask << 1;
    }

    // This code does not process device tables, so the offsets are zeroed out
    // to avoid writing an invalid GPOS table.
    if ((format & (XPLADEVICE | YPLADEVICE | XADVDEVICE | YADVDEVICE)) != 0)
    {
        record->XPlaDevice = record->YPlaDevice = record->XAdvDevice = record->YAdvDevice = 0;
        DEBUG_LOG_WARNING("Ignoring device table");
    }
}

ULONG writeValueRecord(USHORT format, ValueRecord* record, LF_STREAM* stream)
{
    ULONG bitMask = XPLACEMENT;
    SHORT* valuePtr = &record->XPlacement;
    ULONG outSize = 0;

    while(bitMask <= YADVDEVICE)
    {
        if(format & bitMask)
        {
            STREAM_writeUShort(stream, *valuePtr);
            outSize += sizeof(USHORT);
        }

        valuePtr++;
        bitMask = bitMask << 1;
    }

    return outSize;
}

void dumpValueRecord(USHORT format, const ValueRecord* record)
{
    if (format & XPLACEMENT)
        XML_DATA_NODE("XPlacement", record->XPlacement);    //Horizontal adjustment for placement-in design units
    if (format & YPLACEMENT)
        XML_DATA_NODE("YPlacement", record->YPlacement);    //Vertical adjustment for placement-in design units
    if (format & XADVANCE)
        XML_DATA_NODE("XAdvance", record->XAdvance);      //Horizontal adjustment for advance-in design units (only used for horizontal writing)
    if (format & YADVANCE)
        XML_DATA_NODE("YAdvance", record->YAdvance);      //Vertical adjustment for advance-in design units (only used for vertical writing)
    if (format & XPLADEVICE)
        XML_DATA_NODE("XPlaDevice", record->XPlaDevice);      //Vertical adjustment for advance-in design units (only used for vertical writing)
    if (format & YPLADEVICE)
        XML_DATA_NODE("YPlaDevice", record->YPlaDevice);      //Vertical adjustment for advance-in design units (only used for vertical writing)
    if (format & XADVDEVICE)
        XML_DATA_NODE("XAdvDevice", record->XAdvDevice);      //Vertical adjustment for advance-in design units (only used for vertical writing)
    if (format & YADVDEVICE)
        XML_DATA_NODE("YAdvDevice", record->YAdvDevice);      //Vertical adjustment for advance-in design units (only used for vertical writing)
}

