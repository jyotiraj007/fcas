// Copyright (C) 2014, 2016 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// name_table.c

#include <stdlib.h>
#include "name_table.h"
#include "utils.h"

static void NAME_cleanupNameRecords(name_table *table);
static void NAME_cleanupLangTagRecords(name_table *table);

LF_ERROR NAME_readTable(LF_FONT* lfFont, const sfnt_table_record* record, LF_STREAM* stream)
{
    if(STREAM_streamSeek(stream, record->offset) == 0)
    {
        name_table* table = (name_table*)calloc(1, sizeof(name_table));

        if(table == NULL)
            return LF_OUT_OF_MEMORY;

        // read the whole table as before - this buffer will be used to write the table
        table->length = record->length;
        table->data = STREAM_readChunk(stream, table->length);

        table->isParsed = FALSE;
        table->modified = FALSE;

        map_insert(&lfFont->table_map, (void*)(intptr_t)record->tag, table);

        return LF_ERROR_OK;
    }

    return LF_INVALID_OFFSET;
}

LF_ERROR NAME_parseTable(LF_FONT* lfFont)
{
    USHORT i;
    LF_ERROR error = LF_ERROR_OK;
    name_table* table;
    LF_STREAM stream;

    table = (name_table*)map_at(&lfFont->table_map, (void*)TAG_NAME);
    if (table == NULL)
        return LF_TABLE_MISSING;

    if (table->isParsed == TRUE) 
        return LF_ERROR_OK;

    STREAM_initMemStream(&stream, table->data, table->length);

    //now parse it
    if(STREAM_streamSeek(&stream, 0) == 0)
    {
        table->format       = STREAM_readUShort(&stream);
        table->count        = STREAM_readUShort(&stream);
        table->stringOffset = STREAM_readUShort(&stream);
        table->storage      = table->data+table->stringOffset;

        error = vector_init(&table->nameRecords, table->count, 1);
        if(error != LF_ERROR_OK)
        {
            free(table);
            return error;
        }

        for(i = 0; i < table->count; ++i)
        {
            name_record* nr = (name_record*)calloc(1, sizeof(name_record));
            if(nr == NULL)
            {
                NAME_cleanupNameRecords(table);
                vector_delete(&table->nameRecords);
                free(table);
                return LF_OUT_OF_MEMORY;
            }

            nr->platformID  = STREAM_readUShort(&stream);
            nr->encodingID  = STREAM_readUShort(&stream);
            nr->languageID  = STREAM_readUShort(&stream);
            nr->nameID      = STREAM_readUShort(&stream);
            nr->length      = STREAM_readUShort(&stream);
            nr->offset      = STREAM_readUShort(&stream);

            nr->raw = (BYTE*)malloc(sizeof(BYTE)*nr->length);
            if (nr->raw == NULL)
            {
                free(nr);
                NAME_cleanupNameRecords(table);
                vector_delete(&table->nameRecords);
                free(table);
                return LF_OUT_OF_MEMORY;
            }

            memcpy(nr->raw, table->storage + nr->offset, nr->length);

            vector_push_back(&table->nameRecords, (void*)nr);
        }

        if(table->format == 1)
        {
            table->langTagCount = STREAM_readUShort(&stream);

            error = vector_init(&table->langTagRecords, table->langTagCount, 1);
            if(error != LF_ERROR_OK)
            {
                NAME_cleanupNameRecords(table);
                vector_delete(&table->nameRecords);
                free(table);
                return error;
            }

            for(i = 0; i < table->langTagCount; ++i)
            {
                lang_tag_record* ltr = (lang_tag_record*)calloc(1, sizeof(lang_tag_record));
                if(ltr == NULL)
                {
                    NAME_cleanupLangTagRecords(table);
                    NAME_cleanupNameRecords(table);
                    vector_delete(&table->nameRecords);
                    free(table);
                    return LF_OUT_OF_MEMORY;
                }

                ltr->length  = STREAM_readUShort(&stream);
                ltr->offset  = STREAM_readUShort(&stream);

                ltr->raw = (BYTE*)malloc(sizeof(BYTE)*ltr->length);
                if (ltr->raw == NULL)
                {
                    free(ltr);
                    NAME_cleanupLangTagRecords(table);
                    NAME_cleanupNameRecords(table);
                    vector_delete(&table->nameRecords);
                    free(table);

                    return LF_OUT_OF_MEMORY;
                }

                vector_push_back(&table->langTagRecords, (void*)ltr);
            }
        }
    }

    table->isParsed = TRUE;

    return LF_ERROR_OK;
}

LF_ERROR NAME_getTableSize(LF_FONT* lfFont, size_t* tableSize)
{
    name_table* table;

    *tableSize = 0;

    table = (name_table*)map_at(&lfFont->table_map, (void*)TAG_NAME);
    if(table == NULL)
        return LF_EMPTY_TABLE;

    if (table->modified == TRUE)
    {
        size_t i, length;

        length  = 3 * sizeof(USHORT);                   // format, count, and stringOffset
        length += table->count * (6 * sizeof(USHORT));  // name records

        if (table->format == 1)
        {
            length += sizeof(USHORT);                           // language tag count
            length += table->langTagCount * 2 * sizeof(USHORT); // language tag records

            for (i = 0; i < table->langTagRecords.count; i++)
            {
                lang_tag_record* ltr = (lang_tag_record*)vector_at(&table->langTagRecords, i);

                length += ltr->length;
            }
        }

        for (i = 0; i < table->nameRecords.count; i++)
        {
            name_record* nr = (name_record*)vector_at(&table->nameRecords, i);

            length += nr->length;
        }

        *tableSize = length;
    }
    else
    {
        *tableSize = table->length;
    }

    return LF_ERROR_OK;
}

static LF_ERROR NAME_buildTable(LF_FONT* lfFont, BYTE** tableData, size_t* tableSize)
{
    name_table* table = (name_table*)map_at(&lfFont->table_map, (void*)TAG_NAME);
    if (table == NULL)
        return LF_TABLE_MISSING;

    LF_ERROR error = NAME_getTableSize(lfFont, tableSize);
    if (error != LF_ERROR_OK)
        return error;

    size_t paddedSize = *tableSize;
    *tableData = UTILS_AllocTable(&paddedSize);
    if (*tableData == NULL)
    {
        DEBUG_LOG_ERROR("allocation failure in NAME_buildTable");
        return LF_OUT_OF_MEMORY;
    }

    // Calculate the string data offset
    USHORT stringOffset = 3 * sizeof(USHORT);                       // format, count, stringoffset
    stringOffset += (USHORT)(table->count * (6 * sizeof(USHORT)));  // name records

    if (table->format == 1)
    {
        stringOffset += sizeof(USHORT);                                         // lang tag count
        stringOffset += (USHORT)(table->langTagCount * (2 * sizeof(USHORT)));   // lang tag records
    }

    USHORT currentOffset = 0;

    // Update the string offsets
    size_t i;

    if (table->format == 1)
    {
        for (i = 0; i < table->langTagRecords.count; i++)
        {
            lang_tag_record* ltr = (lang_tag_record*)vector_at(&table->langTagRecords, i);

            ltr->offset = currentOffset;
            currentOffset += ltr->length;
        }
    }

    for (i = 0; i < table->nameRecords.count; i++)
    {
        name_record* nr = (name_record*)vector_at(&table->nameRecords, i);

        nr->offset = currentOffset;
        currentOffset += nr->length;
    }

    // Fill in the buffer
    LF_STREAM stream;
    STREAM_initMemStream(&stream, *tableData, *tableSize);

    STREAM_writeUShort(&stream, table->format);
    STREAM_writeUShort(&stream, table->count);
    STREAM_writeUShort(&stream, stringOffset);
    for (i = 0; i < table->nameRecords.count; i++)
    {
        name_record* nr = (name_record*)vector_at(&table->nameRecords, i);

        STREAM_writeUShort(&stream, nr->platformID);
        STREAM_writeUShort(&stream, nr->encodingID);
        STREAM_writeUShort(&stream, nr->languageID);
        STREAM_writeUShort(&stream, nr->nameID);
        STREAM_writeUShort(&stream, nr->length);
        STREAM_writeUShort(&stream, nr->offset);
    }

    if (table->format == 1)
    {
        STREAM_writeUShort(&stream, table->langTagCount);

        for (i = 0; i < table->langTagRecords.count; i++)
        {
            lang_tag_record* ltr = (lang_tag_record*)vector_at(&table->langTagRecords, i);

            STREAM_writeUShort(&stream, ltr->length);
            STREAM_writeUShort(&stream, ltr->offset);
        }
    }

    for (i = 0; i < table->nameRecords.count; i++)
    {
        name_record* nr = (name_record*)vector_at(&table->nameRecords, i);

        STREAM_writeChunk(&stream, nr->raw, nr->length);
    }

    return LF_ERROR_OK;
}

LF_ERROR NAME_writeTable(LF_FONT* lfFont, sfnt_table_record* record, LF_STREAM* stream)
{
    ULONG padLen = 0;
    name_table* table = (name_table*)map_at(&lfFont->table_map, (void*)(intptr_t)record->tag);
    if(table == NULL)
        return LF_EMPTY_TABLE;

    if (table->modified == TRUE)
    {
        size_t tableSize;
        BYTE* tableData;

        LF_ERROR error = NAME_buildTable(lfFont, &tableData, &tableSize);
        if (error != LF_ERROR_OK)
            return error;

        record->checkSum = UTILS_CalcTableChecksum(tableData, tableSize);
        record->length = (ULONG)tableSize;
        record->offset = (ULONG)STREAM_streamPos(stream);

        STREAM_writeChunk(stream, tableData, (tableSize + 3) & ~3);
        free(tableData);
    }
    else
    {
        UTILS_PadTable(&table->data, table->length, &padLen);

        //redo the storage pointer since table->data is potentially realloced
        table->storage = table->data + table->stringOffset;

        record->checkSum = UTILS_CalcTableChecksum(table->data, table->length);
        record->length = table->length;
        record->offset = (ULONG)STREAM_streamPos(stream);

        STREAM_streamSeek(stream, record->offset);
        STREAM_writeChunk(stream, table->data, padLen);
    }

    return LF_ERROR_OK;
}

static void NAME_cleanupNameRecords(name_table *table)
{
    USHORT i;

    for(i = 0; i < table->count; i++)
    {
        name_record *nr = (name_record *)vector_at(&table->nameRecords, i);
        free(nr->raw);
        free(nr);
    }
}

static void NAME_cleanupLangTagRecords(name_table *table)
{
    USHORT i;

    for(i = 0; i < table->langTagCount; i++)
    {
        lang_tag_record *ltr = (lang_tag_record *)vector_at(&table->langTagRecords, i);

        ASSERT(ltr);
        if (ltr)
        {
            free(ltr->raw);
            free(ltr);
        }
    }
}

LF_ERROR NAME_freeTable(LF_FONT* lfFont)
{
    name_table* table;

    if(lfFont == NULL)
        return LF_INVALID_PARAM;

    table = (name_table*)map_at(&lfFont->table_map, (void*)TAG_NAME);

    if(table != NULL)
    {
        free(table->data);

        if(table->isParsed == TRUE)
        {
            NAME_cleanupNameRecords(table);
            vector_delete(&table->nameRecords);

            if(table->format == 1)
            {
                NAME_cleanupLangTagRecords(table);
                vector_delete(&table->langTagRecords);
            }
        }

        free(table);
    }

    return LF_ERROR_OK;
}

//return length of English language string for the given nameID
LF_ERROR NAME_getNameStringLength(LF_FONT* lfFont, USHORT nameID, USHORT* length)
{
    USHORT i;
    name_table* table;

    if((lfFont == NULL) || (length == NULL))
        return LF_INVALID_PARAM;

    *length = 0;

    table = (name_table*)map_at(&lfFont->table_map, (void*)TAG_NAME);
    if(table == NULL)
        return LF_EMPTY_TABLE;

    if(table->isParsed == FALSE)
        return LF_BAD_FORMAT;  // must parse table first

    //loop over the name records, look for a match of 3,1 (windows,Unicode), nameID
    // and return the required length. Does not handle other platforms or encodings as of now

    for(i = 0; i < table->count; ++i)
    {
        name_record* nr = (name_record*)vector_at(&table->nameRecords, i);

        ASSERT(nr);
        if (nr)
        {
            if((nr->platformID == 3) &&
               (nr->encodingID == 1) &&
               (nr->languageID == 0x0409) &&
               (nr->nameID == nameID))
            {
                *length = nr->length;

                return LF_ERROR_OK;
            }
        }
    }

    return LF_INVALID_TYPE; // no match found
}

//copy raw data of English language string for the given nameID into the buffer, up to maxLength
LF_ERROR NAME_getNameString(LF_FONT* lfFont, USHORT nameID, BYTE *buffer, USHORT maxLength)
{
    name_table* table;
    USHORT i;

    if((lfFont == NULL) || (buffer == NULL))
        return LF_INVALID_PARAM;

    table = (name_table*)map_at(&lfFont->table_map, (void*)TAG_NAME);

    if(table == NULL)
        return LF_EMPTY_TABLE;

    if(table->isParsed == FALSE)
        return LF_BAD_FORMAT;  // must parse table first

    for(i = 0; i < table->count; ++i)
    {
        name_record* nr = (name_record*)vector_at(&table->nameRecords, i);

        ASSERT(nr);

        if (nr)
        {
            if((nr->platformID == 3) &&
               (nr->encodingID == 1) &&
               (nr->languageID == 0x0409) &&
               (nr->nameID == nameID))
            {
                LONG j;
                USHORT* src, *dest;
                USHORT toCopy = nr->length;
                if (maxLength < toCopy) toCopy = maxLength;

                src = (USHORT*)(void*)(nr->raw);
                dest = (USHORT*)(void*)buffer;

                for (j = 0; j < toCopy/2; j++, src++, dest++)
                {
                    *dest = SWAP_USHORT(*src);
                }

                return LF_ERROR_OK;
            }
        }
    }

    return LF_INVALID_TYPE; // no match found
}

// Replaces (or adds) the 3,1,U.S. English name string. Passed in buffer must be two bytes
// per character. A NULL buffer will result in the string being removed.
LF_ERROR NAME_setNameString(LF_FONT* lfFont, USHORT nameID, const BYTE *buffer, USHORT length)
{
    if (lfFont == NULL)
        return LF_INVALID_PARAM;

    name_table* table = (name_table*)map_at(&lfFont->table_map, (void*)TAG_NAME);
    if (table == NULL)
        return LF_EMPTY_TABLE;

    if (table->isParsed == FALSE)
        return LF_BAD_FORMAT;  // must parse table first

    // Find the 3,1,0x409, nameID record
    name_record* nr = NULL;
    size_t i;

    for (i = 0; i < table->count; ++i)
    {
        nr = (name_record*)vector_at(&table->nameRecords, i);

        if ((nr->platformID == 3) && (nr->encodingID == 1) && (nr->languageID == 0x0409) && (nr->nameID == nameID))
        {
            break;
        }
    }

    if ((i < table->count) && (nr != NULL))
    {
        // found it
        if (buffer == NULL)
        {
            // remove it
            free(nr->raw);
            vector_erase(&table->nameRecords, i);
        }
        else
        {
            // update it
            free(nr->raw);
            nr->raw = (BYTE*)malloc(sizeof(BYTE)*length);
            if (nr->raw == NULL)
            {
                return LF_OUT_OF_MEMORY;
            }

            USHORT *src = (USHORT*)(void*)buffer, *dest = (USHORT*)(void*)nr->raw;

            for (USHORT j = 0; j < length / 2; j++)
            {
                USHORT temp = *src++;
                *dest++ = SWAP_USHORT(temp);
            }

            nr->offset = (USHORT)-1;
            nr->length = length;
        }

    }
    else if (buffer != NULL)
    {
        // did not find it
        nr = (name_record*)calloc(1, sizeof(name_record));
        if (nr == NULL)
            return LF_OUT_OF_MEMORY;

        nr->platformID = 3;
        nr->encodingID = 1;
        nr->languageID = 0x409;
        nr->nameID = nameID;
        nr->length = length;
        nr->offset = (USHORT)-1;

        nr->raw = (BYTE*)malloc(sizeof(BYTE)*nr->length);
        if (nr->raw == NULL)
        {
            free(nr);
            return LF_OUT_OF_MEMORY;
        }

        USHORT *src = (USHORT*)(void*)buffer, *dest = (USHORT*)(void*)nr->raw;

        for (USHORT j = 0; j < length / 2; j++)
        {
            USHORT temp = *src++;
            *dest++ = SWAP_USHORT(temp);
        }

        vector_push_back(&table->nameRecords, (void*)nr);
    }

    table->modified = TRUE;
    lfFont->isRefitted = TRUE; // triggers table rebuild if only name changed

    return LF_ERROR_OK;
}

static void NAME_obfuscateInternal(BYTE* nameBuf, ULONG nameLen)
{
    // Parse the raw Name Table records and find all of the Font Family Names
    // Zero their string lengths to obfuscate the font

    LF_STREAM stream;
    STREAM_initMemStream(&stream, nameBuf, nameLen);

    stream.Current += sizeof(USHORT);              /* Skip the format */

    USHORT i, count = STREAM_readUShort(&stream);

    stream.Current += sizeof(USHORT);              /* Skip the string offset */
    for (i = 0; i < count; i++)
    {
        /* Seek to the nameID field */
        stream.Current += (3 * sizeof(USHORT));      /* Bypass platformID, encodingID, languageID to get to the nameID */

        USHORT nameID = STREAM_readUShort(&stream);
        if (nameID == 1)                            /* Font Family Name */
        {
            STREAM_writeUShort(&stream, 0);        /* So zero out the next entry which is the length */
            stream.Current += (sizeof(USHORT));    /* One more short to get us back to the top of the record */
        }
        else
        {
            stream.Current += (2 * sizeof(USHORT));  /* Bypass length and offset to get us back to the top of the record */
        }
    }
}


LF_ERROR NAME_getMacNameStringLength(LF_FONT* lfFont, USHORT nameID, USHORT* length)
{
    USHORT i;
    name_table* table;

    if ((lfFont == NULL) || (length == NULL))
        return LF_INVALID_PARAM;

    *length = 0;

    table = (name_table*)map_at(&lfFont->table_map, (void*)TAG_NAME);
    if (table == NULL)
        return LF_EMPTY_TABLE;

    if (table->isParsed == FALSE)
        return LF_BAD_FORMAT;  // must parse table first

    //loop over the name records, look for a match of 1,0,0 (mac,Unicode 1.1, Roman), nameID
    // and return the required length. Does not handle other platforms or encodings as of now

    for (i = 0; i < table->count; ++i)
    {
        name_record* nr = (name_record*)vector_at(&table->nameRecords, i);

        ASSERT(nr);
        if (nr)
        {
            if ((nr->platformID == 1) &&
                (nr->encodingID == 0) &&
                (nr->languageID == 0) &&
                (nr->nameID == nameID))
            {
                *length = nr->length;

                return LF_ERROR_OK;
            }
        }
    }

    return LF_INVALID_TYPE; // no match found
}

LF_ERROR NAME_getMacNameString(LF_FONT* lfFont, USHORT nameID, BYTE *buffer, USHORT maxLength)
{
    name_table* table;
    USHORT i;

    if ((lfFont == NULL) || (buffer == NULL))
        return LF_INVALID_PARAM;

    table = (name_table*)map_at(&lfFont->table_map, (void*)TAG_NAME);

    if (table == NULL)
        return LF_EMPTY_TABLE;

    if (table->isParsed == FALSE)
        return LF_BAD_FORMAT;  // must parse table first

    for (i = 0; i < table->count; ++i)
    {
        name_record* nr = (name_record*)vector_at(&table->nameRecords, i);

        ASSERT(nr);

        if (nr)
        {
            if ((nr->platformID == 1) &&
                (nr->encodingID == 0) &&
                (nr->languageID == 0) &&
                (nr->nameID == nameID))
            {
                USHORT toCopy = nr->length;
                if (maxLength < toCopy)
                    toCopy = maxLength;

                memcpy(buffer, nr->raw, toCopy);

                return LF_ERROR_OK;
            }
        }
    }

    return LF_INVALID_TYPE; // no match found
}

LF_ERROR NAME_setMacNameString(LF_FONT* lfFont, USHORT nameID, const BYTE *buffer, USHORT length)
{
    if (lfFont == NULL)
        return LF_INVALID_PARAM;

    name_table* table = (name_table*)map_at(&lfFont->table_map, (void*)TAG_NAME);
    if (table == NULL)
        return LF_EMPTY_TABLE;

    if (table->isParsed == FALSE)
        return LF_BAD_FORMAT;  // must parse table first

    // Find the 1,1,0 nameID record
    name_record* nr = NULL;
    size_t i;

    for (i = 0; i < table->count; ++i)
    {
        nr = (name_record*)vector_at(&table->nameRecords, i);

        if ((nr->platformID == 1) && (nr->encodingID == 0) && (nr->languageID == 0) && (nr->nameID == nameID))
        {
            break;
        }
    }

    if ((i < table->count) && (nr != NULL))
    {
        // found it
        if (buffer == NULL)
        {
            // remove it
            free(nr->raw);
            vector_erase(&table->nameRecords, i);
        }
        else
        {
            // update it
            free(nr->raw);
            nr->raw = (BYTE*)malloc(sizeof(BYTE)*length);
            if (nr->raw == NULL)
            {
                return LF_OUT_OF_MEMORY;
            }

            memcpy(nr->raw, buffer, length);

            nr->offset = (USHORT)-1;
            nr->length = length;
        }
    }
    else if (buffer != NULL)
    {
        // did not find it
        nr = (name_record*)calloc(1, sizeof(name_record));
        if (nr == NULL)
            return LF_OUT_OF_MEMORY;

        nr->platformID = 1;
        nr->encodingID = 0;
        nr->languageID = 0;
        nr->nameID = nameID;
        nr->length = length;
        nr->offset = (USHORT)-1;

        nr->raw = (BYTE*)malloc(sizeof(BYTE)*nr->length);
        if (nr->raw == NULL)
        {
            free(nr);
            return LF_OUT_OF_MEMORY;
        }

        memcpy(nr->raw, buffer, length);

        LF_ERROR error = vector_push_back(&table->nameRecords, (void*)nr);
        if (error != LF_ERROR_OK)
        {
            free(nr);
            return error;
        }
    }

    table->modified = TRUE;

    return LF_ERROR_OK;
}

LF_ERROR NAME_obfuscate(LF_FONT* lfFont)
{
    name_table* table = (name_table*)map_at(&lfFont->table_map, (void*)TAG_NAME);
    if(table == NULL)
        return LF_EMPTY_TABLE;

    NAME_obfuscateInternal(table->data, table->length);

    return LF_ERROR_OK;
}

LF_ERROR NAME_obfuscateRaw(const BYTE* nameBuf, ULONG length, BYTE** obfuscatedBuf)
{
    size_t paddedLen = length;

    *obfuscatedBuf = UTILS_AllocTable(&paddedLen);
    if (*obfuscatedBuf == NULL)
        return LF_OUT_OF_MEMORY;

    memcpy(*obfuscatedBuf, nameBuf, length);

    NAME_obfuscateInternal(*obfuscatedBuf, length);

    return LF_ERROR_OK;
}
