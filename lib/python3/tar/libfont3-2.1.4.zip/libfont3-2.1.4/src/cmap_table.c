// Copyright (C) 2014, 2016 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// cmap_table.c

#include "cmap_table.h"
#include "utils.h"
#include "maxp_table.h"

#define CMAP_encodingFormat(e) (*(USHORT*)((e)->subtable))
#define CMAP_format4(e) ((cmap_format_4*)((e)->subtable))
#define CMAP_format12(e) ((cmap_format_12*)((e)->subtable))

static LF_ERROR CMAP_createSegmentVectors(cmap_format_4_segments* segs, size_t numSegments, size_t gidLen)
{
    size_t growth = numSegments;    // set the growth to numSegments to reduce the number of times (and mallocs) vectors need to grow
    size_t gidLenToAllocate = gidLen;

    if(gidLenToAllocate == 0)
        gidLenToAllocate = 32;

    segs->startCount = vector_create(numSegments, growth);
    if((segs->startCount == NULL) || (segs->startCount->vector_array == NULL))
        return LF_OUT_OF_MEMORY;

    segs->endCount = vector_create(numSegments, growth);
    if((segs->endCount == NULL) || (segs->endCount->vector_array == NULL))
        return LF_OUT_OF_MEMORY;

    segs->idDelta = vector_create(numSegments, growth);
    if((segs->idDelta == NULL) || (segs->idDelta->vector_array == NULL))
        return LF_OUT_OF_MEMORY;

    segs->idRangeOffset = vector_create(numSegments, growth);
    if((segs->idRangeOffset == NULL) || (segs->idRangeOffset->vector_array == NULL))
        return LF_OUT_OF_MEMORY;

    segs->glyphIdArray = vector_create(gidLenToAllocate, gidLenToAllocate);
    if((segs->glyphIdArray == NULL) || (segs->glyphIdArray->vector_array == NULL))
        return LF_OUT_OF_MEMORY;

    return LF_ERROR_OK;
}

static void CMAP_destroySegmentVectors(const cmap_format_4_segments* segs)
{
    vector_free(segs->startCount);
    vector_free(segs->endCount);
    vector_free(segs->idDelta);
    vector_free(segs->idRangeOffset);
    vector_free(segs->glyphIdArray);
    free(segs->startCount);
    free(segs->endCount);
    free(segs->idDelta);
    free(segs->idRangeOffset);
    free(segs->glyphIdArray);
}

static LF_ERROR CMAP_freeEncoding4(cmap_format_4* table)
{
    CMAP_destroySegmentVectors(&table->segs);

    free(table->forwardMap);
    free(table);

    return LF_ERROR_OK;
}

static LF_ERROR CMAP_freeEncoding12(cmap_format_12* table)
{
    size_t i;

    for(i = 0; i < table->groups->count; i++)
    {
        cmap_format_12_group* group = (cmap_format_12_group*)vector_at(table->groups, i);
        free(group);
    }

    vector_delete(table->groups);
    free(table->groups);
    free(table->rawTable);
    free(table);

    return LF_ERROR_OK;
}

static void CMAP_freeEncodings(cmap_header* table)
{
    size_t i;

    for(i = 0; i < table->encodings.count; i++)
    {
        cmap_encoding* encoding = (cmap_encoding*)vector_at(&table->encodings, i);

        if(encoding->subtable)
        {
            if(4 == CMAP_encodingFormat(encoding))
            {
                CMAP_freeEncoding4((cmap_format_4*)encoding->subtable);
            }
            else if(12 == CMAP_encodingFormat(encoding))
            {
                CMAP_freeEncoding12((cmap_format_12*)encoding->subtable);
            }
            //else not processed
        }

        free(encoding);
    }

    vector_free(&table->encodings);
}

static void CMAP_freeSharedEncodings(const cmap_header* table)
{
    if (table->sharedEncodings)
    {
        for (size_t i = 0; i < table->sharedEncodings->count; i++)
            free(vector_at(table->sharedEncodings, i));
        vector_delete(table->sharedEncodings);
        free(table->sharedEncodings);
    }
}

// stream assumed to be 2 bytes past the start of the table, and format must have been filled in
static LF_ERROR CMAP_readFormat4(cmap_format_4* fmt4, LF_STREAM* stream)
{
    USHORT i, numSegments, val;
    size_t gidArrayLen;
    LF_ERROR error;

    if(fmt4->format != 4)
        return LF_INVALID_PARAM;

    fmt4->length = STREAM_readUShort(stream);
    fmt4->language = STREAM_readUShort(stream);
    fmt4->segCountX2 = STREAM_readUShort(stream);
    fmt4->searchRange = STREAM_readUShort(stream);
    fmt4->entrySelector = STREAM_readUShort(stream);
    fmt4->rangeShift = STREAM_readUShort(stream);

    numSegments = fmt4->segCountX2 >> 1;
    gidArrayLen = (fmt4->length - (8*sizeof(USHORT) + numSegments*4*sizeof(USHORT))) >> 1;

    error = CMAP_createSegmentVectors(&fmt4->segs, numSegments, gidArrayLen);
    if(error != LF_ERROR_OK)
    {
        CMAP_destroySegmentVectors(&fmt4->segs);
        return error;
    }

    for(i = 0; i < numSegments; ++i)
    {
        val = STREAM_readUShort(stream);
        vector_push_back(fmt4->segs.endCount, (void*)(intptr_t)val);
    }

    fmt4->reservedPad = STREAM_readUShort(stream);

    for(i = 0; i < numSegments; ++i)
    {
        val = STREAM_readUShort(stream);
        vector_push_back(fmt4->segs.startCount, (void*)(intptr_t)val);
    }

    for(i = 0; i < numSegments; ++i)
    {
        SHORT sval = STREAM_readShort(stream);
        vector_push_back(fmt4->segs.idDelta, (void*)(intptr_t)sval);
    }

    for(i = 0; i < numSegments; ++i)
    {
        val = STREAM_readUShort(stream);
        vector_push_back(fmt4->segs.idRangeOffset, (void*)(intptr_t)val);
    }

    for(i = 0; i < gidArrayLen; ++i)
    {
        val = STREAM_readUShort(stream);
        vector_push_back(fmt4->segs.glyphIdArray, (void*)(intptr_t)val);
    }

    fmt4->forwardMap = (USHORT*)calloc(65536, sizeof(USHORT));
    if(fmt4->forwardMap == NULL)
    {
        CMAP_destroySegmentVectors(&fmt4->segs);
        return LF_OUT_OF_MEMORY;
    }

    for(i = 0; i < numSegments; ++i)
    {
        USHORT j, glyph;
        USHORT start, end, ro;
        SHORT idDelta;

        start   = (USHORT)(intptr_t)vector_at(fmt4->segs.startCount, i);
        end     = (USHORT)(intptr_t)vector_at(fmt4->segs.endCount, i);

        if(start == 0xFFFF)
            break;

        idDelta = (SHORT)(intptr_t)vector_at(fmt4->segs.idDelta, i);
        ro      = (USHORT)(intptr_t)vector_at(fmt4->segs.idRangeOffset, i);

        for(j = start; j <= end; j++)
        {
            if(ro)
            {
                USHORT glyphOffset = (j - start) + (ro >> 1);
                USHORT index = glyphOffset - (numSegments - i);

                glyph = (USHORT)(intptr_t)vector_at(fmt4->segs.glyphIdArray, index);
            }
            else
                glyph = (USHORT) (j + idDelta);

            fmt4->forwardMap[j] = glyph;
        }
    }

#if 0 // Test code.
    {
    size_t z, x = 0;
    printf("num\tunicd\tgid\n");
    for (z = 0; z < 65536; z++)
    {
        if(fmt4->forwardMap[z])
            printf("%d\t0x%x\t%d\n", x++, z, fmt4->forwardMap[z]);
    }
    }
#endif
#if 0 // Test code.
    {
    size_t z;
    printf("i\tstart\tend\tdelta\tRO\n");
    for(z = 0; z < numSegments; z++)
    {
        printf("%d\t0x%x\t0x%x\t%d\t%d\n", z, (int)vector_at(fmt4->segs.startCount, z),  (int)vector_at(fmt4->segs.endCount, z),
                                              (int)vector_at(fmt4->segs.idDelta, z),     (int)vector_at(fmt4->segs.idRangeOffset, z));
    }

    z = sizeof(USHORT) * 8;
    z += (USHORT)(fmt4->segs.startCount->count * 4 * sizeof(USHORT));
    z+= (USHORT)(sizeof(USHORT) * fmt4->segs.glyphIdArray->count);
    printf("fmt4->length = %d\n", z);

    }
#endif

    return LF_ERROR_OK;
}   //lint !e429

// stream must be two bytes past the start of the subtable and the format must have been read in already
static LF_ERROR CMAP_readFormat12(cmap_format_12* fmt12, LF_STREAM* stream)
{
    ULONG i;
    size_t tableStart;

    if(fmt12->format != 12)
        return LF_INVALID_PARAM;

    tableStart = STREAM_streamPos(stream) - 2;

    fmt12->reserved = STREAM_readUShort(stream);
    fmt12->length = STREAM_readULong(stream);
    fmt12->language = STREAM_readULong(stream);
    fmt12->nGroups = STREAM_readULong(stream);

    fmt12->groups = vector_create(fmt12->nGroups, 1);
    if((fmt12->groups == NULL) || (fmt12->groups->vector_array == NULL))
    {
        return LF_OUT_OF_MEMORY;
    }

    for(i = 0; i < fmt12->nGroups; i++)
    {
        cmap_format_12_group* group = (cmap_format_12_group*)malloc(sizeof(cmap_format_12_group));
        if(group == NULL)
        {
            for(i = 0; i < fmt12->groups->count; i++) //lint !e445
                free(vector_at(fmt12->groups, i));
            vector_delete(fmt12->groups);
            return LF_OUT_OF_MEMORY;
        }

        group->startCharCode = STREAM_readULong(stream);
        group->endCharCode = STREAM_readULong(stream);
        group->startGlyphID = STREAM_readULong(stream);

        vector_push_back(fmt12->groups, (void*)group);
    }

    STREAM_streamSeek(stream, tableStart);

    fmt12->rawTable = STREAM_readChunk(stream, fmt12->length);
    if(fmt12->rawTable == NULL)
    {
        for(i = 0; i < fmt12->groups->count; i++) //lint !e445
            free(vector_at(fmt12->groups, i));
        vector_delete(fmt12->groups);
        return LF_OUT_OF_MEMORY;
    }

    return LF_ERROR_OK;
}   //lint !e429

// stream must be at beginning of the subtable
static LF_ERROR CMAP_parseSubTable(cmap_encoding* encoding, LF_STREAM* stream)
{
    USHORT format= STREAM_readUShort(stream);
    LF_ERROR error = LF_OUT_OF_MEMORY;

    if(4 == format)
    {
        cmap_format_4* fmt4 = (cmap_format_4*)calloc(1, sizeof(cmap_format_4));
        if(fmt4 != NULL)
        {
            fmt4->format = format;

            error = CMAP_readFormat4(fmt4, stream);
            if(error == LF_ERROR_OK)
                encoding->subtable = fmt4;
            else
                free(fmt4);
        }
    }
    else if(12 == format)
    {
        cmap_format_12* fmt12 = (cmap_format_12*)calloc(1, sizeof(cmap_format_12));
        if(fmt12 != NULL)
        {
            fmt12->format = format;

            error = CMAP_readFormat12(fmt12, stream);
            if(error == LF_ERROR_OK)
                encoding->subtable = fmt12;
            else
                free(fmt12);
        }
    }
    else
        error = LF_INVALID_TYPE;

    return error;
}

static LF_ERROR CMAP_findGIDMappingSrc(cmap_header* table)
{
    size_t i;
    cmap_encoding* enc = NULL;

    // look for a 3,10...
    for (i = 0; i < table->encodings.count; i++)
    {
        enc = (cmap_encoding*)vector_at(&table->encodings, i);

        if((enc->platformID == 3) && (enc->encodingID == 10))
        {
            enc->srcForMapping = TRUE;
            break;
        }
    }

    if(enc == NULL)
        return LF_EMPTY_TABLE;

    if(enc->srcForMapping == FALSE)
    {
        // look for a 3,1
        for (i = 0; i < table->encodings.count; i++)
        {
            enc = (cmap_encoding*)vector_at(&table->encodings, i);

            if((enc->platformID == 3) && (enc->encodingID == 1))
            {
                enc->srcForMapping = TRUE;
                break;
            }
        }
    }

    if (enc->srcForMapping == FALSE)
    {
        // 0,4
        for (i = 0; i < table->encodings.count; i++)
        {
            enc = (cmap_encoding*)vector_at(&table->encodings, i);

            if ((enc->platformID == 0) && (enc->encodingID == 4))
            {
                enc->srcForMapping = TRUE;
                break;
            }
        }
    }

    if (enc->srcForMapping == FALSE)
    {
        // 3,0
        for (i = 0; i < table->encodings.count; i++)
        {
            enc = (cmap_encoding*)vector_at(&table->encodings, i);

            if ((enc->platformID == 3) && (enc->encodingID == 0))
            {
                enc->srcForMapping = TRUE;
                break;
            }
        }
    }

    if (enc->srcForMapping == FALSE)
    {
        // 0,3
        for (i = 0; i < table->encodings.count; i++)
        {
            enc = (cmap_encoding*)vector_at(&table->encodings, i);

            if ((enc->platformID == 0) && (enc->encodingID == 3))
            {
                enc->srcForMapping = TRUE;
                break;
            }
        }
    }

    if (enc->srcForMapping == FALSE)
        return LF_BAD_FORMAT;  // did not find a usable encoding from which to create our mapping

    return LF_ERROR_OK;
}   //lint !e429

LF_ERROR CMAP_readTable(LF_FONT* lfFont, const sfnt_table_record* record, LF_STREAM* stream)
{
    if(STREAM_streamSeek(stream, record->offset) == 0)
    {
        USHORT i, numTables;
        LONG* ptr;
        cmap_header* header;
        size_t tableStart = STREAM_streamPos(stream);
        LF_ERROR error;

        header = (cmap_header*)malloc(sizeof(cmap_header));
        if(header == NULL)
            return LF_OUT_OF_MEMORY;

        header->calculatedSize = 0;
        header->newMinUnicode = 0xFFFFFFFF;
        header->newMaxUnicode = 0xFFFFFFFF;
        header->gidMappingLength = MAXP_getNumGlyphs(lfFont);
        header->gidMappingArray = (LONG*)malloc(sizeof(LONG) * header->gidMappingLength);
        if(header->gidMappingArray == NULL)
        {
            free(header);
            return LF_OUT_OF_MEMORY;
        }
        header->remapped = FALSE;
        header->sharedEncodings = NULL;

        // initialize all to 1
        ptr = header->gidMappingArray;
        for (i = 0; i < header->gidMappingLength; ++i)
            *ptr++ = 1;

        // read header version and number of encoding subtables
        header->version = STREAM_readUShort(stream);
        numTables = STREAM_readUShort(stream);

        // initialize containers
        error  = vector_init(&header->encodings, numTables, 4);
        if(error != LF_ERROR_OK)
        {
            free(header->gidMappingArray);
            free(header);
            return LF_OUT_OF_MEMORY;
        }

        // read the encoding tables
        for (i = 0; i < numTables; i++)
        {
            cmap_encoding* encoding = (cmap_encoding*)malloc(sizeof(cmap_encoding));

            if(encoding == NULL)
            {
                CMAP_freeEncodings(header);
                free(header->gidMappingArray);
                free(header);
                return LF_OUT_OF_MEMORY;
            }

            encoding->platformID = STREAM_readUShort(stream);
            encoding->encodingID = STREAM_readUShort(stream);
            encoding->offset = STREAM_readULong(stream);
            encoding->subtable = NULL;
            encoding->srcForMapping = FALSE;

            vector_push_back(&header->encodings, encoding);
        }

        // check for shared encodings
        for (size_t k = 0; k < numTables; k++)
        {
            cmap_encoding* encoding1 = (cmap_encoding*)vector_at(&header->encodings, k);

            for (size_t l = k + 1; l < numTables; l++)
            {
                cmap_encoding* encoding2 = (cmap_encoding*)vector_at(&header->encodings, l);

                if (encoding1->offset == encoding2->offset)
                {
                    if (header->sharedEncodings == NULL)
                    {
                        header->sharedEncodings = vector_create(2, 2);
                        if (header->sharedEncodings == NULL)
                        {
                            CMAP_freeEncodings(header);
                            free(header->gidMappingArray);
                            free(header);
                            return error;
                        }
                    }

                    shared_encoding* se = (shared_encoding*)calloc(1, sizeof(shared_encoding));
                    if (se == NULL)
                    {
                        CMAP_freeEncodings(header);
                        CMAP_freeSharedEncodings(header);
                        free(header->gidMappingArray);
                        free(header);
                        return LF_OUT_OF_MEMORY;
                    }

                    se->platformID1 = encoding1->platformID;
                    se->encodingID1 = encoding1->encodingID;
                    se->platformID2 = encoding2->platformID;
                    se->encodingID2 = encoding2->encodingID;

                    vector_push_back(header->sharedEncodings, se);

                    //printf(" %d, %d and %d, %d share the same data\n", encoding1->platformID, encoding1->encodingID, encoding2->platformID, encoding2->encodingID);
                }
            }
        }

        error = CMAP_findGIDMappingSrc(header);
        if(error != LF_ERROR_OK)
        {
            CMAP_freeEncodings(header);
            CMAP_freeSharedEncodings(header);
            free(header->gidMappingArray);
            free(header);
            return error;
        }

        // loop through all the encoding tables and load the actual encoding subtable data
        for (i = 0; i < header->encodings.count; i++)
        {
            cmap_encoding* encoding = (cmap_encoding*)vector_at(&header->encodings, i);

            if(encoding->platformID == 3 || encoding->platformID == 0 || encoding->platformID == 1)
            {
                STREAM_streamSeek(stream, tableStart + encoding->offset);

                error = CMAP_parseSubTable(encoding, stream);
                if(error == LF_INVALID_TYPE)
                {
                    // we don't parse (or preserve) this encoding
                    free(encoding);
                    vector_erase(&header->encodings, i--);
                }
                else if(error != LF_ERROR_OK)
                {
                    free(header->gidMappingArray);
                    free(header);
                    return error;
                }
            }
            else
            {
                // we don't parse (or preserve) this encoding
                free(encoding);
                vector_erase(&header->encodings, i--);
            }
        }

        map_insert(&lfFont->table_map, (void*)(intptr_t)record->tag, header); //lint !e850

        return LF_ERROR_OK;
    }

    return LF_INVALID_OFFSET;
}

/****************************************************************/
/* the following table is floor(log2(n)) for n = 0 to 255   */
/* note that floor(log2(0)) is undefined but set to 0 below */
static const BYTE floorLog2_256[] =
{
    0, 0, 1, 1, 2, 2, 2, 2, 3, 3, 3, 3, 3, 3, 3, 3,
    4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4,
    5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5,
    5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5,
    6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6,
    6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6,
    6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6,
    6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6,
    7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7,
    7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7,
    7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7,
    7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7,
    7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7,
    7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7,
    7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7,
    7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7
};

/****************************************************************/
/* find the value of FLOOR(log2(count))                         */
/* this value is used as an entry selector in binary search     */
/* in format 8 and 12                                           */
static USHORT entrySelector(ULONG n)
{
    USHORT floorLog2; /* floor(log2(n)) */

    if      (n & 0xFFFF0000)    if      (n & 0xFF000000)    floorLog2 = 24 + floorLog2_256[n >> 24];
                                else /* (n & 0x00FF0000) */ floorLog2 = 16 + floorLog2_256[n >> 16];
    else /* (n & 0x0000FFFF) */ if      (n & 0x0000FF00)    floorLog2 =  8 + floorLog2_256[n >>  8];
                                else /* (n & 0x000000FF) */ floorLog2 =      floorLog2_256[n      ];

    return floorLog2;
}

#undef  GROUPSIZE
#define GROUPSIZE 3  /* group is 3 longs */

#define GET_xLONG(a)  \
           ( ((ULONG) *(BYTE *)(a) << 24)     |  \
             ((ULONG) *((BYTE *)(a)+1) << 16) |  \
             ((ULONG) *((BYTE *)(a)+2) << 8)  |  \
              (ULONG) *((BYTE *)(a)+3) )

static GlyphID CMAP_map_char_12(const cmap_format_12* subtable, ULONG unicode)
{
    ULONG    *m, *n;
    ULONG    *m_last;
    ULONG    numGroups, startCharCode, endCharCode, startGlyphID;
    USHORT   sel, index;

    m = (ULONG*)(void*)subtable->rawTable;

    /* move to number of groupings */
    m += 3;

    numGroups = (ULONG)GET_xLONG(m);
    sel = entrySelector(numGroups);

    /* convert to index */
    if (sel > 0)
        sel = (USHORT)((unsigned)2 << (sel - 1));
    if (sel == numGroups) /* can happen sometimes */
        sel >>= 1;

    m += 1;  /* point to first group */

    /* in a new block to help the compiler generate better code */
    {
        register ULONG t, *q, *p = m + 1; /* point to endCharCode in first group */
        register unsigned int idx = 0;

        q = p + sel * GROUPSIZE;
        t = GET_xLONG(q);
        if (t < unicode) idx = (numGroups - sel - 1) * GROUPSIZE;
        sel >>= 1;

        switch (sel)
        {
        case 32768: q = p+idx+98301/*32767*GROUPSIZE*/; t = GET_xLONG(q); if (t < unicode) idx += 98304/*32768*GROUPSIZE*/;/* FALLTHROUGH */
        case 16384: q = p+idx+49149/*16383*GROUPSIZE*/; t = GET_xLONG(q); if (t < unicode) idx += 49152/*16384*GROUPSIZE*/;/* FALLTHROUGH */
        case  8192: q = p+idx+24573/* 8191*GROUPSIZE*/; t = GET_xLONG(q); if (t < unicode) idx += 24576/* 8192*GROUPSIZE*/;/* FALLTHROUGH */
        case  4096: q = p+idx+12285/* 4095*GROUPSIZE*/; t = GET_xLONG(q); if (t < unicode) idx += 12288/* 4096*GROUPSIZE*/;/* FALLTHROUGH */
        case  2048: q = p+idx+ 6141/* 2047*GROUPSIZE*/; t = GET_xLONG(q); if (t < unicode) idx +=  6144/* 2048*GROUPSIZE*/;/* FALLTHROUGH */
        case  1024: q = p+idx+ 3069/* 1023*GROUPSIZE*/; t = GET_xLONG(q); if (t < unicode) idx +=  3072/* 1024*GROUPSIZE*/;/* FALLTHROUGH */
        case   512: q = p+idx+ 1533/*  511*GROUPSIZE*/; t = GET_xLONG(q); if (t < unicode) idx +=  1536/*  512*GROUPSIZE*/;/* FALLTHROUGH */
        case   256: q = p+idx+  765/*  255*GROUPSIZE*/; t = GET_xLONG(q); if (t < unicode) idx +=   768/*  256*GROUPSIZE*/;/* FALLTHROUGH */
        case   128: q = p+idx+  381/*  127*GROUPSIZE*/; t = GET_xLONG(q); if (t < unicode) idx +=   384/*  128*GROUPSIZE*/;/* FALLTHROUGH */
        case    64: q = p+idx+  189/*   63*GROUPSIZE*/; t = GET_xLONG(q); if (t < unicode) idx +=   192/*   64*GROUPSIZE*/;/* FALLTHROUGH */
        case    32: q = p+idx+   93/*   31*GROUPSIZE*/; t = GET_xLONG(q); if (t < unicode) idx +=    96/*   32*GROUPSIZE*/;/* FALLTHROUGH */
        case    16: q = p+idx+   45/*   15*GROUPSIZE*/; t = GET_xLONG(q); if (t < unicode) idx +=    48/*   16*GROUPSIZE*/;/* FALLTHROUGH */
        case     8: q = p+idx+   21/*    7*GROUPSIZE*/; t = GET_xLONG(q); if (t < unicode) idx +=    24/*    8*GROUPSIZE*/;/* FALLTHROUGH */
        case     4: q = p+idx+    9/*    3*GROUPSIZE*/; t = GET_xLONG(q); if (t < unicode) idx +=    12/*    4*GROUPSIZE*/;/* FALLTHROUGH */
        case     2: q = p+idx+    3/*    1*GROUPSIZE*/; t = GET_xLONG(q); if (t < unicode) idx +=     6/*    2*GROUPSIZE*/;/* FALLTHROUGH */
            break;
        default:
            break;
        }
        m_last = m + (numGroups - 1) * GROUPSIZE + 1; /* point to endCharCode in last possible group */
        m += idx + 1;      /* point to endCharCode in lowest group */
    }

    /* now a small linear search to find first segment where id <= endCharCode */
    for (endCharCode = GET_xLONG(m); ((unicode > endCharCode) && (m < m_last)); endCharCode = GET_xLONG(m))
        m += GROUPSIZE;

    /* id must be in this group or it's not found */
    n = m - 1;
    startCharCode = (ULONG)GET_xLONG(n);
    if ((unicode < startCharCode) || (unicode > endCharCode))
        return 0;

    /* id must be in this group */
    n = m + 1;
    startGlyphID  = (ULONG)GET_xLONG(n);

    index = (USHORT)(unicode - startCharCode + startGlyphID);

    return index;
}

static void CMAP_performRemapping(cmap_header* table)
{
    USHORT i;
    USHORT gid = 0;
    LONG* ptr;

    ptr = table->gidMappingArray;

    for (i = 0; i < table->gidMappingLength; ++i)
    {
        *ptr = *ptr ? gid++ : -1;
        ptr++;
    }

    table->remapped = TRUE;
}

LF_ERROR CMAP_getRemappedGlyphID(const LF_FONT* lfFont, GlyphID gid, GlyphID *newID)
{
    cmap_header* header = (cmap_header*)map_at(&lfFont->table_map, (void*)TAG_CMAP);
    if (header == NULL)
        return LF_EMPTY_TABLE;

    if (lfFont->isSubsetted == FALSE)
        return LF_UNSUPPORTED;
    if (gid > header->gidMappingLength - 1)
        return LF_INVALID_PARAM;

    if (header->remapped == FALSE)
        CMAP_performRemapping(header);

    *newID = (header->gidMappingArray[gid] == -1) ? 0xFFFF : (GlyphID)header->gidMappingArray[gid];

    return LF_ERROR_OK;
}

LF_ERROR CMAP_getCount(const LF_FONT* lfFont, USHORT* count)
{
    cmap_header* header = (cmap_header*)map_at(&lfFont->table_map, (void*)TAG_CMAP);
    if (header == NULL)
        return LF_EMPTY_TABLE;

    if (header->remapped == FALSE)
        CMAP_performRemapping(header);

    if ((lfFont->isSubsetted == TRUE) && (header->remapped == FALSE))
        return LF_BAD_FORMAT;

    *count = 0;

    LONG* ptr = header->gidMappingArray;

    for (int i = 0; i < header->gidMappingLength; ++i)
    {
        if (*ptr != -1)
            (*count)++;
        ptr++;
    }

    return LF_ERROR_OK;
}

LF_ERROR CMAP_getGlyphID(const LF_FONT* lfFont, ULONG unicode, GlyphID* gid)
{
    size_t i;
    cmap_header* header;

    *gid = 0;

    header = (cmap_header*)map_at(&lfFont->table_map, (void*)TAG_CMAP);
    if(header == NULL)
        return LF_EMPTY_TABLE;

    //TODO -- should we scan for a 3,10 first?

    for(i = 0; i < header->encodings.count; i++)
    {
        cmap_encoding* encoding = (cmap_encoding*)vector_at(&header->encodings, i);

        if((encoding->subtable != NULL) &&
           (((encoding->platformID == 3) && ((encoding->encodingID == 1) || (encoding->encodingID == 10)))
             ||
             ((encoding->platformID == 0) && (encoding->encodingID >= 3))))
        {
            if((4 == CMAP_encodingFormat(encoding)) && (unicode <= 0xFFFF))
            {
                *gid = CMAP_format4(encoding)->forwardMap[unicode];
            }
            else if(12 == CMAP_encodingFormat(encoding))
            {
                *gid = CMAP_map_char_12(CMAP_format12(encoding), unicode);
            }
            // else not handled yet

            if(*gid != 0)
                break;
        }
    }

    return LF_ERROR_OK;
}

// create new segment data based on the remapped gid array
static LF_ERROR CMAP_updateFormat4(const cmap_header* table, cmap_format_4* fmt4)
{
    USHORT lastUnicode, newStartCode, firstGIDofSeg, lastGid;
    size_t i, gidCountAtStartofSeg, gidArrayReserve;
    boolean gidsContiguous, first = TRUE;
    LF_ERROR error;
    cmap_format_4_segments newSegs;

    gidArrayReserve = fmt4->segs.glyphIdArray->count;
    if(gidArrayReserve < 32)
        gidArrayReserve = 32;

    // create new segments
    // (initial size of segment vectors is same as original, may be too big, so uses extra memory, but avoids reallocs)
    error = CMAP_createSegmentVectors(&newSegs, fmt4->segCountX2, gidArrayReserve);
    if(error != LF_ERROR_OK)
        return error;

    lastUnicode = newStartCode = firstGIDofSeg = lastGid = 0;  // for lint
    gidsContiguous = TRUE;
    gidCountAtStartofSeg = 0;

    // loop over original ranges
    for(i = 0; i < fmt4->segs.startCount->count; i++)
    {
        USHORT unicode, startCode, endCode, oldGid;
        USHORT newGid;

        startCode = (USHORT)(intptr_t)vector_at(fmt4->segs.startCount, i);
        endCode   = (USHORT)(intptr_t)vector_at(fmt4->segs.endCount, i);

        if(startCode == 0xFFFF)
            break;

        for(unicode = startCode; unicode <= endCode; unicode++)
        {
            oldGid = fmt4->forwardMap[unicode];

            if (table->gidMappingArray[oldGid] == -1)
                continue;  // gone from font

            newGid = (USHORT)table->gidMappingArray[oldGid];

            if(first)
            {
                first = FALSE;

                lastUnicode = newStartCode = unicode;
                lastGid = firstGIDofSeg = newGid;
                vector_push_back(newSegs.glyphIdArray, (void*)(intptr_t)newGid);
                continue;
            }

            if(lastUnicode + 1 != unicode)
            {
                // need new segment
                vector_push_back(newSegs.startCount, (void*)(intptr_t)newStartCode);
                vector_push_back(newSegs.endCount, (void*)(intptr_t)lastUnicode);

                if(gidsContiguous == TRUE)
                {
                    vector_push_back(newSegs.idDelta, (void*)(intptr_t)(((SHORT)(firstGIDofSeg - newStartCode))%65536));
                    vector_push_back(newSegs.idRangeOffset, 0);
                    newSegs.glyphIdArray->count = gidCountAtStartofSeg;
                }
                else
                {
                    vector_push_back(newSegs.idDelta, (void*)0);
                    vector_push_back(newSegs.idRangeOffset, (void*)(gidCountAtStartofSeg | 0x10000)); // 0x10000 is or'd in so the first real RO
                                                                                                      // can be determined when updating them below.
                    gidsContiguous = TRUE;
                    gidCountAtStartofSeg = newSegs.glyphIdArray->count;
                }

                firstGIDofSeg = newGid;
                newStartCode = unicode;
            }
            else if(gidsContiguous)
            {
                if(lastGid + 1 != newGid)
                    gidsContiguous = FALSE;
            }

            vector_push_back(newSegs.glyphIdArray, (void*)(intptr_t)newGid);
            lastUnicode = unicode;
            lastGid = newGid;
        }
    }

    // penultimate one
    vector_push_back(newSegs.startCount, (void*)(intptr_t)newStartCode);
    vector_push_back(newSegs.endCount, (void*)(intptr_t)lastUnicode);
    if(gidsContiguous == TRUE)
    {
        vector_push_back(newSegs.idDelta, (void*)(intptr_t)(((SHORT)(firstGIDofSeg - newStartCode))%65536));
        vector_push_back(newSegs.idRangeOffset, 0);
        newSegs.glyphIdArray->count = gidCountAtStartofSeg;
    }
    else
    {
        vector_push_back(newSegs.idDelta, (void*)0);
        vector_push_back(newSegs.idRangeOffset, (void*)(gidCountAtStartofSeg | 0x10000));
    }

    // last one
    vector_push_back(newSegs.startCount, (void*)0xFFFF);
    vector_push_back(newSegs.endCount, (void*)0xFFFF);
    vector_push_back(newSegs.idDelta, (void*)1);
    vector_push_back(newSegs.idRangeOffset, 0);

    // update the range offsets
    for(i = 0; i < newSegs.startCount->count; i++)
    {
        ULONG oldVal = (ULONG)(intptr_t)vector_at(newSegs.idRangeOffset, i);

        if(oldVal)
        {
            // (oldVal & 0xFFFF) is the original range offset, the 0x10000 was or'd in to distinguish the
            // the first real range offset (which is 0 in the newSegs array and is adjusted to be wrt the
            // start of the gidarray below).
            USHORT newRangeOffset = (USHORT)(2 * ((oldVal & 0xFFFF) + (newSegs.startCount->count - i)));

            vector_set_data(newSegs.idRangeOffset, i, (void*)(intptr_t)newRangeOffset);
        }
    }

#if 0 // Test code.
    {
    size_t z;
    printf("i\tstart\tend\tdelta\tRO\n");
    for(z = 0; z < newSegs.startCount->count; z++)
    {
        printf("%d\t0x%x\t0x%x\t%d\t%d\n", z, (int)vector_at(newSegs.startCount, z),  (int)vector_at(newSegs.endCount, z),
                                              (int)vector_at(newSegs.idDelta, z),     (int)vector_at(newSegs.idRangeOffset, z));
    }
    }
#endif

    // clear out the original stuff
    CMAP_destroySegmentVectors(&fmt4->segs);

    // switch over
    fmt4->segs.startCount    = newSegs.startCount;
    fmt4->segs.endCount      = newSegs.endCount;
    fmt4->segs.idDelta       = newSegs.idDelta;
    fmt4->segs.idRangeOffset = newSegs.idRangeOffset;
    fmt4->segs.glyphIdArray  = newSegs.glyphIdArray;

    // recalculate
    fmt4->length = sizeof(USHORT) * 8;
    fmt4->length += (USHORT)(fmt4->segs.startCount->count * 4 * sizeof(USHORT));
    fmt4->length += (USHORT)(sizeof(USHORT) * fmt4->segs.glyphIdArray->count);

    fmt4->segCountX2 = (USHORT)(fmt4->segs.endCount->count * 2);

    fmt4->entrySelector = offset_log2Floor(fmt4->segs.endCount->count);
    fmt4->searchRange   = (USHORT)(((unsigned)1 << fmt4->entrySelector) * 2);
    fmt4->rangeShift    = (USHORT)(2 * fmt4->segs.endCount->count - fmt4->searchRange);

    return LF_ERROR_OK;
}

// this version reuses the vector of groups instead of creating a new vector and swapping it in
static LF_ERROR CMAP_updateFormat12(const cmap_header* table, cmap_format_12* fmt12)
{
    GlyphID oldGid;
    LONG newGid;
    USHORT lastGid;
    cmap_format_12_group* groupToSet;
    size_t i, nextAvailableIndex, nextNewGroupIndex;
    ULONG startGid, startCode, lastCode;
    boolean first = TRUE;

    nextAvailableIndex = 0;
    nextNewGroupIndex = 0;
    lastCode = startCode = 0;     // lint
    startGid = lastGid = 1;

    for(i = 0; i < fmt12->groups->count; i++)
    {
        ULONG unicode, start, end;
        cmap_format_12_group* group = (cmap_format_12_group*)vector_at(fmt12->groups, i);

        start = group->startCharCode;
        end   = group->endCharCode;

        nextAvailableIndex = i;

        for(unicode = start; unicode <= end; unicode++)
        {
            oldGid = CMAP_map_char_12(fmt12, unicode);
            newGid = table->gidMappingArray[oldGid];

            if(newGid == -1)
            {
                continue;  // gone from font
            }

            if(first) // the first saved glyph
            {
                lastCode = startCode = unicode;
                startGid = newGid;
                first = FALSE;

                if (start == end)
                    lastGid = (USHORT)newGid;

                continue;
            }

            if((lastGid + 1 != newGid) || (lastCode + 1 != unicode))
            {
                if(nextNewGroupIndex > nextAvailableIndex)
                {
                    groupToSet = (cmap_format_12_group*)malloc(sizeof(cmap_format_12_group));
                    if(groupToSet == NULL)
                    {
                        return LF_OUT_OF_MEMORY;
                    }

                    vector_insert(fmt12->groups,nextNewGroupIndex++, groupToSet);
                    i++;
                }
                else
                {
                    groupToSet = (cmap_format_12_group*)vector_at(fmt12->groups, nextNewGroupIndex++);
                }

                groupToSet->startCharCode = startCode;
                groupToSet->endCharCode = lastCode;
                groupToSet->startGlyphID = startGid;

                startCode = unicode;
                startGid = newGid;
            }

            lastCode = unicode;
            lastGid = (USHORT)newGid;
        }
    }


    // last one
    if(nextNewGroupIndex > nextAvailableIndex) //lint !e850
    {
        groupToSet = (cmap_format_12_group*)malloc(sizeof(cmap_format_12_group));
        if(groupToSet == NULL)
        {
            return LF_OUT_OF_MEMORY;
        }

        vector_insert(fmt12->groups, nextNewGroupIndex++, groupToSet);
    }
    else
    {
        groupToSet = (cmap_format_12_group*)vector_at(fmt12->groups, nextNewGroupIndex++);
    }

    groupToSet->startCharCode = startCode;
    groupToSet->endCharCode = lastCode;
    groupToSet->startGlyphID = startGid;

    for(i = nextNewGroupIndex; i < fmt12->groups->count; i++)
    {
        free(vector_at(fmt12->groups, i));
    }

    fmt12->groups->count = nextNewGroupIndex;

    fmt12->length = sizeof(USHORT) * 2 + sizeof(ULONG) * 3;
    fmt12->length += sizeof(ULONG) * 3 * (ULONG)fmt12->groups->count;

    return LF_ERROR_OK;
}


#define CMAP_format4Empty(f4) (((f4)->segs.startCount->count == 0) ? TRUE : FALSE)
#define CMAP_format12Empty(f12) (((f12)->groups->count == 0) ? TRUE : FALSE)

static LF_ERROR CMAP_getDataSize(TABLE_HANDLE hTable, size_t* size)
{
    cmap_header* header = (cmap_header*)hTable;
    ULONG i;
    LF_ERROR error;

    if(header->calculatedSize != 0)
    {
        *size = header->calculatedSize;
        return LF_ERROR_OK;
    }

    if (header->remapped == FALSE)
        CMAP_performRemapping(header);

    *size = sizeof(USHORT) * 2;

    for (i = 0; i < header->encodings.count; i++)
    {
        cmap_encoding* encoding = (cmap_encoding*)vector_at(&header->encodings, i);

        if(encoding->subtable)
        {
            *size += (sizeof(USHORT)*2 + sizeof(ULONG));

            // check for shared encodings
            shared_encoding* activeSE = NULL;
            if (header->sharedEncodings != NULL)
            {
                boolean foundMatch = FALSE;

                for (size_t k = 0; k < header->sharedEncodings->count; k++)
                {
                    shared_encoding* se = vector_at(header->sharedEncodings, k);
                    if (NULL == se)
                        return LF_BAD_FORMAT;

                    if (((se->platformID1 == encoding->platformID) && (se->encodingID1 == encoding->encodingID)) ||
                        ((se->platformID2 == encoding->platformID) && (se->encodingID2 == encoding->encodingID)))
                    {
                        if (se->newOffset == 0)
                            activeSE = se;
                        else
                            foundMatch = TRUE;
                        break;
                    }
                }
                if (foundMatch == TRUE)
                    continue;
            }

            if (4 == CMAP_encodingFormat(encoding))
            {
                cmap_format_4* subtable = CMAP_format4(encoding);

                error = CMAP_updateFormat4(header, subtable);
                if(error != LF_ERROR_OK)
                {
                    return error;
                }

                if(TRUE == CMAP_format4Empty(subtable))
                {
                    CMAP_freeEncoding4(subtable);  // probably don't get here
                    free(encoding);
                    vector_erase(&header->encodings, i--);
                    *size -= (sizeof(USHORT)* 2 + sizeof(ULONG));
                }
                else
                {
                    *size += subtable->length;

                    if (activeSE)
                        activeSE->newOffset = (ULONG)*size;
                }
            }
            else if (12 == CMAP_encodingFormat(encoding))
            {
                cmap_format_12* subtable = CMAP_format12(encoding);

                error = CMAP_updateFormat12(header, subtable);
                if(error != LF_ERROR_OK)
                {
                    return error;
                }

                if(TRUE == CMAP_format12Empty(subtable))
                {
                    CMAP_freeEncoding12(subtable);
                    free(encoding);
                    vector_erase(&header->encodings, i--);
                    *size -= (sizeof(USHORT)* 2 + sizeof(ULONG));
                }
                else
                {
                    *size += subtable->length;

                    if (activeSE)
                        activeSE->newOffset = (ULONG)*size;
                }
            }
            //else not processed yet
        }
    }

    ;//lint !e850 (loop indexer is purposely decremented in above loop if the subtable is removed)

    header->calculatedSize = (ULONG)*size;

    return LF_ERROR_OK;
}

LF_ERROR CMAP_getTableSize(const LF_FONT* lfFont, size_t* tableSize)
{
    cmap_header* header = (cmap_header*)map_at(&lfFont->table_map, (void*)TAG_CMAP);

    *tableSize = 0;

    if(header == NULL)
        return LF_EMPTY_TABLE;

   return CMAP_getDataSize(header, tableSize);
}

static void CMAP_buildFormat4(const cmap_format_4* table, LF_STREAM* stream)
{
    ULONG i;

    STREAM_writeUShort(stream, table->format);
    STREAM_writeUShort(stream, table->length);
    STREAM_writeUShort(stream, table->language);
    STREAM_writeUShort(stream, table->segCountX2);
    STREAM_writeUShort(stream, table->searchRange);
    STREAM_writeUShort(stream, table->entrySelector);
    STREAM_writeUShort(stream, table->rangeShift);

    for(i = 0; i < table->segs.endCount->count; i++)
    {
        STREAM_writeUShort(stream, (USHORT)(intptr_t)vector_at(table->segs.endCount, i));
    }

    STREAM_writeUShort(stream, table->reservedPad);

    for(i = 0; i < table->segs.startCount->count; i++)
    {
        STREAM_writeUShort(stream, (USHORT)(intptr_t)vector_at(table->segs.startCount, i));
    }

    for(i = 0; i < table->segs.idDelta->count; i++)
    {
        STREAM_writeShort(stream, (SHORT)(intptr_t)vector_at(table->segs.idDelta, i));
    }

    for(i = 0; i < table->segs.idRangeOffset->count; i++)
    {
        STREAM_writeUShort(stream, (USHORT)(intptr_t)vector_at(table->segs.idRangeOffset, i));
    }

    for(i = 0; i < table->segs.glyphIdArray->count; i++)
    {
        STREAM_writeUShort(stream, (USHORT)(intptr_t)vector_at(table->segs.glyphIdArray, i));
    }
}

static void CMAP_buildFormat12(const cmap_format_12* table, LF_STREAM* stream)
{
    ULONG i;

    STREAM_writeUShort(stream, table->format);
    STREAM_writeUShort(stream, table->reserved);
    STREAM_writeULong(stream, table->length);
    STREAM_writeULong(stream, table->language);
    STREAM_writeULong(stream, (ULONG)table->groups->count);

    for(i = 0; i < table->groups->count; i++)
    {
        cmap_format_12_group* group = (cmap_format_12_group*)vector_at(table->groups, i);
        STREAM_writeULong(stream, group->startCharCode);
        STREAM_writeULong(stream, group->endCharCode);
        STREAM_writeULong(stream, group->startGlyphID);
    }
}

static BYTE* CMAP_buildTable(cmap_header* table, size_t* tableSize)
{
    size_t i, tableOffset, paddedSize;
    BYTE* tableData;
    LF_STREAM stream;

    *tableSize = 0;

    if(LF_ERROR_OK != CMAP_getDataSize(table, tableSize))
        return NULL;

    paddedSize = *tableSize;
    tableData = UTILS_AllocTable(&paddedSize);
    if(tableData == NULL)
        return NULL;

    STREAM_initMemStream(&stream, tableData, *tableSize);

    STREAM_writeUShort(&stream, table->version);
    STREAM_writeUShort(&stream, (USHORT)table->encodings.count);
    tableOffset = STREAM_streamPos(&stream) + (sizeof(USHORT) * 2 + sizeof(ULONG)) * table->encodings.count;

    if (table->sharedEncodings != NULL)
    {
        // Reset offsets
        for (size_t k = 0; k < table->sharedEncodings->count; k++)
        {
            shared_encoding* se = vector_at(table->sharedEncodings, k);
            se->newOffset = 0;
        }
    }

    for(i = 0; i < table->encodings.count; i++)
    {
        cmap_encoding* encoding = (cmap_encoding*)vector_at(&table->encodings, i);

        if(encoding->subtable)
        {
            size_t currOffset;

            STREAM_writeUShort(&stream, encoding->platformID);
            STREAM_writeUShort(&stream, encoding->encodingID);

            // check for shared encoding
            shared_encoding* activeSE = NULL;
            if (table->sharedEncodings != NULL)
            {
                boolean foundMatch = FALSE;
                for (size_t k = 0; k < table->sharedEncodings->count; k++)
                {
                    shared_encoding* se = vector_at(table->sharedEncodings, k);
                    if (se)
                    {
                        if (((se->platformID1 == encoding->platformID) && (se->encodingID1 == encoding->encodingID)) ||
                            ((se->platformID2 == encoding->platformID) && (se->encodingID2 == encoding->encodingID)))
                        {
                            if (se->newOffset != 0)
                            {
                                STREAM_writeULong(&stream, se->newOffset);
                                foundMatch = TRUE;
                            }
                            else
                                activeSE = se;
                            break;
                        }
                    }
                }
                if (foundMatch == TRUE)
                    continue;
            }

            STREAM_writeULong(&stream, (ULONG)tableOffset);
            if (activeSE != NULL)
                activeSE->newOffset = (ULONG)tableOffset;

            currOffset = STREAM_streamPos(&stream);
            STREAM_streamSeek(&stream, tableOffset);

            switch(CMAP_encodingFormat(encoding))
            {
                case 4:     CMAP_buildFormat4((cmap_format_4*)encoding->subtable, &stream);     break;
                case 12:    CMAP_buildFormat12((cmap_format_12*)encoding->subtable, &stream);   break;
                default:    break;
            }

            tableOffset = STREAM_streamPos(&stream);
            STREAM_streamSeek(&stream, currOffset);
        }
    }

    return tableData;
}

LF_ERROR CMAP_writeTable(const LF_FONT* lfFont, sfnt_table_record* record, LF_STREAM* stream)
{
    size_t table_size = 0;
    //ULONG padLen = 0;
    cmap_header* header;
    BYTE* tableData;

    header = (cmap_header*)map_at(&lfFont->table_map, (void*)(intptr_t)record->tag);
    if(header == NULL)
        return LF_TABLE_MISSING;

    tableData = CMAP_buildTable(header, &table_size);
    if(tableData == NULL)
        return LF_OUT_OF_MEMORY;

    //UTILS_PadTable(&tableData, table_size, &padLen);

    record->checkSum = UTILS_CalcTableChecksum(tableData, table_size);
    record->length = (ULONG)table_size;
    record->offset = (ULONG)STREAM_streamPos(stream);

    STREAM_writeChunk(stream, tableData, (table_size + 3) & ~3);
    free(tableData);

    return LF_ERROR_OK;
}

LF_ERROR CMAP_removeGlyph(const LF_FONT* lfFont, ULONG index)
{
    cmap_header* header = (cmap_header*)map_at(&lfFont->table_map, (void*)TAG_CMAP);

    if(header == NULL)
        return LF_TABLE_MISSING;
    if(index >= header->gidMappingLength)
        return LF_INVALID_PARAM;

    header->gidMappingArray[index] = 0;

    header->calculatedSize = 0;

    return LF_ERROR_OK;
}

LF_ERROR CMAP_freeTable(const LF_FONT* lfFont)
{
    cmap_header* table = (cmap_header*)map_at(&lfFont->table_map, (void*)TAG_CMAP);

    if(table)
    {
        CMAP_freeEncodings(table);
        CMAP_freeSharedEncodings(table);
        free(table->gidMappingArray);

        free(table);
    }

    return LF_ERROR_OK;
}

LF_ERROR CMAP_hasEncoding(const LF_FONT* lfFont, USHORT platformID, USHORT encodingID)
{
    cmap_header* table = (cmap_header*)map_at(&lfFont->table_map, (void*)TAG_CMAP);
    if (table == NULL)
        return LF_TABLE_MISSING;

    for (size_t i = 0; i < table->encodings.count; i++)
    {
        cmap_encoding* encoding = (cmap_encoding*)vector_at(&table->encodings, i);

        if ((encoding->platformID == platformID) && (encoding->encodingID == encodingID))
        {
            return LF_ERROR_OK;
        }
    }

    return LF_NOT_COVERED;
}

LF_ERROR CMAP_getMinMaxRemappedUnicodes(const LF_FONT* lfFont, USHORT *minUni, USHORT *maxUni)
{
    cmap_header* table = (cmap_header*)map_at(&lfFont->table_map, (void*)TAG_CMAP);
    if (table == NULL)
        return LF_TABLE_MISSING;

    if (table->newMinUnicode != 0xFFFFFFFF)
    {
        *minUni = (USHORT)table->newMinUnicode;
        *maxUni = (USHORT)table->newMaxUnicode;

        return LF_ERROR_OK;
    }

    if (table->remapped == FALSE)
        CMAP_performRemapping(table);

    // find the encoding which was used for remapping
    USHORT i;
    cmap_encoding* encoding = NULL;

    for (i = 0; i < table->encodings.count; i++)
    {
        encoding = (cmap_encoding*)vector_at(&table->encodings, i);

        if (encoding->srcForMapping == TRUE)
            break;
    }

    if ((i == table->encodings.count) || (encoding == NULL))
        return LF_BAD_FORMAT;

    if (!((encoding->platformID == 3) && (encoding->encodingID == 1)))
    {
        // The min/max Unicode values should be based on the 3,1 encoding according to the spec.
        // The code below uses the encoding that is used to do the remapping, so
        // the values could be wrong in the unlikely case that the 3,10 had a different
        // set of BMP glyphs than the 3,1. (or the 0,4).
        DEBUG_LOG_WARNING("CMAP_getMinMaxRemappedUnicodes possibly inaccurate results");
    }

    LONG j;
    USHORT format = *(USHORT*)encoding->subtable;

    if (format == 4)
    {
        for (j = 0; j < 65536; j++)
        {
            GlyphID gid = CMAP_format4(encoding)->forwardMap[j];

            if ((gid != 0) && (table->gidMappingArray[gid] > 0))
            {
                *minUni = (USHORT)j;
                break;
            }
        }
        if (j == 65536)
            *minUni = 0;

        cmap_format_4* subtable = CMAP_format4(encoding);

        USHORT maxOrigUni = (USHORT)(intptr_t)vector_at(subtable->segs.endCount, subtable->segs.endCount->count - 1);

        if ((maxOrigUni == 0xFFFF) && (0xFFFF == (USHORT)(intptr_t)vector_at(subtable->segs.startCount, subtable->segs.startCount->count - 1)))
        {
            maxOrigUni = (USHORT)(intptr_t)vector_at(subtable->segs.endCount, subtable->segs.endCount->count - 2);
        }

        for (j = maxOrigUni; j >= 0; j--)
        {
            GlyphID gid = CMAP_format4(encoding)->forwardMap[j];

            if ((gid != 0) && (table->gidMappingArray[gid] > 0))
            {
                *maxUni = (USHORT)j;
                break;
            }
        }
    }
    else if (format == 12)
    {
        cmap_format_12* subtable = CMAP_format12(encoding);
        cmap_format_12_group* group;

        for (i = 0; i < subtable->groups->count; i++)
        {
            group = (cmap_format_12_group*)vector_at(subtable->groups, i);

            ULONG uni;
            ULONG curGID = group->startGlyphID;

            for (uni = group->startCharCode; uni <= group->endCharCode; uni++)
            {
                if (table->gidMappingArray[curGID] > 0)
                {
                    *minUni = (USHORT)uni;
                    break;
                }
                curGID++;
            }
            if (uni <= group->endCharCode)
                break;
        }

        // Start at the last group (highest Unicodes) and work down.
        // If there is a matching GID still present in the mapping array, the
        // corresponding unicode is maximum of the font.
        for (j = (SHORT)(subtable->groups->count - 1); j >= 0; j--)
        {
            group = (cmap_format_12_group*)vector_at(subtable->groups, j);

            LONG uni;
            ULONG curGID = group->startGlyphID + (group->endCharCode - group->startCharCode);
            for (uni = group->endCharCode; uni >= (LONG)group->startCharCode; uni--)
            {
                if (table->gidMappingArray[curGID] > 0)
                {
                    *maxUni = (uni < 0xFFFF) ? (USHORT)uni : 0xFFFF;
                    break;
                }
                curGID--;
            }
            if (uni >= (LONG)(group->startCharCode))
                break;
        }
    }
    else
        return LF_UNSUPPORTED;

    table->newMinUnicode = *minUni;
    table->newMaxUnicode = *maxUni;

    return LF_ERROR_OK;
}

const cmap_encoding* CMAP_getEncodingRecord(const LF_FONT* lfFont, USHORT platformID, USHORT encodingID)
{
    cmap_header* header = (cmap_header*)map_at(&lfFont->table_map, (void*)TAG_CMAP);
    cmap_encoding* encodingRecord = NULL;

    //if (encodingRecord == NULL || encodingRecord->platformID != platformID || encodingRecord->encodingID != encodingID)
    {
        USHORT i;

        for (i = 0; i < header->encodings.count; i++)
        {
            cmap_encoding* encoding = (cmap_encoding*)vector_at(&header->encodings, i);

            if (encoding->platformID == platformID && encoding->encodingID == encodingID)
            {
                encodingRecord = encoding;
            }
        }
    }

    return encodingRecord;
}

GlyphID CMAP_getIndexFromUnicode(const LF_FONT* lfFont, const cmap_encoding* encodingRecord, ULONG unicode, boolean useRemap)
{
    cmap_header* header = (cmap_header*)map_at(&lfFont->table_map, (void*)TAG_CMAP);
    GlyphID gid = 0;
    USHORT format = CMAP_encodingFormat(encodingRecord);

    switch (format)
    {
        case 4:
            if (unicode < 0xFFFF)
                gid = CMAP_format4(encodingRecord)->forwardMap[unicode];
            break;

        case 12:
            gid = CMAP_map_char_12(CMAP_format12(encodingRecord), unicode);
            break;
        default:
            break;
    }

    if (useRemap)
    {
        gid = (header->gidMappingArray[gid] == -1) ? 0xFFFF : (GlyphID)header->gidMappingArray[gid];
    }

    if (gid == 0xFFFF)
        gid = 0;

    return gid;
}
