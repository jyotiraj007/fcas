// Copyright (C) 2014 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// class_rule.c

#include <stdlib.h>

#include "stream.h"
#include "class_rule.h"
#include "common_table.h"
#include "utils.h"


/* ============================================================================
    Class sets and rules


============================================================================ */
void ClassRule_freeRule(class_rule* scr)
{
    if (scr)
    {
        vector_delete(&scr->Class);
        Common_freeSubstLookupRecords(&scr->LookupRecords);
    }
}

LF_ERROR ClassRule_buildRule(class_rule* scr, LF_STREAM* stream)
{
    ULONG n;

    ASSERT(scr);
    ASSERT(stream);

    STREAM_writeUShort(stream, (USHORT)(scr->Class.count + 1));
    STREAM_writeUShort(stream, (USHORT)scr->LookupRecords.count);

    // Array of classes Class[GlyphCount - 1]
    for ( n = 0; n < scr->Class.count; n++ )
    {
        ULONG data = (ULONG)(intptr_t)vector_at(&scr->Class, n);
        STREAM_writeUShort(stream, (USHORT)data);
    }

    Common_buildSubstLookupRecords(&scr->LookupRecords, stream);

    return LF_ERROR_OK;
}


LF_ERROR ClassRule_readRule(class_def* ClassDef, class_rule* scr, LF_STREAM* stream)
{
    LF_ERROR    error;
    USHORT      n, count;

    scr->GlyphCount = STREAM_readUShort(stream);            // how many Glyphs
    scr->LookupCount = STREAM_readUShort(stream);           // how many lookup records
    count = scr->GlyphCount - 1;                            // only GlyphCount - 1 glyphs in stream

    error = vector_init(&scr->Class, count, sizeof(ULONG)); // allocate vector collection
    if (error != LF_ERROR_OK)
    {
        DEBUG_LOG_ERROR("unable to allocate ClassRule->Class");
        return LF_OUT_OF_MEMORY;
    }


    // loop through the stream and read in the class rules
    for ( n = 0; n < count; n++)
    {
        USHORT      classref = STREAM_readUShort(stream);

#if _DEBUG

        // we check whether the specific class is used at all.  If not, class 0
        // is used instead.
        error = ClassDef_isClassReferenced(ClassDef, classref);

        if (error != LF_ERROR_OK)
        {
            DEBUG_LOG_WARNING("class value in sequence NOT referenced in class definition");
//          classref = 0;
        }
#else
        UNUSED(ClassDef);
#endif

        error = vector_push_back(&scr->Class, (void*)(intptr_t)classref);
        if (error != LF_ERROR_OK)
            return error; //TODO possible leaks here
    }

    error = Common_readSubstLookupRecords(&scr->LookupRecords, scr->LookupCount, stream);
    if (error != LF_ERROR_OK)
    {
        ClassRule_freeRule(scr);
    }

    return error;
}


/* ============================================================================
    @description
        return the size of the class rule

    @param
        cr = pointer to the class rule structure

    @return
        ULONG = the memory requirements for the class rule
============================================================================ */
size_t ClassRule_sizeRule(class_rule* cr)
{
    size_t size;

    size  = sizeof(cr->GlyphCount);
    size += sizeof(cr->LookupCount);

    size += (sizeof(USHORT) * cr->Class.count);                     // Class Array size
    size += Common_sizeSubstLookupRecords(&cr->LookupRecords);      // LookupRecord size

    return size;
}

/* ----------------------------------------------------------------------------
    @description
        returns whether the class reference that is passed is referenced in
        the Input class definition.

    @param
        rule = pointer to the class rule
        classref = what class are we checking for
        classstart = what is the starting class for this rule.


    @return
        LF_NOT_COVERED  : means the classref is referenced in the rule
        LF_ERROR_OK     : means the classref is not referenced in the rule
---------------------------------------------------------------------------- */
LF_ERROR ClassRule_isClassReferenced(class_rule* rule, USHORT classref, USHORT classstart)
{
    if (rule)
    {
        if (classref == classstart)
        {
            return LF_NOT_COVERED;
        }

        return (ClassRule_isClassSequenceReferenced(&rule->Class, classref, classstart));
    }
    return LF_ERROR_OK;
}

/* ----------------------------------------------------------------------------
    @description
        given a vector collection of classes, return whether the classref
        is in the sequence.

    @param
        sequence      :    pointer to the vector contain the class sequence
        classref      :    what class are we checking for
        classstart    :    what is the starting class for this rule.


    @return
        LF_NOT_COVERED    : means the classref is referenced in the rule
        LF_ERROR_OK       : means the classref is NOT referenced in the rule
---------------------------------------------------------------------------- */
LF_ERROR ClassRule_isClassSequenceReferenced(LF_VECTOR* sequence, USHORT classref, USHORT classstart)
{
    ULONG k;

    UNUSED(classstart); //TODO remove from prototype?

    for (k = 0; k < sequence->count; k++)
    {
        USHORT classid = (USHORT)(intptr_t)vector_at(sequence, k);
        if (classid == classref)
        {
            return LF_NOT_COVERED;
        }
    }
    return LF_ERROR_OK;
}

#ifdef LF_OT_DUMP
void ClassRule_dumpRule(class_rule* cr)
{
    ULONG i;

//    XML_START("ClassRule");

    if (cr)
    {
        XML_DATA_NODE("context", cr->InputClass);

        for (i = 0; i < cr->Class.count; i++)
        {
            XML_DATA_NODE("context", (long)vector_at(&cr->Class, i));
        }
    }
    else
    {
        XML_COMMENT("ClassRule not found (empty)", 0);
    }
//    XML_END("ClassRule");

    if (cr)
        Common_dumpSubstLookupRecords(&cr->LookupRecords);
}
#endif

/* ============================================================================
    @summary
        validate a class sequence against a class definition structure.

        this will go through the sequence containing class id values and
        determine if the class definition is valid in the class structure.

        if the sequence is represented completely in the class definition
        the function will return OK, otherwise it will return NOT_COVERED.

        classstart is an extra parameter to check against and is added
        primarily to support the Input sequence of chained and context
        rules where the first class identification in the Input sequence
        isn't included in the run of classes vector.

    @param
        sequence        :    pointer to class sequence
        cd              :    pointer to the class definition structure
                             to compare against.

        classstart      :    a class id that represents the beginning of
                             class sequence.  0 - means to ignore it.

============================================================================ */
LF_ERROR ClassRule_validateClassSequence(LF_VECTOR* sequence, class_def* cd, USHORT classstart)
{
    ULONG k;

    // check the start of class sequence first
    if (classstart)
    {
        LF_ERROR ref = ClassDef_isClassFormatReferenced(cd, classstart);
        if (ref != LF_ERROR_OK)
            return LF_NOT_COVERED;
    }

    // now check the actual sequence.
    for (k = 0; k < sequence->count; k++)
    {
        USHORT classid = (USHORT)(intptr_t)vector_at(sequence, k);

        if (classid)
        {
            if (ClassDef_isClassFormatReferenced(cd, classid) != LF_ERROR_OK)
            {
                return LF_NOT_COVERED;
            }
        }
    }
    return LF_ERROR_OK;
}

LF_ERROR ClassRule_cleanupLookups(class_rule* cr, TABLE_HANDLE hLookup)
{
    Common_cleanupLookups(&cr->LookupRecords, hLookup);
    return LF_ERROR_OK;
}

/* ============================================================================
    @summary
        collect all of the class glyphs associated with this class rule

        the function checks if the classes represented in the rule are
        contained in the keepTable and if they are, it will execute
        the lookup records.

    @param
        cr            :        pointer to the class rule structure
        keepList      :        pointer to glyph ids to keep
        hTable        :        pointer to the gsub_header structure
        classdef      :        pointer to the class definition structure that
                               is used with the class rule.

    @return
        LF_ERROR_OK       :    classes synced, however no lookup records didn't.
        LF_ADDED_GLYPH    :    lookup records added a glyph.
        LF_NOT_COVERED    :    classes do not exist in keepTable.

============================================================================ */
LF_ERROR ClassRule_collectGlyphs(class_rule* cr, GlyphList* keepList, TABLE_HANDLE hTable, class_def* classdef)
{
    LF_ERROR error;

    error = ClassDef_classesExists(classdef, keepList, cr->InputClass, &cr->Class);

    if (error == LF_ERROR_OK)
    {
        error = Common_collectLookupRecordGlyphs(&cr->LookupRecords, keepList, hTable);
    }

    return error;
}
