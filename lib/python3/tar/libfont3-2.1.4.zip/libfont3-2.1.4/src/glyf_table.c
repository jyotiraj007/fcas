// Copyright (C) 2014, 2015, 2017 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// glyf_table.c

#include <string.h>
#include <stdlib.h>
#include "utils.h"
#include "stream.h"
#include "lf_map.h"
#include "glyf_table.h"
#include "loca_table.h"
#include "maxp_table.h"
#include "keep_table.h"

static void cleanupGlyfMap(const glyf_table* table)
{
    LF_MAP_ITER* mapIter;

    mapIter = map_begin(table->glyfMap);
    if (mapIter != NULL)
    {
        rb_tree_node* node = map_next(mapIter);

        while (node)
        {
            glyf* glyf_object = (glyf*)node->data;

            if (glyf_object)
                GLYF_destroyGlyf(glyf_object);

            node = map_next(mapIter);
        }

        map_free_iter(mapIter);
    }
    //else there will be memory leaks

    map_clear(table->glyfMap);
    free(table->glyfMap);
}

// Function name   : GLYF_readSimpleGlyf
// Description     : Parse a simple OpenType glyph into the runtime format
// Return type     : LF_ERROR
// Argument        : BYTE* glyfData
static LF_ERROR GLYF_readSimpleGlyf(glyf* glyf_object, LF_STREAM* stream)
{
    SHORT numContours = glyf_object->numberOfContours;
    USHORT i, numPoints;
    BYTE* flags;
    BYTE* flagEnd;
    SHORT* coordPtr;

    //allocate a simple_glyf object and copy the header info
    simple_glyf* simpGlyf = &glyf_object->glyf_data.simple;

    if (numContours == 0)
    {
        ASSERT(simpGlyf->endPtsOfContours == NULL);
        ASSERT(simpGlyf->instructions == NULL);
        ASSERT(simpGlyf->flags == NULL);
        ASSERT(simpGlyf->xCoordinates == NULL);
        ASSERT(simpGlyf->yCoordinates == NULL);
        return LF_ERROR_OK;
    }

    //read end point contours
    simpGlyf->endPtsOfContours = (USHORT*)malloc(sizeof(USHORT) * numContours);

    if (simpGlyf->endPtsOfContours == NULL)
        return LF_OUT_OF_MEMORY;

    for (i = 0; i < numContours; i++)
        simpGlyf->endPtsOfContours[i] = STREAM_readUShort(stream);

    //the assumption is the last endpoint value is the total num + 1 points
    numPoints = simpGlyf->endPtsOfContours[numContours - 1] + 1;

    //read instruction length
    simpGlyf->instructionLength = STREAM_readUShort(stream);

    //read instructions
    simpGlyf->instructions = NULL;
    if (simpGlyf->instructionLength > 0)
    {
        simpGlyf->instructions = STREAM_readChunk(stream, simpGlyf->instructionLength);

        if (simpGlyf->instructions == NULL)
        {
            free(simpGlyf->endPtsOfContours);
            simpGlyf->endPtsOfContours = NULL;
            return LF_OUT_OF_MEMORY;
        }
    }

    //allocate space for flags array
    simpGlyf->flags = (BYTE*)malloc(numPoints);

    if (simpGlyf->flags == NULL)
    {
        free(simpGlyf->endPtsOfContours);
        simpGlyf->endPtsOfContours = NULL;
        free(simpGlyf->instructions);
        simpGlyf->instructions = NULL;
        return LF_OUT_OF_MEMORY;
    }

    flags = simpGlyf->flags;
    flagEnd = flags + numPoints;

    //copy flag data and expand any repeating flags
    while (flags < flagEnd)
    {
        BYTE lastFlag;
        *flags++ = lastFlag = STREAM_readByte(stream);

        if (lastFlag & FLAG_REPEAT)
        {
            BYTE count = STREAM_readByte(stream);
            for (; count > 0 && (flags < flagEnd); count--)
                *flags++ = lastFlag;

            if (count != 0)
            {
                free(simpGlyf->flags);
                simpGlyf->flags = NULL;
                free(simpGlyf->endPtsOfContours);
                simpGlyf->endPtsOfContours = NULL;
                free(simpGlyf->instructions);
                simpGlyf->instructions = NULL;
                return LF_BAD_FORMAT;
            }
        }
    }

    //allocate space for X coordinates array
    simpGlyf->xCoordinates = (SHORT*)malloc(sizeof(SHORT) * numPoints);

    if (simpGlyf->xCoordinates == NULL)
    {
        free(simpGlyf->endPtsOfContours);
        simpGlyf->endPtsOfContours = NULL;
        free(simpGlyf->instructions);
        simpGlyf->instructions = NULL;
        free(simpGlyf->flags);
        simpGlyf->flags = NULL;
        return LF_OUT_OF_MEMORY;
    }

    flags = simpGlyf->flags;
    flagEnd = flags + numPoints;
    coordPtr = simpGlyf->xCoordinates;

    while (flags < flagEnd)
    {
        SHORT value = 0;

        if (*flags & FLAG_X_SHORT_VECTOR)
        {
            value = STREAM_readByte(stream) & 0xFF;
            if (!(*flags & FLAG_X_SAME))
                value = -value;
        }
        else if (!(*flags & FLAG_X_SAME))
        {
            value = STREAM_readUShort(stream);
        }

        *coordPtr++ = value;
        flags++;
    }

    //Y coordinates
    simpGlyf->yCoordinates = (SHORT*)malloc(sizeof(SHORT) * numPoints);

    if (simpGlyf->yCoordinates == NULL)
    {
        free(simpGlyf->xCoordinates);
        simpGlyf->xCoordinates = NULL;
        free(simpGlyf->endPtsOfContours);
        simpGlyf->endPtsOfContours = NULL;
        free(simpGlyf->instructions);
        simpGlyf->instructions = NULL;
        free(simpGlyf->flags);
        simpGlyf->flags = NULL;
        return LF_OUT_OF_MEMORY;
    }

    flags = simpGlyf->flags;
    flagEnd = flags + numPoints;
    coordPtr = simpGlyf->yCoordinates;

    while (flags < flagEnd)
    {
        SHORT value = 0;

        if (*flags & FLAG_Y_SHORT_VECTOR)
        {
            value = STREAM_readByte(stream) & 0xFF;
            if (!(*flags & FLAG_Y_SAME))
                value = -value;
        }
        else if (!(*flags & FLAG_Y_SAME))
        {
            value = STREAM_readUShort(stream);
        }

        *coordPtr++ = value;
        flags++;
    }

    if (!STREAM_ptrIsValid(stream))
    {
        free(simpGlyf->xCoordinates);
        simpGlyf->xCoordinates = NULL;
        free(simpGlyf->endPtsOfContours);
        simpGlyf->endPtsOfContours = NULL;
        free(simpGlyf->instructions);
        simpGlyf->instructions = NULL;
        free(simpGlyf->flags);
        simpGlyf->flags = NULL;
        return LF_BAD_FORMAT;
    }

    return LF_ERROR_OK;
}

static void GLYF_readNextCompositeGlyf(LF_STREAM* stream, composite_glyf* comp_glyf)
{
    comp_glyf->flags = STREAM_readUShort(stream);
    comp_glyf->glyphIndex = STREAM_readUShort(stream);
    comp_glyf->xscale = 0x4000;
    comp_glyf->yscale = 0x4000;
    comp_glyf->scale01 = 0;
    comp_glyf->scale10 = 0;

    if (comp_glyf->flags & ARG_1_AND_2_ARE_WORDS)
    {
        comp_glyf->argument1 = STREAM_readShort(stream);
        comp_glyf->argument2 = STREAM_readShort(stream);
    }
    else
    {
        comp_glyf->argument1 = (CHAR)STREAM_readByte(stream);
        comp_glyf->argument2 = (CHAR)STREAM_readByte(stream);
    }

    if (comp_glyf->flags & WE_HAVE_A_SCALE)
    {
        comp_glyf->xscale = (F2DOT14)(STREAM_readShort(stream));
        comp_glyf->yscale = comp_glyf->xscale;
    }
    else if (comp_glyf->flags & WE_HAVE_AN_X_AND_Y_SCALE)
    {
        comp_glyf->xscale = (F2DOT14)(STREAM_readShort(stream));
        comp_glyf->yscale = (F2DOT14)(STREAM_readShort(stream));
    }
    else if (comp_glyf->flags & WE_HAVE_A_TWO_BY_TWO)
    {
        comp_glyf->xscale = (F2DOT14)(STREAM_readShort(stream));
        comp_glyf->scale01 = (F2DOT14)(STREAM_readShort(stream));
        comp_glyf->scale10 = (F2DOT14)(STREAM_readShort(stream));
        comp_glyf->yscale = (F2DOT14)(STREAM_readShort(stream));
    }
}

static LF_VECTOR* GLYF_readCompositeGlyf(glyf* glyf_object, LF_STREAM* stream)
{
    composite_glyf* comp_glyf = NULL;

    LF_ERROR error = vector_init(&glyf_object->glyf_data.composite, 4, 4);
    if (error != LF_ERROR_OK)
        return NULL;

    do
    {
        comp_glyf = (composite_glyf*)calloc(1, sizeof(composite_glyf));

        if (comp_glyf == NULL)
        {
            // todo free prev. comps.
            vector_free(&glyf_object->glyf_data.composite);
            return NULL;
        }

        GLYF_readNextCompositeGlyf(stream, comp_glyf);

        vector_push_back(&glyf_object->glyf_data.composite, comp_glyf);
    } while (comp_glyf->flags & MORE_COMPONENTS);

    return &glyf_object->glyf_data.composite;
}

static LF_ERROR GLYF_getGlyfInternal(const glyf_table* table, ULONG index, boolean full, glyf* glyf_object)
{

    glyf* glyfOriginal = map_at(table->glyfMap, (void*)(intptr_t)index);

    if (glyfOriginal)
    {
        LF_STREAM stream;

        memcpy(glyf_object, glyfOriginal, sizeof(SHORT) * 5);

        if (full == TRUE)
        {
            glyf_object->glyfBlock = (BYTE*)malloc(glyfOriginal->glyfSize);
            if (glyf_object->glyfBlock == NULL)
                return LF_OUT_OF_MEMORY;

            memcpy(glyf_object->glyfBlock, glyfOriginal->glyfBlock, glyfOriginal->glyfSize);
            glyf_object->glyfSize = glyfOriginal->glyfSize;
        }
        else
        {
            glyf_object->glyfBlock = NULL;
            glyf_object->glyfSize = 0;
        }

        STREAM_initMemStream(&stream, glyfOriginal->glyfBlock, glyfOriginal->glyfSize);

        if (glyfOriginal->numberOfContours >= 0)
        {
            memset(&glyf_object->glyf_data.simple, 0, sizeof(simple_glyf));

            LF_ERROR error = GLYF_readSimpleGlyf(glyf_object, &stream);
            if (error != LF_ERROR_OK)
                return error;
        }
        else
            if (NULL == GLYF_readCompositeGlyf(glyf_object, &stream))
                return LF_OUT_OF_MEMORY;

        glyf_object->parsed = TRUE;
    }
    else
    {
        memset(glyf_object, 0, sizeof(glyf));
    }

    return LF_ERROR_OK;
}

LF_ERROR GLYF_getGlyf(const glyf_table* table, ULONG index, glyf* glyf_object)
{
    return GLYF_getGlyfInternal(table, index, FALSE, glyf_object);
}

// Function name   : GLYF_destroySimpleGlyf
// Description     : Free all data associated with simple glyph object
// Return type     : static void 
// Argument        : simple_glyf* glyf
static void GLYF_destroySimpleGlyf(const simple_glyf* glyf_object)
{
    free(glyf_object->endPtsOfContours);
    free(glyf_object->instructions);
    free(glyf_object->flags);
    free(glyf_object->xCoordinates);
    free(glyf_object->yCoordinates);
}

// Function name   : GLYF_destroyCompositeGlyf
// Description     : Free all data associated with composite glyph object
// Return type     : static void
// Argument        : composite_glyf* glyf
static void GLYF_destroyCompositeGlyf(LF_VECTOR* glyfList)
{
    ULONG i;

    for (i = 0; i < glyfList->count; i++)
    {
        free(vector_at(glyfList, i));
    }

    vector_free(glyfList);
}

//lint -e{818}
void GLYF_destroyGlyf(glyf* glyf_object)
{
    if(glyf_object->glyfBlock)
    {
        free(glyf_object->glyfBlock);
    }

    if (TRUE == glyf_object->parsed)
    {
        if (glyf_object->numberOfContours >= 0)
        {
            GLYF_destroySimpleGlyf(&glyf_object->glyf_data.simple);
        }
        else
        {
            GLYF_destroyCompositeGlyf(&glyf_object->glyf_data.composite);
        }
    }
}

LF_ERROR GLYF_readTable(LF_FONT* lfFont, const sfnt_table_record* record, LF_STREAM* stream)
{
    if (record == NULL)
        return LF_INVALID_PARAM;

    if(STREAM_streamSeek(stream, record->offset) == 0)
    {
        USHORT i, numGlyphs = MAXP_getNumGlyphs(lfFont);
        glyf_table* glyfTable;
        locaIterator* iter;
        LF_MAP* glyfMap;
        LF_ERROR error;

        glyfTable = (glyf_table*)calloc(1, sizeof(glyf_table));
        if (glyfTable == NULL)
            return LF_OUT_OF_MEMORY;
        // above calloc initializes fields of the object to 0/FALSE (including calculated maxp values)

        glyfTable->remapped = TRUE;     // table is up to date until something is removed.

        glyfTable->glyphDataBlock = (glyf*)malloc(numGlyphs * sizeof(glyf));
        if (glyfTable->glyphDataBlock == NULL)
        {
            free(glyfTable);
            return LF_OUT_OF_MEMORY;
        }

        glyfTable->glyfMap = glyfMap = map_create(integer_compare);
        if (glyfTable->glyfMap == NULL)
        {
            free(glyfTable->glyphDataBlock);
            free(glyfTable);
            return LF_OUT_OF_MEMORY;
        }

        iter = LOCA_iteratorCreate(lfFont);
        if (iter == NULL)
        {
            free(glyfTable->glyfMap);
            free(glyfTable->glyphDataBlock);
            free(glyfTable);
            return LF_OUT_OF_MEMORY;
        }

        for(i = 0; i < numGlyphs; i++)
        {
            ULONG glyfOffset, glyfSize;
            glyf* glyf_object;

            error = LOCA_iteratorNext(iter, &glyfOffset, &glyfSize);
            if (error != LF_ERROR_OK)
            {
                cleanupGlyfMap(glyfTable);
                free(glyfTable->glyphDataBlock);
                free(glyfTable);
                LOCA_iteratorDelete(iter);
                return LF_BAD_FORMAT;
            }

            if(glyfSize == 0)
            {
                //put empty entry into link list for empty outline
                map_insert(glyfMap, (void*)(intptr_t)i, NULL);
                continue;
            }

            STREAM_streamSeek(stream, record->offset + glyfOffset);

            glyf_object = glyfTable->glyphDataBlock + i;

            glyf_object->numberOfContours = STREAM_readUShort(stream);
            glyf_object->xMin = STREAM_readShort(stream);
            glyf_object->yMin = STREAM_readShort(stream);
            glyf_object->xMax = STREAM_readShort(stream);
            glyf_object->yMax = STREAM_readShort(stream);

            glyf_object->glyfSize = glyfSize - GLYF_HEADER_SIZE;
            glyf_object->glyfBlock = STREAM_readChunk(stream, glyf_object->glyfSize);
            if(glyf_object->glyfBlock == NULL)
            {
                cleanupGlyfMap(glyfTable);
                free(glyfTable->glyphDataBlock);
                free(glyfTable);
                LOCA_iteratorDelete(iter);
                return LF_OUT_OF_MEMORY;
            }

            glyf_object->parsed = FALSE;

            map_insert(glyfMap, (void*)(intptr_t)i, glyf_object);
        }

        LOCA_iteratorDelete(iter);

        map_insert(&lfFont->table_map, (void*)(intptr_t)record->tag, glyfTable);

        return LF_ERROR_OK;
    }

    return LF_INVALID_OFFSET;
}

// create an empty GLYF table and add it to the map
LF_ERROR GLYF_createTable(LF_FONT* lfFont, USHORT numGlyphs, boolean populateMap)
{
    // create a new glyf table
    glyf_table* glyfTable = (glyf_table*)calloc(1, sizeof(glyf_table));
    if (glyfTable == NULL)
        return LF_OUT_OF_MEMORY;

    glyfTable->glyphDataBlock = (glyf*)calloc(numGlyphs, sizeof(glyf));
    if (glyfTable->glyphDataBlock == NULL)
    {
        free(glyfTable);
        return LF_OUT_OF_MEMORY;
    }

    glyfTable->glyfMap = map_create(integer_compare);
    if (glyfTable->glyfMap == NULL)
    {
        free(glyfTable->glyphDataBlock);
        free(glyfTable);
        return LF_OUT_OF_MEMORY;
    }

    if (TRUE == populateMap)
    {
        for (USHORT i = 0; i < numGlyphs; i++)
        {
            glyf* quad_glyf = (glyfTable->glyphDataBlock + i);

            map_insert(glyfTable->glyfMap, (void*)(intptr_t)i, quad_glyf);
        }
    }

    map_insert(&lfFont->table_map, (void*)TAG_GLYF, glyfTable);

    return LF_ERROR_OK;
}

ULONG GLYF_getCount(LF_FONT* lfFont)
{
    glyf_table* table = (glyf_table*)map_at(&lfFont->table_map, (void*)TAG_GLYF);

    return ((table != NULL) ? map_size(table->glyfMap) : 0);
}

LF_ERROR GLYF_getNumContours(LF_FONT* lfFont, ULONG index, SHORT *numContours)
{
    *numContours = 0;

    glyf_table* table = (glyf_table*)map_at(&lfFont->table_map, (void*)TAG_GLYF);
    if (table == NULL)
        return LF_TABLE_MISSING;

    glyf* glyfObj = map_at(table->glyfMap, (void*)(intptr_t)index);

    if (glyfObj)
    {
        *numContours = glyfObj->numberOfContours;
    }

    return LF_ERROR_OK;
}

LF_ERROR GLYF_getGlyph(LF_FONT* lfFont, glyf* glyf_object, ULONG index)
{
    glyf_table* table = (glyf_table*)map_at(&lfFont->table_map, (void*)TAG_GLYF);
    if (table == NULL)
        return LF_ERROR_OK;

    return GLYF_getGlyf(table, index, glyf_object);
}

LF_ERROR GLYF_getFullGlyph(LF_FONT* lfFont, glyf* glyf_object, ULONG index)
{
    glyf_table* table = (glyf_table*)map_at(&lfFont->table_map, (void*)TAG_GLYF);
    if (table == NULL)
        return LF_ERROR_OK;

    return GLYF_getGlyfInternal(table, index, TRUE, glyf_object);
}

static LF_ERROR GLYF_calcCompositeInfo(glyf_table* gtable, glyf* glyfObject, USHORT *compPoints,
                                       USHORT *compContours, USHORT *compElements, USHORT *compDepth)
{
    ASSERT(glyfObject->numberOfContours == -1);

    (*compDepth)++;

    glyf compGlyf;

    for (size_t i = 0; i < glyfObject->glyf_data.composite.count; ++i)
    {
        (*compElements)++;

        composite_glyf* component = (composite_glyf*)vector_at(&glyfObject->glyf_data.composite, i);

        LF_ERROR error = GLYF_getGlyf(gtable, component->glyphIndex, &compGlyf);
        if (error != LF_ERROR_OK)
        {
            return error;
        }

        if (compGlyf.numberOfContours == -1)
        {
            // Recursive Composite
            error = GLYF_calcCompositeInfo(gtable, &compGlyf, compPoints, compContours, compElements, compDepth);
            if (error != LF_ERROR_OK)
            {
                GLYF_destroyGlyf(&compGlyf);
                return error;
            }
        }
        else if (compGlyf.numberOfContours > 0)
        {
            // Simple
            *compPoints += compGlyf.glyf_data.simple.endPtsOfContours[compGlyf.numberOfContours - 1] + 1;

            *compContours += compGlyf.numberOfContours;
        }

        GLYF_destroyGlyf(&compGlyf);
    }

    return LF_ERROR_OK;
}

// Get maxp info from the glyf table.
//
// if calculate is TRUE, the glyf table will be processed to determine the data,
// which could be an expensive operation.
// if calculate is FALSE, the function will update precalculated values in the
// maxpTable from the derivedMaxp if they have been calculated, otherwise an error is returned.
//
LF_ERROR GLYF_getMAXPInfo(LF_FONT* lfFont, maxp_table* maxpTable, boolean calculate)
{
    if ((lfFont == NULL) || (maxpTable == NULL))
        return LF_INVALID_PARAM;

    glyf_table* gtable = (glyf_table*)map_at(&lfFont->table_map, (void*)TAG_GLYF);

    if (gtable == NULL)
        return LF_TABLE_MISSING;

    maxpTable->numGlyphs = (USHORT)map_size(gtable->glyfMap);

    if ((gtable->maxpInfoUpdated == FALSE) && (calculate == TRUE))
    {
        // These are not modified since the code to calculate them isn't written yet
        (void)maxpTable->maxFunctionDefs;
        (void)maxpTable->maxZones;
        (void)maxpTable->maxTwilightPoints;
        (void)maxpTable->maxStorage;
        (void)maxpTable->maxFunctionDefs;
        (void)maxpTable->maxInstructionDefs;
        (void)maxpTable->maxStackElements;

        USHORT newMaxPoints = 0;
        USHORT newMaxContours = 0;
        USHORT newMaxCompositePoints = 0;
        USHORT newMaxCompositeContours = 0;
        USHORT newMaxComponentElements = 0;
        USHORT newMaxComponentDepth = 0;

        LF_ERROR error;

        for (ULONG i = 0; i < maxpTable->numGlyphs; i++)
        {
            glyf curGlyf;

            error = GLYF_getGlyf(gtable, i, &curGlyf);
            if (error != LF_ERROR_OK)
                return error;

            if (curGlyf.numberOfContours > 0)
            {
                // Simple
                if (curGlyf.glyf_data.simple.endPtsOfContours[curGlyf.numberOfContours - 1] >= newMaxPoints)
                    newMaxPoints = curGlyf.glyf_data.simple.endPtsOfContours[curGlyf.numberOfContours - 1] + 1;

                if (curGlyf.numberOfContours > newMaxContours)
                    newMaxContours = curGlyf.numberOfContours;
            }
            else if (curGlyf.numberOfContours == -1)
            {
                // Composite
                USHORT curMaxCompositePoints = 0;
                USHORT curMaxCompositeContours = 0;
                USHORT curMaxComponentElements = 0;
                USHORT curMaxComponentDepth = 0;

                error = GLYF_calcCompositeInfo(gtable, &curGlyf, &curMaxCompositePoints, &curMaxCompositeContours,
                                               &curMaxComponentElements, &curMaxComponentDepth);

                if (error != LF_ERROR_OK)
                {
                    GLYF_destroyGlyf(&curGlyf);
                    return error;
                }

                if (curMaxCompositePoints > newMaxCompositePoints)
                    newMaxCompositePoints = curMaxCompositePoints;
                if (curMaxCompositeContours > newMaxCompositeContours)
                    newMaxCompositeContours = curMaxCompositeContours;
                if (curMaxComponentElements > newMaxComponentElements)
                    newMaxComponentElements = curMaxComponentElements;
                if (curMaxComponentDepth > newMaxComponentDepth)
                    newMaxComponentDepth = curMaxComponentDepth;
            }

            GLYF_destroyGlyf(&curGlyf);
        }

        maxpTable->maxPoints = newMaxPoints;
        maxpTable->maxContours = newMaxContours;
        maxpTable->maxCompositePoints = newMaxCompositePoints;
        maxpTable->maxCompositeContours = newMaxCompositeContours;
        maxpTable->maxComponentElements = newMaxComponentElements;
        maxpTable->maxComponentDepth = newMaxComponentDepth;

        return LF_ERROR_OK;
    }

    // init rest to 0
    maxpTable->maxPoints = 0;
    maxpTable->maxContours = 0;
    maxpTable->maxCompositePoints = 0;
    maxpTable->maxCompositeContours = 0;
    maxpTable->maxZones = 0;
    maxpTable->maxTwilightPoints = 0;
    maxpTable->maxStorage = 0;
    maxpTable->maxFunctionDefs = 0;
    maxpTable->maxInstructionDefs = 0;
    maxpTable->maxStackElements = 0;
    maxpTable->maxSizeOfInstructions = 0;
    maxpTable->maxComponentElements = 0;
    maxpTable->maxComponentDepth = 0;

    if (gtable->maxpInfoUpdated == FALSE)
    {
        return LF_BAD_FORMAT;
    }

    maxpTable->maxContours = gtable->derivedMaxp.maxContours;
    maxpTable->maxPoints = gtable->derivedMaxp.maxPoints;
    maxpTable->maxZones = gtable->derivedMaxp.maxZones;

    maxpTable->maxCompositePoints = gtable->derivedMaxp.maxCompositePoints;
    maxpTable->maxCompositeContours = gtable->derivedMaxp.maxCompositeContours;
    maxpTable->maxComponentElements = gtable->derivedMaxp.maxComponentElements;
    maxpTable->maxComponentDepth = gtable->derivedMaxp.maxComponentDepth;

    return LF_ERROR_OK;
}

LF_ERROR GLYF_getBoundingBox(LF_FONT* lfFont, SHORT* xMin, SHORT* yMin, SHORT* xMax, SHORT* yMax)
{
    LF_MAP_ITER* mapIter;
    rb_tree_node* node;

    glyf_table* table = (glyf_table*)map_at(&lfFont->table_map, (void*)TAG_GLYF);
    if (table == NULL)
        return LF_EMPTY_TABLE;

    mapIter = map_begin(table->glyfMap);

    if (mapIter == NULL)
        return LF_OUT_OF_MEMORY;

    node = map_next(mapIter);

    *xMin = 32766;
    *yMin = 32766;
    *xMax = -32766;
    *yMax = -32766;

    while (node)
    {
        glyf* glyf_object = (glyf*)node->data;

        if (glyf_object && glyf_object->numberOfContours != 0)
        {
            if (glyf_object->xMin < *xMin)
                *xMin = glyf_object->xMin;

            if (glyf_object->yMin < *yMin)
                *yMin = glyf_object->yMin;

            if (glyf_object->xMax > *xMax)
                *xMax = glyf_object->xMax;

            if (glyf_object->yMax > *yMax)
                *yMax = glyf_object->yMax;
        }

        node = map_next(mapIter);
    }

    map_free_iter(mapIter);

    return LF_ERROR_OK;
}

LF_ERROR GLYF_getTableSize(LF_FONT* lfFont, size_t* tableSize)
{
    LF_ERROR result = LF_ERROR_OK;
    LF_MAP_ITER* mapIter;
    rb_tree_node* node;
    glyf_table* table;

    *tableSize = 0;

    table = (glyf_table*)map_at(&lfFont->table_map, (void*)TAG_GLYF);
    if(table == NULL)
        return LF_EMPTY_TABLE;

    if (table->calculatedTableSize != 0)
    {
        *tableSize = table->calculatedTableSize;
        return LF_ERROR_OK;
    }

    mapIter = map_begin(table->glyfMap);
    if(mapIter == NULL)
        return LF_OUT_OF_MEMORY;

    node = map_next(mapIter);

    while(node)
    {
        glyf* glyf_object = (glyf*)node->data;

        if(glyf_object != NULL)
        {
            if(glyf_object->glyfBlock)
            {
                size_t glyfSize = glyf_object->glyfSize;
                *tableSize += glyfSize + GLYF_HEADER_SIZE;
            }
        }

        node = map_next(mapIter);
    }

    map_free_iter(mapIter);

    table->calculatedTableSize = *tableSize;

    return result;
}

static BYTE* GLYF_buildTable(LF_FONT* lfFont, size_t* tableSize, size_t* paddedTableSize)
{
    USHORT glyfCount = 0;
    size_t dataOffset = 0;
    glyf_table* table;
    LF_MAP_ITER* mapIter;
    rb_tree_node* node;
    LF_ERROR error;
    LF_STREAM stream;

    error = GLYF_getTableSize(lfFont, tableSize);
    if (error != LF_ERROR_OK)
        return NULL;

    *paddedTableSize = (*tableSize + 3) & ~3;

    table = (glyf_table*)map_at(&lfFont->table_map, (void*)TAG_GLYF);
    if(table == NULL)
        return NULL;

    mapIter = map_begin(table->glyfMap);
    if(mapIter == NULL)
        return NULL;

    node = map_next(mapIter);

    STREAM_createMemStream(&stream, *paddedTableSize);

    while(node)
    {
        glyf* glyf_object = (glyf*)node->data;

        if(glyf_object != NULL)
        {
            BYTE* glyfData = NULL;
            size_t glyfSize = 0;

            ASSERT(glyf_object->glyfBlock);

            if(glyf_object->glyfBlock)
            {
                glyfSize = glyf_object->glyfSize;
                glyfData = glyf_object->glyfBlock;
            }

            STREAM_streamSeek(&stream, dataOffset);
            STREAM_writeUShort(&stream, glyf_object->numberOfContours);
            STREAM_writeUShort(&stream, glyf_object->xMin);
            STREAM_writeUShort(&stream, glyf_object->yMin);
            STREAM_writeUShort(&stream, glyf_object->xMax);
            STREAM_writeUShort(&stream, glyf_object->yMax);

            STREAM_writeChunk(&stream, glyfData, glyfSize);

#if 0 // Code to make glyphs two byte aligned in the glyf table.
            //note if this is enabled, the getSize would also have to be modified

            // make sure the whole thing is 4-byte aligned
            BYTE pad[3] = { 0 };
            ULONG totalGlyphSize = glyf_object->glyfSize + GLYF_HEADER_SIZE;
            ULONG paddedGlyphSize = (totalGlyphSize + 3) & ~3;

            if (paddedGlyphSize > totalGlyphSize)
                STREAM_writeChunk(&stream, pad, paddedGlyphSize - totalGlyphSize);
#endif

            LOCA_setOffset(lfFont, glyfCount, (ULONG)dataOffset);
            dataOffset += glyfSize + GLYF_HEADER_SIZE;
        }
        else
        {
            LOCA_setOffset(lfFont, glyfCount, (ULONG)dataOffset);
        }

        glyfCount++;
        node = map_next(mapIter);
    }

    //set the last index to the size of the glyf table
    LOCA_setOffset(lfFont, glyfCount, (ULONG)*tableSize);

    if (TRUE == lfFont->isRefitted)
        LOCA_shrinkFormat(lfFont);

    ASSERT(dataOffset == *tableSize);

    map_free_iter(mapIter);

    return stream.Base;
}

LF_ERROR GLYF_writeTable(LF_FONT* lfFont, sfnt_table_record* record, LF_STREAM* stream)
{
    size_t table_size = 0, paddedLen = 0;
    BYTE* tableData = GLYF_buildTable(lfFont, &table_size, &paddedLen);

    if(tableData == NULL)
        return LF_OUT_OF_MEMORY;

    record->checkSum = UTILS_CalcTableChecksum(tableData, table_size);
    record->length = (ULONG)table_size;
    record->offset = (ULONG)STREAM_streamPos(stream);

    STREAM_streamSeek(stream, record->offset);
    STREAM_writeChunk(stream, tableData, paddedLen);
    free(tableData);

    return LF_ERROR_OK;
}

void GLYF_removeGlyph(LF_FONT* lfFont, ULONG index)
{
    glyf_table* table = (glyf_table*)map_at(&lfFont->table_map, (void*)TAG_GLYF);
    if(table == NULL)
        return;

    table->calculatedTableSize = 0;
    table->remapped = FALSE;

    //if (index < glyfMap->count)
    {
        glyf* glyf_object = (glyf*)map_at(table->glyfMap, (void*)(intptr_t)index);

        if(glyf_object)
        {
            GLYF_destroyGlyf(glyf_object);
            //map_insert(glyfMap, (void*)index, NULL);
        }

        map_erase(table->glyfMap, (void*)(intptr_t)index);  /*completely remove the entry from the GLYF map*/
    }
}

/* ============================================================================
Summary

If the Glyph is still packed as a block
    If its a simple glyph
        Find the start of the Instructions
        If we have instructions
            Write a 0 to the instruction length
            Find the start of the flags which should be right after the instructions
            Copy all of the data starting with the flags (flags, xcoords, ycoords) up to overwrite the instructions
            Adjust the block size
    If it's a complex glyph
        Spin through all of the components to find the last component
        Check the flag of last component to see if there are instructions
        If we have instructions
            Shrink the block to remove the instructions
            Fix up the flag to indicate no instructions
============================================================================ */
LF_ERROR GLYF_removeInstructions(LF_FONT* lfFont)
{
    glyf_table* table = (glyf_table*)map_at(&lfFont->table_map, (void*)TAG_GLYF);
    if(table == NULL)
        return LF_EMPTY_TABLE;

    table->calculatedTableSize = 0;

    LF_MAP_ITER* mapIter = map_begin(table->glyfMap);
    if (mapIter == NULL)
        return LF_OUT_OF_MEMORY;

    rb_tree_node* node = map_next(mapIter);

    while(node)
    {
        glyf* glyf_object = (glyf*)node->data;

        if((glyf_object != NULL) && (glyf_object->glyfBlock != NULL) & (glyf_object->numberOfContours != 0))
        {
            LF_STREAM sourcestream;

            STREAM_initMemStream(&sourcestream, glyf_object->glyfBlock, glyf_object->glyfSize);

            if(glyf_object->numberOfContours > 0)
            {
                // Simple Glyph
                SHORT instructLen;
                BYTE* flagsLocation;

                STREAM_streamSeek(&sourcestream, glyf_object->numberOfContours*2);
                instructLen = STREAM_readUShort(&sourcestream);

                if (0 != instructLen)
                {
                    STREAM_streamSeek(&sourcestream, glyf_object->numberOfContours*2);
                    STREAM_writeUShort(&sourcestream, 0);
                    flagsLocation = STREAM_streamPos(&sourcestream) + sourcestream.Base + instructLen;

                    size_t flagsAndCoordsLen = glyf_object->glyfSize -
                                               (sizeof(USHORT) * (glyf_object->numberOfContours + 1) + instructLen);

                    STREAM_writeChunk(&sourcestream, flagsLocation, flagsAndCoordsLen);
                    glyf_object->glyfSize -= instructLen;

                    if (glyf_object->glyfSize % 2)
                    {
                        // Make sure the size is even
                        BYTE zero = 0;
                        STREAM_writeChunk(&sourcestream, &zero, 1);
                        glyf_object->glyfSize = (glyf_object->glyfSize + 1) & ~1;
                    }
                }
            }
            else
            {
                // Composite Glyph
                USHORT flags;
                size_t flagsLocation = 0;

                // Spin through all of the compound glyph components so we can find
                // the last component.  Then check the flag of that last component
                // to see if there are instructions.

                do
                {
                    flagsLocation = STREAM_streamPos(&sourcestream);    // Save flag location to write new flag data later
                    flags = STREAM_readUShort(&sourcestream);
                    sourcestream.Current += sizeof(USHORT);             // Skip glyph index
                    if (flags & ARG_1_AND_2_ARE_WORDS)
                        sourcestream.Current += (2*sizeof(USHORT));     // Skip 2 WORD args
                    else
                        sourcestream.Current += sizeof(USHORT);         // Skip 2 BYTE args

                    if (flags & WE_HAVE_A_SCALE)
                        sourcestream.Current += sizeof(USHORT);         // Skip one WORD scale
                    else if (flags & WE_HAVE_AN_X_AND_Y_SCALE)
                        sourcestream.Current += (2*sizeof(USHORT));     // Skip 2 WORDS of scale
                    else if (flags & WE_HAVE_A_TWO_BY_TWO)
                        sourcestream.Current += (4*sizeof(USHORT));     // Skip 4 WORDS of scale
                } while(flags & MORE_COMPONENTS);

                // Above code should find the end of all of the components
                // and the flag for the last component should tell us if we have instructions
                // If there are instructions there, then remove them by shortening the size
                // and setting the flag to indicate no instructions.

                if(flags & WE_HAVE_INSTRUCTIONS)
                {
                    glyf_object->glyfSize = STREAM_streamPos(&sourcestream);
                    glyf_object->glyfSize = (glyf_object->glyfSize + 1) & ~1;   // Make sure the size is even
                    STREAM_streamSeek(&sourcestream, flagsLocation);
                    STREAM_writeUShort(&sourcestream, flags & ~WE_HAVE_INSTRUCTIONS);
                }
            }
        }
        node = map_next(mapIter);
    }

    map_free_iter(mapIter);

    return LF_ERROR_OK;
}

LF_ERROR GLYF_freeTable(LF_FONT* lfFont)
{
    glyf_table* table = (glyf_table*)map_at(&lfFont->table_map, (void*)TAG_GLYF);
    if(table == NULL)
        return LF_EMPTY_TABLE;

    if (table->remap != NULL)
    {
        map_clear(table->remap);
        free(table->remap);
    }

    cleanupGlyfMap(table);

    free(table->glyphDataBlock);
    free(table);

    return LF_ERROR_OK;
}

/// <summary>
/// Recursively crawl a composite glyph, creating a list of all referenced simple glyphs.
/// </summary>
/// <param name="lfFont">The LF_FONT object for the loaded font.</param>
/// <param name="idList">The return list of simple glyph IDs.</param>
/// <param name="glyphID">The glyph ID of the composite glyph to analyze.</param>
/// <returns></returns>
static LF_ERROR GLYF_getCompositeIDList(LF_FONT* lfFont, GlyphID glyphID, LF_VECTOR* idList)
{
    glyf* glyf_object;

    glyf_table* table = (glyf_table*)map_at(&lfFont->table_map, (void*)TAG_GLYF);
    if(table == NULL)
        return LF_EMPTY_TABLE;

    glyf_object = (glyf*)map_at(table->glyfMap, (void*)(intptr_t)glyphID);

    if (glyf_object && glyf_object->numberOfContours < 0)
    {
        USHORT flags = 0;
        LF_STREAM stream;
        composite_glyf compGlyf;

        STREAM_initMemStream(&stream, glyf_object->glyfBlock, glyf_object->glyfSize);

        do
        {
            glyf* childGlyf;
            GLYF_readNextCompositeGlyf(&stream, &compGlyf);
            flags = compGlyf.flags;
            childGlyf = (glyf*)map_at(table->glyfMap, (void*)(intptr_t)compGlyf.glyphIndex);

            if (childGlyf && childGlyf->numberOfContours < 0)
                GLYF_getCompositeIDList(lfFont, compGlyf.glyphIndex, idList);

            vector_push_back(idList, (void*)(intptr_t)compGlyf.glyphIndex);
        } while (flags & MORE_COMPONENTS);
    }

    return LF_ERROR_OK;
}

/* ============================================================================
    @brief
        This function needs to parse the kept glyphs and ensure the
        kept glyph with composites are also added to the keep list.
        otherwise composites will be wiped out.

        lfFont will contain all of the glyphid values that need
        to be kept around, lfFont->common_table is a linked list
        with all of the fonts that need to be kept.

    @param
        lfFont = pointer to LF_FONT structure
============================================================================ */
LF_ERROR GLYF_keepGlyphs(LF_FONT* lfFont, GlyphList* keepList)
{
    size_t i;
    ULONG countGlyphs = 0;
    LF_VECTOR idList;

    glyf_table* table = (glyf_table*)map_at(&lfFont->table_map, (void*)TAG_GLYF);
    if (table == NULL)
        return LF_EMPTY_TABLE;

    LF_ERROR error = vector_init(&idList, 4, 4);
    if (error != LF_ERROR_OK)
        return error;

    ULONG numKeepGlyphs;
    GlyphID* glyphList = Keep_getSortedGlyphIDList(keepList, &numKeepGlyphs);
    if (glyphList == NULL)
    {
        vector_free(&idList);
        return LF_OUT_OF_MEMORY;
    }

    GlyphID* curGlyphPtr = glyphList;

    for (i = 0; i < table->glyfMap->count; i++)
    {
        if (countGlyphs < numKeepGlyphs && i >= *curGlyphPtr)
        {
            // Keep these composites
            GLYF_getCompositeIDList(lfFont, (GlyphID)i, &idList);

            curGlyphPtr++;
            countGlyphs++;
        }
    }

    for (i = 0; i < idList.count; i++)
    {
        GlyphID id = (GlyphID)(intptr_t)vector_at(&idList, i);
        LF_ERROR status = Keep_addGlyph(keepList, id);
        if ((status != LF_ADDED_GLYPH) && (status != LF_ERROR_OK))
        {
            // an error occurred, so return the error ...
            error = status;
            break;
        }

        if (status == LF_ADDED_GLYPH)
            error = LF_ADDED_GLYPH;
    }

    free(glyphList);

    vector_free(&idList);

    return error;
}

LF_ERROR GLYF_remapCompositeGlyf(composite_glyf* compGlyf, ULONG newIndex)
{
    compGlyf->glyphIndex = SWAP_USHORT(newIndex);
    return LF_ERROR_OK;
}

LF_ERROR GLYF_remapCompositeGlyfs(LF_FONT* lfFont, LF_MAP *remap)
{
    LF_MAP_ITER* mapIter;
    rb_tree_node* node;
    glyf_table* table = (glyf_table*)map_at(&lfFont->table_map, (void*)TAG_GLYF);
    if (table == NULL)
        return LF_EMPTY_TABLE;

    mapIter = map_begin(table->glyfMap);
    if (mapIter == NULL)
        return LF_OUT_OF_MEMORY;

    node = map_next(mapIter);

    while (node)
    {
        glyf* glyf_object = (glyf*)node->data;

        if (glyf_object && glyf_object->numberOfContours < 0)
        {
            LF_STREAM stream;
            composite_glyf compGlyf;

            STREAM_initMemStream(&stream, glyf_object->glyfBlock, glyf_object->glyfSize);

            do
            {
                composite_glyf* glyfPtr = (composite_glyf*)(void*)stream.Current;
                GLYF_readNextCompositeGlyf(&stream, &compGlyf);
                GLYF_remapCompositeGlyf(glyfPtr, (ULONG)(intptr_t)map_at(remap, (void*)(intptr_t)compGlyf.glyphIndex));
            } while (compGlyf.flags & MORE_COMPONENTS);
        }

        node = map_next(mapIter);
    }

    map_free_iter(mapIter);

    return LF_ERROR_OK;
}

LF_ERROR GLYF_remapTable(LF_FONT* lfFont)
{
    glyf_table* table = (glyf_table*)map_at(&lfFont->table_map, (void*)TAG_GLYF);
    if(table == NULL)
        return LF_TABLE_MISSING;

    if (table->remapped)
        return LF_ERROR_OK;

    table->remap = map_create(integer_compare);
    if (table->remap == NULL)
        return LF_OUT_OF_MEMORY;

    // anything left in the map will be reordered 0 through numglyphs -1.
    GlyphID newGID = 0;

    LF_MAP_ITER* mapIter = map_begin(table->glyfMap);
    if (mapIter == NULL)
        return LF_OUT_OF_MEMORY;

    rb_tree_node* node = map_next(mapIter);

    while (node)
    {
        map_insert(table->remap, node->key, (void*)(intptr_t)newGID);

        node->key = (void*)(intptr_t)newGID++;

        node = map_next(mapIter);
    }

    map_free_iter(mapIter);

    table->remapped = TRUE;

    return LF_ERROR_OK;
}


LF_ERROR GLYF_replaceGlyph(LF_FONT* lfFont, GlyphID index, glyf* newGlyf)
{
    glyf_table* table = (glyf_table*)map_at(&lfFont->table_map, (void*)TAG_GLYF);
    if (table == NULL)
        return LF_TABLE_MISSING;

    USHORT numGlyphs = (USHORT)(long)map_size(table->glyfMap);

    if (index >= numGlyphs)
        return LF_INVALID_PARAM;

    glyf* oldGlyf = (glyf*)map_at(table->glyfMap, (void*)(intptr_t)index);
    if (oldGlyf == NULL)
        return LF_BAD_FORMAT;

    if (oldGlyf->parsed == TRUE)
        return LF_UNIMPLEMENTED;

    oldGlyf->numberOfContours = newGlyf->numberOfContours;
    oldGlyf->xMax = newGlyf->xMax;
    oldGlyf->xMin = newGlyf->xMin;
    oldGlyf->yMax = newGlyf->yMax;
    oldGlyf->yMin = newGlyf->yMin;

    if (newGlyf->numberOfContours == -1)
    {
        return LF_UNIMPLEMENTED;
    }
    else
    {
        if ((oldGlyf->glyfSize > 0) && (oldGlyf->glyfBlock != NULL))
            free(oldGlyf->glyfBlock);

        oldGlyf->glyfSize = newGlyf->glyfSize;

        if (newGlyf->glyfSize != 0)
        {
            oldGlyf->glyfBlock = (BYTE*)malloc(sizeof(BYTE)*newGlyf->glyfSize);
            if (oldGlyf->glyfBlock == NULL)
                return LF_OUT_OF_MEMORY;

            memcpy(oldGlyf->glyfBlock, newGlyf->glyfBlock, newGlyf->glyfSize);
        }
        else
        {
            oldGlyf->glyfBlock = NULL;
            map_insert(table->glyfMap, (void*)(intptr_t)index, NULL);
        }
    }

    return LF_ERROR_OK;
}

static LF_ERROR GLYF_getSimpleGlyfPoints(const glyf* glyfObject, LF_VECTOR* points)
{
    int i;
    int endPoint = 0;
    SHORT prevX = 0;
    SHORT prevY = 0;

    if (glyfObject->numberOfContours == 0)
        return LF_BAD_FORMAT;

    USHORT numPoints = glyfObject->glyf_data.simple.endPtsOfContours[glyfObject->numberOfContours - 1] + 1;

    for (i = 0; i < numPoints; ++i)
    {
        vector_push_back(points, (void*)(intptr_t)glyfObject->glyf_data.simple.flags[i]);
        vector_push_back(points, (void*)(intptr_t)(prevX + glyfObject->glyf_data.simple.xCoordinates[i]));
        vector_push_back(points, (void*)(intptr_t)(prevY + glyfObject->glyf_data.simple.yCoordinates[i]));

        if (i == glyfObject->glyf_data.simple.endPtsOfContours[endPoint])
        {
            vector_push_back(points, (void*)TRUE);
            endPoint++;
        }
        else
        {
            vector_push_back(points, (void*)FALSE);
        }

        prevX += glyfObject->glyf_data.simple.xCoordinates[i];
        prevY += glyfObject->glyf_data.simple.yCoordinates[i];

        //printf("Point: %d %d\n", prevX, prevY);
    }

    return LF_ERROR_OK;
}

LF_ERROR GLYF_getCompositeGlyfPoints(glyf_table* table, glyf* glyfObject, LF_VECTOR* points)
{
    size_t i;
    size_t j = 0;
    glyf compGlyf;

    for (i = 0; i < glyfObject->glyf_data.composite.count; ++i)
    {
        composite_glyf* component = (composite_glyf*)vector_at(&glyfObject->glyf_data.composite, i);
        size_t startIndex = points->count;

        LF_ERROR error = GLYF_getGlyf(table, component->glyphIndex, &compGlyf);
        if (error != LF_ERROR_OK)
        {
            return error;
        }

        GLYF_getGlyfPointsInternal(table, &compGlyf, points);

        double xscale = 1.0;
        double yscale = 1.0;
        double scale10 = 0;
        double scale01 = 0;

        if (component->flags & WE_HAVE_A_SCALE)
        {
            xscale = yscale = (double)component->xscale / (double)0x4000;
        }
        else if (component->flags & WE_HAVE_AN_X_AND_Y_SCALE)
        {
            xscale = (double)component->xscale / (double)0x4000;
            yscale = (double)component->yscale / (double)0x4000;
        }
        else if (component->flags & WE_HAVE_A_TWO_BY_TWO)
        {
            xscale = (double)component->xscale / (double)0x4000;
            yscale = (double)component->yscale / (double)0x4000;
            scale10 = (double)component->scale10 / (double)0x4000;
            scale01 = (double)component->scale01 / (double)0x4000;
        }

        //loop through and apply scale and translations
        for (j = startIndex; j < points->count; j += 4)
        {
            int x = (SHORT)(intptr_t)vector_at(points, j + 1);
            int y = (SHORT)(intptr_t)vector_at(points, j + 2);

            SHORT newX = (SHORT)UTILS_round(x * xscale + y * scale10);
            SHORT newY = (SHORT)UTILS_round(x * scale01 + y * yscale);

            if (component->flags & ARGS_ARE_XY_VALUES)
            {
                newX += component->argument1;
                newY += component->argument2;
            }

            vector_set_data(points, j + 1, (void*)(intptr_t)newX);
            vector_set_data(points, j + 2, (void*)(intptr_t)newY);
        }

        GLYF_destroyGlyf(&compGlyf);
    }

    return LF_ERROR_OK;
}

LF_ERROR GLYF_getGlyfPointsInternal(glyf_table* table, glyf* glyfObject, LF_VECTOR* points)
{
    if (glyfObject->numberOfContours < 0)
    {
        return GLYF_getCompositeGlyfPoints(table, glyfObject, points);
    }

    return GLYF_getSimpleGlyfPoints(glyfObject, points);
}

LF_ERROR GLYF_getGlyfPoints(LF_FONT* lfFont, glyf* glyfObject, LF_VECTOR* points)
{
    glyf_table* table = (glyf_table*)map_at(&lfFont->table_map, (void*)TAG_GLYF);
    if (table == NULL)
        return LF_TABLE_MISSING;

    return GLYF_getGlyfPointsInternal(table, glyfObject, points);
}
