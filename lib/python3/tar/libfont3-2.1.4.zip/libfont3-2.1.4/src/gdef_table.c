// Copyright (C) 2014, 2015 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// gdef_table.c

#include <stdlib.h>
#include "gdef_table.h"
#include "utils.h"
#include "classdef.h"
#include "table_tags.h"

LF_ERROR GDEF_readTable(LF_FONT* lfFont, const sfnt_table_record* record, LF_STREAM* stream)
{
    if(STREAM_streamSeek(stream, record->offset) == 0)
    {
        size_t tableStart = STREAM_streamPos(stream);
        gdef_header* header = (gdef_header*)calloc(1, sizeof(gdef_header));
        OFFSET glyphOffset;
        OFFSET attachOffset;
        OFFSET ligCaretOffset;
        OFFSET markAttachOffset;
        OFFSET markGlyphOffset = 0;

        if(header == NULL)
            return LF_OUT_OF_MEMORY;

        header->isValid = TRUE;                         //TODO actually do validation

        header->Version = STREAM_readULong(stream);
        glyphOffset = STREAM_readOffset(stream);
        attachOffset = STREAM_readOffset(stream);
        ligCaretOffset = STREAM_readOffset(stream);
        markAttachOffset = STREAM_readOffset(stream);

        if(header->Version == 0x00010002)
            markGlyphOffset = STREAM_readOffset(stream);

        //glyph class def
        if(glyphOffset)
        {
            STREAM_streamSeek(stream, tableStart + glyphOffset);
            ClassDef_readTable(&header->GlyphClassDef, stream);
        }

        //attach list
        if(attachOffset)
        {
            STREAM_streamSeek(stream, tableStart + attachOffset);
            AttachmentList_readTable(&header->AttachList, stream);
        }

        //lig caret list
        if(ligCaretOffset)
        {
            STREAM_streamSeek(stream, tableStart + ligCaretOffset);
            LigCaretList_readTable(&header->LigCaretList, stream);
        }

        //mark attach class def
        if(markAttachOffset)
        {
            STREAM_streamSeek(stream, tableStart + markAttachOffset);
            ClassDef_readTable(&header->MarkAttachClassDef, stream);
        }

        //mark glyphs set def
        if(markGlyphOffset)
        {
            STREAM_streamSeek(stream, tableStart + markGlyphOffset);
        }

        map_insert(&lfFont->table_map, (void*)(intptr_t)record->tag, header);
        return LF_ERROR_OK;
    }

    return LF_INVALID_OFFSET;
}

boolean GDEF_isValid(LF_FONT* lfFont)
{
    gdef_header* header = (gdef_header*)map_at(&lfFont->table_map, (void*)TAG_GDEF);
    if (header == NULL)
        return FALSE;

    // NOTE: no actual validation is done for the GDEF table yet.

    return header->isValid;
}

LF_ERROR GDEF_isTableEmpty(LF_FONT* lfFont)
{
    gdef_header* header = (gdef_header*)map_at(&lfFont->table_map, (void*)TAG_GDEF);

    if (header == NULL)
        return LF_TABLE_MISSING;

    if ((header->GlyphClassDef.ClassFormat == 0) &&
        (header->AttachList.Coverage.CoverageFormat == 0) &&
        (header->LigCaretList.Coverage.CoverageFormat == 0) &&
        (header->MarkAttachClassDef.ClassFormat == 0) &&
        header->MarkGlyphSetsDef == 0)
    {
        return LF_EMPTY_TABLE;
    }

    return LF_ERROR_OK;
}

LF_ERROR GDEF_getTableSize(LF_FONT* lfFont, size_t* tableSize)
{
    *tableSize = 0;

    gdef_header* header = (gdef_header*)map_at(&lfFont->table_map, (void*)TAG_GDEF);
    if (header == NULL)
        return LF_TABLE_MISSING;

    if (header->calculatedTableSize != 0)
    {
        *tableSize = header->calculatedTableSize;
        return LF_ERROR_OK;
    }

    LF_ERROR error = LF_ERROR_OK;
    size_t subSize = 0;

    *tableSize = sizeof(ULONG) + sizeof(OFFSET) * 4;

    if(header->Version == 0x00010002)
        *tableSize += sizeof(OFFSET);

    if(header->GlyphClassDef.ClassFormat)
    {
        error = ClassDef_getTableSize(&header->GlyphClassDef, &subSize);
        *tableSize += subSize;
    }

    if ((error == LF_ERROR_OK) && (header->AttachList.Coverage.CoverageFormat))
    {
        error = AttachmentList_getTableSize(&header->AttachList, &subSize);
        *tableSize += subSize;
    }

    if ((error == LF_ERROR_OK) && (header->LigCaretList.Coverage.CoverageFormat))
    {
        error = LigCaretList_getTableSize(&header->LigCaretList, &subSize);
        *tableSize += subSize;
    }

    if((error == LF_ERROR_OK) && (header->MarkAttachClassDef.ClassFormat))
    {
        ClassDef_getTableSize(&header->MarkAttachClassDef, &subSize);
        *tableSize += subSize;
    }

    if (error == LF_ERROR_OK)
    {
        header->calculatedTableSize = *tableSize;
    }

    return error;
}

static BYTE* GDEF_buildTable(LF_FONT* lfFont, size_t* tableSize)
{
    gdef_header* header = (gdef_header*)map_at(&lfFont->table_map, (void*)TAG_GDEF);
    BYTE* tableData = NULL;

    if(LF_ERROR_OK == GDEF_getTableSize(lfFont, tableSize))
    {
        LF_STREAM stream;
        size_t current = 0, paddedSize;
        OFFSET nextTable = sizeof(ULONG) + sizeof(OFFSET) * 4;

        if(header->Version == 0x00010002)
            nextTable += sizeof(OFFSET);

        paddedSize = *tableSize;
        tableData = UTILS_AllocTable(&paddedSize);
        if (tableData == NULL)
            return NULL;

        STREAM_initMemStream(&stream, tableData, *tableSize);
        STREAM_writeULong(&stream, header->Version);

        //glyph class def
        if(header->GlyphClassDef.ClassFormat)
        {
            STREAM_writeOffset(&stream, nextTable);                            // write GlyphClassDef OFFSET
            current = STREAM_streamPos(&stream);
            STREAM_streamSeek(&stream, nextTable);

            if (LF_ERROR_OK != ClassDef_buildTable(&header->GlyphClassDef, &stream))
            {
                free(tableData);
                return NULL;
            }

            nextTable = (OFFSET)STREAM_streamPos(&stream);
            STREAM_streamSeek(&stream, current);
        }
        else
        {
            STREAM_writeOffset(&stream, 0);
        }

        if(header->AttachList.Coverage.CoverageFormat)
        {
            STREAM_writeOffset(&stream, (USHORT)nextTable);
            current = STREAM_streamPos(&stream);
            STREAM_streamSeek(&stream, nextTable);
            AttachmentList_buildTable(&header->AttachList, &stream);
            nextTable = (OFFSET)STREAM_streamPos(&stream);
            STREAM_streamSeek(&stream, current);
        }
        else
        {
            STREAM_writeOffset(&stream, 0);
        }

        // Tunga test font has a LigCaret offset but no actual entries so check for count instead
        // I think this is just a malformed font so not applying this strategy anywhere else
        //
        // Restoring this to the original code.  Make sure Coverage format is cleared on corrupt tables
//        if(header->LigCaretList.LigGlyph.count)
        if (header->LigCaretList.Coverage.CoverageFormat)
        {
            STREAM_writeOffset(&stream, (USHORT)nextTable);
            current = STREAM_streamPos(&stream);
            STREAM_streamSeek(&stream, nextTable);
            LigCaretList_buildTable(&header->LigCaretList, &stream);
            nextTable = (OFFSET)STREAM_streamPos(&stream);
            STREAM_streamSeek(&stream, current);
        }
        else
        {
            STREAM_writeOffset(&stream, 0);
        }

        //mark attach class def
        if(header->MarkAttachClassDef.ClassFormat)
        {
            STREAM_writeOffset(&stream, (USHORT)nextTable);
            current = STREAM_streamPos(&stream);
            STREAM_streamSeek(&stream, nextTable);
            ClassDef_buildTable(&header->MarkAttachClassDef, &stream);
            //nextTable = (OFFSET)STREAM_streamPos(&stream);
            STREAM_streamSeek(&stream, current);
        }
        else
        {
            STREAM_writeOffset(&stream, 0);
        }

        if(header->Version == 0x00010002)
        {
            STREAM_writeOffset(&stream, 0);
        }
    }

    return tableData;
}

LF_ERROR GDEF_writeTable(LF_FONT* lfFont, sfnt_table_record* record, LF_STREAM* stream)
{
    size_t table_size = 0;
    //ULONG padLen = 0;
    BYTE* tableData = GDEF_buildTable(lfFont, &table_size);
    if (tableData == NULL)
        return LF_OUT_OF_MEMORY;

    //UTILS_PadTable(&tableData, table_size, &padLen);

    record->checkSum = UTILS_CalcTableChecksum(tableData, table_size);
    record->length = (ULONG)table_size;
    record->offset = (ULONG)STREAM_streamPos(stream);

    STREAM_writeChunk(stream, tableData, (table_size + 3) & ~3);
    free(tableData);

    return LF_ERROR_OK;
}

LF_ERROR GDEF_freeTable(LF_FONT* lfFont)
{
    gdef_header* header = (gdef_header*)map_at(&lfFont->table_map, (void*)TAG_GDEF);

    if (header)
    {
        if (header->GlyphClassDef.ClassFormat)
            ClassDef_freeTable(&header->GlyphClassDef);

        if (header->AttachList.Coverage.CoverageFormat)
            AttachmentList_freeTable(&header->AttachList);

        if (header->LigCaretList.Coverage.CoverageFormat)
            LigCaretList_freeTable(&header->LigCaretList);

        if (header->MarkAttachClassDef.ClassFormat)
            ClassDef_freeTable(&header->MarkAttachClassDef);

        free(header);
    }

    return LF_ERROR_OK;
}

void GDEF_removeGlyph(LF_FONT* lfFont, GlyphID index)
{
    gdef_header* header = (gdef_header*)map_at(&lfFont->table_map, (void*)TAG_GDEF);

    if (header)
    {
        USHORT  removeSet;
        ULONG   coverageIndex;

        header->calculatedTableSize = 0;

        if (header->GlyphClassDef.ClassFormat)
        {
            LF_ERROR error = ClassDef_removeGlyph(&header->GlyphClassDef, index, &removeSet);
            if(error == LF_EMPTY_TABLE)
                ClassDef_freeTable(&header->GlyphClassDef);
        }

        if (header->AttachList.Coverage.CoverageFormat)
        {
            LF_ERROR error = Coverage_removeGlyphIndex(&header->AttachList.Coverage, index, &coverageIndex);
            if(error == LF_ERROR_OK)
            {
                LF_VECTOR* Points = (LF_VECTOR *)vector_at(&header->AttachList.AttachPoints, coverageIndex);
                vector_free(Points);
                free(Points);
                vector_erase(&header->AttachList.AttachPoints, coverageIndex);
            }
            else if(error == LF_EMPTY_TABLE)
            {
                AttachmentList_freeTable(&header->AttachList);
            }
        }

        if (header->LigCaretList.Coverage.CoverageFormat)
        {
            LF_ERROR error = Coverage_removeGlyphIndex(&header->LigCaretList.Coverage, index, &coverageIndex);
            if (error == LF_ERROR_OK)
            {
                LF_VECTOR* caretList = (LF_VECTOR*)vector_at(&header->LigCaretList.LigGlyph, coverageIndex);
                ULONG j;
                for (j = 0; j < caretList->count; j++)
                {
                    caret_value* caretValue = (caret_value*)vector_at(caretList, j);
                    free(caretValue);
                }
                vector_free(caretList);
                free(caretList);
                vector_erase(&header->LigCaretList.LigGlyph, coverageIndex);
            }
            else if(error == LF_EMPTY_TABLE)
            {
                LigCaretList_freeTable(&header->LigCaretList);
            }
        }

        if (header->MarkAttachClassDef.ClassFormat)
        {
            LF_ERROR error = ClassDef_removeGlyph(&header->MarkAttachClassDef, index, &removeSet);
            if(error == LF_EMPTY_TABLE)
                ClassDef_freeTable(&header->MarkAttachClassDef);
        }
    }
}

LF_ERROR GDEF_remapAll(LF_FONT* lfFont, LF_MAP* remap)
{
    gdef_header* header = (gdef_header*)map_at(&lfFont->table_map, (void*)TAG_GDEF);

    if (header)
    {
        ClassDef_remapGlyphs(&header->GlyphClassDef, remap);
        ClassDef_remapGlyphs(&header->MarkAttachClassDef, remap);

        if (header->AttachList.Coverage.CoverageFormat)
            Coverage_remapAll(&header->AttachList.Coverage, remap);

        if (header->LigCaretList.Coverage.CoverageFormat)
        {
            Coverage_remapAll(&header->LigCaretList.Coverage, remap);
        }
    }

    return LF_ERROR_OK;
}
