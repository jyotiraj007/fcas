/* ----------------------------------------------------------------------------
    Copyright (C) 2014, 2015 Monotype Imaging Inc. All rights reserved.
    Confidential information of Monotype Imaging Inc.
    File    :   lf_valign.c
    Date    :   Jan. 7/2015
---------------------------------------------------------------------------- */
/// \file lf_valign.c

#include "lf_valign.h"
#include "utils.h"
#include "sfnt_core.h"
#include "hhea_table.h"
#include "os2_table.h"

/**
* @defgroup VERTALIGN Vertical Alignment API
* @brief Vertical Alignment API Function
* @{
*/

/**
    Sets the HHEA ascent, descent, and linegap to be equivalent to the OS/2
    values.  Takes into account the sign difference for the descent values.
    @param[in] lfFont font object
    @note This routine can be used with or without subsetting. If called
    with subsetting, it is recommended that it be called after calling
    LF_subsetFont. If called without subsetting, the checksum for the HHEA
    table as well as the checksum adjustment for the font in the head table
    are properly updated.
*/

/* ----------------------------------------------------------------------------
    @see also
        http://jira.monotype.com:8080/browse/LIB-43
---------------------------------------------------------------------------- */
LF_API LF_ERROR LF_applyVerticalAlignment(LF_FONT* lfFont)
{
    boolean didVAUnpacking = FALSE;
    LF_ERROR error;

    if (lfFont == NULL)
        return LF_INVALID_PARAM;

    SFNT_clearSFNT(lfFont);

    if (SFNT_tablesUnpacked(lfFont) == FALSE)
    {
        error = SFNT_unpackVAlignTable(lfFont);

        if (error != LF_ERROR_OK)
        {
            DEBUG_LOG_ERROR("unable to unpack tables for vertical alignment");
            return error;
        }

        didVAUnpacking = TRUE;
    }

    FWORD value;

    error = OS2_getAscent(lfFont, &value);
    if (error == LF_ERROR_OK)
    {
        HHEA_setAscender(lfFont, value);

        error = OS2_getDescent(lfFont, &value);
        if (error == LF_ERROR_OK)
        {
            HHEA_setDescender(lfFont, -value);
            HHEA_setLineGap(lfFont, 0);

            if (TRUE == didVAUnpacking)
            {
                // This writes the HHEA table back into the original stream.  This is
                // done because no other tables were unpacked (no subset occurred) in
                // the lfFont.  So this call will update the stream, and then
                // clean up the OS/2 and HHEA tables that were unpacked.
                error = SFNT_packVAlignTable(lfFont);
            }
        }
    }

    return error;
}

/** @} */ // end of VERTALIGN group
