// Copyright (C) 2014, 2016 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// gpos_marktomark.c

#include <stdlib.h>
#include "coverage_table.h"
#include "gpos_lookup/gpos_marktomark.h"
#include "mark_array.h"

static LF_ERROR GPOS_readMark2Array(gpos_marktomark* table, LF_STREAM* stream)
{
    size_t tableStart = STREAM_streamPos(stream);
    size_t currPos;
    USHORT mark2Count = STREAM_readUShort(stream);
    USHORT i = 0, j = 0;

    vector_init(&table->Mark2Array, mark2Count, 4);

    for(i = 0; i < mark2Count; i ++)
    {
        LF_VECTOR* record = vector_create(table->ClassCount, 4);

        for(j = 0; j < table->ClassCount; j++)
        {
            OFFSET anchorOffset = STREAM_readOffset(stream);

            if (anchorOffset)
            {
                anchor_table* anchorTable = (anchor_table*)malloc(sizeof(anchor_table));

                currPos = STREAM_streamPos(stream);
                STREAM_streamSeek(stream, tableStart + anchorOffset);
                Anchor_readTable(anchorTable, stream);

                vector_push_back(record, anchorTable);
                STREAM_streamSeek(stream, currPos);
            }
            else
            {
                vector_push_back(record, NULL);
            }
        }

        vector_push_back(&table->Mark2Array, record);
    }

    return LF_ERROR_OK;
}

TABLE_HANDLE GPOS_readMarkToMark(LF_STREAM* stream)
{
    gpos_marktomark* table = (gpos_marktomark*)malloc(sizeof(gpos_marktomark));
    size_t tableStart = STREAM_streamPos(stream);
    size_t oldOffset = 0;
    size_t coverageOffset = 0;
    size_t markOffset = 0;
    size_t baseOffset = 0;

    if(table == NULL)
        return NULL;

    table->PosFormat = STREAM_readUShort(stream);

    //read mark coverage
    coverageOffset = STREAM_readOffset(stream);
    oldOffset = STREAM_streamPos(stream);
    STREAM_streamSeek(stream, tableStart + coverageOffset);
    Coverage_readTable(&table->Mark1Coverage, stream);
    STREAM_streamSeek(stream, oldOffset);

    //read base coverage
    coverageOffset = STREAM_readOffset(stream);
    oldOffset = STREAM_streamPos(stream);
    STREAM_streamSeek(stream, tableStart + coverageOffset);
    Coverage_readTable(&table->Mark2Coverage, stream);
    STREAM_streamSeek(stream, oldOffset);

    table->ClassCount = STREAM_readUShort(stream);
    markOffset = STREAM_readOffset(stream);
    baseOffset = STREAM_readOffset(stream);

    STREAM_streamSeek(stream, tableStart + markOffset);
    Mark_readArray(&table->Mark1Array, stream);

    //read BaseArray table
    STREAM_streamSeek(stream, tableStart + baseOffset);
    GPOS_readMark2Array(table, stream);

    return table;
}

size_t GPOS_getMarkToMarkSize(gpos_marktomark* table)
{
    size_t tableSize = sizeof(USHORT) * 2 + sizeof(OFFSET) * 4;
    size_t markSize = 0;
    size_t baseSize = 0;
    ULONG i = 0, j = 0;

    Coverage_getTableSize(&table->Mark1Coverage, &markSize);
    Coverage_getTableSize(&table->Mark2Coverage, &baseSize);
    tableSize += markSize + baseSize;

    Mark_getArraySize(&table->Mark1Array, &markSize);
    baseSize = sizeof(USHORT);

    for(i = 0; i < table->Mark2Array.count; i++)
    {
        LF_VECTOR* baseRecord = (LF_VECTOR*)vector_at(&table->Mark2Array, i);

        for(j = 0; j < baseRecord->count; j++)
        {
            size_t anchorSize = 0;
            anchor_table* at = (anchor_table*)vector_at(baseRecord, j);
            if (at)
                Anchor_getTableSize(at, &anchorSize);
            baseSize += anchorSize + sizeof(OFFSET);
        }
    }

    tableSize += markSize + baseSize;

    //tableSize = (tableSize + 3) & ~3;
    return tableSize;
}

static LF_ERROR GPOS_buildMark2Array(gpos_marktomark* table, LF_STREAM* stream)
{
    size_t baseStart = STREAM_streamPos(stream);
    size_t currPos;
    size_t baseEnd = baseStart + sizeof(USHORT) + sizeof(OFFSET) * table->Mark2Array.count * table->ClassCount;
    ULONG i = 0, j = 0;

    STREAM_writeUShort(stream, (USHORT)table->Mark2Array.count);

    for(i = 0; i < table->Mark2Array.count; i++)
    {
        LF_VECTOR* record = (LF_VECTOR*)vector_at(&table->Mark2Array, i);

        for(j = 0; j < record->count; j++)
        {
            anchor_table* at = (anchor_table*)vector_at(record, j);

            if (at != NULL)
                STREAM_writeOffset(stream, (USHORT)(baseEnd - baseStart));
            else
                STREAM_writeOffset(stream, 0);

            currPos = STREAM_streamPos(stream);
            STREAM_streamSeek(stream, baseEnd);

            if (at != NULL)
                Anchor_buildTable(at, stream);

            baseEnd = STREAM_streamPos(stream);        // Keep track of current table write stream location
            STREAM_streamSeek(stream, currPos);
        }
    }
    STREAM_streamSeek(stream,baseEnd);                // Restore us to the end of the write stream for caller to determine size
    return LF_ERROR_OK;
}

size_t GPOS_buildMarkToMark(gpos_marktomark* table, LF_STREAM* stream)
{
    size_t tableStart = STREAM_streamPos(stream);
    size_t currPos;
    size_t endPos = sizeof(USHORT) * 2 + sizeof(OFFSET) * 4;

    STREAM_writeUShort(stream, table->PosFormat);

    //write mark coverage table
    STREAM_writeOffset(stream, (OFFSET)endPos);
    currPos = STREAM_streamPos(stream);
    STREAM_streamSeek(stream, tableStart + endPos);
    Coverage_buildTable(&table->Mark1Coverage, stream);
    endPos = STREAM_streamPos(stream) - tableStart;

    //write base coverage table
    STREAM_streamSeek(stream, currPos);
    STREAM_writeOffset(stream, (OFFSET)endPos);
    currPos = STREAM_streamPos(stream);
    STREAM_streamSeek(stream, tableStart + endPos);
    Coverage_buildTable(&table->Mark2Coverage, stream);
    endPos = STREAM_streamPos(stream) - tableStart;

    STREAM_streamSeek(stream, currPos);
    STREAM_writeUShort(stream, table->ClassCount);

    //write mark array
    STREAM_writeOffset(stream, (OFFSET)endPos);
    currPos = STREAM_streamPos(stream);
    STREAM_streamSeek(stream, tableStart + endPos);
    Mark_buildArray(&table->Mark1Array, stream);
    endPos = STREAM_streamPos(stream) - tableStart;

    //write base array table
    STREAM_streamSeek(stream, currPos);
    STREAM_writeOffset(stream, (OFFSET)endPos);
    STREAM_streamSeek(stream, tableStart + endPos);
    GPOS_buildMark2Array(table, stream);

    return STREAM_streamPos(stream) - tableStart;
}

LF_ERROR GPOS_markToMarkRemoveGlyph(gpos_marktomark* table, GlyphID glyphID)
{
    ULONG index,i = 0;
    LF_ERROR error = Coverage_removeGlyphIndex(&table->Mark1Coverage, glyphID, &index);

    if (error != LF_EMPTY_TABLE)
    {
        if(error == LF_ERROR_OK)
        {
            error = Mark_removeAtIndex(&table->Mark1Array, index);
        }

        error = Coverage_removeGlyphIndex(&table->Mark2Coverage, glyphID, &index);
        if (error == LF_EMPTY_TABLE)
            return error;

        if(error == LF_ERROR_OK)
        {
            // Retrieve the base record and free up all of its anchor tables.  One per class
            LF_VECTOR* baseRecord = (LF_VECTOR*)vector_at(&table->Mark2Array, index);
            if (baseRecord)
            {
                for(i = 0;i < table->ClassCount;i++)
                {
                    free((anchor_table*)vector_at(baseRecord, i));
                }
                vector_delete(baseRecord);
                free(baseRecord);
            }

            error = vector_erase(&table->Mark2Array, index);
        }
    }
    return error;
}

LF_ERROR GPOS_markToMarkRemapTable(gpos_marktomark* table, LF_MAP *remap)
{
    LF_ERROR error = Coverage_remapAll(&table->Mark1Coverage, remap);

    if((error == LF_ERROR_OK) || (error == LF_EMPTY_TABLE))
    {
        error = Coverage_remapAll(&table->Mark2Coverage, remap);
    }

    return error;
}

LF_ERROR GPOS_markToMarkSetAnchorFmt1(gpos_marktomark* table)
{
    for (size_t i = 0; i < table->Mark2Array.count; i++)
    {
        LF_VECTOR* record = (LF_VECTOR*)vector_at(&table->Mark2Array, i);

        for (size_t j = 0; j < record->count; j++)
        {
            anchor_table* anchor = (anchor_table*)vector_at(record, j);

            if (anchor != NULL && anchor->AnchorFormat == 2)
                anchor->AnchorFormat = 1;
        }
    }

    return Mark_setAnchorFormat1(&table->Mark1Array);
}

#ifdef LF_OT_DUMP
#include "utils.h"

/* ============================================================================
    @summary
        dump the mark to mark structure

============================================================================ */
LF_ERROR GPOS_dumpMarkToMark(gpos_marktomark* table)
{
    XML_START("GPOSMarkToMark");
    XML_DATA_NODE("PosFormat", table->PosFormat);

    XML_START("Mark1Coverage");
    Coverage_dumpTable(&table->Mark1Coverage);
    XML_END("Mark1Coverage");

    XML_START("Mark2Coverage");
    Coverage_dumpTable(&table->Mark2Coverage);
    XML_END("Mark2Coverage");


    // TODO: finish writing the rest of the dump


    XML_END("GPOSMarkToMark");
    return LF_ERROR_OK;
}
#endif


/* ============================================================================
    @summary
        free up the mark to mark structure

============================================================================ */
void GPOS_freeMarkToMark(gpos_marktomark* mm)
{
    ULONG i = 0;
    Coverage_deleteTable(&mm->Mark1Coverage);
    Coverage_deleteTable(&mm->Mark2Coverage);

    while (i < vector_size(&mm->Mark1Array))
    {
        anchor_table* anchor = (anchor_table*)vector_at(&mm->Mark1Array, i++);
        if (anchor != NULL)
        {
            Anchor_freeTable(anchor);
            free(anchor);
        }
    };

    vector_delete(&mm->Mark1Array);

    i = 0;
    while (i < vector_size(&mm->Mark2Array))
    {
        LF_VECTOR* record = (LF_VECTOR*)vector_at(&mm->Mark2Array, i++);
        int j;

        for (j = 0; j < mm->ClassCount; j++)
        {
            anchor_table* anchor = (anchor_table*)vector_at(record, j);
            if (anchor != NULL)
            {
                Anchor_freeTable(anchor);
                free(anchor);
            }
        }
        vector_delete(record);
        free(record);
    };

    vector_delete(&mm->Mark2Array);

    free(mm);
}
