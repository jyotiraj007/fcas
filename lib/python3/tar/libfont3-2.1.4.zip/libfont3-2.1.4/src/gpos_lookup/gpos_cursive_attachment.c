// Copyright (C) 2014 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// gpos_cursive_attachment.c

#include <stdlib.h>
#include "gpos_lookup/gpos_cursive_attachment.h"
#include "coverage_table.h"
#include "utils.h"

TABLE_HANDLE GPOS_readCursiveAttachment(LF_STREAM* stream)
{
    gpos_cursive_attachment* table;
    size_t tableStart = STREAM_streamPos(stream);
    size_t oldOffset;
    OFFSET coverageOffset;
    USHORT entryCount;
    USHORT i;

    table = (gpos_cursive_attachment*)malloc(sizeof(gpos_cursive_attachment));
    if(table == NULL)
        return NULL;

    table->PosFormat = STREAM_readUShort(stream);

    //read the coverage table offset and read the coverage table data
    coverageOffset = STREAM_readOffset(stream);
    oldOffset = STREAM_streamPos(stream);
    STREAM_streamSeek(stream, tableStart + coverageOffset);
    Coverage_readTable(&table->Coverage, stream);
    STREAM_streamSeek(stream, oldOffset);

    entryCount = STREAM_readUShort(stream);
    vector_init(&table->EntryExitRecords, entryCount, 4);

    for(i = 0; i < entryCount; i++)
    {
        OFFSET entryOffset = STREAM_readOffset(stream);
        OFFSET exitOffset = STREAM_readOffset(stream);
        entry_exit_record* record = (entry_exit_record*)calloc(1, sizeof(entry_exit_record));

        if(record == NULL)
        {
            GPOS_freeCursiveAttach(table);
            return NULL;
        }

        oldOffset = STREAM_streamPos(stream);
        if (entryOffset)
        {
            STREAM_streamSeek(stream, tableStart + entryOffset);
            Anchor_readTable(&record->EntryAnchor, stream);
        }
        else
        {
            record->EntryAnchor.AnchorFormat = 0;
        }

        if (exitOffset)
        {
            STREAM_streamSeek(stream, tableStart + exitOffset);
            Anchor_readTable(&record->ExitAnchor, stream);
        }
        else
        {
            record->ExitAnchor.AnchorFormat = 0;
        }

        STREAM_streamSeek(stream, oldOffset);
        vector_push_back(&table->EntryExitRecords, record);
    }

    return table;
}

size_t GPOS_getCursiveAttachmentSize(gpos_cursive_attachment* table)
{
    size_t tableSize = 0;
    ULONG i = 0;

    Coverage_getTableSize(&table->Coverage, &tableSize);
    tableSize += sizeof(USHORT) * 2 + sizeof(OFFSET);
    tableSize += sizeof(OFFSET) * table->EntryExitRecords.count * 2;

    for(; i < table->EntryExitRecords.count; i++)
    {
        entry_exit_record* record = (entry_exit_record*)vector_at(&table->EntryExitRecords, i);
        size_t recordSize = 0;
        size_t anchorSize = 0;

        Anchor_getTableSize(&record->EntryAnchor, &anchorSize);
        recordSize += anchorSize;

        Anchor_getTableSize(&record->ExitAnchor, &anchorSize);
        recordSize += anchorSize;

        tableSize += recordSize;
    }

    //tableSize = (tableSize + 3) & ~3;
    return tableSize;
}

size_t GPOS_buildCursiveAttachment(gpos_cursive_attachment* table, LF_STREAM* stream)
{
    size_t tableStart = STREAM_streamPos(stream);
    size_t anchorOffset;
    size_t recordOffset;
    size_t coverageOffset = sizeof(USHORT) * 2 + sizeof(OFFSET) + sizeof(OFFSET) * table->EntryExitRecords.count * 2;
    ULONG i = 0;

    STREAM_writeUShort(stream, table->PosFormat);
    STREAM_writeOffset(stream, (OFFSET)coverageOffset);
    STREAM_writeUShort(stream, (USHORT)table->EntryExitRecords.count);
    recordOffset = STREAM_streamPos(stream);

    STREAM_streamSeek(stream, tableStart + coverageOffset);
    Coverage_buildTable(&table->Coverage, stream);
    anchorOffset = STREAM_streamPos(stream);

    for(; i < table->EntryExitRecords.count; i++)
    {
        entry_exit_record* record = (entry_exit_record*)vector_at(&table->EntryExitRecords, i);
        size_t entryOffset = anchorOffset;
        size_t exitOffset;

        STREAM_streamSeek(stream, entryOffset);
        if (record->EntryAnchor.AnchorFormat)
        {
            Anchor_buildTable(&record->EntryAnchor, stream);
            entryOffset = entryOffset - tableStart;
        }
        else
        {
            entryOffset = 0;
        }

        exitOffset = STREAM_streamPos(stream);

        if (record->ExitAnchor.AnchorFormat)
        {
            Anchor_buildTable(&record->ExitAnchor, stream);
            exitOffset = exitOffset - tableStart;
        }
        else
        {
            exitOffset = 0;
        }
            
        anchorOffset = STREAM_streamPos(stream);

        STREAM_streamSeek(stream, recordOffset);
        STREAM_writeOffset(stream, (OFFSET)(entryOffset));
        STREAM_writeOffset(stream, (OFFSET)(exitOffset));
        recordOffset = STREAM_streamPos(stream);
    }
    STREAM_streamSeek(stream, anchorOffset);            // Return to end of table to calculate a valid table size
    return STREAM_streamPos(stream) - tableStart;
}

LF_ERROR GPOS_cursiveAttachRemoveGlyph(gpos_cursive_attachment* table, GlyphID glyphID)
{
    entry_exit_record* record = NULL;
    ULONG index = 0;
    LF_ERROR error;

    error = Coverage_removeGlyphIndex(&table->Coverage, glyphID, &index);

    if (error == LF_ERROR_OK)
    {
        record = (entry_exit_record*)vector_at(&table->EntryExitRecords, index);

        if(record)
        {
            Anchor_freeTable(&record->EntryAnchor);
            Anchor_freeTable(&record->ExitAnchor);
            FREE(record);
            vector_erase(&table->EntryExitRecords, index);
        }
    }
    return error;
}

LF_ERROR GPOS_cursiveAttachRemapTable(gpos_cursive_attachment* table, LF_MAP *remap)
{
    return Coverage_remapAll(&table->Coverage, remap);
}

LF_ERROR GPOS_cursiveAttachmentSetAnchorFmt1(gpos_cursive_attachment* table)
{
    for (size_t i = 0; i < table->EntryExitRecords.count; i++)
    {
        entry_exit_record* record = (entry_exit_record*)vector_at(&table->EntryExitRecords, i);

        if (record->EntryAnchor.AnchorFormat == 2)
            record->EntryAnchor.AnchorFormat = 1;
        if (record->ExitAnchor.AnchorFormat == 2)
            record->ExitAnchor.AnchorFormat = 1;
    }

    return LF_ERROR_OK;
}

#ifdef LF_OT_DUMP
LF_ERROR GPOS_dumpCursiveAttach(gpos_cursive_attachment* table)
{
    ULONG i;
    XML_START("GPOSCursiveAttach");

    XML_DATA_NODE("PosFormat", table->PosFormat);
    Coverage_dumpTable(&table->Coverage);

    for(i = 0; i < table->EntryExitRecords.count; i++)
    {
        entry_exit_record* record = (entry_exit_record*)vector_at(&table->EntryExitRecords, i);

        XML_START_COMMENT("EntryExitRecord", i, (int)table->EntryExitRecords.count - 1);
        XML_START("EntryAnchor");
        Anchor_dumpTable(&record->EntryAnchor);
        XML_END("EntryAnchor");

        XML_START("ExitAnchor");
        Anchor_dumpTable(&record->ExitAnchor);
        XML_END("ExitAnchor");
        XML_END("EntryExitRecord");
    }

    XML_END("GPOSCursiveAttach");

    return LF_ERROR_OK;
}
#endif

void GPOS_freeCursiveAttach(gpos_cursive_attachment* table)
{
    ULONG i = 0;
    Coverage_deleteTable(&table->Coverage);

    while (i < table->EntryExitRecords.count)
    {
        entry_exit_record* record = (entry_exit_record*)vector_at(&table->EntryExitRecords, i++);

        Anchor_freeTable(&record->EntryAnchor);
        Anchor_freeTable(&record->ExitAnchor);
        free(record);
    }
    vector_delete(&table->EntryExitRecords);

    free(table);
}
