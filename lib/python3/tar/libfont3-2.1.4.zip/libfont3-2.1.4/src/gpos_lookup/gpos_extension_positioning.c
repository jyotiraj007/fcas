// Copyright (C) 2014 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// gpos_extension_positioning.c

#include <stdlib.h>
#include "gpos_lookup/gpos_extension_positioning.h"
#include "gpos_table.h"

TABLE_HANDLE GPOS_readExtensionPositioning(LF_STREAM* stream)
{
    size_t tableStart = STREAM_streamPos(stream);
    USHORT PosFormat = STREAM_readUShort(stream);
    USHORT ExtensionLookupType = STREAM_readUShort(stream);
    ULONG ExtensionOffset = STREAM_readULong(stream);

    (void)PosFormat;

    STREAM_streamSeek(stream, tableStart + ExtensionOffset);

    return GPOS_readSubtable(ExtensionLookupType, stream);
}
