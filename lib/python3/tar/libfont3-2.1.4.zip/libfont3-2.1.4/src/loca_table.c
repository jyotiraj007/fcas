// Copyright (C) 2014, 2015 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// loca_table.c

#include <stdlib.h>
#include "loca_table.h"
#include "utils.h"
#include "head_table.h"
#include "maxp_table.h"

LF_ERROR LOCA_readTable(LF_FONT* lfFont, const sfnt_table_record* record, LF_STREAM* stream)
{
    if (STREAM_streamSeek(stream, record->offset) == 0)
    {
        if (record->length > 0)
        {
            SHORT locFmt;
            USHORT i, numGlyphs = MAXP_getNumGlyphs(lfFont);
            ULONG offset;
            loca_table* table = (loca_table*)calloc(1, sizeof(loca_table));

            if (table == NULL)
                return LF_OUT_OF_MEMORY;

            if (LF_ERROR_OK != vector_init(&table->locaData, numGlyphs+1, 4))
            {
                free(table);
                return LF_OUT_OF_MEMORY;
            }

            locFmt = HEAD_getLocFormat(lfFont);

            for (i = 0; i < numGlyphs; i++)
            {
                offset = (locFmt) ? STREAM_readULong(stream) : (ULONG)STREAM_readUShort(stream);

                vector_push_back(&table->locaData, (void*)(intptr_t)offset);
            }
            offset = (locFmt) ? STREAM_readULong(stream) : (ULONG)STREAM_readUShort(stream);
            vector_push_back(&table->locaData, (void*)(intptr_t)offset);

            map_insert(&lfFont->table_map, (void*)(intptr_t)record->tag, table);

            return LF_ERROR_OK;
        }
    }

    return LF_INVALID_OFFSET;
}

// create an empty loca table and add it to the map.
LF_ERROR LOCA_createTable(LF_FONT* lfFont, ULONG numGlyphs)
{
    loca_table* table;

    table = (loca_table*)calloc(1, sizeof(loca_table));
    if(table == NULL)
        return LF_OUT_OF_MEMORY;

    if (LF_ERROR_OK != vector_init(&table->locaData, numGlyphs+1, 4))
    {
        free(table);
        return LF_OUT_OF_MEMORY;
    }

    table->locaData.count = numGlyphs+1;  // for performance, since the vector_init does a calloc, so everything is zero already

    map_insert(&lfFont->table_map, (void*)TAG_LOCA, table);

    return LF_ERROR_OK;
}

LF_ERROR LOCA_getTableSize(LF_FONT* lfFont, size_t *tableSize)
{
    loca_table* table;
    head_table* tableh;

    *tableSize = 0;

    tableh = (head_table*)map_at(&lfFont->table_map, (void*)TAG_HEAD);
    table = (loca_table*)map_at(&lfFont->table_map, (void*)TAG_LOCA);
    if((table == NULL) || (tableh == NULL))
        return LF_EMPTY_TABLE;

    size_t numRemaining = table->locaData.count - 1 - table->numRemoved;

    if(HEAD_getLocFormat(lfFont) == 1)
        *tableSize = sizeof(ULONG) * (numRemaining + 1);
    else
        *tableSize = sizeof(USHORT) * (numRemaining + 1);

    return LF_ERROR_OK;
}

// TODO this function is not called yet
LF_ERROR LOCA_shrinkFormat(LF_FONT* lfFont)
{
    loca_table* table = (loca_table*)map_at(&lfFont->table_map, (void*)TAG_LOCA);
    if (table == NULL)
        return LF_TABLE_MISSING;

    // note this should be called after creation of the glyf table
    // but prior to writing the loca table. At which point only up to numGlyphs
    // entries in the vector are valid.

    //TODO - add a flag to the glyf table to indicate that the table has been calculated (similar to cmap)

    if(HEAD_getLocFormat(lfFont) == 1)
    {
        const ULONG maxFormatZeroOffset = 131070; // (2^16 -1 * 2)

        USHORT numGlyphs = MAXP_getNumGlyphs(lfFont);

        // index numGlyphs has the size of the glyf table
        ULONG offset = (ULONG)(intptr_t)vector_at(&table->locaData, numGlyphs);

        if (offset > maxFormatZeroOffset)
            return LF_ERROR_OK; // not able to shrink

        void** ptr = table->locaData.vector_array; // direct access to array for speed

        for (size_t i = 0; i <= numGlyphs; i++, ptr++)
        {
            ULONG temp = (ULONG)(intptr_t)(*ptr);
            *ptr = (void*)(intptr_t)(USHORT)(temp >> 1);
            ASSERT(temp != LOCA_MARK_REMOVED);
        }

        HEAD_setLocFormat(lfFont, 0);
    }

    return LF_ERROR_OK;
}

LF_ERROR LOCA_writeTable(LF_FONT* lfFont, sfnt_table_record* record, LF_STREAM* stream)
{
    loca_table* table = (loca_table*)map_at(&lfFont->table_map, (void*)TAG_LOCA);
    if (table == NULL)
        return LF_TABLE_MISSING;

    SHORT locFmt = HEAD_getLocFormat(lfFont);
    if (locFmt == -1)
        return LF_TABLE_MISSING;

    size_t tableSize;
    LF_ERROR error = LOCA_getTableSize(lfFont, &tableSize);
    if (error != LF_ERROR_OK)
        return error;

    LF_STREAM memStream;
    size_t paddedSize = (ULONG)((tableSize + 3) & ~3);
    STREAM_createMemStream(&memStream, paddedSize);
    if (!STREAM_isValid(memStream))
        return LF_OUT_OF_MEMORY;

    // The glyf table code has called LOCA_setOffset with the NEW index, not the old index
    // so the buffer in the vector has valid values only in 0 - nGlyphs in subset (including the extra slot for the table size)
    size_t numRemaining = table->locaData.count /*- 1*/ - table->numRemoved;

    for (size_t i = 0; i < numRemaining; i++)      // numRemaining includes the extra slot at the end
    {
        ULONG value = (ULONG)(intptr_t)vector_at(&table->locaData, i);

        //if (value != LOCA_MARK_REMOVED)               // don't need this check since the glyf table has updated the buffer
        {
            if (locFmt == 1)
                STREAM_writeULong(&memStream, value);
            else
                STREAM_writeUShort(&memStream, (USHORT)value);
        }
    }

    //ULONG padLen;
    //UTILS_PadTable(&memStream.Base, tableSize, &padLen);

    record->checkSum = UTILS_CalcTableChecksum(memStream.Base, tableSize);
    record->length = (ULONG)tableSize;
    record->offset = (ULONG)STREAM_streamPos(stream);

    STREAM_streamSeek(stream, record->offset);
    STREAM_writeChunk(stream, memStream.Base, paddedSize);

    free(memStream.Base);

    return LF_ERROR_OK;
}

locaIterator* LOCA_iteratorCreate(LF_FONT* lfFont)
{
    loca_table* table = (loca_table*)map_at(&lfFont->table_map, (void*)TAG_LOCA);
    locaIterator* iter;

    if(table == NULL)
        return NULL;

    iter = (locaIterator*)malloc(sizeof(locaIterator));
    if(iter == NULL)
        return NULL;

    iter->table = table;
    iter->curIndex = 0;
    iter->format = HEAD_getLocFormat(lfFont);
    iter->nextOffset = (ULONG)(intptr_t)vector_at(&iter->table->locaData, 0);

    return iter;
}

LF_ERROR LOCA_iteratorNext(locaIterator* iter, ULONG* offset, ULONG* size)
{
    ULONG next;

    *offset = iter->nextOffset;

    next = (ULONG)(intptr_t)vector_at(&iter->table->locaData, iter->curIndex+1);

    if (next < *offset)
        return LF_BAD_FORMAT;

    *size = next - *offset;

    if (iter->format != 1)
    {
        *offset *= 2;
        *size *= 2;
    }

    iter->curIndex++;
    iter->nextOffset = next;

    return LF_ERROR_OK;
}

void LOCA_iteratorDelete(locaIterator* iter)
{
    free(iter);
}

void LOCA_setOffset(LF_FONT* lfFont, USHORT index, ULONG offset)
{
    loca_table* table = (loca_table*)map_at(&lfFont->table_map, (void*)TAG_LOCA);

    if (HEAD_getLocFormat(lfFont) != 1)
        offset /= 2;

    vector_set_data(&table->locaData, index, (void*)(intptr_t)offset);
}

void LOCA_removeGlyph(const LF_FONT* lfFont, ULONG index)
{
    loca_table* table = (loca_table*)map_at(&lfFont->table_map, (void*)TAG_LOCA);
    if (table == NULL)
        return;

    if (LOCA_MARK_REMOVED != (ULONG)(intptr_t)vector_at(&table->locaData, index))  // this check is probably not needed but gaurds against double counting removed glyphs
        table->numRemoved++;

    // mark offset as removed
    vector_set_data(&table->locaData, index, (void*)(long)LOCA_MARK_REMOVED);
}

LF_ERROR LOCA_freeTable(const LF_FONT* lfFont)
{
    loca_table* table = (loca_table*)map_at(&lfFont->table_map, (void*)TAG_LOCA);

    if(table != NULL)
    {
        vector_delete(&table->locaData);
        free(table);
    }

    return LF_ERROR_OK;
}
