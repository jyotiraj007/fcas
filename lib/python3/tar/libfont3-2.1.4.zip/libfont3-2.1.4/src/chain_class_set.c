// Copyright (C) 2014 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// chain_class_set.c

#include <memory.h>
#include "utils.h"
#include "stream.h"
#include "chain_class_set.h"


/* ****************************************************************************

                CHAIN CLASS SETS FUNCTIONS

**************************************************************************** */
LF_ERROR ChainClassSets_pruneLookupRecords(LF_VECTOR* ccss, context_classes* context)
{
    LF_ERROR    error;
    USHORT      n = 1;

    while (n < ccss->count)
    {
        chain_class_set* ccs = (chain_class_set*)vector_at(ccss, n);
        error = ChainClassSet_pruneLookupRecords(ccs, context);

        if (error == LF_EMPTY_TABLE)
        {
            ChainClassSet_freeSet(ccs);
            FREE(ccs);
            vector_erase(ccss, n);
        }
        else
        {
            n++;
        }
    }

    if (ccss->count == 0)
        return LF_EMPTY_TABLE;

    return LF_ERROR_OK;
}

#ifdef LF_OT_DUMP
void ChainClassSets_dumpSets(LF_VECTOR* ccss)
{
    USHORT    n, count;

    count = UTILS_getCount(ccss);
    for (n = 0; n < count; n++)
    {
        chain_class_set* ccs = (chain_class_set*)vector_at(ccss, n);
        XML_START("ChainClassSet");
        ChainClassSet_dumpSet(ccs);
        XML_END("ChainClassSet");
    }
}
#endif


LF_ERROR ChainClassSets_validClassRules(LF_VECTOR* ccss)
{
    ULONG       n = 0;
    LF_ERROR    error;
    USHORT      count = 0;

    while ( n < ccss->count )
    {
        chain_class_set* ccs = (chain_class_set*)vector_at(ccss, n);
        error = ChainClassSet_validClassRules(ccs);

        if (error == LF_EMPTY_TABLE)
        {
            ccs->ChainClassRuleCount = 0;
            n++;
        }
        else
        {
            n++;
            ccs->ChainClassRuleCount = UTILS_getCount(&ccs->ChainClassRule);
        }

        count += ccs->ChainClassRuleCount;
    }

    if (count == 0)
        return LF_EMPTY_TABLE;

    return LF_ERROR_OK;
}


/* ----------------------------------------------------------------------------
    @summary
        a vector collection holding a ChainClassSets is freed from 
        resources.

    @param
        ccss        :    pointer to the vector collection

---------------------------------------------------------------------------- */
void ChainClassSets_freeSets(LF_VECTOR* ccss)
{
    ULONG i = 0;
    while (i < ccss->count)
    {
        chain_class_set* ccs = (chain_class_set*)vector_at(ccss, i++);
        ChainClassSet_freeSet(ccs);
        free(ccs);
    };
    vector_delete(ccss);
}

/* ----------------------------------------------------------------------------
    @summary
        returns the memory requirements in bytes for a vector collection 
        holding ChainClassSets 

    @param
        ccss        :    pointer to the vector collection

    @return
        size in bytes.
---------------------------------------------------------------------------- */
size_t ChainClassSets_sizeSets(LF_VECTOR* ccss)
{
    size_t    size = 0;
    USHORT   n, count;

    count = UTILS_getCount(ccss);
    for (n = 0; n < count; n++)
    {
        chain_class_set* ccs = (chain_class_set*)vector_at(ccss, n);
        size += ChainClassSet_sizeSet(ccs);
    }
    return size;
}

/* ----------------------------------------------------------------------------
    @summary
        reads in a number of ChainClassSets from the stream
        and stores them in a vector collection.

    @param
        ccss        :    pointer to the vector collection
        count        :    number of sets in the stream
        input        :    pointer to a class definition
        backtrack    :    pointer to a class definition
        lookahead    :    pointer to a class definition

        stream        :    pointer to the stream
        baseOffset    :    ChainClassSets starting stream offset.

    @returns
        LF_ERROR_OK    :    streamed in the sets successfully.
---------------------------------------------------------------------------- */
LF_ERROR ChainClassSets_readSets(class_def* input, class_def* backtrack, class_def* lookahead, 
                                 LF_VECTOR* ccss, USHORT count, LF_STREAM* stream, ULONG baseOffset)
{
    USHORT              n;
    size_t              curOffset, newOffset;
    chain_class_set*    ccs;
    LF_ERROR            error;

    vector_init(ccss, count, sizeof(ULONG));
    for (n = 0; n < count; n++)
    {
        newOffset = STREAM_readUShort(stream) + baseOffset;
        ccs = (chain_class_set*)calloc(1, sizeof(chain_class_set));
        if (!ccs)
        {
            DEBUG_LOG_ERROR("failed to allocate ChainClassSet");
            error = LF_OUT_OF_MEMORY;
            goto Fail1;
        }

        ccs->InputClass = n;
        ccs->InputClassDefined = TRUE;

        if (newOffset != baseOffset)
        {
            curOffset = STREAM_streamPos(stream);
            STREAM_streamSeek(stream, newOffset);

            error = ChainClassSet_readSet(input, backtrack,lookahead, ccs, stream);

            if (error != LF_ERROR_OK)
            {
                DEBUG_LOG_ERROR("problem reading ChainClassSet");
                free(ccs);
                goto Fail1;
            }

            STREAM_streamSeek(stream, curOffset);
        }
        else
        {
            ccs->ChainClassRuleCount = 0;
            vector_init(&ccs->ChainClassRule, 0, sizeof(ULONG));
        }
        vector_push_back(ccss, ccs);
    }

    return LF_ERROR_OK;

Fail1:
    return error;
}

/* ----------------------------------------------------------------------------
    @summary
        builds a collection of ChainClassSets, updates the OFFSET
        array for each of the ChainClassSets in the vector collection 
        and writes it to the stream.

    @param
        ccss          :    pointer to the vector collection
        stream        :    pointer to the stream
        baseOffset    :    ChainClassSets starting stream offset.
        arrayOffset   :    stream offset to start of array[]

    @returns
        LF_ERROR_OK   :    streamed in the sets successfully.

---------------------------------------------------------------------------- */
size_t ChainClassSets_buildSets(LF_VECTOR* ccss, LF_STREAM* stream, ULONG arrayOffset, ULONG baseOffset)
{
    USHORT    n, count;
    size_t    curOffset;
    
    count = UTILS_getCount(ccss);

    for (n = 0; n < count; n++)
    {
        chain_class_set* ccs = (chain_class_set*)vector_at(ccss, n);

        curOffset = STREAM_streamPos(stream);
        STREAM_streamSeek(stream, arrayOffset);

        if (ccs->ChainClassRule.count)
        {
            STREAM_writeOffset(stream, (OFFSET)(curOffset - baseOffset));
        }
        else
        {
            STREAM_writeOffset(stream, 0);
        }
        arrayOffset += sizeof(OFFSET);

        STREAM_streamSeek(stream, curOffset);
        ChainClassSet_buildSet(ccs, stream);
    }

    return STREAM_streamPos(stream);
}

/* ----------------------------------------------------------------------------
    @summary
        remove a lookup record index from all of the ChainClassSet Class
        rule records.

    @param
        ccss          :    pointer to the vector collection
        lookupIndex   :    the lookup record to remove
        deltaIndex    :    index value to apply to all lookups that are
                           greater than the index to remove

    @returns
        LF_ERROR_OK    :    streamed in the sets successfully.

---------------------------------------------------------------------------- */
LF_ERROR ChainClassSets_removeLookupRecordIndex(LF_VECTOR* ccss, USHORT lookupIndex, SHORT deltaIndex)
{
    USHORT count = UTILS_getCount(ccss);
    USHORT n;

    for ( n = 0; n < count; n++)
    {
        chain_class_set* ccs = (chain_class_set*)vector_at(ccss, n);
        ChainClassSet_removeLookupRecordIndex(ccs, lookupIndex, deltaIndex);
    }

    return LF_ERROR_OK;
}



/* ****************************************************************************

                    CHAIN CLASS SET FUNCTIONS

**************************************************************************** */

LF_ERROR ChainClassSet_readSet(class_def* input, class_def* backtrack, class_def* lookahead,
                               chain_class_set* ccs, LF_STREAM* stream)
{
    LF_ERROR            error;
    USHORT              n, count;
    size_t              curOffset, newOffset, baseOffset;
    chain_class_rule*   ccr;

    baseOffset = STREAM_streamPos(stream);

    count = ccs->ChainClassRuleCount = STREAM_readUShort(stream);
    vector_init(&ccs->ChainClassRule, count, sizeof(ULONG));

    for (n = 0; n < count; n++)
    {
        ccr = (chain_class_rule*)calloc(1, sizeof(chain_class_rule));
        if (ccr == NULL)
        {
            DEBUG_LOG_ERROR("failed to allocate ChainClassRule");
            error = LF_OUT_OF_MEMORY;
            goto Fail1;
        }

        ccr->InputClass = ccs->InputClass;

        newOffset = STREAM_readUShort(stream) + baseOffset;
        curOffset = STREAM_streamPos(stream);
        STREAM_streamSeek(stream, newOffset);

        error = ChainClassRule_readRule(input, backtrack, lookahead, ccr, stream);
        if (error != LF_ERROR_OK)
        {
            DEBUG_LOG_ERROR("failed to read ChainClassRule");
            goto Fail1;
        }

        vector_push_back(&ccs->ChainClassRule, (void*)ccr);
        STREAM_streamSeek(stream, curOffset);
    }
    return LF_ERROR_OK;

Fail1:
    return error;
}

void ChainClassSet_freeSet(chain_class_set* ccs)
{
    ULONG i = 0;
    while (i < ccs->ChainClassRule.count)
    {
        chain_class_rule* ccr = (chain_class_rule*)vector_at(&ccs->ChainClassRule, i++);
        ChainClassRule_freeRule(ccr);
        FREE(ccr);
    }
    vector_delete(&ccs->ChainClassRule);
}

size_t ChainClassSet_sizeSet(chain_class_set* ccs)
{
    size_t    size = 0;
    USHORT   n, count;

    count = UTILS_getCount(&ccs->ChainClassRule);
    if (count)                                     // Don't add to count if no Class Rules
    {
        size += sizeof(USHORT);                    // ChainClassRuleCount
        size += sizeof(OFFSET) * count;            // Offset[ChainClassRuleCount]

        for (n = 0; n < count; n++)
        {
            chain_class_rule* ccr = (chain_class_rule*)vector_at(&ccs->ChainClassRule, n);
            size += ChainClassRule_sizeRule(ccr);
        }
    }
    return size;
}

size_t ChainClassSet_buildSet(chain_class_set* ccs, LF_STREAM* stream)
{
    USHORT       n, count;
    size_t        curOffset, baseOffset, arrayOffset;

    count = UTILS_getCount(&ccs->ChainClassRule);
    baseOffset = STREAM_streamPos(stream);

    if (count)
    {
        STREAM_writeUShort(stream, count);                        // ChainClassRuleCount
        arrayOffset = Common_buildEmptyArray(stream, count);    // Build placeholder array

        for (n = 0; n < count; n++)
        {
            chain_class_rule* ccr = (chain_class_rule*)vector_at(&ccs->ChainClassRule, n);

            curOffset = STREAM_streamPos(stream);
            STREAM_streamSeek(stream, arrayOffset);
            STREAM_writeOffset(stream, (OFFSET)(curOffset - baseOffset));
            arrayOffset += sizeof(OFFSET);

            STREAM_streamSeek(stream, curOffset);
            ChainClassRule_buildRule(ccr, stream);
        }
    }
    return STREAM_streamPos(stream);
}

LF_ERROR ChainClassSet_removeLookupRecordIndex(chain_class_set* ccs, USHORT lookupIndex, SHORT deltaIndex)
{
    USHORT count = UTILS_getCount(&ccs->ChainClassRule);
    USHORT n;

    for (n = 0; n < count; n++)
    {
        chain_class_rule* ccr = (chain_class_rule*)vector_at(&ccs->ChainClassRule, n);
        Common_removeLookupListIndex(&ccr->Input.LookupRecords, lookupIndex, deltaIndex);
    }

    return LF_ERROR_OK;
}

/* ============================================================================
    @summary
        A class set contains a group of class rules that start with an input
        class id which coincides with the ClassSet index.

        So, if the class set index is 2, then all of the class rule's
        Input sequence of class id begin with class 2.

    @param
        ccs        :    pointer to chain class set structure
        context    :    pointer to structure holding all class definitions
                    and coverages.

    @output
        LF_ERROR_OK        :    removed invalid rules.
============================================================================ */
LF_ERROR ChainClassSet_pruneLookupRecords(chain_class_set* ccs, context_classes* context)
{
    LF_ERROR    error = LF_ERROR_OK;
    USHORT        n = 0;

    while (n < ccs->ChainClassRule.count)
    {
        chain_class_rule* ccr = (chain_class_rule*)vector_at(&ccs->ChainClassRule, n);
        error = ChainClassRule_pruneLookupRecords(ccr, context);

        if (error == LF_EMPTY_TABLE)
        {
            ChainClassRule_freeRule(ccr);
            FREE(ccr);
            vector_erase(&ccs->ChainClassRule, n);
        }
        else
        {
            n++;
        }
    }

    // NOTE:    do not return EMPTY because these sets must be in sync
    //            with the number of classes.  the ClassSet index is what
    //            determines the starting class id for the Input sequence.
    //            What this means, is a ClassSet can be empty, but must
    //            be intact to keep in sync with the class order.
    //
    //    if (ccs->ChainClassRule.count == 0)
    //        return LF_EMPTY_TABLE;

    return LF_ERROR_OK;
}

LF_ERROR ChainClassSet_validClassRules(chain_class_set* ccs)
{
    USHORT        n = 0;
    LF_ERROR    error;

    while (n < ccs->ChainClassRule.count)
    {
        chain_class_rule* ccr = (chain_class_rule*)vector_at(&ccs->ChainClassRule, n);

        error = ChainClassRule_validClassRules(ccr);
        if (error == LF_EMPTY_TABLE)
        {
            ChainClassRule_freeRule(ccr);
            FREE(ccr);
            vector_erase(&ccs->ChainClassRule, n);
        }
        else
        {
            n++;
        }
    }

    if (ccs->ChainClassRule.count == 0)
        return LF_EMPTY_TABLE;

    return LF_ERROR_OK;
}

#ifdef LF_OT_DUMP
void ChainClassSet_dumpSet(chain_class_set* ccs)
{
    USHORT        count = UTILS_getCount(&ccs->ChainClassRule);
    USHORT        n;

    for (n = 0; n < count; n++)
    {
        chain_class_rule* ccr = (chain_class_rule*)vector_at(&ccs->ChainClassRule, n);
        XML_START("ChainClassRule");
        XML_COMMENT("Rule", n);
        ChainClassRule_dumpRule(ccr);
        XML_END("ChainClassRule");
    }
}
#endif

void ChainClassSet_freeValidClasses(context_classes* f2)
{
    if (f2->validClasses)
    {
        ULONG i = 0;
        while (i < f2->validClasses->count)
        {
            context_define* def = (context_define*)vector_at(f2->validClasses, i++);
            free(def);
        }
        vector_delete(f2->validClasses);
        free(f2->validClasses);
    }
    memset(f2, 0, sizeof(context_classes));
}

LF_ERROR ChainClassSet_createValidClasses(USHORT startClass, context_classes* context)
{
    USHORT       n;
    ULONG        maxClass;

    context->totalClasses = startClass;

    maxClass = ClassDef_getMaxClass(context->Input);
    if (maxClass > context->totalClasses)
        context->totalClasses = maxClass;

    maxClass = ClassDef_getMaxClass(context->Backtrack);
    if (maxClass > context->totalClasses)
        context->totalClasses = maxClass;

    maxClass = ClassDef_getMaxClass(context->LookAhead);
    if (maxClass > context->totalClasses)
        context->totalClasses = maxClass;

    context->validClasses = vector_create(context->totalClasses, sizeof(ULONG));
    for (n = 0; n <= context->totalClasses; n++)
    {
        context_define* def = (context_define*)calloc(1, sizeof(context_define));
        if (!def)
        {
            return LF_OUT_OF_MEMORY;
        }

        def->Class = n;
        vector_push_back(context->validClasses, (void*)def);
    }

    return LF_ERROR_OK;
}

/* ============================================================================
    @summary
        remove any Unused classes from the class definition.  Since we
        have cleanup the ClassRules in the chained context this may have
        left a couple of classes lying around that are no longer referenced
        by the rules.

        first we must find the maximum number of classes, and then
        parse all of the ClassRules for a reference to that class in
        the sequence.

        if we do not find a reference to that class in the sequence, we
        can clear out the class.

    @param
        context    :    pointer to context_classes.  must contain all of the
                        pointers to the class definitions.

        ccss       :    pointer to vector collection of chain_class_set

    @return
============================================================================ */
LF_ERROR ChainClassSets_removeUnusedClasses(LF_VECTOR* ccss, context_classes* context)
{
    USHORT      n, count;
    LF_ERROR    error;

    count = UTILS_getCount(ccss);

    error = ChainClassSet_createValidClasses(count, context);
    if (error == LF_ERROR_OK)
    {
        n = 0;

        while (n < ccss->count)
        {
            chain_class_set* ccs = (chain_class_set*)vector_at(ccss, n);
            error = ChainClassSet_findUnusedClasses(ccs, context);
            n++;
        }

#ifdef LF_OT_DUMP
        ChainClassSet_dumpValidClasses(context);
#endif

        n = 0;
        while (n < ccss->count)
        {
            chain_class_set* ccs = (chain_class_set*)vector_at(ccss, n);
            error = ChainClassSet_removeUnusedClasses(ccs, context);

            if (error == LF_EMPTY_TABLE)
            {
                ChainClassSet_freeSet(ccs);
                FREE(ccs);
                vector_erase(ccss, n);
            }
            else
            {
                n++;
            }
        }
    }

    ChainClassSet_freeValidClasses(context);

    if (ccss->count == 0)
        return LF_EMPTY_TABLE;

    return LF_ERROR_OK;
}

#ifdef LF_OT_DUMP
/* ============================================================================
    @summary
        dump the valid classes structure to the output stream.

    @param
        context        :    pointer to the context_classes structure, which
                            holds the validClasses vector collection.

============================================================================ */
void ChainClassSet_dumpValidClasses(context_classes* context)
{
    USHORT  n, count;
    //lint -size(a, 2049)
    char    msg[2048];
    //lint -size(a, 0)

    count = UTILS_getCount(context->validClasses);
    for (n = 0; n < count; n++)
    {
        context_define* def = (context_define*)vector_at(context->validClasses, n);

        UTILS_snprintf(msg, 2048, "(%d) InputClass[%d] = %s", n, def->Class, def->Input ? "TRUE" : "FALSE");
        DEBUG_LOG(msg);
    }

    for (n = 0; n < count; n++)
    {
        context_define* def = (context_define*)vector_at(context->validClasses, n);

        UTILS_snprintf(msg, 2048, "(%d) LookAheadClass[%d] = %s", n, def->Class, def->LookAhead ? "TRUE" : "FALSE");
        DEBUG_LOG(msg);
    }

    for (n = 0; n < count; n++)
    {
        context_define* def = (context_define*)vector_at(context->validClasses, n);
        UTILS_snprintf(msg, 2048, "(%d) BacktrackClass[%d] = %s", n, def->Class, def->Backtrack ? "TRUE" : "FALSE");
        DEBUG_LOG(msg);
    }
}
#endif

/* ============================================================================
    @summary
        given a chain class set structure, search and find any valid classes
        within it's chain class rules.

    @param
        ccs        :    pointer to chain class set
        context    :    pointer to context_classes structure

    @return
        OK        :    the classes have been removed, or unchanged

============================================================================ */
LF_ERROR ChainClassSet_findUnusedClasses(chain_class_set* ccs, context_classes* context)
{
    USHORT        n, count;

    count = UTILS_getCount(&ccs->ChainClassRule);

    for (n = 0; n < count; n++)
    {
        chain_class_rule* ccr = (chain_class_rule*)vector_at(&ccs->ChainClassRule, n);
        ChainClassRule_findValidClasses(ccr, context);
    }
    return LF_ERROR_OK;
}

/* ============================================================================
    @summary
        remove any unused classes from the class def structure.

    @param
        ccs        :    pointer to chain class set
        context    :    pointer to context_classes structure

    @return
        OK         :    the classes have been removed, or unchanged

============================================================================ */
LF_ERROR ChainClassSet_removeUnusedClasses(chain_class_set* ccs, context_classes* context)
{
    USHORT      n;
    LF_ERROR    error;

    (void)ccs;

    for ( n = 1; n < context->validClasses->count; n++)
    {
        context_define* def = (context_define*)vector_at(context->validClasses, n);

        if (!def->Backtrack)
        {
            error = ClassDef_removeClassID(context->Backtrack, def->Class, 0);
            // TODO:    change the above parameter from 0 => -1 so the class
            //            is remapped, but then go through all of the class
            //            sequences and remap them to the new values as well.
        }

        if (!def->Input)
        {
            error = ClassDef_removeClassID(context->Input, def->Class, 0);
            // TODO:    change the above parameter from 0 => -1 so the class
            //            is remapped, but then go through all of the class
            //            sequences and remap them to the new values as well.
        }

        if (!def->LookAhead)
        {
            error = ClassDef_removeClassID(context->LookAhead, def->Class, 0);
            // TODO:    change the above parameter from 0 => -1 so the class
            //            is remapped, but then go through all of the class
            //            sequences and remap them to the new values as well.
        }
        (void)error; // unused TODO use above
    }
    return LF_ERROR_OK;
}

LF_ERROR ChainClassSet_cleanupLookup(chain_class_set* ccs, TABLE_HANDLE hLookup)
{
    LF_ERROR error = LF_ERROR_OK;
    ULONG i;
    for (i = 0; i < ccs->ChainClassRule.count; i++)
    {
        chain_class_rule* ccr = (chain_class_rule*)vector_at(&ccs->ChainClassRule, i);
        Common_cleanupLookups(&ccr->Input.LookupRecords, hLookup);
    }

    return error;
}

LF_ERROR ChainClassSets_cleanupLookups(LF_VECTOR* ccss, TABLE_HANDLE hLookup)
{
    //LF_ERROR    error;
    USHORT      n = 1;

    while (n < ccss->count)
    {
        chain_class_set* ccs = (chain_class_set*)vector_at(ccss, n);
        /*error = */ChainClassSet_cleanupLookup(ccs, hLookup); // always returns ok
        n++;
    }
    return LF_ERROR_OK;
}

static LF_ERROR ChainClassSet_collectGlyphs(chain_class_set* ccs, context_classes* classes, GlyphList* keepList, TABLE_HANDLE hTable)
{
    LF_ERROR error = LF_ERROR_OK;
    ULONG i;

    for (i = 0; i < ccs->ChainClassRule.count; i++)
    {
        chain_class_rule* ccr = (chain_class_rule*)vector_at(&ccs->ChainClassRule, i);
        LF_ERROR status = ChainClassRule_collectGlyphs(ccr, classes, keepList, hTable);
        if (status == LF_ADDED_GLYPH)
            error = status;
    }
    return error;
}

LF_ERROR ChainClassSets_collectGlyphs(LF_VECTOR* ccss, context_classes* classes, GlyphList* keepList, TABLE_HANDLE hTable)
{
    LF_ERROR error = LF_ERROR_OK;
    ULONG i;

    for (i = 0; i < ccss->count; i++)
    {
        chain_class_set* ccs = (chain_class_set*)vector_at(ccss, i);
        LF_ERROR status = ChainClassSet_collectGlyphs(ccs, classes, keepList, hTable);
        if (status == LF_ADDED_GLYPH)
            error = status;
    }

    return error;
}
