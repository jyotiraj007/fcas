// Copyright (C) 2014 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// script_list.c

#include <stdlib.h>
#include "script_list.h"
#include "lf_vector.h"
#include "utils.h"
#include "feature_table.h"
#include "gsub_table.h"

static ULONG Script_getLangSysTableSize(langsys_table* table);
static LF_ERROR Script_collectLangSysTable(GlyphList* keepList, langsys_table* lang, TABLE_HANDLE hTable);

//TODO this could be static
size_t Script_getScriptTableSize(const script_table* table)
{
    if(table->LangList.count != 0)
        return sizeof(OFFSET) + sizeof(USHORT) + LANGSYS_RECORD_SIZE * table->LangList.count;

    return sizeof(OFFSET) + sizeof(USHORT);
}

size_t Script_getListTableSize(TABLE_HANDLE hTable)
{
    LF_VECTOR* script_list_table = (LF_VECTOR*)hTable;
    return sizeof(USHORT) + SCRIPT_RECORD_SIZE * script_list_table->count;
}

static ULONG Script_getLangSysTableSize(langsys_table* table)
{
    ULONG size = 0;

    size += sizeof(OFFSET);                    // LookupOrder
    size += sizeof(USHORT);                    // ReqFeatureIndex
    size += sizeof(USHORT);                    // FeatureCount
//    size += (sizeof(USHORT) * UTILS_getCount(&table->FeatureIndex) + 2);
    size += (sizeof(USHORT) * UTILS_getCount(&table->FeatureIndex));
    return size;
}

static langsys_table* Script_readLangSysTable(LF_STREAM* stream)
{
    OFFSET lookupOrder = STREAM_readOffset(stream);
    USHORT reqFeatureIndex = STREAM_readUShort(stream);
    USHORT featureCount = STREAM_readUShort(stream);
    langsys_table* table = (langsys_table*)calloc(1, sizeof(langsys_table));

    if (table)
    {
        USHORT i;

        table->LookupOrder = lookupOrder;
        table->ReqFeatureIndex = reqFeatureIndex;
        table->FeatureCount = featureCount;

        if (LF_ERROR_OK != vector_init(&table->FeatureIndex, featureCount, sizeof(ULONG)))
        {
            free(table);
            return NULL;
        }

        for(i = 0; i < table->FeatureCount; i++)
        {
            USHORT featureIndex = STREAM_readUShort(stream);
            vector_push_back(&table->FeatureIndex, (void*)(intptr_t)featureIndex);
        }
    }
    return table;
}


static void Script_deleteLangSysTable(langsys_table* langTable)
{
    vector_delete(&langTable->FeatureIndex);
}

static script_table* Script_readScriptTable(LF_STREAM* stream)
{
    script_table* table = (script_table*)calloc(1, sizeof(script_table));

    if(table == NULL)
        return NULL;

    size_t tableStart = STREAM_streamPos(stream);
    OFFSET defaultOffset = STREAM_readOffset(stream);
    LONG langSysCount = STREAM_readUShort(stream);

    if(langSysCount > 0)
    {
        USHORT i;
        if (LF_ERROR_OK != vector_init(&table->LangList, langSysCount, 4))
        {
            free(table);
            return NULL;
        }

        for(i = 0; i < langSysCount; i++)
        {
            TAG langSysTag = STREAM_readTag(stream);
            OFFSET offset = STREAM_readOffset(stream);
            langsys_table* langSysTable;

            size_t currPos = STREAM_streamPos(stream);
            STREAM_streamSeek(stream, tableStart + offset);

            langSysTable = Script_readLangSysTable(stream);
            if (langSysTable == NULL)
            {
                for (size_t j = 0; j < table->LangList.count; j++)
                {
                    langSysTable = (langsys_table*)vector_at(&table->LangList, j);
                    Script_deleteLangSysTable(langSysTable);
                    free(langSysTable);
                }

                free(table);
                return NULL;
            }

            STREAM_streamSeek(stream, currPos);

            langSysTable->LangSysTag = langSysTag;

            vector_push_back(&table->LangList, langSysTable);
        }
    }

    if (defaultOffset)
    {
        STREAM_streamSeek(stream, tableStart + defaultOffset);

        table->DefaultLangSys = Script_readLangSysTable(stream);
        if (table->DefaultLangSys == NULL)
        {
            for (size_t j = 0; j < table->LangList.count; j++)
            {
                langsys_table* langSysTable = (langsys_table*)vector_at(&table->LangList, j);
                Script_deleteLangSysTable(langSysTable);
                free(langSysTable);
            }

            free(table);
            return NULL;
        }
    }

    return table;
}

TABLE_HANDLE Script_readListTable(LF_STREAM* stream, boolean isGPOS)
{
    UNUSED(isGPOS);

    LF_VECTOR* script_list_table = (LF_VECTOR*)malloc(sizeof(LF_VECTOR));
    if(script_list_table == NULL)
        return NULL;

    size_t tableStart = STREAM_streamPos(stream);
    USHORT i, scriptCount = STREAM_readUShort(stream);

    if (LF_ERROR_OK != vector_init(script_list_table, scriptCount, 4))
    {
        free(script_list_table);
        return NULL;
    }

    for(i = 0; i < scriptCount; i++)
    {
        //read in the script record
        TAG scriptTag = STREAM_readTag(stream);
        OFFSET offset = STREAM_readOffset(stream);

        //seek to script table offset and read table
        size_t currPos = STREAM_streamPos(stream);
        STREAM_streamSeek(stream, tableStart + offset);

        script_table* scriptTable = Script_readScriptTable(stream);

        if (scriptTable == NULL)
        {
            Script_deleteTable(script_list_table);
            return NULL;
        }

        STREAM_streamSeek(stream, currPos);

        scriptTable->ScriptTag = scriptTag;

        vector_push_back(script_list_table, scriptTable);
    }

    return script_list_table;
}

size_t Script_getDataSize(TABLE_HANDLE hTable)
{
    LF_VECTOR* script_list_table = (LF_VECTOR*)hTable;
    size_t tableSize = Script_getListTableSize(hTable);
    ULONG i, j = 0;

    for(i = 0; i < script_list_table->count; i++)
    {
        script_table* scriptTable = (script_table*)vector_at(script_list_table, i);
        tableSize += Script_getScriptTableSize(scriptTable);

        if(scriptTable->DefaultLangSys != NULL)
        {
            tableSize += Script_getLangSysTableSize(scriptTable->DefaultLangSys);
        }

        if(scriptTable->LangList.count > 0)
        {
            for(j = 0; j < scriptTable->LangList.count; j++)
            {
                tableSize += Script_getLangSysTableSize((langsys_table*)vector_at(&scriptTable->LangList, j));
            }
        }
    }

    return tableSize;
}

static size_t Script_buildLangSysTable(langsys_table* table, LF_STREAM* stream)
{
    USHORT i;
    USHORT featureCount;

    featureCount = UTILS_getCount(&table->FeatureIndex);

    STREAM_writeUShort(stream, 0);
    STREAM_writeUShort(stream, table->ReqFeatureIndex);
    STREAM_writeUShort(stream, featureCount);

    for(i = 0; i < featureCount; i++)
    {
        USHORT featureIndex = (USHORT)(intptr_t)vector_at(&table->FeatureIndex, i);
        STREAM_writeUShort(stream, featureIndex);
    }

    return STREAM_streamPos(stream);
}

static size_t Script_buildScriptTable(script_table* table, LF_STREAM* stream)
{
    size_t tableStart = STREAM_streamPos(stream);
    size_t langSysOffset = sizeof(OFFSET) + sizeof(USHORT) + (sizeof(TAG) + sizeof(OFFSET)) * table->LangList.count;
    size_t defaultOffset;
    USHORT langSysCount = (USHORT)table->LangList.count;
    ULONG i;

    //if we have a default language, write out now
    if(table->DefaultLangSys != NULL)
    {
        STREAM_writeUShort(stream, (USHORT)langSysOffset);

        defaultOffset = STREAM_streamPos(stream);
        STREAM_streamSeek(stream, tableStart + langSysOffset);
        langSysOffset = Script_buildLangSysTable(table->DefaultLangSys, stream) - tableStart;
        STREAM_streamSeek(stream, defaultOffset);
    }
    else
    {
        STREAM_writeUShort(stream, (USHORT)0);
    }

    STREAM_writeUShort(stream, langSysCount);

    //write out LangSysRecords
    for(i = 0; i< table->LangList.count; i++)
    {
        langsys_table* langSysTable = (langsys_table*)vector_at(&table->LangList, i);

        STREAM_writeTag(stream, langSysTable->LangSysTag);
        STREAM_writeOffset(stream, (OFFSET)langSysOffset);

        defaultOffset = STREAM_streamPos(stream);
        STREAM_streamSeek(stream, langSysOffset + tableStart);                            // Need to stream back to end of record
        langSysOffset = Script_buildLangSysTable(langSysTable, stream) - tableStart;
        STREAM_streamSeek(stream,defaultOffset);                             // Now back to the offset table position
    }
    STREAM_streamSeek(stream, langSysOffset + tableStart);
    return STREAM_streamPos(stream);
}

BYTE* Script_buildTable(TABLE_HANDLE hTable, size_t* tableSize)
{
    LF_VECTOR* script_list_table = (LF_VECTOR*)hTable;
    BYTE* tableData;
    size_t scriptOffset;
    LF_STREAM stream;
    ULONG i;

    *tableSize = Script_getDataSize(hTable);
    tableData = (BYTE*)malloc(*tableSize);
    STREAM_initMemStream(&stream, tableData, *tableSize);

    STREAM_writeUShort(&stream, (USHORT)script_list_table->count);
    scriptOffset = STREAM_streamPos(&stream) + (sizeof(TAG) + sizeof(OFFSET)) * script_list_table->count;

    for(i = 0; i< script_list_table->count; i++)
    {
        script_table* scriptTable = (script_table*)vector_at(script_list_table, i);
        size_t oldPos;

        STREAM_writeTag(&stream, scriptTable->ScriptTag);
        STREAM_writeOffset(&stream, (OFFSET)scriptOffset);

        oldPos = STREAM_streamPos(&stream);
        STREAM_streamSeek(&stream, scriptOffset);
        scriptOffset = Script_buildScriptTable(scriptTable, &stream);
        STREAM_streamSeek(&stream, oldPos);
    }

    return stream.Base;
}

void Script_deleteTable(TABLE_HANDLE hTable)
{
    LF_VECTOR* script_list_table = (LF_VECTOR*)hTable;

    if (script_list_table != NULL)
    {
        for (size_t i = 0; i < script_list_table->count; i++)
        {
            script_table* scriptTable = (script_table*)vector_at(script_list_table, i);

            for (size_t j = 0; j < scriptTable->LangList.count; j++)
            {
                langsys_table* langSysTable = (langsys_table*)vector_at(&scriptTable->LangList, j);
                Script_deleteLangSysTable(langSysTable);
                free(langSysTable);
            }

            if (scriptTable->DefaultLangSys)
            {
                Script_deleteLangSysTable(scriptTable->DefaultLangSys);
            }
            free(scriptTable->DefaultLangSys);
            vector_free(&scriptTable->LangList);
            free(scriptTable);
        }

        vector_free(script_list_table);
        free(script_list_table);
    }
}


/* ----------------------------------------------------------------------------
    @summary
        given a language system table, remap or remove an lookup index from
        the tables.  since we are removing the index, we will need to remap
        any indices that are greater than the removed index by the delta
        value passed.

    @param
        langSysTable    :    pointer to the language system table
        index           :    index value to remove
        delta           :    delta value to apply to any lookup index > index

    @return
        LF_EMPTY_TABLE  :    There are no lookup indices remaining
        LF_ERROR_OK     :    the remap/removal was successful
---------------------------------------------------------------------------- */
static LF_ERROR script_removeLookupIndex(langsys_table* langSysTable, USHORT index, SHORT delta)
{
    LF_ERROR    error = LF_ERROR_OK;
    ULONG        k = 0;

    while (k < langSysTable->FeatureIndex.count)
    {
        USHORT featureIndex = (USHORT)(intptr_t)vector_at(&langSysTable->FeatureIndex, k);
        if ( featureIndex == index)
        {
            vector_erase(&langSysTable->FeatureIndex, k);
        }
        else if (featureIndex > index)
        {
            USHORT deltaIndex;

            deltaIndex = featureIndex + delta;
            vector_set_data(&langSysTable->FeatureIndex, k, (void*)(intptr_t)deltaIndex);
            k++;
        }
        else
        {
            k++;
        }
    }

    if (langSysTable->FeatureIndex.count == 0)
        error = LF_EMPTY_TABLE;

    return error;
}


static LF_ERROR Script_isScriptTableEmpty(const script_table* scriptTable)
{
    if (scriptTable->LangList.count != 0)
        return LF_ERROR_OK;

    if (scriptTable->DefaultLangSys != NULL)
    {
        if (scriptTable->DefaultLangSys->FeatureIndex.count != 0)
            return LF_ERROR_OK;
    }

    return LF_EMPTY_TABLE;
}




LF_ERROR Script_removeLookupIndex(TABLE_HANDLE hScript, USHORT index, SHORT delta)
{
    LF_VECTOR* script_list_table = (LF_VECTOR*)hScript;
    ULONG i = 0;



    while (i < script_list_table->count)
    {
        script_table* scriptTable = (script_table*)vector_at(script_list_table, i);
        ULONG j = 0;

        if (scriptTable->DefaultLangSys != NULL)
        {
            LF_ERROR error = script_removeLookupIndex(scriptTable->DefaultLangSys, index, delta);
            if (error == LF_EMPTY_TABLE)
            {
                Script_deleteLangSysTable(scriptTable->DefaultLangSys);
                free(scriptTable->DefaultLangSys);
                scriptTable->DefaultLangSys = NULL;
            }
        }


        while (j < scriptTable->LangList.count)
        {
            langsys_table* langSysTable = (langsys_table*)vector_at(&scriptTable->LangList, j);

            LF_ERROR status = script_removeLookupIndex(langSysTable, index, delta);

            if (status == LF_EMPTY_TABLE)
            {
                Script_deleteLangSysTable(langSysTable);
                free(langSysTable);
                vector_erase(&scriptTable->LangList, j);
            }
            else
            {
                j++;
            }
        }

        if (Script_isScriptTableEmpty(scriptTable) == LF_EMPTY_TABLE)
        {
            vector_delete(&scriptTable->LangList);
            free(scriptTable);
            vector_erase(script_list_table, i);
        }
        else
        {
            i++;
        }
    }

    if (script_list_table->count == 0)
    {
        return LF_EMPTY_TABLE;
    }

    return LF_ERROR_OK;
}


/* ----------------------------------------------------------------------------
    @summary
        Parse the script and languages to generate a keep glyph list.

    @param
        keepList    :    pointer to GlyphList object
        hScript     :    pointer to LF_VECTOR of script_table structures.

    @return
        LF_ERROR_OK    :    parsing went ok, and keep list is filled.
        LF_ADDED_GLYPH :    one or more glyph ids was added to the keep list.

---------------------------------------------------------------------------- */
LF_ERROR Script_collectGlyphs(GlyphList* keepList, TABLE_HANDLE hTable)
{
    LF_ERROR error = LF_ERROR_OK;
    gsub_header* gsub = (gsub_header*)hTable;

    LF_VECTOR* script_list_table = (LF_VECTOR*)gsub->ScriptList;
    ULONG i = 0;

    while (i < script_list_table->count)
    {
        script_table* scriptTable = (script_table*)vector_at(script_list_table, i);
        langsys_table* langSysTable = NULL;
        ULONG j = 0;

        if (scriptTable->DefaultLangSys != NULL)
        {
            LF_ERROR status;
            langSysTable = scriptTable->DefaultLangSys;
            status = Script_collectLangSysTable(keepList, langSysTable, gsub);

            if (status == LF_ADDED_GLYPH)
            {
                // we need to parse out the temporary glyph list, and
                // copy it to the master list.
                error = LF_ADDED_GLYPH;
            }
        }

        while (j < scriptTable->LangList.count)
        {
            LF_ERROR status;
            langSysTable = (langsys_table*)vector_at(&scriptTable->LangList, j);
            status = Script_collectLangSysTable(keepList, langSysTable, gsub);

            if (status == LF_ADDED_GLYPH)
            {
                // we need to parse out the temporary glyph list, and
                // copy it to the master list.
                error = LF_ADDED_GLYPH;
            }
            j++;
        }

        i++;
    }

    return error;
}

static LF_ERROR Script_collectLangSysTable(GlyphList* keepList, langsys_table* lang, TABLE_HANDLE hTable)
{
    LF_ERROR error = LF_INVALID_SUBTABLE;
    if (lang)
    {
        ULONG i;

        error = LF_ERROR_OK;

        if (lang->ReqFeatureIndex != 0xFFFF)
        {
            DEBUG_LOG("Index of a feature required for this language system");
        }

        // loop through the features
        for (i = 0; i < lang->FeatureIndex.count; i++)
        {
            USHORT featureIndex = (USHORT)(intptr_t)vector_at(&lang->FeatureIndex, i);
            LF_ERROR status = Feature_collectGlyphs(keepList, hTable, featureIndex);
            if (status == LF_ADDED_GLYPH)
                error = LF_ADDED_GLYPH;
        }
    }
    return error;
}
