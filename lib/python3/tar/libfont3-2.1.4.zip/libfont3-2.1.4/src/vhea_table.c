// Copyright (C) 2014 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// vhea_table.c

#include <stdlib.h>
#include "vhea_table.h"
#include "utils.h"

USHORT VHEA_getNumVMetrics(LF_FONT* lfFont)
{
    vhea_table* table = (vhea_table*)map_at(&lfFont->table_map, (void*)TAG_VHEA);

    return (table != NULL) ? table->numberOfVMetrics : 0;
}

void VHEA_setNumVMetrics(LF_FONT* lfFont, USHORT numVMetrics)
{
    vhea_table* table = (vhea_table*)map_at(&lfFont->table_map, (void*)TAG_VHEA);
    if (table != NULL)
        table->numberOfVMetrics = numVMetrics;
}

void VHEA_setAdvanceHeightMax(LF_FONT* lfFont, UFWORD advanceHeightMax)
{
    vhea_table* table = (vhea_table*)map_at(&lfFont->table_map, (void*)TAG_VHEA);
    if (table != NULL)
        table->advanceHeightMax = advanceHeightMax;
}

void VHEA_setTopSidebearingMin(LF_FONT* lfFont, UFWORD topSidebearingMin)
{
    vhea_table* table = (vhea_table*)map_at(&lfFont->table_map, (void*)TAG_VHEA);
    table->minTopSideBearing = topSidebearingMin;
}

void VHEA_setBottomSidebearingMin(LF_FONT* lfFont, UFWORD bottomSidebearingMin)
{
    vhea_table* table = (vhea_table*)map_at(&lfFont->table_map, (void*)TAG_VHEA);
    table->minBottonSideBearing = bottomSidebearingMin;
}

void VHEA_setYMaxExtent(LF_FONT* lfFont, SHORT yMaxExtent)
{
    vhea_table* table = (vhea_table*)map_at(&lfFont->table_map, (void*)TAG_VHEA);
    if (table != NULL)
        table->yMaxExtent = yMaxExtent;
}

void VHEA_setVertTypoLineGap(LF_FONT* lfFont, UFWORD lineGap)
{
    vhea_table* table = (vhea_table*)map_at(&lfFont->table_map, (void*)TAG_VHEA);
    if (table != NULL)
    {
        if (table->version == 0x00010000)
            table->m.v10.LineGap = lineGap;
        else
            table->m.v11.vertTypoLineGap = lineGap;
    }
}

LF_ERROR VHEA_readTable(LF_FONT* lfFont, const sfnt_table_record* record, LF_STREAM* stream)
{
    if(STREAM_streamSeek(stream, record->offset) == 0)
    {
        vhea_table* table = (vhea_table*)calloc(1, sizeof(vhea_table));

        if(table == NULL)
            return LF_EMPTY_TABLE;

        table->version = STREAM_readFixed(stream);

        if (table->version == 0x00010000)
        {
            table->m.v10.ascent = STREAM_readShort(stream);
            table->m.v10.descent = STREAM_readShort(stream);
            table->m.v10.LineGap = STREAM_readShort(stream);
        }
        else
        {
            table->m.v11.vertTypoAscender = STREAM_readShort(stream);
            table->m.v11.vertTypoDescender = STREAM_readShort(stream);
            table->m.v11.vertTypoLineGap = STREAM_readShort(stream);
        }

        table->advanceHeightMax = STREAM_readShort(stream);
        table->minTopSideBearing = STREAM_readShort(stream);
        table->minBottonSideBearing = STREAM_readShort(stream);
        table->yMaxExtent = STREAM_readShort(stream);
        table->caretSlopeRise = STREAM_readShort(stream);
        table->caretSlopeRun = STREAM_readShort(stream);
        table->caretOffset = STREAM_readShort(stream);
        table->reserved1 = STREAM_readShort(stream);
        table->reserved2 = STREAM_readShort(stream);
        table->reserved3 = STREAM_readShort(stream);
        table->reserved4 = STREAM_readShort(stream);
        table->metricDataFormat = STREAM_readShort(stream);
        table->numberOfVMetrics = STREAM_readUShort(stream);

        map_insert(&lfFont->table_map, (void*)(intptr_t)record->tag, table);

        return LF_ERROR_OK;
    }

    return LF_INVALID_OFFSET;
}

LF_ERROR VHEA_getTableSize(LF_FONT* lfFont, size_t* tableSize)
{
    vhea_table* table;

    *tableSize = 0;

    table = (vhea_table*)map_at(&lfFont->table_map, (void*)TAG_VHEA);
    if(table == NULL)
        return LF_EMPTY_TABLE;

    *tableSize = VHEA_TABLE_SIZE;

    return LF_ERROR_OK;
}

LF_ERROR VHEA_writeTable(LF_FONT* lfFont, sfnt_table_record* record, LF_STREAM* stream)
{
    vhea_table* table = (vhea_table*)map_at(&lfFont->table_map, (void*)TAG_VHEA);
    size_t padLen = VHEA_TABLE_SIZE; // updated below
    BYTE* padTable;
    LF_STREAM localStream;

    if(table == NULL)
        return LF_BAD_FORMAT;

    padTable = UTILS_AllocTable(&padLen);

    if (padTable == NULL)
        return LF_OUT_OF_MEMORY;

    STREAM_initMemStream(&localStream, padTable, padLen);

    STREAM_writeFixed(&localStream, table->version);

    if (table->version == 0x00010000)
    {
        STREAM_writeShort(&localStream, table->m.v10.ascent);
        STREAM_writeShort(&localStream, table->m.v10.descent);
        STREAM_writeShort(&localStream, table->m.v10.LineGap);
    }
    else
    {
        STREAM_writeShort(&localStream, table->m.v11.vertTypoAscender);
        STREAM_writeShort(&localStream, table->m.v11.vertTypoDescender);
        STREAM_writeShort(&localStream, table->m.v11.vertTypoLineGap);
    }

    STREAM_writeShort(&localStream, table->advanceHeightMax);
    STREAM_writeShort(&localStream, table->minTopSideBearing);
    STREAM_writeShort(&localStream, table->minBottonSideBearing);
    STREAM_writeShort(&localStream, table->yMaxExtent);
    STREAM_writeShort(&localStream, table->caretSlopeRise);
    STREAM_writeShort(&localStream, table->caretSlopeRun);
    STREAM_writeShort(&localStream, table->caretOffset);
    STREAM_writeShort(&localStream, 0);
    STREAM_writeShort(&localStream, 0);
    STREAM_writeShort(&localStream, 0);
    STREAM_writeShort(&localStream, 0);
    STREAM_writeShort(&localStream, 0);
    STREAM_writeUShort(&localStream, table->numberOfVMetrics);

    record->checkSum = UTILS_CalcTableChecksum(padTable, VHEA_TABLE_SIZE);
    record->length = VHEA_TABLE_SIZE;
    record->offset = (ULONG)STREAM_streamPos(stream);

    STREAM_streamSeek(stream, record->offset);
    STREAM_writeChunk(stream, padTable, padLen);
    free(padTable);

    return LF_ERROR_OK;
}

LF_ERROR VHEA_freeTable(LF_FONT* lfFont)
{
    vhea_table* table = (vhea_table*)map_at(&lfFont->table_map, (void*)TAG_VHEA);
    free(table);
    return LF_ERROR_OK;
}
