/* -------------------------------------------------------------------------
   This is a generated file. Do not edit.

   Language tables generated:
        Jan 04, 2017    08:40:55
 -------------------------------------------------------------------------*/
#include <string.h>
#include "lf_error.h"
#include "lf_map.h"

#define BUILDLANG_RANGE_TOTALS    8

LF_API LF_ERROR BuildLang_getRangeTable(char* listLang, LF_MAP* keepMap, ULONG* count);
LF_API LF_ERROR BuildLang_rangeTableExists(char* lang);

