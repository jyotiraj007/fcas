// Copyright (C) 2014 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// lf_vector.c

#include <stdlib.h>
#include <memory.h>
#include "lf_vector.h"

LF_VECTOR* vector_create(size_t size, size_t grow)
{
    LF_VECTOR* vector = NULL;
   
    if (grow > 0) {
        vector = (LF_VECTOR*)calloc(1, sizeof(LF_VECTOR));

        if (vector) {
            vector_init(vector, size, grow);
        }
    }

    return vector;
}

LF_ERROR vector_init(LF_VECTOR* vector, size_t size, size_t grow)
{
    if (grow == 0)
        return LF_INVALID_PARAM;

    vector->count = 0;
    vector->max_size = size;
    vector->grow_size = grow;
    vector->vector_array = (void**)calloc(1, sizeof(void*) * size);

    if(vector->vector_array == NULL)
        return LF_OUT_OF_MEMORY;

    return LF_ERROR_OK;
}

void vector_free(LF_VECTOR* vector)
{
    free(vector->vector_array);
}

boolean vector_empty(LF_VECTOR* vector)
{
    return vector->count == 0 ? TRUE : FALSE;
}

void vector_clear(LF_VECTOR* vector)
{
    vector->count = 0;
}

void* vector_at(const LF_VECTOR* vector, size_t index)
{
    if (index < vector->count)
        return vector->vector_array[index];

    return 0;
}

#if 0 // Unused.
void** vector_data(LF_VECTOR* vector)
{
    return vector->vector_array;
}
#endif

LF_ERROR vector_resize(LF_VECTOR* vector, size_t size)
{
    vector->max_size = size;
    vector->vector_array = (void**)realloc(vector->vector_array, sizeof(void*) * vector->max_size);

    if(vector->vector_array == NULL)
        return LF_OUT_OF_MEMORY;

    if(vector->max_size < vector->count)
        vector->count = vector->max_size;

    return LF_ERROR_OK;
}

LF_ERROR vector_push_back(LF_VECTOR* vector, void* data)
{
    if(vector->count == vector->max_size)
    {
        if (LF_ERROR_OK != vector_resize(vector, vector->max_size + vector->grow_size))
            return LF_OUT_OF_MEMORY;
    }

    vector->vector_array[vector->count++] = data;

    return LF_ERROR_OK;
}

void* vector_pop_back(LF_VECTOR* vector)
{
    if(vector->count > 0)
    {
        vector->count--;
        return vector->vector_array[vector->count];
    }

    return 0;
}

LF_ERROR vector_erase(LF_VECTOR* vector, size_t index)
{
    if(vector->count > 0 && index < vector->count)
    {
        //previous code to shift array values
        // ULONG i = 0;
        // for(i = index; i < vector->count - 1; i++)
        // {
        //     vector->vector_array[i] = vector->vector_array[i + 1];
        // }
        //
        //optimized code to shift array values (faster than memcpy)

        register void ** pdst = &vector->vector_array[index];
        register void ** pend = &vector->vector_array[vector->count-1];

        while (pdst < pend)
        {
            *pdst = *(pdst + 1);
            pdst++;
        }

        vector->count--;
        return LF_ERROR_OK;
    }

    return LF_INVALID_INDEX;
}

LF_ERROR vector_set_data(LF_VECTOR* vector, size_t index, void* data)
{
    if(index < vector->max_size)
    {
        vector->vector_array[index] = data;
        return LF_ERROR_OK;
    }

    return LF_INVALID_INDEX;
}

LF_ERROR vector_insert(LF_VECTOR* vector, size_t index, void* data)
{
    size_t i;

    if(vector->count+1 >= vector->max_size)
    {
        vector_resize(vector, vector->max_size + vector->grow_size);
    }

    for(i = vector->count; i > index; i--)
    {
        vector->vector_array[i] = vector->vector_array[i - 1];
    }

    vector->vector_array[index] = data;
    vector->count++;

    return LF_ERROR_OK;
}

#if 0 // Unused.
VECTOR_ITER vector_begin(LF_VECTOR* vector)
{
    return &vector->vector_array[0];
}

VECTOR_ITER vector_end(LF_VECTOR* vector)
{
    return &vector->vector_array[vector->count];
}
#endif


void vector_delete(LF_VECTOR* vector)
{
    if (vector && vector->vector_array)
    {
        free(vector->vector_array);
        memset(vector, 0, sizeof(LF_VECTOR));
    }
}

size_t vector_size(const LF_VECTOR* vector)
{
    return vector->count;
}

#if 0 // Unused.
void vector_append(LF_VECTOR* vector, LF_VECTOR* vector2)
{
    ULONG i; 

    for(i = 0; i < vector2->count; i++)
    {
        // TODO: display some warning to the application that the
        // vector array has exceeded the 16 OFFSET value.
        vector_push_back(vector, vector_at(vector2, i));
    }
}
#endif
