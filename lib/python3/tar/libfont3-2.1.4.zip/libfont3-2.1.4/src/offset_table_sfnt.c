// Copyright (C) 2014, 2015 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// offset_table_sfnt.c

#include <string.h>
#include "offset_table_sfnt.h"
#include "table_tags.h"
#include "utils.h"

USHORT offset_log2Floor(size_t tableCount)
{
    SHORT i;
    ULONG maxpow = 0;
    ULONG value = (ULONG)tableCount;

    if (tableCount == 0)
        return 0;

    for (i = 4; i >= 0; --i)
    {
        ULONG shift = ((unsigned)1 << i);
        ULONG x = value >> shift;
        if (x != 0)
        {
            value = x;
            maxpow += shift;
        }
    }

    return (USHORT)maxpow;
}

static void offset_checkGlyphTables(sfnt_offset_table* table, boolean* hasCff, boolean* hasGlyf, boolean* hasLoca,
                               boolean* hasEBLC, boolean* hasEBDT, boolean* hasCBDT, boolean* hasCBLC)
{
    *hasCff = *hasGlyf = *hasLoca = FALSE;
    *hasEBDT = *hasEBLC = *hasCBLC = *hasCBDT = FALSE;

    for (size_t i = 0; i < table->record_list.count; i++)
    {
        sfnt_table_record* record = (sfnt_table_record*)vector_at(&table->record_list, i);

        if (record->tag == TAG_CFF)
            *hasCff = TRUE;
        if (record->tag == TAG_GLYF)
            *hasGlyf = TRUE;
        if (record->tag == TAG_LOCA)
            *hasLoca = TRUE;
        if (record->tag == TAG_EBDT)
            *hasEBDT = TRUE;
        if (record->tag == TAG_EBLC)
            *hasEBLC = TRUE;
        if (record->tag == TAG_CBLC)
            *hasCBLC = TRUE;
        if (record->tag == TAG_CBDT)
            *hasCBDT = TRUE;
    }
}

static void offset_subtractNonCffTables(sfnt_offset_table* table)
{
    for (size_t i = 0; i < table->record_list.count; i++)
    {
        sfnt_table_record* record = (sfnt_table_record*)vector_at(&table->record_list, i);

        if (TableExcludedFromCFFFont(record->tag))
        {
            table->sfntHeader.numTables -= 1;
        }
    }
}

USHORT offset_getNumTables(const LF_FONT* lfFont)
{
    sfnt_offset_table* table = (sfnt_offset_table*)lfFont->offset_table.sfnt;

    if ((lfFont->fontType != eLF_SFNT_FONT) && (lfFont->fontType != eLF_CFF_FONT))
    {
        DEBUG_LOG_ERROR("Invalid output type.");
        return 0;
    }

    USHORT retVal = (USHORT)table->record_list.count;

    boolean hasCff, hasGlyf, hasLoca;
    boolean hasEBDT, hasEBLC, hasCBDT, hasCBLC;

    offset_checkGlyphTables(table, &hasCff, &hasGlyf, &hasLoca, &hasEBLC, &hasEBDT, &hasCBDT, &hasCBLC);

    if (lfFont->fontType == eLF_SFNT_FONT)
    {
        if (hasCff == TRUE)
            table->sfntHeader.numTables -= 1;
    }
    else // CFF
    {
        offset_subtractNonCffTables(table);
    }

    return retVal;
}

LF_ERROR offset_setSignature(const LF_FONT* lfFont, ULONG signature)
{
    sfnt_offset_table* table = (sfnt_offset_table*)lfFont->offset_table.sfnt;
    if (table == NULL)
        return LF_BAD_FORMAT;

    switch (signature)
    {
    default:
        return LF_INVALID_PARAM;
    case SIG_VERSION1:
    case SIG_CFF:
        break;
    }

    table->sfntHeader.sfnt_version = signature;

    return LF_ERROR_OK;
}

sfnt_table_record* offset_getRecord(const LF_FONT* lfFont, size_t index)
{
    sfnt_offset_table* table = (sfnt_offset_table*)lfFont->offset_table.sfnt;
    return (sfnt_table_record*)vector_at(&table->record_list, index);
}

sfnt_table_record* offset_findRecord(const LF_FONT* lfFont, ULONG tag)
{
    sfnt_offset_table* table = (sfnt_offset_table*)lfFont->offset_table.sfnt;
    ULONG i = 0;

    for(; i < table->record_list.count; i++)
    {
        sfnt_table_record* record = (sfnt_table_record*)vector_at(&table->record_list, i);

        if(record && (record->tag == tag))
        {
            return record;
        }
    }

    return NULL;
}

sfnt_table_record* offset_findRecordEx(sfnt_offset_table* table, ULONG tag)
{
    ULONG i = 0;

    for (; i < table->record_list.count; i++)
    {
        sfnt_table_record* record = (sfnt_table_record*)vector_at(&table->record_list, i);

        if (record && (record->tag == tag))
        {
            return record;
        }
    }

    return NULL;
}

boolean offset_recordExists(const LF_FONT* lfFont, ULONG tag)
{
    sfnt_offset_table* table = (sfnt_offset_table*)lfFont->offset_table.sfnt;
    ULONG i = 0;

    for(; i < table->record_list.count; i++)
    {
        sfnt_table_record* record = (sfnt_table_record*)vector_at(&table->record_list, i);

        if(record && (record->tag == tag))
        {
            return TRUE;
        }
    }

    return FALSE;
}

void offset_deleteRecord(const LF_FONT* lfFont, ULONG tag)
{
    sfnt_offset_table* table = (sfnt_offset_table*)lfFont->offset_table.sfnt;
    ULONG i = 0;

    for(; i < table->record_list.count; i++)
    {
        sfnt_table_record* record = (sfnt_table_record*)vector_at(&table->record_list, i);

        if(record && (record->tag == tag))
        {
            vector_erase(&table->record_list, i);
            free(record);
            table->sfntHeader.numTables--;
            return;
        }
    }

    return;
}

// inserts a new record in alphabetical order in the offset table list, assumes list is in order already
LF_ERROR offset_insertNewRecord(const LF_FONT* lfFont, ULONG tag)
{
    if (offset_recordExists(lfFont, tag))
        return LF_INVALID_PARAM;

    sfnt_table_record* newRecord = offset_createRecord();
    if (newRecord == NULL)
        return LF_OUT_OF_MEMORY;

    newRecord->tag = tag;

    sfnt_offset_table* table = (sfnt_offset_table*)lfFont->offset_table.sfnt;
    size_t i;

    for (i = 0; i < table->record_list.count; i++)
    {
        sfnt_table_record* record = (sfnt_table_record*)vector_at(&table->record_list, i);
        if (record == NULL)
        {
            free(newRecord);
            return LF_BAD_FORMAT;
        }

        if (record->tag == tag) //redundant
        {
            free(newRecord);
            return LF_INVALID_PARAM; // table already has this record
        }
        if (record->tag > tag)
        {
            vector_insert(&table->record_list, i, (void*)newRecord);
            return LF_ERROR_OK;
        }
    }

    vector_push_back(&table->record_list, (void*)newRecord);

    return LF_ERROR_OK;
}

sfnt_table_record* offset_readRecord(LF_STREAM* stream)
{
    sfnt_table_record* record = (sfnt_table_record*)malloc(sizeof(sfnt_table_record));
    if(record)
    {
        record->tag = STREAM_readULong(stream);
        record->checkSum = STREAM_readULong(stream);
        record->offset = STREAM_readULong(stream);
        record->length = STREAM_readULong(stream);
    }

    return record;
}

sfnt_offset_table* offset_createTable()
{
    sfnt_offset_table* table = (sfnt_offset_table*)malloc(sizeof(sfnt_offset_table));
    return table;
}


sfnt_offset_table*  offset_copyTable(sfnt_offset_table* table)
{
    sfnt_offset_table* newTable = offset_createTable();

    if (newTable != NULL)
    {
        newTable->sfntHeader.entrySelector = table->sfntHeader.entrySelector;
        newTable->sfntHeader.numTables = table->sfntHeader.numTables;
        newTable->sfntHeader.rangeShift = table->sfntHeader.rangeShift;
        newTable->sfntHeader.searchRange = table->sfntHeader.searchRange;
        newTable->sfntHeader.sfnt_version = table->sfntHeader.sfnt_version;

        LF_ERROR error = vector_init(&newTable->record_list, table->sfntHeader.numTables, 4);
        if (error != LF_ERROR_OK)
        {
            free(newTable);
            return NULL;
        }

        for (size_t i = 0; i < table->record_list.count; i++)
        {
            sfnt_table_record* curRecord = (sfnt_table_record*)vector_at(&table->record_list, i);

            sfnt_table_record* newRecord = (sfnt_table_record*)malloc(sizeof(sfnt_table_record));
            if (newRecord == NULL)
            {
                free(newTable);
                return NULL;
            }

            newRecord->checkSum = curRecord->checkSum;
            newRecord->length = curRecord->length;
            newRecord->offset = curRecord->offset;
            newRecord->tag = curRecord->tag;

            vector_push_back(&newTable->record_list, (void*)newRecord);
        }
    }

    return newTable;
}

sfnt_table_record* offset_createRecord()
{
    sfnt_table_record* record = (sfnt_table_record*)calloc(1,sizeof(sfnt_table_record));
    return record;
}

boolean offset_readFontHeader(const LF_FONT* lfFont, LF_STREAM* stream)
{
    USHORT maxPow2, searchRange, rangeShift;
    sfnt_offset_table* offsetTable = (sfnt_offset_table*)lfFont->offset_table.sfnt;

    offsetTable->sfntHeader.sfnt_version = STREAM_readFixed(stream);
    offsetTable->sfntHeader.numTables = STREAM_readUShort(stream);
    offsetTable->sfntHeader.searchRange = STREAM_readUShort(stream);
    offsetTable->sfntHeader.entrySelector = STREAM_readUShort(stream);
    offsetTable->sfntHeader.rangeShift = STREAM_readUShort(stream);

    maxPow2 = offset_log2Floor(offsetTable->sfntHeader.numTables);

    if (offsetTable->sfntHeader.entrySelector != maxPow2)
    {
        offsetTable->sfntHeader.entrySelector = maxPow2;
        //        return FALSE;
    }

    searchRange = maxPow2 ? (USHORT)((unsigned)1 << (maxPow2 + 4)) : 0;

    if (offsetTable->sfntHeader.searchRange != searchRange)
    {
        offsetTable->sfntHeader.searchRange = searchRange;
//        return FALSE;
    }

    rangeShift = (USHORT)((offsetTable->sfntHeader.numTables << 4) - offsetTable->sfntHeader.searchRange);

    if (offsetTable->sfntHeader.rangeShift != rangeShift)
    {
        offsetTable->sfntHeader.rangeShift = rangeShift;
//        return FALSE;
    }

    return TRUE;
}

boolean offset_readTable(const LF_FONT* lfFont, LF_STREAM* stream, int keepFlags)
{
    USHORT i, numTables;
    sfnt_offset_table* table = (sfnt_offset_table*)lfFont->offset_table.sfnt;

    if(LF_ERROR_OK != vector_init(&table->record_list, table->sfntHeader.numTables, 4))
        return FALSE;

    numTables = table->sfntHeader.numTables;

    for(i = 0; i < numTables; ++i)
    {
        //allocate and read next record
        sfnt_table_record* record = offset_readRecord(stream);

        if(record)
        {
            if((TRUE == LF_retainTable(record->tag, keepFlags)) && (record->length != 0))
            {
                //add to linked list
                vector_push_back(&table->record_list, record);
            }
            else
            {
                free(record);
                table->sfntHeader.numTables--;
            }
        }
        else
        {
            size_t j;
            for(j = 0; j < table->record_list.count; ++j)
                free(vector_at(&table->record_list, j));
            vector_free(&table->record_list);
        }
    }

    return TRUE;
}

LF_ERROR offset_writeTable(const LF_FONT* lfFont, LF_STREAM* stream)
{
    sfnt_offset_table* table = (sfnt_offset_table*)lfFont->offset_table.sfnt;

    if ((lfFont->fontType != eLF_SFNT_FONT) && (lfFont->fontType != eLF_CFF_FONT))
        return LF_INVALID_PARAM;

    table->sfntHeader.numTables = (USHORT)table->record_list.count;

    boolean hasCff, hasGlyf, hasLoca;
    boolean hasEBDT, hasEBLC, hasCBDT, hasCBLC;

    offset_checkGlyphTables(table, &hasCff, &hasGlyf, &hasLoca, &hasEBLC, &hasEBDT, &hasCBDT, &hasCBLC);

    if (lfFont->fontType == eLF_SFNT_FONT)
    {
        if ((hasGlyf == FALSE) && (hasEBDT == FALSE) && (hasCBDT == FALSE))
            return LF_BAD_FORMAT;
        if ((hasGlyf == TRUE) && (hasLoca == FALSE))
            return LF_BAD_FORMAT;
        if ((hasEBDT == TRUE) && (hasEBLC == FALSE))
            return LF_BAD_FORMAT;
        if ((hasCBDT == TRUE) && (hasCBLC == FALSE))
            return LF_BAD_FORMAT;

        if (hasCff == TRUE)
            table->sfntHeader.numTables -= 1;
    }
    else // CFF
    {
        if (hasCff == FALSE)
            return LF_BAD_FORMAT;

        offset_subtractNonCffTables(table);
    }

    USHORT maxPow2 = table->sfntHeader.entrySelector = offset_log2Floor(table->sfntHeader.numTables);
    table->sfntHeader.searchRange = maxPow2 ? (USHORT)((unsigned)1 << (maxPow2 + 4)) : 0;
    table->sfntHeader.rangeShift = (USHORT)((table->sfntHeader.numTables << 4) - table->sfntHeader.searchRange);

    STREAM_writeFixed (stream, table->sfntHeader.sfnt_version);
    STREAM_writeUShort(stream, table->sfntHeader.numTables);
    STREAM_writeUShort(stream, table->sfntHeader.searchRange);
    STREAM_writeUShort(stream, table->sfntHeader.entrySelector);
    STREAM_writeUShort(stream, table->sfntHeader.rangeShift);

    STREAM_streamSeek(stream, 0);

    // write out the table records
    return offset_writeRecords(lfFont, stream);
}

LF_ERROR offset_writeRecords(const LF_FONT* lfFont, LF_STREAM* stream)
{
    sfnt_offset_table* table = (sfnt_offset_table*)lfFont->offset_table.sfnt;

    if ((lfFont->fontType != eLF_SFNT_FONT) && (lfFont->fontType != eLF_CFF_FONT))
        return LF_INVALID_PARAM;

    STREAM_streamSeek(stream, OFFSET_TABLE_SIZE);

    for(size_t i = 0; i < table->record_list.count; i++)
    {
        sfnt_table_record* record = (sfnt_table_record*)vector_at(&table->record_list, i);
        if(record)
        {
            if ((lfFont->fontType == eLF_SFNT_FONT) && (record->tag == TAG_CFF))
                continue;
            if ((lfFont->fontType == eLF_CFF_FONT) && TableExcludedFromCFFFont(record->tag))
                continue;

            STREAM_writeULong(stream, record->tag);
            STREAM_writeULong(stream, record->checkSum);
            STREAM_writeULong(stream, record->offset);
            STREAM_writeULong(stream, record->length);
        }
    }

    return LF_ERROR_OK;
}

LF_ERROR offset_freeTable(LF_FONT* lfFont)
{
    sfnt_offset_table* table = (sfnt_offset_table*)lfFont->offset_table.sfnt;
    ULONG i = 0;

    if(table)
    {
        for(; i < table->record_list.count; i++)
        {
            sfnt_table_record* record = (sfnt_table_record*)vector_at(&table->record_list, i);
            free(record);
        }

        vector_free(&table->record_list);
        free(table);
    }

    lfFont->fontType = eLF_UNDETERMINED;

    return LF_ERROR_OK;
}

LF_ERROR offset_freeTableEx(sfnt_offset_table* table)
{
    ULONG i = 0;

    if (table)
    {
        for (; i < table->record_list.count; i++)
        {
            sfnt_table_record* record = (sfnt_table_record*)vector_at(&table->record_list, i);
            free(record);
        }

        vector_free(&table->record_list);
        free(table);
    }

    return LF_ERROR_OK;
}
