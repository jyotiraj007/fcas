// Copyright (C) 2015, 2016 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
//
/// \file lf_refit.c

#include "lf_refit.h"
#include "cff_refit.h"
#include "table_tags.h"
#include "sfnt_core.h"
#include "cff_table.h"
#include "glyf_table.h"
#include "head_table.h"
#include "hhea_table.h"
#include "hmtx_table.h"
#include "maxp_table.h"
#include "os2_table.h"
#include "vhea_table.h"
#include "vmtx_table.h"
#include "Conversion.h"
#include "cff_conversion.h"

static LF_ERROR checkGlyphTable(const LF_FONT* lfFont, boolean *hasGLYF)
{
    if (NULL != map_at(&lfFont->table_map, (void *)(long)TAG_GLYF))
    {
        *hasGLYF = TRUE;
        return LF_ERROR_OK;
    }
    if (NULL != map_at(&lfFont->table_map, (void *)(long)TAG_CFF))
    {
        *hasGLYF = FALSE;
        return LF_ERROR_OK;
    }
    return LF_TABLE_MISSING;
}


//#define DUMP_ON
#ifdef DUMP_ON

static void dumpQuad(Glyph_Outline* go)
{
    Simple_Outline *quadOutline = &go->component.outline;

    printf("\nQuad Glyph:\n");

    for (int j = 0; j < quadOutline->np; j++)
    {
        printf("%d %f %f %d\n", j, quadOutline->x[j], quadOutline->y[j], quadOutline->types[j]);
    }

    printf("num points = %d\n", quadOutline->np);  //excludes phantom points
    //printf("lsb, rsb = %f,%f\n", quadOutline->x[quadOutline->np - 2], quadOutline->x[quadOutline->np - 1]);
    //printf("bounds = %f,%f,%f,%f\n", go->xMax, go->xMin, go->yMax, go->yMin);
    printf("\n");
}

#define DumpQuad(q) dumpQuad(q)

#else

#define DumpQuad(q)

#endif

static LF_ERROR getCompGlyphInfo(glyf_table* glyfTable, glyf* rootGlyph, const USHORT* pointCounts, USHORT* totalPoints, USHORT* contourCount)
{
    LF_VECTOR compositeList = rootGlyph->glyf_data.composite;

    for (USHORT j = 0; j < compositeList.count; j++)
    {
        composite_glyf* compGlyph = (composite_glyf*)vector_at(&compositeList, j);

        *totalPoints += pointCounts[compGlyph->glyphIndex];

        glyf compGlyf;

        LF_ERROR error = GLYF_getGlyf(glyfTable, compGlyph->glyphIndex, &compGlyf);
        if (error != LF_ERROR_OK)
        {
            return error;
        }

        if (compGlyf.numberOfContours == -1)
        {
            error = getCompGlyphInfo(glyfTable, &compGlyf, pointCounts, totalPoints, contourCount);
            if (error != LF_ERROR_OK)
            {
                GLYF_destroyGlyf(&compGlyf);
                return error;
            }
        }
        else
        {
            contourCount += compGlyf.numberOfContours;
        }

        GLYF_destroyGlyf(&compGlyf);
    }

    return LF_ERROR_OK;
}


LF_ERROR sfnt_refit(LF_FONT*lfFont, float fitTolerance, boolean replaceAll, refitCBInfo* progCBInfo)
{
    // Get glyf table.
    glyf_table* glyfTable = (glyf_table*)map_at(&lfFont->table_map, (void*)TAG_GLYF);
    if (glyfTable == NULL)
        return LF_TABLE_MISSING;

    if (progCBInfo != NULL)
        progCBInfo->progressCB(progCBInfo->userState, 5);

    // Get the design units from the head table.
    USHORT origUPM = HEAD_getUnitsPerEM(lfFont);
    if (origUPM == 0)
        return LF_TABLE_MISSING;

    // Allocate scratch buffers to used when converting SimpleGlyph to a glyf
    glyfBuildScratchSpace scratch;

    if (0 != conversion_allocateScratchSpace(&scratch, 256))
        return LF_OUT_OF_MEMORY;

    USHORT i, numGlyphs = (USHORT)map_size(glyfTable->glyfMap);

    // Allocate block to keep track of the number of points in each glyph
    // so the maxp table can be updated.
    USHORT* pointCounts = (USHORT*)calloc(numGlyphs, sizeof(USHORT));
    if (pointCounts == NULL)
    {
        conversion_freeScratchSpace(&scratch);
        return LF_OUT_OF_MEMORY;
    }


    boolean hasComposites = FALSE;
    boolean anyChanges = FALSE;

    float scaledTolerance = fitTolerance * (origUPM / 1000.0f);

    // progress in this functions starts at 5% and ends at 85%
    USHORT curProg = 5;
    USHORT progMod = numGlyphs / 16;    // report at approx. 5% intervals

    LF_ERROR error;

    // loop over glyphs
    for (i = 0; i < numGlyphs; i++)
    {
        // Get Glyph
        glyf curGlyf;

        if ((progCBInfo != NULL) && (progMod != 0) && (i % progMod == 0))
        {
            progCBInfo->progressCB(progCBInfo->userState, curProg);
            curProg += 5;
        }

        error = GLYF_getGlyf(glyfTable, i, &curGlyf);
        if (error != LF_ERROR_OK)
        {
            free(pointCounts);
            conversion_freeScratchSpace(&scratch);
            return error;
        }

        if ((curGlyf.numberOfContours == 0) || (curGlyf.numberOfContours == -1))
        {
            if (curGlyf.numberOfContours == -1)
                hasComposites = TRUE;

            GLYF_destroyGlyf(&curGlyf);
            continue;
        }

        // Get glyph points
        LF_VECTOR* points = vector_create(128, 64); // each point consumes 4 entries, so this starts with space for 32 points and grows by 16

        if (points == NULL)
        {
            GLYF_destroyGlyf(&curGlyf);
            free(pointCounts);
            conversion_freeScratchSpace(&scratch);
            return LF_OUT_OF_MEMORY;
        }

        error = GLYF_getGlyfPointsInternal(glyfTable, &curGlyf, points);
        if (error != LF_ERROR_OK)
        {
            vector_free(points);
            free(points);
            GLYF_destroyGlyf(&curGlyf);
            free(pointCounts);
            conversion_freeScratchSpace(&scratch);
            return error;
        }

        // convert points to SimpleOutline
        Glyph quadGlyph;
        conversion_setGlyphOutlineParams(&quadGlyph.glyphOutline, i);

        error = conversion_addPointsToGlyphOutline(points, &quadGlyph.glyphOutline);
        if (error != LF_ERROR_OK)
        {
            vector_free(points);
            free(points);
            GLYF_destroyGlyf(&curGlyf);
            conversion_freeGlyphOutline(&quadGlyph);
            free(pointCounts);
            conversion_freeScratchSpace(&scratch);
            return error;
        }

        // refit to new quad
        Glyph refitGlyph;

        memset(&refitGlyph, 0, sizeof(Glyph));

        refitGlyph.glyphOutline.numberOfComponents = 1;

        Simple_Outline *origOutline = &quadGlyph.glyphOutline.component.outline;
        Simple_Outline *refitOutline = &refitGlyph.glyphOutline.component.outline;

        origOutline->designUnits = origUPM;
        refitOutline->designUnits = origUPM;

        DumpQuad(&quadGlyph.glyphOutline);

        Conversion_Error err = refitQuadratic(origOutline, scaledTolerance, refitOutline);
        if (CONVERSION_SUCCESS != err)
        {
            vector_free(points);
            free(points);
            conversion_freeGlyphOutline(&quadGlyph);
            GLYF_destroyGlyf(&curGlyf);
            free(pointCounts);
            conversion_freeScratchSpace(&scratch);
            return (err == CONVERSION_MEMORY) ? LF_OUT_OF_MEMORY : LF_CONVERSION;
        }

        // compute outline bounding box
        conversion_computeQuadBoundingBox(&refitGlyph);

        DumpQuad(&refitGlyph.glyphOutline);

        // See if new quad has fewer points
        int origNumPoints = (int)(points->count / 4);

        //if (origNumPoints < refitOutline->np)
        //    printf("num points increased for glyph %d : %d to %d\n", i, origNumPoints, refitOutline->np);

        if ((replaceAll == TRUE) || (refitOutline->np < origNumPoints))
        {
            anyChanges = TRUE;

            if (quadGlyph.glyphOutline.component.outline.np > scratch.allocated)
            {
                size_t newSize = scratch.allocated;
                while (newSize < quadGlyph.glyphOutline.component.outline.np)
                    newSize += 256;
                if (0 != conversion_reallocateScratchSpace(&scratch, newSize))
                {
                    vector_free(points);
                    free(points);
                    conversion_freeGlyphOutline(&quadGlyph);
                    GLYF_destroyGlyf(&curGlyf);
                    free(pointCounts);
                    return LF_OUT_OF_MEMORY;
                }
            }

            // create new glyf
            glyf* quad_glyf = (glyfTable->glyphDataBlock + i);

            free(quad_glyf->glyfBlock);

            error = conversion_convertGlyphToCompressedGlyf(&refitGlyph, &scratch, quad_glyf);
            if (error != LF_ERROR_OK)
            {
                conversion_freeGlyphOutline(&quadGlyph);
                conversion_freeGlyphOutline(&refitGlyph);
                vector_free(points);
                free(points);
                free(pointCounts);
                conversion_freeScratchSpace(&scratch);
                return error;
            }

            // update maxp info
            pointCounts[i] = refitGlyph.glyphOutline.component.outline.np;

            if (refitGlyph.glyphOutline.component.outline.np > glyfTable->derivedMaxp.maxPoints)
                glyfTable->derivedMaxp.maxPoints = refitGlyph.glyphOutline.component.outline.np;

            if (refitGlyph.glyphOutline.component.outline.nc > glyfTable->derivedMaxp.maxContours)
                glyfTable->derivedMaxp.maxContours = refitGlyph.glyphOutline.component.outline.nc;
        }
        else
        {
            // update maxp info
            pointCounts[i] = quadGlyph.glyphOutline.component.outline.np;

            if (quadGlyph.glyphOutline.component.outline.np > glyfTable->derivedMaxp.maxPoints)
                glyfTable->derivedMaxp.maxPoints = quadGlyph.glyphOutline.component.outline.np;

            if (quadGlyph.glyphOutline.component.outline.nc > glyfTable->derivedMaxp.maxContours)
                glyfTable->derivedMaxp.maxContours = quadGlyph.glyphOutline.component.outline.nc;
        }

        GLYF_destroyGlyf(&curGlyf);
        conversion_freeGlyphOutline(&quadGlyph);
        conversion_freeGlyphOutline(&refitGlyph);
        vector_free(points);
        free(points);
    }

    if (progCBInfo != NULL)
        progCBInfo->progressCB(progCBInfo->userState, 85);

    // Update the maxp table
    if ((anyChanges == TRUE) && (hasComposites == TRUE))
    {
        USHORT maxCompPoints = 0, maxCompContours = 0;

        for (i = 0; i < numGlyphs; i++)
        {
            // Get Glyph
            glyf curGlyf;

            error = GLYF_getGlyf(glyfTable, i, &curGlyf);
            if (error != LF_ERROR_OK)
            {
                free(pointCounts);
                conversion_freeScratchSpace(&scratch);
                return error;
            }

            // if composite, get the total points
            if (curGlyf.numberOfContours == -1)
            {
                USHORT totalPoints = 0, numCompContours = 0;

                error = getCompGlyphInfo(glyfTable, &curGlyf, pointCounts, &totalPoints, &numCompContours);
                if (error != LF_ERROR_OK)
                {
                    GLYF_destroyGlyf(&curGlyf);
                    free(pointCounts);
                    conversion_freeScratchSpace(&scratch);
                    return error;
                }

                if (totalPoints > maxCompPoints)
                    maxCompPoints = totalPoints;

                if (numCompContours > maxCompContours)
                    maxCompContours = numCompContours;
            }

            GLYF_destroyGlyf(&curGlyf);
        }

        glyfTable->derivedMaxp.maxCompositePoints = maxCompPoints;
        glyfTable->derivedMaxp.maxCompositeContours = maxCompContours;
    }

    glyfTable->maxpInfoUpdated = TRUE;

    free(pointCounts);
    conversion_freeScratchSpace(&scratch);

    return LF_ERROR_OK;
}

LF_ERROR LF_refitFont(LF_FONT* lfFont, float fitTolerance, boolean replaceAll, refitCBInfo* progresInfo)
{
    if (lfFont == NULL)
        return LF_INVALID_PARAM;
    if (fitTolerance < 0.3f || fitTolerance > 10.0)
        return LF_INVALID_PARAM;

    LF_ERROR error;

    if (progresInfo != NULL)
        progresInfo->progressCB(progresInfo->userState, 0);

    // Tables must be unpacked in order to do a refit.
    if (map_empty(&lfFont->table_map))
    {
        error = SFNT_unpackTables(lfFont);
        if (error != LF_ERROR_OK)
            return error;
    }

    // font must have either glyf or cff
    boolean hasGLYF;
    error = checkGlyphTable(lfFont, &hasGLYF);
    if (error != LF_ERROR_OK)
        return error;

    if (progresInfo != NULL)
        progresInfo->progressCB(progresInfo->userState, 3);

    // Refit the glyphs
    if (hasGLYF)
        error = sfnt_refit(lfFont, fitTolerance, replaceAll, progresInfo);
    else
        error = cff_refit(lfFont, fitTolerance, replaceAll, progresInfo);

    if (error != LF_ERROR_OK)
        return error;

    // Update other tables
    boolean hasVHEA, hasVMTX;

    LF_hasTable(lfFont, TAG_VHEA, &hasVHEA);
    LF_hasTable(lfFont, TAG_VMTX, &hasVMTX);

    MAXP_updateTable(lfFont, (hasGLYF) ? TAG_GLYF : TAG_CFF, TRUE, FALSE, FALSE);

    if (hasVHEA && hasVMTX)
    {
        VHEA_setAdvanceHeightMax(lfFont, VMTX_getAdvanceHeightMax(lfFont));
        VHEA_setNumVMetrics(lfFont, VMTX_getNumVMetrics(lfFont));
        VHEA_setTopSidebearingMin(lfFont, VMTX_getMinTopSidebearing(lfFont));
        VHEA_setVertTypoLineGap(lfFont, 0);
    }

    SHORT xMin, yMin, xMax, yMax;

    if (hasGLYF)
        error = GLYF_getBoundingBox(lfFont, &xMin, &yMin, &xMax, &yMax);
    else
        error = CFF__getBoundingBox(lfFont, &xMin, &yMin, &xMax, &yMax);

    if (error != LF_ERROR_OK)
        return error;

    if (progresInfo != NULL)
        progresInfo->progressCB(progresInfo->userState, 90);

    // Update hmtx side bearings and get min values
    FWORD minlsb, minrsb, maxadvance;
    error = HMTX_updateSidebearings(lfFont, lfFont->fontType, &minlsb, &minrsb, &maxadvance);
    if (error != LF_ERROR_OK)
        return error;

    HEAD_setBoundingBox(lfFont, xMin, yMin, xMax, yMax);
    HHEA_setXMaxExtent(lfFont, xMax);
    HHEA_setLeftSidebearingMin(lfFont, minlsb);
    HHEA_setRightSidebearingMin(lfFont, minrsb);
    HHEA_setAdvanceWidthMax(lfFont, maxadvance);
    HHEA_setNumHMetrics(lfFont, HMTX_getNumHMetrics(lfFont));

    if ((hasGLYF) && (replaceAll))
        error = SFNT_removeHints(lfFont);

    USHORT os2Version;
    OS2_getVersion(lfFont, &os2Version);
    if (os2Version < 3)
        OS2_upgradeTable(lfFont);
    else
    {
        OS2_updateHeights(lfFont);
        //OS2_updateMaxContent(lfFont);
    }
    OS2_setAvgCharWidth(lfFont, HMTX_getAdvanceWidthAvg(lfFont));

    lfFont->isRefitted = TRUE;

    if (progresInfo != NULL)
        progresInfo->progressCB(progresInfo->userState, 100);

    return error;
}
