// Copyright (C) 2014 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// link_list.c

#include "link_list.h"

void list_init(link_list* list)
{
    list->head = NULL;
    list->last = NULL;
    list->count = 0;
}

link_node* list_at(const link_list* list, int index)
{
    link_node* node = NULL;

    if(list)
    {
        node = list->head;

        while(node && index--)
            node = node->next;
    }

    return node;
}

link_node* list_insert(link_list* list, void* data, link_node* after)
{
    link_node* node = (link_node*)calloc(1, sizeof(link_node));
    if(node)
    {
        node->data = data;
        node->next = after->next;
        node->prev = after;
        after->next = node;

        if(list->last == after)
            list->last = node;

        list->count++;
    }
    return node;
}

link_node* list_append(link_list* list, void* data)
{
    link_node* appended;

    if(list->head == NULL)
    {
        link_node* node = (link_node*)calloc(1, sizeof(link_node));
        if(node)
        {
            node->data = data;
            appended = node;

            list->head = list->last = node;
            list->count = 1;
        }
        else
            appended = NULL;
    }
    else
    {
        appended = list_insert(list, data, list->last);
    }

    return appended;
}

void list_delete(link_list* list, link_node* node)
{
    link_node* prev = node->prev;
    link_node* next = node->next;

    if(list->head == node)
        list->head = list->head->next;

    if(list->last == node)
        list->last = list->last->prev;

    if(prev != NULL)
        prev->next = node->next;

    if(next != NULL)
        next->prev = node->prev;

    free(node);
    list->count--;
}
