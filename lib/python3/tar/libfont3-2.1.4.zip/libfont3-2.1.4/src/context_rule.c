// Copyright (C) 2014 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// context_rule.c

#include "context_rule.h"
#include "common_table.h"
#include "utils.h"
#include "stream.h"

/* ----------------------------------------------------------------------------
    @summary
        read in the Context Rule table into memory and store in the structures.

    @description
        A Rule table consists of a count of the glyphs to be matched in
        the input context sequence (GlyphCount), including the first glyph
        in the sequence, and an array of glyph indices that describe the
        context (Input). The Coverage table specifies the index of the first
        glyph in the context, and the Input array begins with the second glyph
        (array index = 1) in the context sequence.

        Note: The Input array lists the indices in the order the corresponding
        glyphs appear in the text. For text written from right to left, the
        right-most glyph will be first; conversely, for text written from
        left to right, the left-most glyph will be first.

        A SubRule table also contains a count of the substitutions to be
        performed on the input glyph sequence (SubstCount) and an array
        of SubstitutionLookupRecords (SubstLookupRecord). Each record
        specifies a position in the input glyph sequence and a
        LookupListIndex to the substitution lookup that is applied at
        that position. The array should list records in design order,
        or the order the lookups should be applied to the entire glyph
        sequence.

    @param
        sr = pointer to SubRule table
        stream = pointer to the stream that points to the start of
                 the SubRule table.

    @return
        LF_ERROR_OK - returned if everything read correctly.
---------------------------------------------------------------------------- */
LF_ERROR ContextRule_readRule(context_rule* sr, LF_STREAM* stream)
{
    LF_ERROR        error;

    sr->GlyphCount = STREAM_readUShort(stream);
    sr->LookupCount = STREAM_readUShort(stream);

    error = ContextRule_readInputSequence(&sr->Input, sr->GlyphCount, stream);
    if (error != LF_ERROR_OK)
    {
        DEBUG_LOG_ERROR("error reading Input Sequence");
        ContextRule_freeRule(sr);
        return LF_OUT_OF_MEMORY;
    }

    error = Common_readSubstLookupRecords(&sr->LookupRecords, sr->LookupCount, stream);

    if (error != LF_ERROR_OK)
    {
        DEBUG_LOG_ERROR("error reading lookup records");
        ContextRule_freeRule(sr);
        return LF_OUT_OF_MEMORY;
    }
    return LF_ERROR_OK;
}



/* ----------------------------------------------------------------------------
    @description
        read in the input sequence from the stream and populate the 
        passed vector collection.

    @param
        input       :   pointer to the vector collection
        count       :   number of glyphs to populate.  includes coverage
                        glyph as well.

        stream      :   pointer to the stream

---------------------------------------------------------------------------- */
LF_ERROR ContextRule_readInputSequence(LF_VECTOR* input, USHORT count, LF_STREAM* stream)
{
    LF_ERROR    error;
    USHORT      n;


    error = vector_init(input, count, sizeof(ULONG));
    if (error !=  LF_ERROR_OK)
    {
        return LF_OUT_OF_MEMORY;
    }

    // NOTE: the glyph count contains the input stream + the coverage glyph.  You need
    //         to make sure you subtract 1 when reading from the stream.  This goes the
    //         the same when building the stream.  You need to add 1 to the Input sequence
    //         count.
    for (n = 0; n < count - 1; n++)
    {
        USHORT glyph = STREAM_readUShort(stream);
        vector_push_back(input, (void*)(intptr_t)glyph);
    }
    return LF_ERROR_OK;
}




/* ----------------------------------------------------------------------------

---------------------------------------------------------------------------- */
void    ContextRule_freeRule(context_rule* sr)
{
    if (sr)
    {
        vector_delete(&sr->Input);
        Common_freeSubstLookupRecords(&sr->LookupRecords);
    }
}



/* ----------------------------------------------------------------------------
    @summary
        get size of context rule structure.

    @param
        sr        : pointer to context rule structure.

    @return
        size of rule structure in bytes.

---------------------------------------------------------------------------- */
size_t ContextRule_sizeRule(context_rule* sr)
{
    size_t size = 0;

    size += sizeof(sr->GlyphCount);                             // GlyphCount
    size += sizeof(sr->LookupCount);                            // LookupCount
    size += sizeof(GlyphID) * sr->Input.count;                  // Input Array
    size += Common_sizeSubstLookupRecords(&sr->LookupRecords);  // SubstLookupRecord Array

    return size;
}



/* ----------------------------------------------------------------------------
    @summary
        build the context rule and write the OpenType structures to
        the passed stream.


    @param
        sr = pointer to the context rule.
        stream = pointer to the stream to write to.


---------------------------------------------------------------------------- */
size_t ContextRule_buildRule(context_rule* sr, LF_STREAM* stream)
{
    USHORT n;
    USHORT count = UTILS_getCount(&sr->Input);

    STREAM_writeUShort(stream, count + 1);
    STREAM_writeUShort(stream, sr->LookupCount);

    for ( n = 0; n < sr->Input.count; n++ )
    {
        USHORT glyph = (USHORT)(intptr_t)vector_at(&sr->Input, n);
        STREAM_writeUShort(stream, glyph);
    }

    Common_buildSubstLookupRecords(&sr->LookupRecords, stream);
    return STREAM_streamPos(stream);
}

#ifdef LF_OT_DUMP
/* ============================================================================
    @description
        dump the rule to the logging stream.

============================================================================ */
void ContextRule_dumpRule(context_rule* cr)
{
    USHORT i;
    DEBUG_LOG_VALUE("GlyphCount: ", cr->GlyphCount);
    DEBUG_LOG_VALUE("LookupCount: ", (int)cr->LookupRecords.count);

    if (cr->Input.count)
    {
        for (i = 0; i < cr->Input.count; i++)
        {
            //lint -size(a, 2049)
            char    msg[2048];
            //lint -size(a, 0)
            USHORT    glyph = (USHORT)(long)vector_at(&cr->Input, i);

            sprintf(msg, "Input[%d] = %d", i, glyph);
            DEBUG_LOG(msg);
        }
    }
    else
    {
        DEBUG_LOG("Input[] only contains coverage glyph");
    }

    Common_dumpSubstLookupRecords(&cr->LookupRecords);
}
#endif

LF_ERROR ContextRule_searchSequence(LF_VECTOR* sequence, GlyphID glyphid, USHORT* index)
{
    USHORT i;

    for ( i = 0; i < sequence->count; i++ )
    {
        GlyphID glyph = (GlyphID)(intptr_t)vector_at(sequence, i);
        if (glyphid == glyph)
        {
            *index = i;
            return LF_ERROR_OK;
        }
    }
    return LF_NOT_COVERED;
}




LF_ERROR ContextRule_searchRule(context_rule* cr, GlyphID glyphid, USHORT* index)
{
    if (cr && cr->Input.count)
    {
        return ContextRule_searchSequence(&cr->Input, glyphid, index);
    }
    return LF_NOT_COVERED;
}

LF_ERROR ContextRule_remapRule(context_rule* cr, LF_MAP *remap)
{
    if (cr)
    {
        USHORT i, numInputs = (USHORT)vector_size(&cr->Input);
        GlyphID origIndex, newIndex;

        for (i = 0; i < numInputs; i++)
        {
            origIndex = (GlyphID)(intptr_t)vector_at(&cr->Input, i);
            newIndex = (GlyphID)(intptr_t)map_at(remap, (void *)(intptr_t)origIndex);
            vector_set_data(&cr->Input, i, (void *)(intptr_t)newIndex);
        }
    }
    return LF_ERROR_OK;
}


void ContextRule_cleanupLookups(context_rule* cr, TABLE_HANDLE hLookups)
{
    Common_cleanupLookups(&cr->LookupRecords, hLookups);
}



LF_ERROR ContextRule_existsInKeepTable(GlyphList* keepList, LF_VECTOR* glyphs)
{
    if (glyphs)
    {
        USHORT i, numInputs = (USHORT)vector_size(glyphs);
        GlyphID glyph;

        if (numInputs == 0)
            return LF_EMPTY_TABLE;

        for (i = 0; i < numInputs; i++)
        {
            glyph = (GlyphID)(intptr_t)vector_at(glyphs, i);
            if (Keep_coverageExists(keepList, glyph) != LF_ERROR_OK)
                return LF_NOT_COVERED;
        }
    }
    return LF_ERROR_OK;
}

/* ============================================================================
    @summary
        collect



============================================================================ */
LF_ERROR ContextRule_collectGlyphs(context_rule* cr, GlyphList* keepList, TABLE_HANDLE hTable)
{
    LF_ERROR error = LF_ERROR_OK;

    if (cr)
    {
        LF_ERROR status = ContextRule_existsInKeepTable(keepList, &cr->Input);
        if (status != LF_ERROR_OK)
            return LF_NOT_COVERED;

        // if we get here, then the context exists within the keepTable, so
        // we can add the substitution glyph to the rule.
        error = Common_collectLookupRecordGlyphs(&cr->LookupRecords, keepList, hTable);
    }
    return error;
}
