// Copyright (C) 2014 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// offset_table_woff.c

#include <string.h>

#include "offset_table_woff.h"
#include "utils.h"

static woff_table_record* offset_woff_readRecord(LF_STREAM* stream)
{
    woff_table_record* record = (woff_table_record*)malloc(sizeof(woff_table_record));
    if(record != NULL)
    {
        record->tag = STREAM_readULong(stream);
        record->offset = STREAM_readULong(stream);
        record->compLength = STREAM_readULong(stream);
        record->origLength = STREAM_readULong(stream);
        record->origChecksum = STREAM_readULong(stream);
    }

    return record;
}

woff_offset_table* offset_woff_readTable(LF_STREAM* stream, int keepFlags)
{
    USHORT i = 0, numTables;
    woff_offset_table* table = (woff_offset_table*)malloc(sizeof(woff_offset_table));

    if(table != NULL)
    {
        table->woffHeader.signature = STREAM_readULong(stream);
        table->woffHeader.flavor = STREAM_readULong(stream);
        table->woffHeader.length = STREAM_readULong(stream);
        table->woffHeader.numTables = STREAM_readUShort(stream);
        table->woffHeader.reserved = STREAM_readUShort(stream);
        table->woffHeader.totalSfntSize = STREAM_readULong(stream);
        table->woffHeader.majorVersion = STREAM_readUShort(stream);
        table->woffHeader.minorVersion = STREAM_readUShort(stream);
        table->woffHeader.metaOffset = STREAM_readULong(stream);
        table->woffHeader.metaLength = STREAM_readULong(stream);
        table->woffHeader.metaOrigLength = STREAM_readULong(stream);
        table->woffHeader.privOffset = STREAM_readULong(stream);
        table->woffHeader.privLength = STREAM_readULong(stream);

        numTables = table->woffHeader.numTables;
        vector_init(&table->record_list, table->woffHeader.numTables, 4);

        for(i = 0; i < numTables; ++i)
        {
            //allocate and read next record
            woff_table_record* record = offset_woff_readRecord(stream);

            if(record != NULL)
            {
                if((TRUE == LF_retainTable(record->tag, keepFlags)) && (record->origLength != 0))
                {
                    //add to linked list
                    vector_push_back(&table->record_list, record);
                }
                else
                {
                    free(record);
                    table->woffHeader.numTables--;
                }
            }
            else
            {
                DEBUG_LOG_ERROR("allocation failure in offset_woff_readTable");
            }
        }
    }

    return table;
}

size_t offset_woff_writeTable(woff_offset_table* table, LF_STREAM* stream)
{
    ULONG i = 0;

    if(table == NULL)
        return 0;

    STREAM_writeULong(stream, table->woffHeader.signature);
    STREAM_writeULong(stream, table->woffHeader.flavor);
    STREAM_writeULong(stream, table->woffHeader.length);
    STREAM_writeUShort(stream, (USHORT)table->record_list.count);
    STREAM_writeUShort(stream, 0);
    STREAM_writeULong(stream, table->woffHeader.totalSfntSize);
    STREAM_writeUShort(stream, table->woffHeader.majorVersion);
    STREAM_writeUShort(stream, table->woffHeader.minorVersion);
    STREAM_writeULong(stream, table->woffHeader.metaOffset);
    STREAM_writeULong(stream, table->woffHeader.metaLength);
    STREAM_writeULong(stream, table->woffHeader.metaOrigLength);
    STREAM_writeULong(stream, table->woffHeader.privOffset);
    STREAM_writeULong(stream, table->woffHeader.privLength);

    //write out the table records
    for(; i < table->record_list.count; i++)
    {
        woff_table_record* record = (woff_table_record*)vector_at(&table->record_list, i);

        if(record)
        {
            STREAM_writeULong(stream, record->tag);
            STREAM_writeULong(stream, record->offset);
            STREAM_writeULong(stream, record->compLength);
            STREAM_writeULong(stream, record->origLength);
            STREAM_writeULong(stream, record->origChecksum);
        }
    }

    return STREAM_streamPos(stream);
}

LF_ERROR offset_woff_freeTable(woff_offset_table* table)
{
    ULONG i = 0;

    for(; i < table->record_list.count; i++)
    {
        woff_table_record* record = (woff_table_record*)vector_at(&table->record_list, i);
        free(record);
    }

    vector_free(&table->record_list);
    free(table);

    return LF_ERROR_OK;
}
