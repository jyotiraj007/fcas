// Copyright (C) 2014, 2016, 2017 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// sfnt_core.c

#include <stdio.h>
#include <string.h>
#include "lf_core.h"
#include "stream.h"
#include "sfnt_core.h"
#include "gsub_table.h"
#include "gpos_table.h"
#include "os2_table.h"
#include "cmap_table.h"
#include "glyf_table.h"
#include "cbdt_table.h"
#include "cblc_table.h"
#include "colr_table.h"
#include "cpal_table.h"
#include "cff_table.h"
#include "ebdt_table.h"
#include "eblc_table.h"
#include "fmtx_table.h"
#include "fvar_table.h"
#include "gvar_table.h"
#include "hdmx_table.h"
#include "head_table.h"
#include "hhea_table.h"
#include "hmtx_table.h"
#include "loca_table.h"
#include "maxp_table.h"
#include "name_table.h"
#include "post_table.h"
#include "sbix_table.h"
#include "gdef_table.h"
#include "vhea_table.h"
#include "vmtx_table.h"
#include "kern_table.h"
#include "ltsh_table.h"
#include "unknown_table.h"
#include "table_tags.h"
#include "offset_table_sfnt.h"
#include "cff_conversion.h"

static LF_ERROR SFNT_loadTable(LF_FONT* lfFont, const sfnt_table_record* record, LF_STREAM* stream)
{
    switch(record->tag)
    {
        case TAG_CFF:     return CFF__readTable(lfFont, record, stream);
        case TAG_CMAP:    return CMAP_readTable(lfFont, record, stream);
        case TAG_GDEF:    return GDEF_readTable(lfFont, record, stream);
        case TAG_GLYF:    return GLYF_readTable(lfFont, record, stream);
        case TAG_GPOS:    return GPOS_readTable(lfFont, record, stream);
        case TAG_GSUB:    return GSUB_readTable(lfFont, record, stream);
        case TAG_HDMX:    return HDMX_readTable(lfFont, record, stream);
        case TAG_HEAD:    return LF_ERROR_OK; // read second
        case TAG_HHEA:    return LF_ERROR_OK; // read third
        case TAG_HMTX:    return LF_ERROR_OK; // read fourth
        case TAG_KERN:    return KERN_readTable(lfFont, record, stream);
        case TAG_LTSH:    return LTSH_readTable(lfFont, record, stream);
        case TAG_LOCA:    return LF_ERROR_OK; // read sixth if present
        case TAG_CBLC:    return LF_ERROR_OK; // read seventh if present
        case TAG_EBLC:    return LF_ERROR_OK; // read eight if present
        case TAG_MAXP:    return LF_ERROR_OK; // read first
        case TAG_NAME:    return NAME_readTable(lfFont, record, stream);
        case TAG_OS2:     return OS2_readTable (lfFont, record, stream);
        case TAG_POST:    return LF_ERROR_OK; // read fifth
        case TAG_SBIX:    return SBIX_readTable(lfFont, record, stream);
        case TAG_VHEA:    return VHEA_readTable(lfFont, record, stream);
        case TAG_VMTX:    return VMTX_readTable(lfFont, record, stream);
        case TAG_EBDT:    return EBDT_readTable(lfFont, record, stream);
        case TAG_CBDT:    return CBDT_readTable(lfFont, record, stream);
        case TAG_COLR:    return COLR_readTable(lfFont, record, stream);
        case TAG_CPAL:    return CPAL_readTable(lfFont, record, stream);
        case TAG_FVAR:    return FVAR_readTable(lfFont, record, stream);
        case TAG_GVAR:    return GVAR_readTable(lfFont, record, stream);
        case TAG_FMTX:    return FMTX_readTable(lfFont, record, stream);
        default:          break;
    }

    return UNKNOWN_readTable(lfFont, record, stream);
}

static LF_ERROR SFNT_getTableSize(LF_FONT* lfFont, const LF_WRITE_PARAMS *params, ULONG tag, size_t* size)
{
    UNUSED(params);

    *size = 0;

    switch(tag)
    {
        case TAG_CFF:       return CFF__getTableSize(lfFont, size);
        case TAG_CMAP:      return CMAP_getTableSize(lfFont, size);
        case TAG_GDEF:      return GDEF_getTableSize(lfFont, size);
        case TAG_GLYF:      return GLYF_getTableSize(lfFont, size);
        case TAG_GPOS:      return GPOS_getTableSize(lfFont, size);
        case TAG_GSUB:      return GSUB_getTableSize(lfFont, size);
        case TAG_HDMX:      return HDMX_getTableSize(lfFont, size);
        case TAG_HEAD:      return HEAD_getTableSize(lfFont, size);
        case TAG_HHEA:      return HHEA_getTableSize(lfFont, size);
        case TAG_HMTX:      return HMTX_getTableSize(lfFont, size);
        case TAG_KERN:      return KERN_getTableSize(lfFont, size);
        case TAG_LOCA:      return LOCA_getTableSize(lfFont, size);
        case TAG_MAXP:      return MAXP_getTableSize(lfFont, 0x00010000, size);
        case TAG_LTSH:      return LTSH_getTableSize(lfFont, size);
        case TAG_NAME:      return NAME_getTableSize(lfFont, size);
        case TAG_OS2:       return OS2_getTableSize(lfFont, size);
        case TAG_POST:      return POST_getTableSize(lfFont, params->postTableVersion, size);
        case TAG_SBIX:      return SBIX_getTableSize(lfFont, size);
        case TAG_VHEA:      return VHEA_getTableSize(lfFont, size);
        case TAG_VMTX:      return VMTX_getTableSize(lfFont, size);
        case TAG_CBDT:      return CBDT_getTableSize(lfFont, size);
        case TAG_CBLC:      return CBLC_getTableSize(lfFont, size);
        case TAG_EBDT:      return EBDT_getTableSize(lfFont, size);
        case TAG_EBLC:      return EBLC_getTableSize(lfFont, size);
        case TAG_COLR:      return COLR_getTableSize(lfFont, size);
        case TAG_CPAL:      return CPAL_getTableSize(lfFont, size);
        case TAG_FVAR:      return FVAR_getTableSize(lfFont, size);
        case TAG_GVAR:      return GVAR_getTableSize(lfFont, size);
        case TAG_FMTX:      return FMTX_getTableSize(lfFont, size);
        default:            break;
    }

    return UNKNOWN_getTableSize(lfFont, tag, size);
}

LF_ERROR SFNT_writeTable(LF_FONT* lfFont, const LF_WRITE_PARAMS *params, sfnt_table_record* record, LF_STREAM* stream)
{
    UNUSED(params);

    switch(record->tag)
    {
        case TAG_GSUB:    return GSUB_writeTable(lfFont, record, stream);
        case TAG_GPOS:    return GPOS_writeTable(lfFont, record, stream);
        case TAG_CMAP:    return CMAP_writeTable(lfFont, record, stream);
        case TAG_GLYF:    return GLYF_writeTable(lfFont, record, stream);
        case TAG_HEAD:    return HEAD_writeTable(lfFont, record, stream);
        case TAG_HHEA:    return HHEA_writeTable(lfFont, record, stream);
        case TAG_HMTX:    return HMTX_writeTable(lfFont, record, stream);
        case TAG_LOCA:    return LOCA_writeTable(lfFont, record, stream);
        case TAG_MAXP:    return MAXP_writeTable(lfFont, (lfFont->fontType == eLF_CFF_FONT) ? 0x00005000 : 0x00010000, record, stream);
        case TAG_POST:    return POST_writeTable(lfFont, params->postTableVersion, record, stream);
        case TAG_GDEF:    return GDEF_writeTable(lfFont, record, stream);
        case TAG_HDMX:    return HDMX_writeTable(lfFont, record, stream);
        case TAG_KERN:    return KERN_writeTable(lfFont, record, stream);
        case TAG_LTSH:    return LTSH_writeTable(lfFont, record, stream);
        case TAG_VHEA:    return VHEA_writeTable(lfFont, record, stream);
        case TAG_VMTX:    return VMTX_writeTable(lfFont, record, stream);
        case TAG_OS2:     return OS2_writeTable(lfFont,  record, stream);
        case TAG_NAME:    return NAME_writeTable(lfFont, record, stream);
        case TAG_CFF:     return CFF__writeTable(lfFont, record, stream);
        case TAG_SBIX:    return SBIX_writeTable(lfFont, record, stream);
        case TAG_EBDT:    return EBDT_writeTable(lfFont, record, stream);
        case TAG_EBLC:    return EBLC_writeTable(lfFont, record, stream);
        case TAG_CBDT:    return CBDT_writeTable(lfFont, record, stream);
        case TAG_CBLC:    return CBLC_writeTable(lfFont, record, stream);
        case TAG_COLR:    return COLR_writeTable(lfFont, record, stream);
        case TAG_CPAL:    return CPAL_writeTable(lfFont, record, stream);
        case TAG_FVAR:    return FVAR_writeTable(lfFont, record, stream);
        case TAG_GVAR:    return GVAR_writeTable(lfFont, record, stream);
        case TAG_FMTX:    return FMTX_writeTable(lfFont, record, stream);
        default:          break;
    }

    return UNKNOWN_writeTable(lfFont, record, stream);
}

static LF_ERROR SFNT_freeTable(LF_FONT* lfFont, const sfnt_table_record* record)
{
    LF_ERROR error = LF_EMPTY_TABLE;

    if (record)
    {
        switch(record->tag)
        {
            case TAG_GSUB:    error = GSUB_freeTable(lfFont);    break;
            case TAG_GPOS:    error = GPOS_freeTable(lfFont);    break;
            case TAG_CMAP:    error = CMAP_freeTable(lfFont);    break;
            case TAG_GLYF:    error = GLYF_freeTable(lfFont);    break;
            case TAG_HEAD:    error = HEAD_freeTable(lfFont);    break;
            case TAG_HHEA:    error = HHEA_freeTable(lfFont);    break;
            case TAG_HMTX:    error = HMTX_freeTable(lfFont);    break;
            case TAG_LOCA:    error = LOCA_freeTable(lfFont);    break;
            case TAG_MAXP:    error = MAXP_freeTable(lfFont);    break;
            case TAG_POST:    error = POST_freeTable(lfFont);    break;
            case TAG_GDEF:    error = GDEF_freeTable(lfFont);    break;
            case TAG_KERN:    error = KERN_freeTable(lfFont);    break;
            case TAG_LTSH:    error = LTSH_freeTable(lfFont);    break;
            case TAG_HDMX:    error = HDMX_freeTable(lfFont);    break;
            case TAG_VHEA:    error = VHEA_freeTable(lfFont);    break;
            case TAG_VMTX:    error = VMTX_freeTable(lfFont);    break;
            case TAG_CFF:     error = CFF__freeTable(lfFont);    break;
            case TAG_OS2:     error = OS2_freeTable(lfFont);     break;
            case TAG_NAME:    error = NAME_freeTable(lfFont);    break;
            case TAG_SBIX:    error = SBIX_freeTable(lfFont);    break;
            case TAG_EBDT:    error = EBDT_freeTable(lfFont);    break;
            case TAG_EBLC:    error = EBLC_freeTable(lfFont);    break;
            case TAG_CBDT:    error = CBDT_freeTable(lfFont);    break;
            case TAG_CBLC:    error = CBLC_freeTable(lfFont);    break;
            case TAG_COLR:    error = COLR_freeTable(lfFont);    break;
            case TAG_CPAL:    error = CPAL_freeTable(lfFont);    break;
            case TAG_FVAR:    error = FVAR_freeTable(lfFont);    break;
            case TAG_GVAR:    error = GVAR_freeTable(lfFont);    break;
            case TAG_FMTX:    error = FMTX_freeTable(lfFont);    break;
            default:          error = UNKNOWN_freeTable(lfFont, record);     break;
        }

        map_erase(&lfFont->table_map, (void*)(intptr_t)record->tag);
    }
    return error;
}

static LF_ERROR SFNT_validateOffsetTable(const LF_FONT* lfFont)
{
    size_t i, endOfDirectory;
    sfnt_offset_table* offsetTable;

    if(lfFont->offset_table.sfnt == NULL)
        return LF_OUT_OF_MEMORY;

    offsetTable = (sfnt_offset_table*)lfFont->offset_table.sfnt;

    endOfDirectory = 12 + offsetTable->record_list.count * 16;

    for(i = 0; i < offsetTable->record_list.count; ++i)
    {
        sfnt_table_record* record = offset_getRecord(lfFont, i);

        // check for table starting before the end of the directory
        if(record->offset < endOfDirectory)
            return LF_BAD_FORMAT;

        // check for tables which extend past the end of the font
        if(record->offset + record->length > lfFont->fontSize)
            return LF_BAD_FORMAT;

        // check for overlap
        if(i < offsetTable->record_list.count-1)
        {
            sfnt_table_record* nextrecord = offset_getRecord(lfFont, i+1);

            if((nextrecord->offset > record->offset) && (record->offset + record->length > nextrecord->offset))
                return LF_BAD_FORMAT;
        }
    }

    return LF_ERROR_OK;
}

LF_ERROR SFNT_readOffsetTable(LF_FONT* lfFont, LF_STREAM* stream, int keepFlags)
{
    lfFont->offset_table.sfnt = offset_createTable();
    if(lfFont->offset_table.sfnt == NULL)
        return LF_OUT_OF_MEMORY;

    if(FALSE == offset_readFontHeader(lfFont, stream))
    {
        free(lfFont->offset_table.sfnt);
        lfFont->offset_table.sfnt = NULL;
        return LF_BAD_FORMAT;
    }

    if (FALSE == offset_readTable(lfFont, stream, keepFlags))
    {
        free(lfFont->offset_table.sfnt);
        lfFont->offset_table.sfnt = NULL;
        return LF_OUT_OF_MEMORY;
    }

    return SFNT_validateOffsetTable(lfFont);
}

static void SFNT_setFontType(LF_FONT* lfFont, LF_FONT_TYPE newType)
{
    ASSERT((newType == eLF_SFNT_FONT) || (newType == eLF_CFF_FONT));

    lfFont->fontType = newType;
}

static void SFNT_checkOTTables(LF_FONT*lfFont)
{
    // Check if the OT tables are valid and remove them if not.
    if (map_key_exists(&lfFont->table_map, (void*)TAG_GDEF))
    {
        if (FALSE == GDEF_isValid(lfFont))
        {
            SFNT_removeTable(lfFont, TAG_GDEF);
            map_erase(&lfFont->table_map, (void*)TAG_GDEF);
        }
    }
    if (map_key_exists(&lfFont->table_map, (void*)TAG_GPOS))
    {
        if (FALSE == GPOS_isValid(lfFont))
        {
            SFNT_removeTable(lfFont, TAG_GPOS);
            map_erase(&lfFont->table_map, (void*)TAG_GPOS);
        }
    }
    if (map_key_exists(&lfFont->table_map, (void*)TAG_GSUB))
    {
        if (FALSE == GSUB_isValid(lfFont))
        {
            SFNT_removeTable(lfFont, TAG_GSUB);
            map_erase(&lfFont->table_map, (void*)TAG_GSUB);
        }
    }
}

static void SFNT_checkKernTable(LF_FONT*lfFont)
{
    // Check if the kern table is valid and remove it if not.
    if (map_key_exists(&lfFont->table_map, (void*)TAG_KERN))
    {
        kern_table_header* header = (kern_table_header*)map_at(&lfFont->table_map, (void*)TAG_KERN);
        if (header->length == 0 || header->nTables == 0)
        {
            SFNT_removeTable(lfFont, TAG_KERN);
            map_erase(&lfFont->table_map, (void*)TAG_KERN);
        }
    }

}

LF_ERROR SFNT_unpackTables(LF_FONT* lfFont)
{
    USHORT i, numTables;
    sfnt_table_record* record;
    LF_ERROR error;
    LF_STREAM stream;

    STREAM_initMemStream(&stream, lfFont->fontData, lfFont->fontSize);

    map_init(&lfFont->table_map, integer_compare);

    // read maxp first since its values are used to parse other tables
    record = offset_findRecord(lfFont, TAG_MAXP);
    if (record == NULL)
        return LF_TABLE_MISSING;
    error = MAXP_readTable(lfFont, record, &stream);
    if(error != LF_ERROR_OK)
        return error;

    // head table is needed to read through the loca table
    record = offset_findRecord(lfFont, TAG_HEAD);
    if (record == NULL)
        return LF_TABLE_MISSING;
    error = HEAD_readTable(lfFont, record, &stream);
    if(error != LF_ERROR_OK)
        return error;

    // non standard glyph formats (e.g. ccc, ddd) are not supported
    if (0 != HEAD_getGlyphDataFormat(lfFont))
        return LF_UNSUPPORTED;

    // hhea table is needed to read through the hmtx
    record = offset_findRecord(lfFont, TAG_HHEA);
    if (record == NULL)
        return LF_TABLE_MISSING;
    error = HHEA_readTable(lfFont, record, &stream);
    if (error != LF_ERROR_OK)
        return error;

    //TODO see if this is needed
    // hmtx table is needed to read through the glyf table for glyf -> Glyph
    record = offset_findRecord(lfFont, TAG_HMTX);
    if (record == NULL)
        return LF_TABLE_MISSING;
    error = HMTX_readTable(lfFont, record, &stream);
    if (error != LF_ERROR_OK)
        return error;

    //TODO see if this is needed
    // post table is needed to create charset in cff
    record = offset_findRecord(lfFont, TAG_POST);
    if (record == NULL)
        return LF_TABLE_MISSING;
    error = POST_readTable(lfFont, record, &stream);
    if (error != LF_ERROR_OK)
        return error;

    record = offset_findRecord(lfFont, TAG_GLYF);
    if (record != NULL)
    {
        // ttf font -- loca is needed prior to glyf table
        record = offset_findRecord(lfFont, TAG_LOCA);
        if (record == NULL)
            return LF_TABLE_MISSING;
        error = LOCA_readTable(lfFont, record, &stream);
        if (error != LF_ERROR_OK)
            return error;
    }

    record = offset_findRecord(lfFont, TAG_CBDT);
    if (record != NULL)
    {
        // cblc is needed prior to cbdt table
        record = offset_findRecord(lfFont, TAG_CBLC);
        if (record == NULL)
            return LF_TABLE_MISSING;
        error = CBLC_readTable(lfFont, record, &stream);
        if (error != LF_ERROR_OK)
            return error;
    }

    record = offset_findRecord(lfFont, TAG_EBDT);
    if (record != NULL)
    {
        // eblc is needed prior to ebdt table
        record = offset_findRecord(lfFont, TAG_EBLC);
        if (record == NULL)
            return LF_TABLE_MISSING;
        error = EBLC_readTable(lfFont, record, &stream);
        if (error != LF_ERROR_OK)
            return error;
    }

    // read rest of tables
    numTables = offset_getNumTables(lfFont);
    for(i = 0; i < numTables; ++i)
    {
        record = offset_getRecord(lfFont, i);
        error = SFNT_loadTable(lfFont, record, &stream);
        if(error != LF_ERROR_OK)
            return error;
    }

    // check OT tables
    SFNT_checkOTTables(lfFont);

    // check kern table
    SFNT_checkKernTable(lfFont);

    return error;
}

static boolean SFNT_checkPostVersion(const LF_FONT* lfFont, const LF_WRITE_PARAMS *params)
{
    if (params->postTableVersion == 0x00030000)
    {
        // Get pointer to post table
        sfnt_table_record* postRecord = offset_findRecord(lfFont, TAG_POST);
        BYTE* post = lfFont->fontData + postRecord->offset;

        // the first thing is the version
        ULONG origVersion = *((ULONG*)(void*)(post));
        origVersion = SWAP_ULONG(origVersion);
        if (origVersion == 0x00020000)
            return TRUE;
    }

    return FALSE;
}

static void SFNT_writeSlimmedPostTable(const LF_FONT* lfFont, LF_STREAM* stream, sfnt_table_record* sfntRecord, ULONG* checkSum)
{
    // Get pointer to post table
    sfnt_table_record* postRecord = offset_findRecord(lfFont, TAG_POST);
    BYTE* post = lfFont->fontData + postRecord->offset;

    // The first 32 bytes are the version 3 content
    BYTE postV3Buf[32];

    memcpy(postV3Buf, post, 32);

    // Change the version
    postV3Buf[1] = 3;

    sfntRecord->checkSum = UTILS_CalcTableChecksum(postV3Buf, 32);
    sfntRecord->length = 32;
    sfntRecord->offset = (ULONG)STREAM_streamPos(stream);

    // add table contribution to the checksum (both table itself and table record)
    *checkSum += sfntRecord->checkSum;  // add table checksum
    *checkSum += UTILS_CalcTableRecordChecksum((BYTE *)sfntRecord, sizeof(sfnt_table_record));  // add table record checksum

    STREAM_writeChunk(stream, postV3Buf, 32);
}

static LF_ERROR SFNT_writeObfuscatedNameTable(const LF_FONT* lfFont, LF_STREAM* stream, sfnt_table_record* sfntRecord, ULONG* checkSum)
{
    // Get pointer to name table
    sfnt_table_record* nameRecord = offset_findRecord(lfFont, TAG_NAME);
    BYTE* name = lfFont->fontData + nameRecord->offset;

    BYTE* obfuscatedBuf = NULL;

    // NOTE: Obfuscating does not change the table length
    LF_ERROR error = NAME_obfuscateRaw(name, nameRecord->length, &obfuscatedBuf);

    if (error == LF_ERROR_OK)
    {
        sfntRecord->checkSum = UTILS_CalcTableChecksum(obfuscatedBuf, nameRecord->length);
        sfntRecord->length = nameRecord->length;
        sfntRecord->offset = (ULONG)STREAM_streamPos(stream);

        // add table contribution to the checksum (both table itself and table record)
        *checkSum += sfntRecord->checkSum;  // add table checksum
        *checkSum += UTILS_CalcTableRecordChecksum((BYTE *)sfntRecord, sizeof(sfnt_table_record));  // add table record checksum

        STREAM_writeChunk(stream, obfuscatedBuf, nameRecord->length);
    }

    free(obfuscatedBuf);

    return error;
}

static LF_ERROR SFNT_writeToStreamPacked(const LF_FONT* lfFont, const LF_WRITE_PARAMS *params, LF_STREAM* stream, sfnt_offset_table** offsetTable)
{
    sfnt_offset_table* origTable;
    sfnt_offset_table* newTable;
    size_t i, fontLength, headTableOffset = 0;
    LF_FONT temp;
    ULONG checkSum = 0;

    if(lfFont == NULL)
        return LF_INVALID_PARAM;
    if(lfFont->fontData==NULL)
        return LF_BAD_FORMAT;

    boolean needToSlimPostTable = SFNT_checkPostVersion(lfFont, params);

    memset(&temp, 0, sizeof(LF_FONT));
    temp.fontType = lfFont->fontType;

    // create a new offset table, possibly with fewer records than the original, based on the flags param

     origTable = (sfnt_offset_table*)lfFont->offset_table.sfnt;
     ASSERT(origTable);

    newTable = (sfnt_offset_table*)calloc(1, sizeof(sfnt_offset_table));
    if(newTable == NULL)
        return LF_OUT_OF_MEMORY;

    vector_init(&newTable->record_list, origTable->sfntHeader.numTables, 4);

    for(i = 0; i < origTable->record_list.count; ++i) // note that tables may have already been removed so the count in the list may be less than that indicated in the (not updated) header
    {
        sfnt_table_record* newRecord;
        sfnt_table_record* origRecord = offset_getRecord(lfFont, i);

        newRecord = (sfnt_table_record*)calloc(1, sizeof(sfnt_table_record));
        if(newRecord == NULL)
        {
            size_t j;
            for(j = 0; j < newTable->record_list.count; j++)
            {
                sfnt_table_record* record = (sfnt_table_record*)vector_at(&newTable->record_list, j);
                free(record);
            }
            free(newTable);
            return LF_OUT_OF_MEMORY;
        }

        newRecord->tag = origRecord->tag;
        // rest of fields remain at 0 for now

        // add to list
        vector_push_back(&newTable->record_list, newRecord);
    }

    newTable->sfntHeader.sfnt_version = origTable->sfntHeader.sfnt_version;
    newTable->sfntHeader.numTables = (USHORT)vector_size(&newTable->record_list);

    // write the initial version of sfnt header to the output
    temp.offset_table.sfnt = newTable;

    LF_ERROR error = offset_writeTable(&temp, stream);
    if (error != LF_ERROR_OK)
    {
        offset_freeTable(&temp);
        return error;
    }

    // now write tables to the output and update the new offset table records as we go
    // the offset table records in the lfFont contain the offsets into the lfFont->FontData to the raw data for each table
    for(i = 0; i < newTable->record_list.count; ++i)
    {
        ULONG paddedTableLen;
        ULONG tableRecordCheckSum;
        sfnt_table_record* origRecord;
        sfnt_table_record* sfntRecord = (sfnt_table_record*)vector_at(&newTable->record_list, i);

        if ((lfFont->fontType == eLF_SFNT_FONT) && (sfntRecord->tag == TAG_CFF))
            continue;
        if (lfFont->fontType == eLF_CFF_FONT)
        {
            if (TableExcludedFromCFFFont(sfntRecord->tag))
                continue;
        }

        // find the corresponding entry in the original sfnt table
        origRecord = offset_findRecord(lfFont, sfntRecord->tag);
        if(origRecord == NULL)
        {
            temp.offset_table.sfnt = newTable;
            offset_freeTable(&temp);
            return LF_BAD_FORMAT;
        }

        if ((sfntRecord->tag == TAG_POST) && (TRUE == needToSlimPostTable))
        {
            SFNT_writeSlimmedPostTable(lfFont, stream, sfntRecord, &checkSum);

            continue;
        }
        if ((sfntRecord->tag == TAG_NAME) && (TRUE == lfFont->obfuscateOnWrite))
        {
            error = SFNT_writeObfuscatedNameTable(lfFont, stream, sfntRecord, &checkSum);
            if (error != LF_ERROR_OK)
            {
                temp.offset_table.sfnt = newTable;
                offset_freeTable(&temp);
                return error;
            }
            continue;
        }

        sfntRecord->checkSum = origRecord->checkSum;
        sfntRecord->length = origRecord->length;
        sfntRecord->offset = (ULONG)STREAM_streamPos(stream);

        paddedTableLen = (origRecord->length + 3) & ~3;

        // For the head table, we must zero the checkSumAdjustment value and compute the table checksum
        // The checkSumAdjustment will be updated once we have the checksum for the full font 
        if (sfntRecord->tag == TAG_HEAD)
        {
            ULONG *checkSumAdjustment = (ULONG *)(void*)(lfFont->fontData + origRecord->offset + 8);
            *checkSumAdjustment = 0;  // zero out head table checkSumAdjustment in the head table
            // update the head table checksum
            sfntRecord->checkSum = UTILS_CalcTableChecksum(lfFont->fontData+origRecord->offset, sfntRecord->length);
            // save head table offset for future updating with checkSumAdjustment
            headTableOffset = STREAM_streamPos(stream);
        }

        // add table contribution to the checksum (both table itself and table record)
        checkSum += sfntRecord->checkSum;  // add table checksum
        tableRecordCheckSum = UTILS_CalcTableRecordChecksum((BYTE *)sfntRecord, sizeof(sfnt_table_record));
        checkSum += tableRecordCheckSum;  // add table record checksum

        STREAM_writeChunk(stream, lfFont->fontData+origRecord->offset, paddedTableLen); // Note this is assuming the original data is padded properly and is copying the pad bytes
    }

    fontLength = STREAM_streamPos(stream);

    // calculate new font header checksum
    checkSum += UTILS_CalcHeaderChecksum((BYTE *)&(newTable->sfntHeader)); // add font header checksum
    checkSum = 0xB1B0AFBA - checkSum; // now equals the checkSumAdjustment value

    // update the checkSumAdjustment in the head table
    STREAM_streamSeek(stream, headTableOffset+8);
    STREAM_writeULong(stream, checkSum);

    // write updated header
    STREAM_streamSeek(stream, 0);
    temp.offset_table.sfnt = newTable;

    error = offset_writeTable(&temp, stream);

    STREAM_streamSeek(stream, fontLength);

    if ((error == LF_ERROR_OK) && (offsetTable != NULL))
    {
        *offsetTable = offset_copyTable(newTable);
        if (*offsetTable == NULL)
            error = LF_OUT_OF_MEMORY;
    }

    offset_freeTable(&temp);

    return error;
}

//#define UPM_SCALING_ENABLED

static LF_ERROR SFNT_updateAndScaleTables(LF_FONT* lfFont, LF_FONT_TYPE type, const LF_WRITE_PARAMS *params, boolean calcMaxp)
{
#ifdef UPM_SCALING_ENABLED
    // See if we need to scale values in various tables
    //USHORT origUPM = HEAD_getUnitsPerEM(lfFont);
    USHORT targetUpm = DEFAUT_TTF_UPM;

    //if (type == eLF_CFF_FONT)
    //    targetUpm = (params->unitsPerEm == 0) ? DEFAUT_CFF_UPM : params->unitsPerEm;
    //else
    //    targetUpm = (params->unitsPerEm == 0) ? DEFAUT_TTF_UPM : params->unitsPerEm;

    //boolean needToScale = (targetUpm != origUPM) ? TRUE : FALSE;

    boolean needToScale = FALSE;
    // Update head table
    if (needToScale)
        HEAD_setUnitsPerEM(lfFont, targetUpm);
#endif

    LF_ERROR error;

    (void)params;

    // The glyphs are already scaled so we can compute the the bounding box from them.
    // In the case where there is no scaling, the bounding boxes of the glyphs probably don't change,
    // (but they could for large tolerances).
    SHORT xMin, yMin, xMax, yMax;

    if (type == eLF_CFF_FONT)
        error = CFF__getBoundingBox(lfFont, &xMin, &yMin, &xMax, &yMax);
    else
        error = GLYF_getBoundingBox(lfFont, &xMin, &yMin, &xMax, &yMax);

    if (error != LF_ERROR_OK)
        return error;

    error = HEAD_setBoundingBox(lfFont, xMin, yMin, xMax, yMax);
    if (error != LF_ERROR_OK)
        return error;

    // Update MAXP table. This routine uses data in the glyf/cff table to do it.
    error = MAXP_updateTable(lfFont, (type == eLF_CFF_FONT) ? TAG_CFF : TAG_GLYF, TRUE, calcMaxp, FALSE);
    if (error != LF_ERROR_OK)
        return error;

#ifdef UPM_SCALING_ENABLED
    if (needToScale)
    {
        // The following tables need to be scaled

        // OS/2
        //HHEA
        //HMTX
        //VMTX
        //GPOS
        //KERN

    }
#endif

    // Update hmtx side bearings and get min values
    FWORD minlsb, minrsb, maxadvance;
    error = HMTX_updateSidebearings(lfFont, type, &minlsb, &minrsb, &maxadvance);
    if (error != LF_ERROR_OK)
        return error;

    // Update hhea table
    HHEA_setXMaxExtent(lfFont, xMax);
    HHEA_setAdvanceWidthMax(lfFont, maxadvance);
    HHEA_setLeftSidebearingMin(lfFont, minlsb);
    HHEA_setRightSidebearingMin(lfFont, minrsb);
    HHEA_setNumHMetrics(lfFont, HMTX_getNumHMetrics(lfFont));

    // Update OS/2 table
    OS2_upgradeTable(lfFont);
    OS2_setAvgCharWidth(lfFont, HMTX_getAdvanceWidthAvg(lfFont));
    USHORT minUni, maxUni;
    error = CMAP_getMinMaxRemappedUnicodes(lfFont, &minUni, &maxUni);
    if (error != LF_ERROR_OK)
        return error;

    OS2_setCharIndex(lfFont, minUni, maxUni);

    // Update vhea table
    if (TRUE == map_key_exists(&lfFont->table_map, (void*)TAG_VMTX))
    {
        FWORD mintsb, minbsb, maxvadvance, yMaxExtent;
        error = VMTX_updateSidebearings(lfFont, lfFont->fontType, &mintsb, &minbsb, &maxvadvance, &yMaxExtent);
        if (error != LF_ERROR_OK)
            return error;

        VHEA_setAdvanceHeightMax(lfFont, maxvadvance);
        VHEA_setYMaxExtent(lfFont, yMaxExtent);
        VHEA_setTopSidebearingMin(lfFont, mintsb);
        VHEA_setBottomSidebearingMin(lfFont, minbsb);
        VHEA_setVertTypoLineGap(lfFont, 0);
        VHEA_setNumVMetrics(lfFont, VMTX_getNumVMetrics(lfFont));
    }

    return error;
}

// inserts a glyf and loca table into the offset table and the table map
LF_ERROR SFNT_insertGLYFAndLOCA(LF_FONT* lfFont, boolean populateMap)
{
    // See if there is a cff table
    if (FALSE == map_key_exists(&lfFont->table_map, (void*)TAG_CFF))
        return LF_TABLE_MISSING;

    USHORT numGlyphs = MAXP_getNumGlyphs(lfFont);

    LF_ERROR error = LOCA_createTable(lfFont, numGlyphs);
    if (error != LF_ERROR_OK)
        return error;

    error = offset_insertNewRecord(lfFont, TAG_LOCA);
    if (error != LF_ERROR_OK)
    {
        LOCA_freeTable(lfFont);
        map_erase(&lfFont->table_map, (void*)TAG_LOCA);
        return error;
    }

    numGlyphs = MAXP_getNumGlyphs(lfFont);

    error = GLYF_createTable(lfFont, numGlyphs, populateMap);
    if (error != LF_ERROR_OK)
    {
        LOCA_freeTable(lfFont);
        map_erase(&lfFont->table_map, (void*)TAG_LOCA);
        offset_deleteRecord(lfFont, TAG_LOCA);
        return error;
    }

    // add glyf to the offset table
    error = offset_insertNewRecord(lfFont, TAG_GLYF);
    if (error != LF_ERROR_OK)
    {
        LOCA_freeTable(lfFont);
        map_erase(&lfFont->table_map, (void*)TAG_LOCA);
        offset_deleteRecord(lfFont, TAG_LOCA);
        GLYF_freeTable(lfFont);
        return error;
    }

    // since we don't know how many glyphs (or how big they will be) will be in the font, set format to long
    HEAD_setLocFormat(lfFont, 1);

    return LF_ERROR_OK;
}

// inserts a CFF table into the offset table and the table map
LF_ERROR SFNT_insertCFF(LF_FONT* lfFont)
{
    // create empty CFF table and insert into table map
    LF_ERROR error = CFF__createTable(lfFont);
    if (error != LF_ERROR_OK)
        return error;

    // add it to offset table
    error = offset_insertNewRecord(lfFont, TAG_CFF);
    if (error != LF_ERROR_OK)
    {
        CFF__freeTable(lfFont);
        map_erase(&lfFont->table_map, (void*)TAG_CFF);
        return error;
    }

    return LF_ERROR_OK;
}

// fills in the glyf table by converting the (possibly subsetted) charstrings in the cff table
// to (compressed) glyfs in the glyf table
static LF_ERROR SFNT_populateGLYFFromCFF(LF_FONT* lfFont, const LF_WRITE_PARAMS *params)
{
    LF_ERROR error;

    if (params->postTableVersion == 0x00020000)
    {
        error = conversion_populatePOSTTable(lfFont);
        if (error != LF_ERROR_OK)
            return error;
    }

    return conversion_populateGLYFTable(lfFont, params->conversionTolerance,
                                        DEFAUT_TTF_UPM/* this is currently ignored in convertCubic()*/);
                                        //(params->unitsPerEm == 0) ? DEFAUT_TTF_UPM : params->unitsPerEm);
}

static LF_ERROR SFNT_populateCFFFromGLYF(LF_FONT* lfFont, const LF_WRITE_PARAMS *params)
{
    return conversion_populateCFFTable(lfFont, params->conversionTolerance, DEFAUT_CFF_UPM/* this is currently ignored in convertQuadratic()*/);
}

// updates the size of the appropriate table(s) in the offset table
static LF_ERROR SFNT_updateOffsetRecords(LF_FONT* lfFont, boolean glyfAndLoca)
{
    if (TRUE == glyfAndLoca)
    {
        // update the table record to reflect the size of the glyf table
        sfnt_table_record* glyfRecord = offset_findRecord(lfFont, TAG_GLYF);
        if (glyfRecord == NULL)
            return LF_BAD_FORMAT;

        size_t glyfTableSize;
        LF_ERROR error = GLYF_getTableSize(lfFont, &glyfTableSize);
        if (error != LF_ERROR_OK)
            return error;

        glyfRecord->length = (ULONG)glyfTableSize;

        // also update the loca table record to reflect the size of the loca table
        sfnt_table_record* locaRecord = offset_findRecord(lfFont, TAG_LOCA);
        if (locaRecord == NULL)
            return LF_BAD_FORMAT;

        size_t locaTableSize;
        error = LOCA_getTableSize(lfFont, &locaTableSize);
        if (error != LF_ERROR_OK)
            return error;

        locaRecord->length = (ULONG)locaTableSize;
    }
    else
    {
        // update the offset table with the size of the created cff table
        sfnt_table_record* cffRecord = offset_findRecord(lfFont, TAG_CFF);
        if (cffRecord == NULL)
            return LF_BAD_FORMAT;

        size_t cffTableSize;
        LF_ERROR error = CFF__getTableSize(lfFont, &cffTableSize);
        if (error != LF_ERROR_OK)
            return error;

        cffRecord->length = (ULONG)cffTableSize;
    }

    return LF_ERROR_OK;
}

LF_ERROR SFNT_processForCFFfont(LF_FONT* lfFont, const LF_WRITE_PARAMS *params, boolean origHasCffTable)
{
    // Set output font type
    SFNT_setFontType(lfFont, eLF_CFF_FONT);

    // Set signature to match
    LF_ERROR error = offset_setSignature(lfFont, SIG_CFF);
    if (error != LF_ERROR_OK)
        return error;

    // If tables are not unpacked, we are doing a CFF->CFF conversion and there is nothing to do here.
    if (TRUE == map_empty(&lfFont->table_map))
        return LF_ERROR_OK;
    else if ((origHasCffTable == TRUE) && (lfFont->isRefitted == FALSE) && (lfFont->isSubsetted == FALSE))
    {
        return LF_ERROR_OK;
    }

    // Set loca format to 1 for CFF output
    HEAD_setLocFormat(lfFont, 1);

    if (FALSE == map_key_exists(&lfFont->table_map, (void*)TAG_CFF))
    {
        // Converting or subsetting TTF to CFF. Need to create a CFF table.

        error = SFNT_insertCFF(lfFont);
        if (error != LF_ERROR_OK)
            return error;

        error = SFNT_populateCFFFromGLYF(lfFont, params);       // Conversion happens here.
        if (error != LF_ERROR_OK)
            return error;

        error = SFNT_updateOffsetRecords(lfFont, FALSE);
        if (error != LF_ERROR_OK)
            return error;

        error = GPOS_removeAnchorPoints(lfFont);
        if (error != LF_ERROR_OK)
            return error;

        error = SFNT_updateAndScaleTables(lfFont, eLF_CFF_FONT, params, FALSE);
        if (error != LF_ERROR_OK)
            return error;
    }
    else
    {
        // Check for case where the font has been written as other than CFF.
        // (i.e. the built sfnt is not cff)
        if (lfFont->builtSFNT != NULL)
        {
            sfnt_offset_table* sot = (sfnt_offset_table*)lfFont->builtSFNTOffsetTable;

            // Update table data for cff output
            if (sot->sfntHeader.sfnt_version == SIG_VERSION1)
            {
                error = SFNT_updateAndScaleTables(lfFont, eLF_CFF_FONT, params, FALSE);
                if (error != LF_ERROR_OK)
                    return error;
            }
        }
    }

    return LF_ERROR_OK;
}

LF_ERROR SFNT_processForGLYFfont(LF_FONT* lfFont, const LF_WRITE_PARAMS *params, boolean origHasGlyfTable)
{
    // Set output font type
    SFNT_setFontType(lfFont, eLF_SFNT_FONT);

    // Set signature to match
    LF_ERROR error = offset_setSignature(lfFont, SIG_VERSION1);
    if (error != LF_ERROR_OK)
        return error;

    // If tables are not unpacked, we are doing a TTF->TTF conversion and there is nothing to do here.
    if (TRUE == map_empty(&lfFont->table_map))
    {
        return LF_ERROR_OK;
    }
    else if ((origHasGlyfTable == TRUE) && (lfFont->isRefitted == FALSE) && (lfFont->isSubsetted == FALSE))
    {
        return LF_ERROR_OK;
    }

    if (FALSE == map_key_exists(&lfFont->table_map, (void*)TAG_GLYF))
    {
        if (TRUE == map_key_exists(&lfFont->table_map, (void*)TAG_CFF))
        {
            // Converting or subsetting CFF to TTF.

            error = SFNT_insertGLYFAndLOCA(lfFont, FALSE);
            if (error != LF_ERROR_OK)
                return error;

            error = SFNT_populateGLYFFromCFF(lfFont, params);  // Conversion happens here.
            if (error != LF_ERROR_OK)
                return error;

            error = SFNT_updateOffsetRecords(lfFont, TRUE);
            if (error != LF_ERROR_OK)
                return error;

            error = GPOS_removeAnchorPoints(lfFont);
            if (error != LF_ERROR_OK)
                return error;

            error = SFNT_updateAndScaleTables(lfFont, eLF_SFNT_FONT, params, FALSE);
            if (error != LF_ERROR_OK)
                return error;
        }
        else
        {
            // Subsetting CBDT
            if (TRUE == map_key_exists(&lfFont->table_map, (void*)TAG_CBDT))
            {
                ;
            }
        }
    }
    else
    {
        // Check for case where the font has been written as a CFF, in which case the
        // content of the original glyf table (or the glyf manufactured from the cff table)
        // will be written to the font, so other tables need to be updated to match that.
        if (lfFont->builtSFNT != NULL)
        {
            sfnt_offset_table* sot = (sfnt_offset_table*)lfFont->builtSFNTOffsetTable;

            if (sot->sfntHeader.sfnt_version == SIG_CFF)
            {
                error = SFNT_updateAndScaleTables(lfFont, eLF_SFNT_FONT, params, TRUE);
                if (error != LF_ERROR_OK)
                    return error;
            }
        }
    }

    return error;
}

LF_ERROR SFNT_checkGlyphTable(LF_FONT* lfFont, LF_FONT_TYPE outputType, const LF_WRITE_PARAMS *params)
{
    LF_ERROR error = LF_ERROR_OK;

    boolean needsUnpacking = FALSE;
    boolean outputHasCffTable = FALSE;  // FALSE = output has glyf/loca
    boolean origHasCffTable = FALSE;
    boolean origHasGlyfTable = FALSE;

    boolean isUnpacked = (map_empty(&lfFont->table_map)) ? FALSE : TRUE;

    if ((lfFont->origType == eLF_CFF_FONT) ||
        (((lfFont->origType == eLF_WOFF_FONT) ||
          (lfFont->origType == eLF_WOFF2_FONT) ||
          (lfFont->origType == eLF_EOT_FONT)) && (lfFont->origFlavor == SIG_CFF)))
    {
        origHasCffTable = TRUE;
    }

    // woff, woff2, and eot may have either glyf/loca or cff
    if ((lfFont->origType == eLF_SFNT_FONT)  ||
        (((lfFont->origType == eLF_WOFF_FONT) ||
          (lfFont->origType == eLF_WOFF2_FONT) ||
          (lfFont->origType == eLF_EOT_FONT)) && (lfFont->origFlavor != SIG_CFF)))
    {
        origHasGlyfTable = TRUE;
    }

    // The output will have a cff table if:
    //  -cff output is specified
    //  -woff or woff2 or eot output is specified and output with cff is specified
    //  -woff or woff2 or eot output is specified and the original font has a cff table
    if ((outputType == eLF_CFF_FONT) ||
        (((outputType == eLF_WOFF_FONT) ||
          (outputType == eLF_WOFF2_FONT) ||
          (outputType == eLF_EOT_FONT)) && (params->sfnt_ttf == FALSE)
                                        && ((params->sfnt_cff == TRUE) || (origHasCffTable == TRUE))))
    {
        outputHasCffTable = TRUE;
    }

    if ((isUnpacked == FALSE) &&
        (((outputHasCffTable == TRUE) && (origHasCffTable == FALSE)) ||
         ((outputHasCffTable == FALSE) && (origHasGlyfTable == FALSE))))
    {
        needsUnpacking = TRUE;
    }


    if (needsUnpacking == TRUE)
    {
        error = SFNT_unpackTables(lfFont);
        if (error != LF_ERROR_OK)
            return error;
    }

    // SFNT_processForCFFfont/SFNT_processForGLYFfont will set lfFont->type to either eLF_SFNT_FONT or eLF_CFF_FONT
    if (outputHasCffTable == TRUE)
    {
        error = SFNT_processForCFFfont(lfFont, params, origHasCffTable);
    }
    else
    {
        if (origHasCffTable == TRUE)
        {
            USHORT cffGlyphs;
            error = CFF__getCount(lfFont, &cffGlyphs);
            if (error != LF_ERROR_OK)
                return error;
            if (cffGlyphs != MAXP_getNumGlyphs(lfFont))
                return LF_MAXP_CFF_MISMATCH;
        }

        error = SFNT_processForGLYFfont(lfFont, params, origHasGlyfTable);
    }

    return error;
}

static LF_ERROR SFNT_writeToStreamInternal(LF_FONT* lfFont, const LF_WRITE_PARAMS *params, LF_STREAM* stream, sfnt_offset_table** newTable)
{
    sfnt_table_record* record;
    size_t end;
    ULONG checkSum = 0;
    LF_ERROR error;

    HHEA_setNumHMetrics(lfFont, HMTX_getNumHMetrics(lfFont));
    if (NULL != map_at(&lfFont->table_map, (void *)(long)TAG_VMTX))
        VHEA_setNumVMetrics(lfFont, VMTX_getNumVMetrics(lfFont));

    if (lfFont->obfuscateOnWrite == TRUE)
    {
        error = NAME_obfuscate(lfFont);
        if (error != LF_ERROR_OK)
            return error;
    }

    error = offset_writeTable(lfFont, stream);
    if (error != LF_ERROR_OK)
        return error;

    sfnt_offset_table* table = (sfnt_offset_table*)lfFont->offset_table.sfnt;

    // make a copy of the original offset table since the code below
    // changes the offset table in the lfFont
    sfnt_offset_table* origOffsetTable = offset_copyTable(table);
    if (origOffsetTable == NULL)
        return LF_OUT_OF_MEMORY;

    for (size_t i = 0; i < table->record_list.count; ++i)
    {
        ULONG tableRecordCheckSum;

        record = offset_getRecord(lfFont, i);

        if ((lfFont->fontType == eLF_SFNT_FONT) && (record->tag == TAG_CFF))
            continue;
        // Hint tables are not written to fonts with a cff table
        // Some aat tables are not written to fonts with a cff table
        // Note: Some aat tables are still let through and will be invalid. See the note for
        //       LF_KEEP_ALL_TABLES in lf_core.h
        if (lfFont->fontType == eLF_CFF_FONT && TableExcludedFromCFFFont(record->tag))
            continue;

        // For the head table, we must zero the checkSumAdjustment value and compute the table checksum
        // The checkSumAdjustment will be updated once we have the checksum for the full font
        if (record->tag == TAG_HEAD)
        {
            head_table* headTable = (head_table*)map_at(&lfFont->table_map, (void*)TAG_HEAD);
            headTable->checkSumAdjustment = 0;  // zero out head table checkSumAdjustment in the head table
        }

        error = SFNT_writeTable(lfFont, params, record, stream);
        if (error != LF_ERROR_OK)
        {
            offset_freeTableEx(table);
            lfFont->offset_table.sfnt = origOffsetTable;
            return error;
        }

        // add table contribution to the checksum (both table itself and table record)
        checkSum += record->checkSum;  // add table checksum
        tableRecordCheckSum = UTILS_CalcTableRecordChecksum((BYTE *)record, sizeof(sfnt_table_record));
        checkSum += tableRecordCheckSum;  // add table record checksum
    }

    if (FALSE == STREAM_ptrIsValid(stream))
    {
        offset_freeTableEx(table);
        lfFont->offset_table.sfnt = origOffsetTable;
        return LF_STREAM_OVERRUN;
    }

    end = STREAM_streamPos(stream);

    // calculate new font header checksum
    {
        sfnt_offset_table* offsetTable = (sfnt_offset_table*)lfFont->offset_table.sfnt;
        checkSum += UTILS_CalcHeaderChecksum((BYTE *)&offsetTable->sfntHeader); // add font header checksum
        checkSum = 0xB1B0AFBA - checkSum; // now the checkSumAdjustment value
    }

    // update the checkSumAdjustment in the head table
    {
        head_table* headTable = (head_table*)map_at(&lfFont->table_map, (void*)TAG_HEAD);
        headTable->checkSumAdjustment = checkSum;
    }

    // rewrite the HEAD table
    record = offset_findRecord(lfFont, TAG_HEAD);
    STREAM_streamSeek(stream, record->offset);
    SFNT_writeTable(lfFont, params, record, stream);

    error = offset_writeRecords(lfFont, stream);

    if (error == LF_ERROR_OK)
    {
        *newTable = offset_copyTable(table);
        if (*newTable == NULL)
        {
            offset_freeTableEx(table);
            lfFont->offset_table.sfnt = origOffsetTable;
            return LF_OUT_OF_MEMORY;
        }
    }

    // put back original offset table
    offset_freeTableEx(table);
    lfFont->offset_table.sfnt = origOffsetTable;

    STREAM_streamSeek(stream, end);

    if (FALSE == STREAM_ptrIsValid(stream))
        return LF_STREAM_OVERRUN;

    return error;
}

LF_ERROR SFNT_clearSFNT(LF_FONT* lfFont)
{
    free(lfFont->builtSFNT);
    lfFont->builtSFNT = NULL;
    lfFont->builtSFNTSize = 0;
    offset_freeTableEx(lfFont->builtSFNTOffsetTable);
    lfFont->builtSFNTOffsetTable = NULL;

    return LF_ERROR_OK;
}

boolean SFNT_isUnpackedSlim(LF_FONT* lfFont)
{
    boolean unpackedSlim = FALSE;

    if ((lfFont->isSubsetted == FALSE) && (lfFont->isRefitted == FALSE))
    {
        // lfFont->fontType will be either eLF_SFNT_FONT or eLF_CFF_FONT at this point */
        if (lfFont->origType == lfFont->fontType)
        {
            unpackedSlim = TRUE;
        }
        else
        {
            boolean origMayHaveCff = ((lfFont->origType == eLF_EOT_FONT) ||
                                      (lfFont->origType == eLF_WOFF_FONT) ||
                                      (lfFont->origType == eLF_WOFF2_FONT)) ? TRUE : FALSE;

            if ((lfFont->fontType == eLF_SFNT_FONT) &&
                (origMayHaveCff == TRUE) &&
                (lfFont->origFlavor != SIG_CFF))
            {
                unpackedSlim = TRUE;
            }
            else if ((lfFont->fontType == eLF_CFF_FONT) &&
                     (origMayHaveCff == TRUE) &&
                     (lfFont->origFlavor == SIG_CFF))
            {
                unpackedSlim = TRUE;
            }
        }
    }

    return unpackedSlim;
}

LF_ERROR SFNT_constructSFNT(LF_FONT* lfFont, const LF_WRITE_PARAMS *params)
{
    if ((lfFont->builtSFNT != NULL) &&
        (lfFont->builtParams.conversionTolerance == params->conversionTolerance) &&       //lint !e777
        (lfFont->builtParams.postTableVersion == params->postTableVersion)) // account for unitPerEm in next rev.
    {
        sfnt_offset_table* sot = (sfnt_offset_table*)lfFont->builtSFNTOffsetTable;

        if (((lfFont->fontType == eLF_SFNT_FONT) && (sot->sfntHeader.sfnt_version == SIG_VERSION1)) ||
            ((lfFont->fontType == eLF_CFF_FONT) && (sot->sfntHeader.sfnt_version == 0x4F54544F)))
        {
            return LF_ERROR_OK;
        }
    }

    SFNT_clearSFNT(lfFont);

    size_t sfntLength;
    BYTE* sfntBuffer;
    LF_STREAM sfntStream;

    LF_ERROR error = SFNT_getSFNTSize(lfFont, params, &sfntLength);
    if (error != LF_ERROR_OK)
    {
        return error;
    }

    sfntBuffer = (BYTE*)malloc(sfntLength);
    if (sfntBuffer == NULL)
    {
        return LF_OUT_OF_MEMORY;
    }

    STREAM_initMemStream(&sfntStream, sfntBuffer, sfntLength);

    sfnt_offset_table* newOffsetTable = NULL;

    // write the sfnt into a temp stream
    if (TRUE == map_empty(&lfFont->table_map) || SFNT_isUnpackedSlim(lfFont))
    {
        error = SFNT_writeToStreamPacked(lfFont, params, &sfntStream, &newOffsetTable);
    }
    else
    {
        error = SFNT_writeToStreamInternal(lfFont, params, &sfntStream, &newOffsetTable);
    }

    if (error != LF_ERROR_OK)
    {
        free(sfntBuffer);
        return error;
    }

    lfFont->builtParams = *params;
    lfFont->builtSFNT = (TABLE_HANDLE)sfntBuffer;
    lfFont->builtSFNTSize = (ULONG)STREAM_streamPos(&sfntStream);
    lfFont->builtSFNTOffsetTable = (TABLE_HANDLE)newOffsetTable;

    return LF_ERROR_OK;
}

LF_ERROR SFNT_writeToStream(LF_FONT* lfFont, const LF_WRITE_PARAMS *params, LF_STREAM* stream)
{
    if ((lfFont == NULL) || (params == NULL) || (stream == NULL))
        return LF_INVALID_PARAM;

    if ((lfFont->builtSFNT == NULL) || (lfFont->builtSFNTOffsetTable == NULL))
        return LF_BAD_FORMAT;

    UNUSED(params);

    STREAM_writeChunk(stream, lfFont->builtSFNT, lfFont->builtSFNTSize);

    return (STREAM_ptrIsValid(stream) ? LF_ERROR_OK : LF_STREAM_OVERRUN);
}

boolean SFNT_tableInOffsetTable(LF_FONT* lfFont, ULONG tag)
{
    sfnt_table_record* record = offset_findRecord(lfFont, tag);

    return (record != NULL) ? TRUE : FALSE;
}

LF_ERROR SFNT_removeTable(LF_FONT* lfFont, ULONG tag)
{
    sfnt_table_record* record = offset_findRecord(lfFont, tag);
    if(record)
    {
        if(lfFont->table_map.count)
            SFNT_freeTable(lfFont, record);
        offset_deleteRecord(lfFont, tag);
    }

    return LF_ERROR_OK;
}

LF_ERROR SFNT_removeHints(LF_FONT* lfFont)
{
    if (FALSE == SFNT_tablesUnpacked(lfFont))
    {
        LF_ERROR error = SFNT_unpackTables(lfFont);
        if (error != LF_ERROR_OK)
            return error;
        lfFont->isSubsetted = TRUE; // subset is entire font, forces use of unpacked tables
    }

    GLYF_removeInstructions(lfFont);

    SFNT_removeTable(lfFont, TAG_FPGM);
    SFNT_removeTable(lfFont, TAG_CVT);
    SFNT_removeTable(lfFont, TAG_PREP);
    SFNT_removeTable(lfFont, TAG_VDMX); // these depend on the hints
    SFNT_removeTable(lfFont, TAG_HDMX);
    SFNT_removeTable(lfFont, TAG_CVAR);

    MAXP_setUnhinted(lfFont);
    HEAD_setUnhinted(lfFont);

    return LF_ERROR_OK;
}

LF_ERROR SFNT_obfuscateFont(LF_FONT* lfFont)
{
    if (FALSE == SFNT_tablesUnpacked(lfFont))
    {
        lfFont->obfuscateOnWrite = TRUE;

        return LF_ERROR_OK;
    }
    else
    {
        return NAME_obfuscate(lfFont);
    }
}

LF_ERROR SFNT_getNameString(LF_FONT* lfFont, boolean isMac, USHORT nameID, BYTE** name, USHORT* length)
{
    LF_ERROR error;

    *length = 0;
    *name = NULL;

    if (FALSE == SFNT_tablesUnpacked(lfFont))
    {
        error = SFNT_unpackTables(lfFont);
        if (error != LF_ERROR_OK)
            return error;
    }

    error = NAME_parseTable(lfFont);
    if (error != LF_ERROR_OK)
        return error;

    if (isMac)
    {
        error = NAME_getMacNameStringLength(lfFont, nameID, length);
        if (error != LF_ERROR_OK)
            return error;

        *name = (BYTE*)malloc(*length);
        if (*name == NULL)
            return LF_OUT_OF_MEMORY;

        return NAME_getMacNameString(lfFont, nameID, *name, *length);
    }
    else
    {
        error = NAME_getNameStringLength(lfFont, nameID, length);
        if (error != LF_ERROR_OK)
            return error;

        *name = (BYTE*)malloc(*length);
        if (*name == NULL)
            return LF_OUT_OF_MEMORY;

        return NAME_getNameString(lfFont, nameID, *name, *length);
    }
}

LF_ERROR SFNT_setNameString(LF_FONT* lfFont, boolean isMac, USHORT nameID, const BYTE *buffer, USHORT length)
{
    if (isMac)
        return NAME_setMacNameString(lfFont, nameID, buffer, length);
    else
        return NAME_setNameString(lfFont, nameID, buffer, length);
}

LF_ERROR SFNT_getGlyphID(LF_FONT* lfFont, ULONG unicode, GlyphID* glyphID)
{
    if (FALSE == SFNT_tablesUnpacked(lfFont))
    {
        LF_ERROR error = SFNT_unpackTables(lfFont);
        if (error != LF_ERROR_OK)
            return error;
    }

    // See if the font has a 3, 10 encoding
    const cmap_encoding* encodingRecord = CMAP_getEncodingRecord(lfFont, 3, 10);
    if (encodingRecord == NULL)
    {
        // See if the font has a 3, 1 encoding
        encodingRecord = CMAP_getEncodingRecord(lfFont, 3, 1);
    }

    if (encodingRecord == NULL)
        return LF_UNSUPPORTED;

    *glyphID = CMAP_getIndexFromUnicode(lfFont, encodingRecord, unicode, lfFont->isSubsetted);

    return LF_ERROR_OK;
}

LF_ERROR SFNT_getVendorID(LF_FONT* lfFont, CHAR achVendID[4])
{
    if (FALSE == SFNT_tablesUnpacked(lfFont))
    {
        LF_ERROR error = SFNT_unpackTables(lfFont);
        if (error != LF_ERROR_OK)
            return error;
    }

    return OS2_getVendor(lfFont, achVendID);
}

LF_ERROR SFNT_getFsType(LF_FONT* lfFont, USHORT* embedding)
{
    if (FALSE == SFNT_tablesUnpacked(lfFont))
    {
        LF_ERROR error = SFNT_unpackTables(lfFont);
        if (error != LF_ERROR_OK)
            return error;
    }

    return OS2_getFsType(lfFont, embedding);
}

LF_ERROR SFNT_setFsType(LF_FONT* lfFont, USHORT embedding)
{
    if (FALSE == SFNT_tablesUnpacked(lfFont))
    {
        LF_ERROR error = SFNT_unpackTables(lfFont);
        if (error != LF_ERROR_OK)
            return error;
        lfFont->isSubsetted = TRUE; // subset is entire font, forces use of unpacked tables
    }

    return OS2_setFsType(lfFont, embedding);
}

LF_ERROR SFNT_getFsSelection(LF_FONT* lfFont, USHORT* selection)
{
    if (FALSE == SFNT_tablesUnpacked(lfFont))
    {
        LF_ERROR error = SFNT_unpackTables(lfFont);
        if (error != LF_ERROR_OK)
            return error;
    }

    return OS2_getFsSelection(lfFont, selection);
}

LF_ERROR SFNT_setFsSelection(LF_FONT* lfFont, USHORT selection)
{
    if (FALSE == SFNT_tablesUnpacked(lfFont))
    {
        LF_ERROR error = SFNT_unpackTables(lfFont);
        if (error != LF_ERROR_OK)
            return error;
        lfFont->isSubsetted = TRUE; // subset is entire font, forces use of unpacked tables
    }

    return OS2_setFsSelection(lfFont, selection);
}

LF_ERROR SFNT_getUsWeightClass(LF_FONT* lfFont, USHORT* usWeightClass)
{
    if (FALSE == SFNT_tablesUnpacked(lfFont))
    {
        LF_ERROR error = SFNT_unpackTables(lfFont);
        if (error != LF_ERROR_OK)
            return error;
    }

    return OS2_getWeightClass(lfFont, usWeightClass);
}

LF_ERROR SFNT_setUsWeightClass(LF_FONT* lfFont, USHORT usWeightClass)
{
    if (FALSE == SFNT_tablesUnpacked(lfFont))
    {
        LF_ERROR error = SFNT_unpackTables(lfFont);
        if (error != LF_ERROR_OK)
            return error;
        lfFont->isSubsetted = TRUE; // subset is entire font, forces use of unpacked tables
    }

    return OS2_setWeightClass(lfFont, usWeightClass);
}

LF_ERROR SFNT_getMacStyle(LF_FONT* lfFont, USHORT* macStyle)
{
    if (FALSE == SFNT_tablesUnpacked(lfFont))
    {
        LF_ERROR error = SFNT_unpackTables(lfFont);
        if (error != LF_ERROR_OK)
            return error;
    }

    return HEAD_getMacStyle(lfFont, macStyle);
}

LF_ERROR SFNT_setMacStyle(LF_FONT* lfFont, USHORT macStyle)
{
    if (FALSE == SFNT_tablesUnpacked(lfFont))
    {
        LF_ERROR error = SFNT_unpackTables(lfFont);
        if (error != LF_ERROR_OK)
            return error;
        lfFont->isSubsetted = TRUE; // subset is entire font, forces use of unpacked tables
    }

    return HEAD_setMacStyle(lfFont, macStyle);
}

LF_ERROR SFNT_getSFNTSize(LF_FONT* lfFont, const LF_WRITE_PARAMS *params, size_t* size)
{
    LF_ERROR error;

    error = SFNT_getTablesSize(lfFont, params, size);
    if(error != LF_ERROR_OK)
        return error;

    *size += SFNT_HEADER_SIZE;
    *size += 4 * sizeof(ULONG) * offset_getNumTables(lfFont);

    return LF_ERROR_OK;
}

// gets the total of the (padded) table sizes.
LF_ERROR SFNT_getTablesSize(LF_FONT* lfFont, const LF_WRITE_PARAMS *params, size_t* size)
{
    *size = 0;

    boolean isPacked = map_empty(&lfFont->table_map);
    boolean unpackedSlim = SFNT_isUnpackedSlim(lfFont);

    sfnt_offset_table* table = (sfnt_offset_table*)lfFont->offset_table.sfnt;

    // loop over the tables and add up the sizes
    for (size_t i = 0; i < table->record_list.count; ++i)
    {
        sfnt_table_record* record = offset_getRecord(lfFont, i);
        if(NULL == record)
            return LF_BAD_FORMAT;

        if ((lfFont->fontType == eLF_SFNT_FONT) && (record->tag == TAG_CFF))
            continue;

        // Hint tables are not written to fonts with cff tables
        // Some aat tables are not written to fonts with cff tables
        // Note: Some aat tables are still let through and will be invalid. See the note for
        //       LF_KEEP_ALL_TABLES in lf_core.h
        // lfFont->fontType will be either eLF_SNFT_FONT or eLF_CFF_FONT here
        if ((lfFont->fontType == eLF_CFF_FONT) && TableExcludedFromCFFFont(record->tag))
            continue;

        if (isPacked || unpackedSlim)
            *size += (record->length + 3) & ~3;    // just add the padded length
        else
        {
            LF_ERROR error;
            size_t unPaddedSize;

            // need to calculate per table
            error = SFNT_getTableSize(lfFont, params, record->tag, &unPaddedSize);
            if(error != LF_ERROR_OK)
                return LF_BAD_FORMAT;

            *size += (unPaddedSize + 3) & ~3;
        }
    }

    return LF_ERROR_OK;
}

LF_ERROR SFNT_freeFont(LF_FONT* lfFont)
{
    if(FALSE == map_empty(&lfFont->table_map))
    {
        sfnt_offset_table* table = (sfnt_offset_table*)lfFont->offset_table.sfnt;

        for (size_t i = 0; i < table->record_list.count; ++i)
        {
            sfnt_table_record* record = offset_getRecord(lfFont, i);
            SFNT_freeTable(lfFont, record);
        }
    }

    return offset_freeTable(lfFont);
}

boolean SFNT_tablesUnpacked(LF_FONT* lfFont)
{
    ASSERT(lfFont);
    if (TRUE == map_empty(&lfFont->table_map))
        return FALSE;

    return TRUE;
}

LF_ERROR SFNT_unpackVAlignTable(LF_FONT* lfFont)
{
    sfnt_table_record* record;
    LF_ERROR error;
    LF_STREAM stream;

    if (0 != map_size(&lfFont->table_map))
        return LF_BAD_FORMAT;    // no tables should be unpacked yet

    STREAM_initMemStream(&stream, lfFont->fontData, lfFont->fontSize);

    // unpack HHEA
    record = offset_findRecord(lfFont, TAG_HHEA);
    if (record == NULL)
        return LF_TABLE_MISSING;

    error = HHEA_readTable(lfFont, record, &stream);
    if (error != LF_ERROR_OK)
        return error;

    // unpack OS/2
    record = offset_findRecord(lfFont, TAG_OS2);
    if (record == NULL)
        return LF_TABLE_MISSING;

    return OS2_readTable(lfFont, record, &stream);
}

LF_ERROR SFNT_packVAlignTable(LF_FONT* lfFont)
{
    sfnt_table_record* record;
    LF_ERROR error;
    LF_STREAM stream;

    STREAM_initMemStream(&stream, lfFont->fontData, lfFont->fontSize);

    record = offset_findRecord(lfFont, TAG_HHEA);
    if (record == NULL)
        return LF_TABLE_MISSING;

    error = HHEA_overwriteTable(lfFont, record, &stream);
    if (error != LF_ERROR_OK)
    {
        DEBUG_LOG_ERROR("error writing out HHEA table");
    }

    HHEA_freeTable(lfFont);
    OS2_freeTable(lfFont);

    map_erase(&lfFont->table_map, (void*)TAG_HHEA);
    map_erase(&lfFont->table_map, (void*)TAG_OS2);

    return error;
}

LF_ERROR SFNT_getGlyph(LF_FONT* lfFont, GlyphID index, LF_GLYPH** glyphData)
{
    *glyphData = NULL;

    // Tables have to be unpakced to get glyphs
    boolean isUnpacked = SFNT_tablesUnpacked(lfFont);

    if (FALSE == isUnpacked)
    {
        LF_ERROR error = SFNT_unpackTables(lfFont);
        if (error != LF_ERROR_OK)
            return error;
        // ?? lfFont->isSubsetted = TRUE; // subset is entire font, forces use of unpacked tables
    }

    USHORT numGlyphs = MAXP_getNumGlyphs(lfFont);

    if (index >= numGlyphs)
        return LF_INVALID_PARAM;

    LF_GLYPH* newGlyph = calloc(1, sizeof(LF_GLYPH));
    if (NULL == newGlyph)
        return LF_OUT_OF_MEMORY;

    LF_ERROR error;

    if ((lfFont->origType == eLF_CFF_FONT) || (lfFont->origFlavor == SIG_CFF))
    {

        // not done yet

        free(newGlyph);

        // conversion_getCFFGlyph(const cff_table* cffTable, USHORT index, Glyph* cubicGlyph)

        return LF_UNIMPLEMENTED;
    }
    else
    {

        // ttf font, get the glyph from the glyf table

        glyf myglyf;

        error = GLYF_getFullGlyph(lfFont, &myglyf, (ULONG)index);
        if (LF_ERROR_OK != error)
        {
            free(newGlyph);
            return error;
        }

        if (myglyf.numberOfContours == -1)
        {
            newGlyph->isComposite = TRUE;

            size_t numComponents = vector_size(&myglyf.glyf_data.composite);

            LF_GLYPH_COMPONENT* gc = &newGlyph->component;

            composite_glyf* comp_glyf = (composite_glyf*)vector_at(&myglyf.glyf_data.composite, 0);

            gc->flags = comp_glyf->flags;
            gc->xoffset = comp_glyf->argument1; // user responsible for checking if this is an offset or a point #
            gc->yoffset = comp_glyf->argument2;
            gc->xscale = comp_glyf->xscale;
            gc->yscale = comp_glyf->yscale;
            gc->scale01 = comp_glyf->scale01;
            gc->scale10 = comp_glyf->scale10;

            for (size_t i = 1; i < numComponents; i++)
            {
                comp_glyf = (composite_glyf*)vector_at(&myglyf.glyf_data.composite, i);

                LF_GLYPH_COMPONENT* newgc = (LF_GLYPH_COMPONENT*)calloc(1, sizeof(LF_GLYPH_COMPONENT));
                if (NULL == newgc)
                {
                    // unwind components todo
                    free(newGlyph);
                    return LF_OUT_OF_MEMORY;
                }

                gc->next = newgc;
                gc = newgc;
                gc->flags = comp_glyf->flags;
                gc->xoffset = comp_glyf->argument1; // user responsible for checking if this is an offset or a point #
                gc->yoffset = comp_glyf->argument2;
                gc->xscale = comp_glyf->xscale;
                gc->yscale = comp_glyf->yscale;
                gc->scale01 = comp_glyf->scale01;
                gc->scale10 = comp_glyf->scale10;
            }
        }
        else if (myglyf.numberOfContours == 0)
        {
            ;   // new glyph initialized above
        }
        else
        {
            // Get points from glyf object
            LF_VECTOR pointsArray;

            error = vector_init(&pointsArray, myglyf.glyf_data.simple.endPtsOfContours[myglyf.numberOfContours - 1], 4);
            if (error != LF_ERROR_OK)
            {
                GLYF_destroyGlyf(&myglyf);
                free(newGlyph);
                return error;
            }

            error = GLYF_getGlyfPoints(lfFont, &myglyf, &pointsArray);
            if (error != LF_ERROR_OK)
            {
                GLYF_destroyGlyf(&myglyf);
                free(newGlyph);
                return error;
            }

            Glyph quadGlyph;
            Glyph_Outline* quadGlyphOutline = &quadGlyph.glyphOutline;
            Simple_Outline* so = &quadGlyphOutline->component.outline;

            memset(&quadGlyph, 0, sizeof(Glyph));

            error = conversion_addPointsToGlyphOutlineV2(&pointsArray, quadGlyphOutline);
            if (error != LF_ERROR_OK)
            {
                vector_free(&pointsArray);
                GLYF_destroyGlyf(&myglyf);
                free(newGlyph);
                return error;
            }

            // Fill in new structure


            newGlyph->component.outline.numContours = so->nc;
            newGlyph->component.outline.numPoints = so->np;
            newGlyph->component.outline.endPtsOfContours = (USHORT*)calloc(so->nc, sizeof(USHORT));

            if (NULL == newGlyph->component.outline.endPtsOfContours)
            {
                conversion_freeGlyphOutline(&quadGlyph);
                vector_free(&pointsArray);
                GLYF_destroyGlyf(&myglyf);
                free(newGlyph);
                return error;
            }

            for (size_t j = 0; j < quadGlyphOutline->component.outline.nc; j++)
                newGlyph->component.outline.endPtsOfContours[j] = so->endPtsOfContours[j];

            error = vector_init(&newGlyph->component.outline.points, newGlyph->component.outline.numPoints, 4);
            if (LF_ERROR_OK != error)
            {
                conversion_freeGlyphOutline(&quadGlyph);
                vector_free(&pointsArray);
                GLYF_destroyGlyf(&myglyf);
                free(newGlyph);
                return error;
            }

            for (size_t j = 0; j < newGlyph->component.outline.numPoints; j++)
            {
                LF_CONTOUR_POINT* toPt = (LF_CONTOUR_POINT*)calloc(1, sizeof(LF_CONTOUR_POINT));

                if (NULL == toPt)
                {
                    conversion_freeGlyphOutline(&quadGlyph);
                    vector_free(&pointsArray);
                    GLYF_destroyGlyf(&myglyf);
                    free(newGlyph);
                    return error;
                }

                switch (so->types[j])
                {
                case MOVE_TO:
                    toPt->type = LF_MOVETO;
                    break;
                case LINE_TO:
                    toPt->type = LF_LINETO;
                    break;
                case ON_CURVE:
                    toPt->type = LF_ON_CURVE;
                    break;
                case OFF_CURVE:
                    toPt->type = LF_OFF_CURVE;
                    break;
                }

                toPt->x = (FIXED)(so->x[j] * 65536);
                toPt->y = (FIXED)(so->y[j] * 65536);

                error = vector_push_back(&newGlyph->component.outline.points, toPt);

                if (LF_ERROR_OK != error)
                {
                    conversion_freeGlyphOutline(&quadGlyph);
                    vector_free(&pointsArray);
                    GLYF_destroyGlyf(&myglyf);
                    free(newGlyph);
                    return error;
                }
            }

            conversion_freeGlyphOutline(&quadGlyph);
            vector_free(&pointsArray);
        }
        GLYF_destroyGlyf(&myglyf);
    }

    *glyphData = newGlyph;

    return LF_ERROR_OK;
}

LF_ERROR SFNT_freeGlyph(LF_GLYPH* glyphData)
{
    if (glyphData->isComposite)
    {
        LF_GLYPH_COMPONENT* gc = glyphData->component.next;

        while (gc)
        {
            LF_GLYPH_COMPONENT* next = gc->next;
            free(gc);
            gc = next;
        }
    }
    else
    {
        if (glyphData->component.outline.endPtsOfContours != NULL)
            free(glyphData->component.outline.endPtsOfContours);

        size_t numPoints = vector_size(&glyphData->component.outline.points);

        if (0 != numPoints)
        {
            for (size_t i = 0; i < numPoints; i++)
            {
                LF_CONTOUR_POINT* curPt = vector_at(&glyphData->component.outline.points, i);

                free(curPt);
            }
        }

        vector_free(&glyphData->component.outline.points);
    }

    free(glyphData);

    return LF_ERROR_OK;
}

LF_ERROR SFNT_setGlyph(LF_FONT* lfFont, GlyphID index, LF_GLYPH* glyphData)
{
    LF_ERROR error = LF_ERROR_OK;

    if ((lfFont->origType == eLF_CFF_FONT) || (lfFont->origFlavor == SIG_CFF))
    {
        // not done yet

        return LF_UNIMPLEMENTED;
    }
    else
    {
        // Determine number of points
        USHORT numPoints;

        if (glyphData->isComposite == TRUE)
        {
            return LF_UNIMPLEMENTED;
        }
        else
        {
            numPoints = glyphData->component.outline.numPoints;
        }


        // Create scratch space
        glyfBuildScratchSpace scratch;

        if (0 != conversion_allocateScratchSpace(&scratch, numPoints + 10))
            return LF_OUT_OF_MEMORY;

        LF_GLYPH_OUTLINE* go = &glyphData->component.outline;

        Glyph quadGlyph;
        memset(&quadGlyph, 0, sizeof(quadGlyph));

        quadGlyph.glyphType = eGlyph_TTF;
        quadGlyph.glyphOutline.numberOfComponents = 1;
        quadGlyph.glyphOutline.component.next = 0;
        quadGlyph.glyphOutline.component.glyphIndex = index;
        quadGlyph.glyphOutline.component.type = eSimple;


        // Add points
        Simple_Outline* so = &quadGlyph.glyphOutline.component.outline;

        so->np = numPoints;
        so->nc = go->numContours;

        so->endPtsOfContours = (unsigned short *)calloc(so->nc, sizeof(unsigned short));
        if (NULL == so->endPtsOfContours)
        {
            conversion_freeScratchSpace(&scratch);
            return LF_OUT_OF_MEMORY;
        }
        for (int i = 0; i < so->nc; i++)
            so->endPtsOfContours[i] = go->endPtsOfContours[i];

        so->x = (float *)calloc(so->np, sizeof(float));
        if (NULL == so->x)
        {
            free(so->endPtsOfContours);
            conversion_freeScratchSpace(&scratch);
            return LF_OUT_OF_MEMORY;
        }

        so->y = (float *)calloc(so->np, sizeof(float));
        if (NULL == so->y)
        {
            free(so->x);
            free(so->endPtsOfContours);
            conversion_freeScratchSpace(&scratch);
            return LF_OUT_OF_MEMORY;
        }

        so->types = (Point_Type *)calloc(so->np, sizeof(Point_Type));
        if (NULL == so->types)
        {
            free(so->y);
            free(so->x);
            free(so->endPtsOfContours);
            conversion_freeScratchSpace(&scratch);
            return LF_OUT_OF_MEMORY;
        }

        for (int i = 0; i < so->np; i++)
        {
            LF_CONTOUR_POINT* curPt = vector_at(&go->points, i);

            so->x[i] = curPt->x / 65536.f;
            so->y[i] = curPt->y / 65536.f;

            if (curPt->type == LF_MOVETO)
                so->types[i] = MOVE_TO;
            else if (curPt->type == LF_LINETO)
                so->types[i] = LINE_TO;
            else if (curPt->type == LF_ON_CURVE)
                so->types[i] = ON_CURVE;
            else
                so->types[i] = OFF_CURVE;
        }

        // calculate bounding box
        conversion_computeQuadBoundingBox(&quadGlyph);

        // create glyf header and data from Glyph
        glyf newGlyf;
        memset(&newGlyf, 0, sizeof(glyf));

        error = conversion_convertGlyphToCompressedGlyf(&quadGlyph, &scratch, &newGlyf);
        if (error != LF_ERROR_OK)
        {
            conversion_freeScratchSpace(&scratch);
            return error;
        }

        error = GLYF_replaceGlyph(lfFont, index, &newGlyf);

        free(newGlyf.glyfBlock);    // the above copies, not take possesion
        conversion_freeGlyphOutline(&quadGlyph);
        conversion_freeScratchSpace(&scratch);
    }

    return error;
}

LF_ERROR SFNT_updateFont(LF_FONT* lfFont)
{
    // Update the font after the font has changed.
    // Note that this is currently customized for what to do when harmonizing.


    maxp_table* table = (maxp_table*)map_at(&lfFont->table_map, (void*)TAG_MAXP);
    if (table == NULL)
        return LF_TABLE_MISSING;

    LF_ERROR error;

    // Note this function does not support the conversion case
    //if (lfFont->origType != )


    if (lfFont->origType != eLF_CFF_FONT)
    {
        error = GLYF_getMAXPInfo(lfFont, table, TRUE);
        if (error != LF_ERROR_OK)
            return error;
    }

    boolean hasVHEA, hasVMTX;

    LF_hasTable(lfFont, TAG_VHEA, &hasVHEA);
    LF_hasTable(lfFont, TAG_VMTX, &hasVMTX);

    if (hasVHEA && hasVMTX)
    {
        VHEA_setAdvanceHeightMax(lfFont, VMTX_getAdvanceHeightMax(lfFont));
        VHEA_setNumVMetrics(lfFont, VMTX_getNumVMetrics(lfFont));
        VHEA_setTopSidebearingMin(lfFont, VMTX_getMinTopSidebearing(lfFont));
        VHEA_setVertTypoLineGap(lfFont, 0);
    }

    SHORT xMin, yMin, xMax, yMax;

    if (lfFont->origType == eLF_CFF_FONT)
        error = CFF__getBoundingBox(lfFont, &xMin, &yMin, &xMax, &yMax);
    else
        error = GLYF_getBoundingBox(lfFont, &xMin, &yMin, &xMax, &yMax);
    if (error != LF_ERROR_OK)
        return error;

    // Update hmtx side bearings and get min values
    FWORD minlsb, minrsb, maxadvance;
    error = HMTX_updateSidebearings(lfFont, lfFont->fontType, &minlsb, &minrsb, &maxadvance);
    if (error != LF_ERROR_OK)
        return error;

    HEAD_setBoundingBox(lfFont, xMin, yMin, xMax, yMax);
    HHEA_setXMaxExtent(lfFont, xMax);
    HHEA_setLeftSidebearingMin(lfFont, minlsb);
    HHEA_setRightSidebearingMin(lfFont, minrsb);
    HHEA_setAdvanceWidthMax(lfFont, maxadvance);
    HHEA_setNumHMetrics(lfFont, HMTX_getNumHMetrics(lfFont));

    error = SFNT_removeHints(lfFont);
    if (error != LF_ERROR_OK)
        DEBUG_LOG("WARNING: Failed to remove hints from font.\n");

    SFNT_removeTable(lfFont, TAG_DSIG);
    SFNT_removeTable(lfFont, TAG_LTSH);

    USHORT os2Version;
    OS2_getVersion(lfFont, &os2Version);
    if (os2Version < 3)
        OS2_upgradeTable(lfFont);
    else
    {
        OS2_updateHeights(lfFont);
        //OS2_updateMaxContent(curFont);
    }
    OS2_setAvgCharWidth(lfFont, HMTX_getAdvanceWidthAvg(lfFont));

    return LF_ERROR_OK;
}
