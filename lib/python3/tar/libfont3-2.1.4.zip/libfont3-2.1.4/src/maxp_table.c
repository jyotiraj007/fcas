// Copyright (C) 2014, 2015 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// maxp_table.c

#include <stdlib.h>
#include "maxp_table.h"
#include "cff_table.h"
#include "glyf_table.h"
#include "cmap_table.h"
#include "utils.h"

LF_ERROR MAXP_readTable(LF_FONT* lfFont, const sfnt_table_record* record, LF_STREAM* stream)
{
    if (STREAM_streamSeek(stream, record->offset) == 0)
    {
        if (record->length > 0)
        {
            maxp_table* table = (maxp_table*)calloc(sizeof(maxp_table), 1);
            if (table == NULL)
                return LF_OUT_OF_MEMORY;

            table->version = STREAM_readFixed(stream);
            table->numGlyphs = STREAM_readUShort(stream);

            if (table->version == 0x00010000)
            {
                table->maxPoints = STREAM_readUShort(stream);
                table->maxContours = STREAM_readUShort(stream);
                table->maxCompositePoints = STREAM_readUShort(stream);
                table->maxCompositeContours = STREAM_readUShort(stream);
                table->maxZones = STREAM_readUShort(stream);
                table->maxTwilightPoints = STREAM_readUShort(stream);
                table->maxStorage = STREAM_readUShort(stream);
                table->maxFunctionDefs = STREAM_readUShort(stream);
                table->maxInstructionDefs = STREAM_readUShort(stream);
                table->maxStackElements = STREAM_readUShort(stream);
                table->maxSizeOfInstructions = STREAM_readUShort(stream);
                table->maxComponentElements = STREAM_readUShort(stream);
                table->maxComponentDepth = STREAM_readUShort(stream);
            }

            map_insert(&lfFont->table_map, (void*)(intptr_t)record->tag, table);
            return LF_ERROR_OK;
        }
    }

    return LF_INVALID_OFFSET;
}

LF_ERROR MAXP_writeTable(LF_FONT* lfFont, FIXED version, sfnt_table_record* record, LF_STREAM* stream)
{
    ULONG tableLen;
    size_t padLen;
    BYTE* padTable;
    maxp_table* table = (maxp_table*)map_at(&lfFont->table_map, (void*)(intptr_t)record->tag);
    LF_STREAM localStream;

    if (table == NULL)
        return LF_TABLE_MISSING;

    if (version == 0x00005000)
    {
        tableLen = MAXP_V05_TABLE_SIZE;
        //padLen = (MAXP_V05_TABLE_SIZE + 3) & ~3;
    }
    else
    {
        tableLen = MAXP_V10_TABLE_SIZE;
        //padLen = (MAXP_V10_TABLE_SIZE + 3) & ~3;
    }

    padLen = tableLen;
    padTable = UTILS_AllocTable(&padLen);
    if (padTable == NULL)
        return LF_OUT_OF_MEMORY;

    STREAM_initMemStream(&localStream, padTable, tableLen);

    STREAM_writeFixed(&localStream, version);
    STREAM_writeShort(&localStream, table->numGlyphs);

    if (version == 0x00010000)
    {
        STREAM_writeShort(&localStream, table->maxPoints);
        STREAM_writeShort(&localStream, table->maxContours);
        STREAM_writeShort(&localStream, table->maxCompositePoints);
        STREAM_writeShort(&localStream, table->maxCompositeContours);
        STREAM_writeShort(&localStream, table->maxZones);
        STREAM_writeShort(&localStream, table->maxTwilightPoints);
        STREAM_writeShort(&localStream, table->maxStorage);
        STREAM_writeShort(&localStream, table->maxFunctionDefs);
        STREAM_writeShort(&localStream, table->maxInstructionDefs);
        STREAM_writeShort(&localStream, table->maxStackElements);
        STREAM_writeShort(&localStream, table->maxSizeOfInstructions);
        STREAM_writeShort(&localStream, table->maxComponentElements);
        STREAM_writeShort(&localStream, table->maxComponentDepth);
    }

    record->checkSum = UTILS_CalcTableChecksum(padTable, tableLen);
    record->length = tableLen;
    record->offset = (ULONG)STREAM_streamPos(stream);

    STREAM_streamSeek(stream, record->offset);
    STREAM_writeChunk(stream, padTable, padLen);
    free(padTable);

    return LF_ERROR_OK;
}

LF_ERROR MAXP_updateTable(LF_FONT* lfFont, ULONG updateFrom, boolean fullUpdate, boolean calculate, boolean checkEBTables)
{
    maxp_table* table = (maxp_table*)map_at(&lfFont->table_map, (void*)TAG_MAXP);
    if (table == NULL)
        return LF_TABLE_MISSING;

    table->numGlyphs = 0;

    LF_ERROR error = LF_ERROR_OK;

    if (updateFrom == TAG_GLYF)
    {
        if (TRUE == fullUpdate)
            error = GLYF_getMAXPInfo(lfFont, table, calculate);
        else
            table->numGlyphs = (USHORT)GLYF_getCount(lfFont);
    }
    else if (updateFrom == TAG_CFF)
    {
        error = CFF__getCount(lfFont, &table->numGlyphs);   // only care about number of glyphs for format 0.5
    }
    else if (FALSE == checkEBTables)
        return LF_INVALID_PARAM;

    // Assuming that if there is a glyf table, any bitmaps in the CBDT table also have
    // a glyph associated with them in the glyf table. If that is not correct, we
    // would need to analyze the cmap to get the right number.
    if ((error == LF_ERROR_OK) && (checkEBTables == TRUE) && (table->numGlyphs == 0))
    {
        if (TRUE == map_key_exists(&lfFont->table_map, (void*)TAG_CBDT))
        {
            // The font has a CBDT but no glyf or cff. Use the number of entries left in
            // the cmap to determine how many glyphs there are. This accounts for glyph 0,
            // for which there may not be an image in the CBDT
            USHORT numInCmap;
            CMAP_getCount(lfFont, &numInCmap);

            table->numGlyphs = numInCmap;
        }
    }

    return error;
}

LF_ERROR MAXP_setUnhinted(LF_FONT* lfFont)
{
    maxp_table* table = (maxp_table*)map_at(&lfFont->table_map, (void*)TAG_MAXP);
    if (table == NULL)
        return LF_TABLE_MISSING;

    table->maxStorage = 0;
    table->maxFunctionDefs = 0;
    table->maxSizeOfInstructions = 0;
    table->maxStackElements = 0;
    table->maxInstructionDefs = 0;
    table->maxTwilightPoints = 0;

    return LF_ERROR_OK;
}

LF_ERROR MAXP_getTableSize(LF_FONT* lfFont, FIXED version, size_t* tableSize)
{
    *tableSize = 0;

    maxp_table* table = (maxp_table*)map_at(&lfFont->table_map, (void*)TAG_MAXP);
    if (table == NULL)
        return LF_TABLE_MISSING;

    if (version == 0x00005000)
        *tableSize = MAXP_V05_TABLE_SIZE;
    else if (version == 0x00010000)
        *tableSize = MAXP_V10_TABLE_SIZE;
    else
        return LF_INVALID_PARAM;

    return LF_ERROR_OK;
}

LF_ERROR MAXP_freeTable(LF_FONT* lfFont)
{
    maxp_table* table = (maxp_table*)map_at(&lfFont->table_map, (void*)TAG_MAXP);

    if (table != NULL)
        free(table);

    return LF_ERROR_OK;
}

USHORT MAXP_getNumGlyphs(LF_FONT* lfFont)
{
    maxp_table* table = (maxp_table*)map_at(&lfFont->table_map, (void*)TAG_MAXP);

    if (table == NULL)
        return 0;       // error

    return table->numGlyphs;
}

USHORT MAXP_getMaxPoints(LF_FONT* lfFont)
{
    maxp_table* table = (maxp_table*)map_at(&lfFont->table_map, (void*)TAG_MAXP);
    if (table == NULL)
        return 0;       // error

    return table->maxPoints;
}

USHORT MAXP_getMaxContours(LF_FONT* lfFont)
{
    maxp_table* table = (maxp_table*)map_at(&lfFont->table_map, (void*)TAG_MAXP);
    if (table == NULL)
        return 0;       // error

    return table->maxContours;
}

USHORT MAXP_getMaxCompDepth(LF_FONT* lfFont)
{
    maxp_table* table = (maxp_table*)map_at(&lfFont->table_map, (void*)TAG_MAXP);
    if (table == NULL)
        return 0;       // error

    return table->maxComponentDepth;
}
