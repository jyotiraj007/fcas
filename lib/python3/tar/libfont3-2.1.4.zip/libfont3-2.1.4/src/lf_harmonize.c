// Copyright (C) 2016, 2017 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
//
/// \file lf_harmonize.c

#include <string.h>
#include <sys/stat.h>
#include <stdlib.h>
#include <ctype.h>
#include <time.h>

#include "Harmonizer.h"
#include "lf_harmonize.h"
#include "cff_conversion.h"
#include "sfnt_core.h"
#include "cmap_table.h"
#include "glyf_table.h"
#include "gpos_table.h"
#include "head_table.h"
#include "hmtx_table.h"
#include "hhea_table.h"
#include "loca_table.h"
#include "maxp_table.h"
#include "name_table.h"
#include "os2_table.h"
#include "post_table.h"
#include "vhea_table.h"
#include "vmtx_table.h"
#include "utils.h"


#define writeLog(...)   if (logFile) { fprintf(logFile, __VA_ARGS__); } (void)logFile

static USHORT convertShortToNumber(USHORT* x, USHORT count)
{
    USHORT ret = 0;

    for (SHORT i = (SHORT)(count-1); i >= 0; i--)
    {
        USHORT val = x[count - i - 1];

        if (val < 0x0030 || val > 0x0039)
            return 0;
        USHORT multipler = 1;
        for (USHORT j = 0; j < i; j++)
            multipler *= 10;
        ret += (USHORT)((val - 0x0030) * multipler);
    }

    return ret;
}

static void numberToUShort(USHORT x, USHORT* s, USHORT* len)
{
    if (x < 10)
    {
        s[0] = x + 0x030;
        *len = 1;
    }
    else if (x < 100)
    {
        USHORT tens = x / 10;

        s[0] = tens + 0x0030;

        USHORT ones = x % 10;

        s[1] = ones + 0x0030;

        *len = 2;
    }
    else
    {
        *len = 3;
        s[0] = 0x0032;
        s[1] = 0x0030;
        s[2] = 0x0030;
    }
}

static LF_ERROR updateWindowsNames(LF_FONT* lfFont)
{
    // Update Font Family and Sub Family

    BYTE* uniqueName = NULL;
    BYTE* fullName = NULL;
    USHORT uniqueNameLen, fullNameLen;

    LF_ERROR error = LF_getNameString(lfFont, NAME_UNIQUE_SUBFAMILY_IDENTIFICATION, &uniqueName, &uniqueNameLen);
    if (error != LF_ERROR_OK)
        return error;

    error = LF_getNameString(lfFont, NAME_FONT_FULL_NAME, &fullName, &fullNameLen);
    if (error != LF_ERROR_OK)
    {
        free(uniqueName);
        return error;
    }

    const USHORT harmonized[] = { 0x0020, 0x0068, 0x0061, 0x0072, 0x006D, 0x006F, 0x006E, 0x0069, 0x007A, 0x0065, 0x0064 };
    USHORT harmonizedSize = sizeof(harmonized);
    BYTE *newUnique, *newFull;

    newUnique = (BYTE*)malloc(harmonizedSize + uniqueNameLen);
    if (newUnique == NULL)
    {
        free(fullName);
        free(uniqueName);
        return LF_OUT_OF_MEMORY;
    }

    newFull = (BYTE*)malloc(harmonizedSize + fullNameLen);
    if (newFull == NULL)
    {
        free(newUnique);
        free(fullName);
        free(uniqueName);
        return LF_OUT_OF_MEMORY;
    }

    memcpy(newUnique, uniqueName, uniqueNameLen);
    memcpy(newUnique + uniqueNameLen, harmonized, harmonizedSize);
    memcpy(newFull, fullName, fullNameLen);
    memcpy(newFull + fullNameLen, harmonized, harmonizedSize);

    error = LF_setNameString(lfFont, NAME_UNIQUE_SUBFAMILY_IDENTIFICATION, newUnique, harmonizedSize + uniqueNameLen);
    if (error == LF_ERROR_OK)
        error = LF_setNameString(lfFont, NAME_FONT_FULL_NAME, newFull, harmonizedSize + fullNameLen);

    free(newUnique);
    free(newFull);
    free(fullName);
    free(uniqueName);

    if (error != LF_ERROR_OK)
        return error;

    // Update version
    BYTE* origVersion = NULL;
    USHORT origVersionLen, newVersionLen;

    error = LF_getNameString(lfFont, NAME_VERSION_NAME_TABLE, &origVersion, &origVersionLen);
    if (error != LF_ERROR_OK)
        return error;

    // Check that the string format valid
    USHORT verString[] = { 0x0056, 0x0065, 0x0072, 0x0073, 0x0069, 0x006F, 0x006E, 0x0020 };

    boolean versionOK = FALSE;

    if (0 == memcmp(origVersion, verString, sizeof(verString)))
    {
        versionOK = TRUE;

        USHORT* vers = (USHORT*)(void*)origVersion;
        USHORT len = origVersionLen / 2;
        USHORT dotIndex = 0;

        // figure out the major version
        for (USHORT i = 8; i < len; i++)
        {
            if (vers[i] == 0x002E)
            {
                dotIndex = i;
                break;
            }
        }

        if (dotIndex == 0)
        {
            versionOK = FALSE;
        }
        else
        {
            USHORT origMajor = convertShortToNumber(&vers[8], dotIndex - 8);

            // find the end of the minor version
            USHORT spaceIndex = 0;

            for (USHORT i = dotIndex; i < len; i++)
            {
                if (vers[i] == 0x0020)
                {
                    spaceIndex = i;
                    break;
                }
            }

            // increase the major version
            USHORT newMajor = origMajor + 1;

            USHORT major[10];
            USHORT majorLen;

            numberToUShort(newMajor, major, &majorLen);

            USHORT DotZero[] = { 0x002E, 0x0030, 0x0030 };

            // new string = new major version + .00 + anything after the minor version
            newVersionLen = (USHORT)(sizeof(verString) + majorLen*sizeof(USHORT) + sizeof(DotZero));

            if (spaceIndex != 0)
                newVersionLen += (USHORT)((len - spaceIndex)*sizeof(USHORT));

            if (newVersionLen == 0)
                return LF_BAD_FORMAT;

            BYTE* newVersion = (BYTE*)malloc(newVersionLen);
            if (newVersion == NULL)
                return LF_OUT_OF_MEMORY;

            memcpy(newVersion, verString, sizeof(verString));
            memcpy(newVersion + sizeof(verString), major, majorLen*sizeof(USHORT));
            memcpy(newVersion + sizeof(verString) + majorLen*sizeof(USHORT), DotZero, sizeof(DotZero));
            if (spaceIndex != 0)
                memcpy(newVersion + sizeof(verString) + majorLen*sizeof(USHORT) + sizeof(DotZero),
                &origVersion[2 * spaceIndex], sizeof(USHORT)*(len - spaceIndex));

            error = LF_setNameString(lfFont, NAME_VERSION_NAME_TABLE, newVersion, newVersionLen);

            free(newVersion);
        }
    }

    if (versionOK == FALSE)
    {
        // just put 'Version 2.00'  (assuming original was meant to be 1.0)
        USHORT twoDotZero[] = { 0x0032, 0x002E, 0x0030, 0x0030 };

        newVersionLen = sizeof(verString) + sizeof(twoDotZero);

        BYTE* newVersion = (BYTE*)malloc(newVersionLen);
        if (newVersion == NULL)
            return LF_OUT_OF_MEMORY;

        memcpy(newVersion, verString, sizeof(verString));
        memcpy(newVersion + sizeof(verString), twoDotZero, sizeof(twoDotZero));

        error = LF_setNameString(lfFont, NAME_VERSION_NAME_TABLE, newVersion, newVersionLen);

        free(newVersion);
    }

    free(origVersion);

    return error;
}

static LF_ERROR updateMacNames(LF_FONT* lfFont)
{
    // Update Font Family and Sub Family

    BYTE uniqueName[50];
    BYTE fullName[128];
    USHORT uniqueNameMax = 50, fullNameMax = 128;

    memset(uniqueName, 0, sizeof(uniqueName));
    memset(fullName, 0, sizeof(fullName));

    LF_ERROR error = NAME_getMacNameString(lfFont, NAME_UNIQUE_SUBFAMILY_IDENTIFICATION, uniqueName, uniqueNameMax-1);
    if (error != LF_ERROR_OK)
    {
        if (error == LF_INVALID_TYPE)   // ok if there isn't one
            return LF_ERROR_OK;
        return error;
    }

    size_t uniqueNameLen = strlen((char*)uniqueName);

    error = NAME_getMacNameString(lfFont, NAME_FONT_FULL_NAME, fullName, fullNameMax-1);
    if (error != LF_ERROR_OK)
    {
        return error;
    }

    size_t fullNameLen = strlen((char*)fullName);

    const BYTE harmonized[] = { 0x20, 0x68, 0x61, 0x72, 0x6D, 0x6F, 0x6E, 0x69, 0x7A, 0x65, 0x64 };
    USHORT harmonizedSize = sizeof(harmonized);
    BYTE *newUnique, *newFull;

    newUnique = (BYTE*)malloc(harmonizedSize + uniqueNameLen);
    if (newUnique == NULL)
    {
        return LF_OUT_OF_MEMORY;
    }

    newFull = (BYTE*)malloc(harmonizedSize + fullNameLen);
    if (newFull == NULL)
    {
        free(newUnique);
        return LF_OUT_OF_MEMORY;
    }

    memcpy(newUnique, uniqueName, uniqueNameLen);
    memcpy(newUnique + uniqueNameLen, harmonized, harmonizedSize);
    memcpy(newFull, fullName, fullNameLen);
    memcpy(newFull + fullNameLen, harmonized, harmonizedSize);

    error = NAME_setMacNameString(lfFont, NAME_UNIQUE_SUBFAMILY_IDENTIFICATION, newUnique, (USHORT)(harmonizedSize + uniqueNameLen));
    if (error == LF_ERROR_OK)
        error = NAME_setMacNameString(lfFont, NAME_FONT_FULL_NAME, newFull, (USHORT)(harmonizedSize + fullNameLen));

    free(newFull);
    free(newUnique);

    if (error != LF_ERROR_OK)
        return error;

    // Update version
    BYTE origVersion[50];
    USHORT origVersionLenMax = 50, newVersionLen;

    memset(origVersion, 0, sizeof(origVersion));

    error = NAME_getMacNameString(lfFont, NAME_VERSION_NAME_TABLE, origVersion, origVersionLenMax-1);
    if (error != LF_ERROR_OK)
        return error;

    size_t origVersionLen = strlen((char*)origVersion);

    // Check that the string format valid
    BYTE verString[] = { 0x56, 0x65, 0x72, 0x73, 0x69, 0x6F, 0x6E, 0x20 };

    boolean versionOK = FALSE;

    if (0 == memcmp(origVersion, verString, sizeof(verString)))
    {
        versionOK = TRUE;

        USHORT dotIndex = 0;

        // figure out the major version
        for (USHORT i = 8; i < origVersionLen; i++)
        {
            if (origVersion[i] == 0x002E)
            {
                dotIndex = i;
                break;
            }
        }

        if (dotIndex == 0)
        {
            versionOK = FALSE;
        }
        else
        {
            char vers[8] = { 0 };

            memcpy(vers, origVersion + 8, dotIndex - 8);

            USHORT origMajor = (USHORT)atoi(vers);

            // find the end of the minor version
            size_t spaceIndex = 0, end = origVersionLen < 8 ? origVersionLen : 8;

            for (size_t i = dotIndex; i < end; i++)
            {
                if (vers[i] == 0x20)
                {
                    spaceIndex = i;
                    break;
                }
            }

            // increase the major version
            USHORT newMajor = origMajor + 1;

            char major[10];

            sprintf(major, "%d", newMajor);

            size_t majorLen = strlen(major);

            BYTE DotZero[] = { 0x2E, 0x30, 0x30 };

            // new string = new major version + .00 + anything after the minor version
            newVersionLen = (USHORT)(sizeof(verString) + majorLen*sizeof(BYTE) + sizeof(DotZero));

            if (spaceIndex != 0)
                newVersionLen += (USHORT)(origVersionLen - spaceIndex);

            if (newVersionLen == 0)
                return LF_BAD_FORMAT;

            BYTE* newVersion = (BYTE*)malloc(newVersionLen);
            if (newVersion == NULL)
                return LF_OUT_OF_MEMORY;

            memcpy(newVersion, verString, sizeof(verString));
            memcpy(newVersion + sizeof(verString), major, majorLen);
            memcpy(newVersion + sizeof(verString) + majorLen, DotZero, sizeof(DotZero));
            if (spaceIndex != 0)
                memcpy(newVersion + sizeof(verString) + majorLen + sizeof(DotZero),
                &origVersion[spaceIndex], (origVersionLen - spaceIndex));

            error = NAME_setMacNameString(lfFont, NAME_VERSION_NAME_TABLE, newVersion, newVersionLen);

            free(newVersion);
        }
    }

    if (versionOK == FALSE)
    {
        // just put 'Version 2.00'  (assuming original was meant to be 1.0)
        BYTE twoDotZero[] = { 0x32, 0x2E, 0x30, 0x30 };

        newVersionLen = sizeof(verString) + sizeof(twoDotZero);

        BYTE* newVersion = (BYTE*)malloc(newVersionLen);
        if (newVersion == NULL)
        {
            return LF_OUT_OF_MEMORY;
        }

        memcpy(newVersion, verString, sizeof(verString));
        memcpy(newVersion + sizeof(verString), twoDotZero, sizeof(twoDotZero));

        error = NAME_setMacNameString(lfFont, NAME_VERSION_NAME_TABLE, newVersion, newVersionLen);

        free(newVersion);
    }

    return error;
}

static LF_ERROR updateNameTable(LF_FONT* lfFont)
{
    LF_ERROR error = updateWindowsNames(lfFont);

    if (error == LF_ERROR_OK)
        error = updateMacNames(lfFont);

    return error;
}

static LF_ERROR checkInputPaths(const LF_VECTOR* inputFonts, const char* outputPath)
{
    char* inbuf = (char*)malloc(512);
    if (NULL == inbuf)
        return LF_OUT_OF_MEMORY;
    char* outbuf = (char*)malloc(512);
    if (NULL == outbuf)
    {
        free(inbuf);
        return LF_OUT_OF_MEMORY;
    }

    for (size_t i = 0; i < inputFonts->count; i++)
    {
        char* inputName = (char*)vector_at((LF_VECTOR*)inputFonts, i);
        size_t inLen = strlen(inputName);

        memcpy(inbuf, inputName, inLen);
        inbuf[inLen] = 0;

        for (size_t j = 0; j < inLen; j++)
        {
            if (inbuf[j] == '\\')
                inbuf[j] = '/';
        }

        char *p = inbuf;

        while (*p)
        {
            *p = (char)tolower(*p);
            p++;
        }

        char* index = strrchr(inbuf, '/');

        if (index == NULL)
        {
            if (strlen(outputPath) == 0)
            {
                free(inbuf);
                free(outbuf);
                return LF_HARMONIZE_PATHS; // both are working folder
            }
        }
        else
        {
            size_t outLen = strlen(outputPath);
            if (outLen == (size_t)(index - inbuf))
            {
                memcpy(outbuf, outputPath, outLen);
                outbuf[outLen] = 0;

                for (size_t j = 0; j < outLen; j++)
                {
                    if (outbuf[j] == '\\')
                        outbuf[j] = '/';
                }

                p = outbuf;

                while (*p)
                {
                    *p = (char)tolower(*p);
                    p++;
                }

                if (0 == strncmp(inbuf, outbuf, index - inbuf))
                {
                    free(inbuf);
                    free(outbuf);
                    return LF_HARMONIZE_PATHS;
                }
            }
        }
    }

    free(inbuf);
    free(outbuf);

    return LF_ERROR_OK;
}

static LF_ERROR checkUnitsPerEm(LF_VECTOR* fonts, FILE* logFile)
{
    if (logFile)
        fprintf(logFile, "Checking UnitsPerEm...");

    USHORT firstUPM = HEAD_getUnitsPerEM((LF_FONT*)vector_at(fonts, 0));

    size_t i, numFonts = vector_size(fonts);

    for (i = 1; i < numFonts; i++)
    {
        USHORT curUPM = HEAD_getUnitsPerEM((LF_FONT*)vector_at(fonts, i));

        if (curUPM != firstUPM)
        {
            if (logFile)
            {
                if (1 == i)
                    fprintf(logFile, "ERROR: the 2nd font has a different UnitsPerEm than the 1st font\n");
                else if (2 == i)
                    fprintf(logFile, "ERROR: the 3rd font has a different UnitsPerEm than the 1st font\n");
                else
                    fprintf(logFile, "ERROR: the %zdth font has a different UnitsPerEm than the 1st font\n", i);
            }

            return LF_HARMONIZE_UPM;
        }
    }

    if (logFile)
        fprintf(logFile, "OK\n");

    return LF_ERROR_OK;
}

static LF_ERROR checkGlyphOrder(LF_VECTOR* fonts, FILE* logFile)
{
    if (logFile)
        fprintf(logFile, "Checking glyph ordering...");

    size_t numFonts = vector_size(fonts);

    for (ULONG i = 0; i < 65536; i++)
    {
        GlyphID gid;
        CMAP_getGlyphID((LF_FONT*)vector_at(fonts, 0), i, &gid);

        if (gid != 0)
        {
            for (size_t j = 1; j < numFonts; j++)
            {
                GlyphID gid2;

                CMAP_getGlyphID((LF_FONT*)vector_at(fonts, 0), i, &gid2);

                if (gid2 != gid)
                {
                    if (logFile)
                        fprintf(logFile, "ERROR:The fonts do not all have the same glyph ordering, so they cannot be harmonized.\n");
                    return LF_HARMONIZE_CMAP;
                }
            }
        }
    }

    if (logFile)
        fprintf(logFile, "OK\n");

    return LF_ERROR_OK;
}

static LF_ERROR checkGlyphCounts(const LF_VECTOR* inputFonts, LF_VECTOR* fonts, FILE* logFile)
{
    boolean allSame = TRUE;

    LF_FONT* curFont = vector_at(fonts, 0);
    USHORT numGlyphs = MAXP_getNumGlyphs(curFont);

    if (logFile)
        fprintf(logFile, "Checking glyph counts...");

    for (size_t i = 1; i < fonts->count; i++)
    {
        curFont = vector_at(fonts, i);

        USHORT curNumGlyphs = MAXP_getNumGlyphs(curFont);

        if (curNumGlyphs != numGlyphs)
            allSame = FALSE;
    }

    if (logFile)
    {
        if (TRUE == allSame)
        {
            fprintf(logFile, "OK\n");
        }
        else
        {
            for (size_t i = 0; i < fonts->count; i++)
            {
                char* fullPath = (char*)vector_at((LF_VECTOR*)inputFonts, i);
                if (fullPath != NULL)
                {
                    char* fnamePtr = strrchr(fullPath, '/');
                    if (fnamePtr != NULL)
                        fnamePtr++;
                    curFont = vector_at(fonts, i);
                    fprintf(logFile, "%s : %d\n", fnamePtr, MAXP_getNumGlyphs(curFont));
                }
            }

            fprintf(logFile, "ERROR:The fonts do not all have the same number of glyphs, so they cannot be harmonized.\n");
        }
    }

    return ((allSame == TRUE) ? LF_ERROR_OK : LF_HARMONIZE_NUM_GLYPHS);
}

#if 0
// checkContourCountsIgnoreAnchorPts is currently used instead of this
static LF_ERROR checkContourCounts(LF_VECTOR* fonts, boolean force, FILE* logFile, LF_FONT_TYPE type)
{
    if (logFile)
        fprintf(logFile, "Checking contour counts...");

    LF_FONT* firstFont = vector_at(fonts, 0);
    USHORT i, numGlyphs = MAXP_getNumGlyphs(firstFont);
    size_t numFonts = fonts->count;
    LF_ERROR error = LF_ERROR_OK;
    boolean firstWarning = TRUE;

    for (i = 0; (i < numGlyphs) && (error == LF_ERROR_OK); i++)
    {
        // Get num contours for glyph in first font
        SHORT firstFontNC;

        if (eLF_CFF_FONT == type)
            error = CFF__getNumContours(firstFont, i, &firstFontNC);
        else
            error = GLYF_getNumContours(firstFont, i, &firstFontNC);
        if (error != LF_ERROR_OK)
            break;

        // see if the other fonts have the same count
        for (size_t j = 1; (j < numFonts) && (error == LF_ERROR_OK); j++)
        {
            LF_FONT* curFont = vector_at(fonts, j);

            SHORT curNC;

            if (eLF_CFF_FONT == type)
                error = CFF__getNumContours(curFont, i, &curNC);
            else
                error = GLYF_getNumContours(curFont, i, &curNC);
            if (error != LF_ERROR_OK)
                break;

            if (curNC != firstFontNC)
            {
                if ((force == FALSE) || (eLF_CFF_FONT == type))
                {
                    // for now at least, if the inputs are cff, it is required that the contour counts are the same
                    error = LF_HARMONIZE_CONTOURS;
                }
                else
                {
                    if (logFile)
                    {
                        if (firstWarning == TRUE)
                        {
                            fprintf(logFile, "\n");
                            firstWarning = FALSE;
                        }
                        fprintf(logFile, "WARNING: Glyph index %d has mismatching contour counts ", i);
                         if (j == 1)
                             fprintf(logFile, "(%d in the first font, %d in the 2nd font)\n", firstFontNC, curNC);
                         else if (j == 2)
                             fprintf(logFile, "(%d in the first font, %d in the 3rd font)\n", firstFontNC, curNC);
                         else
                             fprintf(logFile, "(%d in the first font, %d in the %luth font)\n", firstFontNC, curNC, (unsigned long)(j+1));
                    }
                }
            }
        }
    }

    if (logFile)
    {
        if (error == LF_ERROR_OK)
            fprintf(logFile, "OK\n");
        else
            fprintf(logFile, "ERROR:Glyphs at index %d have different numbers of contours, so the fonts cannot be harmonized.\n", i);
    }

    return error;
}
#endif

static USHORT countAnchorPoints(LF_GLYPH* glyph)
{
    if (glyph->isComposite)
        return 0;

    USHORT numAPs = 0;

    LF_GLYPH_OUTLINE* go = &glyph->component.outline;

    USHORT nc = go->numContours;

    for (SHORT i = 0; i < nc; i++)
    {
        if (0 == i)
        {
            if (go->endPtsOfContours[i] == 0)
                numAPs++;
        }
        else
        {
            if (1 == go->endPtsOfContours[i] - go->endPtsOfContours[i-1])
                numAPs++;
        }
    }

    return numAPs;
}

static LF_ERROR checkContourCountsIgnoreAnchorPts(LF_VECTOR* fonts, boolean force, FILE* logFile, LF_FONT_TYPE type)
{
    if (logFile)
        fprintf(logFile, "Checking contour counts...");

    LF_FONT* firstFont = vector_at(fonts, 0);
    USHORT i, numGlyphs = MAXP_getNumGlyphs(firstFont);
    size_t numFonts = fonts->count;
    LF_ERROR error = LF_ERROR_OK;
    boolean firstWarning = TRUE;

    for (i = 0; (i < numGlyphs) && (error == LF_ERROR_OK); i++)
    {
        // Get num contours for glyph in first font
        SHORT firstFontNC;
        USHORT firstFontNumAP;      // number of anchor point (single point) contours in the glyph of the first font.

        LF_GLYPH* curGlyph;

        error = LF_getGlyph(firstFont, i, &curGlyph);

        if (LF_ERROR_OK == error)
        {
            firstFontNC = curGlyph->component.outline.numContours;
            firstFontNumAP = countAnchorPoints(curGlyph);

            LF_freeGlyph(curGlyph);

            // see if the other fonts have the same count
            for (size_t j = 1; (j < numFonts) && (error == LF_ERROR_OK); j++)
            {
                LF_FONT* curFont = vector_at(fonts, j);

                error = LF_getGlyph(curFont, i, &curGlyph);

                if (LF_ERROR_OK == error)
                {
                    SHORT curNC = curGlyph->component.outline.numContours;

                    if (curNC != firstFontNC)
                    {
                        USHORT curNumAP = countAnchorPoints(curGlyph);
                        USHORT firstNonAP = firstFontNC - firstFontNumAP;
                        USHORT curNonAP = curNC - curNumAP;

                        if (firstNonAP == curNonAP)
                        {
                            if (logFile)
                            {
                                if (firstWarning == TRUE)
                                {
                                    fprintf(logFile, "\n");
                                    firstWarning = FALSE;
                                }

                                fprintf(logFile, "INFO: Ignoring single point contour diffs at index %d\n", i);
                            }
                        }
                        else
                        {
                            if ((force == FALSE) || (eLF_CFF_FONT == type))
                            {
                                // for now at least, if the inputs are cff, it is required that the contour counts are the same
                                error = LF_HARMONIZE_CONTOURS;
                            }
                            else
                            {
                                if (logFile)
                                {
                                    if (firstWarning == TRUE)
                                    {
                                        fprintf(logFile, "\n");
                                        firstWarning = FALSE;
                                    }
                                    fprintf(logFile, "WARNING: Glyph index %d has mismatching contour counts ", i);
                                    if (j == 1)
                                        fprintf(logFile, "(%d in the first font, %d in the 2nd font)\n", firstFontNC, curNC);
                                    else if (j == 2)
                                        fprintf(logFile, "(%d in the first font, %d in the 3rd font)\n", firstFontNC, curNC);
                                    else
                                        fprintf(logFile, "(%d in the first font, %d in the %luth font)\n", firstFontNC, curNC, (unsigned long)(j + 1));
                                }
                            }
                        }
                    }

                    LF_freeGlyph(curGlyph);
                }
            }
        }
    }

    if (logFile)
    {
        if (error == LF_ERROR_OK)
            fprintf(logFile, "OK\n");
        else
            fprintf(logFile, "ERROR:Glyphs at index %d have different numbers of contours, so the fonts cannot be harmonized.\n", i);
    }

    return error;
}

static LF_ERROR checkComposites(LF_VECTOR* fonts, FILE* logFile, LF_FONT_TYPE type)
{
    if (logFile)
        fprintf(logFile, "Checking composite glyphs...");

    LF_FONT* firstFont = vector_at(fonts, 0);
    USHORT numGlyphs = MAXP_getNumGlyphs(firstFont);
    size_t numFonts = fonts->count;
    LF_ERROR error = LF_ERROR_OK;

    if (type == eLF_CFF_FONT)
    {
        if (logFile)
            fprintf(logFile, "Input fonts are CFF based, skipping composite checking.\n");

        return error;
    }

    for (USHORT i = 1; (i < numGlyphs) && (error == LF_ERROR_OK); i++)
    {
        // Get glyph from first font
        glyf firstFontGlyf;

        error = GLYF_getGlyph(firstFont, &firstFontGlyf, i);
        if (error != LF_ERROR_OK)
            break;

        // if it is a composite, then in all the other fonts it must also be a composite, and have the same components
        // if it is a simple glyph, then the glyph in all the other fonts must not be a composite

        for (size_t j = 1; (j < numFonts) && (error == LF_ERROR_OK); j++)
        {
            LF_FONT* curFont = vector_at(fonts, j);

            glyf curGlyf;

            error = GLYF_getGlyph(curFont, &curGlyf, i);
            if (error != LF_ERROR_OK)
            {
                GLYF_destroyGlyf(&firstFontGlyf);
                break;
            }

            if (firstFontGlyf.numberOfContours == -1)
            {
                if (curGlyf.numberOfContours != -1)
                {
                    error = LF_HARMONIZE_COMPOSITES;
                    break;
                }
                else
                {
                    // see if # of components is same
                    if (firstFontGlyf.glyf_data.composite.count != curGlyf.glyf_data.composite.count)
                    {
                        error = LF_HARMONIZE_COMPOSITES;
                        break;
                    }

                    size_t numComps = firstFontGlyf.glyf_data.composite.count;

                    for (size_t k = 0; k < numComps; k++)
                    {
                        composite_glyf* compFirst = (composite_glyf*)vector_at(&firstFontGlyf.glyf_data.composite, k);
                        composite_glyf* compCurr = (composite_glyf*)vector_at(&curGlyf.glyf_data.composite, k);

                        if (compFirst->glyphIndex != compCurr->glyphIndex)
                        {
                            error = LF_HARMONIZE_COMPOSITES;
                            break;
                        }
                    }
                }
            }
            else
            {
                if (curGlyf.numberOfContours == -1)
                {
                    error = LF_HARMONIZE_COMPOSITES;
                    break;
                }
            }

            GLYF_destroyGlyf(&curGlyf);
        }

        GLYF_destroyGlyf(&firstFontGlyf);
    }

    if (logFile)
    {
        if (error == LF_ERROR_OK)
            fprintf(logFile, "OK\n");
        else if (error == LF_HARMONIZE_COMPOSITES)
            fprintf(logFile, "ERROR:The composite glyphs in fonts do not all have the same components, so the fonts cannot be harmonized.\n");
        else
            fprintf(logFile, "ERROR:An error occurerd while checking the glyphs, so the fonts cannot be harmonized.\n");
    }

    return error;
}

#if 0
static LF_ERROR checkGlyphNames(LF_VECTOR* fonts, FILE* logFile)
{
    if (logFile)
        fprintf(logFile, "Checking glyph names...");

    size_t numFonts = fonts->count;

    // make sure they all have the same version
    ULONG firstVer = POST_getVersion((LF_FONT*)vector_at(fonts, 0));

    for (size_t i = 1; i < numFonts; i++)
    {
        ULONG curVer = POST_getVersion((LF_FONT*)vector_at(fonts, i));

        if (curVer != firstVer)
        {
            if (logFile)
                fprintf(logFile, "The fonts do not all have the same post table version, so the fonts cannot be harmonized.\n");
            return LF_HARMONIZE_POST_VERS;
        }
    }

    // if all version 3, then print warning to log
    if (firstVer == 0x00030000)
    {
        if (logFile)
            fprintf(logFile, "\n    The fonts have post table version 3, so the names will not be checked.\n");
        return LF_ERROR_OK;
    }

    // if all version 2, then check that the names are all the same in all the fonts
    else if (firstVer == 0x00020000)
    {
        USHORT numGlyphs = MAXP_getNumGlyphs((LF_FONT*)vector_at(fonts, 0));

        for (USHORT i = 0; i < numGlyphs; i++)
        {
            CHAR* firstName = POST_getGlyfNameFromIndex((LF_FONT*)vector_at(fonts, 0), i);

            for (size_t j = 1; j < numFonts; j++)
            {
                CHAR* curName = POST_getGlyfNameFromIndex((LF_FONT*)vector_at(fonts, j), i);

                if (((firstName == NULL) && (curName != NULL)) ||
                    ((firstName != NULL) && (curName == NULL)) ||
                    ((firstName != NULL) && (curName != NULL) && 
                      (strcmp((char*)firstName, (char*)curName) != 0)))
                {
                    if (!((strcmp((char*)firstName, (char*)"null") == 0) || (strcmp((char*)curName, (char*)"null") == 0)))
                    {
                        if (logFile)
                            fprintf(logFile, "The glyph names in the post tables of the fonts do not all match, so the fonts cannot be harmonized.\n");
                        return LF_HARMONIZE_POST_NAMES;
                    }
                }
            }
        }

        if (logFile)
            fprintf(logFile, "OK\n");
        return LF_ERROR_OK;
    }
    else
    {
        if (logFile)
            fprintf(logFile, "The fonts have an unsupported post table version, so the fonts cannot be harmonized.\n");
        return LF_HARMONIZE_POST_VERS;
    }
}
#endif

static char* createOutputName(const LF_VECTOR*inputFonts, const char* outputPath, LF_FONT_TYPE outputType, size_t index)
{
    char* inputName = (char*)vector_at((LF_VECTOR*)inputFonts, index);

    char* startOfBase = strrchr(inputName, '\\');

    if (startOfBase == NULL)
        startOfBase = strrchr(inputName, '/');

    if (startOfBase == NULL)
        startOfBase = inputName;
    else
        startOfBase++;

    char* startOfExtension = strrchr(startOfBase, '.');

    size_t lengthOfOutPath = strlen(outputPath);

    size_t lengthOfBase;
    if (startOfExtension != NULL)
        lengthOfBase = startOfExtension - startOfBase;
    else
        lengthOfBase = strlen(startOfBase);

    size_t lengthOfOutName = lengthOfOutPath + lengthOfBase + 4;

    if (!((outputPath[lengthOfOutPath - 1] == '/') || (outputPath[lengthOfOutPath - 1] == '\\')))
        lengthOfOutName++;

    char* outName = (char*)calloc(lengthOfOutName+1, sizeof(char));
    if (outName != NULL)
    {
        strncpy(outName, outputPath, lengthOfOutPath);
        outName[lengthOfOutPath] = 0;

        if (!((outName[lengthOfOutPath - 1] == '/') || (outName[lengthOfOutPath - 1] == '\\')))
            strncat(outName, "/", 1);

        strncat(outName, startOfBase, lengthOfBase);

        if (eLF_CFF_FONT == outputType)
            strncat(outName, ".otf", 4);
        else
            strncat(outName, ".ttf", 4);
        outName[lengthOfOutName] = 0;
    }

    return outName;
}

static void verifyHarmonization(USHORT index, Glyph* glyphArray, size_t numFonts, USHORT* numPointMismatch, FILE* logFile)
{
    if (logFile == NULL)
        return;

    boolean mismatch = FALSE;

    if (glyphArray[0].glyphOutline.numberOfComponents > 1)
    {
        fprintf(logFile, "WARNING: Glyph %d is unexpectedly a composite glyph.\n", index);
        return;
    }
    if (glyphArray[0].glyphOutline.numberOfComponents < 1)
    {
        fprintf(logFile, "WARNING: Glyph %d is unexpectedly an empty glyph.\n", index);
        return;
    }

    // See if all the glyphs have the same number of points
    unsigned short firstNumPoints = glyphArray[0].glyphOutline.component.outline.np;

    for (size_t i = 1; i < numFonts; i++)
    {
        unsigned short curNumPoints = glyphArray[i].glyphOutline.component.outline.np;

        if (firstNumPoints != curNumPoints)
        {
            fprintf(logFile, "WARNING: Resulting glyphs at index %d do not all have the same number of points ", index);
            if (i == 1)
                fprintf(logFile, "(first font has %d, 2nd font has %d)\n", firstNumPoints, curNumPoints);
            else if (i == 2)
                fprintf(logFile, "(first font has %d, 3rd font has %d)\n", firstNumPoints, curNumPoints);
            else
                fprintf(logFile, "(first font has %d, %uth font has %d)\n", firstNumPoints, (unsigned int)(i+1), curNumPoints);

            mismatch = TRUE;
        }
    }

    if (TRUE == mismatch)
        (*numPointMismatch)++;

    // See if all the glyphs have the same number of contours
    unsigned short firstNumContours = glyphArray[0].glyphOutline.component.outline.nc;

    if (firstNumContours == 0)
        fprintf(logFile, "WARNING: Glyph at index %d of first font has no contours!\n", index);

    for (size_t i = 1; i < numFonts; i++)
    {
        unsigned short curNumContours = glyphArray[i].glyphOutline.component.outline.nc;

        if (curNumContours == 0)
        {
            if (i == 1)
                fprintf(logFile, "WARNING: Glyph at index %d of 2nd font has no contours!\n", index);
            else if (i == 2)
                fprintf(logFile, "WARNING: Glyph at index %d of 3rd font has no contours!\n", index);
            else
                fprintf(logFile, "WARNING: Glyph at index %d of %uth font has no contours!\n", index, (unsigned int)(i + 1));
        }

        if (firstNumContours != curNumContours)
        {
            fprintf(logFile, "WARNING: Resulting glyphs at index %d do not all have the same number of contours ", index);
            if (i == 1)
                fprintf(logFile, "(first font has %d, 2nd font %d)\n", firstNumContours, curNumContours);
            else if (i == 2)
                fprintf(logFile, "(first font has %d, 3rd font has %d)\n", firstNumContours, curNumContours);
            else
                fprintf(logFile, "(first font has %d, %uth font has %d)\n", firstNumContours, (unsigned int)(i+1), curNumContours);
        }
    }
}

static void destroyFontArray(LF_VECTOR* fonts)
{
    for (size_t j = 0; j < fonts->count; j++)
    {
        LF_FONT* f = (LF_FONT*)vector_at(fonts, j);

        LF_destroyFont(f);
    }

    vector_free(fonts);
}

static LF_ERROR createFontArray(const LF_VECTOR* inputFonts, LF_VECTOR* lfFonts, FILE* logFile)
{
    size_t numFonts = inputFonts->count;

    LF_ERROR error = vector_init(lfFonts, numFonts, 1);
    if (error != LF_ERROR_OK)
        return error;

    for (size_t i = 0; (i < numFonts) && (error == LF_ERROR_OK); i++)
    {
        // Create font.
        LF_FONT* font = LF_createFont();
        if (font == NULL)
            error = LF_OUT_OF_MEMORY;

        if (error == LF_ERROR_OK)
        {
            // Add to list.
            error = vector_push_back(lfFonts, (void*)font);

            if (error == LF_ERROR_OK)
            {
                // Read it in.
                error = LF_readFontFromFile(font, (char*)vector_at((LF_VECTOR*)inputFonts, i), LF_KEEP_ALL_TABLES);
                if (error != LF_ERROR_OK)
                {
                    if (logFile)
                        fprintf(logFile, "Unable to read %s, exiting.\n", (char*)vector_at((LF_VECTOR*)inputFonts, i));
                }
                else
                {
                    // Unpack it.
                    error = SFNT_unpackTables(font);
                    if (error != LF_ERROR_OK)
                    {
                        if (logFile)
                            fprintf(logFile, "Unable to parse %s, exiting.\n", (char*)vector_at((LF_VECTOR*)inputFonts, i));
                    }
                }
            }
        }
    }

    if (error != LF_ERROR_OK)
        destroyFontArray(lfFonts);

    return error;
}

static LF_ERROR checkFontTypes(const LF_VECTOR* inputFonts, FILE* logFile, LF_FONT_TYPE* type)
{
    LF_FONT* firstFont = (LF_FONT*)vector_at(inputFonts, 0);
    LF_FONT_TYPE firstType;
    ULONG firstFlavor;

    *type = eLF_UNDETERMINED;

    LF_ERROR  error = LF_getFontInfo(firstFont, &firstType, &firstFlavor);

    if (error != LF_ERROR_OK)
    {
        if (logFile)
            fprintf(logFile, "ERROR: LF_getFontInfo failed.\n");
        return error;
    }

    size_t i, numFonts = vector_size(inputFonts);

    for (i = 1; i < numFonts; i++)
    {
        LF_FONT_TYPE curType;
        ULONG curFlavor;

        error = LF_getFontInfo(firstFont, &curType, &curFlavor);

        if (error != LF_ERROR_OK)
        {
            if (logFile)
                fprintf(logFile, "ERROR: LF_getFontInfo failed.\n");
            return error;
        }

        if ((curType != firstType) || (curFlavor != firstFlavor))
        {
            if (logFile)
            {
                char zzz[5];

                if (i == 1)
                    strncpy(zzz, "2nd", 4);
                else if (i == 2)
                    strncpy(zzz, "3rd", 4);
                else
                    sprintf(zzz, "%dth", (int)(i+1));
                zzz[4] = 0;

                fprintf(logFile, "The %s font's type is different from that of the first font.\n", zzz);
            }
            return LF_HARMONIZE_FONT_TYPES;
        }
    }

    *type = firstType;

    if (firstFlavor == SIG_CFF)
        *type = eLF_CFF_FONT;       // in case woff/2 are input

    return error;
}

static LF_ERROR checkInputFonts(const LF_VECTOR* inputFonts, LF_VECTOR* lfFonts, boolean force, FILE* logFile, LF_FONT_TYPE* type)
{
   // note: type will be set to eLF_CFF_FONT for OTFs or woff/woff2 with cff table, the original font type otherwise
    *type = eLF_UNDETERMINED;

    // Check that all of the fonts have the same type
    LF_ERROR error = checkFontTypes(lfFonts, logFile, type);
    if (error == LF_ERROR_OK)
    {
        // Check that all the fonts have the same # glyphs
        error = checkGlyphCounts(inputFonts, lfFonts, logFile);
        if (error == LF_ERROR_OK)
        {
            // Check that all the fonts have the same UnitsPerEm
            error = checkUnitsPerEm(lfFonts, logFile);
            if (error == LF_ERROR_OK)
            {
                // Check that glyph order is the same
                error = checkGlyphOrder(lfFonts, logFile);
                if (error == LF_ERROR_OK)
                {
                    // Check composites
                    error = checkComposites(lfFonts, logFile, *type);
                    if (error == LF_ERROR_OK)
                    {
                        // Check that number of contours is the same
                        //error = checkContourCounts(lfFonts, force, logFile, *type);
                        error = checkContourCountsIgnoreAnchorPts(lfFonts, force, logFile, *type);

// Checking of glyph names disabled since there is no standard for glyph names
#if 0
                        if (error == LF_ERROR_OK)
                        {
                            // Check glyph names
                            error = checkGlyphNames(lfFonts, logFile);
                        }
#endif
                    }
                }
            }
        }
    }

    return error;
}

static void checkProgress(USHORT current, USHORT total, harmonizeOptions* options)
{
    if (options->prog != NULL)
    {
        const int startPct = 5;
        const int endPct = 90;

        USHORT percent = (USHORT)(startPct + (USHORT)(((float)current / total) * (endPct-startPct)));

        if (total < 1000)
        {
            if ((percent > startPct) && (percent % 10 == 0))
                options->prog->progressCB(options->prog->userState, percent);
        }
        else
        {
            if ((percent > startPct) && (percent % 2 == 0))
                options->prog->progressCB(options->prog->userState, percent);
        }
    }
}

#define reportProgress(x)     if (options->prog != NULL) { options->prog->progressCB(options->prog->userState, x); } (void)x



typedef struct
{
    size_t numFonts;
    Glyph* glyphArray;                      // Array of numFonts Glyphs
    LF_VECTOR* pointsArray;                 // Array to hold points data read from original glyfs
    glyfBuildScratchSpace scratch;          // Scratch space for when building new glyfs
} harmonizeResources;


static void clearGlyphs(harmonizeResources* resources)
{
    for (USHORT i = 0; i < resources->numFonts; i++)
        conversion_freeGlyphOutline(&resources->glyphArray[i]);

    memset(resources->glyphArray, 0, sizeof(Glyph) * resources->numFonts);
}

static void destroyResources(harmonizeResources* resources)
{
    vector_free(resources->pointsArray);
    free(resources->pointsArray);
    free(resources->glyphArray);
    conversion_freeScratchSpace(&resources->scratch);
}

static LF_ERROR allocateResources(harmonizeResources* resources, LF_VECTOR* lfFonts, FILE* logFile)
{
    USHORT maxMaxPoints = 0;
    USHORT maxMaxContours = 0;

    size_t numFonts = lfFonts->count;
    resources->numFonts = numFonts;

    // Allocate space
    resources->glyphArray = (Glyph*)malloc(sizeof(Glyph)*numFonts);
    if (resources->glyphArray == NULL)
    {
        writeLog("ERROR:Allocation failure.\n");
        return LF_OUT_OF_MEMORY;
    }

    LF_FONT* curFont;

    // Find the maximum of the maxPoints in all the fonts and use that as a starting
    // point for the memory we need
    for (size_t i = 0; i < numFonts; i++)
    {
        curFont = (LF_FONT*)vector_at(lfFonts, i);

        USHORT maxPoints = MAXP_getMaxPoints(curFont);

        if (maxPoints > maxMaxPoints)
            maxMaxPoints = maxPoints;

        USHORT maxContours = MAXP_getMaxContours(curFont);

        if (maxContours > maxMaxContours)
            maxMaxContours = maxContours;
    }

    resources->pointsArray = vector_create(maxMaxPoints * 4, 4); // each point consumes 4 entries

    if (resources->pointsArray == NULL)
    {
        writeLog("ERROR:Allocation failure.\n");
        free(resources->glyphArray);
        return LF_OUT_OF_MEMORY;
    }

    // Allocate temp space for the new compressed glyf data, start with enough for the max points plus
    // max contours (to account for closing points added to contours). This still may be
    // (probably will be) reallocated below since the harmonize algorithm will add points.

    if (0 != conversion_allocateScratchSpace(&resources->scratch, maxMaxPoints + maxMaxContours))
    {
        writeLog("ERROR:Allocation failure.\n");
        free(resources->pointsArray);
        free(resources->glyphArray);
        return LF_OUT_OF_MEMORY;
    }

    return LF_ERROR_OK;
}

static LF_ERROR addGlyfTables(LF_VECTOR* lfFonts, FILE* logFile)
{
    size_t i, numFonts = vector_size(lfFonts);

    for (i = 0; i < numFonts; i++)
    {
        LF_FONT* curFont = (LF_FONT*)vector_at(lfFonts, i);

        LF_ERROR error = SFNT_insertGLYFAndLOCA(curFont, TRUE);
        if (error != LF_ERROR_OK)
        {
            writeLog("ERROR: failed creating glyf table for font at index %zu.", i);

            return error;
        }
    }

    return LF_ERROR_OK;
}

static LF_ERROR addCFFTables(LF_VECTOR* lfFonts, FILE* logFile)
{
    size_t i, numFonts = vector_size(lfFonts);

    for (i = 0; i < numFonts; i++)
    {
        LF_FONT* curFont = (LF_FONT*)vector_at(lfFonts, i);

        LF_ERROR error = SFNT_insertCFF(curFont);
        if (error != LF_ERROR_OK)
        {
            writeLog("ERROR: failed creating cff table for font at index %zu.", i);

            return error;
        }
    }

    return LF_ERROR_OK;
}

static LF_ERROR checkGlyphsTables(LF_VECTOR* inputFonts, FILE* logFile, LF_FONT_TYPE inputType, LF_FONT_TYPE outputType)
{
    LF_ERROR error = LF_ERROR_OK;

    if ((eLF_CFF_FONT == inputType) && (eLF_SFNT_FONT == outputType))
    {
        // Create new glyf tables for the fonts (populated with empty glyphs), and add them to the fonts
        error = addGlyfTables(inputFonts, logFile);
    }
    else if ((eLF_SFNT_FONT == inputType) && (eLF_CFF_FONT == outputType))
    {
        // Create new cff tables for the fonts (populated with empty glyphs), and add them to the fonts
        error = addCFFTables(inputFonts, logFile);
    }

    return error;
}

static LF_ERROR writeFonts(const LF_VECTOR* inputFonts, const char* outputPath, LF_FONT_TYPE outputType, LF_VECTOR* lfFonts, FILE* logFile)
{
    LF_WRITE_PARAMS writeParams;
    LF_defaultWriteParams(&writeParams);
    writeParams.postTableVersion = 0;   // Keep original version

    LF_ERROR error = LF_ERROR_OK;

    for (size_t i = 0; ((i < inputFonts->count) && (error == LF_ERROR_OK)); i++)
    {
        char* outName = createOutputName(inputFonts, outputPath, outputType, i);
        if (outName == NULL)
        {
            error = LF_OUT_OF_MEMORY;
            writeLog("ERROR:Allocation failure.\n");
        }
        else
        {
            error = LF_writeFontToFile((LF_FONT*)vector_at(lfFonts, i), outName, outputType, &writeParams);
            if (error != LF_ERROR_OK)
                writeLog("ERROR:Failed to write %s.\n", outName);
            free(outName);
        }
    }

    return error;
}

static LF_ERROR updateNameTables(LF_VECTOR* lfFonts, FILE* logFile)
{
    // loop over num Fonts and update name table
    for (size_t i = 0; i < lfFonts->count; i++)
    {
        // update name table
        LF_ERROR error = updateNameTable((LF_FONT*)vector_at(lfFonts, i));

        if (error != LF_ERROR_OK)
        {
            writeLog("ERROR:Failed to update name table for font at index %u.\n", (unsigned int)i);
            return error;
        }
    }

    return LF_ERROR_OK;
}

static LF_ERROR updateHeadTable(LF_FONT* font)
{
    // update the fontRevision
    FIXED revision;

    LF_ERROR error = HEAD_getFontRevision(font, &revision);

    if (error == LF_ERROR_OK)
    {
        USHORT majorVersion = (USHORT)(revision >> 16);

        majorVersion++;

        revision = majorVersion << 16;

        error = HEAD_setFontRevision(font, revision);
    }

#ifdef TEMPORARILY_DISABLED
    // update the modified date
    if (error == LF_ERROR_OK)
    {
        time_t seconds;

        time(&seconds);

        // add in difference between 1970 and 1904
        seconds += 0x7c0f4700 + 0x151800;

        LONGDATETIME modified =   (seconds >> 56)                | (((seconds >> 48) & 0xFF) <<  8) |
                                (((seconds >> 40) & 0xFF) << 16) | (((seconds >> 32) & 0xFF) << 24) |
                                (((seconds >> 24) & 0xFF) << 32) | (((seconds >> 16) & 0xFF) << 40) |
                                (((seconds >>  8) & 0xFF) << 48) | (((seconds >>  0) & 0xFF) << 56);

        error = HEAD_setModified(font, modified);
    }
#endif

    return error;
}

static LF_ERROR updateHeadTables(LF_VECTOR* lfFonts, FILE* logFile)
{
    // loop over num Fonts and update head table
    for (size_t i = 0; i < lfFonts->count; i++)
    {
        // update name table
        LF_ERROR error = updateHeadTable((LF_FONT*)vector_at(lfFonts, i));

        if (error != LF_ERROR_OK)
        {
            writeLog("ERROR:Failed to update head table for font at index %u.\n", (unsigned int)i);
            return error;
        }
    }

    return LF_ERROR_OK;
}

static LF_ERROR updateOtherTables(LF_VECTOR* lfFonts, LF_FONT_TYPE type, FILE* logFile)
{
    // loop over num fonts and update tables which could be affected by the changing glyf table
    for (size_t i = 0; i < lfFonts->count; i++)
    {
        LF_FONT* curFont = (LF_FONT*)vector_at(lfFonts, i);

        maxp_table* table = (maxp_table*)map_at(&curFont->table_map, (void*)TAG_MAXP);
        if (table == NULL)
            return LF_TABLE_MISSING;

        LF_ERROR error;

        if (type != eLF_CFF_FONT)
        {
            error = GLYF_getMAXPInfo(curFont, table, TRUE);
            if (error != LF_ERROR_OK)
                return error;
        }

        boolean hasVHEA, hasVMTX;

        LF_hasTable(curFont, TAG_VHEA, &hasVHEA);
        LF_hasTable(curFont, TAG_VMTX, &hasVMTX);

        if (hasVHEA && hasVMTX)
        {
            VHEA_setAdvanceHeightMax(curFont, VMTX_getAdvanceHeightMax(curFont));
            VHEA_setNumVMetrics(curFont, VMTX_getNumVMetrics(curFont));
            VHEA_setTopSidebearingMin(curFont, VMTX_getMinTopSidebearing(curFont));
            VHEA_setVertTypoLineGap(curFont, 0);
        }

        SHORT xMin, yMin, xMax, yMax;

        if (type == eLF_CFF_FONT)
            error = CFF__getBoundingBox(curFont, &xMin, &yMin, &xMax, &yMax);
        else
            error = GLYF_getBoundingBox(curFont, &xMin, &yMin, &xMax, &yMax);
        if (error != LF_ERROR_OK)
            return error;

        // Update hmtx side bearings and get min values
        FWORD minlsb, minrsb, maxadvance;
        error = HMTX_updateSidebearings(curFont, curFont->fontType, &minlsb, &minrsb, &maxadvance);
        if (error != LF_ERROR_OK)
            return error;

        HEAD_setBoundingBox(curFont, xMin, yMin, xMax, yMax);
        HHEA_setXMaxExtent(curFont, xMax);
        HHEA_setLeftSidebearingMin(curFont, minlsb);
        HHEA_setRightSidebearingMin(curFont, minrsb);
        HHEA_setAdvanceWidthMax(curFont, maxadvance);
        HHEA_setNumHMetrics(curFont, HMTX_getNumHMetrics(curFont));

        error = SFNT_removeHints(curFont);
        if (error != LF_ERROR_OK)
            writeLog("WARNING: Failed to remove hints from font at index %u\n", (unsigned int)i);

        SFNT_removeTable(curFont, TAG_DSIG);
        SFNT_removeTable(curFont, TAG_LTSH);

        USHORT os2Version;
        OS2_getVersion(curFont, &os2Version);
        if (os2Version < 3)
            OS2_upgradeTable(curFont);
        else
        {
            OS2_updateHeights(curFont);
            //OS2_updateMaxContent(curFont);
        }
        OS2_setAvgCharWidth(curFont, HMTX_getAdvanceWidthAvg(curFont));
    }

    return LF_ERROR_OK;
}

static LF_ERROR replaceGlyphsAtIndex(USHORT index, harmonizeResources* glyphData, LF_FONT_TYPE outputType, LF_VECTOR* lfFonts, FILE* logFile)
{
    // replace new glyph in glyf table of each font
    for (size_t j = 0; j < lfFonts->count; j++)
    {
        LF_FONT* curFont = (LF_FONT*)vector_at(lfFonts, j);

        if (eLF_SFNT_FONT == outputType)
        {
            glyf curGlyf;
            memset(&curGlyf, 0, sizeof(glyf));

            // see if we have enough scratch space for the new glyf data
            if (glyphData->glyphArray[j].glyphOutline.component.outline.np > glyphData->scratch.allocated)
            {
                size_t newSize = glyphData->scratch.allocated;
                while (newSize < glyphData->glyphArray[j].glyphOutline.component.outline.np)
                    newSize += 256;
                if (0 != conversion_reallocateScratchSpace(&glyphData->scratch, newSize))
                {
                    writeLog("ERROR:Allocation failure.\n");
                    return LF_OUT_OF_MEMORY;
                }
            }

            // create glyf header and data from Glyph
            LF_ERROR error = conversion_convertGlyphToCompressedGlyf(&glyphData->glyphArray[j], &glyphData->scratch, &curGlyf);
            if (error != LF_ERROR_OK)
            {
                writeLog("ERROR:Failed creating new glyf (index %u).\n", index);
                return error;
            }

            // update glyf table
            error = GLYF_replaceGlyph(curFont, index, &curGlyf);
            if (error != LF_ERROR_OK)
            {
                writeLog("ERROR:Failed replacing new glyf (index %u).\n", index);
                return error;
            }

            free(curGlyf.glyfBlock);
            //conversion_freeGlyphOutline(&glyphData->glyphArray[j]);
        }
        else
        {
            cffAnalyzedCharstring* newCS;

            // Create an cffAnalyzedCharstring from the (cubic) Glyph
            LF_ERROR error = conversion_createCharstring(curFont, index, &glyphData->glyphArray[j], &newCS);
            if (error != LF_ERROR_OK)
            {
                writeLog("ERROR:Failed creating new charstring (index %u).\n", index);
                return error;
            }

            // update cff table
            error = CFF__replaceCharstring(curFont, index, newCS);
            if (error != LF_ERROR_OK)
            {
                writeLog("ERROR:Failed replacing new charstring (index %u).\n", index);
                return error;
            }
        }
    }

    return LF_ERROR_OK;
}

static LF_ERROR needsHarmonization(LF_FONT_TYPE type, GlyphID index, LF_VECTOR* lfFonts, boolean* needToHarmonize)
{
    LF_ERROR error;
    LF_FONT* firstFont = (LF_FONT*)vector_at(lfFonts, 0);
    SHORT numContours;

    *needToHarmonize = FALSE;

    if (type == eLF_CFF_FONT)
        error = CFF__getNumContours(firstFont, index, &numContours);
    else
        error = GLYF_getNumContours(firstFont, index, &numContours);

    if (error != LF_ERROR_OK)
        return error;

    *needToHarmonize = ((numContours == -1) || (numContours == 0)) ? FALSE : TRUE;

    return error;
}

static LF_ERROR retrieveGlyphsAtIndex(LF_FONT_TYPE type, GlyphID index, harmonizeResources* glyphData, LF_VECTOR* lfFonts, FILE* logFile)
{
    LF_ERROR error;

    // loop over fonts, get the glyph at the current index from each font,
    // convert it to a Glyph, and put it into glyphArray

    for (size_t j = 0; j < lfFonts->count; j++)
    {
        LF_FONT* curFont = (LF_FONT*)vector_at(lfFonts, j);

        memset(&glyphData->glyphArray[j], 0, sizeof(Glyph));

        conversion_setGlyphOutlineParams(&(glyphData->glyphArray)[j].glyphOutline, index);

        if (eLF_CFF_FONT == type)
        {
            cff_table* cffTable = (cff_table*)map_at(&curFont->table_map, (void*)TAG_CFF);
            if (cffTable == NULL)
                return LF_TABLE_MISSING;

            (glyphData->glyphArray)[j].glyphType = eGlyph_CFF;

            error = conversion_getCFFGlyph(cffTable, index, &(glyphData->glyphArray)[j]);
            if (error != LF_ERROR_OK)
            {
                writeLog("ERROR:Failed retrieving glyph %d from font at index %u.\n", index, (unsigned int)j);
                return error;
            }
        }
        else
        {
            glyf curGlyf;
            memset(&curGlyf, 0, sizeof(glyf));

            error = GLYF_getGlyph(curFont, &curGlyf, index);
            if (error != LF_ERROR_OK)
            {
                writeLog("ERROR:Failed retrieving glyph %d from font at index %u.\n", index, (unsigned int)j);
                return error;
            }

            error = GLYF_getGlyfPoints(curFont, &curGlyf, glyphData->pointsArray);
            if (error != LF_ERROR_OK)
            {
                GLYF_destroyGlyf(&curGlyf);
                writeLog("ERROR:Failed retrieving glyph %d from font at index %u.\n", index, (unsigned int)j);
                return error;
            }

            (glyphData->glyphArray)[j].glyphType = eGlyph_TTF;

            error = conversion_addPointsToGlyphOutlineV2(glyphData->pointsArray, &(glyphData->glyphArray[j]).glyphOutline);
            if (error != LF_ERROR_OK)
            {
                GLYF_destroyGlyf(&curGlyf);
                writeLog("ERROR:Failed retrieving glyph.\n");
                return error;
            }

            vector_clear(glyphData->pointsArray);
            GLYF_destroyGlyf(&curGlyf);
        }

        conversion_removeSinglePointContours(&(glyphData->glyphArray[j]).glyphOutline);
    }

    return LF_ERROR_OK;
}

#if 0
// checkContourCountsAtIndexIgnoreAnchorPts is currently used instead of this
static LF_ERROR checkContourCountsAtIndex(GlyphID index, LF_VECTOR* lfFonts, boolean* uniformContourCount)
{
    // See if all the glyphs at the given index have the same contour count
    SHORT firstFontNumContours;

    LF_ERROR error = GLYF_getNumContours((LF_FONT*)vector_at(lfFonts, 0), index, &firstFontNumContours);
    if (error != LF_ERROR_OK)
        return error;

    *uniformContourCount = TRUE;

    for (size_t j = 1; j < lfFonts->count; j++)
    {
        SHORT curNumContours;

        error = GLYF_getNumContours(vector_at(lfFonts, j), index, &curNumContours);
        if (error != LF_ERROR_OK)
            return error;

        if (curNumContours != firstFontNumContours)
        {
            *uniformContourCount = FALSE;
            break;
        }
    }

    return LF_ERROR_OK;
}
#endif

static LF_ERROR checkContourCountsAtIndexIgnoreAnchorPts(GlyphID index, LF_VECTOR* lfFonts, boolean* uniformContourCount)
{
    // See if all the glyphs at the given index have the same contour count
    *uniformContourCount = TRUE;


    LF_FONT* curFont = vector_at(lfFonts, 0);
    size_t numFonts = lfFonts->count;

    SHORT firstFontNC;
    USHORT firstFontNumAP;      // number of anchor point (single point) contours in the glyph of the first font.

    LF_GLYPH* curGlyph;

    LF_ERROR error = LF_getGlyph(curFont, index, &curGlyph);

    if (LF_ERROR_OK == error)
    {
        firstFontNC = curGlyph->component.outline.numContours;
        firstFontNumAP = countAnchorPoints(curGlyph);

        LF_freeGlyph(curGlyph);

        // see if the other fonts have the same count
        for (size_t j = 1; (j < numFonts) && (error == LF_ERROR_OK) && (*uniformContourCount == TRUE); j++)
        {
            curFont = vector_at(lfFonts, j);

            error = LF_getGlyph(curFont, index, &curGlyph);

            if (LF_ERROR_OK == error)
            {
                SHORT curNC = curGlyph->component.outline.numContours;

                if (curNC != firstFontNC)
                {
                    USHORT curNumAP = countAnchorPoints(curGlyph);
                    USHORT firstNonAP = firstFontNC - firstFontNumAP;
                    USHORT curNonAP = curNC - curNumAP;

                    if (firstNonAP != curNonAP)
                    {
                        *uniformContourCount = FALSE;
                        //break;
                    }
                }

                LF_freeGlyph(curGlyph);
            }
        }
    }

    return error;
}

static LF_ERROR replicateGlyphsAtIndex(GlyphID index, LF_FONT_TYPE outputType, LF_VECTOR* lfFonts, FILE* logFile)
{
    writeLog("INFO:    Copying original glyph from first font to all output fonts at index %d\n", index);

    if (eLF_SFNT_FONT == outputType)
    {
        glyf firstGlyf;
        memset(&firstGlyf, 0, sizeof(glyf));

        LF_ERROR error = GLYF_getFullGlyph((LF_FONT*)vector_at(lfFonts, 0), &firstGlyf, index);
        if (error != LF_ERROR_OK)
        {
            writeLog("ERROR: Failed retrieving glyph %d from font at index 0.\n", index);
            return error;
        }

        for (size_t j = 1; j < lfFonts->count; j++)
        {
            error = GLYF_replaceGlyph(vector_at(lfFonts, j), index, &firstGlyf);
            if (error != LF_ERROR_OK)
            {
                GLYF_destroyGlyf(&firstGlyf);
                writeLog("ERROR: Failed replicating glyph %d into font at index %zu.\n", index, j);
                return error;
            }
        }

        GLYF_destroyGlyf(&firstGlyf);

        return LF_ERROR_OK;
    }
    else
    {
        return LF_UNSUPPORTED;
    }
}

static void nullGlyphsAtIndex(LF_VECTOR* lfFonts, USHORT index)
{
    size_t i, numFonts = vector_size(lfFonts);

    for (i = 0; i < numFonts; i++)
    {
        LF_FONT* curFont = (LF_FONT*)vector_at(lfFonts, i);

        glyf_table* glyfTable = (glyf_table*)map_at(&curFont->table_map, (void*)TAG_GLYF);

        map_insert(glyfTable->glyfMap, (void*)(intptr_t)index, NULL);
    }
}

static LF_ERROR prepCFFTables(LF_VECTOR* lfFonts)
{
    // This function updates the parsed internal structure of the cff
    // tables, so that the existing write function can be used to output the new table.
    // The charstrings in the charstring maps have been updated to their harmonized versions.
    // This program does not create subroutines, so any existing ones are removed
    // below.

    size_t i, numFonts = vector_size(lfFonts);

    for (i = 0; i < numFonts; i++)
    {
        LF_FONT* curFont = (LF_FONT*)vector_at(lfFonts, i);

        cff_table* cffTable = (cff_table*)map_at(&curFont->table_map, (void*)TAG_CFF);

        CFF_TAB* cffParsed = cffTable->cffTable;

        if (cffParsed->localSubrIndex != NULL)
        {
            cff_indexDestroy(cffParsed->localSubrIndex);
            cffParsed->localSubrIndex = NULL;
        }

        if (0 != cff_indexGetCount(cffParsed->globalSubrIndex))
        {
            cff_indexDestroy(cffParsed->globalSubrIndex);
            cffParsed->globalSubrIndex = NULL;

            cffIndex* newIndex;
            CFF_ERROR cffErr = cff_indexInitializeWithSize(0, &newIndex);

            if (cffErr != CFF_ERR_OK)
            {
                return cff_mapCffErrorToLfError(cffErr);
            }
            cffParsed->globalSubrIndex = newIndex;
        }


        if (cffParsed->isCID == TRUE)
        {
            //ASSERT(0);

            printf("CID fotns not handled yet!\n");

            // TODO need to convert to non-cid
        }
    }

    return LF_ERROR_OK;
}

static LF_ERROR removeAnchorPoints(LF_VECTOR* lfFonts, FILE* logFile)
{
    // Since the harmonize process strips out the single point contours from the glyphs
    // we must remove references to those points from the GPOS tables.

    size_t i, numFonts = vector_size(lfFonts);

    for (i = 0; i < numFonts; i++)
    {
        LF_FONT* curFont = (LF_FONT*)vector_at(lfFonts, i);

        LF_ERROR error = GPOS_removeAnchorPoints(curFont);

        if (LF_ERROR_OK != error)
        {
            fprintf(logFile, "ERROR: failed to remove Anchor points from font at index %zd. Check its GPOS table.\n", i);
        }
    }

    return LF_ERROR_OK;
}


// public API

LF_API LF_ERROR LF_harmonizeFonts(const LF_VECTOR* inputFonts, const char* outputPath, harmonizeOptions* options)
{
    if ((NULL == inputFonts) || (NULL == outputPath) || (NULL == options))
        return LF_INVALID_PARAM;
    if ((options->prog != NULL) && (options->prog->progressCB == NULL))
        return LF_INVALID_PARAM;
    if (0 == vector_size(inputFonts))
        return LF_INVALID_PARAM;

    // Alias
    FILE* logFile = options->logFile;   // may be NULL

    reportProgress(0);

    // Check that input path(s) is different from output path
    LF_ERROR error = checkInputPaths(inputFonts, outputPath);
    if (error != LF_ERROR_OK)
    {
        writeLog("ERROR:Output path can not be the same as the input path.\n");
        return error;
    }

    reportProgress(1);

    // Create array of LF_FONTs.
    LF_VECTOR fonts;

    error = createFontArray(inputFonts, &fonts, logFile);
    if (error != LF_ERROR_OK)
        return error;

    reportProgress(3);

    LF_FONT_TYPE outputType = (options->outputCFF == TRUE) ? eLF_CFF_FONT : eLF_SFNT_FONT;
    LF_FONT_TYPE inputType;

    // Check that the input fonts are harmonizeable.
    error = checkInputFonts(inputFonts, &fonts, options->forceReplacement, logFile, &inputType);
    if (error != LF_ERROR_OK)
    {
        destroyFontArray(&fonts);
        return error;
    }

    harmonizeResources workingData;

    error = allocateResources(&workingData, &fonts, logFile);
    if (error != LF_ERROR_OK)
    {
        destroyFontArray(&fonts);
        return error;
    }


    error = checkGlyphsTables(&fonts, logFile, inputType, outputType);
    if (error != LF_ERROR_OK)
    {
        destroyFontArray(&fonts);
        return error;
    }

    writeLog("Harmonizing...\n");

    reportProgress(5);

    USHORT numAlgMismatch = 0;
    USHORT numCopied = 0;
    USHORT numPointMismatch = 0;

    LF_FONT* curFont = vector_at(&fonts, 0);
    USHORT numGlyphs = MAXP_getNumGlyphs(curFont);
    USHORT unitsPerEm = HEAD_getUnitsPerEM(curFont);  // assumes all fonts have the same units per em!

    // Loop over glyphs
    for (USHORT i = 0; i < numGlyphs; i++)
    {
        checkProgress(i, numGlyphs, options);

        if (TRUE == options->forceReplacement)
        {
            // If the contour counts are not the same, just copy the glyph from the first font to the others.
            boolean uniformContourCount;

            error = checkContourCountsAtIndexIgnoreAnchorPts(i, &fonts, &uniformContourCount);
            //error = checkContourCountsAtIndex(i, &fonts, &uniformContourCount);
            if (error != LF_ERROR_OK)
            {
                destroyResources(&workingData);
                destroyFontArray(&fonts);
                return error;
            }

            if (FALSE == uniformContourCount)
            {
                error = replicateGlyphsAtIndex(i, outputType, &fonts, logFile);

                if (error != LF_ERROR_OK)
                {
                    destroyResources(&workingData);
                    destroyFontArray(&fonts);
                    return error;
                }

                numCopied++;
                continue;
            }
        }

        boolean needToHarmonize = TRUE;
        error = needsHarmonization(inputType, i, &fonts, &needToHarmonize);
        if (error != LF_ERROR_OK)
        {
            destroyResources(&workingData);
            destroyFontArray(&fonts);
            return error;
        }

        if (needToHarmonize == FALSE)
        {
            if ((eLF_CFF_FONT == inputType) && (eLF_SFNT_FONT == outputType))
                nullGlyphsAtIndex(&fonts, i);
            continue;
        }

        // Get the glyphs for the current index.
        error = retrieveGlyphsAtIndex(inputType, i, &workingData, &fonts, logFile);
        if (error != LF_ERROR_OK)
        {
            clearGlyphs(&workingData);
            destroyResources(&workingData);
            destroyFontArray(&fonts);
            return error;
        }

        if (TRUE == options->verbose)
            printf("\n----------------------------\nGlyph %d\n", i);

        // Call algorithm.

        harmonizerParameters hParams;
        hParams.noContorCheck = options->suppressContourCheck;
        hParams.noExtremaAdding = options->suppressExtremaAddition;
        hParams.noStartPointCheck = options->suppressStartPointCheck;
        hParams.outputType = (eLF_SFNT_FONT == outputType) ? eGlyph_TTF : eGlyph_CFF;

        Harmonizer_Error err = harmonizer_harmonizeGlyphs(workingData.glyphArray, (int)fonts.count, unitsPerEm,
                                                          &hParams, (int)options->verbose);
        if (err != HARMONIZER_SUCCESS)
        {
            if (err == HARMONIZER_FAILED_MATCH)
            {
                numAlgMismatch++;
                writeLog("WARNING: Algorithm reports failure to match glyphs at index %d.\n", i);
            }
            else
            {
                clearGlyphs(&workingData);
                destroyResources(&workingData);
                destroyFontArray(&fonts);
                return LF_HARMONIZE_ALGORITHM;
            }
        }

        // Check output (only logs warnings).
        verifyHarmonization(i, workingData.glyphArray, fonts.count, &numPointMismatch, logFile);

        // Replace new glyph in glyf/cff table of each font.
        error = replaceGlyphsAtIndex(i, &workingData, outputType, &fonts, logFile);
        if (error != LF_ERROR_OK)
        {
            clearGlyphs(&workingData);
            destroyResources(&workingData);
            destroyFontArray(&fonts);
            return error;
        }

        clearGlyphs(&workingData);
    }

    if ((eLF_CFF_FONT == inputType) && (eLF_CFF_FONT == outputType))
    {
        // Prepare the cff tables to be written
        error = prepCFFTables(&fonts);
        if (error != LF_ERROR_OK)
        {
            destroyResources(&workingData);
            destroyFontArray(&fonts);
            return error;
        }
    }

    writeLog("Writing fonts...\n");

    reportProgress(90);

    // Remove anchor points
    error = removeAnchorPoints(&fonts, logFile);

    // Update tables.
    if (error == LF_ERROR_OK)
        error = updateNameTables(&fonts, logFile);

    if (error == LF_ERROR_OK)
        error = updateHeadTables(&fonts, logFile);

    if (error == LF_ERROR_OK)
        error = updateOtherTables(&fonts, outputType, logFile);

    reportProgress(95);

    // Write fonts.
    if (error == LF_ERROR_OK)
        error = writeFonts(inputFonts, outputPath, outputType, &fonts, logFile);

    destroyResources(&workingData);
    destroyFontArray(&fonts);

    writeLog("Stats...\n");
    writeLog("Number of glyphs                  : %d\n", numGlyphs);
    writeLog("Not harmonized (contour mismatch) : %d (%1.2f%%)\n", numCopied, ((float)numCopied / (float)numGlyphs) * 100.0f);
    writeLog("Algorithm failed to match         : %d (%1.2f%%)\n", numAlgMismatch, ((float)numAlgMismatch / numGlyphs) * 100.f);
    writeLog("Point count mismatch              : %d (%1.2f%%)\n", numPointMismatch, ((float)numPointMismatch / (float)numGlyphs) * 100.f);

    reportProgress(100);

    return error;
}
