// Copyright (C) 2014, 2017 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// eot_core.c

#include "lf_core.h"
#include "eot_core.h"
#include "offset_table_eot.h"
#include "os2_table.h"
#include "name_table.h"
#include "sfnt_core.h"
#include "table_tags.h"
#include "utils.h"

LF_ERROR EOT_readOffsetTable(LF_FONT* lfFont, LF_STREAM* stream, int keepFlags)
{
    USHORT i, numTables;
    LF_ERROR error;
    eot_offset_table *table;
    LF_SFNT_HEADER sfntHeader;
    LF_STREAM sfntStream;

    error = offset_eot_readTable(stream, (eot_offset_table**)&lfFont->offset_table.eot);
    if (error != LF_ERROR_OK)
        return error;

    table = (eot_offset_table*)lfFont->offset_table.eot;
    if(table->eotHeader.fontDataSize == 0)
        return LF_BAD_FORMAT;

    // store pointer to uncompressed font data
    lfFont->fontSize = table->eotHeader.fontDataSize;
    lfFont->fontData = table->eotHeader.fontData;

    STREAM_initMemStream(&sfntStream, lfFont->fontData, lfFont->fontSize);

    // now initialize the record list
    sfntHeader.sfnt_version  = STREAM_readFixed(&sfntStream);
    sfntHeader.numTables     = STREAM_readUShort(&sfntStream);
    sfntHeader.searchRange   = STREAM_readUShort(&sfntStream);
    sfntHeader.entrySelector = STREAM_readUShort(&sfntStream);
    sfntHeader.rangeShift    = STREAM_readUShort(&sfntStream);

    error = vector_init(&table->record_list, sfntHeader.numTables, 4);
    if (error != LF_ERROR_OK)
        return error;

    numTables = sfntHeader.numTables;

    for(i = 0; i < numTables; ++i)
    {
        // allocate and read next record
        sfnt_table_record* record = offset_readRecord(&sfntStream);

        if(record != NULL)
        {
            if((TRUE == LF_retainTable(record->tag, keepFlags)) && (record->length != 0))
            {
                // add to linked list
                vector_push_back(&table->record_list, record);
            }
            else
            {
                free(record);
                sfntHeader.numTables--;
            }
        }
        else
        {
            DEBUG_LOG_ERROR("allocation failure in EOT_readOffsetTable");
            offset_eot_freeTable(lfFont);
            lfFont->offset_table.eot = NULL;
            lfFont->fontSize = 0;
            lfFont->fontData = NULL;
            return LF_OUT_OF_MEMORY;
        }
    }

    return LF_ERROR_OK;
}

// changes the lfFont from EOT type to SFNT type
LF_ERROR EOT_to_SFNT(LF_FONT* lfFont, int keepFlags)
{
    USHORT i, numTables;
    sfnt_offset_table* sfntTable;
    eot_offset_table *eotTable;
    LF_STREAM sfntStream;

    if(lfFont == NULL)
        return LF_INVALID_PARAM;
    if(lfFont->fontType != eLF_EOT_FONT)
        return LF_BAD_FORMAT;

    // create a new sfnt offset table from the decompressed sfnt
    sfntTable = (sfnt_offset_table*)calloc(1, sizeof(sfnt_offset_table));
    if(sfntTable == NULL)
        return LF_OUT_OF_MEMORY;

    eotTable = (eot_offset_table*)lfFont->offset_table.eot;

    if(eotTable->srcWasCompressed == FALSE)
    {
        // allocate a new buffer for the sfnt
        BYTE* buf = (BYTE*)malloc(eotTable->eotHeader.fontDataSize);
        if(buf == NULL)
        {
            free(sfntTable);
            return LF_OUT_OF_MEMORY;
        }

        memcpy(buf, eotTable->eotHeader.fontData, eotTable->eotHeader.fontDataSize);

        lfFont->fontData = buf;
    }
    else
    {
        lfFont->fontData = eotTable->eotHeader.fontData;
    }
    lfFont->fontSize = eotTable->eotHeader.fontDataSize;


    STREAM_initMemStream(&sfntStream, lfFont->fontData, lfFont->fontSize);

    sfntTable->sfntHeader.sfnt_version  = STREAM_readFixed(&sfntStream);
    sfntTable->sfntHeader.numTables     = STREAM_readUShort(&sfntStream);
    sfntTable->sfntHeader.searchRange   = STREAM_readUShort(&sfntStream);
    sfntTable->sfntHeader.entrySelector = STREAM_readUShort(&sfntStream);
    sfntTable->sfntHeader.rangeShift    = STREAM_readUShort(&sfntStream);

    LF_ERROR error = vector_init(&sfntTable->record_list, sfntTable->sfntHeader.numTables, 4);
    if (LF_ERROR_OK != error)
    {
        free(sfntTable);
        return error;
    }

    numTables = sfntTable->sfntHeader.numTables;

    for(i = 0; i < numTables; ++i)
    {
        // allocate and read next record
        sfnt_table_record* record = offset_readRecord(&sfntStream);

        if(record)
        {
            if((TRUE == LF_retainTable(record->tag, keepFlags)) && (record->length != 0))
            {
                //add to linked list
                vector_push_back(&sfntTable->record_list, record);
            }
            else
            {
                free(record);
                sfntTable->sfntHeader.numTables--;
            }
        }
        else
        {
            size_t j;
            for(j = 0; j < sfntTable->record_list.count; ++j)
                free(vector_at(&sfntTable->record_list, j));
            vector_free(&sfntTable->record_list);
            free(sfntTable);
            free(lfFont->fontData);
            lfFont->fontData = NULL;
            lfFont->fontSize = 0;
            return LF_OUT_OF_MEMORY;
        }
    }

    // get rid of the original eot offset table
    offset_eot_freeTable(lfFont);

    // switch to the new sfnt table
    lfFont->offset_table.sfnt = sfntTable;
    lfFont->fontType = (sfntTable->sfntHeader.sfnt_version == SIG_CFF) ? eLF_CFF_FONT : eLF_SFNT_FONT;
    if (sfntTable->sfntHeader.sfnt_version == SIG_CFF)
        lfFont->origFlavor = SIG_CFF;

    return LF_ERROR_OK;
}

LF_ERROR EOT_getMaxSize(LF_FONT* lfFont, const LF_WRITE_PARAMS *params, size_t* size)
{
    size_t sfntSize = 0;
    LF_ERROR error;
    USHORT nameLen;

    error = SFNT_getSFNTSize(lfFont, params, &sfntSize);
    if(error != LF_ERROR_OK)
        return error;

    // add size for EOT version 2.1 header

    *size = sfntSize;
    *size += (sizeof(ULONG)* 16) + (sizeof(BYTE)* 12) + (sizeof(USHORT)* 12); // for the eot 2.1 header excluding the fields which are pointers.

    // add in the name fields
    if(TRUE == map_empty(&lfFont->table_map))
    {
        // packed, so just add the size of the name table for now, could unpack it temporarily to get more accurate value
        sfnt_table_record* nameRecord = offset_findRecord(lfFont, TAG_NAME);
        if(nameRecord)
            *size += nameRecord->length;
    }
    else
    {
        // Need to parse name table before getting names.
        error = NAME_parseTable(lfFont);
        if (error != LF_ERROR_OK)
            return error;

        error = NAME_getNameStringLength(lfFont, 1, &nameLen);
        if (error == LF_ERROR_OK)
            *size += nameLen;

        error = NAME_getNameStringLength(lfFont, 2, &nameLen);
        if (error == LF_ERROR_OK)
            *size += nameLen;

        error = NAME_getNameStringLength(lfFont, 5, &nameLen);
        if (error == LF_ERROR_OK)
            *size += nameLen;

        error = NAME_getNameStringLength(lfFont, 4, &nameLen);
        if (error == LF_ERROR_OK)
            *size += nameLen;
    }

    // root string would go here but we don't process that yet

    return LF_ERROR_OK;
}

LF_ERROR EOT_writeToStream(LF_FONT* lfFont, const LF_WRITE_PARAMS *params, LF_STREAM* stream)
{
    LF_ERROR error;
    eot_offset_table* eotTable;
    boolean srcIsUnPacked = TRUE;
    LF_FONT temp;                       // this is used (only) so an LF_FONT can be passed to offset_eot_freeTable

    UNUSED(params);

    if ((lfFont == NULL) || (stream == NULL))
        return LF_INVALID_PARAM;

    if ((lfFont->builtSFNT == NULL) || (lfFont->builtSFNTOffsetTable == NULL))
        return LF_BAD_FORMAT;

    memset(&temp, 0, sizeof(LF_FONT));

    if (TRUE == map_empty(&lfFont->table_map))
        srcIsUnPacked = FALSE;

    // create a new eot offset table
    eotTable = (eot_offset_table*)calloc(1, sizeof(eot_offset_table));
    if (eotTable == NULL)
        return LF_OUT_OF_MEMORY;

    temp.offset_table.eot = eotTable;

    if (srcIsUnPacked == FALSE)
    {
        // we must temporarily unpack the os2 and name table so we can get info from them
        sfnt_table_record* record;
        LF_STREAM tempStream;

        STREAM_initMemStream(&tempStream, (BYTE*)lfFont->fontData, lfFont->fontSize);

        record = offset_findRecord(lfFont, TAG_OS2);

        if (record)
        {
            error = OS2_readTable(lfFont, record, &tempStream);
            if (error != LF_ERROR_OK)
            {
                DEBUG_LOG_ERROR("EOT_writeToStream: could not read OS/2 table.\n");
                free(eotTable);
                return error;
            }
        }

        record = offset_findRecord(lfFont, TAG_NAME);

        if (record)
        {
            error = NAME_readTable(lfFont, record, &tempStream);
            if (error != LF_ERROR_OK)
            {
                DEBUG_LOG_ERROR("EOT_writeToStream: could not read name table.\n");
                OS2_freeTable(lfFont);
                map_erase(&lfFont->table_map, (void*)TAG_OS2);
                free(eotTable);
                return error;
            }
        }
    }

    // parse name table. If not present, relevant fields in eot header will be empty
    NAME_parseTable(lfFont);

    //initialize some values in the eot table header
    {
    USHORT fsSelection;
    USHORT weightClass;

    //eotTable->eotHeader.eotSize                                           // we don't know this yet
    //eotTable->eotHeader.fontDataSize                                      // we don't know this yet either
    //eotTable->eotHeader.version = 0x00020001;                             // set by routine that does the writing
    //eotTable->eotHeader.flags = TTEMBED_TTCOMPRESSED;                     // determined by routine that does the writing
    OS2_getPanoseValues(lfFont, eotTable->eotHeader.fontPanose);
    //eotTable->eotHeader.charset = 0x01;                                   // Default charset
    eotTable->eotHeader.charset = 0x00;                                     // ANSI charset
    OS2_getFsSelection(lfFont, &fsSelection);
    eotTable->eotHeader.italic = ((fsSelection & 0x01) != 0) ? 0x01 : 0x00;
    OS2_getWeightClass(lfFont, &weightClass);
    eotTable->eotHeader.weight = (ULONG)weightClass;
    OS2_getFsType(lfFont, &eotTable->eotHeader.fsType);
    //table->eotHeader.magicNumber = 0x504C;                                // set by routine that does the writing
    OS2_getUnicodeRange(lfFont, &eotTable->eotHeader.unicodeRange1,
                                &eotTable->eotHeader.unicodeRange2,
                                &eotTable->eotHeader.unicodeRange3,
                                &eotTable->eotHeader.unicodeRange4);
    OS2_getCodePageRange(lfFont, &eotTable->eotHeader.codePageRange1,
                                 &eotTable->eotHeader.codePageRange2);

    error = NAME_getNameStringLength(lfFont, 1, &eotTable->eotHeader.familyNameSize);
    if(error == LF_ERROR_OK)
    {
        eotTable->eotHeader.familyName = (BYTE*)calloc(1, eotTable->eotHeader.familyNameSize);
        NAME_getNameString(lfFont, 1, eotTable->eotHeader.familyName, eotTable->eotHeader.familyNameSize);
    }

    error = NAME_getNameStringLength(lfFont, 2, &eotTable->eotHeader.styleNameSize);
    if(error == LF_ERROR_OK)
    {
        eotTable->eotHeader.styleName = (BYTE*)calloc(1, eotTable->eotHeader.styleNameSize);
        NAME_getNameString(lfFont, 2, eotTable->eotHeader.styleName, eotTable->eotHeader.styleNameSize);
    }
    error = NAME_getNameStringLength(lfFont, 5, &eotTable->eotHeader.versionNameSize);
    if(error == LF_ERROR_OK)
    {
        eotTable->eotHeader.versionName = (BYTE*)calloc(1, eotTable->eotHeader.versionNameSize);
        NAME_getNameString(lfFont, 5, eotTable->eotHeader.versionName, eotTable->eotHeader.versionNameSize);
    }
    error = NAME_getNameStringLength(lfFont, 4, &eotTable->eotHeader.fullNameSize);
    if(error == LF_ERROR_OK)
    {
        eotTable->eotHeader.fullName = (BYTE*)calloc(1, eotTable->eotHeader.fullNameSize);
        NAME_getNameString(lfFont, 4, eotTable->eotHeader.fullName, eotTable->eotHeader.fullNameSize);
    }

    eotTable->eotHeader.rootStringSize = 0;
    eotTable->eotHeader.rootString = NULL;
    }

    if (srcIsUnPacked == FALSE)
    {
        // free the NAME and OS2 tables
        NAME_freeTable(lfFont);
        map_erase(&lfFont->table_map, (void*)TAG_NAME);
        OS2_freeTable(lfFont);
        map_erase(&lfFont->table_map, (void*)TAG_OS2);
    }

    eotTable->eotHeader.fontDataSize = lfFont->builtSFNTSize;
    eotTable->eotHeader.fontData = lfFont->builtSFNT;

    sfnt_offset_table* offsetTable = (sfnt_offset_table*)lfFont->builtSFNTOffsetTable;

    sfnt_table_record* headRecord = offset_findRecordEx(offsetTable, TAG_HEAD);

    ULONG* checksumAdjPtr = (ULONG*)(void*)((BYTE*)lfFont->builtSFNT + headRecord->offset + 8);

    eotTable->eotHeader.checkSumAdjustment = SWAP_ULONG(*checksumAdjPtr);

    error = offset_eot_writeEmbeddedFont(eotTable, stream);

    offset_eot_freeTable(&temp);

    if ((error == LF_ERROR_OK) && (FALSE == STREAM_ptrIsValid(stream)))
        error = LF_STREAM_OVERRUN;

    return error;
}
