// Copyright (C) 2014 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// chain_rule.c

#include "utils.h"
#include "common_table.h"
#include "chain_rule.h"

static LF_ERROR chainRule_readGlyphs(LF_VECTOR* glyphs, USHORT count, LF_STREAM* stream);
static LF_ERROR chainRule_buildGlyphArray(LF_STREAM* stream, LF_VECTOR* glyphs, SHORT adjustment);

LF_ERROR ChainRule_readRule(chain_rule* cr, LF_STREAM* stream)
{
    LF_ERROR                error;
    USHORT                  count;

    ASSERT(cr);
    ASSERT(stream);

    count = STREAM_readUShort(stream);
    error = chainRule_readGlyphs(&cr->Backtrack, count, stream);

    cr->Input.GlyphCount = count = STREAM_readUShort(stream);
    error = ContextRule_readInputSequence(&cr->Input.Input, count, stream);

    count = STREAM_readUShort(stream);
    error = chainRule_readGlyphs(&cr->LookAhead, count, stream);

    cr->Input.LookupCount = count = STREAM_readUShort(stream);
    error = Common_readSubstLookupRecords(&cr->Input.LookupRecords, count, stream);

    return error;
}

static LF_ERROR chainRule_readGlyphs(LF_VECTOR* glyphs, USHORT count, LF_STREAM* stream)
{
    USHORT      n;
    LF_ERROR    error = vector_init(glyphs, count, sizeof(ULONG));

    if (error != LF_ERROR_OK)
        return error;

    for (n = 0; n < count; n++)
    {
        USHORT data = STREAM_readUShort(stream);
        vector_push_back(glyphs, (void*)(intptr_t)data);
    }
    return LF_ERROR_OK;
}

/* ----------------------------------------------------------------------------
    @description
        free all of the Chain rule resources
---------------------------------------------------------------------------- */
void ChainRule_freeRule(chain_rule* cr)
{
    if (cr)
    {
        ContextRule_freeRule(&cr->Input);
        vector_delete(&cr->Backtrack);
        vector_delete(&cr->LookAhead);
    }
}

/* ----------------------------------------------------------------------------
    @summary
        get size of chain rule structure.

    @param
        sr        : pointer to chain rule structure.

    @return
        size of rule structure in bytes.

---------------------------------------------------------------------------- */
size_t ChainRule_sizeRule(chain_rule* cr)
{
    size_t size = 0;

    size += sizeof(USHORT);                // Backtrack Count
    size += sizeof(GlyphID) * cr->Backtrack.count;

    size += sizeof(USHORT);                // Lookahead Count
    size += sizeof(GlyphID) * cr->LookAhead.count;

    size += ContextRule_sizeRule(&cr->Input);

    return size;
}

/* ----------------------------------------------------------------------------
    @summary
        build the glyph sequence that includes a count for chain rules

    @param
        stream        :    pointer to the stream

        glyphs        :    pointer to vector collection of glyphs

        adjustment    :    adjustment value to the glyphs count.  This is included
                           because some sequences must include a coverage glyph that
                           is not in the glyph sequence, but must be included with
                           the count.

    @return
        size of rule structure in bytes.

---------------------------------------------------------------------------- */
static LF_ERROR chainRule_buildGlyphArray(LF_STREAM* stream, LF_VECTOR* glyphs, SHORT adjustment)
{
    USHORT n;
    USHORT count = UTILS_getCount(glyphs);                      // get the count in the sequence

    STREAM_writeUShort(stream, count + adjustment);             // write out the count in the sequence

    for ( n = 0; n < glyphs->count; n++)
    {
        GlyphID glyph = (GlyphID)(intptr_t)vector_at(glyphs, n);
        STREAM_writeUShort(stream, glyph);
    }

    return LF_ERROR_OK;
}


/* ============================================================================
    @summary
        build the Chain Rule.  The chain rule is broken into a context
        rule, and a backtrack and lookahead sequence.

    @param
        cr        : pointer to the chain rule
        stream    : pointer to the stream

    @return
        current position of the stream.

============================================================================ */
size_t ChainRule_buildRule(chain_rule* cr, LF_STREAM* stream)
{
    USHORT      count;
    //LF_ERROR    error;

    //chainRule_buildGlyphArray always returns OK
    /*error = */chainRule_buildGlyphArray(stream, &cr->Backtrack, 0);        // no adjustment required
    /*error = */chainRule_buildGlyphArray(stream, &cr->Input.Input, 1);      // adjustment of 1 to include coverage glyph
    /*error = */chainRule_buildGlyphArray(stream, &cr->LookAhead, 0);        // no adjustment required

    // write out lookup records
    count = UTILS_getCount(&cr->Input.LookupRecords);
    STREAM_writeUShort(stream, count);
    Common_buildSubstLookupRecords(&cr->Input.LookupRecords, stream);

    return STREAM_streamPos(stream);
}

#ifdef LF_OT_DUMP
//lint -size(a, 2049)
void ChainRule_dumpRule(chain_rule* cr)
{
    USHORT i;

    DEBUG_LOG_VALUE("BacktrackCount: ", (int)cr->Backtrack.count);
    for (i = 0; i < cr->Backtrack.count; i++)
    {
        char    msg[2048];
        USHORT    glyph = (USHORT)(long)vector_at(&cr->Backtrack, i);

        sprintf(msg, "Backtrack[%d] = %d", i, glyph);
        DEBUG_LOG(msg);
    }

    DEBUG_LOG_VALUE("LookaheadCount: ", (int)cr->LookAhead.count);
    for (i = 0; i < cr->LookAhead.count; i++)
    {
        char    msg[2048];
        USHORT    glyph = (USHORT)(long)vector_at(&cr->LookAhead, i);

        sprintf(msg, "Lookahead[%d] = %d", i, glyph);
        DEBUG_LOG(msg);
    }

    ContextRule_dumpRule(&cr->Input);
}
//lint +size(a, 0)
#endif

/* ============================================================================
    @description
        search all of the chain rule sequences and determine if the 
        glyph is present.

    @param
        cr         :    pointer to chain rule
        glyphid    :    glyph to search for
        index      :    pointer to variable of found glyph index.

    @return
        LF_NOT_COVERED     :    glyph wasn't found
        LF_ERROR_OK        :    glyph was found in a chain rule sequence

============================================================================ */
LF_ERROR ChainRule_searchRule(chain_rule* cr, GlyphID glyphid, USHORT* index)
{
    LF_ERROR  error = LF_NOT_COVERED;

    if(cr->Input.Input.count)
        error = ContextRule_searchSequence(&cr->Input.Input, glyphid, index);
    if (error == LF_ERROR_OK)
        return LF_ERROR_OK;

    if(cr->Backtrack.count)
        error = ContextRule_searchSequence(&cr->Backtrack, glyphid, index);
    if (error == LF_ERROR_OK)
        return LF_ERROR_OK;

    if(cr->LookAhead.count)
        error = ContextRule_searchSequence(&cr->LookAhead, glyphid, index);
    if (error == LF_ERROR_OK)
        return LF_ERROR_OK;

    return LF_NOT_COVERED;
}

LF_ERROR ChainRule_remapRule(chain_rule* cr, LF_MAP *remap)
{
    if (cr)
    {
        LF_ERROR error;

        error = ContextRule_remapRule(&cr->Input, remap);
        if ((error == LF_NOT_COVERED) || (error == LF_ERROR_OK))
        {
            GlyphID origGlyphID, newGlyphID;
            USHORT i, numBacktracks, numLookAheads;

            numBacktracks = UTILS_getCount(&cr->Backtrack);

            for (i = 0; i < numBacktracks; i++)
            {
                origGlyphID = (GlyphID)(intptr_t)vector_at(&cr->Backtrack, i);

                newGlyphID = (GlyphID)(intptr_t)map_at(remap, (void*)(intptr_t)origGlyphID);

#if _DEBUG
                if ((newGlyphID == 0) && (origGlyphID != 0))
                {
                    DEBUG_LOG_ERROR("warning remap returned 0 glyphID");
                }
#endif
                vector_set_data(&cr->Backtrack, i, (void*)(intptr_t)newGlyphID);
            }

            numLookAheads = UTILS_getCount(&cr->LookAhead);

            for (i = 0; i < numLookAheads; i++)
            {
                origGlyphID = (GlyphID)(intptr_t)vector_at(&cr->LookAhead, i);

                newGlyphID = (GlyphID)(intptr_t)map_at(remap, (void*)(intptr_t)origGlyphID);

#if _DEBUG
                if ((newGlyphID == 0) && (origGlyphID != 0))
                {
                    DEBUG_LOG_ERROR("warning remap returned 0 glyphID");
                }
#endif

                vector_set_data(&cr->LookAhead, i, (void*)(intptr_t)newGlyphID);
            }
        }

        return error;
    }

    return LF_NOT_COVERED;
}

LF_ERROR ChainRule_collectGlyphs(chain_rule* cr, GlyphList* keepList, TABLE_HANDLE hTable)
{
    LF_ERROR    error;

    error = ContextRule_existsInKeepTable(keepList, &cr->Input.Input);
    if (error == LF_NOT_COVERED)
        return error;

    error = ContextRule_existsInKeepTable(keepList, &cr->Backtrack);
    if (error == LF_NOT_COVERED)
        return error;

    error = ContextRule_existsInKeepTable(keepList, &cr->LookAhead);
    if (error == LF_NOT_COVERED)
        return error;

    // if we reach this point, the chain rule is valid and we need to add the
    // glyphs to the keepTable.
    error = Common_collectLookupRecordGlyphs(&cr->Input.LookupRecords, keepList, hTable);

    return error;
}
