// Copyright (C) 2014, 2015 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// lookup_table.c

#include <string.h>
#include <stdlib.h>
#include "lookup_table.h"
#include "feature_table.h"
#include "gpos_table.h"
#include "gsub_table.h"
#include "gsub_lookup/gsub_common.h"

#define DELETE_EMPTY_SUBTABLES    1
#define REMOVE_SUBTABLE           1

static LF_ERROR Lookup_removeLookupIndex(TABLE_HANDLE hTable, USHORT refIndex, boolean isGPOS);
static void Lookup_freeTable(lookup_table* lookupTable, boolean isGPOS);

static lookup_table* Lookup_readLookupTable(LF_STREAM* stream, boolean isGPOS, USHORT lookupIndex)
{
    lookup_table* table = (lookup_table*)calloc(1, sizeof(lookup_table));
    if (!table)
    {
        DEBUG_LOG_ERROR("failed to allocate lookup table structure");
        return NULL;
    }

    USHORT  subtableCount;
    boolean isExtension = FALSE;

    size_t tableStart = STREAM_streamPos(stream);

    table->LookupType = STREAM_readUShort(stream);
    table->LookupFlag = STREAM_readUShort(stream);
    subtableCount = STREAM_readUShort(stream);

    if (isGPOS == FALSE && table->LookupType == 7)
    {
        isExtension = TRUE;
    }

    if (isGPOS == TRUE && table->LookupType == 9)
    {
        isExtension = TRUE;
    }

    LF_ERROR error = vector_init(&table->SubTables, subtableCount, 4);
    if (error != LF_ERROR_OK)
    {
        free(table);
        return NULL;
    }

    if(subtableCount > 0)
    {
        USHORT j;
        for(j = 0; j < subtableCount; j++)
        {
            OFFSET offset = STREAM_readOffset(stream);
            size_t newOffset = tableStart + offset;

            TABLE_HANDLE subtable = NULL;
            size_t oldOffset = STREAM_streamPos(stream);

            if ( isExtension )
            {
                STREAM_streamSeek(stream, newOffset);
                if (STREAM_readUShort(stream) != 1)
                {
                    DEBUG_LOG_ERROR("bad format: should be 1 for lookup extensions");
                    vector_free(&table->SubTables);
                    free(table);
                    return NULL;
                }

                table->LookupType = STREAM_readUShort(stream);
                newOffset += STREAM_readULong(stream);
            }

            if(isGPOS)
            {
                STREAM_streamSeek(stream, newOffset);
                subtable = GPOS_readSubtable(table->LookupType, stream);
                if (subtable)
                {
                    BaseTable_init(subtable, NULL);
                    BaseTable_setType(subtable, TABLETYPE_GPOS, (eBaseSubTableTypes)table->LookupType);
                }
                else
                {
                    Lookup_freeTable(table, isGPOS);
                    return NULL;
                }


                STREAM_streamSeek(stream, oldOffset);
            }
            else
            {
                STREAM_streamSeek(stream, newOffset);
                subtable = GSUB_readSubtable(table->LookupType, stream);
                if (subtable)
                {
                    BaseTable_init(subtable, NULL);
                    BaseTable_setType(subtable, TABLETYPE_GSUB, (eBaseSubTableTypes)table->LookupType);
                }
                STREAM_streamSeek(stream, oldOffset);
            }

            if(subtable)
            {
                vector_push_back(&table->SubTables, subtable);

                // setup some DEBUG information, or tracking information.  useful to 
                // help debug remapped lookup tables.  stores off the original lookup
                // index, so we can lookup the previous table.
                BaseTable_setPrevLookup(subtable, lookupIndex);
            }
        }
    }

    if (table->LookupFlag & USEMARKFILTERINGSET)
    {
        table->MarkFilteringSet = STREAM_readUShort(stream);

        // mark filtering sets are not supported yet
        table->LookupFlag &= ~USEMARKFILTERINGSET;
        table->MarkFilteringSet = 0;
        DEBUG_LOG_WARNING("WARNING: clearing mark filtering set flag in a lookup");
    }
    else
        table->MarkFilteringSet = 0;

    return table;
}

TABLE_HANDLE Lookup_readListTable(LF_STREAM* stream, boolean isGPOS)
{
    size_t tableStart = STREAM_streamPos(stream);
    USHORT lookupCount = STREAM_readUShort(stream);
    USHORT i;
    LF_VECTOR* lookup_list_table = vector_create(lookupCount, 4);
    if (lookup_list_table == NULL)
        return NULL;

    for(i = 0; i < lookupCount; i++)
    {
        lookup_table* table;
        OFFSET lookupOffset = STREAM_readOffset(stream);
        size_t oldOffset = STREAM_streamPos(stream);
        STREAM_streamSeek(stream, tableStart + lookupOffset);

        table = Lookup_readLookupTable(stream, isGPOS, i);
        if (table == NULL)
        {
            Lookup_freeTableList(lookup_list_table, isGPOS);
            return NULL;
        }


#if defined(_ROBA) && defined(_DEBUG)
        // this is a useful debugging technique to use when you want 
        // to watch a specific table.  by applying a flag to the 
        // base table of that structure, you may trap it in the
        // appropriate subtable areas regardless if the lookup index 
        // changes and moves the table around.
        if (table && (i == 28) && isGPOS == FALSE)
        {
            ULONG n;
            for (n = 0; n < table->SubTables.count; n++)
            {
                base_table* base = (base_table*)vector_at(&table->SubTables, n);
                base->dump = TRUE;
            }
        }
#endif

        STREAM_streamSeek(stream, oldOffset);

        vector_push_back(lookup_list_table, table);
    }

    return lookup_list_table;
}

static size_t Lookup_getLookupTableSize(lookup_table* table, boolean isGPOS, boolean isExtension)
{
    ULONG i;
    size_t lookupTableSize = sizeof(USHORT) * 3;
    lookupTableSize += sizeof(OFFSET) * table->SubTables.count;

    for(i = 0; i < table->SubTables.count; i++)
    {
        if (isExtension)
        {
            lookupTableSize += sizeof(USHORT) * 2 + sizeof(ULONG);
        }
        else
        {
            if (isGPOS)
                lookupTableSize += GPOS_getSubtableSize(table->LookupType, (TABLE_HANDLE)vector_at(&table->SubTables, i));
            else
                lookupTableSize += GSUB_getSubtableSize(table->LookupType, (TABLE_HANDLE)vector_at(&table->SubTables, i));
        }
    }

    if(table->LookupFlag & USEMARKFILTERINGSET)
        lookupTableSize += sizeof(USHORT);

    return lookupTableSize;
}


size_t Lookup_getDataSize(TABLE_HANDLE hTable, boolean isGPOS)
{
    LF_VECTOR tableSizes;
    ULONG lookupListSize = 0;
    ULONG lastOffsetPosition;
    boolean needExtension = FALSE;
    LF_VECTOR* lookup_list_table = (LF_VECTOR*)hTable;
    size_t tableSize = sizeof(USHORT) + sizeof(OFFSET) * lookup_list_table->count;

    // Simple loop to calculate the size of all lookup tables
    // Nothing further required if all of the lookups stay under 0xffff

    vector_init(&tableSizes, lookup_list_table->count, 4);

    for (size_t i = 0; i < lookup_list_table->count; i++)
    {
        lookup_table* table = (lookup_table*)vector_at(lookup_list_table, i);
        lookupListSize = (ULONG)Lookup_getLookupTableSize(table, isGPOS, FALSE);
        vector_push_back(&tableSizes, (void*)(intptr_t)lookupListSize);
        // Test against furthest offset value which is beginning of last table
//      needExtension = tableSize > 0x0000ffff ? TRUE : FALSE;
        if (tableSize > 0x0000ffff || lookupListSize > 0x0000ffff)
            needExtension = TRUE;
        tableSize += lookupListSize;
    }

    // Only need to do this if we have extension lookups.
    // Then we need to add the extension Lookups (8 bytes per subtable extension) to our total


    lastOffsetPosition = (ULONG)(tableSize - lookupListSize);            // Tracks amount over 0xffff starting at last offset pos
    while (needExtension)
    {
        ULONG maxSize = 0;
        ULONG extensionSize;
        size_t index = 0;

        // First find the largest lookup
        for (size_t i = 0; i < tableSizes.count; ++i)
        {
            ULONG lookupSize = (ULONG)(intptr_t)vector_at(&tableSizes, i);

            if (lookupSize > maxSize)
            {
                maxSize = lookupSize;
                index = i;
            }
        }

        vector_set_data(&tableSizes, index, (void*)0L);         /* Don't count this max size again in our search*/

        // Add the size of a table extension for each subtable in the lookup
        lookup_table* lookupTable = (lookup_table*)vector_at(lookup_list_table, index);
        extensionSize = (ULONG)((sizeof(USHORT) * 2 + sizeof(ULONG)) * lookupTable->SubTables.count);
        tableSize += extensionSize;

        // Update the amount past 0xffff and recheck to see if we still overflow
        // Use Lookup_getLookupTableSize since we also want to include the subtable offsets
        extensionSize = (ULONG)Lookup_getLookupTableSize(lookupTable, isGPOS, TRUE);
        if (lastOffsetPosition >= maxSize - extensionSize)
            // We're checking offset values so the last offset size doesn't affect how many extension subtables that there are
            // This aligns with how the build lookup function calculates the number of extensions.  It does not adjust the last offset value
            if (index != tableSizes.count - 1)
                lastOffsetPosition -= maxSize - extensionSize;
        needExtension = lastOffsetPosition > 0x0000ffff ? TRUE : FALSE;
    }
    vector_free(&tableSizes);
    return tableSize;
}


//#define EXTENSION_SIZE  ((sizeof(USHORT) * 2) + sizeof(ULONG))

static ULONG Lookup_buildLookupSubtable(TABLE_HANDLE subtable, USHORT LookupType, LF_STREAM* stream, boolean isGPOS, ULONG lookupIndex)
{
    // setup the remapped table
    BaseTable_setNextLookup(subtable, lookupIndex);

    if (isGPOS)
        return  (ULONG)GPOS_buildSubTable(LookupType, subtable, stream);

    return (ULONG)GSUB_buildSubTable(LookupType, subtable, stream);
}


static ULONG Lookup_buildLookupTable(lookup_table* table, LF_STREAM* stream, boolean isGPOS, ULONG lookupIndex)
{
    size_t tableStart = STREAM_streamPos(stream);
    ULONG subOffset = sizeof(USHORT) * 3 + (sizeof(OFFSET) * (OFFSET)table->SubTables.count);
    ULONG i;

    if(table->LookupFlag & USEMARKFILTERINGSET)
        subOffset += sizeof(USHORT);

    STREAM_writeUShort(stream, table->LookupType);
    STREAM_writeUShort(stream, table->LookupFlag);
    STREAM_writeUShort(stream, (USHORT)table->SubTables.count);

    for(i = 0; i < table->SubTables.count; i++)
    {
        TABLE_HANDLE subtable = (TABLE_HANDLE)vector_at(&table->SubTables, i);
        size_t oldPos;

        STREAM_writeUShort(stream, (USHORT)subOffset);

        oldPos = STREAM_streamPos(stream);
        STREAM_streamSeek(stream, tableStart + subOffset);

        subOffset += Lookup_buildLookupSubtable(subtable, table->LookupType, stream, isGPOS, lookupIndex);
        STREAM_streamSeek(stream, oldPos);
    }

    if(table->LookupFlag & USEMARKFILTERINGSET)
        STREAM_writeUShort(stream, table->MarkFilteringSet);

    STREAM_streamSeek(stream, tableStart + subOffset);
    return subOffset; //STREAM_streamPos(stream) - tableStart;
}

static ULONG Lookup_buildLookupExtension(lookup_table* table, ULONG extStart, LF_STREAM* stream, boolean isGPOS, ULONG lookupIndex)
{
    size_t tableStart = STREAM_streamPos(stream);
    size_t offsetPos = sizeof(USHORT) * 3 + sizeof(OFFSET) * table->SubTables.count;
    LF_STREAM extStream;
    ULONG i;

    isGPOS ? STREAM_writeUShort(stream, 9) : STREAM_writeUShort(stream, 7);
    STREAM_writeUShort(stream, table->LookupFlag);
    STREAM_writeUShort(stream, (USHORT)table->SubTables.count);

    STREAM_initMemStream(&extStream, stream->Base + extStart, stream->Length - extStart);

    for (i = 0; i < table->SubTables.count; i++)
    {
        size_t oldPos;

        STREAM_writeOffset(stream, offsetPos);
        oldPos = STREAM_streamPos(stream);
        STREAM_streamSeek(stream, tableStart + offsetPos);

        size_t startPos = STREAM_streamPos(stream);
        STREAM_writeUShort(stream, 1);
        STREAM_writeUShort(stream, table->LookupType);
        STREAM_writeULong(stream, (ULONG)(extStart - startPos));

        STREAM_streamSeek(stream, oldPos);
        offsetPos += sizeof(USHORT) * 2 + sizeof(ULONG);

        TABLE_HANDLE subtable = (TABLE_HANDLE)vector_at(&table->SubTables, i);
        extStart += Lookup_buildLookupSubtable(subtable, table->LookupType, &extStream, isGPOS, lookupIndex);
    }

    return (ULONG)(STREAM_streamPos(stream) - tableStart);
}

LF_ERROR Lookup_buildTable(TABLE_HANDLE hTable, boolean isGPOS, size_t* tableSize, BYTE** table)
{
    LF_VECTOR* lookup_list_table = (LF_VECTOR*)hTable;

    LF_VECTOR lookupOffsets;
    LF_VECTOR tableSizes;
    LF_VECTOR tableSizesKeep;		// Keeps all of the table sizes and doesn't get fixed up with extensions
    LF_VECTOR extensionList;
    ULONG offset = (ULONG)(sizeof(USHORT) + (lookup_list_table->count * sizeof(OFFSET)));
    boolean needExtension = FALSE;
    LF_STREAM stream;
    ULONG extStart = 0;

    *tableSize += offset;

    vector_init(&lookupOffsets, lookup_list_table->count, 4);
    vector_init(&tableSizes, lookup_list_table->count, 4);
    vector_init(&tableSizesKeep, lookup_list_table->count, 4);
    vector_init(&extensionList, lookup_list_table->count, 4);

    //calculate offset and lookup table sizes
    for (size_t i = 0; i < lookup_list_table->count; i++)
    {
        lookup_table* lookupTable = (lookup_table*)vector_at(lookup_list_table, i);
        ULONG lookupSize = (ULONG)Lookup_getLookupTableSize(lookupTable, isGPOS, FALSE);

        vector_push_back(&tableSizes, (void*)(intptr_t)lookupSize);
        // tableSizes is later altered with extension sizes so we need another table that is preserved
        vector_push_back(&tableSizesKeep, (void*)(intptr_t)lookupSize);
        vector_push_back(&lookupOffsets, (void*)(intptr_t)offset);
        vector_push_back(&extensionList, (void*)FALSE);

        //fprintf(stderr, "\ncalcSize[%d]\t%d", i, lookupSize);

        //needExtension = offset > 0x0000ffff ? TRUE : FALSE;
        // We need to check the offset of the last lookup
        // Also need to check the actual lookupSize to catch the boundary case where there is only 
        // a single lookup table that is bigger than 0xffff
        if (offset > 0x0000ffff || lookupSize > 0x0000ffff)
            needExtension = TRUE;
        offset += lookupSize;
        *tableSize += lookupSize;
    }

    while (needExtension)
    {
        ULONG maxSize = 0;
        size_t index = 0;
        ULONG lookupSize = 0;

        // Find the biggest lookup table
        for (size_t i = 0; i < tableSizes.count; ++i)
        {
            lookupSize = (ULONG)(intptr_t)vector_at(&tableSizes, i);

            if (lookupSize > maxSize)
            {
                maxSize = lookupSize;
                index = i;
            }
        }

        lookup_table* lookupTable = (lookup_table*)vector_at(lookup_list_table, index);
        lookupSize = (ULONG)Lookup_getLookupTableSize(lookupTable, isGPOS, TRUE);
        vector_set_data(&tableSizes, index, (void*)(intptr_t)lookupSize);
        vector_set_data(&extensionList, index, (void*)TRUE);

        *tableSize += (sizeof(USHORT) * 2 + sizeof(ULONG)) * lookupTable->SubTables.count;

        //Note that the last offset size is never adjusted since its size does not alter how many extensions must be added
        for (size_t i = index + 1; i < lookupOffsets.count; ++i)
        {
            ULONG tableOffset = (ULONG)(intptr_t)vector_at(&lookupOffsets, i);
            tableOffset -= maxSize - lookupSize;
            vector_set_data(&lookupOffsets, i, (void*)(intptr_t)tableOffset);
        }

        ULONG lastOffset = (ULONG)(intptr_t)vector_at(&lookupOffsets, lookupOffsets.count - 1);
        needExtension = lastOffset > 0x0000ffff ? TRUE : FALSE;

        //calculate start of extensions
        extStart = lastOffset + (ULONG)(intptr_t)vector_at(&tableSizes, tableSizes.count - 1);
    }
    *table = (BYTE*)calloc(1, *tableSize);
    if (*table == NULL)
        return LF_OUT_OF_MEMORY;

    STREAM_initMemStream(&stream, *table, *tableSize);

    STREAM_writeUShort(&stream, (USHORT)lookup_list_table->count);

    //write lookup offsets
    for (size_t i = 0; i < lookupOffsets.count; i++)
    {
        OFFSET tableOffset = (OFFSET)(intptr_t)vector_at(&lookupOffsets, i);
        STREAM_writeOffset(&stream, tableOffset);
    }

    for (size_t i = 0; i < lookup_list_table->count; i++)
    {
        lookup_table* lookupTable = (lookup_table*)vector_at(lookup_list_table, i);
        ULONG tableOffset = (ULONG)(intptr_t)vector_at(&lookupOffsets, i);
        boolean isExtension = (boolean)(intptr_t)vector_at(&extensionList, i);
        ULONG outSize;

        STREAM_streamSeek(&stream, tableOffset);
        if (isExtension)
        {
            outSize = Lookup_buildLookupExtension(lookupTable, extStart, &stream, isGPOS, (ULONG)i);

            // Update the position for the next extension subtable
            // First add the total size of the lookup table that was just rendered in the extension area
            // This is the value returned from Lookup_getLookupTableSize
            // Since that value includes lookup header info which is not in the extension area:
            // We need to subtract off the lookup header and subtable offsets
            extStart += (ULONG)(intptr_t)vector_at(&tableSizesKeep, i);
            extStart -= sizeof(USHORT) * 3;
            extStart -= (ULONG)(sizeof(OFFSET) * lookupTable->SubTables.count);
        }
        else
        {
            outSize = Lookup_buildLookupTable(lookupTable, &stream, isGPOS, (ULONG)i);
        }

        (void)outSize;
        //fprintf(stderr, "\noutSize[%d]\t%d", i, outSize);
    }

    vector_free(&lookupOffsets);
    vector_free(&tableSizes);
    vector_free(&tableSizesKeep);
    vector_free(&extensionList);

    return LF_ERROR_OK;
}

//LF_ERROR Lookup_buildTable2(TABLE_HANDLE hTable, boolean isGPOS, size_t* tableSize, BYTE** table)
//{
//    LF_VECTOR* lookup_list_table = (LF_VECTOR*)hTable;
//
//    *tableSize = 0;
//    *table = NULL;
//
//    if (lookup_list_table)
//    {
//        //OFFSET lookupOffset = (OFFSET)(sizeof(USHORT) + sizeof(OFFSET) * (OFFSET)lookup_list_table->count);
//        ULONG lookupOffset = (ULONG)(sizeof(USHORT) + sizeof(OFFSET) * (OFFSET)lookup_list_table->count);
//        LF_STREAM stream;
//        LF_VECTOR subtables;
//        LF_VECTOR tableSizes;
//        LF_VECTOR extensions;
//        //LF_VECTOR extOffset;
//        ULONG lastOffset = 0;
//        //ULONG endTables = 0;
//        //ULONG extIndex = 0;
//        size_t offsetsPos = 0;
//        size_t lookupsPos = 0;
//
//        //create 3 lists: subTables, sizes of each subtable and an empty extension list
//        vector_init(&subtables, lookup_list_table->count, 4);
//        vector_init(&tableSizes, lookup_list_table->count, 4);
//        vector_init(&extensions, 4, 4);
//        //vector_init(&extOffset, 4, 4);
//
//        *tableSize = sizeof(USHORT) + sizeof(OFFSET) * lookup_list_table->count;
//
//        for (size_t i = 0; i < lookup_list_table->count; i++)
//        {
//            lookup_table* lookupTable = (lookup_table*)vector_at(lookup_list_table, i);
//            ULONG lookupSize = Lookup_getLookupTableSize(lookupTable, isGPOS, FALSE);
//            vector_push_back(&subtables, lookupTable);
//            vector_push_back(&extensions, NULL);
//            vector_push_back(&tableSizes, (void*)lookupSize);
//
//            lastOffset = lookupOffset;
//            lookupOffset += (OFFSET)lookupSize;
//            *tableSize += lookupSize;
//            //endTables = *tableSize;
//        }
//
//        while (lastOffset > 0x0000ffff)
//        {
//            ULONG maxSize = 0;
//            ULONG tableIndex = 0;
//            lookup_table* lookupTable = NULL;
//
//            //find the largest table
//            for (size_t i = 0; i < tableSizes.count; i++)
//            {
//                ULONG size = (ULONG)vector_at(&tableSizes, i);
//
//                if (size > maxSize)
//                {
//                    maxSize = size;
//                    tableIndex = i;
//                }
//            }
//
//            //remove lookup table and replace it with extension table
//            lookupTable = (lookup_table*)vector_at(&subtables, tableIndex);
//            //vector_push_back(&extensions, lookupTable);
//            vector_set_data(&extensions, tableIndex, lookupTable);
//            vector_set_data(&subtables, tableIndex, NULL);
//
//            lastOffset -= maxSize - EXTENSION_SIZE;
//            //endTables -= maxSize - EXTENSION_SIZE;
//            *tableSize += EXTENSION_SIZE;
//        }
//
//        //*tableSize = Lookup_getDataSize(hTable, isGPOS);
//
//        *table = (BYTE*)calloc(1, *tableSize);
//        if (*table == NULL)
//            return LF_OUT_OF_MEMORY;
//
//        STREAM_initMemStream(&stream, *table, *tableSize);
//        STREAM_writeUShort(&stream, (USHORT)lookup_list_table->count);
//        offsetsPos = STREAM_streamPos(&stream);
//        lookupsPos = offsetsPos + sizeof(OFFSET) * lookup_list_table->count;
//        //lookupOffset = lookupsPos;
//
//        //lookupOffset = (ULONG)(sizeof(USHORT) + sizeof(OFFSET) * (OFFSET)lookup_list_table->count);
//
//        for (size_t i = 0; i < subtables.count; i++)
//        {
//            lookup_table* lookupTable = (lookup_table*)vector_at(&subtables, i);
//
//            //write the lookup table offset
//            STREAM_streamSeek(&stream, offsetsPos);
//            STREAM_writeOffset(&stream, lookupsPos);
//            offsetsPos += sizeof(OFFSET);
//
//            //write the lookup table
//            STREAM_streamSeek(&stream, lookupsPos);
//
//            if (lookupTable)
//            {
//                lookupsPos += Lookup_buildLookupTable(lookupTable, &stream, isGPOS, (ULONG)i);
//            }
//            else
//            {
//                lookupTable = (lookup_table*)vector_at(&extensions, i);
//                lookupsPos += Lookup_buildLookupExtension(lookupTable, 0, &stream, isGPOS, (ULONG)i);
//            }
//        }
//
//        STREAM_streamSeek(&stream, lookupsPos);
//        offsetsPos = 0;
//
//        for (size_t i = 0; i < extensions.count; i++)
//        {
//            lookup_table* lookupTable = (lookup_table*)vector_at(&extensions, i);
//            OFFSET offset = 0;
//            offsetsPos += sizeof(USHORT);
//
//            if (lookupTable)
//            {
//                STREAM_streamSeek(&stream, offsetsPos);
//                offset = STREAM_readOffset(&stream) + (sizeof(USHORT) * 3);
//                STREAM_streamSeek(&stream, offset);
//
//                lookupsPos += Lookup_buildLookupTable(lookupTable, &stream, isGPOS, (ULONG)i);
//            }
//        }
//
//        vector_free(&subtables);
//        vector_free(&tableSizes);
//        vector_free(&extensions);
//
//        STREAM_streamSeek(&stream, 0);
//        Lookup_readListTable(&stream, isGPOS);
//    }
//
//    return LF_ERROR_OK;
//}

/* ============================================================================
    @summary
        remove a glyph from the subtables in GPOS/GSUB depending on the
        passed parameter.

    @description
        this function will go through all of the subtables assigned to
        the gpos/gsub and remove one glyph from the subtable.  the return
        value if EMPTY, will remove the lookup table from the lookup
        table list.

        the outer loop manages all of the lookups in the list.  if the
        subtable list comes back empty, it will remove the reference
        to the empty table.  However, some cleanup has to be done to
        the FeatureTable and rules that use LookupRecords.  These records
        refer to specific lookup tables, and therefore need to be remapped
        if we remove one.

    @param
        hTable = pointer to Lookup list table.
        hFeature = pointer to Feature table.
        index = glyph ID to remove
        isGPOS = true - GPOS Lookup list, otherwise GSUB Lookup list.

    @notes
        removing empty tables is conditional at this point to make debugging
        simpler.  for example, if you want to debug removal on a specific
        lookup table (i.e. 4), it is easier to trace if no tables are be
        removed previously.

        for the same reason as above, the lookup table cleanup is also
        condition at this point to make debugging easier.

============================================================================ */
LF_ERROR Lookup_removeGlyph(TABLE_HANDLE hTable, TABLE_HANDLE hHeader, ULONG index, boolean isGPOS)
{
    LF_VECTOR* lookup_list_table = (LF_VECTOR*)hTable;

    if (lookup_list_table)
    {
        ULONG i = 0, j = 0;
        LF_ERROR error = LF_ERROR_OK;


        while(i < lookup_list_table->count)
        {
            lookup_table* lookupTable = (lookup_table*)vector_at(lookup_list_table, i);

            j = 0;            // reset the subtable iterator

            while (j < lookupTable->SubTables.count)
            {
                TABLE_HANDLE subtable = (TABLE_HANDLE)vector_at(&lookupTable->SubTables, j);

                if (subtable)
                {
                    if(isGPOS)
                    {
                        error = GPOS_subtableRemoveGlyph(lookupTable->LookupType, subtable, index);
                    }
                    else
                    {
                        error = GSUB_subtableRemoveGlyph(lookupTable->LookupType, subtable, index);
                    }
#if REMOVE_SUBTABLE
                    // check if the subtable returned empty...
                    if (error == LF_EMPTY_TABLE)
                    {
                        if (isGPOS)
                        {
                            GPOS_freeSubtable(lookupTable->LookupType, subtable);
                        }
                        else
                        {
                            GSUB_freeSubtable(lookupTable->LookupType, subtable);
                        }
                        vector_erase(&lookupTable->SubTables, j);

                    }
                    else
#endif
                    {
                        j++;    // advance  subtable iterator
                    }
                }
            }


#if DELETE_EMPTY_SUBTABLES

            if (lookupTable->SubTables.count == 0)
            {
                TABLE_HANDLE hFeature;
                TABLE_HANDLE hScript;

                vector_free(&lookupTable->SubTables);
                free(lookupTable);
                vector_erase(lookup_list_table, i);
                hFeature = Lookup_getFeatureTable(hHeader, isGPOS);
                hScript  = Lookup_getScriptTable(hHeader, isGPOS);

                Lookup_removeLookupIndex(hTable, (USHORT)i, isGPOS);
                error = Feature_removeLookupIndex(hFeature, hScript, (USHORT)i, -1);
                if (error == LF_EMPTY_TABLE)
                    return error;
            }
            else
            {
                i++;            // advance the table iterator
            }
#else
            i++;                // advance the table iterator
#endif
        }
    }
    return LF_ERROR_OK;
}

static void Lookup_freeTable(lookup_table* lookupTable, boolean isGPOS)
{
    ULONG j = 0;

    while (j < lookupTable->SubTables.count)
    {
        TABLE_HANDLE subtable = (TABLE_HANDLE)vector_at(&lookupTable->SubTables, j++);

        if (isGPOS)
        {
            GPOS_freeSubtable(lookupTable->LookupType, subtable);
        }
        else
        {
            GSUB_freeSubtable(lookupTable->LookupType, subtable);
        }
    }

    vector_free(&lookupTable->SubTables);
    free(lookupTable);
}

LF_ERROR Lookup_freeTableList(TABLE_HANDLE hTable, boolean isGPOS)
{
    LF_VECTOR* lookup_list_table = (LF_VECTOR*)hTable;
    if (lookup_list_table)
    {
        ULONG i = 0;

        while (i < lookup_list_table->count)
        {
            lookup_table* lookupTable = (lookup_table*)vector_at(lookup_list_table, i++);

            Lookup_freeTable(lookupTable, isGPOS);
        }

        vector_free(lookup_list_table);
        free(lookup_list_table);
    }
    return LF_ERROR_OK;
}

/* ============================================================================
    @desc
        remove the lookup index from all of the lookup records and remap
        all of the indices accordingly.

============================================================================ */
static LF_ERROR Lookup_removeLookupIndex(TABLE_HANDLE hTable, USHORT refIndex, boolean isGPOS)
{
    LF_VECTOR* lookup_list_table = (LF_VECTOR*)hTable;

    ULONG i, j = 0;
    LF_ERROR error = LF_ERROR_OK;

    for(i = 0; i < lookup_list_table->count; i++)
    {
        lookup_table* lookupTable = (lookup_table*)vector_at(lookup_list_table, i);

        j = 0;
        while (j < lookupTable->SubTables.count)
        {
            TABLE_HANDLE subtable = (TABLE_HANDLE)vector_at(&lookupTable->SubTables, j);

            if(isGPOS)
            {
                error = GPOS_removeLookupIndexSubtable(lookupTable->LookupType, subtable, refIndex, -1);
            }
            else
            {
                error = GSUB_removeLookupIndexSubtable(lookupTable->LookupType, subtable, refIndex, -1);
            }

#if REMOVE_SUBTABLE
            // check if the subtable returned empty...
            if (error == LF_EMPTY_TABLE)
            {
                if (isGPOS)
                {
                    GPOS_freeSubtable(lookupTable->LookupType, subtable);
                }
                else
                {
                    GSUB_freeSubtable(lookupTable->LookupType, subtable);
                }
                vector_erase(&lookupTable->SubTables, j);
            }
            else
#endif
            {
                j++;
            }
        }
    }
    return LF_ERROR_OK;
}

LF_ERROR Lookup_pruneLookups(TABLE_HANDLE hTable, TABLE_HANDLE hHeader, boolean isGPOS)
{
    LF_VECTOR* lookup_list_table = (LF_VECTOR*)hTable;
    if (lookup_list_table)
    {
        ULONG i = 0, j = 0;
        LF_ERROR error = LF_ERROR_OK;


        while(i < lookup_list_table->count)
        {
            lookup_table* lookupTable = (lookup_table*)vector_at(lookup_list_table, i);

            j = 0;            // reset the subtable iterator

            while (j < lookupTable->SubTables.count)
            {
                TABLE_HANDLE subtable = (TABLE_HANDLE)vector_at(&lookupTable->SubTables, j);

                if (subtable)
                {
                    if(isGPOS)
                    {
                        error = GPOS_pruneLookupRecords(lookupTable->LookupType, subtable);
                    }
                    else
                    {
                        error = GSUB_pruneLookupRecords(lookupTable->LookupType, subtable);
                    }

#if REMOVE_SUBTABLE
                    // check if the subtable returned empty...
                    if (error == LF_EMPTY_TABLE)
                    {
                        if (!isGPOS)
                        {
                            GSUB_freeSubtable(lookupTable->LookupType, subtable);
                        }
                        else
                        {
                            GPOS_freeSubtable(lookupTable->LookupType, subtable);
                        }

                        vector_erase(&lookupTable->SubTables, j);
                    }
                    else
#endif
                    {
                        j++;
                    }
                }
            }
#if DELETE_EMPTY_SUBTABLES
            if (lookupTable->SubTables.count == 0)
            {
                TABLE_HANDLE hFeature;
                TABLE_HANDLE hScript;
                vector_free(&lookupTable->SubTables);
                free(lookupTable);
                vector_erase(lookup_list_table, i);

                hFeature = Lookup_getFeatureTable(hHeader, isGPOS);
                hScript  = Lookup_getScriptTable(hHeader, isGPOS);

                // cleanup the lookup tables
                Lookup_removeLookupIndex(hTable, (USHORT)i, isGPOS);
                Feature_removeLookupIndex(hFeature, hScript, (USHORT)i, -1);
            }
            else
            {
                i++;            // advance the table iterator
            }
#else
            i++;                // advance the table iterator
#endif
        }
    }
    return LF_ERROR_OK;
}

LF_ERROR Lookup_remapTables(TABLE_HANDLE hTable, LF_MAP* remap, boolean isGPOS)
{
    LF_VECTOR*   lookup_list_table = (LF_VECTOR*)hTable;
    ULONG        i = 0, j = 0;

    if (lookup_list_table == NULL)
        return LF_INVALID_INDEX;

    while(i < lookup_list_table->count)
    {
        lookup_table* lookupTable = (lookup_table*)vector_at(lookup_list_table, i);

        j = 0;            // reset the subtable iterator

        while (j < lookupTable->SubTables.count)
        {
            TABLE_HANDLE subtable = (TABLE_HANDLE)vector_at(&lookupTable->SubTables, j);

            if (subtable)
            {
                LF_ERROR     error;

                if(isGPOS)
                {
                    error = GPOS_subtableRemapGlyph(lookupTable->LookupType, subtable, remap);
                }
                else
                {
                    error = GSUB_subtableRemapGlyph(lookupTable->LookupType, subtable, remap);
                }

                j++;    // advance  subtable iterator

                (void)error;  //unused TODO, just remove the variable? looks like could return NOT_COVERED which would not be an error
            }
        }

        i++;
    }

    return LF_ERROR_OK;
}

#ifdef LF_OT_DUMP
LF_ERROR Lookup_dumpTables(TABLE_HANDLE hTable, boolean isGPOS)
{
    LF_VECTOR*   lookup_list_table = (LF_VECTOR*)hTable;
    ULONG        i = 0, j = 0;

    if (lookup_list_table == NULL)
        return LF_INVALID_INDEX;

    XML_START("LookupTables");
    while(i < lookup_list_table->count)
    {
        lookup_table* lookupTable = (lookup_table*)vector_at(lookup_list_table, i);

        j = 0;            // reset the subtable iterator
        XML_START_COMMENT("LookupTable", i , (int)lookup_list_table->count - 1);

        while (j < lookupTable->SubTables.count)
        {
            TABLE_HANDLE subtable = (TABLE_HANDLE)vector_at(&lookupTable->SubTables, j);

//            XML_START_COMMENT("LookupSubTable", j, lookupTable->SubTables.count - 1);

            if (subtable)
            {
                LF_ERROR     error;
#if _DEBUG
                base_table* base = (base_table*)subtable;

                if (base->refCount == 0)
                    DEBUG_LOG("not referenced");
#endif

                if(isGPOS == FALSE)
                {
                    error = GSUB_dumpSubtable(lookupTable->LookupType, subtable);
                }
                else
                {
                    error = GPOS_dumpSubtable(lookupTable->LookupType, subtable);
                }

                (void)error; //unused TODO remove variable??

                j++;    // advance  subtable iterator

            }
//            XML_END("LookupSubTable");
        }

        i++;
        XML_END("LookupTable");
    }
    XML_END("LookupTables");

    return LF_ERROR_OK;
}
#endif

TABLE_HANDLE Lookup_getFeatureTable(TABLE_HANDLE hHandle, boolean isGPOS)
{
    TABLE_HANDLE hFeature = NULL;

    if (isGPOS == FALSE)
    {
        gsub_header* gsub = (gsub_header*)hHandle;
        hFeature = gsub->FeatureList;
    }
    else
    {
        gpos_header* gpos = (gpos_header*)hHandle;
        hFeature = gpos->FeatureList;
    }

    return hFeature;
}

TABLE_HANDLE Lookup_getScriptTable(TABLE_HANDLE hHandle, boolean isGPOS)
{
    TABLE_HANDLE hScript = NULL;

    if (isGPOS == FALSE)
    {
        gsub_header* gsub = (gsub_header*)hHandle;
        hScript = gsub->ScriptList;
    }
    else
    {
        gpos_header* gpos = (gpos_header*)hHandle;
        hScript = gpos->ScriptList;
    }

    return hScript;
}

void Lookup_cleanupLookups(TABLE_HANDLE hLookups, USHORT lookupIndex)
{
    LF_VECTOR*    lookup_list_table = (LF_VECTOR*)hLookups;
    if (lookup_list_table == NULL)
        return;

    lookup_table* lookupTable = (lookup_table*)vector_at(lookup_list_table, lookupIndex);

    if (lookupTable)
    {
        ULONG j = 0;                                // reset the subtable iterator

        while (j < lookupTable->SubTables.count)
        {
            TABLE_HANDLE subtable = (TABLE_HANDLE)vector_at(&lookupTable->SubTables, j);

            if (subtable)
            {
                if (((base_table*)subtable)->type == TABLETYPE_GSUB)
                {
                    GSUB_cleanupLookupSubtables(lookupTable->LookupType, subtable, hLookups);
                }
                else
                {
                    GPOS_cleanupLookupSubtables(lookupTable->LookupType, subtable, hLookups);
                }

                j++;    // advance  subtable iterator
            }
        }
    }
}

/* ----------------------------------------------------------------------------
    @summary
        remove unreference lookups from the lookup tables and remap
        all of the lookup records and feature table.
---------------------------------------------------------------------------- */
LF_ERROR Lookup_removeUnReferencedLookups(TABLE_HANDLE hTable, TABLE_HANDLE hHeader, boolean isGPOS)
{
    ULONG        i = 0;
    ULONG        j = 0;

    LF_VECTOR* lookup_list_table = (LF_VECTOR*)hTable;
    if (lookup_list_table == NULL)
        return LF_INVALID_SUBTABLE;

    while(i < lookup_list_table->count)
    {
        lookup_table* lookupTable = (lookup_table*)vector_at(lookup_list_table, i);

        j = 0;                                // reset the subtable iterator

        while (j < lookupTable->SubTables.count)
        {
            TABLE_HANDLE subtable = (TABLE_HANDLE)vector_at(&lookupTable->SubTables, j);
            base_table* base = (base_table*)subtable;


            if (base->refCount == 0)
            {
//                if (base->type == TABLETYPE_GSUB)
//                    isGPOS = FALSE;
//                else
//                    isGPOS = TRUE;

                if (!isGPOS)
                {
                    GSUB_freeSubtable(lookupTable->LookupType, subtable);
                }
                else
                {
                    GPOS_freeSubtable(lookupTable->LookupType, subtable);
                }
                vector_erase(&lookupTable->SubTables, j);
            }
            else
            {
                j++;
            }
        }
        if (lookupTable->SubTables.count == 0)
        {
            TABLE_HANDLE hFeature;
            TABLE_HANDLE hScript;
            vector_free(&lookupTable->SubTables);
            free(lookupTable);
            vector_erase(lookup_list_table, i);

            hFeature = Lookup_getFeatureTable(hHeader, isGPOS);
            hScript  = Lookup_getScriptTable(hHeader, isGPOS);

            // cleanup the lookup tables
            Lookup_removeLookupIndex(hTable, (USHORT)i, isGPOS);
            Feature_removeLookupIndex(hFeature, hScript, (USHORT)i, -1);
        }
        else
        {
            i++;            // advance the table iterator
        }
    }
    return LF_ERROR_OK;
}

LF_ERROR Lookup_clearGDEFFlags(TABLE_HANDLE hTable)
{
    LF_VECTOR* lookups = (LF_VECTOR*)hTable;
    if (lookups == NULL)
        return LF_INVALID_SUBTABLE;

    for (size_t i = 0; i < lookups->count; ++i)
    {
        lookup_table* lookupTable = (lookup_table*)vector_at(lookups, i);

        lookupTable->LookupFlag &= ~(IGNORE_BASE_GLYPHS | IGNORE_LIGATURES | IGNORE_MARKS);
    }

    return LF_ERROR_OK;
}

void Lookup_clearCollectFlags(TABLE_HANDLE hTable)
{
    gsub_header* gsub = (gsub_header*)hTable;

    if (NULL == gsub->LookupList)
        return;

    // NOTE: if you get an error here, please update VS2013 to the latest version (12.0.31101.00 Update 4)

    LF_VECTOR* lookupList = (LF_VECTOR*)gsub->LookupList;

    for (size_t i = 0; i < lookupList->count; i++)
    {
        lookup_table* lookupTable = (lookup_table*)vector_at(lookupList, i);
        lookupTable->Base.collected = FALSE;
    }
}

LF_ERROR Lookup_collectUncollectedAlternateGlyphs(GlyphList* keepList, TABLE_HANDLE hTable)
{
    gsub_header* gsub = (gsub_header*)hTable;
    LF_VECTOR* lookipList = (LF_VECTOR*)gsub->LookupList;

    //GlyphList* keepList = Keep_getGlyphList(font);

    LF_ERROR error = LF_ERROR_OK;

    if (lookipList != NULL)
    {
        for (size_t i = 0; i < lookipList->count; i++)
        {
            lookup_table* lookupTable = (lookup_table*)vector_at(lookipList, i);

            if ((lookupTable->Base.collected == FALSE) && (lookupTable->LookupType == GSUB_LOOKUP_ALTERNATE))
            {
                for (size_t j = 0; j < lookupTable->SubTables.count; ++j)
                {
                    TABLE_HANDLE subtable = (TABLE_HANDLE)vector_at(&lookupTable->SubTables, j);
                    error = GSUB_collectSubtableGlyphs(keepList, hTable, lookupTable->LookupType, subtable);

                    if (!((error == LF_ERROR_OK) || (error == LF_ADDED_GLYPH) || (error == LF_NOT_COVERED)))
                        break;
                }
            }
        }

        if ((error == LF_ADDED_GLYPH) || (error == LF_NOT_COVERED))
            error = LF_ERROR_OK;
    }

    return error;
}

LF_ERROR Lookup_collectGlyphs(GlyphList* keepList, TABLE_HANDLE hTable, USHORT lookupIndex)
{
    LF_ERROR error = LF_INVALID_INDEX;
    gsub_header* gsub = (gsub_header*)hTable;
    LF_VECTOR* lookup_list_table = (LF_VECTOR*)gsub->LookupList;
    lookup_table* lookupTable = (lookup_table*)vector_at(lookup_list_table, lookupIndex);

    ULONG j = 0;            // reset the subtable iterator

    while (j < lookupTable->SubTables.count)
    {
        TABLE_HANDLE subtable = (TABLE_HANDLE)vector_at(&lookupTable->SubTables, j);

        if (subtable)
        {
            LF_ERROR status = GSUB_collectSubtableGlyphs(keepList, hTable, lookupTable->LookupType, subtable);
            if (status == LF_ADDED_GLYPH)
            {
                error = status;
            }
            j++;
        }
    }

    lookupTable->Base.collected = TRUE;

    return error;
}
