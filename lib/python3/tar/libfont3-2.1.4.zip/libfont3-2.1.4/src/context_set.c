// Copyright (C) 2014, 2015 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// context_set.c

#include "context_set.h"
#include "context_rule.h"
#include "stream.h"
#include "utils.h"

/* ============================================================================
    @description
        read in the complete rule set given a number of sets and a 
        stream to retrieve the sets from.

    @param
        rulesets      : pointer to vector collection to draw from
        numSets       : the number of sets contained in the stream
        stream        : pointer to the stream to read from
        baseOffset    : starting position in the stream for this table which
                        all of the OFFSET values are based upon.

============================================================================ */
LF_ERROR ContextSet_readRuleSets(LF_VECTOR* rulesets, USHORT numSets, LF_STREAM* stream, ULONG baseOffset)
{
    USHORT      n;
    LF_ERROR    error = LF_ERROR_OK;
    size_t       curOffset, newOffset;

    for (n = 0; n < numSets; n++)
    {
        context_rule_set* prs;
        newOffset = STREAM_readUShort(stream) + baseOffset;
        curOffset = STREAM_streamPos(stream);
        STREAM_streamSeek(stream, newOffset);

        prs = (context_rule_set*)calloc(1, sizeof(context_rule_set));

        if (!prs)
        {
            return LF_OUT_OF_MEMORY;
        }

        error = ContextSet_readRuleSet(prs, stream);
        STREAM_streamSeek(stream, curOffset);

        if (error != LF_ERROR_OK)
        {
            free(prs);
            return error;
        }

        vector_push_back(rulesets, prs);
    }
    return error;
}

/* ----------------------------------------------------------------------------
    @summary
        read in a sub-rule set from the stream into the passed srs 
        structure.
---------------------------------------------------------------------------- */
LF_ERROR ContextSet_readRuleSet(context_rule_set* srs, LF_STREAM* stream)
{
    LF_ERROR                error;
    USHORT                  n, count;
    size_t                   curOffset, newOffset, baseOffset;
    context_rule*           sr;

    baseOffset = STREAM_streamPos(stream);
    count = STREAM_readUShort(stream);                           // how many sub rules are in the set.
    vector_init(&srs->RuleSet, count, sizeof(ULONG));            // create a list to hold the sub-rules

    // loop through the sub-rules in the set
    for ( n = 0; n < count; n++)
    {
        // create a structure to hold the sub-rule
        sr = (context_rule*)calloc(1, sizeof(context_rule));
        if (!sr)
        {
            error = LF_OUT_OF_MEMORY;
            goto Fail1;
        }

        newOffset = STREAM_readUShort(stream) + baseOffset;
        curOffset = STREAM_streamPos(stream);
        STREAM_streamSeek(stream, newOffset);

        error = ContextRule_readRule(sr, stream);            // read in subtable
        if (error != LF_ERROR_OK)
        {
            goto Fail1;                                      // problem reading subtable, so bail
        }

        STREAM_streamSeek(stream, curOffset);
        vector_push_back(&srs->RuleSet, sr);
    }

    return LF_ERROR_OK;

Fail1:
    ContextSet_freeRuleSets(&srs->RuleSet);
    return error;
}

/* ----------------------------------------------------------------------------
    @summary
        free all of the context rule sets in the collection.

    @param
        list = pointer to the vector array
---------------------------------------------------------------------------- */
void ContextSet_freeRuleSets(LF_VECTOR* rss)
{
    ULONG i = 0;
    ASSERT(rss);

    while (i < rss->count)
    {
        context_rule_set* rs = (context_rule_set*)vector_at(rss, i++);
        ContextSet_freeRuleSet(rs);
        free(rs);
    }
    vector_delete(rss);
}

/* ----------------------------------------------------------------------------
    @summary
        given a vector collection of context_rule structure, free all of the
        collection and remove the vector contents.

    @param
        list = pointer to the vector array
---------------------------------------------------------------------------- */
static void contextSet_freeRules(LF_VECTOR* rss)
{
    ULONG i = 0;
    ASSERT(rss);

    while (i < rss->count)
    {
        context_rule* cr = (context_rule*)vector_at(rss, i++);
        
        ASSERT(cr);
        ContextRule_freeRule(cr);

        FREE(cr);
    }
}

void ContextSet_freeRuleSet(context_rule_set* crs)
{
    LF_VECTOR* ruleset = &crs->RuleSet;
    contextSet_freeRules(ruleset);
    vector_delete(ruleset);
}

size_t ContextSet_sizeRuleSets(LF_VECTOR* rulesets)
{
    USHORT count = UTILS_getCount(rulesets);
    USHORT n;
    size_t size = 0;
    for (n = 0; n < count; n++)
    {
        context_rule_set* crs = (context_rule_set*)vector_at(rulesets, n);
        size += ContextSet_sizeRuleSet(crs);            // Context Rule Set size
    }

    return size;
}

/* ----------------------------------------------------------------------------
    @summary
        return the size of the sub-rule set.

    SubRuleSet table
        USHORT            SubRuleCount
        OFFSET            SubRule[SubRuleCount]

---------------------------------------------------------------------------- */
size_t ContextSet_sizeRuleSet(context_rule_set* srs)
{
    size_t     size;
    USHORT    n, count;

    count = UTILS_getCount(&srs->RuleSet);                // how many sub-rules

    size =  sizeof(USHORT);                               // SubRuleCount
    size +=    sizeof(OFFSET) * count;                    // array of offsets for the sets

    // loop through the sub-rules
    for ( n = 0; n < count; n++)
    {
        context_rule* sr = (context_rule*)vector_at(&srs->RuleSet, n);
        size += ContextRule_sizeRule(sr);
    }
    return size;
}
/* ----------------------------------------------------------------------------
    @summary
        this will build the a sub-rule set
---------------------------------------------------------------------------- */
size_t ContextSet_buildRuleSet(context_rule_set* srs, LF_STREAM* stream)
{
    size_t    baseOffset = STREAM_streamPos(stream);    // save the start of the sub-rule set table
    size_t    offset, curOffset;
    USHORT  n, count;
    size_t    offsetArray;
    count = (USHORT)srs->RuleSet.count;

    STREAM_writeUShort(stream, count);                 // write SubRuleCount
    offsetArray = STREAM_streamPos(stream);            // save the start of the array of offsets

    // loop through all of the sub-rules.
    for ( n = 0; n < count; n++)
    {
        STREAM_writeUShort(stream, 0);                 // write out placeholder array of offset
    }

    // According to documentation, Array offsets to SubRule tables are from
    // the beginning of SubRuleSet table - ordered by preference.  This is
    // the beginning of the sub-rule set table and this loop will write out
    // all of the rules
    for ( n = 0; n < count; n++)
    {
        context_rule* sr = (context_rule*)vector_at(&srs->RuleSet, n);

        curOffset = STREAM_streamPos(stream);
        offset = curOffset - baseOffset;
        STREAM_streamSeek(stream, offsetArray);
        STREAM_writeOffset(stream, (OFFSET)offset);
        offsetArray += sizeof(OFFSET);
        STREAM_streamSeek(stream, curOffset);

        ContextRule_buildRule(sr, stream);
    }
    return STREAM_streamPos(stream);
}

#ifdef LF_OT_DUMP
void ContextSet_dumpSet(context_rule_set* crs)
{
    ULONG i;

    DEBUG_LOG_VALUE("RuleSetCount: ", (int)crs->RuleSet.count);
    for (i = 0; i < crs->RuleSet.count; i++)
    {
        context_rule* cr = (context_rule*)vector_at(&crs->RuleSet, i);

        DEBUG_LOG_VALUE("ContextRule Index: ", i);
        if (cr)
        {
            ContextRule_dumpRule(cr);
        }
    }
}
#endif

LF_ERROR ContextSet_pruneRuleSets(LF_VECTOR* RuleSets, coverage_table* table, GlyphID glyphid)
{
    USHORT n = 0;
    USHORT m;
    USHORT index = 0;
    while (n < RuleSets->count)
    {
        context_rule_set* crs = (context_rule_set*)vector_at(RuleSets, n);
        if (NULL == crs)
            return LF_BAD_FORMAT;

        m = 0;
        while (m < crs->RuleSet.count)
        {
            context_rule* cr = (context_rule*)vector_at(&crs->RuleSet, m);
            LF_ERROR status = ContextRule_searchRule(cr, glyphid, &index);

            if (status == LF_ERROR_OK)
            {
                DEBUG_LOG_VALUE("removing empty ContextRule", m);
                ContextRule_freeRule(cr);
                FREE(cr);
                vector_erase(&crs->RuleSet, m);
            }
            else
            {
                m++;
            }
        }

        if (crs->RuleSet.count == 0)
        {
            DEBUG_LOG_VALUE("removing empty ContextRuleSet", n);
            ContextSet_freeRuleSet(crs);
            FREE(crs);
            vector_erase(RuleSets, n);

            Coverage_eraseIndex(table, n);
        }
        else
        {
            n++;
        }
    }

    if (RuleSets->count == 0)
        return LF_EMPTY_TABLE;

    return LF_ERROR_OK;
}

LF_ERROR ContextSet_remapRuleSets(LF_VECTOR* RuleSets, LF_MAP *remap)
{
    USHORT i, numRuleSets;
    LF_ERROR err;

    numRuleSets = (USHORT)vector_size(RuleSets);

    for(i = 0; i < numRuleSets; i++)
    {
        USHORT j, numRules;
        context_rule_set* crs = (context_rule_set*)vector_at(RuleSets, i);

        numRules = (USHORT)vector_size(&crs->RuleSet);

        for(j = 0; j < numRules; j++)
        {
            context_rule *cr = (context_rule *)vector_at(&crs->RuleSet, j);

            err = ContextRule_remapRule(cr, remap);
            if (err != LF_ERROR_OK)
                return err;
        }
    }

    return LF_ERROR_OK;
}

LF_ERROR ContextSet_cleanupLookups(LF_VECTOR* RuleSets, TABLE_HANDLE hLookups)
{
    USHORT i, numRuleSets;

    numRuleSets = (USHORT)vector_size(RuleSets);

    for(i = 0; i < numRuleSets; i++)
    {
        USHORT j, numRules;
        context_rule_set* crs = (context_rule_set*)vector_at(RuleSets, i);

        numRules = (USHORT)vector_size(&crs->RuleSet);

        for(j = 0; j < numRules; j++)
        {
            context_rule *cr = (context_rule *)vector_at(&crs->RuleSet, j);
            ContextRule_cleanupLookups(cr, hLookups);
        }
    }
    return LF_ERROR_OK;
}

/* ============================================================================
    @summary
        check if the coverage and context rule exists using 
        the keep table to check against.  if the context exists,
        then the substitution will be added to the keep table.

        otherwise, it will skip the context rule within the set.

    @param
        keepList        :    pointer to glyph ids to keep
        RuleSets        :    pointer to the LF_VECTOR collection
        hTable          :    pointer to the gsub_table structure
        coverageTable   :    pointer to the coverage table for this
                             RuleSet collection.  one coverage for
                             each of the RuleSets.

    @return
        LF_ERROR_OK     :    parsed the rule, and nothing was added or
                             existed in the RuleSets

        LF_ADDED_GLYPH  :    one or more RuleSets matched up with the
                             keep glyph table, so the substitution was
                             added to the keep table.

============================================================================ */
LF_ERROR ContextSet_collectGlyphs(GlyphList* keepList, LF_VECTOR* RuleSets, TABLE_HANDLE hTable, TABLE_HANDLE coverageTable)
{
    LF_ERROR          error = LF_ERROR_OK;
    coverage_table*   coverage = (coverage_table*)coverageTable;
    USHORT            i, numRuleSets;

    numRuleSets = (USHORT)vector_size(RuleSets);

    for(i = 0; i < numRuleSets; i++)
    {
        USHORT j, numRules;
        GlyphID coverageGlyph;

        LF_ERROR status = Coverage_getCoverageAt(coverage, i, &coverageGlyph);
        if (status != LF_ERROR_OK)
        {
            DEBUG_LOG_ERROR("coverage out of sync with Context Set");
            continue;
        }

        if (Keep_coverageExists(keepList, coverageGlyph) == LF_ERROR_OK)
        {
            context_rule_set* crs = (context_rule_set*)vector_at(RuleSets, i);

            numRules = (USHORT)vector_size(&crs->RuleSet);

            for(j = 0; j < numRules; j++)
            {
                context_rule *cr = (context_rule *)vector_at(&crs->RuleSet, j);

                status = ContextRule_collectGlyphs(cr, keepList, hTable);
                if (status == LF_ADDED_GLYPH)
                {
                    error = status;
                }
            }
        }
    }
    return error;
}
