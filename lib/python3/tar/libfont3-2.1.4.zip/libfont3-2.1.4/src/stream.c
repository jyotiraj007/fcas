// Copyright (C) 2014 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// stream.c

#include <string.h>
#include <stdlib.h>
#ifndef WIN32
#include <math.h>
#endif
#include "stream.h"
#include "utils.h"

// private functions
static boolean stream_Validate(LF_STREAM* stream, size_t size, boolean read);



static BYTE readByte(LF_FILE* file)
{
    BYTE value;
    fread(&value, sizeof(BYTE), 1, file);

    return value;
}

static INLINE size_t writeByte(LF_FILE* file, BYTE value)
{
    return fwrite(&value, sizeof(BYTE), 1, file);
}

static USHORT readUShort(LF_FILE* stream)
{
    USHORT value;
    fread(&value, sizeof(USHORT), 1, stream);

    value = SWAP_USHORT(value);

    return value;
}

static INLINE size_t writeUShort(LF_FILE* file, USHORT value)
{
    return fwrite(&value, sizeof(USHORT), 1, file);
}

static ULONG readULong(LF_FILE* file)
{
    ULONG value;
    fread(&value, sizeof(ULONG), 1, file);

    value = SWAP_ULONG(value);

    return value;
}

static INLINE size_t writeULong(LF_FILE* file, ULONG value)
{
    return fwrite(&value, sizeof(ULONG), 1, file);
}

static LONGDATETIME readLongDateTime(LF_FILE* file)
{
    LONGDATETIME value;
    fread(&value, sizeof(LONGDATETIME), 1, file);

    //value = SWAP_ULONG(value); //FIX!!

    return value;
}

static INLINE size_t writeLongDateTime(LF_FILE* file, LONGDATETIME value)
{
    return fwrite(&value, sizeof(LONGDATETIME), 1, file);
}

static INLINE size_t writeChunk(LF_FILE* file, const BYTE* data, size_t len)
{
    return fwrite(data, len, 1, file);
}

// seek to a global position in the file
static INLINE LONG fileSeek(LF_FILE* stream, int32_t pos)
{
    LONG error = 0;
    if (stream != NULL) {
        error = fseek(stream, pos, SEEK_SET);
    }

    return error;
}

static INLINE size_t filePos(LF_FILE* file)
{
    if (file != NULL) {
        return ftell(file);
    }
    return (size_t)-1;
}

static void STREAM_initStream(LF_STREAM* stream)
{
    memset((void*)stream, 0, sizeof(LF_STREAM));
}


// streaming constructors
void    STREAM_openStream(LF_STREAM* stream, eSTREAM_TYPE type)
{
    UNUSED(stream);
    UNUSED(type);
}


void    STREAM_closeStream(LF_STREAM* stream)
{
    UNUSED(stream);
}


/* ==================================================================
    @brief


================================================================== */
void    STREAM_initFileStream(LF_STREAM* stream, FILE* file)
{
    STREAM_initStream(stream);
    stream->FileRef = file;
    stream->Type = eSTREAM_TYPE_FILE;
}


/* ==================================================================
    @brief
        initialize the memory stream.  this sets up the base and
        current pointer to memory and will adjust it according
        to what is read.

        it will advance the current pointer for every read from
        the stream.  The base pointer will always remain the constant
        and is used as a way to seek and tell positions within 
        the stream.

    @param
        stream    = pointer to the stream structure.
        mem       = pointer to the memory pointer.
        length    = length of the stream.

================================================================== */
void    STREAM_initMemStream(LF_STREAM* stream, BYTE* mem, size_t length)
{
    STREAM_initStream(stream);              // initialize the stream structure.

    stream->Type = eSTREAM_TYPE_MEM;        // how the stream is calculated
    stream->Base = mem;                     // base starting pointer of the stream
    stream->Current = mem;                  // current memory pointer in the stream
    stream->Length = length;                // length of the stream
}

void STREAM_createMemStream(LF_STREAM* stream, size_t length)
{
    BYTE* data = (BYTE*)calloc(1, length);

    stream->Type = eSTREAM_TYPE_MEM;        // how the stream is calculated
    stream->Base = data;                    // base starting pointer of the stream
    stream->Current = data;                 // current memory pointer in the stream
    stream->Length = length;                // length of the stream
    stream->isInvalid = (data == NULL) ? TRUE : FALSE;
    stream->FileRef = NULL;
}

LF_ERROR STREAM_growStream(LF_STREAM* stream, size_t grow)
{
    if (stream->Type == eSTREAM_TYPE_MEM)
    {
        BYTE* tmp;
        size_t curOffset = stream->Current - stream->Base;

        stream->Length += grow;

        tmp = realloc(stream->Base, stream->Length);
        if (tmp == NULL)
        {
            stream->isInvalid = TRUE;
            return LF_OUT_OF_MEMORY;
        }
        stream->Base = tmp;

        stream->Current = stream->Base + curOffset;
        return LF_ERROR_OK;
    }

    return LF_INVALID_TYPE;
}

void    STREAM_closeFileStream(LF_STREAM* stream)
{
    UNUSED(stream);
}



// access stream
BYTE STREAM_readByte(LF_STREAM* stream)
{
    BYTE value = 0;
    switch (stream->Type)
    {
    case eSTREAM_TYPE_FILE:
        return readByte(stream->FileRef);
        // break;

    case eSTREAM_TYPE_MEM:
        if (stream_Validate(stream, sizeof(BYTE), TRUE))
        {
            value = *(stream->Current++);        // read the value in the stream and advance the current stream
        }
        break;

    default:
        break;
    }

    return value;
}

size_t STREAM_writeByte(LF_STREAM* stream, BYTE value)
{
    switch (stream->Type)
    {
    case eSTREAM_TYPE_FILE:
        return writeByte(stream->FileRef, value);

    case eSTREAM_TYPE_MEM:
        if (stream_Validate(stream, sizeof(BYTE), FALSE))
        {
            *((BYTE*)stream->Current) = value;        // set the value in the stream
            stream->Current += sizeof(BYTE);          // advance the current stream
            return sizeof(BYTE);
        }
    //lint -fallthrough
    default:
        break;
    }

    return 0;
}

USHORT STREAM_readUShort(LF_STREAM* stream)
{
    switch (stream->Type)
    {
    case eSTREAM_TYPE_MEM:
        if (stream_Validate(stream, sizeof(USHORT), TRUE))
        {
            register USHORT value = *((USHORT*)(void*)stream->Current);     // read the value in the stream
            stream->Current += sizeof(USHORT);                              // advance the current stream
            return SWAP_USHORT(value);                                      // convert the value to proper endian
        }
    //lint -fallthrough
    default:
        return 0;

    case eSTREAM_TYPE_FILE:
        return readUShort(stream->FileRef);
    }
}

void STREAM_writeUShort(LF_STREAM* stream, USHORT value)
{
    switch (stream->Type)
    {
    case eSTREAM_TYPE_FILE:
        writeUShort(stream->FileRef, SWAP_USHORT(value));
        break;

    case eSTREAM_TYPE_MEM:
        if (stream_Validate(stream, sizeof(USHORT), FALSE))
        {
            *((USHORT*)(void*)stream->Current) = SWAP_USHORT(value);    // write the value in the stream
            stream->Current += sizeof(USHORT);                          // advance the current stream
        }
        break;

    default:
        break;
    }
}

LF_ERROR STREAM_writeCffOffset(LF_STREAM* stream, size_t offset, BYTE offSize)
{
    for (size_t i = 0; i < offSize; i++)
    {
        STREAM_writeByte(stream, ((offset >> (8*(offSize-i-1))) & 0xFF));
    }

    return LF_ERROR_OK;
}

size_t STREAM_getBytesToEncodeCffInteger(LONG n)
{
    if (n >= -107 && n <= 107)
    {
        return 1;
    }
    else if (n >= 108 && n <= 1131)
    {
        return 2;
    }
    else if (n >= -1131 && n <= -108)
    {
        return 2;
    }
    else if (n >= -32768 && n <= 32767)
    {
        return 3;
    }
    else //if (n >= -2147483647 && n <= 2147483647)
    {
        return 5;
    }
}

LF_ERROR STREAM_writeCffEncodedOffset(LF_STREAM* stream, LONG offset)
{
    // Offsets will always be encoded with 4 bytes (plus 1 for the operator = 5)
    STREAM_writeByte(stream, 29);
    //lint -e702 the passed in value should alawys be positive
    STREAM_writeByte(stream, (BYTE)(offset >> 24));
    STREAM_writeByte(stream, (BYTE)((offset >> 16) & 0xff));
    STREAM_writeByte(stream, (BYTE)((offset >> 8) & 0xff));
    //lint +e702
    STREAM_writeByte(stream, (BYTE)(offset & 0xff));

    return LF_ERROR_OK;
}

LF_ERROR STREAM_writeCffIntegerOperand(LF_STREAM* stream, LONG value)
{
    int ns;
    BYTE v, w;

    if (value >= -107 && value <= 107)
    {
        ns = value + 139;
        STREAM_writeByte(stream, (BYTE)ns);
    }
    else if (value >= 108 && value <= 1131)
    {
        ns = value - 108;
        v = (BYTE)((int)(ns / 256) + 247);
        w = (BYTE)(ns % 256);
        STREAM_writeByte(stream, v);
        STREAM_writeByte(stream, w);
    }
    else if (value >= -1131 && value <= -108)
    {
        ns = -(value + 108);
        v = (BYTE)((int)(ns / 256) + 251);
        w = (BYTE)(ns % 256);
        STREAM_writeByte(stream, v);
        STREAM_writeByte(stream, w);
    }
    else if (value >= -32768 && value <= 32767)
    {
        STREAM_writeByte(stream, 28);
        STREAM_writeUShort(stream, (USHORT)value);
    }
    else // if (value >= -2147483647 && value <= 2147483647) not needed since LONG is 32 bits
    {
        STREAM_writeByte(stream, 29);
        STREAM_writeByte(stream, (BYTE)(value >> 24));              //lint !e702
        STREAM_writeByte(stream, (BYTE)((value >> 16) & 0xff));     //lint !e702
        STREAM_writeByte(stream, (BYTE)((value >> 8) & 0xff));      //lint !e702
        STREAM_writeByte(stream, (BYTE)(value & 0xff));
    }

    return LF_ERROR_OK;
}

LF_ERROR STREAM_writeCffRealOperand(LF_STREAM* stream, float val)
{
    // Note: below code adapted from dictSaveNumber() in dict.c in the AdobeFDK

    LONG lval = (LONG)val;

    if (lval == val)
        return STREAM_writeCffIntegerOperand(stream, (LONG)val);

    /* Convert to string */
    char buf[50];

#ifndef WIN32
    long long y = (long long)round((val * 1000000000));
    val = (float)y / 1000000000;
#endif

    UTILS_snprintf(buf, 50, "%g", val);

    //printf("%s\n", buf);

    BYTE i;
    BYTE value;          /* Current nibble value */
    BYTE last = 0;       /* Last nibble value */
    BYTE odd = 0;        /* Flags odd nibble */

    STREAM_writeByte(stream, 30);

    for (i = buf[0] == '0'; ; i++)
    {
        switch (buf[i])
        {
        case '\0':
            /* Terminate number */
            STREAM_writeByte(stream, odd ? (BYTE)(last << 4 | 0xf) : 0xff);
            return LF_ERROR_OK;
        case '+':
            continue;
        case '-':
            value = 0xe;
            break;
        case '.':
            value = 0xa;
            break;
        case 'E':
        case 'e':
            value = (buf[++i] == '-') ? 0xc : 0xb;
            break;
        default:
            value = buf[i] - '0';
            break;
        }

        if (odd)
            STREAM_writeByte(stream, (BYTE)(last << 4 | value));
        else
            last = value;
        odd = !odd;
    }
}

ULONG STREAM_readULong(LF_STREAM* stream)
{
    ULONG value = 0;
    switch (stream->Type)
    {
    case eSTREAM_TYPE_FILE:
        value = readULong(stream->FileRef);
        break;
    case eSTREAM_TYPE_MEM:
        if (stream_Validate(stream, sizeof(ULONG), TRUE))
        {
            value = *((ULONG*)(void*)stream->Current);
            value = SWAP_ULONG(value);
            stream->Current += sizeof(ULONG);
        }
        break;
    default:
        break;
    }

    return value;
}

void STREAM_writeULong(LF_STREAM* stream, ULONG value)
{
    switch (stream->Type)
    {
    case eSTREAM_TYPE_FILE:
        writeULong(stream->FileRef, SWAP_ULONG(value));
        break;

    case eSTREAM_TYPE_MEM:
        if (stream_Validate(stream, sizeof(ULONG), FALSE))
        {
            *((ULONG*)(void*)stream->Current) = SWAP_ULONG(value);      // write the value in the stream
            stream->Current += sizeof(ULONG);                           // advance the current stream
        }
        break;

    default:
        break;
    }
}

LONGDATETIME STREAM_readLongDateTime(LF_STREAM* stream)
{
    LONGDATETIME value = 0;
    switch (stream->Type)
    {
    case eSTREAM_TYPE_FILE:
        value = readLongDateTime(stream->FileRef);
        break;


    case eSTREAM_TYPE_MEM:
        value = *((LONGDATETIME*)(void*)stream->Current);
        //value = SWAP_ULONG(value); //FIX!!
        stream->Current += sizeof(LONGDATETIME);
        break;
    default:
        break;
    }

    return value;
}

void STREAM_writeLongDateTime(LF_STREAM* stream, LONGDATETIME value)
{
    switch (stream->Type)
    {
    case eSTREAM_TYPE_FILE:
        writeLongDateTime(stream->FileRef, value);
        break;

    case eSTREAM_TYPE_MEM:
        if (stream_Validate(stream, sizeof(LONGDATETIME), FALSE))
        {
            *((LONGDATETIME*)(void*)stream->Current) = value;        // write the value in the stream
            stream->Current += sizeof(LONGDATETIME);                // advance the current stream
        }
        break;

    default:
        break;
    }
}

size_t STREAM_writeChunk(LF_STREAM* stream, const BYTE* data, size_t len)
{
    switch (stream->Type)
    {
    case eSTREAM_TYPE_FILE:
        return writeChunk(stream->FileRef, data, len);

    case eSTREAM_TYPE_MEM:
        if (stream_Validate(stream, len, FALSE))
        {
            memcpy(stream->Current, data, len);
            stream->Current += len;            // advance the current stream
            return len;
        }
        break;

    default:
        break;
    }

    return 0;
}

BYTE* STREAM_readChunk(LF_STREAM* stream, size_t size)
{
    BYTE* data = (BYTE*)malloc(size);

    if (data == NULL)
        return NULL;

    switch (stream->Type)
    {
        case eSTREAM_TYPE_FILE:
            fread(data, size, 1, stream->FileRef);
            break;

        case eSTREAM_TYPE_MEM:
            memcpy(data, stream->Current, size);
            stream->Current += size;
            break;
        default:
            break;
    }

    return data;
}

LF_ERROR STREAM_getChunk(LF_STREAM* stream, BYTE* buf, size_t size)
{
    switch (stream->Type)
    {
        case eSTREAM_TYPE_FILE:
            fread(buf, size, 1, stream->FileRef);
            break;

        case eSTREAM_TYPE_MEM:
            memcpy(buf, stream->Current, size);
            stream->Current += size;
            break;
        default:
            break;
    }

    return LF_ERROR_OK;
}

CHAR* STREAM_readString(LF_STREAM* stream, ULONG len)
{
    CHAR* string = (CHAR*)calloc(1, len + 1);

    if (string == NULL)
        return NULL;

    switch (stream->Type)
    {
        case eSTREAM_TYPE_FILE:
            fread(string, len, 1, stream->FileRef);
            break;

        case eSTREAM_TYPE_MEM:
            memcpy(string, stream->Current, len);
            stream->Current += len;
            break;
        default:
            break;
    }

    return string;
}

//
// UIntBase128 data type is used by woff/woff2 formats. Description from the spec:
// UIntBase128 is a different variable length encoding of unsigned integers, suitable for values up to 2^32-1.
// A UIntBase128 encoded number is a sequence of bytes for which the most significant bit is set for all but the last byte,
// and clear for the last byte. The number itself is base 128 encoded in the lower 7 bits of each byte.
// Thus, a decoding procedure for a UIntBase128 is: start with value = 0. Consume a byte, setting value = old
// value times 128 + (byte bitwise-and 127). Repeat last step until the most significant bit of byte is false.

boolean STREAM_readUIntBase128(LF_STREAM* stream, ULONG* value)
{
    BYTE curByte;

    *value = 0;

    do
    {
        curByte = STREAM_readByte(stream);

        // If any of the top seven bits are set then we're about to overflow.
        if (*value & 0xfe000000)
            return FALSE;

        *value = (*value << 7) + (curByte & 0x7f);
    } while ((curByte & 0x80) != 0);


    return TRUE;
}

void STREAM_writeUIntBase128(LF_STREAM* stream, ULONG value)
{
    BYTE i, numBytes = 1;
    ULONG x = value;

      for (; x >= 128; x >>= 7)
          ++numBytes;

    for (i = 0; i < numBytes; ++i)
    {
        BYTE curByte;

        curByte = (value >> (7 * (numBytes - i - 1))) & 0x7f;
        if (i < numBytes - 1)
            curByte |= 0x80;

        STREAM_writeByte(stream, curByte);
    }
}

static const ULONG kWordCode = 253;
static const ULONG kOneMoreByteCode2 = 254;
static const ULONG kOneMoreByteCode1 = 255;
static const ULONG kLowestUCode = 253;
static const ULONG kLowestUCodex2 = 506;

USHORT STREAM_read255UShort(LF_STREAM* stream)
{
    USHORT value = (USHORT)STREAM_readByte(stream);

    if(value == kWordCode)
        value = STREAM_readUShort(stream);
    else if(value == kOneMoreByteCode1)
        value = (USHORT)(STREAM_readByte(stream) + kLowestUCode);
    else if(value == kOneMoreByteCode2)
        value = (USHORT)(STREAM_readByte(stream) + kLowestUCodex2);

    return value;
}

USHORT STREAM_255UShortBytesNeeded(USHORT value)
{
    if(value < kWordCode)
        return 1;
    else if(value < 762)
        return 2;
    else
        return 3;
}

void STREAM_write255UShort(LF_STREAM* stream, USHORT value)
{
    if(value < kWordCode)
        STREAM_writeByte(stream, (BYTE)value);
    else if(value < kLowestUCodex2)
    {
        STREAM_writeByte(stream, (BYTE)kOneMoreByteCode1);
        STREAM_writeByte(stream, (BYTE)(value-kLowestUCode));
    }
    else if(value < 762)
    {
        STREAM_writeByte(stream, (BYTE)kOneMoreByteCode2);
        STREAM_writeByte(stream, (BYTE)(value-kLowestUCodex2));
    }
    else
    {
        STREAM_writeByte(stream, (BYTE)kWordCode);
        STREAM_writeByte(stream, (BYTE)(value>>8));
        STREAM_writeByte(stream, (BYTE)value & 0xff);
    }
}


/* ============================================================================
    @brief
        return the current position in the stream.

    @param
        stream        = pointer to the stream structure
        pos           = position inside the stream

============================================================================ */
size_t STREAM_streamPos(const LF_STREAM* stream)
{
    size_t    value = (size_t)-1;
    switch (stream->Type)
    {
    case eSTREAM_TYPE_FILE:
        value = filePos(stream->FileRef);
        break;


    case eSTREAM_TYPE_MEM:
        // calculate the (current pointer - base pointer) which 
        // would give current position relative to start.
        value = stream->Current - stream->Base;
        break;

    default:
        break;

    }
    return value;
}

/* ============================================================================
    @brief
        seek to a specific position in the stream.

    @param
        stream        = pointer to the stream structure
        pos           = position inside the stream

============================================================================ */
LONG STREAM_streamSeek(LF_STREAM* stream, size_t pos)
{
    LONG ret = 0;
    switch (stream->Type)
    {
    case eSTREAM_TYPE_FILE:
        ret = fileSeek(stream->FileRef, (int32_t)pos);
        break;

    case eSTREAM_TYPE_MEM:
        if (pos <= stream->Length)
            stream->Current = stream->Base + pos;
        else
            stream->Current = stream->Base + stream->Length - 1;   // position at end, next read will generate an error
        break;
    default:
        break;
    }
    return ret;
}

/* ----------------------------------------------------------------------------
    @summary
        check the stream access and ensure it remains within the bounds
        of the stream chunk.  if it exceeds, the function will print a message
        to stderr and return FALSE, and the stream is put into an invalid
        state so that no more reads or writes may be done.

    @param
        stream  = pointer to the stream
        size    = number of bytes we want to access in the stream from
                  it's current position.
        read    = TRUE of reading from stream

    @returns
        returns TRUE if the access is within bounds, otherwise FALSE
---------------------------------------------------------------------------- */
static boolean stream_Validate(LF_STREAM* stream, size_t size, boolean read)
{
    if(stream->isInvalid || (size_t)((stream->Current + size) - stream->Base)  > stream->Length)
    {
        if(!stream->isInvalid)
        {
            stream->isInvalid = TRUE;
#if _DEBUG
            fflush(NULL);
            fprintf(stderr, "Attempt to %s past end of stream: file %s line %d\n", read ? "read" : "write", __FILE__, __LINE__);
            fflush(stderr);
#endif
        }
        return FALSE;
    }

    return TRUE;
}

/* ============================================================================
    @desc:
        validate the offset value to be 16bits

    @param:
        offset value to validate

    @return
        TRUE  - offset is within 16-value
        FALSE - offset exceeds 16bit value.

============================================================================ */
boolean STREAM_ValidateOffset(size_t offset)
{
    if (offset > 0xFFFF)
        return FALSE;

    return TRUE;
}


#if STREAM_OFFSET_VALIDATE
/* ============================================================================
    @desc:
        write an offset to the stream.  this function takes in a LONG offset
        as a parameter and will check if the OFFSET is a valid 16bit offset.

        this was done because so much of the application uses LONG values
        to calculate the stream and table chunk deltas.  A sanity check is
        required to catch any problems that may occur.

    @param:
        offset value to validate

    @return
        TRUE  - offset is within 16-value
        FALSE - offset exceeds 16bit value.

============================================================================ */
LF_ERROR Stream_writeOffset(LF_STREAM* stream, size_t offset, char* strFile, unsigned uline)
{
    USHORT      value;
    LF_ERROR    error = LF_ERROR_OK;

    if (STREAM_ValidateOffset(offset) == FALSE)
    {
#if _DEBUG
        char hexvalue[32];
        /*lint -size(a,4907) */
        char message[4096];
        /*lint -size(a,0) */
        char* filename = strrchr(strFile, '\\');

        if (filename == NULL)
            filename = strFile;
        else
            filename++;

        UTILS_snprintf(hexvalue, 32, "%02X", (unsigned int)offset);
        UTILS_snprintf(message, 4096, "offset ( 0x%s ) exceeds 16bit range at [ %s : %u ]", hexvalue, filename, uline);

        DEBUG_LOG_ERROR(message);
#else
        (void)uline;
        (void)strFile;
#endif
        error = LF_INVALID_OFFSET;
    }

    // flatten the offset ...
    value = (USHORT)offset;
    STREAM_writeUShort(stream, value);

    return error;
}
#else
LF_ERROR Stream_writeOffset(LF_STREAM* stream, size_t offset)
{
    USHORT value = (USHORT)offset;
    STREAM_writeUShort(stream, value);

    return LF_ERROR_OK;
}
#endif

