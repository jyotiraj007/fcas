// Copyright (C) 2014 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// offset_table_woff2.c

#include "offset_table_woff2.h"
#include "utils.h"
#include "table_tags.h"

woff2_table_flag offset_woff2_getTableFlag(ULONG tag)
{
    switch(tag)
    {
    case TAG_CFF:   return etf_CFF;
    case TAG_CMAP:  return etf_cmap;
    case TAG_CVT:   return etf_cvt;
    case TAG_DSIG:  return etf_arbitrary;
    case TAG_GASP:  return etf_gasp;
    case TAG_GDEF:  return etf_GDEF;
    case TAG_GLYF:  return etf_glyf;
    case TAG_GPOS:  return etf_GPOS;
    case TAG_GSUB:  return etf_GSUB;
    case TAG_HDMX:  return etf_hdmx;
    case TAG_HEAD:  return etf_head;
    case TAG_HHEA:  return etf_hhea;
    case TAG_HMTX:  return etf_hmtx;
    case TAG_KERN:  return etf_kern;
    case TAG_LOCA:  return etf_loca;
    case TAG_MAXP:  return etf_maxp;
    case TAG_NAME:  return etf_name;
    case TAG_OS2:   return etf_OS2;
    case TAG_POST:  return etf_post;
    case TAG_PREP:  return etf_prep;
    case TAG_VDMX:  return etf_VDMX;
    case TAG_VHEA:  return etf_vhea;
    case TAG_VMTX:  return etf_vmtx;

    case TAG_EBDT:  return etf_EBDT;
    case TAG_EBLC:  return etf_EBLC;
    case TAG_LTSH:  return etf_LTSH;
    case TAG_FPGM:  return etf_fpgm;
    case TAG_FFTM:  return etf_arbitrary;

    case TAG_VORG:  return etf_VORG;
    case TAG_BASE:  return etf_BASE;
    case TAG_EBSC:  return etf_EBSC;
    case TAG_JSTF:  return etf_JSTF;
    case TAG_MATH:  return etf_MATH;
    case TAG_CBDT:  return etf_CBDT;
    case TAG_CBLC:  return etf_CBLC;
    case TAG_COLR:  return etf_COLR;
    case TAG_CPAL:  return etf_CPAL;
    case TAG_SVG:   return etf_SVG;
    case TAG_SBIX:  return etf_sbix;
    case TAG_ACNT:  return etf_acnt;
    case TAG_AVAR:  return etf_avar;
    case TAG_BDAT:  return etf_bdat;
    case TAG_BLOC:  return etf_bloc;
    case TAG_BSLN:  return etf_bsln;
    case TAG_CVAR:  return etf_cvar;
    case TAG_FDSC:  return etf_fdsc;
    case TAG_feat:  return etf_feat;
    case TAG_FMTX:  return etf_fmtx;
    case TAG_FVAR:  return etf_fvar;
    case TAG_GVAR:  return etf_gvar;
    case TAG_HSTY:  return etf_hsty;
    case TAG_JUST:  return etf_just;
    case TAG_LCAR:  return etf_lcar;
    case TAG_MORT:  return etf_mort;
    case TAG_MORX:  return etf_morx;
    case TAG_OPBD:  return etf_opbd;
    case TAG_PCLT:  return etf_PCLT;
    case TAG_PROP:  return etf_prop;
    case TAG_TRAK:  return etf_trak;
    case TAG_ZAPF:  return etf_Zapf;
    case TAG_SILF:  return etf_Silf;
    case TAG_GLAT:  return etf_Glat;
    case TAG_GLOC:  return etf_Gloc;
    case TAG_FEAT:  return etf_Feat;
    case TAG_SILL:  return etf_Sill;
    case TAG_HVAR:  return etf_arbitrary;
    case TAG_MVAR:  return etf_arbitrary;
    case TAG_STAT:  return etf_arbitrary;
    default:        return etf_arbitrary;
    }
}

static ULONG offset_woff2_get_tag(woff2_table_flag flagval)
{
    switch(flagval)
    {
    case etf_cmap: return TAG_CMAP;
    case etf_head: return TAG_HEAD;
    case etf_hhea: return TAG_HHEA;
    case etf_hmtx: return TAG_HMTX;
    case etf_maxp: return TAG_MAXP;
    case etf_name: return TAG_NAME;
    case etf_OS2:  return TAG_OS2;
    case etf_post: return TAG_POST;
    case etf_cvt:  return TAG_CVT;
    case etf_fpgm: return TAG_FPGM;
    case etf_glyf: return TAG_GLYF;
    case etf_loca: return TAG_LOCA;
    case etf_prep: return TAG_PREP;
    case etf_CFF:  return TAG_CFF;
    case etf_VORG: return TAG_VORG;
    case etf_EBDT: return TAG_EBDT;
    case etf_EBLC: return TAG_EBLC;
    case etf_gasp: return TAG_GASP;
    case etf_hdmx: return TAG_HDMX;
    case etf_kern: return TAG_KERN;
    case etf_LTSH: return TAG_LTSH;
    case etf_PCLT: return TAG_PCLT;
    case etf_VDMX: return TAG_VDMX;
    case etf_vhea: return TAG_VHEA;
    case etf_vmtx: return TAG_VMTX;
    case etf_BASE: return TAG_BASE;
    case etf_GDEF: return TAG_GDEF;
    case etf_GPOS: return TAG_GPOS;
    case etf_GSUB: return TAG_GSUB;
    case etf_EBSC: return TAG_EBSC;
    case etf_JSTF: return TAG_JSTF;
    case etf_MATH: return TAG_MATH;
    case etf_CBDT: return TAG_CBDT;
    case etf_CBLC: return TAG_CBLC;
    case etf_COLR: return TAG_COLR;
    case etf_CPAL: return TAG_CPAL;
    case etf_SVG:  return TAG_SVG;
    case etf_sbix: return TAG_SBIX;
    case etf_acnt: return TAG_ACNT;
    case etf_avar: return TAG_AVAR;
    case etf_bdat: return TAG_BDAT;
    case etf_bloc: return TAG_BLOC;
    case etf_bsln: return TAG_BSLN;
    case etf_cvar: return TAG_CVAR;
    case etf_fdsc: return TAG_FDSC;
    case etf_feat: return TAG_FEAT;
    case etf_fmtx: return TAG_FMTX;
    case etf_fvar: return TAG_FVAR;
    case etf_gvar: return TAG_GVAR;
    case etf_hsty: return TAG_HSTY;
    case etf_just: return TAG_JUST;
    case etf_lcar: return TAG_LCAR;
    case etf_mort: return TAG_MORT;
    case etf_morx: return TAG_MORX;
    case etf_opbd: return TAG_OPBD;
    case etf_prop: return TAG_PROP;
    case etf_trak: return TAG_TRAK;
    case etf_Zapf: return TAG_ZAPF;
    case etf_Silf: return TAG_SILF;
    case etf_Glat: return TAG_GLAT;
    case etf_Gloc: return TAG_GLOC;
    case etf_Feat: return TAG_FEAT;
    case etf_Sill: return TAG_SILL;
    default: return 0xffffffff;
    }
}

static woff2_table_record* offset_woff2_readRecord(LF_STREAM* stream)
{
    woff2_table_record* record = (woff2_table_record*)calloc(1, sizeof(woff2_table_record));
    if(record != NULL)
    {
        record->flags = STREAM_readByte(stream);

        if(record->flags > (BYTE)etf_arbitrary)
        {
            DEBUG_LOG_ERROR("offset_woff2_readRecord invalid flags value");
            free(record);
            return NULL;
        }
        else if(record->flags == etf_arbitrary)
        {
            // read the next 4 bytes, to get the tag
            record->tag = STREAM_readULong(stream);
        }
        else
        {
            record->tag = offset_woff2_get_tag((woff2_table_flag)record->flags);
        }

        if(FALSE == STREAM_readUIntBase128(stream, &record->origLength))
        {
            free(record);
            return NULL;
        }

        if(((record->flags & 0x3F) == etf_glyf) || ((record->flags & 0x3F) == etf_loca))
        {
            if (FALSE == STREAM_readUIntBase128(stream, &record->transformLength))
            {
                free(record);
                return NULL;
            }
        }
    }

    return record;
}

woff2_offset_table* offset_woff2_readTable(LF_STREAM* stream, int keepFlags)
{
    USHORT i = 0, numTables;
    ULONG currentOffset = 0;

    woff2_offset_table* table = (woff2_offset_table*)malloc(sizeof(woff2_offset_table));

    if(table != NULL)
    {
        table->woffHeader.signature = STREAM_readULong(stream);
        table->woffHeader.flavor = STREAM_readULong(stream);
        table->woffHeader.length = STREAM_readULong(stream);
        table->woffHeader.numTables = STREAM_readUShort(stream);
        table->woffHeader.reserved = STREAM_readUShort(stream);
        table->woffHeader.totalSfntSize = STREAM_readULong(stream);
        table->woffHeader.totalCompressedSize = STREAM_readULong(stream);
        table->woffHeader.majorVersion = STREAM_readUShort(stream);
        table->woffHeader.minorVersion = STREAM_readUShort(stream);
        table->woffHeader.metaOffset = STREAM_readULong(stream);
        table->woffHeader.metaLength = STREAM_readULong(stream);
        table->woffHeader.metaOrigLength = STREAM_readULong(stream);
        table->woffHeader.privOffset = STREAM_readULong(stream);
        table->woffHeader.privLength = STREAM_readULong(stream);

        vector_init(&table->record_list, table->woffHeader.numTables, 4);

        numTables = table->woffHeader.numTables;

        for(i = 0; i < numTables; ++i)
        {
            // allocate and read next record
            woff2_table_record* record = offset_woff2_readRecord(stream);

            if(record != NULL)
            {
                record->offset = currentOffset;

                if((record->tag == TAG_GLYF) || (record->tag == TAG_LOCA))
                    currentOffset += record->transformLength;
                else
                    currentOffset += record->origLength;

                if((TRUE == LF_retainTable(record->tag, keepFlags)) && (record->origLength != 0))
                {
                    // add to linked list
                    vector_push_back(&table->record_list, record);
                }
                else
                {
                    free(record);
                    table->woffHeader.numTables--;
                }
            }
            else
            {
                offset_woff2_freeTable(table);
                return NULL;
            }
        }

        table->compressedFontDataOffset = STREAM_streamPos(stream);
    }

    return table;
}

size_t offset_woff2_writeTable(woff2_offset_table* table, LF_STREAM* stream)
{
    ULONG i = 0;

    if(table == NULL)
        return 0;

    STREAM_writeULong(stream, table->woffHeader.signature);
    STREAM_writeULong(stream, table->woffHeader.flavor);
    STREAM_writeULong(stream, table->woffHeader.length);
    STREAM_writeUShort(stream, (USHORT)table->record_list.count);
    STREAM_writeUShort(stream, 0);
    STREAM_writeULong(stream, table->woffHeader.totalSfntSize);
    STREAM_writeULong(stream, table->woffHeader.totalCompressedSize);
    STREAM_writeUShort(stream, table->woffHeader.majorVersion);
    STREAM_writeUShort(stream, table->woffHeader.minorVersion);
    STREAM_writeULong(stream, table->woffHeader.metaOffset);
    STREAM_writeULong(stream, table->woffHeader.metaLength);
    STREAM_writeULong(stream, table->woffHeader.metaOrigLength);
    STREAM_writeULong(stream, table->woffHeader.privOffset);
    STREAM_writeULong(stream, table->woffHeader.privLength);

    //write out the table records
    for(; i < table->record_list.count; i++)
    {
        woff2_table_record* record = (woff2_table_record*)vector_at(&table->record_list, i);

        if(record)
        {
            //encode the table type into the flags value
            record->flags = (BYTE)offset_woff2_getTableFlag(record->tag);

            STREAM_writeByte(stream, record->flags);

            if((record->flags & 0x3f) == etf_arbitrary)
                STREAM_writeULong(stream, record->tag);

            STREAM_writeUIntBase128(stream, record->origLength);

            if(((record->flags & 0x3f) == etf_glyf) || ((record->flags & 0x3f) == etf_loca))
                STREAM_writeUIntBase128(stream, record->transformLength);
        }
    }

    return STREAM_streamPos(stream);
}   //lint !e429 (table is freed elsewhere)

LF_ERROR offset_woff2_freeTable(woff2_offset_table* table)
{
    ULONG i = 0;

    for(; i < table->record_list.count; i++)
    {
        woff2_table_record* record = (woff2_table_record*)vector_at(&table->record_list, i);
        free(record);
    }

    vector_free(&table->record_list);
    free(table);

    return LF_ERROR_OK;
}
