// Copyright (C) 2014, 2015 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// gsub_table.c

#include <stdlib.h>

#include "gsub_table.h"
#include "utils.h"
#include "data_types.h"
#include "table_tags.h"
#include "gsub_lookup/gsub_common.h"
#include "gsub_lookup/gsub_single.h"
#include "gsub_lookup/gsub_multiple.h"
#include "gsub_lookup/gsub_alternate.h"
#include "gsub_lookup/gsub_ligature.h"
#include "gsub_lookup/gsub_context.h"
#include "gsub_lookup/gsub_chaining_context.h"
#include "gsub_lookup/gsub_reverse_chaining_single.h"


/* ============================================================================
    @brief
        given a glyph, parse the lookup table and all subtables that
        contain substitution coverage and check if we need to remove
        any of the rules.

    @param
        hTable = pointer to the glyph substitution table
        index  = the glyph ID to remove.

    @return
        the status to remove the glyph.

============================================================================ */
LF_ERROR GSUB_removeGlyph(LF_FONT* lfFont, ULONG index)
{
    LF_ERROR error = LF_ERROR_OK;
    gsub_header* table = (gsub_header*)map_at(&lfFont->table_map, (void*)TAG_GSUB);

    if (table)
    {
        table->calculatedTableSize = 0;

        error = Lookup_removeGlyph(table->LookupList, table, index, FALSE);

        if (error == LF_EMPTY_TABLE)
        {
            // TODO: clean up the GSUB table
            GSUB_freeTable(lfFont);
            map_erase(&lfFont->table_map, (void*)TAG_GSUB);
        }
    }

    return error;
}

LF_ERROR GSUB_subtableRemoveGlyph(USHORT lookupType, TABLE_HANDLE hTable, ULONG index)
{
    switch(lookupType)
    {
    case GSUB_LOOKUP_SINGLE:        return GSUB_removeGlyphIndex((gsub_single_substitution*)hTable, (GlyphID)index);
    case GSUB_LOOKUP_MULTIPLE:      return GSUB_removeMultipleGlyphIndex((gsub_multiple_substitution*)hTable, (GlyphID)index);
    case GSUB_LOOKUP_ALTERNATE:     return GSUB_removeAlternateGlyphIndex((gsub_alternate_substitution*)hTable, (GlyphID)index);
    case GSUB_LOOKUP_LIGATURE:      return GSUB_removeLigatureGlyphIndex((gsub_ligature*)hTable, (GlyphID)index);
    case GSUB_LOOKUP_CONTEXT:       return GSUB_removeContextGlyphIndex((gsub_context_substitution*)hTable, (GlyphID)index);
    case GSUB_LOOKUP_CHAIN:         return GSUB_removeChainContextSubst((gsub_chain_context_substitution*)hTable, (GlyphID)index);
    case GSUB_LOOKUP_EXTENSION:     return LF_ERROR_OK;
    case GSUB_LOOKUP_REVERSE_CHAIN: return GSUB_removeReverseChainSingleSubst((gsub_reverse_chain_single_substitution*)hTable, (GlyphID)index);
    default:
        break;
    }

    return LF_BAD_FORMAT;
}

/* ----------------------------------------------------------------------------
    @brief
        The headers of the GSUB and GPOS tables contain offsets to Feature List
        tables (FeatureList) that enumerate all the features in a font. Features
        in a particular FeatureList are not limited to any single script. A
        FeatureList contains the entire list of either the GSUB or GPOS features
        that are used to render the glyphs in all the scripts in the font.

        The FeatureList table enumerates features in an array of records 
        (FeatureRecord) and specifies the total number of features (FeatureCount).
        Every feature must have a FeatureRecord, which consists of a FeatureTag
        that identifies the feature and an offset to a Feature table (described
        next). The FeatureRecord array is arranged alphabetically by FeatureTag
        names.

---------------------------------------------------------------------------- */
TABLE_HANDLE GSUB_readSubtable(USHORT lookupType, LF_STREAM* stream)
{
    TABLE_HANDLE subtable = NULL;

    switch (lookupType)
    {
    case GSUB_LOOKUP_SINGLE:         subtable = GSUB_readSingleSubst(stream);               break;
    case GSUB_LOOKUP_MULTIPLE:       subtable = GSUB_readMultipleSubst(stream);             break;
    case GSUB_LOOKUP_ALTERNATE:      subtable = GSUB_readAlternateSubst(stream);            break;
    case GSUB_LOOKUP_LIGATURE:       subtable = GSUB_readLigatureSubst(stream);             break;
    case GSUB_LOOKUP_CONTEXT:        subtable = GSUB_readContextSubst(stream);              break;
    case GSUB_LOOKUP_CHAIN:          subtable = GSUB_readChainContextSubst(stream);         break;
    case GSUB_LOOKUP_REVERSE_CHAIN:  subtable = GSUB_readReverseChainSingleSubst(stream);   break;
    case GSUB_LOOKUP_EXTENSION:                                                             break;
    default:
        break;
    }

    return subtable;
}

/* ============================================================================
    @brief
        parse the lookup type and stream out the subtable.  the function
        returns the current stream offset value.

    @param
        lookupType = the lookup type that represents the subtable
        table = pointer to the subtable.
        stream = pointer to the stream instance

    @returns
        the current offset in the stream.

============================================================================ */
size_t GSUB_buildSubTable(USHORT lookupType, TABLE_HANDLE table, LF_STREAM* stream)
{
    size_t    offset = 0;
    size_t    tableStart = STREAM_streamPos(stream);

    switch (lookupType)
    {
    case GSUB_LOOKUP_SINGLE:        offset = GSUB_buildSingleSubstitution((gsub_single_substitution*)table, stream);          break;
    case GSUB_LOOKUP_MULTIPLE:      offset = GSUB_buildMultipleSubst((gsub_multiple_substitution*)table, stream);             break;
    case GSUB_LOOKUP_ALTERNATE:     offset = GSUB_buildAlternateSubst((gsub_alternate_substitution*)table, stream);           break;
    case GSUB_LOOKUP_LIGATURE:      offset = GSUB_buildLigatureSubst((gsub_ligature*)table, stream);                          break;
    case GSUB_LOOKUP_CONTEXT:       offset = GSUB_buildContextSubst((gsub_context_substitution*)table, stream);               break;
    case GSUB_LOOKUP_CHAIN:         offset = GSUB_buildChainContextSubst((gsub_chain_context_substitution*)table, stream);    break;
    case GSUB_LOOKUP_REVERSE_CHAIN: offset = GSUB_buildReverseChainSingleSubst((gsub_reverse_chain_single_substitution*)table, stream);    break;
    case GSUB_LOOKUP_EXTENSION:     DEBUG_LOG_ERROR("GSUB lookup extension NOT implemented");  /*lint -fallthrough */
    default:
                                    DEBUG_LOG_ERROR("GSUB Build: bad lookupType");
                                    offset = tableStart;
                                    break;
    }

    return offset - tableStart;
}

/* ============================================================================
    @brief
        build the glyph substitution table for final output.
============================================================================ */
static LF_ERROR GSUB_buildTable(TABLE_HANDLE hTable, size_t* tableSize, BYTE** tableData)
{
    gsub_header* table = (gsub_header*)hTable;
    size_t scriptSize = 0, featureSize = 0, lookupSize = 0;

    BYTE* scriptData = Script_buildTable(table->ScriptList, &scriptSize);
    BYTE* featureData = Feature_buildTable(table->FeatureList, FALSE, &featureSize);

    if (featureData == NULL)
        return LF_OUT_OF_MEMORY;

    BYTE* lookupData = NULL;

    LF_ERROR error = Lookup_buildTable(table->LookupList, FALSE, &lookupSize, &lookupData);
    if (error == LF_ERROR_OK)
    {
        ULONG headerSize = sizeof(FIXED) + sizeof(OFFSET) * 3;
        *tableSize = headerSize + scriptSize + featureSize + lookupSize;

        size_t paddedSize = *tableSize;
        *tableData = UTILS_AllocTable(&paddedSize);
        if (*tableData == NULL)
        {
            error = LF_OUT_OF_MEMORY;
        }
        else
        {
            LF_STREAM stream;
            STREAM_initMemStream(&stream, *tableData, *tableSize);
            STREAM_writeFixed(&stream, table->Version);
            STREAM_writeOffset(&stream, (USHORT)headerSize);
            STREAM_writeOffset(&stream, (USHORT)(headerSize + scriptSize));
            STREAM_writeOffset(&stream, (USHORT)(headerSize + scriptSize + featureSize));

            STREAM_writeChunk(&stream, scriptData, scriptSize);
            STREAM_writeChunk(&stream, featureData, featureSize);
            STREAM_writeChunk(&stream, lookupData, lookupSize);
        }
    }

    free(scriptData);
    free(featureData);
    free(lookupData);

    return error;
}

/* ----------------------------------------------------------------------------
    @brief
        read in and create the GSUB table.  This method begins with a header
        that contains a description of the version and how to find the
        script, feature, and lookup lists.

        The lists are simply offsets from the beginning of the GSUB table.

---------------------------------------------------------------------------- */
LF_ERROR GSUB_readTable(LF_FONT* lfFont, const sfnt_table_record* record, LF_STREAM* stream)
{
    ULONG           baseOffset = record->offset;
    gsub_header*    header = NULL;

    // record length
    if (record->length)
    {
        // stream to the beginning of this table
        if (STREAM_streamSeek(stream, record->offset) == 0)
        {
            FIXED   version;
            OFFSET  scriptOffset, featureOffset, lookupOffset;

            header = (gsub_header*)calloc(1, sizeof(gsub_header));
            if (header == NULL)
                return LF_OUT_OF_MEMORY;

            BaseTable_init(header, NULL);
            BaseTable_setType(header, TABLETYPE_GSUB, SUBTABLE_TYPE_NONE);

            header->isValid = TRUE;
            header->calculatedTableSize = 0;

            version         = STREAM_readFixed(stream);
            scriptOffset    = STREAM_readOffset(stream);
            featureOffset   = STREAM_readOffset(stream);
            lookupOffset    = STREAM_readOffset(stream);

            header->Version = version;

            if ((featureOffset == 0) || (lookupOffset == 0))
            {
                header->isValid = FALSE;
            }
            else
            {
                STREAM_streamSeek(stream, baseOffset + scriptOffset);
                header->ScriptList = Script_readListTable(stream, FALSE);
                if (header->ScriptList == NULL)
                {
                    free(header);
                    return LF_OUT_OF_MEMORY;
                }

                STREAM_streamSeek(stream, baseOffset + featureOffset);

                LF_ERROR error = Feature_readListTable(stream, FALSE, &header->FeatureList);
                if (error != LF_ERROR_OK)
                {
                    Script_deleteTable(header->ScriptList);
                    free(header);
                    return error;
                }

                STREAM_streamSeek(stream, baseOffset + lookupOffset);
                header->LookupList = Lookup_readListTable(stream, FALSE);
                if (header->LookupList == NULL)
                {
                    Feature_deleteTable(header->FeatureList);
                    Script_deleteTable(header->ScriptList);
                    free(header);
                    return LF_OUT_OF_MEMORY;
                }
            }

            map_insert(&lfFont->table_map, (void*)(intptr_t)record->tag, header);

            return LF_ERROR_OK;
        }

        return LF_INVALID_OFFSET;
    }

    return LF_INVALID_LENGTH;
}

/* ----------------------------------------------------------------------------
    @brief
        returns size (length) that the table will be if written now

---------------------------------------------------------------------------- */
LF_ERROR GSUB_getTableSize(LF_FONT* lfFont, size_t* tableSize)
{
    gsub_header* table;
    size_t headerSize;
    size_t scriptSize, featureSize, lookupSize;

    *tableSize = 0;

    table = (gsub_header*)map_at(&lfFont->table_map, (void*)TAG_GSUB);

    if(table == NULL)
        return LF_EMPTY_TABLE;

    if (table->calculatedTableSize != 0)
    {
        *tableSize = table->calculatedTableSize;
        return LF_ERROR_OK;
    }

    headerSize = sizeof(FIXED) + sizeof(OFFSET) * 3;

    scriptSize = Script_getDataSize(table->ScriptList);
    featureSize = Feature_getDataSize(table->FeatureList);
    lookupSize = Lookup_getDataSize(table->LookupList, FALSE);

    *tableSize = headerSize + scriptSize + featureSize + lookupSize;

    table->calculatedTableSize = *tableSize;

    return LF_ERROR_OK;
}

LF_ERROR GSUB_writeTable(LF_FONT* lfFont, sfnt_table_record* record, LF_STREAM* stream)
{
    size_t table_size = 0;
    gsub_header* table = (gsub_header*)map_at(&lfFont->table_map, (void*)TAG_GSUB);
    LF_ERROR error = LF_ERROR_OK;

    if (table)
    {
        BYTE* tableData;
        error = GSUB_buildTable(table, &table_size, &tableData);
        if (error == LF_ERROR_OK)
        {
            //ULONG padLen = 0;
            //UTILS_PadTable(&tableData, table_size, &padLen);

            record->checkSum = UTILS_CalcTableChecksum(tableData, table_size);
            record->length = (ULONG)table_size;
            record->offset = (ULONG)STREAM_streamPos(stream);

            STREAM_streamSeek(stream, record->offset);
            STREAM_writeChunk(stream, tableData, (table_size + 3) & ~3);
            free(tableData);
        }
    }

    return error;
}

LF_ERROR GSUB_freeTable(LF_FONT* lfFont)
{
    gsub_header* table = (gsub_header*)map_at(&lfFont->table_map, (void*)TAG_GSUB);

    if(table)
    {
        Feature_deleteTable(table->FeatureList);
        Script_deleteTable(table->ScriptList);
        Lookup_freeTableList(table->LookupList, FALSE);

        free(table);
    }

    return LF_ERROR_OK;
}


/* ============================================================================
    @brief


============================================================================ */
size_t GSUB_getSubtableSize( USHORT lookupType, TABLE_HANDLE hTable)
{
    size_t size = 0;

    switch (lookupType)
    {
    case GSUB_LOOKUP_SINGLE:        size = GSUB_getSingleSubstitutionSize((gsub_single_substitution*)hTable);    break;
    case GSUB_LOOKUP_MULTIPLE:      size = GSUB_getMultipleSubstSize((gsub_multiple_substitution*)hTable);       break;
    case GSUB_LOOKUP_ALTERNATE:     size = GSUB_getAlternateSubstSize((gsub_alternate_substitution*)hTable);     break;
    case GSUB_LOOKUP_LIGATURE:      size = GSUB_getLigatureSubstSize((gsub_ligature*)hTable);                    break;
    case GSUB_LOOKUP_CONTEXT:       size = GSUB_getContextSubstSize((gsub_context_substitution*)hTable);         break;
    case GSUB_LOOKUP_CHAIN:         size = GSUB_sizeChainContextSubst((gsub_chain_context_substitution*)hTable); break;
    case GSUB_LOOKUP_EXTENSION:     break;
    case GSUB_LOOKUP_REVERSE_CHAIN: size = GSUB_sizeReverseChainSingleSubst((gsub_reverse_chain_single_substitution*)hTable);    break;

    default:
        break;
    }
    return size;
}

/* ============================================================================
    @summary
        free up the subtable resources from the system.

    @param
        lookupType = lookup type for casting table pointer.
        table = pointer to the gsub rule

============================================================================ */
void GSUB_freeSubtable(USHORT lookupType, TABLE_HANDLE table)
{
    switch (lookupType)
    {
    case GSUB_LOOKUP_SINGLE:        GSUB_freeSingleSubst((gsub_single_substitution*)table);                 break;
    case GSUB_LOOKUP_MULTIPLE:      GSUB_freeMultipleSubst((gsub_multiple_substitution*)table);             break;
    case GSUB_LOOKUP_ALTERNATE:     GSUB_freeAlternateSubst((gsub_alternate_substitution*)table);           break;
    case GSUB_LOOKUP_LIGATURE:      GSUB_freeLigatureSubst((gsub_ligature*)table);                          break;
    case GSUB_LOOKUP_CONTEXT:       GSUB_freeContextSubst((gsub_context_substitution*)table);               break;
    case GSUB_LOOKUP_CHAIN:         GSUB_freeChainContextSubst((gsub_chain_context_substitution*)table);    break;
    case GSUB_LOOKUP_EXTENSION:     break;
    case GSUB_LOOKUP_REVERSE_CHAIN: GSUB_freeReverseChainSingleSubst((gsub_reverse_chain_single_substitution*)table);    break;

    default:
        break;
    }
}

/* ============================================================================
    @summary
        free up the subtable resources from the system.

    @param
        lookupType = lookup type for casting table pointer.
        table = pointer to the gsub rule

============================================================================ */
LF_ERROR GSUB_removeLookupIndexSubtable(USHORT lookupType, TABLE_HANDLE table, USHORT refIndex, SHORT deltaIndex)
{
    LF_ERROR error = LF_NOT_COVERED;

    switch (lookupType)
    {
    case GSUB_LOOKUP_CONTEXT:
        error = GSUB_removeContextSubstLookupIndex((gsub_context_substitution*)table, refIndex, deltaIndex);
        break;

    case GSUB_LOOKUP_CHAIN:
        error = GSUB_removeChainContextSubstLookupIndex((gsub_chain_context_substitution*)table, refIndex, deltaIndex);
        break;

    case GSUB_LOOKUP_REVERSE_CHAIN:
        error = GSUB_removeReverseChainSingleSubstLookupIndex((gsub_reverse_chain_single_substitution*)table, refIndex, deltaIndex);
        break;

    case GSUB_LOOKUP_SINGLE:
    case GSUB_LOOKUP_MULTIPLE:
    case GSUB_LOOKUP_ALTERNATE:
    case GSUB_LOOKUP_LIGATURE:
    case GSUB_LOOKUP_EXTENSION:
    default:
        break;
    }

    return error;
}

/* ============================================================================
    @summary
        lookup records contain references to context and classes.  This
        function will go through those relevant rules and remove any
        of the lookup records that reference a empty class and remove
        them.

        primarily this is being done to help with the MT font validate
        from detecting errors in the font files referencing an empty
        class.

    @param
        lookupType = lookup type for casting table pointer.
        table = pointer to the GSUB rule

============================================================================ */
LF_ERROR GSUB_pruneLookupRecords(USHORT lookupType, TABLE_HANDLE table)
{
    LF_ERROR error = LF_NOT_COVERED;

    switch (lookupType)
    {
    case GSUB_LOOKUP_CONTEXT:
        error = GSUB_pruneContextSubstLookupRecords((gsub_context_substitution*)table);
        break;

    case GSUB_LOOKUP_CHAIN:
        error = GSUB_pruneChainContextSubstLookupRecords((gsub_chain_context_substitution*)table);
        break;

    case GSUB_LOOKUP_REVERSE_CHAIN:
//        error = GSUB_removeReverseChainSingleSubstLookupIndex((gsub_reverse_chain_single_substitution*)table);
        break;

    case GSUB_LOOKUP_SINGLE:
    case GSUB_LOOKUP_MULTIPLE:
    case GSUB_LOOKUP_ALTERNATE:
    case GSUB_LOOKUP_LIGATURE:
    case GSUB_LOOKUP_EXTENSION:
    default:
        break;
    }

    return error;
}

/* ============================================================================
    @summary
        prune lookups goes through and cleans up any classes that have
        been emptied, but need to be cleaned up.  since there is no
        particular order to how the glyphs are removed we cannot guarantee
        that all empty classes, coverages and lookup records have been
        properly pruned.

============================================================================ */
LF_ERROR GSUB_pruneLookups(LF_FONT* lfFont)
{
    LF_ERROR error = LF_ERROR_OK;
    gsub_header* table = (gsub_header*)map_at(&lfFont->table_map, (void*)TAG_GSUB);

    if (table)
    {
        table->calculatedTableSize = 0;

        error = Lookup_pruneLookups(table->LookupList, table, FALSE);
    }

    return error;
}

LF_ERROR GSUB_subtableRemapGlyph(USHORT lookupType, TABLE_HANDLE table, LF_MAP* remap)
{
    LF_ERROR error = LF_NOT_COVERED;

    switch (lookupType)
    {
    case GSUB_LOOKUP_SINGLE:        error = GSUB_remapSingleSubstGlyphs((gsub_single_substitution*)table, remap);                            break;
    case GSUB_LOOKUP_MULTIPLE:      error = GSUB_remapMultipleSubstGlyphs((gsub_multiple_substitution*)table, remap);                        break;
    case GSUB_LOOKUP_ALTERNATE:     error = GSUB_remapAlternateGlyphs((gsub_alternate_substitution*)table, remap);                           break;
    case GSUB_LOOKUP_LIGATURE:      error = GSUB_remapLigatureSubstGlyphs((gsub_ligature*)table, remap);                                     break;
    case GSUB_LOOKUP_CONTEXT:       error = GSUB_remapContextSubstGlyphs((gsub_context_substitution*)table, remap);                          break;
    case GSUB_LOOKUP_CHAIN:         error = GSUB_remapChainContextGlyphs((gsub_chain_context_substitution*)table, remap);                    break;
    case GSUB_LOOKUP_REVERSE_CHAIN: error = GSUB_remapReverseChainSingleSubstGlyphs((gsub_reverse_chain_single_substitution*)table, remap);  break;
    case GSUB_LOOKUP_EXTENSION:     error = LF_ERROR_OK;                                                                                     break;
    default:                                                                                                                                 break;
    }
    return error;
}

LF_ERROR GSUB_remapTable(LF_FONT* lfFont, LF_MAP* remap)
{
    LF_ERROR error = LF_ERROR_OK;
    gsub_header* header = (gsub_header*)map_at(&lfFont->table_map, (void*)TAG_GSUB);

    if((header != NULL) && (header->LookupList != NULL))
    {
        error = Lookup_remapTables(header->LookupList, remap, FALSE);
    }

    return error;
}

#ifdef LF_OT_DUMP
LF_ERROR GSUB_dumpSubtable(USHORT lookupType, TABLE_HANDLE table)
{
    switch (lookupType)
    {
    case GSUB_LOOKUP_SINGLE:        GSUB_dumpSingleSubst((gsub_single_substitution*)table);          break;
    case GSUB_LOOKUP_MULTIPLE:      GSUB_dumpMultipleSubst((gsub_multiple_substitution*)table);      break;
    case GSUB_LOOKUP_ALTERNATE:     GSUB_dumpAlternateSubst((gsub_alternate_substitution*)table);    break;
    case GSUB_LOOKUP_LIGATURE:      GSUB_dumpLigatureSubst((gsub_ligature*)table);                   break;
    case GSUB_LOOKUP_CONTEXT:       GSUB_dumpContextSubst((gsub_context_substitution*)table);        break;
    case GSUB_LOOKUP_CHAIN:         GSUB_dumpChainContext((gsub_chain_context_substitution*)table);  break;
    case GSUB_LOOKUP_REVERSE_CHAIN:                                                                  break;
    case GSUB_LOOKUP_EXTENSION:                                                                      break;
    default:                                                                                         break;
    }

    return LF_ERROR_OK;
}

LF_ERROR GSUB_dumpTable(LF_FONT* lfFont)
{
    LF_ERROR error = LF_ERROR_OK;
    gsub_header* header = (gsub_header*)map_at(&lfFont->table_map, (void*)TAG_GSUB);

    if((header != NULL) && (header->LookupList != NULL))
    {
        error = Lookup_dumpTables(header->LookupList, FALSE);
    }
    return error;
}
#endif

LF_ERROR GSUB_removeAllTables(LF_FONT* lfFont)
{
    gsub_header* table = (gsub_header*)map_at(&lfFont->table_map, (void*)TAG_GSUB);

    if(table)
    {
        Lookup_freeTableList(table->LookupList, FALSE);
        table->LookupList = NULL;
    }

    return LF_ERROR_OK;
}

boolean GSUB_isValid(LF_FONT* lfFont)
{
    gsub_header* table = (gsub_header*)map_at(&lfFont->table_map, (void*)TAG_GSUB);
    if (table == NULL)
        return FALSE;

    // NOTE: the only validation done so far is to check that the feature offset and lookup offset are not 0.

    return table->isValid;
}

LF_ERROR GSUB_isTableEmpty(LF_FONT* lfFont)
{
    gsub_header* table = (gsub_header*)map_at(&lfFont->table_map, (void*)TAG_GSUB);
    if (table)
    {
        LF_VECTOR* hLookup = (LF_VECTOR*)table->LookupList;

        return (hLookup && hLookup->count) ? LF_ERROR_OK : LF_EMPTY_TABLE;
    }

    return LF_EMPTY_TABLE;
}

LF_ERROR GSUB_getMaxLigaDepth(LF_FONT* lfFont, USHORT* depth)
{
    *depth = 0;

    gsub_header* table = (gsub_header*)map_at(&lfFont->table_map, (void*)TAG_GSUB);
    if (table == NULL)
        return LF_TABLE_MISSING;

    LF_VECTOR* lookup_list_table = (LF_VECTOR*)table->LookupList;

    for (size_t i = 0; i < lookup_list_table->count; i++)
    {
        lookup_table* lookupTable = (lookup_table*)vector_at(lookup_list_table, i);

        if (lookupTable->LookupType == GSUB_LOOKUP_LIGATURE)
        {
            for (size_t j = 0; j < lookupTable->SubTables.count; ++j)
            {
                TABLE_HANDLE subtable = (TABLE_HANDLE)vector_at(&lookupTable->SubTables, j);

                USHORT subTableMax = 0;

                GSUB_getMaxComponentCount((gsub_ligature*)subtable, &subTableMax);

                if (subTableMax > *depth)
                    *depth = subTableMax;
            }
        }
    }

    return LF_ERROR_OK;
}

/* ----------------------------------------------------------------------------
    @summary
        this method goes through the feature table and removes any of
        the hanging lookups that may be left over from pruning and
        subsetting.

    @param
        lfFont        :    pointer to the main font structure.

---------------------------------------------------------------------------- */
LF_ERROR GSUB_cleanupLookups(LF_FONT* lfFont)
{
    gsub_header* table = (gsub_header*)map_at(&lfFont->table_map, (void*)TAG_GSUB);
    if (table)
    {
        table->calculatedTableSize = 0;

        TABLE_HANDLE hLookup = (TABLE_HANDLE)table->LookupList;
        TABLE_HANDLE hFeature = (TABLE_HANDLE)table->FeatureList;

        Feature_cleanupLookups(hFeature, hLookup, FALSE);
    }
    return LF_ERROR_OK;
}


LF_ERROR GSUB_cleanupLookupSubtables(USHORT lookupType, TABLE_HANDLE subtable, TABLE_HANDLE hLookup)
{
    //LF_ERROR error = LF_NOT_COVERED;  not used TODO remove?
    base_table* base = (base_table*)subtable;

    // flag the reference count, that we need this subtable
    base->refCount = 1;

    switch (lookupType)
    {
    case GSUB_LOOKUP_CONTEXT:
        /*error = */GSUB_cleanupContextLookups((gsub_context_substitution*)subtable, hLookup);
        break;
    case GSUB_LOOKUP_CHAIN:
        /*error = */GSUB_cleanupChainContextLookups((gsub_chain_context_substitution*)subtable, hLookup);
        break;
    case GSUB_LOOKUP_REVERSE_CHAIN:
        DEBUG_LOG("reverse chain detected");
        break;
    default:
        break;
    }

    return LF_ERROR_OK;
}

LF_ERROR GSUB_removeUnReferencedLookups(LF_FONT* lfFont)
{
    gsub_header* table = (gsub_header*)map_at(&lfFont->table_map, (void*)TAG_GSUB);
    if (table)
    {
        table->calculatedTableSize = 0;

        TABLE_HANDLE hLookup = (TABLE_HANDLE)table->LookupList;
        Lookup_removeUnReferencedLookups(hLookup, table, FALSE);
    }
    return LF_ERROR_OK;
}

LF_ERROR GSUB_updateLookupFlags(LF_FONT* lfFont)
{
    // This updates lookup flags based on presence/absence of the GDEF table.
    // TODO update based on content of GDEF if it is there

    gsub_header* table = (gsub_header*)map_at(&lfFont->table_map, (void*)TAG_GSUB);
    if (table == NULL)
        return LF_TABLE_MISSING;

    if (FALSE == map_key_exists(&lfFont->table_map, (void*)TAG_GDEF))
    {
        // there is no GDEF table, so we need to update flags in the lookup tables to
        // clear out any that require GDEF
        if (table->LookupList != NULL)
            return Lookup_clearGDEFFlags(table->LookupList);
    }
    return LF_ERROR_OK;
}

/* ----------------------------------------------------------------------------
    @summary
        goes into the individual subtables and determines if we need to
        keep any glyphs due to substitution rules.

---------------------------------------------------------------------------- */
LF_ERROR GSUB_collectSubtableGlyphs(GlyphList* keepList, TABLE_HANDLE hTable, USHORT lookupType, TABLE_HANDLE hSubTable)
{
    LF_ERROR        error = LF_NOT_COVERED;
    //gsub_header*    gsubTable = (gsub_header*)hTable;

    switch (lookupType)
    {
    case GSUB_LOOKUP_SINGLE:        error = GSUB_keepSingleSubstGlyphs((gsub_single_substitution*)hSubTable, keepList);               break;
    case GSUB_LOOKUP_MULTIPLE:      error = GSUB_keepMultipleSubstGlyphs((gsub_multiple_substitution*)hSubTable, keepList);           break;
    case GSUB_LOOKUP_ALTERNATE:     error = GSUB_keepAlternateSubstGlyphs((gsub_alternate_substitution*)hSubTable, keepList);         break;
    case GSUB_LOOKUP_LIGATURE:      error = GSUB_keepLigSubstGlyphs((gsub_ligature*)hSubTable, keepList);                             break;
    case GSUB_LOOKUP_CONTEXT:       error = GSUB_collectContextSubstGlyphs(keepList, hTable, (gsub_context_substitution*)hSubTable);       break;
    case GSUB_LOOKUP_CHAIN:         error = GSUB_collectChainContextGlyphs(keepList, hTable, (gsub_chain_context_substitution*)hSubTable); break;
//    case GSUB_LOOKUP_REVERSE_CHAIN:    error = GSUB_keepReverseChainSingleSubstGlyphs((gsub_reverse_chain_single_substitution*)hSubTable);    break;
    case GSUB_LOOKUP_EXTENSION:     error = LF_ERROR_OK;                                                                               break;
    default:                        error = LF_NOT_COVERED;                                                                            break;
    }

    return error;
}

LF_ERROR GSUB_collectGlyphs(LF_FONT* lfFont, GlyphList* keepList)
{
    LF_ERROR        error = LF_ERROR_OK;
    gsub_header*    gsubTable = (gsub_header*)map_at(&lfFont->table_map, (void*)TAG_GSUB);

    if (gsubTable)
    {
        Lookup_clearCollectFlags(gsubTable);

        error = Script_collectGlyphs(keepList, (TABLE_HANDLE)gsubTable);

        if ((error == LF_ERROR_OK) || (error == LF_ADDED_GLYPH))
        {
            LF_ERROR lookupError = Lookup_collectUncollectedAlternateGlyphs(keepList, gsubTable);

            if (lookupError != LF_ERROR_OK)
                error = lookupError;
        }
    }

    return error;
}

script_table* GSUB_getScriptTable(LF_FONT* lfFont, TAG tag)
{
    gsub_header* gsubTable = (gsub_header*)map_at(&lfFont->table_map, (void*)TAG_GSUB);

    if (gsubTable)
    {
        LF_VECTOR* script_list_table = (LF_VECTOR*)gsubTable->ScriptList;
        ULONG i;

        for (i = 0; i < script_list_table->count; ++i)
        {
            script_table* scriptTable = (script_table*)vector_at(script_list_table, i);
            if (scriptTable->ScriptTag == tag)
                return scriptTable;
        }
    }

    return NULL;
}

feature_table* GSUB_getFeatureTable(LF_FONT* lfFont, langsys_table* langTable, TAG tag)
{
    gsub_header* gsubTable = (gsub_header*)map_at(&lfFont->table_map, (void*)TAG_GSUB);

    if (gsubTable)
    {
        feature_list* featList = (feature_list*)gsubTable->FeatureList;
        LF_VECTOR* feature_list_table = &featList->features;
        ULONG i;

        for (i = 0; i < langTable->FeatureCount; ++i)
        {
            USHORT featureIndex = (USHORT)(intptr_t)vector_at(&langTable->FeatureIndex, i);

            feature_table* featureTable = (feature_table*)vector_at(feature_list_table, featureIndex);
            if (featureTable->FeatureTag == tag)
                return featureTable;
        }
    }

    return NULL;
}

lookup_table* GSUB_getLookupTable(LF_FONT* lfFont, feature_table* featureTable, ULONG index)
{
    gsub_header* gsubTable = (gsub_header*)map_at(&lfFont->table_map, (void*)TAG_GSUB);
    LF_VECTOR* lookup_list_table = (LF_VECTOR*)gsubTable->LookupList;

    USHORT lookupIndex = (USHORT)(intptr_t)vector_at(&featureTable->LookupListIndex, 0);

    UNUSED(index);

    return (lookup_table*)vector_at(lookup_list_table, lookupIndex);
}
