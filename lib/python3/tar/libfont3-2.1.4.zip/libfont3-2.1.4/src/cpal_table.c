// Copyright (C) 2016 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// cpal_table.c

#include "cpal_table.h"
#include "table_tags.h"
#include "utils.h"

LF_ERROR CPAL_readTable(LF_FONT* lfFont, const sfnt_table_record* record, LF_STREAM* stream)
{
    if(STREAM_streamSeek(stream, record->offset) == 0)
    {
        if(record->length > 0)
        {
            cpal_table* table = (cpal_table*)malloc(sizeof(cpal_table));
            if(table)
            {
                table->length = record->length;
                table->data = STREAM_readChunk(stream, table->length);

                map_insert(&lfFont->table_map, (void*)(intptr_t)record->tag, table);
                return LF_ERROR_OK;
            }
            else
                return LF_OUT_OF_MEMORY;
        }
    }

    return LF_INVALID_OFFSET;
}

LF_ERROR CPAL_getTableSize(LF_FONT* lfFont, size_t* tableSize)
{
    cpal_table* table = (cpal_table*)map_at(&lfFont->table_map, (void*)(long)TAG_CPAL);

    *tableSize = 0;

    if(table == NULL)
        return LF_EMPTY_TABLE;

    *tableSize = table->length;

    return LF_ERROR_OK;
}

LF_ERROR CPAL_writeTable(LF_FONT* lfFont, sfnt_table_record* record, LF_STREAM* stream)
{
    ULONG padLen = 0;
    cpal_table* table = (cpal_table*)map_at(&lfFont->table_map, (void*)(intptr_t)record->tag);

    if(table == NULL)
        return LF_EMPTY_TABLE;

    UTILS_PadTable(&table->data, table->length, &padLen);

    record->checkSum = UTILS_CalcTableChecksum(table->data, table->length);
    record->length = table->length;
    record->offset = (ULONG)STREAM_streamPos(stream);

    STREAM_streamSeek(stream, record->offset);
    STREAM_writeChunk(stream, table->data, padLen);

    return LF_ERROR_OK;
}

LF_ERROR CPAL_freeTable(LF_FONT* lfFont)
{
    cpal_table* table = (cpal_table*)map_at(&lfFont->table_map, (void*)(long)TAG_CPAL);

    if(table)
    {
        free(table->data);
        free(table);
    }

    return LF_ERROR_OK;
}
