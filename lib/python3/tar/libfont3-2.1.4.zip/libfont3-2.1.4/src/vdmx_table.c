// Copyright (C) 2014 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// vdmx_table.c

#include "vdmx_table.h"
#include "table_tags.h"
#include "unknown_table.h"


#if 0 // The below functions are not yet implemented.
LF_ERROR VDMX_readTable(LF_FONT* lfFont, const sfnt_table_record* record, LF_STREAM* stream)
{
    return UNKNOWN_readTable(lfFont, record, stream);
}

LF_ERROR VDMX_getTableSize(LF_FONT* lfFont, size_t* tableSize)
{
    return UNKNOWN_getTableSize(lfFont, TAG_VDMX, tableSize);
}

LF_ERROR VDMX_writeTable(LF_FONT* lfFont, sfnt_table_record* record, LF_STREAM* stream)
{
    return UNKNOWN_writeTable(lfFont, record, stream);
}

LF_ERROR VDMX_freeTable(LF_FONT* lfFont, const sfnt_table_record* record)
{
    return UNKNOWN_freeTable(lfFont, record);
}
#endif
