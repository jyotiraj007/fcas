// Copyright (C) 2014 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// norm_nfcdat.c

#include "normalization/norm_nfcdat.h"

/* ******************** Begin Script-Generated Code  ******************** */

/************************************************************
 * The following table was generated from:
 *    http://www.unicode.org/Public/UNIDATA/UnicodeData.txt
 * by the Python script:
 *    CompositionTables.py
 * on:
 *    Wed 13 Feb 2013 @ 12:35:55
 ************************************************************/


const CompositionDataType
compositionData[] = 
{
   /* --------------- block_00_03 @    0 --------------- */
   { 0x3C, 0x38, 0x226E }, /* 0x003C + 0x0338 = 0x226E NOT LESS-THAN                                                            */
   { 0x3D, 0x38, 0x2260 }, /* 0x003D + 0x0338 = 0x2260 NOT EQUAL TO                                                             */
   { 0x3E, 0x38, 0x226F }, /* 0x003E + 0x0338 = 0x226F NOT GREATER-THAN                                                         */
   { 0x41, 0x00, 0x00C0 }, /* 0x0041 + 0x0300 = 0x00C0 LATIN CAPITAL LETTER A WITH GRAVE                                        */
   { 0x41, 0x01, 0x00C1 }, /* 0x0041 + 0x0301 = 0x00C1 LATIN CAPITAL LETTER A WITH ACUTE                                        */
   { 0x41, 0x02, 0x00C2 }, /* 0x0041 + 0x0302 = 0x00C2 LATIN CAPITAL LETTER A WITH CIRCUMFLEX                                   */
   { 0x41, 0x03, 0x00C3 }, /* 0x0041 + 0x0303 = 0x00C3 LATIN CAPITAL LETTER A WITH TILDE                                        */
   { 0x41, 0x04, 0x0100 }, /* 0x0041 + 0x0304 = 0x0100 LATIN CAPITAL LETTER A WITH MACRON                                       */
   { 0x41, 0x06, 0x0102 }, /* 0x0041 + 0x0306 = 0x0102 LATIN CAPITAL LETTER A WITH BREVE                                        */
   { 0x41, 0x07, 0x0226 }, /* 0x0041 + 0x0307 = 0x0226 LATIN CAPITAL LETTER A WITH DOT ABOVE                                    */
   { 0x41, 0x08, 0x00C4 }, /* 0x0041 + 0x0308 = 0x00C4 LATIN CAPITAL LETTER A WITH DIAERESIS                                    */
   { 0x41, 0x09, 0x1EA2 }, /* 0x0041 + 0x0309 = 0x1EA2 LATIN CAPITAL LETTER A WITH HOOK ABOVE                                   */
   { 0x41, 0x0A, 0x00C5 }, /* 0x0041 + 0x030A = 0x00C5 LATIN CAPITAL LETTER A WITH RING ABOVE                                   */
   { 0x41, 0x0C, 0x01CD }, /* 0x0041 + 0x030C = 0x01CD LATIN CAPITAL LETTER A WITH CARON                                        */
   { 0x41, 0x0F, 0x0200 }, /* 0x0041 + 0x030F = 0x0200 LATIN CAPITAL LETTER A WITH DOUBLE GRAVE                                 */
   { 0x41, 0x11, 0x0202 }, /* 0x0041 + 0x0311 = 0x0202 LATIN CAPITAL LETTER A WITH INVERTED BREVE                               */
   { 0x41, 0x23, 0x1EA0 }, /* 0x0041 + 0x0323 = 0x1EA0 LATIN CAPITAL LETTER A WITH DOT BELOW                                    */
   { 0x41, 0x25, 0x1E00 }, /* 0x0041 + 0x0325 = 0x1E00 LATIN CAPITAL LETTER A WITH RING BELOW                                   */
   { 0x41, 0x28, 0x0104 }, /* 0x0041 + 0x0328 = 0x0104 LATIN CAPITAL LETTER A WITH OGONEK                                       */
   { 0x42, 0x07, 0x1E02 }, /* 0x0042 + 0x0307 = 0x1E02 LATIN CAPITAL LETTER B WITH DOT ABOVE                                    */
   { 0x42, 0x23, 0x1E04 }, /* 0x0042 + 0x0323 = 0x1E04 LATIN CAPITAL LETTER B WITH DOT BELOW                                    */
   { 0x42, 0x31, 0x1E06 }, /* 0x0042 + 0x0331 = 0x1E06 LATIN CAPITAL LETTER B WITH LINE BELOW                                   */
   { 0x43, 0x01, 0x0106 }, /* 0x0043 + 0x0301 = 0x0106 LATIN CAPITAL LETTER C WITH ACUTE                                        */
   { 0x43, 0x02, 0x0108 }, /* 0x0043 + 0x0302 = 0x0108 LATIN CAPITAL LETTER C WITH CIRCUMFLEX                                   */
   { 0x43, 0x07, 0x010A }, /* 0x0043 + 0x0307 = 0x010A LATIN CAPITAL LETTER C WITH DOT ABOVE                                    */
   { 0x43, 0x0C, 0x010C }, /* 0x0043 + 0x030C = 0x010C LATIN CAPITAL LETTER C WITH CARON                                        */
   { 0x43, 0x27, 0x00C7 }, /* 0x0043 + 0x0327 = 0x00C7 LATIN CAPITAL LETTER C WITH CEDILLA                                      */
   { 0x44, 0x07, 0x1E0A }, /* 0x0044 + 0x0307 = 0x1E0A LATIN CAPITAL LETTER D WITH DOT ABOVE                                    */
   { 0x44, 0x0C, 0x010E }, /* 0x0044 + 0x030C = 0x010E LATIN CAPITAL LETTER D WITH CARON                                        */
   { 0x44, 0x23, 0x1E0C }, /* 0x0044 + 0x0323 = 0x1E0C LATIN CAPITAL LETTER D WITH DOT BELOW                                    */
   { 0x44, 0x27, 0x1E10 }, /* 0x0044 + 0x0327 = 0x1E10 LATIN CAPITAL LETTER D WITH CEDILLA                                      */
   { 0x44, 0x2D, 0x1E12 }, /* 0x0044 + 0x032D = 0x1E12 LATIN CAPITAL LETTER D WITH CIRCUMFLEX BELOW                             */
   { 0x44, 0x31, 0x1E0E }, /* 0x0044 + 0x0331 = 0x1E0E LATIN CAPITAL LETTER D WITH LINE BELOW                                   */
   { 0x45, 0x00, 0x00C8 }, /* 0x0045 + 0x0300 = 0x00C8 LATIN CAPITAL LETTER E WITH GRAVE                                        */
   { 0x45, 0x01, 0x00C9 }, /* 0x0045 + 0x0301 = 0x00C9 LATIN CAPITAL LETTER E WITH ACUTE                                        */
   { 0x45, 0x02, 0x00CA }, /* 0x0045 + 0x0302 = 0x00CA LATIN CAPITAL LETTER E WITH CIRCUMFLEX                                   */
   { 0x45, 0x03, 0x1EBC }, /* 0x0045 + 0x0303 = 0x1EBC LATIN CAPITAL LETTER E WITH TILDE                                        */
   { 0x45, 0x04, 0x0112 }, /* 0x0045 + 0x0304 = 0x0112 LATIN CAPITAL LETTER E WITH MACRON                                       */
   { 0x45, 0x06, 0x0114 }, /* 0x0045 + 0x0306 = 0x0114 LATIN CAPITAL LETTER E WITH BREVE                                        */
   { 0x45, 0x07, 0x0116 }, /* 0x0045 + 0x0307 = 0x0116 LATIN CAPITAL LETTER E WITH DOT ABOVE                                    */
   { 0x45, 0x08, 0x00CB }, /* 0x0045 + 0x0308 = 0x00CB LATIN CAPITAL LETTER E WITH DIAERESIS                                    */
   { 0x45, 0x09, 0x1EBA }, /* 0x0045 + 0x0309 = 0x1EBA LATIN CAPITAL LETTER E WITH HOOK ABOVE                                   */
   { 0x45, 0x0C, 0x011A }, /* 0x0045 + 0x030C = 0x011A LATIN CAPITAL LETTER E WITH CARON                                        */
   { 0x45, 0x0F, 0x0204 }, /* 0x0045 + 0x030F = 0x0204 LATIN CAPITAL LETTER E WITH DOUBLE GRAVE                                 */
   { 0x45, 0x11, 0x0206 }, /* 0x0045 + 0x0311 = 0x0206 LATIN CAPITAL LETTER E WITH INVERTED BREVE                               */
   { 0x45, 0x23, 0x1EB8 }, /* 0x0045 + 0x0323 = 0x1EB8 LATIN CAPITAL LETTER E WITH DOT BELOW                                    */
   { 0x45, 0x27, 0x0228 }, /* 0x0045 + 0x0327 = 0x0228 LATIN CAPITAL LETTER E WITH CEDILLA                                      */
   { 0x45, 0x28, 0x0118 }, /* 0x0045 + 0x0328 = 0x0118 LATIN CAPITAL LETTER E WITH OGONEK                                       */
   { 0x45, 0x2D, 0x1E18 }, /* 0x0045 + 0x032D = 0x1E18 LATIN CAPITAL LETTER E WITH CIRCUMFLEX BELOW                             */
   { 0x45, 0x30, 0x1E1A }, /* 0x0045 + 0x0330 = 0x1E1A LATIN CAPITAL LETTER E WITH TILDE BELOW                                  */
   { 0x46, 0x07, 0x1E1E }, /* 0x0046 + 0x0307 = 0x1E1E LATIN CAPITAL LETTER F WITH DOT ABOVE                                    */
   { 0x47, 0x01, 0x01F4 }, /* 0x0047 + 0x0301 = 0x01F4 LATIN CAPITAL LETTER G WITH ACUTE                                        */
   { 0x47, 0x02, 0x011C }, /* 0x0047 + 0x0302 = 0x011C LATIN CAPITAL LETTER G WITH CIRCUMFLEX                                   */
   { 0x47, 0x04, 0x1E20 }, /* 0x0047 + 0x0304 = 0x1E20 LATIN CAPITAL LETTER G WITH MACRON                                       */
   { 0x47, 0x06, 0x011E }, /* 0x0047 + 0x0306 = 0x011E LATIN CAPITAL LETTER G WITH BREVE                                        */
   { 0x47, 0x07, 0x0120 }, /* 0x0047 + 0x0307 = 0x0120 LATIN CAPITAL LETTER G WITH DOT ABOVE                                    */
   { 0x47, 0x0C, 0x01E6 }, /* 0x0047 + 0x030C = 0x01E6 LATIN CAPITAL LETTER G WITH CARON                                        */
   { 0x47, 0x27, 0x0122 }, /* 0x0047 + 0x0327 = 0x0122 LATIN CAPITAL LETTER G WITH CEDILLA                                      */
   { 0x48, 0x02, 0x0124 }, /* 0x0048 + 0x0302 = 0x0124 LATIN CAPITAL LETTER H WITH CIRCUMFLEX                                   */
   { 0x48, 0x07, 0x1E22 }, /* 0x0048 + 0x0307 = 0x1E22 LATIN CAPITAL LETTER H WITH DOT ABOVE                                    */
   { 0x48, 0x08, 0x1E26 }, /* 0x0048 + 0x0308 = 0x1E26 LATIN CAPITAL LETTER H WITH DIAERESIS                                    */
   { 0x48, 0x0C, 0x021E }, /* 0x0048 + 0x030C = 0x021E LATIN CAPITAL LETTER H WITH CARON                                        */
   { 0x48, 0x23, 0x1E24 }, /* 0x0048 + 0x0323 = 0x1E24 LATIN CAPITAL LETTER H WITH DOT BELOW                                    */
   { 0x48, 0x27, 0x1E28 }, /* 0x0048 + 0x0327 = 0x1E28 LATIN CAPITAL LETTER H WITH CEDILLA                                      */
   { 0x48, 0x2E, 0x1E2A }, /* 0x0048 + 0x032E = 0x1E2A LATIN CAPITAL LETTER H WITH BREVE BELOW                                  */
   { 0x49, 0x00, 0x00CC }, /* 0x0049 + 0x0300 = 0x00CC LATIN CAPITAL LETTER I WITH GRAVE                                        */
   { 0x49, 0x01, 0x00CD }, /* 0x0049 + 0x0301 = 0x00CD LATIN CAPITAL LETTER I WITH ACUTE                                        */
   { 0x49, 0x02, 0x00CE }, /* 0x0049 + 0x0302 = 0x00CE LATIN CAPITAL LETTER I WITH CIRCUMFLEX                                   */
   { 0x49, 0x03, 0x0128 }, /* 0x0049 + 0x0303 = 0x0128 LATIN CAPITAL LETTER I WITH TILDE                                        */
   { 0x49, 0x04, 0x012A }, /* 0x0049 + 0x0304 = 0x012A LATIN CAPITAL LETTER I WITH MACRON                                       */
   { 0x49, 0x06, 0x012C }, /* 0x0049 + 0x0306 = 0x012C LATIN CAPITAL LETTER I WITH BREVE                                        */
   { 0x49, 0x07, 0x0130 }, /* 0x0049 + 0x0307 = 0x0130 LATIN CAPITAL LETTER I WITH DOT ABOVE                                    */
   { 0x49, 0x08, 0x00CF }, /* 0x0049 + 0x0308 = 0x00CF LATIN CAPITAL LETTER I WITH DIAERESIS                                    */
   { 0x49, 0x09, 0x1EC8 }, /* 0x0049 + 0x0309 = 0x1EC8 LATIN CAPITAL LETTER I WITH HOOK ABOVE                                   */
   { 0x49, 0x0C, 0x01CF }, /* 0x0049 + 0x030C = 0x01CF LATIN CAPITAL LETTER I WITH CARON                                        */
   { 0x49, 0x0F, 0x0208 }, /* 0x0049 + 0x030F = 0x0208 LATIN CAPITAL LETTER I WITH DOUBLE GRAVE                                 */
   { 0x49, 0x11, 0x020A }, /* 0x0049 + 0x0311 = 0x020A LATIN CAPITAL LETTER I WITH INVERTED BREVE                               */
   { 0x49, 0x23, 0x1ECA }, /* 0x0049 + 0x0323 = 0x1ECA LATIN CAPITAL LETTER I WITH DOT BELOW                                    */
   { 0x49, 0x28, 0x012E }, /* 0x0049 + 0x0328 = 0x012E LATIN CAPITAL LETTER I WITH OGONEK                                       */
   { 0x49, 0x30, 0x1E2C }, /* 0x0049 + 0x0330 = 0x1E2C LATIN CAPITAL LETTER I WITH TILDE BELOW                                  */
   { 0x4A, 0x02, 0x0134 }, /* 0x004A + 0x0302 = 0x0134 LATIN CAPITAL LETTER J WITH CIRCUMFLEX                                   */
   { 0x4B, 0x01, 0x1E30 }, /* 0x004B + 0x0301 = 0x1E30 LATIN CAPITAL LETTER K WITH ACUTE                                        */
   { 0x4B, 0x0C, 0x01E8 }, /* 0x004B + 0x030C = 0x01E8 LATIN CAPITAL LETTER K WITH CARON                                        */
   { 0x4B, 0x23, 0x1E32 }, /* 0x004B + 0x0323 = 0x1E32 LATIN CAPITAL LETTER K WITH DOT BELOW                                    */
   { 0x4B, 0x27, 0x0136 }, /* 0x004B + 0x0327 = 0x0136 LATIN CAPITAL LETTER K WITH CEDILLA                                      */
   { 0x4B, 0x31, 0x1E34 }, /* 0x004B + 0x0331 = 0x1E34 LATIN CAPITAL LETTER K WITH LINE BELOW                                   */
   { 0x4C, 0x01, 0x0139 }, /* 0x004C + 0x0301 = 0x0139 LATIN CAPITAL LETTER L WITH ACUTE                                        */
   { 0x4C, 0x0C, 0x013D }, /* 0x004C + 0x030C = 0x013D LATIN CAPITAL LETTER L WITH CARON                                        */
   { 0x4C, 0x23, 0x1E36 }, /* 0x004C + 0x0323 = 0x1E36 LATIN CAPITAL LETTER L WITH DOT BELOW                                    */
   { 0x4C, 0x27, 0x013B }, /* 0x004C + 0x0327 = 0x013B LATIN CAPITAL LETTER L WITH CEDILLA                                      */
   { 0x4C, 0x2D, 0x1E3C }, /* 0x004C + 0x032D = 0x1E3C LATIN CAPITAL LETTER L WITH CIRCUMFLEX BELOW                             */
   { 0x4C, 0x31, 0x1E3A }, /* 0x004C + 0x0331 = 0x1E3A LATIN CAPITAL LETTER L WITH LINE BELOW                                   */
   { 0x4D, 0x01, 0x1E3E }, /* 0x004D + 0x0301 = 0x1E3E LATIN CAPITAL LETTER M WITH ACUTE                                        */
   { 0x4D, 0x07, 0x1E40 }, /* 0x004D + 0x0307 = 0x1E40 LATIN CAPITAL LETTER M WITH DOT ABOVE                                    */
   { 0x4D, 0x23, 0x1E42 }, /* 0x004D + 0x0323 = 0x1E42 LATIN CAPITAL LETTER M WITH DOT BELOW                                    */
   { 0x4E, 0x00, 0x01F8 }, /* 0x004E + 0x0300 = 0x01F8 LATIN CAPITAL LETTER N WITH GRAVE                                        */
   { 0x4E, 0x01, 0x0143 }, /* 0x004E + 0x0301 = 0x0143 LATIN CAPITAL LETTER N WITH ACUTE                                        */
   { 0x4E, 0x03, 0x00D1 }, /* 0x004E + 0x0303 = 0x00D1 LATIN CAPITAL LETTER N WITH TILDE                                        */
   { 0x4E, 0x07, 0x1E44 }, /* 0x004E + 0x0307 = 0x1E44 LATIN CAPITAL LETTER N WITH DOT ABOVE                                    */
   { 0x4E, 0x0C, 0x0147 }, /* 0x004E + 0x030C = 0x0147 LATIN CAPITAL LETTER N WITH CARON                                        */
   { 0x4E, 0x23, 0x1E46 }, /* 0x004E + 0x0323 = 0x1E46 LATIN CAPITAL LETTER N WITH DOT BELOW                                    */
   { 0x4E, 0x27, 0x0145 }, /* 0x004E + 0x0327 = 0x0145 LATIN CAPITAL LETTER N WITH CEDILLA                                      */
   { 0x4E, 0x2D, 0x1E4A }, /* 0x004E + 0x032D = 0x1E4A LATIN CAPITAL LETTER N WITH CIRCUMFLEX BELOW                             */
   { 0x4E, 0x31, 0x1E48 }, /* 0x004E + 0x0331 = 0x1E48 LATIN CAPITAL LETTER N WITH LINE BELOW                                   */
   { 0x4F, 0x00, 0x00D2 }, /* 0x004F + 0x0300 = 0x00D2 LATIN CAPITAL LETTER O WITH GRAVE                                        */
   { 0x4F, 0x01, 0x00D3 }, /* 0x004F + 0x0301 = 0x00D3 LATIN CAPITAL LETTER O WITH ACUTE                                        */
   { 0x4F, 0x02, 0x00D4 }, /* 0x004F + 0x0302 = 0x00D4 LATIN CAPITAL LETTER O WITH CIRCUMFLEX                                   */
   { 0x4F, 0x03, 0x00D5 }, /* 0x004F + 0x0303 = 0x00D5 LATIN CAPITAL LETTER O WITH TILDE                                        */
   { 0x4F, 0x04, 0x014C }, /* 0x004F + 0x0304 = 0x014C LATIN CAPITAL LETTER O WITH MACRON                                       */
   { 0x4F, 0x06, 0x014E }, /* 0x004F + 0x0306 = 0x014E LATIN CAPITAL LETTER O WITH BREVE                                        */
   { 0x4F, 0x07, 0x022E }, /* 0x004F + 0x0307 = 0x022E LATIN CAPITAL LETTER O WITH DOT ABOVE                                    */
   { 0x4F, 0x08, 0x00D6 }, /* 0x004F + 0x0308 = 0x00D6 LATIN CAPITAL LETTER O WITH DIAERESIS                                    */
   { 0x4F, 0x09, 0x1ECE }, /* 0x004F + 0x0309 = 0x1ECE LATIN CAPITAL LETTER O WITH HOOK ABOVE                                   */
   { 0x4F, 0x0B, 0x0150 }, /* 0x004F + 0x030B = 0x0150 LATIN CAPITAL LETTER O WITH DOUBLE ACUTE                                 */
   { 0x4F, 0x0C, 0x01D1 }, /* 0x004F + 0x030C = 0x01D1 LATIN CAPITAL LETTER O WITH CARON                                        */
   { 0x4F, 0x0F, 0x020C }, /* 0x004F + 0x030F = 0x020C LATIN CAPITAL LETTER O WITH DOUBLE GRAVE                                 */
   { 0x4F, 0x11, 0x020E }, /* 0x004F + 0x0311 = 0x020E LATIN CAPITAL LETTER O WITH INVERTED BREVE                               */
   { 0x4F, 0x1B, 0x01A0 }, /* 0x004F + 0x031B = 0x01A0 LATIN CAPITAL LETTER O WITH HORN                                         */
   { 0x4F, 0x23, 0x1ECC }, /* 0x004F + 0x0323 = 0x1ECC LATIN CAPITAL LETTER O WITH DOT BELOW                                    */
   { 0x4F, 0x28, 0x01EA }, /* 0x004F + 0x0328 = 0x01EA LATIN CAPITAL LETTER O WITH OGONEK                                       */
   { 0x50, 0x01, 0x1E54 }, /* 0x0050 + 0x0301 = 0x1E54 LATIN CAPITAL LETTER P WITH ACUTE                                        */
   { 0x50, 0x07, 0x1E56 }, /* 0x0050 + 0x0307 = 0x1E56 LATIN CAPITAL LETTER P WITH DOT ABOVE                                    */
   { 0x52, 0x01, 0x0154 }, /* 0x0052 + 0x0301 = 0x0154 LATIN CAPITAL LETTER R WITH ACUTE                                        */
   { 0x52, 0x07, 0x1E58 }, /* 0x0052 + 0x0307 = 0x1E58 LATIN CAPITAL LETTER R WITH DOT ABOVE                                    */
   { 0x52, 0x0C, 0x0158 }, /* 0x0052 + 0x030C = 0x0158 LATIN CAPITAL LETTER R WITH CARON                                        */
   { 0x52, 0x0F, 0x0210 }, /* 0x0052 + 0x030F = 0x0210 LATIN CAPITAL LETTER R WITH DOUBLE GRAVE                                 */
   { 0x52, 0x11, 0x0212 }, /* 0x0052 + 0x0311 = 0x0212 LATIN CAPITAL LETTER R WITH INVERTED BREVE                               */
   { 0x52, 0x23, 0x1E5A }, /* 0x0052 + 0x0323 = 0x1E5A LATIN CAPITAL LETTER R WITH DOT BELOW                                    */
   { 0x52, 0x27, 0x0156 }, /* 0x0052 + 0x0327 = 0x0156 LATIN CAPITAL LETTER R WITH CEDILLA                                      */
   { 0x52, 0x31, 0x1E5E }, /* 0x0052 + 0x0331 = 0x1E5E LATIN CAPITAL LETTER R WITH LINE BELOW                                   */
   { 0x53, 0x01, 0x015A }, /* 0x0053 + 0x0301 = 0x015A LATIN CAPITAL LETTER S WITH ACUTE                                        */
   { 0x53, 0x02, 0x015C }, /* 0x0053 + 0x0302 = 0x015C LATIN CAPITAL LETTER S WITH CIRCUMFLEX                                   */
   { 0x53, 0x07, 0x1E60 }, /* 0x0053 + 0x0307 = 0x1E60 LATIN CAPITAL LETTER S WITH DOT ABOVE                                    */
   { 0x53, 0x0C, 0x0160 }, /* 0x0053 + 0x030C = 0x0160 LATIN CAPITAL LETTER S WITH CARON                                        */
   { 0x53, 0x23, 0x1E62 }, /* 0x0053 + 0x0323 = 0x1E62 LATIN CAPITAL LETTER S WITH DOT BELOW                                    */
   { 0x53, 0x26, 0x0218 }, /* 0x0053 + 0x0326 = 0x0218 LATIN CAPITAL LETTER S WITH COMMA BELOW                                  */
   { 0x53, 0x27, 0x015E }, /* 0x0053 + 0x0327 = 0x015E LATIN CAPITAL LETTER S WITH CEDILLA                                      */
   { 0x54, 0x07, 0x1E6A }, /* 0x0054 + 0x0307 = 0x1E6A LATIN CAPITAL LETTER T WITH DOT ABOVE                                    */
   { 0x54, 0x0C, 0x0164 }, /* 0x0054 + 0x030C = 0x0164 LATIN CAPITAL LETTER T WITH CARON                                        */
   { 0x54, 0x23, 0x1E6C }, /* 0x0054 + 0x0323 = 0x1E6C LATIN CAPITAL LETTER T WITH DOT BELOW                                    */
   { 0x54, 0x26, 0x021A }, /* 0x0054 + 0x0326 = 0x021A LATIN CAPITAL LETTER T WITH COMMA BELOW                                  */
   { 0x54, 0x27, 0x0162 }, /* 0x0054 + 0x0327 = 0x0162 LATIN CAPITAL LETTER T WITH CEDILLA                                      */
   { 0x54, 0x2D, 0x1E70 }, /* 0x0054 + 0x032D = 0x1E70 LATIN CAPITAL LETTER T WITH CIRCUMFLEX BELOW                             */
   { 0x54, 0x31, 0x1E6E }, /* 0x0054 + 0x0331 = 0x1E6E LATIN CAPITAL LETTER T WITH LINE BELOW                                   */
   { 0x55, 0x00, 0x00D9 }, /* 0x0055 + 0x0300 = 0x00D9 LATIN CAPITAL LETTER U WITH GRAVE                                        */
   { 0x55, 0x01, 0x00DA }, /* 0x0055 + 0x0301 = 0x00DA LATIN CAPITAL LETTER U WITH ACUTE                                        */
   { 0x55, 0x02, 0x00DB }, /* 0x0055 + 0x0302 = 0x00DB LATIN CAPITAL LETTER U WITH CIRCUMFLEX                                   */
   { 0x55, 0x03, 0x0168 }, /* 0x0055 + 0x0303 = 0x0168 LATIN CAPITAL LETTER U WITH TILDE                                        */
   { 0x55, 0x04, 0x016A }, /* 0x0055 + 0x0304 = 0x016A LATIN CAPITAL LETTER U WITH MACRON                                       */
   { 0x55, 0x06, 0x016C }, /* 0x0055 + 0x0306 = 0x016C LATIN CAPITAL LETTER U WITH BREVE                                        */
   { 0x55, 0x08, 0x00DC }, /* 0x0055 + 0x0308 = 0x00DC LATIN CAPITAL LETTER U WITH DIAERESIS                                    */
   { 0x55, 0x09, 0x1EE6 }, /* 0x0055 + 0x0309 = 0x1EE6 LATIN CAPITAL LETTER U WITH HOOK ABOVE                                   */
   { 0x55, 0x0A, 0x016E }, /* 0x0055 + 0x030A = 0x016E LATIN CAPITAL LETTER U WITH RING ABOVE                                   */
   { 0x55, 0x0B, 0x0170 }, /* 0x0055 + 0x030B = 0x0170 LATIN CAPITAL LETTER U WITH DOUBLE ACUTE                                 */
   { 0x55, 0x0C, 0x01D3 }, /* 0x0055 + 0x030C = 0x01D3 LATIN CAPITAL LETTER U WITH CARON                                        */
   { 0x55, 0x0F, 0x0214 }, /* 0x0055 + 0x030F = 0x0214 LATIN CAPITAL LETTER U WITH DOUBLE GRAVE                                 */
   { 0x55, 0x11, 0x0216 }, /* 0x0055 + 0x0311 = 0x0216 LATIN CAPITAL LETTER U WITH INVERTED BREVE                               */
   { 0x55, 0x1B, 0x01AF }, /* 0x0055 + 0x031B = 0x01AF LATIN CAPITAL LETTER U WITH HORN                                         */
   { 0x55, 0x23, 0x1EE4 }, /* 0x0055 + 0x0323 = 0x1EE4 LATIN CAPITAL LETTER U WITH DOT BELOW                                    */
   { 0x55, 0x24, 0x1E72 }, /* 0x0055 + 0x0324 = 0x1E72 LATIN CAPITAL LETTER U WITH DIAERESIS BELOW                              */
   { 0x55, 0x28, 0x0172 }, /* 0x0055 + 0x0328 = 0x0172 LATIN CAPITAL LETTER U WITH OGONEK                                       */
   { 0x55, 0x2D, 0x1E76 }, /* 0x0055 + 0x032D = 0x1E76 LATIN CAPITAL LETTER U WITH CIRCUMFLEX BELOW                             */
   { 0x55, 0x30, 0x1E74 }, /* 0x0055 + 0x0330 = 0x1E74 LATIN CAPITAL LETTER U WITH TILDE BELOW                                  */
   { 0x56, 0x03, 0x1E7C }, /* 0x0056 + 0x0303 = 0x1E7C LATIN CAPITAL LETTER V WITH TILDE                                        */
   { 0x56, 0x23, 0x1E7E }, /* 0x0056 + 0x0323 = 0x1E7E LATIN CAPITAL LETTER V WITH DOT BELOW                                    */
   { 0x57, 0x00, 0x1E80 }, /* 0x0057 + 0x0300 = 0x1E80 LATIN CAPITAL LETTER W WITH GRAVE                                        */
   { 0x57, 0x01, 0x1E82 }, /* 0x0057 + 0x0301 = 0x1E82 LATIN CAPITAL LETTER W WITH ACUTE                                        */
   { 0x57, 0x02, 0x0174 }, /* 0x0057 + 0x0302 = 0x0174 LATIN CAPITAL LETTER W WITH CIRCUMFLEX                                   */
   { 0x57, 0x07, 0x1E86 }, /* 0x0057 + 0x0307 = 0x1E86 LATIN CAPITAL LETTER W WITH DOT ABOVE                                    */
   { 0x57, 0x08, 0x1E84 }, /* 0x0057 + 0x0308 = 0x1E84 LATIN CAPITAL LETTER W WITH DIAERESIS                                    */
   { 0x57, 0x23, 0x1E88 }, /* 0x0057 + 0x0323 = 0x1E88 LATIN CAPITAL LETTER W WITH DOT BELOW                                    */
   { 0x58, 0x07, 0x1E8A }, /* 0x0058 + 0x0307 = 0x1E8A LATIN CAPITAL LETTER X WITH DOT ABOVE                                    */
   { 0x58, 0x08, 0x1E8C }, /* 0x0058 + 0x0308 = 0x1E8C LATIN CAPITAL LETTER X WITH DIAERESIS                                    */
   { 0x59, 0x00, 0x1EF2 }, /* 0x0059 + 0x0300 = 0x1EF2 LATIN CAPITAL LETTER Y WITH GRAVE                                        */
   { 0x59, 0x01, 0x00DD }, /* 0x0059 + 0x0301 = 0x00DD LATIN CAPITAL LETTER Y WITH ACUTE                                        */
   { 0x59, 0x02, 0x0176 }, /* 0x0059 + 0x0302 = 0x0176 LATIN CAPITAL LETTER Y WITH CIRCUMFLEX                                   */
   { 0x59, 0x03, 0x1EF8 }, /* 0x0059 + 0x0303 = 0x1EF8 LATIN CAPITAL LETTER Y WITH TILDE                                        */
   { 0x59, 0x04, 0x0232 }, /* 0x0059 + 0x0304 = 0x0232 LATIN CAPITAL LETTER Y WITH MACRON                                       */
   { 0x59, 0x07, 0x1E8E }, /* 0x0059 + 0x0307 = 0x1E8E LATIN CAPITAL LETTER Y WITH DOT ABOVE                                    */
   { 0x59, 0x08, 0x0178 }, /* 0x0059 + 0x0308 = 0x0178 LATIN CAPITAL LETTER Y WITH DIAERESIS                                    */
   { 0x59, 0x09, 0x1EF6 }, /* 0x0059 + 0x0309 = 0x1EF6 LATIN CAPITAL LETTER Y WITH HOOK ABOVE                                   */
   { 0x59, 0x23, 0x1EF4 }, /* 0x0059 + 0x0323 = 0x1EF4 LATIN CAPITAL LETTER Y WITH DOT BELOW                                    */
   { 0x5A, 0x01, 0x0179 }, /* 0x005A + 0x0301 = 0x0179 LATIN CAPITAL LETTER Z WITH ACUTE                                        */
   { 0x5A, 0x02, 0x1E90 }, /* 0x005A + 0x0302 = 0x1E90 LATIN CAPITAL LETTER Z WITH CIRCUMFLEX                                   */
   { 0x5A, 0x07, 0x017B }, /* 0x005A + 0x0307 = 0x017B LATIN CAPITAL LETTER Z WITH DOT ABOVE                                    */
   { 0x5A, 0x0C, 0x017D }, /* 0x005A + 0x030C = 0x017D LATIN CAPITAL LETTER Z WITH CARON                                        */
   { 0x5A, 0x23, 0x1E92 }, /* 0x005A + 0x0323 = 0x1E92 LATIN CAPITAL LETTER Z WITH DOT BELOW                                    */
   { 0x5A, 0x31, 0x1E94 }, /* 0x005A + 0x0331 = 0x1E94 LATIN CAPITAL LETTER Z WITH LINE BELOW                                   */
   { 0x61, 0x00, 0x00E0 }, /* 0x0061 + 0x0300 = 0x00E0 LATIN SMALL LETTER A WITH GRAVE                                          */
   { 0x61, 0x01, 0x00E1 }, /* 0x0061 + 0x0301 = 0x00E1 LATIN SMALL LETTER A WITH ACUTE                                          */
   { 0x61, 0x02, 0x00E2 }, /* 0x0061 + 0x0302 = 0x00E2 LATIN SMALL LETTER A WITH CIRCUMFLEX                                     */
   { 0x61, 0x03, 0x00E3 }, /* 0x0061 + 0x0303 = 0x00E3 LATIN SMALL LETTER A WITH TILDE                                          */
   { 0x61, 0x04, 0x0101 }, /* 0x0061 + 0x0304 = 0x0101 LATIN SMALL LETTER A WITH MACRON                                         */
   { 0x61, 0x06, 0x0103 }, /* 0x0061 + 0x0306 = 0x0103 LATIN SMALL LETTER A WITH BREVE                                          */
   { 0x61, 0x07, 0x0227 }, /* 0x0061 + 0x0307 = 0x0227 LATIN SMALL LETTER A WITH DOT ABOVE                                      */
   { 0x61, 0x08, 0x00E4 }, /* 0x0061 + 0x0308 = 0x00E4 LATIN SMALL LETTER A WITH DIAERESIS                                      */
   { 0x61, 0x09, 0x1EA3 }, /* 0x0061 + 0x0309 = 0x1EA3 LATIN SMALL LETTER A WITH HOOK ABOVE                                     */
   { 0x61, 0x0A, 0x00E5 }, /* 0x0061 + 0x030A = 0x00E5 LATIN SMALL LETTER A WITH RING ABOVE                                     */
   { 0x61, 0x0C, 0x01CE }, /* 0x0061 + 0x030C = 0x01CE LATIN SMALL LETTER A WITH CARON                                          */
   { 0x61, 0x0F, 0x0201 }, /* 0x0061 + 0x030F = 0x0201 LATIN SMALL LETTER A WITH DOUBLE GRAVE                                   */
   { 0x61, 0x11, 0x0203 }, /* 0x0061 + 0x0311 = 0x0203 LATIN SMALL LETTER A WITH INVERTED BREVE                                 */
   { 0x61, 0x23, 0x1EA1 }, /* 0x0061 + 0x0323 = 0x1EA1 LATIN SMALL LETTER A WITH DOT BELOW                                      */
   { 0x61, 0x25, 0x1E01 }, /* 0x0061 + 0x0325 = 0x1E01 LATIN SMALL LETTER A WITH RING BELOW                                     */
   { 0x61, 0x28, 0x0105 }, /* 0x0061 + 0x0328 = 0x0105 LATIN SMALL LETTER A WITH OGONEK                                         */
   { 0x62, 0x07, 0x1E03 }, /* 0x0062 + 0x0307 = 0x1E03 LATIN SMALL LETTER B WITH DOT ABOVE                                      */
   { 0x62, 0x23, 0x1E05 }, /* 0x0062 + 0x0323 = 0x1E05 LATIN SMALL LETTER B WITH DOT BELOW                                      */
   { 0x62, 0x31, 0x1E07 }, /* 0x0062 + 0x0331 = 0x1E07 LATIN SMALL LETTER B WITH LINE BELOW                                     */
   { 0x63, 0x01, 0x0107 }, /* 0x0063 + 0x0301 = 0x0107 LATIN SMALL LETTER C WITH ACUTE                                          */
   { 0x63, 0x02, 0x0109 }, /* 0x0063 + 0x0302 = 0x0109 LATIN SMALL LETTER C WITH CIRCUMFLEX                                     */
   { 0x63, 0x07, 0x010B }, /* 0x0063 + 0x0307 = 0x010B LATIN SMALL LETTER C WITH DOT ABOVE                                      */
   { 0x63, 0x0C, 0x010D }, /* 0x0063 + 0x030C = 0x010D LATIN SMALL LETTER C WITH CARON                                          */
   { 0x63, 0x27, 0x00E7 }, /* 0x0063 + 0x0327 = 0x00E7 LATIN SMALL LETTER C WITH CEDILLA                                        */
   { 0x64, 0x07, 0x1E0B }, /* 0x0064 + 0x0307 = 0x1E0B LATIN SMALL LETTER D WITH DOT ABOVE                                      */
   { 0x64, 0x0C, 0x010F }, /* 0x0064 + 0x030C = 0x010F LATIN SMALL LETTER D WITH CARON                                          */
   { 0x64, 0x23, 0x1E0D }, /* 0x0064 + 0x0323 = 0x1E0D LATIN SMALL LETTER D WITH DOT BELOW                                      */
   { 0x64, 0x27, 0x1E11 }, /* 0x0064 + 0x0327 = 0x1E11 LATIN SMALL LETTER D WITH CEDILLA                                        */
   { 0x64, 0x2D, 0x1E13 }, /* 0x0064 + 0x032D = 0x1E13 LATIN SMALL LETTER D WITH CIRCUMFLEX BELOW                               */
   { 0x64, 0x31, 0x1E0F }, /* 0x0064 + 0x0331 = 0x1E0F LATIN SMALL LETTER D WITH LINE BELOW                                     */
   { 0x65, 0x00, 0x00E8 }, /* 0x0065 + 0x0300 = 0x00E8 LATIN SMALL LETTER E WITH GRAVE                                          */
   { 0x65, 0x01, 0x00E9 }, /* 0x0065 + 0x0301 = 0x00E9 LATIN SMALL LETTER E WITH ACUTE                                          */
   { 0x65, 0x02, 0x00EA }, /* 0x0065 + 0x0302 = 0x00EA LATIN SMALL LETTER E WITH CIRCUMFLEX                                     */
   { 0x65, 0x03, 0x1EBD }, /* 0x0065 + 0x0303 = 0x1EBD LATIN SMALL LETTER E WITH TILDE                                          */
   { 0x65, 0x04, 0x0113 }, /* 0x0065 + 0x0304 = 0x0113 LATIN SMALL LETTER E WITH MACRON                                         */
   { 0x65, 0x06, 0x0115 }, /* 0x0065 + 0x0306 = 0x0115 LATIN SMALL LETTER E WITH BREVE                                          */
   { 0x65, 0x07, 0x0117 }, /* 0x0065 + 0x0307 = 0x0117 LATIN SMALL LETTER E WITH DOT ABOVE                                      */
   { 0x65, 0x08, 0x00EB }, /* 0x0065 + 0x0308 = 0x00EB LATIN SMALL LETTER E WITH DIAERESIS                                      */
   { 0x65, 0x09, 0x1EBB }, /* 0x0065 + 0x0309 = 0x1EBB LATIN SMALL LETTER E WITH HOOK ABOVE                                     */
   { 0x65, 0x0C, 0x011B }, /* 0x0065 + 0x030C = 0x011B LATIN SMALL LETTER E WITH CARON                                          */
   { 0x65, 0x0F, 0x0205 }, /* 0x0065 + 0x030F = 0x0205 LATIN SMALL LETTER E WITH DOUBLE GRAVE                                   */
   { 0x65, 0x11, 0x0207 }, /* 0x0065 + 0x0311 = 0x0207 LATIN SMALL LETTER E WITH INVERTED BREVE                                 */
   { 0x65, 0x23, 0x1EB9 }, /* 0x0065 + 0x0323 = 0x1EB9 LATIN SMALL LETTER E WITH DOT BELOW                                      */
   { 0x65, 0x27, 0x0229 }, /* 0x0065 + 0x0327 = 0x0229 LATIN SMALL LETTER E WITH CEDILLA                                        */
   { 0x65, 0x28, 0x0119 }, /* 0x0065 + 0x0328 = 0x0119 LATIN SMALL LETTER E WITH OGONEK                                         */
   { 0x65, 0x2D, 0x1E19 }, /* 0x0065 + 0x032D = 0x1E19 LATIN SMALL LETTER E WITH CIRCUMFLEX BELOW                               */
   { 0x65, 0x30, 0x1E1B }, /* 0x0065 + 0x0330 = 0x1E1B LATIN SMALL LETTER E WITH TILDE BELOW                                    */
   { 0x66, 0x07, 0x1E1F }, /* 0x0066 + 0x0307 = 0x1E1F LATIN SMALL LETTER F WITH DOT ABOVE                                      */
   { 0x67, 0x01, 0x01F5 }, /* 0x0067 + 0x0301 = 0x01F5 LATIN SMALL LETTER G WITH ACUTE                                          */
   { 0x67, 0x02, 0x011D }, /* 0x0067 + 0x0302 = 0x011D LATIN SMALL LETTER G WITH CIRCUMFLEX                                     */
   { 0x67, 0x04, 0x1E21 }, /* 0x0067 + 0x0304 = 0x1E21 LATIN SMALL LETTER G WITH MACRON                                         */
   { 0x67, 0x06, 0x011F }, /* 0x0067 + 0x0306 = 0x011F LATIN SMALL LETTER G WITH BREVE                                          */
   { 0x67, 0x07, 0x0121 }, /* 0x0067 + 0x0307 = 0x0121 LATIN SMALL LETTER G WITH DOT ABOVE                                      */
   { 0x67, 0x0C, 0x01E7 }, /* 0x0067 + 0x030C = 0x01E7 LATIN SMALL LETTER G WITH CARON                                          */
   { 0x67, 0x27, 0x0123 }, /* 0x0067 + 0x0327 = 0x0123 LATIN SMALL LETTER G WITH CEDILLA                                        */
   { 0x68, 0x02, 0x0125 }, /* 0x0068 + 0x0302 = 0x0125 LATIN SMALL LETTER H WITH CIRCUMFLEX                                     */
   { 0x68, 0x07, 0x1E23 }, /* 0x0068 + 0x0307 = 0x1E23 LATIN SMALL LETTER H WITH DOT ABOVE                                      */
   { 0x68, 0x08, 0x1E27 }, /* 0x0068 + 0x0308 = 0x1E27 LATIN SMALL LETTER H WITH DIAERESIS                                      */
   { 0x68, 0x0C, 0x021F }, /* 0x0068 + 0x030C = 0x021F LATIN SMALL LETTER H WITH CARON                                          */
   { 0x68, 0x23, 0x1E25 }, /* 0x0068 + 0x0323 = 0x1E25 LATIN SMALL LETTER H WITH DOT BELOW                                      */
   { 0x68, 0x27, 0x1E29 }, /* 0x0068 + 0x0327 = 0x1E29 LATIN SMALL LETTER H WITH CEDILLA                                        */
   { 0x68, 0x2E, 0x1E2B }, /* 0x0068 + 0x032E = 0x1E2B LATIN SMALL LETTER H WITH BREVE BELOW                                    */
   { 0x68, 0x31, 0x1E96 }, /* 0x0068 + 0x0331 = 0x1E96 LATIN SMALL LETTER H WITH LINE BELOW                                     */
   { 0x69, 0x00, 0x00EC }, /* 0x0069 + 0x0300 = 0x00EC LATIN SMALL LETTER I WITH GRAVE                                          */
   { 0x69, 0x01, 0x00ED }, /* 0x0069 + 0x0301 = 0x00ED LATIN SMALL LETTER I WITH ACUTE                                          */
   { 0x69, 0x02, 0x00EE }, /* 0x0069 + 0x0302 = 0x00EE LATIN SMALL LETTER I WITH CIRCUMFLEX                                     */
   { 0x69, 0x03, 0x0129 }, /* 0x0069 + 0x0303 = 0x0129 LATIN SMALL LETTER I WITH TILDE                                          */
   { 0x69, 0x04, 0x012B }, /* 0x0069 + 0x0304 = 0x012B LATIN SMALL LETTER I WITH MACRON                                         */
   { 0x69, 0x06, 0x012D }, /* 0x0069 + 0x0306 = 0x012D LATIN SMALL LETTER I WITH BREVE                                          */
   { 0x69, 0x08, 0x00EF }, /* 0x0069 + 0x0308 = 0x00EF LATIN SMALL LETTER I WITH DIAERESIS                                      */
   { 0x69, 0x09, 0x1EC9 }, /* 0x0069 + 0x0309 = 0x1EC9 LATIN SMALL LETTER I WITH HOOK ABOVE                                     */
   { 0x69, 0x0C, 0x01D0 }, /* 0x0069 + 0x030C = 0x01D0 LATIN SMALL LETTER I WITH CARON                                          */
   { 0x69, 0x0F, 0x0209 }, /* 0x0069 + 0x030F = 0x0209 LATIN SMALL LETTER I WITH DOUBLE GRAVE                                   */
   { 0x69, 0x11, 0x020B }, /* 0x0069 + 0x0311 = 0x020B LATIN SMALL LETTER I WITH INVERTED BREVE                                 */
   { 0x69, 0x23, 0x1ECB }, /* 0x0069 + 0x0323 = 0x1ECB LATIN SMALL LETTER I WITH DOT BELOW                                      */
   { 0x69, 0x28, 0x012F }, /* 0x0069 + 0x0328 = 0x012F LATIN SMALL LETTER I WITH OGONEK                                         */
   { 0x69, 0x30, 0x1E2D }, /* 0x0069 + 0x0330 = 0x1E2D LATIN SMALL LETTER I WITH TILDE BELOW                                    */
   { 0x6A, 0x02, 0x0135 }, /* 0x006A + 0x0302 = 0x0135 LATIN SMALL LETTER J WITH CIRCUMFLEX                                     */
   { 0x6A, 0x0C, 0x01F0 }, /* 0x006A + 0x030C = 0x01F0 LATIN SMALL LETTER J WITH CARON                                          */
   { 0x6B, 0x01, 0x1E31 }, /* 0x006B + 0x0301 = 0x1E31 LATIN SMALL LETTER K WITH ACUTE                                          */
   { 0x6B, 0x0C, 0x01E9 }, /* 0x006B + 0x030C = 0x01E9 LATIN SMALL LETTER K WITH CARON                                          */
   { 0x6B, 0x23, 0x1E33 }, /* 0x006B + 0x0323 = 0x1E33 LATIN SMALL LETTER K WITH DOT BELOW                                      */
   { 0x6B, 0x27, 0x0137 }, /* 0x006B + 0x0327 = 0x0137 LATIN SMALL LETTER K WITH CEDILLA                                        */
   { 0x6B, 0x31, 0x1E35 }, /* 0x006B + 0x0331 = 0x1E35 LATIN SMALL LETTER K WITH LINE BELOW                                     */
   { 0x6C, 0x01, 0x013A }, /* 0x006C + 0x0301 = 0x013A LATIN SMALL LETTER L WITH ACUTE                                          */
   { 0x6C, 0x0C, 0x013E }, /* 0x006C + 0x030C = 0x013E LATIN SMALL LETTER L WITH CARON                                          */
   { 0x6C, 0x23, 0x1E37 }, /* 0x006C + 0x0323 = 0x1E37 LATIN SMALL LETTER L WITH DOT BELOW                                      */
   { 0x6C, 0x27, 0x013C }, /* 0x006C + 0x0327 = 0x013C LATIN SMALL LETTER L WITH CEDILLA                                        */
   { 0x6C, 0x2D, 0x1E3D }, /* 0x006C + 0x032D = 0x1E3D LATIN SMALL LETTER L WITH CIRCUMFLEX BELOW                               */
   { 0x6C, 0x31, 0x1E3B }, /* 0x006C + 0x0331 = 0x1E3B LATIN SMALL LETTER L WITH LINE BELOW                                     */
   { 0x6D, 0x01, 0x1E3F }, /* 0x006D + 0x0301 = 0x1E3F LATIN SMALL LETTER M WITH ACUTE                                          */
   { 0x6D, 0x07, 0x1E41 }, /* 0x006D + 0x0307 = 0x1E41 LATIN SMALL LETTER M WITH DOT ABOVE                                      */
   { 0x6D, 0x23, 0x1E43 }, /* 0x006D + 0x0323 = 0x1E43 LATIN SMALL LETTER M WITH DOT BELOW                                      */
   { 0x6E, 0x00, 0x01F9 }, /* 0x006E + 0x0300 = 0x01F9 LATIN SMALL LETTER N WITH GRAVE                                          */
   { 0x6E, 0x01, 0x0144 }, /* 0x006E + 0x0301 = 0x0144 LATIN SMALL LETTER N WITH ACUTE                                          */
   { 0x6E, 0x03, 0x00F1 }, /* 0x006E + 0x0303 = 0x00F1 LATIN SMALL LETTER N WITH TILDE                                          */
   { 0x6E, 0x07, 0x1E45 }, /* 0x006E + 0x0307 = 0x1E45 LATIN SMALL LETTER N WITH DOT ABOVE                                      */
   { 0x6E, 0x0C, 0x0148 }, /* 0x006E + 0x030C = 0x0148 LATIN SMALL LETTER N WITH CARON                                          */
   { 0x6E, 0x23, 0x1E47 }, /* 0x006E + 0x0323 = 0x1E47 LATIN SMALL LETTER N WITH DOT BELOW                                      */
   { 0x6E, 0x27, 0x0146 }, /* 0x006E + 0x0327 = 0x0146 LATIN SMALL LETTER N WITH CEDILLA                                        */
   { 0x6E, 0x2D, 0x1E4B }, /* 0x006E + 0x032D = 0x1E4B LATIN SMALL LETTER N WITH CIRCUMFLEX BELOW                               */
   { 0x6E, 0x31, 0x1E49 }, /* 0x006E + 0x0331 = 0x1E49 LATIN SMALL LETTER N WITH LINE BELOW                                     */
   { 0x6F, 0x00, 0x00F2 }, /* 0x006F + 0x0300 = 0x00F2 LATIN SMALL LETTER O WITH GRAVE                                          */
   { 0x6F, 0x01, 0x00F3 }, /* 0x006F + 0x0301 = 0x00F3 LATIN SMALL LETTER O WITH ACUTE                                          */
   { 0x6F, 0x02, 0x00F4 }, /* 0x006F + 0x0302 = 0x00F4 LATIN SMALL LETTER O WITH CIRCUMFLEX                                     */
   { 0x6F, 0x03, 0x00F5 }, /* 0x006F + 0x0303 = 0x00F5 LATIN SMALL LETTER O WITH TILDE                                          */
   { 0x6F, 0x04, 0x014D }, /* 0x006F + 0x0304 = 0x014D LATIN SMALL LETTER O WITH MACRON                                         */
   { 0x6F, 0x06, 0x014F }, /* 0x006F + 0x0306 = 0x014F LATIN SMALL LETTER O WITH BREVE                                          */
   { 0x6F, 0x07, 0x022F }, /* 0x006F + 0x0307 = 0x022F LATIN SMALL LETTER O WITH DOT ABOVE                                      */
   { 0x6F, 0x08, 0x00F6 }, /* 0x006F + 0x0308 = 0x00F6 LATIN SMALL LETTER O WITH DIAERESIS                                      */
   { 0x6F, 0x09, 0x1ECF }, /* 0x006F + 0x0309 = 0x1ECF LATIN SMALL LETTER O WITH HOOK ABOVE                                     */
   { 0x6F, 0x0B, 0x0151 }, /* 0x006F + 0x030B = 0x0151 LATIN SMALL LETTER O WITH DOUBLE ACUTE                                   */
   { 0x6F, 0x0C, 0x01D2 }, /* 0x006F + 0x030C = 0x01D2 LATIN SMALL LETTER O WITH CARON                                          */
   { 0x6F, 0x0F, 0x020D }, /* 0x006F + 0x030F = 0x020D LATIN SMALL LETTER O WITH DOUBLE GRAVE                                   */
   { 0x6F, 0x11, 0x020F }, /* 0x006F + 0x0311 = 0x020F LATIN SMALL LETTER O WITH INVERTED BREVE                                 */
   { 0x6F, 0x1B, 0x01A1 }, /* 0x006F + 0x031B = 0x01A1 LATIN SMALL LETTER O WITH HORN                                           */
   { 0x6F, 0x23, 0x1ECD }, /* 0x006F + 0x0323 = 0x1ECD LATIN SMALL LETTER O WITH DOT BELOW                                      */
   { 0x6F, 0x28, 0x01EB }, /* 0x006F + 0x0328 = 0x01EB LATIN SMALL LETTER O WITH OGONEK                                         */
   { 0x70, 0x01, 0x1E55 }, /* 0x0070 + 0x0301 = 0x1E55 LATIN SMALL LETTER P WITH ACUTE                                          */
   { 0x70, 0x07, 0x1E57 }, /* 0x0070 + 0x0307 = 0x1E57 LATIN SMALL LETTER P WITH DOT ABOVE                                      */
   { 0x72, 0x01, 0x0155 }, /* 0x0072 + 0x0301 = 0x0155 LATIN SMALL LETTER R WITH ACUTE                                          */
   { 0x72, 0x07, 0x1E59 }, /* 0x0072 + 0x0307 = 0x1E59 LATIN SMALL LETTER R WITH DOT ABOVE                                      */
   { 0x72, 0x0C, 0x0159 }, /* 0x0072 + 0x030C = 0x0159 LATIN SMALL LETTER R WITH CARON                                          */
   { 0x72, 0x0F, 0x0211 }, /* 0x0072 + 0x030F = 0x0211 LATIN SMALL LETTER R WITH DOUBLE GRAVE                                   */
   { 0x72, 0x11, 0x0213 }, /* 0x0072 + 0x0311 = 0x0213 LATIN SMALL LETTER R WITH INVERTED BREVE                                 */
   { 0x72, 0x23, 0x1E5B }, /* 0x0072 + 0x0323 = 0x1E5B LATIN SMALL LETTER R WITH DOT BELOW                                      */
   { 0x72, 0x27, 0x0157 }, /* 0x0072 + 0x0327 = 0x0157 LATIN SMALL LETTER R WITH CEDILLA                                        */
   { 0x72, 0x31, 0x1E5F }, /* 0x0072 + 0x0331 = 0x1E5F LATIN SMALL LETTER R WITH LINE BELOW                                     */
   { 0x73, 0x01, 0x015B }, /* 0x0073 + 0x0301 = 0x015B LATIN SMALL LETTER S WITH ACUTE                                          */
   { 0x73, 0x02, 0x015D }, /* 0x0073 + 0x0302 = 0x015D LATIN SMALL LETTER S WITH CIRCUMFLEX                                     */
   { 0x73, 0x07, 0x1E61 }, /* 0x0073 + 0x0307 = 0x1E61 LATIN SMALL LETTER S WITH DOT ABOVE                                      */
   { 0x73, 0x0C, 0x0161 }, /* 0x0073 + 0x030C = 0x0161 LATIN SMALL LETTER S WITH CARON                                          */
   { 0x73, 0x23, 0x1E63 }, /* 0x0073 + 0x0323 = 0x1E63 LATIN SMALL LETTER S WITH DOT BELOW                                      */
   { 0x73, 0x26, 0x0219 }, /* 0x0073 + 0x0326 = 0x0219 LATIN SMALL LETTER S WITH COMMA BELOW                                    */
   { 0x73, 0x27, 0x015F }, /* 0x0073 + 0x0327 = 0x015F LATIN SMALL LETTER S WITH CEDILLA                                        */
   { 0x74, 0x07, 0x1E6B }, /* 0x0074 + 0x0307 = 0x1E6B LATIN SMALL LETTER T WITH DOT ABOVE                                      */
   { 0x74, 0x08, 0x1E97 }, /* 0x0074 + 0x0308 = 0x1E97 LATIN SMALL LETTER T WITH DIAERESIS                                      */
   { 0x74, 0x0C, 0x0165 }, /* 0x0074 + 0x030C = 0x0165 LATIN SMALL LETTER T WITH CARON                                          */
   { 0x74, 0x23, 0x1E6D }, /* 0x0074 + 0x0323 = 0x1E6D LATIN SMALL LETTER T WITH DOT BELOW                                      */
   { 0x74, 0x26, 0x021B }, /* 0x0074 + 0x0326 = 0x021B LATIN SMALL LETTER T WITH COMMA BELOW                                    */
   { 0x74, 0x27, 0x0163 }, /* 0x0074 + 0x0327 = 0x0163 LATIN SMALL LETTER T WITH CEDILLA                                        */
   { 0x74, 0x2D, 0x1E71 }, /* 0x0074 + 0x032D = 0x1E71 LATIN SMALL LETTER T WITH CIRCUMFLEX BELOW                               */
   { 0x74, 0x31, 0x1E6F }, /* 0x0074 + 0x0331 = 0x1E6F LATIN SMALL LETTER T WITH LINE BELOW                                     */
   { 0x75, 0x00, 0x00F9 }, /* 0x0075 + 0x0300 = 0x00F9 LATIN SMALL LETTER U WITH GRAVE                                          */
   { 0x75, 0x01, 0x00FA }, /* 0x0075 + 0x0301 = 0x00FA LATIN SMALL LETTER U WITH ACUTE                                          */
   { 0x75, 0x02, 0x00FB }, /* 0x0075 + 0x0302 = 0x00FB LATIN SMALL LETTER U WITH CIRCUMFLEX                                     */
   { 0x75, 0x03, 0x0169 }, /* 0x0075 + 0x0303 = 0x0169 LATIN SMALL LETTER U WITH TILDE                                          */
   { 0x75, 0x04, 0x016B }, /* 0x0075 + 0x0304 = 0x016B LATIN SMALL LETTER U WITH MACRON                                         */
   { 0x75, 0x06, 0x016D }, /* 0x0075 + 0x0306 = 0x016D LATIN SMALL LETTER U WITH BREVE                                          */
   { 0x75, 0x08, 0x00FC }, /* 0x0075 + 0x0308 = 0x00FC LATIN SMALL LETTER U WITH DIAERESIS                                      */
   { 0x75, 0x09, 0x1EE7 }, /* 0x0075 + 0x0309 = 0x1EE7 LATIN SMALL LETTER U WITH HOOK ABOVE                                     */
   { 0x75, 0x0A, 0x016F }, /* 0x0075 + 0x030A = 0x016F LATIN SMALL LETTER U WITH RING ABOVE                                     */
   { 0x75, 0x0B, 0x0171 }, /* 0x0075 + 0x030B = 0x0171 LATIN SMALL LETTER U WITH DOUBLE ACUTE                                   */
   { 0x75, 0x0C, 0x01D4 }, /* 0x0075 + 0x030C = 0x01D4 LATIN SMALL LETTER U WITH CARON                                          */
   { 0x75, 0x0F, 0x0215 }, /* 0x0075 + 0x030F = 0x0215 LATIN SMALL LETTER U WITH DOUBLE GRAVE                                   */
   { 0x75, 0x11, 0x0217 }, /* 0x0075 + 0x0311 = 0x0217 LATIN SMALL LETTER U WITH INVERTED BREVE                                 */
   { 0x75, 0x1B, 0x01B0 }, /* 0x0075 + 0x031B = 0x01B0 LATIN SMALL LETTER U WITH HORN                                           */
   { 0x75, 0x23, 0x1EE5 }, /* 0x0075 + 0x0323 = 0x1EE5 LATIN SMALL LETTER U WITH DOT BELOW                                      */
   { 0x75, 0x24, 0x1E73 }, /* 0x0075 + 0x0324 = 0x1E73 LATIN SMALL LETTER U WITH DIAERESIS BELOW                                */
   { 0x75, 0x28, 0x0173 }, /* 0x0075 + 0x0328 = 0x0173 LATIN SMALL LETTER U WITH OGONEK                                         */
   { 0x75, 0x2D, 0x1E77 }, /* 0x0075 + 0x032D = 0x1E77 LATIN SMALL LETTER U WITH CIRCUMFLEX BELOW                               */
   { 0x75, 0x30, 0x1E75 }, /* 0x0075 + 0x0330 = 0x1E75 LATIN SMALL LETTER U WITH TILDE BELOW                                    */
   { 0x76, 0x03, 0x1E7D }, /* 0x0076 + 0x0303 = 0x1E7D LATIN SMALL LETTER V WITH TILDE                                          */
   { 0x76, 0x23, 0x1E7F }, /* 0x0076 + 0x0323 = 0x1E7F LATIN SMALL LETTER V WITH DOT BELOW                                      */
   { 0x77, 0x00, 0x1E81 }, /* 0x0077 + 0x0300 = 0x1E81 LATIN SMALL LETTER W WITH GRAVE                                          */
   { 0x77, 0x01, 0x1E83 }, /* 0x0077 + 0x0301 = 0x1E83 LATIN SMALL LETTER W WITH ACUTE                                          */
   { 0x77, 0x02, 0x0175 }, /* 0x0077 + 0x0302 = 0x0175 LATIN SMALL LETTER W WITH CIRCUMFLEX                                     */
   { 0x77, 0x07, 0x1E87 }, /* 0x0077 + 0x0307 = 0x1E87 LATIN SMALL LETTER W WITH DOT ABOVE                                      */
   { 0x77, 0x08, 0x1E85 }, /* 0x0077 + 0x0308 = 0x1E85 LATIN SMALL LETTER W WITH DIAERESIS                                      */
   { 0x77, 0x0A, 0x1E98 }, /* 0x0077 + 0x030A = 0x1E98 LATIN SMALL LETTER W WITH RING ABOVE                                     */
   { 0x77, 0x23, 0x1E89 }, /* 0x0077 + 0x0323 = 0x1E89 LATIN SMALL LETTER W WITH DOT BELOW                                      */
   { 0x78, 0x07, 0x1E8B }, /* 0x0078 + 0x0307 = 0x1E8B LATIN SMALL LETTER X WITH DOT ABOVE                                      */
   { 0x78, 0x08, 0x1E8D }, /* 0x0078 + 0x0308 = 0x1E8D LATIN SMALL LETTER X WITH DIAERESIS                                      */
   { 0x79, 0x00, 0x1EF3 }, /* 0x0079 + 0x0300 = 0x1EF3 LATIN SMALL LETTER Y WITH GRAVE                                          */
   { 0x79, 0x01, 0x00FD }, /* 0x0079 + 0x0301 = 0x00FD LATIN SMALL LETTER Y WITH ACUTE                                          */
   { 0x79, 0x02, 0x0177 }, /* 0x0079 + 0x0302 = 0x0177 LATIN SMALL LETTER Y WITH CIRCUMFLEX                                     */
   { 0x79, 0x03, 0x1EF9 }, /* 0x0079 + 0x0303 = 0x1EF9 LATIN SMALL LETTER Y WITH TILDE                                          */
   { 0x79, 0x04, 0x0233 }, /* 0x0079 + 0x0304 = 0x0233 LATIN SMALL LETTER Y WITH MACRON                                         */
   { 0x79, 0x07, 0x1E8F }, /* 0x0079 + 0x0307 = 0x1E8F LATIN SMALL LETTER Y WITH DOT ABOVE                                      */
   { 0x79, 0x08, 0x00FF }, /* 0x0079 + 0x0308 = 0x00FF LATIN SMALL LETTER Y WITH DIAERESIS                                      */
   { 0x79, 0x09, 0x1EF7 }, /* 0x0079 + 0x0309 = 0x1EF7 LATIN SMALL LETTER Y WITH HOOK ABOVE                                     */
   { 0x79, 0x0A, 0x1E99 }, /* 0x0079 + 0x030A = 0x1E99 LATIN SMALL LETTER Y WITH RING ABOVE                                     */
   { 0x79, 0x23, 0x1EF5 }, /* 0x0079 + 0x0323 = 0x1EF5 LATIN SMALL LETTER Y WITH DOT BELOW                                      */
   { 0x7A, 0x01, 0x017A }, /* 0x007A + 0x0301 = 0x017A LATIN SMALL LETTER Z WITH ACUTE                                          */
   { 0x7A, 0x02, 0x1E91 }, /* 0x007A + 0x0302 = 0x1E91 LATIN SMALL LETTER Z WITH CIRCUMFLEX                                     */
   { 0x7A, 0x07, 0x017C }, /* 0x007A + 0x0307 = 0x017C LATIN SMALL LETTER Z WITH DOT ABOVE                                      */
   { 0x7A, 0x0C, 0x017E }, /* 0x007A + 0x030C = 0x017E LATIN SMALL LETTER Z WITH CARON                                          */
   { 0x7A, 0x23, 0x1E93 }, /* 0x007A + 0x0323 = 0x1E93 LATIN SMALL LETTER Z WITH DOT BELOW                                      */
   { 0x7A, 0x31, 0x1E95 }, /* 0x007A + 0x0331 = 0x1E95 LATIN SMALL LETTER Z WITH LINE BELOW                                     */
   { 0xA8, 0x00, 0x1FED }, /* 0x00A8 + 0x0300 = 0x1FED GREEK DIALYTIKA AND VARIA                                                */
   { 0xA8, 0x01, 0x0385 }, /* 0x00A8 + 0x0301 = 0x0385 GREEK DIALYTIKA TONOS                                                    */
   { 0xA8, 0x42, 0x1FC1 }, /* 0x00A8 + 0x0342 = 0x1FC1 GREEK DIALYTIKA AND PERISPOMENI                                          */
   { 0xC2, 0x00, 0x1EA6 }, /* 0x00C2 + 0x0300 = 0x1EA6 LATIN CAPITAL LETTER A WITH CIRCUMFLEX AND GRAVE                         */
   { 0xC2, 0x01, 0x1EA4 }, /* 0x00C2 + 0x0301 = 0x1EA4 LATIN CAPITAL LETTER A WITH CIRCUMFLEX AND ACUTE                         */
   { 0xC2, 0x03, 0x1EAA }, /* 0x00C2 + 0x0303 = 0x1EAA LATIN CAPITAL LETTER A WITH CIRCUMFLEX AND TILDE                         */
   { 0xC2, 0x09, 0x1EA8 }, /* 0x00C2 + 0x0309 = 0x1EA8 LATIN CAPITAL LETTER A WITH CIRCUMFLEX AND HOOK ABOVE                    */
   { 0xC4, 0x04, 0x01DE }, /* 0x00C4 + 0x0304 = 0x01DE LATIN CAPITAL LETTER A WITH DIAERESIS AND MACRON                         */
   { 0xC5, 0x01, 0x01FA }, /* 0x00C5 + 0x0301 = 0x01FA LATIN CAPITAL LETTER A WITH RING ABOVE AND ACUTE                         */
   { 0xC6, 0x01, 0x01FC }, /* 0x00C6 + 0x0301 = 0x01FC LATIN CAPITAL LETTER AE WITH ACUTE                                       */
   { 0xC6, 0x04, 0x01E2 }, /* 0x00C6 + 0x0304 = 0x01E2 LATIN CAPITAL LETTER AE WITH MACRON                                      */
   { 0xC7, 0x01, 0x1E08 }, /* 0x00C7 + 0x0301 = 0x1E08 LATIN CAPITAL LETTER C WITH CEDILLA AND ACUTE                            */
   { 0xCA, 0x00, 0x1EC0 }, /* 0x00CA + 0x0300 = 0x1EC0 LATIN CAPITAL LETTER E WITH CIRCUMFLEX AND GRAVE                         */
   { 0xCA, 0x01, 0x1EBE }, /* 0x00CA + 0x0301 = 0x1EBE LATIN CAPITAL LETTER E WITH CIRCUMFLEX AND ACUTE                         */
   { 0xCA, 0x03, 0x1EC4 }, /* 0x00CA + 0x0303 = 0x1EC4 LATIN CAPITAL LETTER E WITH CIRCUMFLEX AND TILDE                         */
   { 0xCA, 0x09, 0x1EC2 }, /* 0x00CA + 0x0309 = 0x1EC2 LATIN CAPITAL LETTER E WITH CIRCUMFLEX AND HOOK ABOVE                    */
   { 0xCF, 0x01, 0x1E2E }, /* 0x00CF + 0x0301 = 0x1E2E LATIN CAPITAL LETTER I WITH DIAERESIS AND ACUTE                          */
   { 0xD4, 0x00, 0x1ED2 }, /* 0x00D4 + 0x0300 = 0x1ED2 LATIN CAPITAL LETTER O WITH CIRCUMFLEX AND GRAVE                         */
   { 0xD4, 0x01, 0x1ED0 }, /* 0x00D4 + 0x0301 = 0x1ED0 LATIN CAPITAL LETTER O WITH CIRCUMFLEX AND ACUTE                         */
   { 0xD4, 0x03, 0x1ED6 }, /* 0x00D4 + 0x0303 = 0x1ED6 LATIN CAPITAL LETTER O WITH CIRCUMFLEX AND TILDE                         */
   { 0xD4, 0x09, 0x1ED4 }, /* 0x00D4 + 0x0309 = 0x1ED4 LATIN CAPITAL LETTER O WITH CIRCUMFLEX AND HOOK ABOVE                    */
   { 0xD5, 0x01, 0x1E4C }, /* 0x00D5 + 0x0301 = 0x1E4C LATIN CAPITAL LETTER O WITH TILDE AND ACUTE                              */
   { 0xD5, 0x04, 0x022C }, /* 0x00D5 + 0x0304 = 0x022C LATIN CAPITAL LETTER O WITH TILDE AND MACRON                             */
   { 0xD5, 0x08, 0x1E4E }, /* 0x00D5 + 0x0308 = 0x1E4E LATIN CAPITAL LETTER O WITH TILDE AND DIAERESIS                          */
   { 0xD6, 0x04, 0x022A }, /* 0x00D6 + 0x0304 = 0x022A LATIN CAPITAL LETTER O WITH DIAERESIS AND MACRON                         */
   { 0xD8, 0x01, 0x01FE }, /* 0x00D8 + 0x0301 = 0x01FE LATIN CAPITAL LETTER O WITH STROKE AND ACUTE                             */
   { 0xDC, 0x00, 0x01DB }, /* 0x00DC + 0x0300 = 0x01DB LATIN CAPITAL LETTER U WITH DIAERESIS AND GRAVE                          */
   { 0xDC, 0x01, 0x01D7 }, /* 0x00DC + 0x0301 = 0x01D7 LATIN CAPITAL LETTER U WITH DIAERESIS AND ACUTE                          */
   { 0xDC, 0x04, 0x01D5 }, /* 0x00DC + 0x0304 = 0x01D5 LATIN CAPITAL LETTER U WITH DIAERESIS AND MACRON                         */
   { 0xDC, 0x0C, 0x01D9 }, /* 0x00DC + 0x030C = 0x01D9 LATIN CAPITAL LETTER U WITH DIAERESIS AND CARON                          */
   { 0xE2, 0x00, 0x1EA7 }, /* 0x00E2 + 0x0300 = 0x1EA7 LATIN SMALL LETTER A WITH CIRCUMFLEX AND GRAVE                           */
   { 0xE2, 0x01, 0x1EA5 }, /* 0x00E2 + 0x0301 = 0x1EA5 LATIN SMALL LETTER A WITH CIRCUMFLEX AND ACUTE                           */
   { 0xE2, 0x03, 0x1EAB }, /* 0x00E2 + 0x0303 = 0x1EAB LATIN SMALL LETTER A WITH CIRCUMFLEX AND TILDE                           */
   { 0xE2, 0x09, 0x1EA9 }, /* 0x00E2 + 0x0309 = 0x1EA9 LATIN SMALL LETTER A WITH CIRCUMFLEX AND HOOK ABOVE                      */
   { 0xE4, 0x04, 0x01DF }, /* 0x00E4 + 0x0304 = 0x01DF LATIN SMALL LETTER A WITH DIAERESIS AND MACRON                           */
   { 0xE5, 0x01, 0x01FB }, /* 0x00E5 + 0x0301 = 0x01FB LATIN SMALL LETTER A WITH RING ABOVE AND ACUTE                           */
   { 0xE6, 0x01, 0x01FD }, /* 0x00E6 + 0x0301 = 0x01FD LATIN SMALL LETTER AE WITH ACUTE                                         */
   { 0xE6, 0x04, 0x01E3 }, /* 0x00E6 + 0x0304 = 0x01E3 LATIN SMALL LETTER AE WITH MACRON                                        */
   { 0xE7, 0x01, 0x1E09 }, /* 0x00E7 + 0x0301 = 0x1E09 LATIN SMALL LETTER C WITH CEDILLA AND ACUTE                              */
   { 0xEA, 0x00, 0x1EC1 }, /* 0x00EA + 0x0300 = 0x1EC1 LATIN SMALL LETTER E WITH CIRCUMFLEX AND GRAVE                           */
   { 0xEA, 0x01, 0x1EBF }, /* 0x00EA + 0x0301 = 0x1EBF LATIN SMALL LETTER E WITH CIRCUMFLEX AND ACUTE                           */
   { 0xEA, 0x03, 0x1EC5 }, /* 0x00EA + 0x0303 = 0x1EC5 LATIN SMALL LETTER E WITH CIRCUMFLEX AND TILDE                           */
   { 0xEA, 0x09, 0x1EC3 }, /* 0x00EA + 0x0309 = 0x1EC3 LATIN SMALL LETTER E WITH CIRCUMFLEX AND HOOK ABOVE                      */
   { 0xEF, 0x01, 0x1E2F }, /* 0x00EF + 0x0301 = 0x1E2F LATIN SMALL LETTER I WITH DIAERESIS AND ACUTE                            */
   { 0xF4, 0x00, 0x1ED3 }, /* 0x00F4 + 0x0300 = 0x1ED3 LATIN SMALL LETTER O WITH CIRCUMFLEX AND GRAVE                           */
   { 0xF4, 0x01, 0x1ED1 }, /* 0x00F4 + 0x0301 = 0x1ED1 LATIN SMALL LETTER O WITH CIRCUMFLEX AND ACUTE                           */
   { 0xF4, 0x03, 0x1ED7 }, /* 0x00F4 + 0x0303 = 0x1ED7 LATIN SMALL LETTER O WITH CIRCUMFLEX AND TILDE                           */
   { 0xF4, 0x09, 0x1ED5 }, /* 0x00F4 + 0x0309 = 0x1ED5 LATIN SMALL LETTER O WITH CIRCUMFLEX AND HOOK ABOVE                      */
   { 0xF5, 0x01, 0x1E4D }, /* 0x00F5 + 0x0301 = 0x1E4D LATIN SMALL LETTER O WITH TILDE AND ACUTE                                */
   { 0xF5, 0x04, 0x022D }, /* 0x00F5 + 0x0304 = 0x022D LATIN SMALL LETTER O WITH TILDE AND MACRON                               */
   { 0xF5, 0x08, 0x1E4F }, /* 0x00F5 + 0x0308 = 0x1E4F LATIN SMALL LETTER O WITH TILDE AND DIAERESIS                            */
   { 0xF6, 0x04, 0x022B }, /* 0x00F6 + 0x0304 = 0x022B LATIN SMALL LETTER O WITH DIAERESIS AND MACRON                           */
   { 0xF8, 0x01, 0x01FF }, /* 0x00F8 + 0x0301 = 0x01FF LATIN SMALL LETTER O WITH STROKE AND ACUTE                               */
   { 0xFC, 0x00, 0x01DC }, /* 0x00FC + 0x0300 = 0x01DC LATIN SMALL LETTER U WITH DIAERESIS AND GRAVE                            */
   { 0xFC, 0x01, 0x01D8 }, /* 0x00FC + 0x0301 = 0x01D8 LATIN SMALL LETTER U WITH DIAERESIS AND ACUTE                            */
   { 0xFC, 0x04, 0x01D6 }, /* 0x00FC + 0x0304 = 0x01D6 LATIN SMALL LETTER U WITH DIAERESIS AND MACRON                           */
   { 0xFC, 0x0C, 0x01DA }, /* 0x00FC + 0x030C = 0x01DA LATIN SMALL LETTER U WITH DIAERESIS AND CARON                            */
   /* --------------- block_01_03 @  434 --------------- */
   { 0x02, 0x00, 0x1EB0 }, /* 0x0102 + 0x0300 = 0x1EB0 LATIN CAPITAL LETTER A WITH BREVE AND GRAVE                              */
   { 0x02, 0x01, 0x1EAE }, /* 0x0102 + 0x0301 = 0x1EAE LATIN CAPITAL LETTER A WITH BREVE AND ACUTE                              */
   { 0x02, 0x03, 0x1EB4 }, /* 0x0102 + 0x0303 = 0x1EB4 LATIN CAPITAL LETTER A WITH BREVE AND TILDE                              */
   { 0x02, 0x09, 0x1EB2 }, /* 0x0102 + 0x0309 = 0x1EB2 LATIN CAPITAL LETTER A WITH BREVE AND HOOK ABOVE                         */
   { 0x03, 0x00, 0x1EB1 }, /* 0x0103 + 0x0300 = 0x1EB1 LATIN SMALL LETTER A WITH BREVE AND GRAVE                                */
   { 0x03, 0x01, 0x1EAF }, /* 0x0103 + 0x0301 = 0x1EAF LATIN SMALL LETTER A WITH BREVE AND ACUTE                                */
   { 0x03, 0x03, 0x1EB5 }, /* 0x0103 + 0x0303 = 0x1EB5 LATIN SMALL LETTER A WITH BREVE AND TILDE                                */
   { 0x03, 0x09, 0x1EB3 }, /* 0x0103 + 0x0309 = 0x1EB3 LATIN SMALL LETTER A WITH BREVE AND HOOK ABOVE                           */
   { 0x12, 0x00, 0x1E14 }, /* 0x0112 + 0x0300 = 0x1E14 LATIN CAPITAL LETTER E WITH MACRON AND GRAVE                             */
   { 0x12, 0x01, 0x1E16 }, /* 0x0112 + 0x0301 = 0x1E16 LATIN CAPITAL LETTER E WITH MACRON AND ACUTE                             */
   { 0x13, 0x00, 0x1E15 }, /* 0x0113 + 0x0300 = 0x1E15 LATIN SMALL LETTER E WITH MACRON AND GRAVE                               */
   { 0x13, 0x01, 0x1E17 }, /* 0x0113 + 0x0301 = 0x1E17 LATIN SMALL LETTER E WITH MACRON AND ACUTE                               */
   { 0x4C, 0x00, 0x1E50 }, /* 0x014C + 0x0300 = 0x1E50 LATIN CAPITAL LETTER O WITH MACRON AND GRAVE                             */
   { 0x4C, 0x01, 0x1E52 }, /* 0x014C + 0x0301 = 0x1E52 LATIN CAPITAL LETTER O WITH MACRON AND ACUTE                             */
   { 0x4D, 0x00, 0x1E51 }, /* 0x014D + 0x0300 = 0x1E51 LATIN SMALL LETTER O WITH MACRON AND GRAVE                               */
   { 0x4D, 0x01, 0x1E53 }, /* 0x014D + 0x0301 = 0x1E53 LATIN SMALL LETTER O WITH MACRON AND ACUTE                               */
   { 0x5A, 0x07, 0x1E64 }, /* 0x015A + 0x0307 = 0x1E64 LATIN CAPITAL LETTER S WITH ACUTE AND DOT ABOVE                          */
   { 0x5B, 0x07, 0x1E65 }, /* 0x015B + 0x0307 = 0x1E65 LATIN SMALL LETTER S WITH ACUTE AND DOT ABOVE                            */
   { 0x60, 0x07, 0x1E66 }, /* 0x0160 + 0x0307 = 0x1E66 LATIN CAPITAL LETTER S WITH CARON AND DOT ABOVE                          */
   { 0x61, 0x07, 0x1E67 }, /* 0x0161 + 0x0307 = 0x1E67 LATIN SMALL LETTER S WITH CARON AND DOT ABOVE                            */
   { 0x68, 0x01, 0x1E78 }, /* 0x0168 + 0x0301 = 0x1E78 LATIN CAPITAL LETTER U WITH TILDE AND ACUTE                              */
   { 0x69, 0x01, 0x1E79 }, /* 0x0169 + 0x0301 = 0x1E79 LATIN SMALL LETTER U WITH TILDE AND ACUTE                                */
   { 0x6A, 0x08, 0x1E7A }, /* 0x016A + 0x0308 = 0x1E7A LATIN CAPITAL LETTER U WITH MACRON AND DIAERESIS                         */
   { 0x6B, 0x08, 0x1E7B }, /* 0x016B + 0x0308 = 0x1E7B LATIN SMALL LETTER U WITH MACRON AND DIAERESIS                           */
   { 0x7F, 0x07, 0x1E9B }, /* 0x017F + 0x0307 = 0x1E9B LATIN SMALL LETTER LONG S WITH DOT ABOVE                                 */
   { 0xA0, 0x00, 0x1EDC }, /* 0x01A0 + 0x0300 = 0x1EDC LATIN CAPITAL LETTER O WITH HORN AND GRAVE                               */
   { 0xA0, 0x01, 0x1EDA }, /* 0x01A0 + 0x0301 = 0x1EDA LATIN CAPITAL LETTER O WITH HORN AND ACUTE                               */
   { 0xA0, 0x03, 0x1EE0 }, /* 0x01A0 + 0x0303 = 0x1EE0 LATIN CAPITAL LETTER O WITH HORN AND TILDE                               */
   { 0xA0, 0x09, 0x1EDE }, /* 0x01A0 + 0x0309 = 0x1EDE LATIN CAPITAL LETTER O WITH HORN AND HOOK ABOVE                          */
   { 0xA0, 0x23, 0x1EE2 }, /* 0x01A0 + 0x0323 = 0x1EE2 LATIN CAPITAL LETTER O WITH HORN AND DOT BELOW                           */
   { 0xA1, 0x00, 0x1EDD }, /* 0x01A1 + 0x0300 = 0x1EDD LATIN SMALL LETTER O WITH HORN AND GRAVE                                 */
   { 0xA1, 0x01, 0x1EDB }, /* 0x01A1 + 0x0301 = 0x1EDB LATIN SMALL LETTER O WITH HORN AND ACUTE                                 */
   { 0xA1, 0x03, 0x1EE1 }, /* 0x01A1 + 0x0303 = 0x1EE1 LATIN SMALL LETTER O WITH HORN AND TILDE                                 */
   { 0xA1, 0x09, 0x1EDF }, /* 0x01A1 + 0x0309 = 0x1EDF LATIN SMALL LETTER O WITH HORN AND HOOK ABOVE                            */
   { 0xA1, 0x23, 0x1EE3 }, /* 0x01A1 + 0x0323 = 0x1EE3 LATIN SMALL LETTER O WITH HORN AND DOT BELOW                             */
   { 0xAF, 0x00, 0x1EEA }, /* 0x01AF + 0x0300 = 0x1EEA LATIN CAPITAL LETTER U WITH HORN AND GRAVE                               */
   { 0xAF, 0x01, 0x1EE8 }, /* 0x01AF + 0x0301 = 0x1EE8 LATIN CAPITAL LETTER U WITH HORN AND ACUTE                               */
   { 0xAF, 0x03, 0x1EEE }, /* 0x01AF + 0x0303 = 0x1EEE LATIN CAPITAL LETTER U WITH HORN AND TILDE                               */
   { 0xAF, 0x09, 0x1EEC }, /* 0x01AF + 0x0309 = 0x1EEC LATIN CAPITAL LETTER U WITH HORN AND HOOK ABOVE                          */
   { 0xAF, 0x23, 0x1EF0 }, /* 0x01AF + 0x0323 = 0x1EF0 LATIN CAPITAL LETTER U WITH HORN AND DOT BELOW                           */
   { 0xB0, 0x00, 0x1EEB }, /* 0x01B0 + 0x0300 = 0x1EEB LATIN SMALL LETTER U WITH HORN AND GRAVE                                 */
   { 0xB0, 0x01, 0x1EE9 }, /* 0x01B0 + 0x0301 = 0x1EE9 LATIN SMALL LETTER U WITH HORN AND ACUTE                                 */
   { 0xB0, 0x03, 0x1EEF }, /* 0x01B0 + 0x0303 = 0x1EEF LATIN SMALL LETTER U WITH HORN AND TILDE                                 */
   { 0xB0, 0x09, 0x1EED }, /* 0x01B0 + 0x0309 = 0x1EED LATIN SMALL LETTER U WITH HORN AND HOOK ABOVE                            */
   { 0xB0, 0x23, 0x1EF1 }, /* 0x01B0 + 0x0323 = 0x1EF1 LATIN SMALL LETTER U WITH HORN AND DOT BELOW                             */
   { 0xB7, 0x0C, 0x01EE }, /* 0x01B7 + 0x030C = 0x01EE LATIN CAPITAL LETTER EZH WITH CARON                                      */
   { 0xEA, 0x04, 0x01EC }, /* 0x01EA + 0x0304 = 0x01EC LATIN CAPITAL LETTER O WITH OGONEK AND MACRON                            */
   { 0xEB, 0x04, 0x01ED }, /* 0x01EB + 0x0304 = 0x01ED LATIN SMALL LETTER O WITH OGONEK AND MACRON                              */
   /* --------------- block_02_03 @  482 --------------- */
   { 0x26, 0x04, 0x01E0 }, /* 0x0226 + 0x0304 = 0x01E0 LATIN CAPITAL LETTER A WITH DOT ABOVE AND MACRON                         */
   { 0x27, 0x04, 0x01E1 }, /* 0x0227 + 0x0304 = 0x01E1 LATIN SMALL LETTER A WITH DOT ABOVE AND MACRON                           */
   { 0x28, 0x06, 0x1E1C }, /* 0x0228 + 0x0306 = 0x1E1C LATIN CAPITAL LETTER E WITH CEDILLA AND BREVE                            */
   { 0x29, 0x06, 0x1E1D }, /* 0x0229 + 0x0306 = 0x1E1D LATIN SMALL LETTER E WITH CEDILLA AND BREVE                              */
   { 0x2E, 0x04, 0x0230 }, /* 0x022E + 0x0304 = 0x0230 LATIN CAPITAL LETTER O WITH DOT ABOVE AND MACRON                         */
   { 0x2F, 0x04, 0x0231 }, /* 0x022F + 0x0304 = 0x0231 LATIN SMALL LETTER O WITH DOT ABOVE AND MACRON                           */
   { 0x92, 0x0C, 0x01EF }, /* 0x0292 + 0x030C = 0x01EF LATIN SMALL LETTER EZH WITH CARON                                        */
   /* --------------- block_03_03 @  489 --------------- */
   { 0x91, 0x00, 0x1FBA }, /* 0x0391 + 0x0300 = 0x1FBA GREEK CAPITAL LETTER ALPHA WITH VARIA                                    */
   { 0x91, 0x01, 0x0386 }, /* 0x0391 + 0x0301 = 0x0386 GREEK CAPITAL LETTER ALPHA WITH TONOS                                    */
   { 0x91, 0x04, 0x1FB9 }, /* 0x0391 + 0x0304 = 0x1FB9 GREEK CAPITAL LETTER ALPHA WITH MACRON                                   */
   { 0x91, 0x06, 0x1FB8 }, /* 0x0391 + 0x0306 = 0x1FB8 GREEK CAPITAL LETTER ALPHA WITH VRACHY                                   */
   { 0x91, 0x13, 0x1F08 }, /* 0x0391 + 0x0313 = 0x1F08 GREEK CAPITAL LETTER ALPHA WITH PSILI                                    */
   { 0x91, 0x14, 0x1F09 }, /* 0x0391 + 0x0314 = 0x1F09 GREEK CAPITAL LETTER ALPHA WITH DASIA                                    */
   { 0x91, 0x45, 0x1FBC }, /* 0x0391 + 0x0345 = 0x1FBC GREEK CAPITAL LETTER ALPHA WITH PROSGEGRAMMENI                           */
   { 0x95, 0x00, 0x1FC8 }, /* 0x0395 + 0x0300 = 0x1FC8 GREEK CAPITAL LETTER EPSILON WITH VARIA                                  */
   { 0x95, 0x01, 0x0388 }, /* 0x0395 + 0x0301 = 0x0388 GREEK CAPITAL LETTER EPSILON WITH TONOS                                  */
   { 0x95, 0x13, 0x1F18 }, /* 0x0395 + 0x0313 = 0x1F18 GREEK CAPITAL LETTER EPSILON WITH PSILI                                  */
   { 0x95, 0x14, 0x1F19 }, /* 0x0395 + 0x0314 = 0x1F19 GREEK CAPITAL LETTER EPSILON WITH DASIA                                  */
   { 0x97, 0x00, 0x1FCA }, /* 0x0397 + 0x0300 = 0x1FCA GREEK CAPITAL LETTER ETA WITH VARIA                                      */
   { 0x97, 0x01, 0x0389 }, /* 0x0397 + 0x0301 = 0x0389 GREEK CAPITAL LETTER ETA WITH TONOS                                      */
   { 0x97, 0x13, 0x1F28 }, /* 0x0397 + 0x0313 = 0x1F28 GREEK CAPITAL LETTER ETA WITH PSILI                                      */
   { 0x97, 0x14, 0x1F29 }, /* 0x0397 + 0x0314 = 0x1F29 GREEK CAPITAL LETTER ETA WITH DASIA                                      */
   { 0x97, 0x45, 0x1FCC }, /* 0x0397 + 0x0345 = 0x1FCC GREEK CAPITAL LETTER ETA WITH PROSGEGRAMMENI                             */
   { 0x99, 0x00, 0x1FDA }, /* 0x0399 + 0x0300 = 0x1FDA GREEK CAPITAL LETTER IOTA WITH VARIA                                     */
   { 0x99, 0x01, 0x038A }, /* 0x0399 + 0x0301 = 0x038A GREEK CAPITAL LETTER IOTA WITH TONOS                                     */
   { 0x99, 0x04, 0x1FD9 }, /* 0x0399 + 0x0304 = 0x1FD9 GREEK CAPITAL LETTER IOTA WITH MACRON                                    */
   { 0x99, 0x06, 0x1FD8 }, /* 0x0399 + 0x0306 = 0x1FD8 GREEK CAPITAL LETTER IOTA WITH VRACHY                                    */
   { 0x99, 0x08, 0x03AA }, /* 0x0399 + 0x0308 = 0x03AA GREEK CAPITAL LETTER IOTA WITH DIALYTIKA                                 */
   { 0x99, 0x13, 0x1F38 }, /* 0x0399 + 0x0313 = 0x1F38 GREEK CAPITAL LETTER IOTA WITH PSILI                                     */
   { 0x99, 0x14, 0x1F39 }, /* 0x0399 + 0x0314 = 0x1F39 GREEK CAPITAL LETTER IOTA WITH DASIA                                     */
   { 0x9F, 0x00, 0x1FF8 }, /* 0x039F + 0x0300 = 0x1FF8 GREEK CAPITAL LETTER OMICRON WITH VARIA                                  */
   { 0x9F, 0x01, 0x038C }, /* 0x039F + 0x0301 = 0x038C GREEK CAPITAL LETTER OMICRON WITH TONOS                                  */
   { 0x9F, 0x13, 0x1F48 }, /* 0x039F + 0x0313 = 0x1F48 GREEK CAPITAL LETTER OMICRON WITH PSILI                                  */
   { 0x9F, 0x14, 0x1F49 }, /* 0x039F + 0x0314 = 0x1F49 GREEK CAPITAL LETTER OMICRON WITH DASIA                                  */
   { 0xA1, 0x14, 0x1FEC }, /* 0x03A1 + 0x0314 = 0x1FEC GREEK CAPITAL LETTER RHO WITH DASIA                                      */
   { 0xA5, 0x00, 0x1FEA }, /* 0x03A5 + 0x0300 = 0x1FEA GREEK CAPITAL LETTER UPSILON WITH VARIA                                  */
   { 0xA5, 0x01, 0x038E }, /* 0x03A5 + 0x0301 = 0x038E GREEK CAPITAL LETTER UPSILON WITH TONOS                                  */
   { 0xA5, 0x04, 0x1FE9 }, /* 0x03A5 + 0x0304 = 0x1FE9 GREEK CAPITAL LETTER UPSILON WITH MACRON                                 */
   { 0xA5, 0x06, 0x1FE8 }, /* 0x03A5 + 0x0306 = 0x1FE8 GREEK CAPITAL LETTER UPSILON WITH VRACHY                                 */
   { 0xA5, 0x08, 0x03AB }, /* 0x03A5 + 0x0308 = 0x03AB GREEK CAPITAL LETTER UPSILON WITH DIALYTIKA                              */
   { 0xA5, 0x14, 0x1F59 }, /* 0x03A5 + 0x0314 = 0x1F59 GREEK CAPITAL LETTER UPSILON WITH DASIA                                  */
   { 0xA9, 0x00, 0x1FFA }, /* 0x03A9 + 0x0300 = 0x1FFA GREEK CAPITAL LETTER OMEGA WITH VARIA                                    */
   { 0xA9, 0x01, 0x038F }, /* 0x03A9 + 0x0301 = 0x038F GREEK CAPITAL LETTER OMEGA WITH TONOS                                    */
   { 0xA9, 0x13, 0x1F68 }, /* 0x03A9 + 0x0313 = 0x1F68 GREEK CAPITAL LETTER OMEGA WITH PSILI                                    */
   { 0xA9, 0x14, 0x1F69 }, /* 0x03A9 + 0x0314 = 0x1F69 GREEK CAPITAL LETTER OMEGA WITH DASIA                                    */
   { 0xA9, 0x45, 0x1FFC }, /* 0x03A9 + 0x0345 = 0x1FFC GREEK CAPITAL LETTER OMEGA WITH PROSGEGRAMMENI                           */
   { 0xAC, 0x45, 0x1FB4 }, /* 0x03AC + 0x0345 = 0x1FB4 GREEK SMALL LETTER ALPHA WITH OXIA AND YPOGEGRAMMENI                     */
   { 0xAE, 0x45, 0x1FC4 }, /* 0x03AE + 0x0345 = 0x1FC4 GREEK SMALL LETTER ETA WITH OXIA AND YPOGEGRAMMENI                       */
   { 0xB1, 0x00, 0x1F70 }, /* 0x03B1 + 0x0300 = 0x1F70 GREEK SMALL LETTER ALPHA WITH VARIA                                      */
   { 0xB1, 0x01, 0x03AC }, /* 0x03B1 + 0x0301 = 0x03AC GREEK SMALL LETTER ALPHA WITH TONOS                                      */
   { 0xB1, 0x04, 0x1FB1 }, /* 0x03B1 + 0x0304 = 0x1FB1 GREEK SMALL LETTER ALPHA WITH MACRON                                     */
   { 0xB1, 0x06, 0x1FB0 }, /* 0x03B1 + 0x0306 = 0x1FB0 GREEK SMALL LETTER ALPHA WITH VRACHY                                     */
   { 0xB1, 0x13, 0x1F00 }, /* 0x03B1 + 0x0313 = 0x1F00 GREEK SMALL LETTER ALPHA WITH PSILI                                      */
   { 0xB1, 0x14, 0x1F01 }, /* 0x03B1 + 0x0314 = 0x1F01 GREEK SMALL LETTER ALPHA WITH DASIA                                      */
   { 0xB1, 0x42, 0x1FB6 }, /* 0x03B1 + 0x0342 = 0x1FB6 GREEK SMALL LETTER ALPHA WITH PERISPOMENI                                */
   { 0xB1, 0x45, 0x1FB3 }, /* 0x03B1 + 0x0345 = 0x1FB3 GREEK SMALL LETTER ALPHA WITH YPOGEGRAMMENI                              */
   { 0xB5, 0x00, 0x1F72 }, /* 0x03B5 + 0x0300 = 0x1F72 GREEK SMALL LETTER EPSILON WITH VARIA                                    */
   { 0xB5, 0x01, 0x03AD }, /* 0x03B5 + 0x0301 = 0x03AD GREEK SMALL LETTER EPSILON WITH TONOS                                    */
   { 0xB5, 0x13, 0x1F10 }, /* 0x03B5 + 0x0313 = 0x1F10 GREEK SMALL LETTER EPSILON WITH PSILI                                    */
   { 0xB5, 0x14, 0x1F11 }, /* 0x03B5 + 0x0314 = 0x1F11 GREEK SMALL LETTER EPSILON WITH DASIA                                    */
   { 0xB7, 0x00, 0x1F74 }, /* 0x03B7 + 0x0300 = 0x1F74 GREEK SMALL LETTER ETA WITH VARIA                                        */
   { 0xB7, 0x01, 0x03AE }, /* 0x03B7 + 0x0301 = 0x03AE GREEK SMALL LETTER ETA WITH TONOS                                        */
   { 0xB7, 0x13, 0x1F20 }, /* 0x03B7 + 0x0313 = 0x1F20 GREEK SMALL LETTER ETA WITH PSILI                                        */
   { 0xB7, 0x14, 0x1F21 }, /* 0x03B7 + 0x0314 = 0x1F21 GREEK SMALL LETTER ETA WITH DASIA                                        */
   { 0xB7, 0x42, 0x1FC6 }, /* 0x03B7 + 0x0342 = 0x1FC6 GREEK SMALL LETTER ETA WITH PERISPOMENI                                  */
   { 0xB7, 0x45, 0x1FC3 }, /* 0x03B7 + 0x0345 = 0x1FC3 GREEK SMALL LETTER ETA WITH YPOGEGRAMMENI                                */
   { 0xB9, 0x00, 0x1F76 }, /* 0x03B9 + 0x0300 = 0x1F76 GREEK SMALL LETTER IOTA WITH VARIA                                       */
   { 0xB9, 0x01, 0x03AF }, /* 0x03B9 + 0x0301 = 0x03AF GREEK SMALL LETTER IOTA WITH TONOS                                       */
   { 0xB9, 0x04, 0x1FD1 }, /* 0x03B9 + 0x0304 = 0x1FD1 GREEK SMALL LETTER IOTA WITH MACRON                                      */
   { 0xB9, 0x06, 0x1FD0 }, /* 0x03B9 + 0x0306 = 0x1FD0 GREEK SMALL LETTER IOTA WITH VRACHY                                      */
   { 0xB9, 0x08, 0x03CA }, /* 0x03B9 + 0x0308 = 0x03CA GREEK SMALL LETTER IOTA WITH DIALYTIKA                                   */
   { 0xB9, 0x13, 0x1F30 }, /* 0x03B9 + 0x0313 = 0x1F30 GREEK SMALL LETTER IOTA WITH PSILI                                       */
   { 0xB9, 0x14, 0x1F31 }, /* 0x03B9 + 0x0314 = 0x1F31 GREEK SMALL LETTER IOTA WITH DASIA                                       */
   { 0xB9, 0x42, 0x1FD6 }, /* 0x03B9 + 0x0342 = 0x1FD6 GREEK SMALL LETTER IOTA WITH PERISPOMENI                                 */
   { 0xBF, 0x00, 0x1F78 }, /* 0x03BF + 0x0300 = 0x1F78 GREEK SMALL LETTER OMICRON WITH VARIA                                    */
   { 0xBF, 0x01, 0x03CC }, /* 0x03BF + 0x0301 = 0x03CC GREEK SMALL LETTER OMICRON WITH TONOS                                    */
   { 0xBF, 0x13, 0x1F40 }, /* 0x03BF + 0x0313 = 0x1F40 GREEK SMALL LETTER OMICRON WITH PSILI                                    */
   { 0xBF, 0x14, 0x1F41 }, /* 0x03BF + 0x0314 = 0x1F41 GREEK SMALL LETTER OMICRON WITH DASIA                                    */
   { 0xC1, 0x13, 0x1FE4 }, /* 0x03C1 + 0x0313 = 0x1FE4 GREEK SMALL LETTER RHO WITH PSILI                                        */
   { 0xC1, 0x14, 0x1FE5 }, /* 0x03C1 + 0x0314 = 0x1FE5 GREEK SMALL LETTER RHO WITH DASIA                                        */
   { 0xC5, 0x00, 0x1F7A }, /* 0x03C5 + 0x0300 = 0x1F7A GREEK SMALL LETTER UPSILON WITH VARIA                                    */
   { 0xC5, 0x01, 0x03CD }, /* 0x03C5 + 0x0301 = 0x03CD GREEK SMALL LETTER UPSILON WITH TONOS                                    */
   { 0xC5, 0x04, 0x1FE1 }, /* 0x03C5 + 0x0304 = 0x1FE1 GREEK SMALL LETTER UPSILON WITH MACRON                                   */
   { 0xC5, 0x06, 0x1FE0 }, /* 0x03C5 + 0x0306 = 0x1FE0 GREEK SMALL LETTER UPSILON WITH VRACHY                                   */
   { 0xC5, 0x08, 0x03CB }, /* 0x03C5 + 0x0308 = 0x03CB GREEK SMALL LETTER UPSILON WITH DIALYTIKA                                */
   { 0xC5, 0x13, 0x1F50 }, /* 0x03C5 + 0x0313 = 0x1F50 GREEK SMALL LETTER UPSILON WITH PSILI                                    */
   { 0xC5, 0x14, 0x1F51 }, /* 0x03C5 + 0x0314 = 0x1F51 GREEK SMALL LETTER UPSILON WITH DASIA                                    */
   { 0xC5, 0x42, 0x1FE6 }, /* 0x03C5 + 0x0342 = 0x1FE6 GREEK SMALL LETTER UPSILON WITH PERISPOMENI                              */
   { 0xC9, 0x00, 0x1F7C }, /* 0x03C9 + 0x0300 = 0x1F7C GREEK SMALL LETTER OMEGA WITH VARIA                                      */
   { 0xC9, 0x01, 0x03CE }, /* 0x03C9 + 0x0301 = 0x03CE GREEK SMALL LETTER OMEGA WITH TONOS                                      */
   { 0xC9, 0x13, 0x1F60 }, /* 0x03C9 + 0x0313 = 0x1F60 GREEK SMALL LETTER OMEGA WITH PSILI                                      */
   { 0xC9, 0x14, 0x1F61 }, /* 0x03C9 + 0x0314 = 0x1F61 GREEK SMALL LETTER OMEGA WITH DASIA                                      */
   { 0xC9, 0x42, 0x1FF6 }, /* 0x03C9 + 0x0342 = 0x1FF6 GREEK SMALL LETTER OMEGA WITH PERISPOMENI                                */
   { 0xC9, 0x45, 0x1FF3 }, /* 0x03C9 + 0x0345 = 0x1FF3 GREEK SMALL LETTER OMEGA WITH YPOGEGRAMMENI                              */
   { 0xCA, 0x00, 0x1FD2 }, /* 0x03CA + 0x0300 = 0x1FD2 GREEK SMALL LETTER IOTA WITH DIALYTIKA AND VARIA                         */
   { 0xCA, 0x01, 0x0390 }, /* 0x03CA + 0x0301 = 0x0390 GREEK SMALL LETTER IOTA WITH DIALYTIKA AND TONOS                         */
   { 0xCA, 0x42, 0x1FD7 }, /* 0x03CA + 0x0342 = 0x1FD7 GREEK SMALL LETTER IOTA WITH DIALYTIKA AND PERISPOMENI                   */
   { 0xCB, 0x00, 0x1FE2 }, /* 0x03CB + 0x0300 = 0x1FE2 GREEK SMALL LETTER UPSILON WITH DIALYTIKA AND VARIA                      */
   { 0xCB, 0x01, 0x03B0 }, /* 0x03CB + 0x0301 = 0x03B0 GREEK SMALL LETTER UPSILON WITH DIALYTIKA AND TONOS                      */
   { 0xCB, 0x42, 0x1FE7 }, /* 0x03CB + 0x0342 = 0x1FE7 GREEK SMALL LETTER UPSILON WITH DIALYTIKA AND PERISPOMENI                */
   { 0xCE, 0x45, 0x1FF4 }, /* 0x03CE + 0x0345 = 0x1FF4 GREEK SMALL LETTER OMEGA WITH OXIA AND YPOGEGRAMMENI                     */
   { 0xD2, 0x01, 0x03D3 }, /* 0x03D2 + 0x0301 = 0x03D3 GREEK UPSILON WITH ACUTE AND HOOK SYMBOL                                 */
   { 0xD2, 0x08, 0x03D4 }, /* 0x03D2 + 0x0308 = 0x03D4 GREEK UPSILON WITH DIAERESIS AND HOOK SYMBOL                             */
   /* --------------- block_04_03 @  585 --------------- */
   { 0x06, 0x08, 0x0407 }, /* 0x0406 + 0x0308 = 0x0407 CYRILLIC CAPITAL LETTER YI                                               */
   { 0x10, 0x06, 0x04D0 }, /* 0x0410 + 0x0306 = 0x04D0 CYRILLIC CAPITAL LETTER A WITH BREVE                                     */
   { 0x10, 0x08, 0x04D2 }, /* 0x0410 + 0x0308 = 0x04D2 CYRILLIC CAPITAL LETTER A WITH DIAERESIS                                 */
   { 0x13, 0x01, 0x0403 }, /* 0x0413 + 0x0301 = 0x0403 CYRILLIC CAPITAL LETTER GJE                                              */
   { 0x15, 0x00, 0x0400 }, /* 0x0415 + 0x0300 = 0x0400 CYRILLIC CAPITAL LETTER IE WITH GRAVE                                    */
   { 0x15, 0x06, 0x04D6 }, /* 0x0415 + 0x0306 = 0x04D6 CYRILLIC CAPITAL LETTER IE WITH BREVE                                    */
   { 0x15, 0x08, 0x0401 }, /* 0x0415 + 0x0308 = 0x0401 CYRILLIC CAPITAL LETTER IO                                               */
   { 0x16, 0x06, 0x04C1 }, /* 0x0416 + 0x0306 = 0x04C1 CYRILLIC CAPITAL LETTER ZHE WITH BREVE                                   */
   { 0x16, 0x08, 0x04DC }, /* 0x0416 + 0x0308 = 0x04DC CYRILLIC CAPITAL LETTER ZHE WITH DIAERESIS                               */
   { 0x17, 0x08, 0x04DE }, /* 0x0417 + 0x0308 = 0x04DE CYRILLIC CAPITAL LETTER ZE WITH DIAERESIS                                */
   { 0x18, 0x00, 0x040D }, /* 0x0418 + 0x0300 = 0x040D CYRILLIC CAPITAL LETTER I WITH GRAVE                                     */
   { 0x18, 0x04, 0x04E2 }, /* 0x0418 + 0x0304 = 0x04E2 CYRILLIC CAPITAL LETTER I WITH MACRON                                    */
   { 0x18, 0x06, 0x0419 }, /* 0x0418 + 0x0306 = 0x0419 CYRILLIC CAPITAL LETTER SHORT I                                          */
   { 0x18, 0x08, 0x04E4 }, /* 0x0418 + 0x0308 = 0x04E4 CYRILLIC CAPITAL LETTER I WITH DIAERESIS                                 */
   { 0x1A, 0x01, 0x040C }, /* 0x041A + 0x0301 = 0x040C CYRILLIC CAPITAL LETTER KJE                                              */
   { 0x1E, 0x08, 0x04E6 }, /* 0x041E + 0x0308 = 0x04E6 CYRILLIC CAPITAL LETTER O WITH DIAERESIS                                 */
   { 0x23, 0x04, 0x04EE }, /* 0x0423 + 0x0304 = 0x04EE CYRILLIC CAPITAL LETTER U WITH MACRON                                    */
   { 0x23, 0x06, 0x040E }, /* 0x0423 + 0x0306 = 0x040E CYRILLIC CAPITAL LETTER SHORT U                                          */
   { 0x23, 0x08, 0x04F0 }, /* 0x0423 + 0x0308 = 0x04F0 CYRILLIC CAPITAL LETTER U WITH DIAERESIS                                 */
   { 0x23, 0x0B, 0x04F2 }, /* 0x0423 + 0x030B = 0x04F2 CYRILLIC CAPITAL LETTER U WITH DOUBLE ACUTE                              */
   { 0x27, 0x08, 0x04F4 }, /* 0x0427 + 0x0308 = 0x04F4 CYRILLIC CAPITAL LETTER CHE WITH DIAERESIS                               */
   { 0x2B, 0x08, 0x04F8 }, /* 0x042B + 0x0308 = 0x04F8 CYRILLIC CAPITAL LETTER YERU WITH DIAERESIS                              */
   { 0x2D, 0x08, 0x04EC }, /* 0x042D + 0x0308 = 0x04EC CYRILLIC CAPITAL LETTER E WITH DIAERESIS                                 */
   { 0x30, 0x06, 0x04D1 }, /* 0x0430 + 0x0306 = 0x04D1 CYRILLIC SMALL LETTER A WITH BREVE                                       */
   { 0x30, 0x08, 0x04D3 }, /* 0x0430 + 0x0308 = 0x04D3 CYRILLIC SMALL LETTER A WITH DIAERESIS                                   */
   { 0x33, 0x01, 0x0453 }, /* 0x0433 + 0x0301 = 0x0453 CYRILLIC SMALL LETTER GJE                                                */
   { 0x35, 0x00, 0x0450 }, /* 0x0435 + 0x0300 = 0x0450 CYRILLIC SMALL LETTER IE WITH GRAVE                                      */
   { 0x35, 0x06, 0x04D7 }, /* 0x0435 + 0x0306 = 0x04D7 CYRILLIC SMALL LETTER IE WITH BREVE                                      */
   { 0x35, 0x08, 0x0451 }, /* 0x0435 + 0x0308 = 0x0451 CYRILLIC SMALL LETTER IO                                                 */
   { 0x36, 0x06, 0x04C2 }, /* 0x0436 + 0x0306 = 0x04C2 CYRILLIC SMALL LETTER ZHE WITH BREVE                                     */
   { 0x36, 0x08, 0x04DD }, /* 0x0436 + 0x0308 = 0x04DD CYRILLIC SMALL LETTER ZHE WITH DIAERESIS                                 */
   { 0x37, 0x08, 0x04DF }, /* 0x0437 + 0x0308 = 0x04DF CYRILLIC SMALL LETTER ZE WITH DIAERESIS                                  */
   { 0x38, 0x00, 0x045D }, /* 0x0438 + 0x0300 = 0x045D CYRILLIC SMALL LETTER I WITH GRAVE                                       */
   { 0x38, 0x04, 0x04E3 }, /* 0x0438 + 0x0304 = 0x04E3 CYRILLIC SMALL LETTER I WITH MACRON                                      */
   { 0x38, 0x06, 0x0439 }, /* 0x0438 + 0x0306 = 0x0439 CYRILLIC SMALL LETTER SHORT I                                            */
   { 0x38, 0x08, 0x04E5 }, /* 0x0438 + 0x0308 = 0x04E5 CYRILLIC SMALL LETTER I WITH DIAERESIS                                   */
   { 0x3A, 0x01, 0x045C }, /* 0x043A + 0x0301 = 0x045C CYRILLIC SMALL LETTER KJE                                                */
   { 0x3E, 0x08, 0x04E7 }, /* 0x043E + 0x0308 = 0x04E7 CYRILLIC SMALL LETTER O WITH DIAERESIS                                   */
   { 0x43, 0x04, 0x04EF }, /* 0x0443 + 0x0304 = 0x04EF CYRILLIC SMALL LETTER U WITH MACRON                                      */
   { 0x43, 0x06, 0x045E }, /* 0x0443 + 0x0306 = 0x045E CYRILLIC SMALL LETTER SHORT U                                            */
   { 0x43, 0x08, 0x04F1 }, /* 0x0443 + 0x0308 = 0x04F1 CYRILLIC SMALL LETTER U WITH DIAERESIS                                   */
   { 0x43, 0x0B, 0x04F3 }, /* 0x0443 + 0x030B = 0x04F3 CYRILLIC SMALL LETTER U WITH DOUBLE ACUTE                                */
   { 0x47, 0x08, 0x04F5 }, /* 0x0447 + 0x0308 = 0x04F5 CYRILLIC SMALL LETTER CHE WITH DIAERESIS                                 */
   { 0x4B, 0x08, 0x04F9 }, /* 0x044B + 0x0308 = 0x04F9 CYRILLIC SMALL LETTER YERU WITH DIAERESIS                                */
   { 0x4D, 0x08, 0x04ED }, /* 0x044D + 0x0308 = 0x04ED CYRILLIC SMALL LETTER E WITH DIAERESIS                                   */
   { 0x56, 0x08, 0x0457 }, /* 0x0456 + 0x0308 = 0x0457 CYRILLIC SMALL LETTER YI                                                 */
   { 0x74, 0x0F, 0x0476 }, /* 0x0474 + 0x030F = 0x0476 CYRILLIC CAPITAL LETTER IZHITSA WITH DOUBLE GRAVE ACCENT                 */
   { 0x75, 0x0F, 0x0477 }, /* 0x0475 + 0x030F = 0x0477 CYRILLIC SMALL LETTER IZHITSA WITH DOUBLE GRAVE ACCENT                   */
   { 0xD8, 0x08, 0x04DA }, /* 0x04D8 + 0x0308 = 0x04DA CYRILLIC CAPITAL LETTER SCHWA WITH DIAERESIS                             */
   { 0xD9, 0x08, 0x04DB }, /* 0x04D9 + 0x0308 = 0x04DB CYRILLIC SMALL LETTER SCHWA WITH DIAERESIS                               */
   { 0xE8, 0x08, 0x04EA }, /* 0x04E8 + 0x0308 = 0x04EA CYRILLIC CAPITAL LETTER BARRED O WITH DIAERESIS                          */
   { 0xE9, 0x08, 0x04EB }, /* 0x04E9 + 0x0308 = 0x04EB CYRILLIC SMALL LETTER BARRED O WITH DIAERESIS                            */
   /* --------------- block_06_06 @  637 --------------- */
   { 0x27, 0x53, 0x0622 }, /* 0x0627 + 0x0653 = 0x0622 ARABIC LETTER ALEF WITH MADDA ABOVE                                      */
   { 0x27, 0x54, 0x0623 }, /* 0x0627 + 0x0654 = 0x0623 ARABIC LETTER ALEF WITH HAMZA ABOVE                                      */
   { 0x27, 0x55, 0x0625 }, /* 0x0627 + 0x0655 = 0x0625 ARABIC LETTER ALEF WITH HAMZA BELOW                                      */
   { 0x48, 0x54, 0x0624 }, /* 0x0648 + 0x0654 = 0x0624 ARABIC LETTER WAW WITH HAMZA ABOVE                                       */
   { 0x4A, 0x54, 0x0626 }, /* 0x064A + 0x0654 = 0x0626 ARABIC LETTER YEH WITH HAMZA ABOVE                                       */
   { 0xC1, 0x54, 0x06C2 }, /* 0x06C1 + 0x0654 = 0x06C2 ARABIC LETTER HEH GOAL WITH HAMZA ABOVE                                  */
   { 0xD2, 0x54, 0x06D3 }, /* 0x06D2 + 0x0654 = 0x06D3 ARABIC LETTER YEH BARREE WITH HAMZA ABOVE                                */
   { 0xD5, 0x54, 0x06C0 }, /* 0x06D5 + 0x0654 = 0x06C0 ARABIC LETTER HEH WITH YEH ABOVE                                         */
   /* --------------- block_09_09 @  645 --------------- */
   { 0x28, 0x3C, 0x0929 }, /* 0x0928 + 0x093C = 0x0929 DEVANAGARI LETTER NNNA                                                   */
   { 0x30, 0x3C, 0x0931 }, /* 0x0930 + 0x093C = 0x0931 DEVANAGARI LETTER RRA                                                    */
   { 0x33, 0x3C, 0x0934 }, /* 0x0933 + 0x093C = 0x0934 DEVANAGARI LETTER LLLA                                                   */
   { 0xC7, 0xBE, 0x09CB }, /* 0x09C7 + 0x09BE = 0x09CB BENGALI VOWEL SIGN O                                                     */
   { 0xC7, 0xD7, 0x09CC }, /* 0x09C7 + 0x09D7 = 0x09CC BENGALI VOWEL SIGN AU                                                    */
   /* --------------- block_0B_0B @  650 --------------- */
   { 0x47, 0x3E, 0x0B4B }, /* 0x0B47 + 0x0B3E = 0x0B4B ORIYA VOWEL SIGN O                                                       */
   { 0x47, 0x56, 0x0B48 }, /* 0x0B47 + 0x0B56 = 0x0B48 ORIYA VOWEL SIGN AI                                                      */
   { 0x47, 0x57, 0x0B4C }, /* 0x0B47 + 0x0B57 = 0x0B4C ORIYA VOWEL SIGN AU                                                      */
   { 0x92, 0xD7, 0x0B94 }, /* 0x0B92 + 0x0BD7 = 0x0B94 TAMIL LETTER AU                                                          */
   { 0xC6, 0xBE, 0x0BCA }, /* 0x0BC6 + 0x0BBE = 0x0BCA TAMIL VOWEL SIGN O                                                       */
   { 0xC6, 0xD7, 0x0BCC }, /* 0x0BC6 + 0x0BD7 = 0x0BCC TAMIL VOWEL SIGN AU                                                      */
   { 0xC7, 0xBE, 0x0BCB }, /* 0x0BC7 + 0x0BBE = 0x0BCB TAMIL VOWEL SIGN OO                                                      */
   /* --------------- block_0C_0C @  657 --------------- */
   { 0x46, 0x56, 0x0C48 }, /* 0x0C46 + 0x0C56 = 0x0C48 TELUGU VOWEL SIGN AI                                                     */
   { 0xBF, 0xD5, 0x0CC0 }, /* 0x0CBF + 0x0CD5 = 0x0CC0 KANNADA VOWEL SIGN II                                                    */
   { 0xC6, 0xC2, 0x0CCA }, /* 0x0CC6 + 0x0CC2 = 0x0CCA KANNADA VOWEL SIGN O                                                     */
   { 0xC6, 0xD5, 0x0CC7 }, /* 0x0CC6 + 0x0CD5 = 0x0CC7 KANNADA VOWEL SIGN EE                                                    */
   { 0xC6, 0xD6, 0x0CC8 }, /* 0x0CC6 + 0x0CD6 = 0x0CC8 KANNADA VOWEL SIGN AI                                                    */
   { 0xCA, 0xD5, 0x0CCB }, /* 0x0CCA + 0x0CD5 = 0x0CCB KANNADA VOWEL SIGN OO                                                    */
   /* --------------- block_0D_0D @  663 --------------- */
   { 0x46, 0x3E, 0x0D4A }, /* 0x0D46 + 0x0D3E = 0x0D4A MALAYALAM VOWEL SIGN O                                                   */
   { 0x46, 0x57, 0x0D4C }, /* 0x0D46 + 0x0D57 = 0x0D4C MALAYALAM VOWEL SIGN AU                                                  */
   { 0x47, 0x3E, 0x0D4B }, /* 0x0D47 + 0x0D3E = 0x0D4B MALAYALAM VOWEL SIGN OO                                                  */
   { 0xD9, 0xCA, 0x0DDA }, /* 0x0DD9 + 0x0DCA = 0x0DDA SINHALA VOWEL SIGN DIGA KOMBUVA                                          */
   { 0xD9, 0xCF, 0x0DDC }, /* 0x0DD9 + 0x0DCF = 0x0DDC SINHALA VOWEL SIGN KOMBUVA HAA AELA-PILLA                                */
   { 0xD9, 0xDF, 0x0DDE }, /* 0x0DD9 + 0x0DDF = 0x0DDE SINHALA VOWEL SIGN KOMBUVA HAA GAYANUKITTA                               */
   { 0xDC, 0xCA, 0x0DDD }, /* 0x0DDC + 0x0DCA = 0x0DDD SINHALA VOWEL SIGN KOMBUVA HAA DIGA AELA-PILLA                           */
   /* --------------- block_10_10 @  670 --------------- */
   { 0x25, 0x2E, 0x1026 }, /* 0x1025 + 0x102E = 0x1026 MYANMAR LETTER UU                                                        */
   /* --------------- block_1B_1B @  671 --------------- */
   { 0x05, 0x35, 0x1B06 }, /* 0x1B05 + 0x1B35 = 0x1B06 BALINESE LETTER AKARA TEDUNG                                             */
   { 0x07, 0x35, 0x1B08 }, /* 0x1B07 + 0x1B35 = 0x1B08 BALINESE LETTER IKARA TEDUNG                                             */
   { 0x09, 0x35, 0x1B0A }, /* 0x1B09 + 0x1B35 = 0x1B0A BALINESE LETTER UKARA TEDUNG                                             */
   { 0x0B, 0x35, 0x1B0C }, /* 0x1B0B + 0x1B35 = 0x1B0C BALINESE LETTER RA REPA TEDUNG                                           */
   { 0x0D, 0x35, 0x1B0E }, /* 0x1B0D + 0x1B35 = 0x1B0E BALINESE LETTER LA LENGA TEDUNG                                          */
   { 0x11, 0x35, 0x1B12 }, /* 0x1B11 + 0x1B35 = 0x1B12 BALINESE LETTER OKARA TEDUNG                                             */
   { 0x3A, 0x35, 0x1B3B }, /* 0x1B3A + 0x1B35 = 0x1B3B BALINESE VOWEL SIGN RA REPA TEDUNG                                       */
   { 0x3C, 0x35, 0x1B3D }, /* 0x1B3C + 0x1B35 = 0x1B3D BALINESE VOWEL SIGN LA LENGA TEDUNG                                      */
   { 0x3E, 0x35, 0x1B40 }, /* 0x1B3E + 0x1B35 = 0x1B40 BALINESE VOWEL SIGN TALING TEDUNG                                        */
   { 0x3F, 0x35, 0x1B41 }, /* 0x1B3F + 0x1B35 = 0x1B41 BALINESE VOWEL SIGN TALING REPA TEDUNG                                   */
   { 0x42, 0x35, 0x1B43 }, /* 0x1B42 + 0x1B35 = 0x1B43 BALINESE VOWEL SIGN PEPET TEDUNG                                         */
   /* --------------- block_1E_03 @  682 --------------- */
   { 0x36, 0x04, 0x1E38 }, /* 0x1E36 + 0x0304 = 0x1E38 LATIN CAPITAL LETTER L WITH DOT BELOW AND MACRON                         */
   { 0x37, 0x04, 0x1E39 }, /* 0x1E37 + 0x0304 = 0x1E39 LATIN SMALL LETTER L WITH DOT BELOW AND MACRON                           */
   { 0x5A, 0x04, 0x1E5C }, /* 0x1E5A + 0x0304 = 0x1E5C LATIN CAPITAL LETTER R WITH DOT BELOW AND MACRON                         */
   { 0x5B, 0x04, 0x1E5D }, /* 0x1E5B + 0x0304 = 0x1E5D LATIN SMALL LETTER R WITH DOT BELOW AND MACRON                           */
   { 0x62, 0x07, 0x1E68 }, /* 0x1E62 + 0x0307 = 0x1E68 LATIN CAPITAL LETTER S WITH DOT BELOW AND DOT ABOVE                      */
   { 0x63, 0x07, 0x1E69 }, /* 0x1E63 + 0x0307 = 0x1E69 LATIN SMALL LETTER S WITH DOT BELOW AND DOT ABOVE                        */
   { 0xA0, 0x02, 0x1EAC }, /* 0x1EA0 + 0x0302 = 0x1EAC LATIN CAPITAL LETTER A WITH CIRCUMFLEX AND DOT BELOW                     */
   { 0xA0, 0x06, 0x1EB6 }, /* 0x1EA0 + 0x0306 = 0x1EB6 LATIN CAPITAL LETTER A WITH BREVE AND DOT BELOW                          */
   { 0xA1, 0x02, 0x1EAD }, /* 0x1EA1 + 0x0302 = 0x1EAD LATIN SMALL LETTER A WITH CIRCUMFLEX AND DOT BELOW                       */
   { 0xA1, 0x06, 0x1EB7 }, /* 0x1EA1 + 0x0306 = 0x1EB7 LATIN SMALL LETTER A WITH BREVE AND DOT BELOW                            */
   { 0xB8, 0x02, 0x1EC6 }, /* 0x1EB8 + 0x0302 = 0x1EC6 LATIN CAPITAL LETTER E WITH CIRCUMFLEX AND DOT BELOW                     */
   { 0xB9, 0x02, 0x1EC7 }, /* 0x1EB9 + 0x0302 = 0x1EC7 LATIN SMALL LETTER E WITH CIRCUMFLEX AND DOT BELOW                       */
   { 0xCC, 0x02, 0x1ED8 }, /* 0x1ECC + 0x0302 = 0x1ED8 LATIN CAPITAL LETTER O WITH CIRCUMFLEX AND DOT BELOW                     */
   { 0xCD, 0x02, 0x1ED9 }, /* 0x1ECD + 0x0302 = 0x1ED9 LATIN SMALL LETTER O WITH CIRCUMFLEX AND DOT BELOW                       */
   /* --------------- block_1F_03 @  696 --------------- */
   { 0x00, 0x00, 0x1F02 }, /* 0x1F00 + 0x0300 = 0x1F02 GREEK SMALL LETTER ALPHA WITH PSILI AND VARIA                            */
   { 0x00, 0x01, 0x1F04 }, /* 0x1F00 + 0x0301 = 0x1F04 GREEK SMALL LETTER ALPHA WITH PSILI AND OXIA                             */
   { 0x00, 0x42, 0x1F06 }, /* 0x1F00 + 0x0342 = 0x1F06 GREEK SMALL LETTER ALPHA WITH PSILI AND PERISPOMENI                      */
   { 0x00, 0x45, 0x1F80 }, /* 0x1F00 + 0x0345 = 0x1F80 GREEK SMALL LETTER ALPHA WITH PSILI AND YPOGEGRAMMENI                    */
   { 0x01, 0x00, 0x1F03 }, /* 0x1F01 + 0x0300 = 0x1F03 GREEK SMALL LETTER ALPHA WITH DASIA AND VARIA                            */
   { 0x01, 0x01, 0x1F05 }, /* 0x1F01 + 0x0301 = 0x1F05 GREEK SMALL LETTER ALPHA WITH DASIA AND OXIA                             */
   { 0x01, 0x42, 0x1F07 }, /* 0x1F01 + 0x0342 = 0x1F07 GREEK SMALL LETTER ALPHA WITH DASIA AND PERISPOMENI                      */
   { 0x01, 0x45, 0x1F81 }, /* 0x1F01 + 0x0345 = 0x1F81 GREEK SMALL LETTER ALPHA WITH DASIA AND YPOGEGRAMMENI                    */
   { 0x02, 0x45, 0x1F82 }, /* 0x1F02 + 0x0345 = 0x1F82 GREEK SMALL LETTER ALPHA WITH PSILI AND VARIA AND YPOGEGRAMMENI          */
   { 0x03, 0x45, 0x1F83 }, /* 0x1F03 + 0x0345 = 0x1F83 GREEK SMALL LETTER ALPHA WITH DASIA AND VARIA AND YPOGEGRAMMENI          */
   { 0x04, 0x45, 0x1F84 }, /* 0x1F04 + 0x0345 = 0x1F84 GREEK SMALL LETTER ALPHA WITH PSILI AND OXIA AND YPOGEGRAMMENI           */
   { 0x05, 0x45, 0x1F85 }, /* 0x1F05 + 0x0345 = 0x1F85 GREEK SMALL LETTER ALPHA WITH DASIA AND OXIA AND YPOGEGRAMMENI           */
   { 0x06, 0x45, 0x1F86 }, /* 0x1F06 + 0x0345 = 0x1F86 GREEK SMALL LETTER ALPHA WITH PSILI AND PERISPOMENI AND YPOGEGRAMMENI    */
   { 0x07, 0x45, 0x1F87 }, /* 0x1F07 + 0x0345 = 0x1F87 GREEK SMALL LETTER ALPHA WITH DASIA AND PERISPOMENI AND YPOGEGRAMMENI    */
   { 0x08, 0x00, 0x1F0A }, /* 0x1F08 + 0x0300 = 0x1F0A GREEK CAPITAL LETTER ALPHA WITH PSILI AND VARIA                          */
   { 0x08, 0x01, 0x1F0C }, /* 0x1F08 + 0x0301 = 0x1F0C GREEK CAPITAL LETTER ALPHA WITH PSILI AND OXIA                           */
   { 0x08, 0x42, 0x1F0E }, /* 0x1F08 + 0x0342 = 0x1F0E GREEK CAPITAL LETTER ALPHA WITH PSILI AND PERISPOMENI                    */
   { 0x08, 0x45, 0x1F88 }, /* 0x1F08 + 0x0345 = 0x1F88 GREEK CAPITAL LETTER ALPHA WITH PSILI AND PROSGEGRAMMENI                 */
   { 0x09, 0x00, 0x1F0B }, /* 0x1F09 + 0x0300 = 0x1F0B GREEK CAPITAL LETTER ALPHA WITH DASIA AND VARIA                          */
   { 0x09, 0x01, 0x1F0D }, /* 0x1F09 + 0x0301 = 0x1F0D GREEK CAPITAL LETTER ALPHA WITH DASIA AND OXIA                           */
   { 0x09, 0x42, 0x1F0F }, /* 0x1F09 + 0x0342 = 0x1F0F GREEK CAPITAL LETTER ALPHA WITH DASIA AND PERISPOMENI                    */
   { 0x09, 0x45, 0x1F89 }, /* 0x1F09 + 0x0345 = 0x1F89 GREEK CAPITAL LETTER ALPHA WITH DASIA AND PROSGEGRAMMENI                 */
   { 0x0A, 0x45, 0x1F8A }, /* 0x1F0A + 0x0345 = 0x1F8A GREEK CAPITAL LETTER ALPHA WITH PSILI AND VARIA AND PROSGEGRAMMENI       */
   { 0x0B, 0x45, 0x1F8B }, /* 0x1F0B + 0x0345 = 0x1F8B GREEK CAPITAL LETTER ALPHA WITH DASIA AND VARIA AND PROSGEGRAMMENI       */
   { 0x0C, 0x45, 0x1F8C }, /* 0x1F0C + 0x0345 = 0x1F8C GREEK CAPITAL LETTER ALPHA WITH PSILI AND OXIA AND PROSGEGRAMMENI        */
   { 0x0D, 0x45, 0x1F8D }, /* 0x1F0D + 0x0345 = 0x1F8D GREEK CAPITAL LETTER ALPHA WITH DASIA AND OXIA AND PROSGEGRAMMENI        */
   { 0x0E, 0x45, 0x1F8E }, /* 0x1F0E + 0x0345 = 0x1F8E GREEK CAPITAL LETTER ALPHA WITH PSILI AND PERISPOMENI AND PROSGEGRAMMENI */
   { 0x0F, 0x45, 0x1F8F }, /* 0x1F0F + 0x0345 = 0x1F8F GREEK CAPITAL LETTER ALPHA WITH DASIA AND PERISPOMENI AND PROSGEGRAMMENI */
   { 0x10, 0x00, 0x1F12 }, /* 0x1F10 + 0x0300 = 0x1F12 GREEK SMALL LETTER EPSILON WITH PSILI AND VARIA                          */
   { 0x10, 0x01, 0x1F14 }, /* 0x1F10 + 0x0301 = 0x1F14 GREEK SMALL LETTER EPSILON WITH PSILI AND OXIA                           */
   { 0x11, 0x00, 0x1F13 }, /* 0x1F11 + 0x0300 = 0x1F13 GREEK SMALL LETTER EPSILON WITH DASIA AND VARIA                          */
   { 0x11, 0x01, 0x1F15 }, /* 0x1F11 + 0x0301 = 0x1F15 GREEK SMALL LETTER EPSILON WITH DASIA AND OXIA                           */
   { 0x18, 0x00, 0x1F1A }, /* 0x1F18 + 0x0300 = 0x1F1A GREEK CAPITAL LETTER EPSILON WITH PSILI AND VARIA                        */
   { 0x18, 0x01, 0x1F1C }, /* 0x1F18 + 0x0301 = 0x1F1C GREEK CAPITAL LETTER EPSILON WITH PSILI AND OXIA                         */
   { 0x19, 0x00, 0x1F1B }, /* 0x1F19 + 0x0300 = 0x1F1B GREEK CAPITAL LETTER EPSILON WITH DASIA AND VARIA                        */
   { 0x19, 0x01, 0x1F1D }, /* 0x1F19 + 0x0301 = 0x1F1D GREEK CAPITAL LETTER EPSILON WITH DASIA AND OXIA                         */
   { 0x20, 0x00, 0x1F22 }, /* 0x1F20 + 0x0300 = 0x1F22 GREEK SMALL LETTER ETA WITH PSILI AND VARIA                              */
   { 0x20, 0x01, 0x1F24 }, /* 0x1F20 + 0x0301 = 0x1F24 GREEK SMALL LETTER ETA WITH PSILI AND OXIA                               */
   { 0x20, 0x42, 0x1F26 }, /* 0x1F20 + 0x0342 = 0x1F26 GREEK SMALL LETTER ETA WITH PSILI AND PERISPOMENI                        */
   { 0x20, 0x45, 0x1F90 }, /* 0x1F20 + 0x0345 = 0x1F90 GREEK SMALL LETTER ETA WITH PSILI AND YPOGEGRAMMENI                      */
   { 0x21, 0x00, 0x1F23 }, /* 0x1F21 + 0x0300 = 0x1F23 GREEK SMALL LETTER ETA WITH DASIA AND VARIA                              */
   { 0x21, 0x01, 0x1F25 }, /* 0x1F21 + 0x0301 = 0x1F25 GREEK SMALL LETTER ETA WITH DASIA AND OXIA                               */
   { 0x21, 0x42, 0x1F27 }, /* 0x1F21 + 0x0342 = 0x1F27 GREEK SMALL LETTER ETA WITH DASIA AND PERISPOMENI                        */
   { 0x21, 0x45, 0x1F91 }, /* 0x1F21 + 0x0345 = 0x1F91 GREEK SMALL LETTER ETA WITH DASIA AND YPOGEGRAMMENI                      */
   { 0x22, 0x45, 0x1F92 }, /* 0x1F22 + 0x0345 = 0x1F92 GREEK SMALL LETTER ETA WITH PSILI AND VARIA AND YPOGEGRAMMENI            */
   { 0x23, 0x45, 0x1F93 }, /* 0x1F23 + 0x0345 = 0x1F93 GREEK SMALL LETTER ETA WITH DASIA AND VARIA AND YPOGEGRAMMENI            */
   { 0x24, 0x45, 0x1F94 }, /* 0x1F24 + 0x0345 = 0x1F94 GREEK SMALL LETTER ETA WITH PSILI AND OXIA AND YPOGEGRAMMENI             */
   { 0x25, 0x45, 0x1F95 }, /* 0x1F25 + 0x0345 = 0x1F95 GREEK SMALL LETTER ETA WITH DASIA AND OXIA AND YPOGEGRAMMENI             */
   { 0x26, 0x45, 0x1F96 }, /* 0x1F26 + 0x0345 = 0x1F96 GREEK SMALL LETTER ETA WITH PSILI AND PERISPOMENI AND YPOGEGRAMMENI      */
   { 0x27, 0x45, 0x1F97 }, /* 0x1F27 + 0x0345 = 0x1F97 GREEK SMALL LETTER ETA WITH DASIA AND PERISPOMENI AND YPOGEGRAMMENI      */
   { 0x28, 0x00, 0x1F2A }, /* 0x1F28 + 0x0300 = 0x1F2A GREEK CAPITAL LETTER ETA WITH PSILI AND VARIA                            */
   { 0x28, 0x01, 0x1F2C }, /* 0x1F28 + 0x0301 = 0x1F2C GREEK CAPITAL LETTER ETA WITH PSILI AND OXIA                             */
   { 0x28, 0x42, 0x1F2E }, /* 0x1F28 + 0x0342 = 0x1F2E GREEK CAPITAL LETTER ETA WITH PSILI AND PERISPOMENI                      */
   { 0x28, 0x45, 0x1F98 }, /* 0x1F28 + 0x0345 = 0x1F98 GREEK CAPITAL LETTER ETA WITH PSILI AND PROSGEGRAMMENI                   */
   { 0x29, 0x00, 0x1F2B }, /* 0x1F29 + 0x0300 = 0x1F2B GREEK CAPITAL LETTER ETA WITH DASIA AND VARIA                            */
   { 0x29, 0x01, 0x1F2D }, /* 0x1F29 + 0x0301 = 0x1F2D GREEK CAPITAL LETTER ETA WITH DASIA AND OXIA                             */
   { 0x29, 0x42, 0x1F2F }, /* 0x1F29 + 0x0342 = 0x1F2F GREEK CAPITAL LETTER ETA WITH DASIA AND PERISPOMENI                      */
   { 0x29, 0x45, 0x1F99 }, /* 0x1F29 + 0x0345 = 0x1F99 GREEK CAPITAL LETTER ETA WITH DASIA AND PROSGEGRAMMENI                   */
   { 0x2A, 0x45, 0x1F9A }, /* 0x1F2A + 0x0345 = 0x1F9A GREEK CAPITAL LETTER ETA WITH PSILI AND VARIA AND PROSGEGRAMMENI         */
   { 0x2B, 0x45, 0x1F9B }, /* 0x1F2B + 0x0345 = 0x1F9B GREEK CAPITAL LETTER ETA WITH DASIA AND VARIA AND PROSGEGRAMMENI         */
   { 0x2C, 0x45, 0x1F9C }, /* 0x1F2C + 0x0345 = 0x1F9C GREEK CAPITAL LETTER ETA WITH PSILI AND OXIA AND PROSGEGRAMMENI          */
   { 0x2D, 0x45, 0x1F9D }, /* 0x1F2D + 0x0345 = 0x1F9D GREEK CAPITAL LETTER ETA WITH DASIA AND OXIA AND PROSGEGRAMMENI          */
   { 0x2E, 0x45, 0x1F9E }, /* 0x1F2E + 0x0345 = 0x1F9E GREEK CAPITAL LETTER ETA WITH PSILI AND PERISPOMENI AND PROSGEGRAMMENI   */
   { 0x2F, 0x45, 0x1F9F }, /* 0x1F2F + 0x0345 = 0x1F9F GREEK CAPITAL LETTER ETA WITH DASIA AND PERISPOMENI AND PROSGEGRAMMENI   */
   { 0x30, 0x00, 0x1F32 }, /* 0x1F30 + 0x0300 = 0x1F32 GREEK SMALL LETTER IOTA WITH PSILI AND VARIA                             */
   { 0x30, 0x01, 0x1F34 }, /* 0x1F30 + 0x0301 = 0x1F34 GREEK SMALL LETTER IOTA WITH PSILI AND OXIA                              */
   { 0x30, 0x42, 0x1F36 }, /* 0x1F30 + 0x0342 = 0x1F36 GREEK SMALL LETTER IOTA WITH PSILI AND PERISPOMENI                       */
   { 0x31, 0x00, 0x1F33 }, /* 0x1F31 + 0x0300 = 0x1F33 GREEK SMALL LETTER IOTA WITH DASIA AND VARIA                             */
   { 0x31, 0x01, 0x1F35 }, /* 0x1F31 + 0x0301 = 0x1F35 GREEK SMALL LETTER IOTA WITH DASIA AND OXIA                              */
   { 0x31, 0x42, 0x1F37 }, /* 0x1F31 + 0x0342 = 0x1F37 GREEK SMALL LETTER IOTA WITH DASIA AND PERISPOMENI                       */
   { 0x38, 0x00, 0x1F3A }, /* 0x1F38 + 0x0300 = 0x1F3A GREEK CAPITAL LETTER IOTA WITH PSILI AND VARIA                           */
   { 0x38, 0x01, 0x1F3C }, /* 0x1F38 + 0x0301 = 0x1F3C GREEK CAPITAL LETTER IOTA WITH PSILI AND OXIA                            */
   { 0x38, 0x42, 0x1F3E }, /* 0x1F38 + 0x0342 = 0x1F3E GREEK CAPITAL LETTER IOTA WITH PSILI AND PERISPOMENI                     */
   { 0x39, 0x00, 0x1F3B }, /* 0x1F39 + 0x0300 = 0x1F3B GREEK CAPITAL LETTER IOTA WITH DASIA AND VARIA                           */
   { 0x39, 0x01, 0x1F3D }, /* 0x1F39 + 0x0301 = 0x1F3D GREEK CAPITAL LETTER IOTA WITH DASIA AND OXIA                            */
   { 0x39, 0x42, 0x1F3F }, /* 0x1F39 + 0x0342 = 0x1F3F GREEK CAPITAL LETTER IOTA WITH DASIA AND PERISPOMENI                     */
   { 0x40, 0x00, 0x1F42 }, /* 0x1F40 + 0x0300 = 0x1F42 GREEK SMALL LETTER OMICRON WITH PSILI AND VARIA                          */
   { 0x40, 0x01, 0x1F44 }, /* 0x1F40 + 0x0301 = 0x1F44 GREEK SMALL LETTER OMICRON WITH PSILI AND OXIA                           */
   { 0x41, 0x00, 0x1F43 }, /* 0x1F41 + 0x0300 = 0x1F43 GREEK SMALL LETTER OMICRON WITH DASIA AND VARIA                          */
   { 0x41, 0x01, 0x1F45 }, /* 0x1F41 + 0x0301 = 0x1F45 GREEK SMALL LETTER OMICRON WITH DASIA AND OXIA                           */
   { 0x48, 0x00, 0x1F4A }, /* 0x1F48 + 0x0300 = 0x1F4A GREEK CAPITAL LETTER OMICRON WITH PSILI AND VARIA                        */
   { 0x48, 0x01, 0x1F4C }, /* 0x1F48 + 0x0301 = 0x1F4C GREEK CAPITAL LETTER OMICRON WITH PSILI AND OXIA                         */
   { 0x49, 0x00, 0x1F4B }, /* 0x1F49 + 0x0300 = 0x1F4B GREEK CAPITAL LETTER OMICRON WITH DASIA AND VARIA                        */
   { 0x49, 0x01, 0x1F4D }, /* 0x1F49 + 0x0301 = 0x1F4D GREEK CAPITAL LETTER OMICRON WITH DASIA AND OXIA                         */
   { 0x50, 0x00, 0x1F52 }, /* 0x1F50 + 0x0300 = 0x1F52 GREEK SMALL LETTER UPSILON WITH PSILI AND VARIA                          */
   { 0x50, 0x01, 0x1F54 }, /* 0x1F50 + 0x0301 = 0x1F54 GREEK SMALL LETTER UPSILON WITH PSILI AND OXIA                           */
   { 0x50, 0x42, 0x1F56 }, /* 0x1F50 + 0x0342 = 0x1F56 GREEK SMALL LETTER UPSILON WITH PSILI AND PERISPOMENI                    */
   { 0x51, 0x00, 0x1F53 }, /* 0x1F51 + 0x0300 = 0x1F53 GREEK SMALL LETTER UPSILON WITH DASIA AND VARIA                          */
   { 0x51, 0x01, 0x1F55 }, /* 0x1F51 + 0x0301 = 0x1F55 GREEK SMALL LETTER UPSILON WITH DASIA AND OXIA                           */
   { 0x51, 0x42, 0x1F57 }, /* 0x1F51 + 0x0342 = 0x1F57 GREEK SMALL LETTER UPSILON WITH DASIA AND PERISPOMENI                    */
   { 0x59, 0x00, 0x1F5B }, /* 0x1F59 + 0x0300 = 0x1F5B GREEK CAPITAL LETTER UPSILON WITH DASIA AND VARIA                        */
   { 0x59, 0x01, 0x1F5D }, /* 0x1F59 + 0x0301 = 0x1F5D GREEK CAPITAL LETTER UPSILON WITH DASIA AND OXIA                         */
   { 0x59, 0x42, 0x1F5F }, /* 0x1F59 + 0x0342 = 0x1F5F GREEK CAPITAL LETTER UPSILON WITH DASIA AND PERISPOMENI                  */
   { 0x60, 0x00, 0x1F62 }, /* 0x1F60 + 0x0300 = 0x1F62 GREEK SMALL LETTER OMEGA WITH PSILI AND VARIA                            */
   { 0x60, 0x01, 0x1F64 }, /* 0x1F60 + 0x0301 = 0x1F64 GREEK SMALL LETTER OMEGA WITH PSILI AND OXIA                             */
   { 0x60, 0x42, 0x1F66 }, /* 0x1F60 + 0x0342 = 0x1F66 GREEK SMALL LETTER OMEGA WITH PSILI AND PERISPOMENI                      */
   { 0x60, 0x45, 0x1FA0 }, /* 0x1F60 + 0x0345 = 0x1FA0 GREEK SMALL LETTER OMEGA WITH PSILI AND YPOGEGRAMMENI                    */
   { 0x61, 0x00, 0x1F63 }, /* 0x1F61 + 0x0300 = 0x1F63 GREEK SMALL LETTER OMEGA WITH DASIA AND VARIA                            */
   { 0x61, 0x01, 0x1F65 }, /* 0x1F61 + 0x0301 = 0x1F65 GREEK SMALL LETTER OMEGA WITH DASIA AND OXIA                             */
   { 0x61, 0x42, 0x1F67 }, /* 0x1F61 + 0x0342 = 0x1F67 GREEK SMALL LETTER OMEGA WITH DASIA AND PERISPOMENI                      */
   { 0x61, 0x45, 0x1FA1 }, /* 0x1F61 + 0x0345 = 0x1FA1 GREEK SMALL LETTER OMEGA WITH DASIA AND YPOGEGRAMMENI                    */
   { 0x62, 0x45, 0x1FA2 }, /* 0x1F62 + 0x0345 = 0x1FA2 GREEK SMALL LETTER OMEGA WITH PSILI AND VARIA AND YPOGEGRAMMENI          */
   { 0x63, 0x45, 0x1FA3 }, /* 0x1F63 + 0x0345 = 0x1FA3 GREEK SMALL LETTER OMEGA WITH DASIA AND VARIA AND YPOGEGRAMMENI          */
   { 0x64, 0x45, 0x1FA4 }, /* 0x1F64 + 0x0345 = 0x1FA4 GREEK SMALL LETTER OMEGA WITH PSILI AND OXIA AND YPOGEGRAMMENI           */
   { 0x65, 0x45, 0x1FA5 }, /* 0x1F65 + 0x0345 = 0x1FA5 GREEK SMALL LETTER OMEGA WITH DASIA AND OXIA AND YPOGEGRAMMENI           */
   { 0x66, 0x45, 0x1FA6 }, /* 0x1F66 + 0x0345 = 0x1FA6 GREEK SMALL LETTER OMEGA WITH PSILI AND PERISPOMENI AND YPOGEGRAMMENI    */
   { 0x67, 0x45, 0x1FA7 }, /* 0x1F67 + 0x0345 = 0x1FA7 GREEK SMALL LETTER OMEGA WITH DASIA AND PERISPOMENI AND YPOGEGRAMMENI    */
   { 0x68, 0x00, 0x1F6A }, /* 0x1F68 + 0x0300 = 0x1F6A GREEK CAPITAL LETTER OMEGA WITH PSILI AND VARIA                          */
   { 0x68, 0x01, 0x1F6C }, /* 0x1F68 + 0x0301 = 0x1F6C GREEK CAPITAL LETTER OMEGA WITH PSILI AND OXIA                           */
   { 0x68, 0x42, 0x1F6E }, /* 0x1F68 + 0x0342 = 0x1F6E GREEK CAPITAL LETTER OMEGA WITH PSILI AND PERISPOMENI                    */
   { 0x68, 0x45, 0x1FA8 }, /* 0x1F68 + 0x0345 = 0x1FA8 GREEK CAPITAL LETTER OMEGA WITH PSILI AND PROSGEGRAMMENI                 */
   { 0x69, 0x00, 0x1F6B }, /* 0x1F69 + 0x0300 = 0x1F6B GREEK CAPITAL LETTER OMEGA WITH DASIA AND VARIA                          */
   { 0x69, 0x01, 0x1F6D }, /* 0x1F69 + 0x0301 = 0x1F6D GREEK CAPITAL LETTER OMEGA WITH DASIA AND OXIA                           */
   { 0x69, 0x42, 0x1F6F }, /* 0x1F69 + 0x0342 = 0x1F6F GREEK CAPITAL LETTER OMEGA WITH DASIA AND PERISPOMENI                    */
   { 0x69, 0x45, 0x1FA9 }, /* 0x1F69 + 0x0345 = 0x1FA9 GREEK CAPITAL LETTER OMEGA WITH DASIA AND PROSGEGRAMMENI                 */
   { 0x6A, 0x45, 0x1FAA }, /* 0x1F6A + 0x0345 = 0x1FAA GREEK CAPITAL LETTER OMEGA WITH PSILI AND VARIA AND PROSGEGRAMMENI       */
   { 0x6B, 0x45, 0x1FAB }, /* 0x1F6B + 0x0345 = 0x1FAB GREEK CAPITAL LETTER OMEGA WITH DASIA AND VARIA AND PROSGEGRAMMENI       */
   { 0x6C, 0x45, 0x1FAC }, /* 0x1F6C + 0x0345 = 0x1FAC GREEK CAPITAL LETTER OMEGA WITH PSILI AND OXIA AND PROSGEGRAMMENI        */
   { 0x6D, 0x45, 0x1FAD }, /* 0x1F6D + 0x0345 = 0x1FAD GREEK CAPITAL LETTER OMEGA WITH DASIA AND OXIA AND PROSGEGRAMMENI        */
   { 0x6E, 0x45, 0x1FAE }, /* 0x1F6E + 0x0345 = 0x1FAE GREEK CAPITAL LETTER OMEGA WITH PSILI AND PERISPOMENI AND PROSGEGRAMMENI */
   { 0x6F, 0x45, 0x1FAF }, /* 0x1F6F + 0x0345 = 0x1FAF GREEK CAPITAL LETTER OMEGA WITH DASIA AND PERISPOMENI AND PROSGEGRAMMENI */
   { 0x70, 0x45, 0x1FB2 }, /* 0x1F70 + 0x0345 = 0x1FB2 GREEK SMALL LETTER ALPHA WITH VARIA AND YPOGEGRAMMENI                    */
   { 0x74, 0x45, 0x1FC2 }, /* 0x1F74 + 0x0345 = 0x1FC2 GREEK SMALL LETTER ETA WITH VARIA AND YPOGEGRAMMENI                      */
   { 0x7C, 0x45, 0x1FF2 }, /* 0x1F7C + 0x0345 = 0x1FF2 GREEK SMALL LETTER OMEGA WITH VARIA AND YPOGEGRAMMENI                    */
   { 0xB6, 0x45, 0x1FB7 }, /* 0x1FB6 + 0x0345 = 0x1FB7 GREEK SMALL LETTER ALPHA WITH PERISPOMENI AND YPOGEGRAMMENI              */
   { 0xBF, 0x00, 0x1FCD }, /* 0x1FBF + 0x0300 = 0x1FCD GREEK PSILI AND VARIA                                                    */
   { 0xBF, 0x01, 0x1FCE }, /* 0x1FBF + 0x0301 = 0x1FCE GREEK PSILI AND OXIA                                                     */
   { 0xBF, 0x42, 0x1FCF }, /* 0x1FBF + 0x0342 = 0x1FCF GREEK PSILI AND PERISPOMENI                                              */
   { 0xC6, 0x45, 0x1FC7 }, /* 0x1FC6 + 0x0345 = 0x1FC7 GREEK SMALL LETTER ETA WITH PERISPOMENI AND YPOGEGRAMMENI                */
   { 0xF6, 0x45, 0x1FF7 }, /* 0x1FF6 + 0x0345 = 0x1FF7 GREEK SMALL LETTER OMEGA WITH PERISPOMENI AND YPOGEGRAMMENI              */
   { 0xFE, 0x00, 0x1FDD }, /* 0x1FFE + 0x0300 = 0x1FDD GREEK DASIA AND VARIA                                                    */
   { 0xFE, 0x01, 0x1FDE }, /* 0x1FFE + 0x0301 = 0x1FDE GREEK DASIA AND OXIA                                                     */
   { 0xFE, 0x42, 0x1FDF }, /* 0x1FFE + 0x0342 = 0x1FDF GREEK DASIA AND PERISPOMENI                                              */
   /* --------------- block_21_03 @  829 --------------- */
   { 0x90, 0x38, 0x219A }, /* 0x2190 + 0x0338 = 0x219A LEFTWARDS ARROW WITH STROKE                                              */
   { 0x92, 0x38, 0x219B }, /* 0x2192 + 0x0338 = 0x219B RIGHTWARDS ARROW WITH STROKE                                             */
   { 0x94, 0x38, 0x21AE }, /* 0x2194 + 0x0338 = 0x21AE LEFT RIGHT ARROW WITH STROKE                                             */
   { 0xD0, 0x38, 0x21CD }, /* 0x21D0 + 0x0338 = 0x21CD LEFTWARDS DOUBLE ARROW WITH STROKE                                       */
   { 0xD2, 0x38, 0x21CF }, /* 0x21D2 + 0x0338 = 0x21CF RIGHTWARDS DOUBLE ARROW WITH STROKE                                      */
   { 0xD4, 0x38, 0x21CE }, /* 0x21D4 + 0x0338 = 0x21CE LEFT RIGHT DOUBLE ARROW WITH STROKE                                      */
   /* --------------- block_22_03 @  835 --------------- */
   { 0x03, 0x38, 0x2204 }, /* 0x2203 + 0x0338 = 0x2204 THERE DOES NOT EXIST                                                     */
   { 0x08, 0x38, 0x2209 }, /* 0x2208 + 0x0338 = 0x2209 NOT AN ELEMENT OF                                                        */
   { 0x0B, 0x38, 0x220C }, /* 0x220B + 0x0338 = 0x220C DOES NOT CONTAIN AS MEMBER                                               */
   { 0x23, 0x38, 0x2224 }, /* 0x2223 + 0x0338 = 0x2224 DOES NOT DIVIDE                                                          */
   { 0x25, 0x38, 0x2226 }, /* 0x2225 + 0x0338 = 0x2226 NOT PARALLEL TO                                                          */
   { 0x3C, 0x38, 0x2241 }, /* 0x223C + 0x0338 = 0x2241 NOT TILDE                                                                */
   { 0x43, 0x38, 0x2244 }, /* 0x2243 + 0x0338 = 0x2244 NOT ASYMPTOTICALLY EQUAL TO                                              */
   { 0x45, 0x38, 0x2247 }, /* 0x2245 + 0x0338 = 0x2247 NEITHER APPROXIMATELY NOR ACTUALLY EQUAL TO                              */
   { 0x48, 0x38, 0x2249 }, /* 0x2248 + 0x0338 = 0x2249 NOT ALMOST EQUAL TO                                                      */
   { 0x4D, 0x38, 0x226D }, /* 0x224D + 0x0338 = 0x226D NOT EQUIVALENT TO                                                        */
   { 0x61, 0x38, 0x2262 }, /* 0x2261 + 0x0338 = 0x2262 NOT IDENTICAL TO                                                         */
   { 0x64, 0x38, 0x2270 }, /* 0x2264 + 0x0338 = 0x2270 NEITHER LESS-THAN NOR EQUAL TO                                           */
   { 0x65, 0x38, 0x2271 }, /* 0x2265 + 0x0338 = 0x2271 NEITHER GREATER-THAN NOR EQUAL TO                                        */
   { 0x72, 0x38, 0x2274 }, /* 0x2272 + 0x0338 = 0x2274 NEITHER LESS-THAN NOR EQUIVALENT TO                                      */
   { 0x73, 0x38, 0x2275 }, /* 0x2273 + 0x0338 = 0x2275 NEITHER GREATER-THAN NOR EQUIVALENT TO                                   */
   { 0x76, 0x38, 0x2278 }, /* 0x2276 + 0x0338 = 0x2278 NEITHER LESS-THAN NOR GREATER-THAN                                       */
   { 0x77, 0x38, 0x2279 }, /* 0x2277 + 0x0338 = 0x2279 NEITHER GREATER-THAN NOR LESS-THAN                                       */
   { 0x7A, 0x38, 0x2280 }, /* 0x227A + 0x0338 = 0x2280 DOES NOT PRECEDE                                                         */
   { 0x7B, 0x38, 0x2281 }, /* 0x227B + 0x0338 = 0x2281 DOES NOT SUCCEED                                                         */
   { 0x7C, 0x38, 0x22E0 }, /* 0x227C + 0x0338 = 0x22E0 DOES NOT PRECEDE OR EQUAL                                                */
   { 0x7D, 0x38, 0x22E1 }, /* 0x227D + 0x0338 = 0x22E1 DOES NOT SUCCEED OR EQUAL                                                */
   { 0x82, 0x38, 0x2284 }, /* 0x2282 + 0x0338 = 0x2284 NOT A SUBSET OF                                                          */
   { 0x83, 0x38, 0x2285 }, /* 0x2283 + 0x0338 = 0x2285 NOT A SUPERSET OF                                                        */
   { 0x86, 0x38, 0x2288 }, /* 0x2286 + 0x0338 = 0x2288 NEITHER A SUBSET OF NOR EQUAL TO                                         */
   { 0x87, 0x38, 0x2289 }, /* 0x2287 + 0x0338 = 0x2289 NEITHER A SUPERSET OF NOR EQUAL TO                                       */
   { 0x91, 0x38, 0x22E2 }, /* 0x2291 + 0x0338 = 0x22E2 NOT SQUARE IMAGE OF OR EQUAL TO                                          */
   { 0x92, 0x38, 0x22E3 }, /* 0x2292 + 0x0338 = 0x22E3 NOT SQUARE ORIGINAL OF OR EQUAL TO                                       */
   { 0xA2, 0x38, 0x22AC }, /* 0x22A2 + 0x0338 = 0x22AC DOES NOT PROVE                                                           */
   { 0xA8, 0x38, 0x22AD }, /* 0x22A8 + 0x0338 = 0x22AD NOT TRUE                                                                 */
   { 0xA9, 0x38, 0x22AE }, /* 0x22A9 + 0x0338 = 0x22AE DOES NOT FORCE                                                           */
   { 0xAB, 0x38, 0x22AF }, /* 0x22AB + 0x0338 = 0x22AF NEGATED DOUBLE VERTICAL BAR DOUBLE RIGHT TURNSTILE                       */
   { 0xB2, 0x38, 0x22EA }, /* 0x22B2 + 0x0338 = 0x22EA NOT NORMAL SUBGROUP OF                                                   */
   { 0xB3, 0x38, 0x22EB }, /* 0x22B3 + 0x0338 = 0x22EB DOES NOT CONTAIN AS NORMAL SUBGROUP                                      */
   { 0xB4, 0x38, 0x22EC }, /* 0x22B4 + 0x0338 = 0x22EC NOT NORMAL SUBGROUP OF OR EQUAL TO                                       */
   { 0xB5, 0x38, 0x22ED }, /* 0x22B5 + 0x0338 = 0x22ED DOES NOT CONTAIN AS NORMAL SUBGROUP OR EQUAL                             */
   /* --------------- block_30_30 @  870 --------------- */
   { 0x46, 0x99, 0x3094 }, /* 0x3046 + 0x3099 = 0x3094 HIRAGANA LETTER VU                                                       */
   { 0x4B, 0x99, 0x304C }, /* 0x304B + 0x3099 = 0x304C HIRAGANA LETTER GA                                                       */
   { 0x4D, 0x99, 0x304E }, /* 0x304D + 0x3099 = 0x304E HIRAGANA LETTER GI                                                       */
   { 0x4F, 0x99, 0x3050 }, /* 0x304F + 0x3099 = 0x3050 HIRAGANA LETTER GU                                                       */
   { 0x51, 0x99, 0x3052 }, /* 0x3051 + 0x3099 = 0x3052 HIRAGANA LETTER GE                                                       */
   { 0x53, 0x99, 0x3054 }, /* 0x3053 + 0x3099 = 0x3054 HIRAGANA LETTER GO                                                       */
   { 0x55, 0x99, 0x3056 }, /* 0x3055 + 0x3099 = 0x3056 HIRAGANA LETTER ZA                                                       */
   { 0x57, 0x99, 0x3058 }, /* 0x3057 + 0x3099 = 0x3058 HIRAGANA LETTER ZI                                                       */
   { 0x59, 0x99, 0x305A }, /* 0x3059 + 0x3099 = 0x305A HIRAGANA LETTER ZU                                                       */
   { 0x5B, 0x99, 0x305C }, /* 0x305B + 0x3099 = 0x305C HIRAGANA LETTER ZE                                                       */
   { 0x5D, 0x99, 0x305E }, /* 0x305D + 0x3099 = 0x305E HIRAGANA LETTER ZO                                                       */
   { 0x5F, 0x99, 0x3060 }, /* 0x305F + 0x3099 = 0x3060 HIRAGANA LETTER DA                                                       */
   { 0x61, 0x99, 0x3062 }, /* 0x3061 + 0x3099 = 0x3062 HIRAGANA LETTER DI                                                       */
   { 0x64, 0x99, 0x3065 }, /* 0x3064 + 0x3099 = 0x3065 HIRAGANA LETTER DU                                                       */
   { 0x66, 0x99, 0x3067 }, /* 0x3066 + 0x3099 = 0x3067 HIRAGANA LETTER DE                                                       */
   { 0x68, 0x99, 0x3069 }, /* 0x3068 + 0x3099 = 0x3069 HIRAGANA LETTER DO                                                       */
   { 0x6F, 0x99, 0x3070 }, /* 0x306F + 0x3099 = 0x3070 HIRAGANA LETTER BA                                                       */
   { 0x6F, 0x9A, 0x3071 }, /* 0x306F + 0x309A = 0x3071 HIRAGANA LETTER PA                                                       */
   { 0x72, 0x99, 0x3073 }, /* 0x3072 + 0x3099 = 0x3073 HIRAGANA LETTER BI                                                       */
   { 0x72, 0x9A, 0x3074 }, /* 0x3072 + 0x309A = 0x3074 HIRAGANA LETTER PI                                                       */
   { 0x75, 0x99, 0x3076 }, /* 0x3075 + 0x3099 = 0x3076 HIRAGANA LETTER BU                                                       */
   { 0x75, 0x9A, 0x3077 }, /* 0x3075 + 0x309A = 0x3077 HIRAGANA LETTER PU                                                       */
   { 0x78, 0x99, 0x3079 }, /* 0x3078 + 0x3099 = 0x3079 HIRAGANA LETTER BE                                                       */
   { 0x78, 0x9A, 0x307A }, /* 0x3078 + 0x309A = 0x307A HIRAGANA LETTER PE                                                       */
   { 0x7B, 0x99, 0x307C }, /* 0x307B + 0x3099 = 0x307C HIRAGANA LETTER BO                                                       */
   { 0x7B, 0x9A, 0x307D }, /* 0x307B + 0x309A = 0x307D HIRAGANA LETTER PO                                                       */
   { 0x9D, 0x99, 0x309E }, /* 0x309D + 0x3099 = 0x309E HIRAGANA VOICED ITERATION MARK                                           */
   { 0xA6, 0x99, 0x30F4 }, /* 0x30A6 + 0x3099 = 0x30F4 KATAKANA LETTER VU                                                       */
   { 0xAB, 0x99, 0x30AC }, /* 0x30AB + 0x3099 = 0x30AC KATAKANA LETTER GA                                                       */
   { 0xAD, 0x99, 0x30AE }, /* 0x30AD + 0x3099 = 0x30AE KATAKANA LETTER GI                                                       */
   { 0xAF, 0x99, 0x30B0 }, /* 0x30AF + 0x3099 = 0x30B0 KATAKANA LETTER GU                                                       */
   { 0xB1, 0x99, 0x30B2 }, /* 0x30B1 + 0x3099 = 0x30B2 KATAKANA LETTER GE                                                       */
   { 0xB3, 0x99, 0x30B4 }, /* 0x30B3 + 0x3099 = 0x30B4 KATAKANA LETTER GO                                                       */
   { 0xB5, 0x99, 0x30B6 }, /* 0x30B5 + 0x3099 = 0x30B6 KATAKANA LETTER ZA                                                       */
   { 0xB7, 0x99, 0x30B8 }, /* 0x30B7 + 0x3099 = 0x30B8 KATAKANA LETTER ZI                                                       */
   { 0xB9, 0x99, 0x30BA }, /* 0x30B9 + 0x3099 = 0x30BA KATAKANA LETTER ZU                                                       */
   { 0xBB, 0x99, 0x30BC }, /* 0x30BB + 0x3099 = 0x30BC KATAKANA LETTER ZE                                                       */
   { 0xBD, 0x99, 0x30BE }, /* 0x30BD + 0x3099 = 0x30BE KATAKANA LETTER ZO                                                       */
   { 0xBF, 0x99, 0x30C0 }, /* 0x30BF + 0x3099 = 0x30C0 KATAKANA LETTER DA                                                       */
   { 0xC1, 0x99, 0x30C2 }, /* 0x30C1 + 0x3099 = 0x30C2 KATAKANA LETTER DI                                                       */
   { 0xC4, 0x99, 0x30C5 }, /* 0x30C4 + 0x3099 = 0x30C5 KATAKANA LETTER DU                                                       */
   { 0xC6, 0x99, 0x30C7 }, /* 0x30C6 + 0x3099 = 0x30C7 KATAKANA LETTER DE                                                       */
   { 0xC8, 0x99, 0x30C9 }, /* 0x30C8 + 0x3099 = 0x30C9 KATAKANA LETTER DO                                                       */
   { 0xCF, 0x99, 0x30D0 }, /* 0x30CF + 0x3099 = 0x30D0 KATAKANA LETTER BA                                                       */
   { 0xCF, 0x9A, 0x30D1 }, /* 0x30CF + 0x309A = 0x30D1 KATAKANA LETTER PA                                                       */
   { 0xD2, 0x99, 0x30D3 }, /* 0x30D2 + 0x3099 = 0x30D3 KATAKANA LETTER BI                                                       */
   { 0xD2, 0x9A, 0x30D4 }, /* 0x30D2 + 0x309A = 0x30D4 KATAKANA LETTER PI                                                       */
   { 0xD5, 0x99, 0x30D6 }, /* 0x30D5 + 0x3099 = 0x30D6 KATAKANA LETTER BU                                                       */
   { 0xD5, 0x9A, 0x30D7 }, /* 0x30D5 + 0x309A = 0x30D7 KATAKANA LETTER PU                                                       */
   { 0xD8, 0x99, 0x30D9 }, /* 0x30D8 + 0x3099 = 0x30D9 KATAKANA LETTER BE                                                       */
   { 0xD8, 0x9A, 0x30DA }, /* 0x30D8 + 0x309A = 0x30DA KATAKANA LETTER PE                                                       */
   { 0xDB, 0x99, 0x30DC }, /* 0x30DB + 0x3099 = 0x30DC KATAKANA LETTER BO                                                       */
   { 0xDB, 0x9A, 0x30DD }, /* 0x30DB + 0x309A = 0x30DD KATAKANA LETTER PO                                                       */
   { 0xEF, 0x99, 0x30F7 }, /* 0x30EF + 0x3099 = 0x30F7 KATAKANA LETTER VA                                                       */
   { 0xF0, 0x99, 0x30F8 }, /* 0x30F0 + 0x3099 = 0x30F8 KATAKANA LETTER VI                                                       */
   { 0xF1, 0x99, 0x30F9 }, /* 0x30F1 + 0x3099 = 0x30F9 KATAKANA LETTER VE                                                       */
   { 0xF2, 0x99, 0x30FA }, /* 0x30F2 + 0x3099 = 0x30FA KATAKANA LETTER VO                                                       */
   { 0xFD, 0x99, 0x30FE }, /* 0x30FD + 0x3099 = 0x30FE KATAKANA VOICED ITERATION MARK                                           */
   /* --------------- block_110_110 @  928 --------------- */
   { 0x99, 0xBA, 0x1109A }, /* 0x11099 + 0x110BA = 0x1109A KAITHI LETTER DDDHA                                                      */
   { 0x9B, 0xBA, 0x1109C }, /* 0x1109B + 0x110BA = 0x1109C KAITHI LETTER RHA                                                        */
   { 0xA5, 0xBA, 0x110AB }, /* 0x110A5 + 0x110BA = 0x110AB KAITHI LETTER VA                                                         */
   /* --------------- block_111_111 @  931 --------------- */
   { 0x31, 0x27, 0x1112E }, /* 0x11131 + 0x11127 = 0x1112E CHAKMA VOWEL SIGN O                                                      */
   { 0x32, 0x27, 0x1112F }, /* 0x11132 + 0x11127 = 0x1112F CHAKMA VOWEL SIGN AU                                                     */
   /* --------------- end of list @  933 --------------- */
};

const CompositionIndexType
compositionIndex[] = 
{
   { 0x003C, 0x00FC, 0x0300, 0x0342,    0, 434 },
   { 0x0102, 0x01EB, 0x0300, 0x0323,  434,  48 },
   { 0x0226, 0x0292, 0x0304, 0x030C,  482,   7 },
   { 0x0391, 0x03D2, 0x0300, 0x0345,  489,  96 },
   { 0x0406, 0x04E9, 0x0300, 0x030F,  585,  52 },
   { 0x0627, 0x06D5, 0x0653, 0x0655,  637,   8 },
   { 0x0928, 0x09C7, 0x093C, 0x09D7,  645,   5 },
   { 0x0B47, 0x0BC7, 0x0B3E, 0x0BD7,  650,   7 },
   { 0x0C46, 0x0CCA, 0x0C56, 0x0CD6,  657,   6 },
   { 0x0D46, 0x0DDC, 0x0D3E, 0x0DDF,  663,   7 },
   { 0x1025, 0x1025, 0x102E, 0x102E,  670,   1 },
   { 0x1B05, 0x1B42, 0x1B35, 0x1B35,  671,  11 },
   { 0x1E36, 0x1ECD, 0x0302, 0x0307,  682,  14 },
   { 0x1F00, 0x1FFE, 0x0300, 0x0345,  696, 133 },
   { 0x2190, 0x21D4, 0x0338, 0x0338,  829,   6 },
   { 0x2203, 0x22B5, 0x0338, 0x0338,  835,  35 },
   { 0x3046, 0x30FD, 0x3099, 0x309A,  870,  58 },
   { 0x11099, 0x110A5, 0x110BA, 0x110BA,  928,   3 },
   { 0x11131, 0x11132, 0x11127, 0x11127,  931,   2 },
};


const CompositionMetaIndexType
compositionMetaIndex[] = {
     0, /* Block: 0x00.. indexed in compositionIndex[ 0] */
     1, /* Block: 0x01.. indexed in compositionIndex[ 1] */
     2, /* Block: 0x02.. indexed in compositionIndex[ 2] */
     3, /* Block: 0x03.. indexed in compositionIndex[ 3] */
     4, /* Block: 0x04.. indexed in compositionIndex[ 4] */
   255, /* Block: 0x05.. contains no Composition data    */
     5, /* Block: 0x06.. indexed in compositionIndex[ 5] */
   255, /* Block: 0x07.. contains no Composition data    */
   255, /* Block: 0x08.. contains no Composition data    */
     6, /* Block: 0x09.. indexed in compositionIndex[ 6] */
   255, /* Block: 0x0a.. contains no Composition data    */
     7, /* Block: 0x0b.. indexed in compositionIndex[ 7] */
     8, /* Block: 0x0c.. indexed in compositionIndex[ 8] */
     9, /* Block: 0x0d.. indexed in compositionIndex[ 9] */
   255, /* Block: 0x0e.. contains no Composition data    */
   255, /* Block: 0x0f.. contains no Composition data    */
    10, /* Block: 0x10.. indexed in compositionIndex[10] */
   255, /* Block: 0x11.. contains no Composition data    */
   255, /* Block: 0x12.. contains no Composition data    */
   255, /* Block: 0x13.. contains no Composition data    */
   255, /* Block: 0x14.. contains no Composition data    */
   255, /* Block: 0x15.. contains no Composition data    */
   255, /* Block: 0x16.. contains no Composition data    */
   255, /* Block: 0x17.. contains no Composition data    */
   255, /* Block: 0x18.. contains no Composition data    */
   255, /* Block: 0x19.. contains no Composition data    */
   255, /* Block: 0x1a.. contains no Composition data    */
    11, /* Block: 0x1b.. indexed in compositionIndex[11] */
   255, /* Block: 0x1c.. contains no Composition data    */
   255, /* Block: 0x1d.. contains no Composition data    */
    12, /* Block: 0x1e.. indexed in compositionIndex[12] */
    13, /* Block: 0x1f.. indexed in compositionIndex[13] */
   255, /* Block: 0x20.. contains no Composition data    */
    14, /* Block: 0x21.. indexed in compositionIndex[14] */
    15, /* Block: 0x22.. indexed in compositionIndex[15] */
   255, /* Block: 0x23.. contains no Composition data    */
   255, /* Block: 0x24.. contains no Composition data    */
   255, /* Block: 0x25.. contains no Composition data    */
   255, /* Block: 0x26.. contains no Composition data    */
   255, /* Block: 0x27.. contains no Composition data    */
   255, /* Block: 0x28.. contains no Composition data    */
   255, /* Block: 0x29.. contains no Composition data    */
   255, /* Block: 0x2a.. contains no Composition data    */
   255, /* Block: 0x2b.. contains no Composition data    */
   255, /* Block: 0x2c.. contains no Composition data    */
   255, /* Block: 0x2d.. contains no Composition data    */
   255, /* Block: 0x2e.. contains no Composition data    */
   255, /* Block: 0x2f.. contains no Composition data    */
    16, /* Block: 0x30.. indexed in compositionIndex[16] */
   255, /* Block: 0x31.. contains no Composition data    */
   255, /* Block: 0x32.. contains no Composition data    */
   255, /* Block: 0x33.. contains no Composition data    */
   255, /* Block: 0x34.. contains no Composition data    */
   255, /* Block: 0x35.. contains no Composition data    */
   255, /* Block: 0x36.. contains no Composition data    */
   255, /* Block: 0x37.. contains no Composition data    */
   255, /* Block: 0x38.. contains no Composition data    */
   255, /* Block: 0x39.. contains no Composition data    */
   255, /* Block: 0x3a.. contains no Composition data    */
   255, /* Block: 0x3b.. contains no Composition data    */
   255, /* Block: 0x3c.. contains no Composition data    */
   255, /* Block: 0x3d.. contains no Composition data    */
   255, /* Block: 0x3e.. contains no Composition data    */
   255, /* Block: 0x3f.. contains no Composition data    */
   255, /* Block: 0x40.. contains no Composition data    */
   255, /* Block: 0x41.. contains no Composition data    */
   255, /* Block: 0x42.. contains no Composition data    */
   255, /* Block: 0x43.. contains no Composition data    */
   255, /* Block: 0x44.. contains no Composition data    */
   255, /* Block: 0x45.. contains no Composition data    */
   255, /* Block: 0x46.. contains no Composition data    */
   255, /* Block: 0x47.. contains no Composition data    */
   255, /* Block: 0x48.. contains no Composition data    */
   255, /* Block: 0x49.. contains no Composition data    */
   255, /* Block: 0x4a.. contains no Composition data    */
   255, /* Block: 0x4b.. contains no Composition data    */
   255, /* Block: 0x4c.. contains no Composition data    */
   255, /* Block: 0x4d.. contains no Composition data    */
   255, /* Block: 0x4e.. contains no Composition data    */
   255, /* Block: 0x4f.. contains no Composition data    */
   255, /* Block: 0x50.. contains no Composition data    */
   255, /* Block: 0x51.. contains no Composition data    */
   255, /* Block: 0x52.. contains no Composition data    */
   255, /* Block: 0x53.. contains no Composition data    */
   255, /* Block: 0x54.. contains no Composition data    */
   255, /* Block: 0x55.. contains no Composition data    */
   255, /* Block: 0x56.. contains no Composition data    */
   255, /* Block: 0x57.. contains no Composition data    */
   255, /* Block: 0x58.. contains no Composition data    */
   255, /* Block: 0x59.. contains no Composition data    */
   255, /* Block: 0x5a.. contains no Composition data    */
   255, /* Block: 0x5b.. contains no Composition data    */
   255, /* Block: 0x5c.. contains no Composition data    */
   255, /* Block: 0x5d.. contains no Composition data    */
   255, /* Block: 0x5e.. contains no Composition data    */
   255, /* Block: 0x5f.. contains no Composition data    */
   255, /* Block: 0x60.. contains no Composition data    */
   255, /* Block: 0x61.. contains no Composition data    */
   255, /* Block: 0x62.. contains no Composition data    */
   255, /* Block: 0x63.. contains no Composition data    */
   255, /* Block: 0x64.. contains no Composition data    */
   255, /* Block: 0x65.. contains no Composition data    */
   255, /* Block: 0x66.. contains no Composition data    */
   255, /* Block: 0x67.. contains no Composition data    */
   255, /* Block: 0x68.. contains no Composition data    */
   255, /* Block: 0x69.. contains no Composition data    */
   255, /* Block: 0x6a.. contains no Composition data    */
   255, /* Block: 0x6b.. contains no Composition data    */
   255, /* Block: 0x6c.. contains no Composition data    */
   255, /* Block: 0x6d.. contains no Composition data    */
   255, /* Block: 0x6e.. contains no Composition data    */
   255, /* Block: 0x6f.. contains no Composition data    */
   255, /* Block: 0x70.. contains no Composition data    */
   255, /* Block: 0x71.. contains no Composition data    */
   255, /* Block: 0x72.. contains no Composition data    */
   255, /* Block: 0x73.. contains no Composition data    */
   255, /* Block: 0x74.. contains no Composition data    */
   255, /* Block: 0x75.. contains no Composition data    */
   255, /* Block: 0x76.. contains no Composition data    */
   255, /* Block: 0x77.. contains no Composition data    */
   255, /* Block: 0x78.. contains no Composition data    */
   255, /* Block: 0x79.. contains no Composition data    */
   255, /* Block: 0x7a.. contains no Composition data    */
   255, /* Block: 0x7b.. contains no Composition data    */
   255, /* Block: 0x7c.. contains no Composition data    */
   255, /* Block: 0x7d.. contains no Composition data    */
   255, /* Block: 0x7e.. contains no Composition data    */
   255, /* Block: 0x7f.. contains no Composition data    */
   255, /* Block: 0x80.. contains no Composition data    */
   255, /* Block: 0x81.. contains no Composition data    */
   255, /* Block: 0x82.. contains no Composition data    */
   255, /* Block: 0x83.. contains no Composition data    */
   255, /* Block: 0x84.. contains no Composition data    */
   255, /* Block: 0x85.. contains no Composition data    */
   255, /* Block: 0x86.. contains no Composition data    */
   255, /* Block: 0x87.. contains no Composition data    */
   255, /* Block: 0x88.. contains no Composition data    */
   255, /* Block: 0x89.. contains no Composition data    */
   255, /* Block: 0x8a.. contains no Composition data    */
   255, /* Block: 0x8b.. contains no Composition data    */
   255, /* Block: 0x8c.. contains no Composition data    */
   255, /* Block: 0x8d.. contains no Composition data    */
   255, /* Block: 0x8e.. contains no Composition data    */
   255, /* Block: 0x8f.. contains no Composition data    */
   255, /* Block: 0x90.. contains no Composition data    */
   255, /* Block: 0x91.. contains no Composition data    */
   255, /* Block: 0x92.. contains no Composition data    */
   255, /* Block: 0x93.. contains no Composition data    */
   255, /* Block: 0x94.. contains no Composition data    */
   255, /* Block: 0x95.. contains no Composition data    */
   255, /* Block: 0x96.. contains no Composition data    */
   255, /* Block: 0x97.. contains no Composition data    */
   255, /* Block: 0x98.. contains no Composition data    */
   255, /* Block: 0x99.. contains no Composition data    */
   255, /* Block: 0x9a.. contains no Composition data    */
   255, /* Block: 0x9b.. contains no Composition data    */
   255, /* Block: 0x9c.. contains no Composition data    */
   255, /* Block: 0x9d.. contains no Composition data    */
   255, /* Block: 0x9e.. contains no Composition data    */
   255, /* Block: 0x9f.. contains no Composition data    */
   255, /* Block: 0xa0.. contains no Composition data    */
   255, /* Block: 0xa1.. contains no Composition data    */
   255, /* Block: 0xa2.. contains no Composition data    */
   255, /* Block: 0xa3.. contains no Composition data    */
   255, /* Block: 0xa4.. contains no Composition data    */
   255, /* Block: 0xa5.. contains no Composition data    */
   255, /* Block: 0xa6.. contains no Composition data    */
   255, /* Block: 0xa7.. contains no Composition data    */
   255, /* Block: 0xa8.. contains no Composition data    */
   255, /* Block: 0xa9.. contains no Composition data    */
   255, /* Block: 0xaa.. contains no Composition data    */
   255, /* Block: 0xab.. contains no Composition data    */
   255, /* Block: 0xac.. contains no Composition data    */
   255, /* Block: 0xad.. contains no Composition data    */
   255, /* Block: 0xae.. contains no Composition data    */
   255, /* Block: 0xaf.. contains no Composition data    */
   255, /* Block: 0xb0.. contains no Composition data    */
   255, /* Block: 0xb1.. contains no Composition data    */
   255, /* Block: 0xb2.. contains no Composition data    */
   255, /* Block: 0xb3.. contains no Composition data    */
   255, /* Block: 0xb4.. contains no Composition data    */
   255, /* Block: 0xb5.. contains no Composition data    */
   255, /* Block: 0xb6.. contains no Composition data    */
   255, /* Block: 0xb7.. contains no Composition data    */
   255, /* Block: 0xb8.. contains no Composition data    */
   255, /* Block: 0xb9.. contains no Composition data    */
   255, /* Block: 0xba.. contains no Composition data    */
   255, /* Block: 0xbb.. contains no Composition data    */
   255, /* Block: 0xbc.. contains no Composition data    */
   255, /* Block: 0xbd.. contains no Composition data    */
   255, /* Block: 0xbe.. contains no Composition data    */
   255, /* Block: 0xbf.. contains no Composition data    */
   255, /* Block: 0xc0.. contains no Composition data    */
   255, /* Block: 0xc1.. contains no Composition data    */
   255, /* Block: 0xc2.. contains no Composition data    */
   255, /* Block: 0xc3.. contains no Composition data    */
   255, /* Block: 0xc4.. contains no Composition data    */
   255, /* Block: 0xc5.. contains no Composition data    */
   255, /* Block: 0xc6.. contains no Composition data    */
   255, /* Block: 0xc7.. contains no Composition data    */
   255, /* Block: 0xc8.. contains no Composition data    */
   255, /* Block: 0xc9.. contains no Composition data    */
   255, /* Block: 0xca.. contains no Composition data    */
   255, /* Block: 0xcb.. contains no Composition data    */
   255, /* Block: 0xcc.. contains no Composition data    */
   255, /* Block: 0xcd.. contains no Composition data    */
   255, /* Block: 0xce.. contains no Composition data    */
   255, /* Block: 0xcf.. contains no Composition data    */
   255, /* Block: 0xd0.. contains no Composition data    */
   255, /* Block: 0xd1.. contains no Composition data    */
   255, /* Block: 0xd2.. contains no Composition data    */
   255, /* Block: 0xd3.. contains no Composition data    */
   255, /* Block: 0xd4.. contains no Composition data    */
   255, /* Block: 0xd5.. contains no Composition data    */
   255, /* Block: 0xd6.. contains no Composition data    */
   255, /* Block: 0xd7.. contains no Composition data    */
   255, /* Block: 0xd8.. contains no Composition data    */
   255, /* Block: 0xd9.. contains no Composition data    */
   255, /* Block: 0xda.. contains no Composition data    */
   255, /* Block: 0xdb.. contains no Composition data    */
   255, /* Block: 0xdc.. contains no Composition data    */
   255, /* Block: 0xdd.. contains no Composition data    */
   255, /* Block: 0xde.. contains no Composition data    */
   255, /* Block: 0xdf.. contains no Composition data    */
   255, /* Block: 0xe0.. contains no Composition data    */
   255, /* Block: 0xe1.. contains no Composition data    */
   255, /* Block: 0xe2.. contains no Composition data    */
   255, /* Block: 0xe3.. contains no Composition data    */
   255, /* Block: 0xe4.. contains no Composition data    */
   255, /* Block: 0xe5.. contains no Composition data    */
   255, /* Block: 0xe6.. contains no Composition data    */
   255, /* Block: 0xe7.. contains no Composition data    */
   255, /* Block: 0xe8.. contains no Composition data    */
   255, /* Block: 0xe9.. contains no Composition data    */
   255, /* Block: 0xea.. contains no Composition data    */
   255, /* Block: 0xeb.. contains no Composition data    */
   255, /* Block: 0xec.. contains no Composition data    */
   255, /* Block: 0xed.. contains no Composition data    */
   255, /* Block: 0xee.. contains no Composition data    */
   255, /* Block: 0xef.. contains no Composition data    */
   255, /* Block: 0xf0.. contains no Composition data    */
   255, /* Block: 0xf1.. contains no Composition data    */
   255, /* Block: 0xf2.. contains no Composition data    */
   255, /* Block: 0xf3.. contains no Composition data    */
   255, /* Block: 0xf4.. contains no Composition data    */
   255, /* Block: 0xf5.. contains no Composition data    */
   255, /* Block: 0xf6.. contains no Composition data    */
   255, /* Block: 0xf7.. contains no Composition data    */
   255, /* Block: 0xf8.. contains no Composition data    */
   255, /* Block: 0xf9.. contains no Composition data    */
   255, /* Block: 0xfa.. contains no Composition data    */
   255, /* Block: 0xfb.. contains no Composition data    */
   255, /* Block: 0xfc.. contains no Composition data    */
   255, /* Block: 0xfd.. contains no Composition data    */
   255, /* Block: 0xfe.. contains no Composition data    */
   255, /* Block: 0xff.. contains no Composition data    */
   255, /* Block: 0x100.. contains no Composition data    */
   255, /* Block: 0x101.. contains no Composition data    */
   255, /* Block: 0x102.. contains no Composition data    */
   255, /* Block: 0x103.. contains no Composition data    */
   255, /* Block: 0x104.. contains no Composition data    */
   255, /* Block: 0x105.. contains no Composition data    */
   255, /* Block: 0x106.. contains no Composition data    */
   255, /* Block: 0x107.. contains no Composition data    */
   255, /* Block: 0x108.. contains no Composition data    */
   255, /* Block: 0x109.. contains no Composition data    */
   255, /* Block: 0x10a.. contains no Composition data    */
   255, /* Block: 0x10b.. contains no Composition data    */
   255, /* Block: 0x10c.. contains no Composition data    */
   255, /* Block: 0x10d.. contains no Composition data    */
   255, /* Block: 0x10e.. contains no Composition data    */
   255, /* Block: 0x10f.. contains no Composition data    */
    17, /* Block: 0x110.. indexed in compositionIndex[17] */
    18, /* Block: 0x111.. indexed in compositionIndex[18] */
};


/* Note: this jamo data was generated with a different script: */

const USHORT
jamoTable[NUM_COMPATIBILITY_JAMO_SUPPORTED] =
{
    /* Note: this table MUST be correspond to consecutive values 0x3131..0x318E */
    0x1100, /* 0x3131 HANGUL LETTER KIYEOK */
    0x1101, /* 0x3132 HANGUL LETTER SSANGKIYEOK */
    0x11AA, /* 0x3133 HANGUL LETTER KIYEOK-SIOS */
    0x1102, /* 0x3134 HANGUL LETTER NIEUN */
    0x11AC, /* 0x3135 HANGUL LETTER NIEUN-CIEUC */
    0x11AD, /* 0x3136 HANGUL LETTER NIEUN-HIEUH */
    0x1103, /* 0x3137 HANGUL LETTER TIKEUT */
    0x1104, /* 0x3138 HANGUL LETTER SSANGTIKEUT */
    0x1105, /* 0x3139 HANGUL LETTER RIEUL */
    0x11B0, /* 0x313A HANGUL LETTER RIEUL-KIYEOK */
    0x11B1, /* 0x313B HANGUL LETTER RIEUL-MIEUM */
    0x11B2, /* 0x313C HANGUL LETTER RIEUL-PIEUP */
    0x11B3, /* 0x313D HANGUL LETTER RIEUL-SIOS */
    0x11B4, /* 0x313E HANGUL LETTER RIEUL-THIEUTH */
    0x11B5, /* 0x313F HANGUL LETTER RIEUL-PHIEUPH */
    0x111A, /* 0x3140 HANGUL LETTER RIEUL-HIEUH */
    0x1106, /* 0x3141 HANGUL LETTER MIEUM */
    0x1107, /* 0x3142 HANGUL LETTER PIEUP */
    0x1108, /* 0x3143 HANGUL LETTER SSANGPIEUP */
    0x1121, /* 0x3144 HANGUL LETTER PIEUP-SIOS */
    0x1109, /* 0x3145 HANGUL LETTER SIOS */
    0x110A, /* 0x3146 HANGUL LETTER SSANGSIOS */
    0x110B, /* 0x3147 HANGUL LETTER IEUNG */
    0x110C, /* 0x3148 HANGUL LETTER CIEUC */
    0x110D, /* 0x3149 HANGUL LETTER SSANGCIEUC */
    0x110E, /* 0x314A HANGUL LETTER CHIEUCH */
    0x110F, /* 0x314B HANGUL LETTER KHIEUKH */
    0x1110, /* 0x314C HANGUL LETTER THIEUTH */
    0x1111, /* 0x314D HANGUL LETTER PHIEUPH */
    0x1112, /* 0x314E HANGUL LETTER HIEUH */
    0x1161, /* 0x314F HANGUL LETTER A */
    0x1162, /* 0x3150 HANGUL LETTER AE */
    0x1163, /* 0x3151 HANGUL LETTER YA */
    0x1164, /* 0x3152 HANGUL LETTER YAE */
    0x1165, /* 0x3153 HANGUL LETTER EO */
    0x1166, /* 0x3154 HANGUL LETTER E */
    0x1167, /* 0x3155 HANGUL LETTER YEO */
    0x1168, /* 0x3156 HANGUL LETTER YE */
    0x1169, /* 0x3157 HANGUL LETTER O */
    0x116A, /* 0x3158 HANGUL LETTER WA */
    0x116B, /* 0x3159 HANGUL LETTER WAE */
    0x116C, /* 0x315A HANGUL LETTER OE */
    0x116D, /* 0x315B HANGUL LETTER YO */
    0x116E, /* 0x315C HANGUL LETTER U */
    0x116F, /* 0x315D HANGUL LETTER WEO */
    0x1170, /* 0x315E HANGUL LETTER WE */
    0x1171, /* 0x315F HANGUL LETTER WI */
    0x1172, /* 0x3160 HANGUL LETTER YU */
    0x1173, /* 0x3161 HANGUL LETTER EU */
    0x1174, /* 0x3162 HANGUL LETTER YI */
    0x1175, /* 0x3163 HANGUL LETTER I */
    0x1160, /* 0x3164 HANGUL FILLER */
    0x1114, /* 0x3165 HANGUL LETTER SSANGNIEUN */
    0x1115, /* 0x3166 HANGUL LETTER NIEUN-TIKEUT */
    0x11C7, /* 0x3167 HANGUL LETTER NIEUN-SIOS */
    0x11C8, /* 0x3168 HANGUL LETTER NIEUN-PANSIOS */
    0x11CC, /* 0x3169 HANGUL LETTER RIEUL-KIYEOK-SIOS */
    0x11CE, /* 0x316A HANGUL LETTER RIEUL-TIKEUT */
    0x11D3, /* 0x316B HANGUL LETTER RIEUL-PIEUP-SIOS */
    0x11D7, /* 0x316C HANGUL LETTER RIEUL-PANSIOS */
    0x11D9, /* 0x316D HANGUL LETTER RIEUL-YEORINHIEUH */
    0x111C, /* 0x316E HANGUL LETTER MIEUM-PIEUP */
    0x11DD, /* 0x316F HANGUL LETTER MIEUM-SIOS */
    0x11DF, /* 0x3170 HANGUL LETTER MIEUM-PANSIOS */
    0x111D, /* 0x3171 HANGUL LETTER KAPYEOUNMIEUM */
    0x111E, /* 0x3172 HANGUL LETTER PIEUP-KIYEOK */
    0x1120, /* 0x3173 HANGUL LETTER PIEUP-TIKEUT */
    0x1122, /* 0x3174 HANGUL LETTER PIEUP-SIOS-KIYEOK */
    0x1123, /* 0x3175 HANGUL LETTER PIEUP-SIOS-TIKEUT */
    0x1127, /* 0x3176 HANGUL LETTER PIEUP-CIEUC */
    0x1129, /* 0x3177 HANGUL LETTER PIEUP-THIEUTH */
    0x112B, /* 0x3178 HANGUL LETTER KAPYEOUNPIEUP */
    0x112C, /* 0x3179 HANGUL LETTER KAPYEOUNSSANGPIEUP */
    0x112D, /* 0x317A HANGUL LETTER SIOS-KIYEOK */
    0x112E, /* 0x317B HANGUL LETTER SIOS-NIEUN */
    0x112F, /* 0x317C HANGUL LETTER SIOS-TIKEUT */
    0x1132, /* 0x317D HANGUL LETTER SIOS-PIEUP */
    0x1136, /* 0x317E HANGUL LETTER SIOS-CIEUC */
    0x1140, /* 0x317F HANGUL LETTER PANSIOS */
    0x1147, /* 0x3180 HANGUL LETTER SSANGIEUNG */
    0x114C, /* 0x3181 HANGUL LETTER YESIEUNG */
    0x11F1, /* 0x3182 HANGUL LETTER YESIEUNG-SIOS */
    0x11F2, /* 0x3183 HANGUL LETTER YESIEUNG-PANSIOS */
    0x1157, /* 0x3184 HANGUL LETTER KAPYEOUNPHIEUPH */
    0x1158, /* 0x3185 HANGUL LETTER SSANGHIEUH */
    0x1159, /* 0x3186 HANGUL LETTER YEORINHIEUH */
    0x1184, /* 0x3187 HANGUL LETTER YO-YA */
    0x1185, /* 0x3188 HANGUL LETTER YO-YAE */
    0x1188, /* 0x3189 HANGUL LETTER YO-I */
    0x1191, /* 0x318A HANGUL LETTER YU-YEO */
    0x1192, /* 0x318B HANGUL LETTER YU-YE */
    0x1194, /* 0x318C HANGUL LETTER YU-I */
    0x119E, /* 0x318D HANGUL LETTER ARAEA */
    0x11A1  /* 0x318E HANGUL LETTER ARAEAE */
};

/* ******************** End of Script-Generated Code ******************** */
