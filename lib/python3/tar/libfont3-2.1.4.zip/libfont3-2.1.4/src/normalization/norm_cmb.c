// Copyright (C) 2014 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// norm_cmb.c (Code to process combining class data.)

#include "normalization/norm_nrmtxt.h"
#include "normalization/norm_cmb.h"
#include "normalization/norm_uniprp.h"

/* General utility macros */
#define GET_COMBINING_CLASS(p)      ((TsCombClassType) (((p) & TS_COMBINING_CLASS_MASK) >> TS_COMBINING_CLASS_SHIFT))
#define TS_UNICODE_MAX_VALUE 0x010FFFF

static ULONG
getGeneralProps(ULONG c)
{
    ULONG A, B, C, D;
    ULONG props;

    if (c <= 0xFF)
        props = tsGeneralPropsArray[tsGeneralPropsLut[c]];
    else
    {
        if (c > TS_UNICODE_MAX_VALUE)
            c = 0xFFFF;

        A = (c & TS_GENERAL_PROPS_INDEX_MASK_A) >> TS_GENERAL_PROPS_INDEX_SHIFT_A;
        B = (c & TS_GENERAL_PROPS_INDEX_MASK_B) >> TS_GENERAL_PROPS_INDEX_SHIFT_B;
        C = (c & TS_GENERAL_PROPS_INDEX_MASK_C) >> TS_GENERAL_PROPS_INDEX_SHIFT_C;
        D = (c & TS_GENERAL_PROPS_INDEX_MASK_D) >> TS_GENERAL_PROPS_INDEX_SHIFT_D;

        props = tsGeneralPropsArray[tsGeneralPropsLut[tsGeneralPropsIndex[tsGeneralPropsIndex[tsGeneralPropsIndex[A] + B] + C] + D]];
    }

    return(props);
}


static LF_ERROR
sortRunOfCombiningMarks(
    TsNormTextObj *inputTextObj,
    LONG       runStartIndex,
    LONG       runEndIndex
)
{
    LONG i, j;
    TsCombClassType class1, class2;
    ULONG char1, char2;
    LONG sourceIndex1, sourceIndex2;
    LF_ERROR result;

    result = LF_ERROR_OK;

    for(i=runStartIndex; i<runEndIndex; i++)
    {
        for (j=runStartIndex; j<(runEndIndex - (i-runStartIndex)); j++)
        {
            result = inputTextObj->getChar(inputTextObj, j, &char1, &sourceIndex1);
            LF_CHECK_RESULT(result);

            result = inputTextObj->getChar(inputTextObj, j+1, &char2, &sourceIndex2);
            LF_CHECK_RESULT(result);

            class1 = TsNorm_getCombiningClass(char1);
            class2 = TsNorm_getCombiningClass(char2);
            if ((class1 > class2))
            {
                result = inputTextObj->setChar(inputTextObj, j,   char2, sourceIndex2);
                LF_CHECK_RESULT(result);

                result = inputTextObj->setChar(inputTextObj, j+1, char1, sourceIndex1);
                LF_CHECK_RESULT(result);
            }
        }
    }

    return result;
}


/*lint +fpn *//* be sure to check for NULL pointer issues in exported functions */


TsCombClassType
TsNorm_getCombiningClass(ULONG inputChar)
{
    return(GET_COMBINING_CLASS(getGeneralProps(inputChar)));
}


/* Normalization utility macros */
#define IS_COMBINING_LETTER(p)      ((boolean)((((p) & TS_COMBINING_LETTERS_MASK) != 0) ? TRUE : FALSE))
#define IS_COMPOSITION_EXCLUDED(p)  ((boolean)((((p) & TS_COMPOSITION_EXCLUSION_MASK) != 0) ? TRUE : FALSE))

void
TsNorm_getCombiningData(ULONG inputChar, TsCombClassType *combiningClass, boolean *isCombiningLetter, boolean *isCompositionExcluded)
{
    ULONG props;

    if(combiningClass == NULL)
        return;
    if(isCombiningLetter == NULL)
        return;
    if(isCompositionExcluded == NULL)
        return;

    props = getGeneralProps(inputChar);

    *combiningClass = GET_COMBINING_CLASS(props);
    *isCombiningLetter = IS_COMBINING_LETTER(props);
    *isCompositionExcluded = IS_COMPOSITION_EXCLUDED(props);
}


LF_ERROR
TsNorm_findEndOfRunOfCombiningLettersAndMarks(
    const TsNormTextObj *inputTextObj,
    LONG       runStartIndex,
    LONG       inputEndIndex,
    LONG      *runEndIndex
)
{
    boolean  isCombiningLetter;
    boolean  isCompositionExcluded;
    ULONG currChar;
    LONG sourceIndex;
    TsCombClassType currClass;
    LF_ERROR result;

    if(inputTextObj == NULL)
        return LF_INVALID_PARAM;
    if(runEndIndex == NULL)
        return LF_INVALID_PARAM;

    *runEndIndex = runStartIndex + 1;
    result = LF_ERROR_OK;

    if(*runEndIndex <= inputEndIndex)
    {
        do
        {
            result = inputTextObj->getChar(inputTextObj, *runEndIndex, &currChar, &sourceIndex);
            LF_CHECK_RESULT(result);

            TsNorm_getCombiningData(currChar, &currClass, &isCombiningLetter, &isCompositionExcluded);
            if(((currClass != TS_COMB_CLASS_000) || isCombiningLetter) && (*runEndIndex <= inputEndIndex))
            {
                *runEndIndex += 1;
            }
        } while ((currClass != TS_COMB_CLASS_000) && (*runEndIndex <= inputEndIndex));
    }
    *runEndIndex -= 1;

    return result;
}


LF_ERROR
TsNorm_findEndOfRunOfCombiningMarks(
    const TsNormTextObj *inputTextObj,
    LONG       runStartIndex,
    LONG       inputEndIndex,
    LONG      *runEndIndex
)
{
    ULONG currChar;
    LONG sourceIndex;
    TsCombClassType currClass;
    LF_ERROR result;

    if(inputTextObj == NULL)
        return LF_INVALID_PARAM;
    if(runEndIndex == NULL)
        return LF_INVALID_PARAM;

    result = LF_ERROR_OK;

    *runEndIndex = runStartIndex + 1;

    if(*runEndIndex <= inputEndIndex)
    {
        do
        {
            result = inputTextObj->getChar(inputTextObj, *runEndIndex, &currChar, &sourceIndex);
            LF_CHECK_RESULT(result);

            currClass = TsNorm_getCombiningClass(currChar);
            if((currClass != TS_COMB_CLASS_000) && (*runEndIndex <= inputEndIndex))
            {
                *runEndIndex += 1;
            }
        } while ((currClass != TS_COMB_CLASS_000) && (*runEndIndex <= inputEndIndex));
    }
    *runEndIndex -= 1;

    return result;
}


LF_ERROR
TsNorm_canonicallyReorderCombiningMarks(
    TsNormTextObj *inputTextObj,
    LONG       inputStartIndex,
    LONG       inputEndIndex
)
{
    LONG i, runStartIndex, runEndIndex;
    LONG sourceIndex;
    ULONG currChar;
    LF_ERROR result;

    if(inputTextObj == NULL)
        return LF_INVALID_PARAM;

    result = LF_ERROR_OK;

    i = inputStartIndex;

    while(i <= inputEndIndex)
    {
        result = inputTextObj->getChar(inputTextObj, i, &currChar, &sourceIndex);
        LF_CHECK_RESULT(result);

        if(TsNorm_getCombiningClass(currChar) != TS_COMB_CLASS_000)
        {
            runStartIndex = i;

            result = TsNorm_findEndOfRunOfCombiningMarks(inputTextObj, runStartIndex, inputEndIndex, &runEndIndex);
            LF_CHECK_RESULT(result);

            result = sortRunOfCombiningMarks(inputTextObj, runStartIndex, runEndIndex);
            LF_CHECK_RESULT(result);
            i = runEndIndex;
        }
        i++;
    }
    return result;
}


/*lint -fpn */ /* turn off checking for NULL pointer issues */
