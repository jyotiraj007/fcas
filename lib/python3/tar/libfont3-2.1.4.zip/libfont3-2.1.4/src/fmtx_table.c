// Copyright (C) 2016 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// fmtx_table.c

#include <stdlib.h>
#include "fmtx_table.h"
#include "utils.h"
#include "table_tags.h"

LF_ERROR FMTX_readTable(LF_FONT* lfFont, const sfnt_table_record* record, LF_STREAM* stream)
{
    if (record->length == 0)
        return LF_BAD_FORMAT;

    if (STREAM_streamSeek(stream, record->offset) != 0)
        return LF_INVALID_OFFSET;

    fmtx_table* table = (fmtx_table*)calloc(1, sizeof(fmtx_table));

    if (NULL == table)
        return LF_OUT_OF_MEMORY;

    if (STREAM_streamSeek(stream, record->offset) != 0)
    {
        free(table);
        return LF_INVALID_OFFSET;
    }

    table->version = STREAM_readFixed(stream);
    table->glyphIndex = STREAM_readULong(stream);
    table->horizontalBefore = STREAM_readByte(stream);

    table->horizontalAfter = STREAM_readByte(stream);
    table->horizontalCaretHead = STREAM_readByte(stream);
    table->horizontalCaretBase = STREAM_readByte(stream);
    table->verticalBefore = STREAM_readByte(stream);
    table->verticalAfter = STREAM_readByte(stream);
    table->verticalCaretHead = STREAM_readByte(stream);
    table->verticalCaretBase = STREAM_readByte(stream);

    map_insert(&lfFont->table_map, (void*)(intptr_t)record->tag, table);

    return LF_ERROR_OK;
}

LF_ERROR FMTX_remapTable(LF_FONT* lfFont, LF_MAP *glyphIndexMap)
{
    fmtx_table* table = (fmtx_table*)map_at(&lfFont->table_map, (void*)(long)TAG_FMTX);
    if (table == NULL)
        return LF_EMPTY_TABLE;

    table->glyphIndex = (ULONG)(intptr_t)map_at(glyphIndexMap, (void*)(intptr_t)table->glyphIndex);

    return LF_ERROR_OK;
}

LF_ERROR FMTX_getMetricsGlyph(LF_FONT* lfFont, GlyphID* gid)
{
    fmtx_table* table = (fmtx_table*)map_at(&lfFont->table_map, (void*)(long)TAG_FMTX);
    if (table == NULL)
        return LF_EMPTY_TABLE;

    *gid = (GlyphID)table->glyphIndex;

    return LF_ERROR_OK;
}

LF_ERROR FMTX_getTableSize(LF_FONT* lfFont, size_t* tableSize)
{
    fmtx_table* table = (fmtx_table*)map_at(&lfFont->table_map, (void*)(long)TAG_FMTX);

    *tableSize = 0;

    if(table == NULL)
        return LF_EMPTY_TABLE;

    *tableSize = FMTX_TABLE_SIZE;

    return LF_ERROR_OK;
}

LF_ERROR FMTX_writeTable(LF_FONT* lfFont, sfnt_table_record* record, LF_STREAM* stream)
{
    fmtx_table* table = (fmtx_table*)map_at(&lfFont->table_map, (void*)TAG_FMTX);
    if (table == NULL)
        return LF_EMPTY_TABLE;

    size_t tableSize = FMTX_TABLE_SIZE;

    BYTE* tableData = UTILS_AllocTable(&tableSize);
    if (tableData == NULL)
        return LF_OUT_OF_MEMORY;

    LF_STREAM localStream;

    STREAM_initMemStream(&localStream, tableData, tableSize);

    STREAM_writeFixed(&localStream, table->version);
    STREAM_writeULong(&localStream, table->glyphIndex);
    STREAM_writeByte(&localStream, table->horizontalBefore);
    STREAM_writeByte(&localStream, table->horizontalAfter);
    STREAM_writeByte(&localStream, table->horizontalCaretHead);
    STREAM_writeByte(&localStream, table->horizontalCaretBase);
    STREAM_writeByte(&localStream, table->verticalBefore);
    STREAM_writeByte(&localStream, table->verticalAfter);
    STREAM_writeByte(&localStream, table->verticalCaretHead);
    STREAM_writeByte(&localStream, table->verticalCaretBase);

    record->checkSum = UTILS_CalcTableChecksum(tableData, tableSize);
    record->length = (ULONG)tableSize;
    record->offset = (ULONG)STREAM_streamPos(stream);

    STREAM_writeChunk(stream, tableData, tableSize);
    free(tableData);

    return LF_ERROR_OK;
}

LF_ERROR FMTX_freeTable(LF_FONT* lfFont)
{
    fmtx_table* table = (fmtx_table*)map_at(&lfFont->table_map, (void*)(long)TAG_FMTX);

    if (table)
    {
        free(table);
    }

    return LF_ERROR_OK;
}
