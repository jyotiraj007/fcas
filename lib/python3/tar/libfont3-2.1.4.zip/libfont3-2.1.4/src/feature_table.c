// Copyright (C) 2014, 2015 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// feature_table.c

#include <string.h>
#include <stdlib.h>
#include "utils.h"
#include "feature_table.h"
#include "lookup_table.h"
#include "gsub_table.h"

static size_t Feature_getFeatureTableSize(const feature_table* table)
{
    return sizeof(OFFSET) + sizeof(USHORT) * (table->LookupListIndex.count + 1);
}

static size_t Feature_getListTableSize(TABLE_HANDLE hTable)
{
    feature_list* featList = (feature_list*)hTable;

    size_t size = sizeof(USHORT) + FEATURE_RECORD_SIZE * featList->features.count;

    if (featList->hasGPOSSizeFeature == TRUE)
        size += 5 * sizeof(USHORT);

    return size;
}

/* ----------------------------------------------------------------------------
    @brief
        A Feature table defines a feature with one or more lookups. The client 
        uses the lookups to substitute or position glyphs.

        Feature tables defined within the GSUB table contain references to 
        glyph substitution lookups, and feature tables defined within the GPOS 
        table contain references to glyph positioning lookups. If a text-
        processing operation requires both glyph substitution and positioning, 
        then both the GSUB and GPOS tables must each define a Feature table, 
        and the tables must use the same FeatureTags.

        A Feature table consists of an offset to a Feature Parameters 
        (FeatureParams) table, a count of the lookups listed for the feature 
        (LookupCount), and an arbitrarily ordered array of indices into a 
        LookupList (LookupListIndex). The LookupList indices are references 
        into an array of offsets to Lookup tables.

        The format of the Feature Parameters table is specific to a particular 
        feature, and must be specified in the feature's entry in the Feature Tags 
        section of the OpenType Layout Tag Registry. The length of the Feature 
        Parameters table must be implicitly or explicitly specified in the Feature 
        Parameters table itself. The FeatureParams field in the Feature Table 
        records the offset relative to the beginning of the Feature Table. If a 
        Feature Parameters table is not needed, the FeatureParams field must be 
        set to NULL.

        To identify the features in a GSUB or GPOS table, a text-processing client 
        reads the FeatureTag of each FeatureRecord referenced in a given LangSys 
        table. Then the client selects the features it wants to implement and uses 
        the LookupList to retrieve the Lookup indices of the chosen features. Next, 
        the client arranges the indices in the LookupList order. Finally, the 
        client applies the lookup data to substitute or position glyphs.

    @param
        stream  = pointer to the stream to retrieve the feature table.  stream is
                  pointing to the start of the feature table.

        table   = pointer to feauture table pointer which is created

    @returns
        LF_ERROR value.
---------------------------------------------------------------------------- */
static LF_ERROR Feature_readFeatureTable(LF_STREAM* stream, feature_list* featList, TAG featureTag,
                                         size_t startOfFeatureTableList, boolean isGPOS)
{
    boolean isOpticalSize = FALSE;

    size_t startOfFeatureTable = STREAM_streamPos(stream);

    OFFSET featureParamsOffset = STREAM_readOffset(stream);
    USHORT lookupCount = STREAM_readUShort(stream);

    if (isGPOS && (featureTag == 0x73697A65 /*'size'*/))
    {
        isOpticalSize = TRUE;
    }

    if (lookupCount != 0)
    {
        USHORT i;
        ULONG featureSize = sizeof(feature_table) + sizeof(USHORT) * (lookupCount - 1);

        feature_table* table = (feature_table*)calloc(1, featureSize);
        if (table == NULL)
            return LF_OUT_OF_MEMORY;

        table->FeatureParams = featureParamsOffset;

        if (table->FeatureParams != 0)
        {
            DEBUG_LOG_WARNING("WARNING: zeroing out feature params offset since feature params are not processed");
            table->FeatureParams = 0;
        }

        table->LookupCount = lookupCount;

        LF_ERROR error = vector_init(&table->LookupListIndex, lookupCount, sizeof(ULONG));
        if (error != LF_ERROR_OK)
        {
            free(table);
            return error;
        }

        for (i = 0; i < table->LookupCount; i++)
        {
            vector_push_back(&table->LookupListIndex, (void*)(intptr_t)STREAM_readUShort(stream));
        }

        table->FeatureTag = featureTag;
        vector_push_back(&featList->features, table);
    }
    else if (isOpticalSize == TRUE)
    {
        ULONG featureSize = sizeof(feature_table);

        feature_table* table = (feature_table*)calloc(1, featureSize);
        if (table == NULL)
            return LF_OUT_OF_MEMORY;

        if (featList->hasGPOSSizeFeature == FALSE)
        {
            // read in the size params (only the first time they all must be the same)
            STREAM_streamSeek(stream, startOfFeatureTable + featureParamsOffset);

            featList->optSize.designSize = STREAM_readUShort(stream);
            featList->optSize.subfamilyID = STREAM_readUShort(stream);
            featList->optSize.subfamilyNameID = STREAM_readUShort(stream);
            featList->optSize.minSize = STREAM_readUShort(stream);
            featList->optSize.maxSize = STREAM_readUShort(stream);

            // The offset to the optical params is supposed to be from the start of each table,
            // but some fonts have it from the start of the feature table list, so this tries to find the
            // right values.
            if ((featList->optSize.subfamilyID != 0) &&
                ((featList->optSize.subfamilyNameID < 256) || (featList->optSize.maxSize < featList->optSize.minSize)))
            {
                DEBUG_LOG_WARNING("attempting to correct bad (offsets to) optical size params");
                STREAM_streamSeek(stream, startOfFeatureTableList + featureParamsOffset);

                featList->optSize.designSize = STREAM_readUShort(stream);
                featList->optSize.subfamilyID = STREAM_readUShort(stream);
                featList->optSize.subfamilyNameID = STREAM_readUShort(stream);
                featList->optSize.minSize = STREAM_readUShort(stream);
                featList->optSize.maxSize = STREAM_readUShort(stream);

                if ((featList->optSize.subfamilyNameID < 256) || (featList->optSize.maxSize < featList->optSize.minSize))
                {
                    DEBUG_LOG_WARNING("optical size params are still bad");
                }
            }

            featList->hasGPOSSizeFeature = TRUE;
        }

        table->FeatureTag = featureTag;
        table->FeatureParams = 0xFFFF;                  // a flag to distinguish between the GPOS size feauture, and a size feature in GSUB tables of some test fonts.
        vector_push_back(&featList->features, table);
    }
    else
    {
        ULONG featureSize = sizeof(feature_table);

        feature_table* table = (feature_table*)calloc(1, featureSize);
        if (table == NULL)
            return LF_OUT_OF_MEMORY;

        table->FeatureTag = featureTag;
        vector_push_back(&featList->features, table);
    }

    return LF_ERROR_OK;
}

/* ============================================================================
    @brief
        The headers of the GSUB and GPOS tables contain offsets to Feature
        List tables that enumerate all the features in a font.  Features in
        a particular FeatureList are not limited to any single script.  A
        featureList contains the entire list of either the GSUB or GPOS
        features that are used to render the glyphs in all the scripts in
        the font.

        The FeatureList table enumerates features in an array of records
        (FeatureRecord) and specifies the total number of features
        (FeatureCount). Every feature must have a FeatureRecord, which
        consists of a FeatureTag that identifies the feature and an offset
        to a Feature table (described next). The FeatureRecord array is
        arranged alphabetically by FeatureTag names.

    @param
        stream    =    pointer to the stream which is pointing to a stream list

        isGPOS    =    boolean value where TRUE is GPOS feature, otherwise it
                       is a GSUB feature.

        tableList =    pointer to table list pointer

    @return
        LF_ERROR value.
============================================================================ */
LF_ERROR Feature_readListTable(LF_STREAM* stream, boolean isGPOS, TABLE_HANDLE* tableList)
{
    size_t tableStart = STREAM_streamPos(stream);
    USHORT i, featureCount = STREAM_readUShort(stream);

    *tableList = NULL;

    feature_list* featList = (feature_list*)calloc(1, sizeof(feature_list));
    if (featList == NULL)
        return LF_OUT_OF_MEMORY;

    LF_ERROR error = vector_init(&featList->features, featureCount, 4);
    if (LF_ERROR_OK != error)
    {
        free(featList);
        return error;
    }

    for(i = 0; i < featureCount; i++)
    {
        TAG featureTag = STREAM_readTag(stream);
        OFFSET offset = STREAM_readOffset(stream);
        size_t currPos = STREAM_streamPos(stream);

        STREAM_streamSeek(stream, tableStart + offset);

        error = Feature_readFeatureTable(stream, featList, featureTag, tableStart, isGPOS);
        if (error != LF_ERROR_OK)
        {
            Feature_deleteTable(featList);
            return error;
        }

        STREAM_streamSeek(stream, currPos);
    }

    *tableList = featList;
    return LF_ERROR_OK;
}

size_t Feature_getDataSize(TABLE_HANDLE hTable)
{
    size_t tableSize = Feature_getListTableSize(hTable);

    feature_list* featList = (feature_list*)hTable;

    for (size_t i = 0; i < featList->features.count; i++)
    {
        tableSize += Feature_getFeatureTableSize((feature_table*)vector_at(&featList->features, i));
    }

    return tableSize;
}

/* ----------------------------------------------------------------------------
    @brief
        parse the passed feature table and write it to the stream.

    @param
        stream    = pointer to the stream to write out the feature table

    @return
        the current stream position

---------------------------------------------------------------------------- */
static size_t Feature_buildFeatureTable(feature_table* table, boolean isGPOS, size_t optSzOffset, LF_STREAM* stream)
{
    ULONG i;
    USHORT count = UTILS_getCount(&table->LookupListIndex);

    if (count != 0)
    {
        STREAM_writeOffset(stream, table->FeatureParams);
        STREAM_writeUShort(stream, count);

        for (i = 0; i < count; i++)
        {
            USHORT index = (USHORT)(intptr_t)vector_at(&table->LookupListIndex, i);
            STREAM_writeUShort(stream, index);
        }
    }
    else
    {
        if (isGPOS == TRUE)
        {
            if (table->FeatureTag == 0x73697A65 /*'size'*/)
            {
                size_t startOfFeatureTable = STREAM_streamPos(stream);

                STREAM_writeOffset(stream, optSzOffset - startOfFeatureTable);
            }
            else
            {
                STREAM_writeOffset(stream, 0);
            }

            STREAM_writeUShort(stream, 0);
        }
    }

    return STREAM_streamPos(stream);
}

BYTE* Feature_buildTable(TABLE_HANDLE hTable, boolean isGPOS, size_t* tableSize)
{
    *tableSize = Feature_getDataSize(hTable);

    BYTE* tableData = (BYTE*)malloc(*tableSize);
    if (tableData == NULL)
        return NULL;

    feature_list* featList = (feature_list*)hTable;

    size_t featureOffset;
    ULONG i;
    LF_STREAM stream;

    size_t offsetToOpticalSizeParams = 0;

    if (featList->hasGPOSSizeFeature == TRUE)
        offsetToOpticalSizeParams = *tableSize - 10;

    STREAM_initMemStream(&stream, tableData, *tableSize);

    STREAM_writeUShort(&stream, (USHORT)featList->features.count);
    featureOffset = STREAM_streamPos(&stream) + (sizeof(TAG) + sizeof(OFFSET)) * featList->features.count;

    for (i = 0; i < featList->features.count; i++)
    {
        feature_table* featureTable = (feature_table*)vector_at(&featList->features, i);
        size_t oldPos;

        STREAM_writeTag(&stream, featureTable->FeatureTag);
        STREAM_writeOffset(&stream, (OFFSET)featureOffset);

        oldPos = STREAM_streamPos(&stream);
        STREAM_streamSeek(&stream, featureOffset);
        featureOffset = Feature_buildFeatureTable(featureTable, isGPOS, offsetToOpticalSizeParams, &stream);
        STREAM_streamSeek(&stream, oldPos);
    }

    if (featList->hasGPOSSizeFeature == TRUE)
    {
        STREAM_streamSeek(&stream, featureOffset);

        STREAM_writeUShort(&stream, (USHORT)featList->optSize.designSize);
        STREAM_writeUShort(&stream, (USHORT)featList->optSize.subfamilyID);
        STREAM_writeUShort(&stream, (USHORT)featList->optSize.subfamilyNameID);
        STREAM_writeUShort(&stream, (USHORT)featList->optSize.minSize);
        STREAM_writeUShort(&stream, (USHORT)featList->optSize.maxSize);
    }

    return tableData;
}

/* ============================================================================
    @brief
        delete the feature list from the system

============================================================================ */
void Feature_deleteTable(TABLE_HANDLE hTable)
{
    feature_list* featList = (feature_list*)hTable;

    if (featList != NULL)
    {
        for (size_t i = 0; i < featList->features.count; i++)
        {
            feature_table* featureTable = (feature_table*)vector_at(&featList->features, i);
            vector_free(&featureTable->LookupListIndex);
            free(featureTable);
        }

        vector_free(&featList->features);
        free(featList);
    }
}


#define PRUNE_FEATURE_TABLE 1

/* ============================================================================

    @desc
        given a lookup index value, remove this from the feature table
        and apply the deltaIndex to lookups values greater than the
        lookupIndex.

    @param
        hTable = pointer to the feature table
        hScript = 
        lookupIndex = index value to remove
        deltaIndex = value to apply to the lookups > lookupIndex.

============================================================================ */
LF_ERROR Feature_removeLookupIndex(TABLE_HANDLE hTable, TABLE_HANDLE hScript, USHORT lookupIndex, SHORT deltaIndex)
{
    LF_ERROR error = LF_ERROR_OK;

    feature_list* featList = (feature_list*)hTable;
    ULONG i, j;

    i = 0;
    while (i < featList->features.count)
    {
        feature_table* featureTable = (feature_table*)vector_at(&featList->features, i);

        j = 0;
        while( j < featureTable->LookupListIndex.count)
        {
            ULONG index = (ULONG)(intptr_t)vector_at(&featureTable->LookupListIndex, j);

            if (index == lookupIndex)
            {
                // remove this one
                vector_erase(&featureTable->LookupListIndex, j);
            }
            else if (index > lookupIndex)
            {
                index += deltaIndex;
                vector_set_data(&featureTable->LookupListIndex, j, (void*)(intptr_t)index);
                j++;
            }
            else
            {
                j++;
            }
        }

#if PRUNE_FEATURE_TABLE
        if ((featureTable->LookupListIndex.count == 0) &&
            !((featureTable->FeatureTag == 0x73697A65 /*'size'*/) && (featureTable->FeatureParams == 0xFFFF)))
        {
            // this table is empty, and can be removed
            vector_free(&featureTable->LookupListIndex);
            free(featureTable);
            vector_erase(&featList->features, i);
            error = Script_removeLookupIndex(hScript, (USHORT)i, -1);

            if (error == LF_EMPTY_TABLE)
            {
                DEBUG_LOG("empty script table");
                return error;
            }
        }
        else
#endif
        {
            i++;
            featureTable->LookupCount = UTILS_getCount(&featureTable->LookupListIndex);
        }
    }

    return error;
}

LF_ERROR Feature_pruneTable(TABLE_HANDLE hTable)
{
    feature_list* featList = (feature_list*)hTable;
    ULONG i;

    i = 0;
    while (i < featList->features.count)
    {
        feature_table* featureTable = (feature_table*)vector_at(&featList->features, i);

        if (featureTable->LookupListIndex.count)
        {
            return LF_ERROR_OK;
        }

        i++;
    }
    return LF_EMPTY_TABLE;
}

void Feature_cleanupLookups(TABLE_HANDLE hTable, TABLE_HANDLE hLookups, boolean isGPOS)
{
    size_t      i, j;

    feature_list* featList = (feature_list*)hTable;
    LF_VECTOR*  feature_list_table = &featList->features;

    UNUSED(isGPOS);

    for (i = 0; i < feature_list_table->count; i++)
    {
        feature_table*    featureTable = (feature_table*)vector_at(feature_list_table, i);
        LF_VECTOR*        lookupIndices = &featureTable->LookupListIndex;

        for (j = 0; j < lookupIndices->count; j++)
        {
            USHORT lookupIndex = (USHORT)(intptr_t)vector_at(lookupIndices, j);
            Lookup_cleanupLookups(hLookups, lookupIndex);
        }
    }
}

/*
    @summary
        go through the feature table in order and examine the lookups and
        keep the glyphs.

    @param
        keepList        :    pointer to glyph ids to keep
        hTable          :    pointer to gsub_header
        featureIndex    :
*/
LF_ERROR Feature_collectGlyphs(GlyphList* keepList, TABLE_HANDLE hTable, USHORT featureIndex)
{
    LF_ERROR        error = LF_INVALID_SUBTABLE;
    gsub_header*    gsub = (gsub_header*)hTable;
    feature_list*   featList = (feature_list*)gsub->FeatureList;
    LF_VECTOR*      feature_list_table = &featList->features;
    feature_table*  featureTable = (feature_table*)vector_at(feature_list_table, featureIndex);

    if (featureTable)
    {
        ULONG i;

        for (i = 0; i < featureTable->LookupListIndex.count; i++)
        {
            USHORT lookupIndex = (USHORT)(intptr_t)vector_at(&featureTable->LookupListIndex, i);
            error = Lookup_collectGlyphs(keepList, hTable, lookupIndex);
        }
    }
    return error;
}
