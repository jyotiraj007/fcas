// Copyright (C) 2014, 2015, 2016 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// cff_core.c

#include "cff_core.h"
#include "cff_core_prv.h"
//lint -esym(528,ISOAdobeNAME) don�t complain if not referenced
#include "cff_data.h"
#include "cff_conversion.h"
#include "utils.h"
#include <math.h>

// Experimental work to actually subset subroutine indexes instead of setting unused entries to no-ops
//#define SUBSET_SUBROUTINES


//
// Functions which start with cff_ are 'public'. All others are local to this file.
//

//
//  Functions to handle INDEXes
//

CFF_ERROR cff_indexInitializeFromBuffer(const BYTE* startOfIndex, cffIndex** createdIndex)
{
    if ((startOfIndex == NULL) || (createdIndex == NULL))
        return CFF_ERR_BAD_PARAM;

    *createdIndex = NULL;

    cffIndex* index = calloc(1, sizeof(cffIndex));
    if (index == NULL)
        return CFF_ERR_MEMORY;

    const BYTE* rawIndexPtr = startOfIndex;

    memset(index, 0, sizeof(cffIndex));

    index->count = SWAP_USHORT((*(cffCard16*)(void*)rawIndexPtr));

    if (index->count == 0)
    {
        index->size = index->size = 2;       // empty index
        *createdIndex = index;
        return CFF_ERR_OK;
    }

    rawIndexPtr += 2;

    index->offSize = *rawIndexPtr;

    if ((index->offSize == 0) || (index->offSize > 4))
    {
        free(index);
        return CFF_ERR_BAD_OFFSET_SIZE;
    }

    rawIndexPtr++;      // now points to beginning of offset array

    LF_ERROR error = vector_init(&index->content, index->count, 4);
    if (error != LF_ERROR_OK)
    {
        free(index);
        return CFF_ERR_MEMORY;
    }

    index->size = 3 /* 2 for count, 1 for offset size */ + ((index->count + 1) * index->offSize);

    const BYTE* dataPtr = startOfIndex + index->size;

    cffOffset curOffset, nextOffset;

    curOffset = 0;
    for (size_t i = 0; i < index->offSize; i++)
        curOffset = (curOffset << 8) + *rawIndexPtr++;

    for (size_t i = 0; i < index->count; i++)
    {
        cffIndexItem* object = malloc(sizeof(cffIndexItem));
        if (object == NULL)
        {
            for (size_t j = 0; j < index->content.count; j++)
            {
                cffIndexItem* x = vector_at(&index->content, j);
                free(x->data);
                free(x);
            }
            vector_delete(&index->content);
            free(index);
            return CFF_ERR_MEMORY;
        }

        nextOffset = 0;
        for (size_t j = 0; j < index->offSize; j++)
        {
            nextOffset = (nextOffset << 8) + *rawIndexPtr++;
        }

        if (nextOffset < curOffset)
        {
            for (size_t j = 0; j < index->content.count; j++)
            {
                cffIndexItem* x = vector_at(&index->content, j);
                free(x->data);
                free(x);
            }
            vector_delete(&index->content);
            free(object);
            free(index);
            return CFF_ERR_BAD_OFFSET_SIZE;
        }

        object->length = nextOffset - curOffset;

        object->data = malloc(object->length*sizeof(BYTE));

        if (object->data == NULL)
        {
            for (size_t j = 0; j < index->content.count; j++)
            {
                cffIndexItem* x = vector_at(&index->content, j);
                free(x->data);
                free(x);
            }
            vector_delete(&index->content);
            free(object);
            free(index);
            return CFF_ERR_MEMORY;
        }

        memcpy(object->data, dataPtr, object->length);

        vector_push_back(&index->content, object);

        curOffset = nextOffset;
        dataPtr += object->length;
        index->size += object->length;
    }

    *createdIndex = index;

    return CFF_ERR_OK;
}

CFF_ERROR cff_indexInitializeWithSize(ULONG size, cffIndex** createdIndex)
{
    if (createdIndex == NULL)
        return CFF_ERR_BAD_PARAM;

    *createdIndex = NULL;

    cffIndex* index = calloc(1, sizeof(cffIndex));
    if (index == NULL)
        return CFF_ERR_MEMORY;

    LF_ERROR error = vector_init(&index->content, size, 4);
    if (error != LF_ERROR_OK)
        free(index);
    else
        *createdIndex = index;

    return (error == LF_ERROR_OK) ? CFF_ERR_OK : CFF_ERR_MEMORY;
}

CFF_ERROR cff_indexCopy(cffIndex* index, cffIndex** createdIndex)
{
    if (createdIndex == NULL)
        return CFF_ERR_BAD_PARAM;

    ULONG count = cff_indexGetCount(index);

    CFF_ERROR cffErr = cff_indexInitializeWithSize(count, createdIndex);
    if (cffErr != CFF_ERR_OK)
        return cffErr;

    for (ULONG i = 0; i < count; i++)
    {
        cffIndexItem* item = cff_indexGetItem(index, i);

        cffErr = cff_indexAppendCopy(*createdIndex, item);
        if (cffErr != CFF_ERR_OK)
        {
            cff_indexDestroy(*createdIndex);
            return cffErr;
        }
    }

    return CFF_ERR_OK;
}

CFF_ERROR cff_indexAppendCopy(cffIndex* index, const cffIndexItem* item)
{
    if (index == NULL)
        return CFF_ERR_INTERNAL;

    cffIndexItem* copy = (cffIndexItem*)malloc(sizeof(cffIndexItem));
    if (copy == NULL)
        return CFF_ERR_MEMORY;

    copy->length = item->length;
    copy->data = (BYTE*)malloc(item->length * sizeof(BYTE));
    if (copy->data == NULL)
    {
        free(copy);
        return CFF_ERR_MEMORY;
    }

    memcpy(copy->data, item->data, item->length);

    LF_ERROR error = vector_push_back(&index->content, (void*)copy);
    if (error != LF_ERROR_OK)
    {
        free(copy->data);
        free(copy);
    }

    index->count++;

    return (error == LF_ERROR_OK) ? CFF_ERR_OK : CFF_ERR_MEMORY;
}

CFF_ERROR cff_indexRemoveItem(cffIndex* index, ULONG which)
{
    if (index == NULL)
        return CFF_ERR_INTERNAL;

    if (which >= index->count)
        return CFF_ERR_BAD_PARAM;

    cffIndexItem* item = (cffIndexItem*)vector_at(&index->content, which);

    free(item->data);
    free(item);

    vector_erase(&index->content, which);

    index->count--;

    return CFF_ERR_OK;
}

CFF_ERROR cff_indexReplaceCopy(cffIndex* index, ULONG which, cffIndexItem* newItem)
{
    if (index == NULL)
        return CFF_ERR_INTERNAL;
    if (newItem == NULL)
        return CFF_ERR_INTERNAL;

    if (which >= index->count)
        return CFF_ERR_BAD_PARAM;

    cffIndexItem* copy = (cffIndexItem*)malloc(sizeof(cffIndexItem));
    if (copy == NULL)
        return CFF_ERR_MEMORY;

    copy->length = newItem->length;
    copy->data = (BYTE*)malloc(newItem->length * sizeof(BYTE));
    if (copy->data == NULL)
    {
        free(copy);
        return CFF_ERR_MEMORY;
    }

    memcpy(copy->data, newItem->data, newItem->length);

    cffIndexItem* item = (cffIndexItem*)vector_at(&index->content, which);
    free(item->data);
    free(item);

    vector_set_data(&index->content, which, newItem);

    return CFF_ERR_OK;
}

void cff_indexDestroy(cffIndex* index)
{
    if (index == NULL)
    {
        DEBUG_LOG_ERROR("NULL pointer to cff_indexDestroy");
        return;
    }

    for (size_t i = 0; i < index->count; i++)
    {
        cffIndexItem* object = vector_at(&index->content, i);
        free(object->data);
        free(object);
    }

    vector_free(&index->content);
    free(index);
}

ULONG cff_indexGetLengthForSingleItemIndex(ULONG itemSize)
{
    if (itemSize == 0)
        return 0;       //error

    LONG offSize;

    if (itemSize < 255)
        offSize = 1;
    else if (itemSize < 65535)
        offSize = 2;
    else if (itemSize < 16777215)
        offSize = 3;
    else
        offSize = 4;

    LONG retVal = sizeof(cffCard16) + sizeof(cffOffSize);   // for the count and the array element size
    retVal += (1 + 1) * offSize;                            // for the offset array
    retVal += (LONG)itemSize;                               // for the item itself
    return retVal;
}

ULONG cff_indexGetLengthForIndexWithSizes(const ULONG* itemSizes, ULONG numItems)
{
    if (numItems == 0)
        return 2;

    ULONG offSize, totalItemsSize = 0;

    for (size_t i = 0; i < numItems; i++)
        totalItemsSize += itemSizes[i];

    if (totalItemsSize < 255)
        offSize = 1;
    else if (totalItemsSize < 65535)
        offSize = 2;
    else if (totalItemsSize < 16777215)
        offSize = 3;
    else
        offSize = 4;

    LONG retVal = sizeof(cffCard16) + sizeof(cffOffSize);   // for the count and the array element size
    retVal += (1 + numItems) * offSize;                     // for the offset array
    retVal += totalItemsSize;                               // for the items

    return retVal;
}

void indexCalcSize(cffIndex* index)
{
    // calculate size needed
    if (index->count == 0)
    {
        index->size = 2;
    }
    else
    {
        if (index->offSize == 0)
        {
            size_t total = 0;
            for (size_t i = 0; i < index->count; i++)
            {
                cffIndexItem* ii = (cffIndexItem*)vector_at(&index->content, i);
                total += ii->length;
            }

            if (total < 255)
                index->offSize = 1;
            else if (total < 65535)
                index->offSize = 2;
            else if (total < 16777215)
                index->offSize = 3;
            else
                index->offSize = 4;
        }

        index->size = sizeof(cffCard16) + sizeof(cffOffSize);  // for the count and the array element size
        index->size += (index->count + 1) * (index->offSize);  // for the offset array

        for (size_t i = 0; i < index->count; i++)
        {
            cffIndexItem* ii = (cffIndexItem*)vector_at(&index->content, i);
            index->size += ii->length;
        }
    }
}

// returns how much space it would take (not how many items)
ULONG cff_indexGetLength(cffIndex* index)
{
    if (index == NULL)
    {
        DEBUG_LOG_ERROR("NULL pointer to cff_indexGetLength");
        return 0;
    }

    if (index->size == 0)
        indexCalcSize(index);

    return index->size;
}

ULONG cff_indexGetCount(const cffIndex* index)
{
    if (index == NULL)
    {
        DEBUG_LOG_ERROR("NULL pointer to cff_indexGetCount");
        return 0;
    }

    return (LONG)index->count;
}

cffIndexItem* cff_indexGetItem(cffIndex* index, ULONG which)
{
    if (index == NULL)
    {
        DEBUG_LOG_ERROR("NULL pointer to cff_indexGetItem");
        return NULL;
    }

    return (cffIndexItem*)vector_at(&index->content, which);
}

LF_ERROR cff_indexAppendToStream(cffIndex* index, LF_STREAM* stream)
{
    if (index == NULL)
        return LF_INVALID_PARAM;
    if (index->size == 0)
        return LF_BAD_FORMAT;

    STREAM_writeCard16(stream, index->count);

    if (index->count != 0)
    {
        STREAM_writeOffSize(stream, index->offSize);

        size_t i, curOffset = 1;

        for (i = 0; i < index->count; i++)
        {
            STREAM_writeCffOffset(stream, curOffset, index->offSize);
            cffIndexItem* ii = (cffIndexItem*)vector_at(&index->content, i);
            curOffset += ii->length;
        }
        STREAM_writeCffOffset(stream, curOffset, index->offSize);

        for (i = 0; i < index->count; i++)
        {
            cffIndexItem* ii = (cffIndexItem*)vector_at(&index->content, i);
            STREAM_writeChunk(stream, ii->data, ii->length);
        }
    }

    return (STREAM_ptrIsValid(stream) ? LF_ERROR_OK : LF_STREAM_OVERRUN);
}

///////////////////////////////////////////////////////////////////////////////////

LF_ERROR cff_mapCffErrorToLfError(CFF_ERROR e)
{
    switch (e)
    {
    case CFF_ERR_OK:
        return LF_ERROR_OK;
    case CFF_ERR_MEMORY:
        return LF_OUT_OF_MEMORY;
    case CFF_ERR_BAD_PARAM:
        return LF_INVALID_PARAM;
    case CFF_ERR_BAD_OPCODE:
    case CFF_ERR_BAD_SUBRSPTR:
    case CFF_ERR_BAD_FORMAT:
        return LF_BAD_FORMAT;
    case CFF_ERR_UNSUPPORTED_FORMAT:
        return LF_UNSUPPORTED;
    case CFF_ERR_BAD_FD_FORMAT:
    case CFF_ERR_BAD_TOP_FORMAT:
    case CFF_ERR_BAD_PRIV_FORMAT:
    case CFF_ERR_BAD_OFFSET_SIZE:
    case CFF_ERR_INTERNAL:
    default:
        return LF_BAD_FORMAT;
    case CFF_ERR_CS_BUF_EXCEEDED:
        return LF_STREAM_OVERRUN;
    }
}

///////////////////////////////////////////////////////////////////////////////////

#define cff_read_buf(cffBuf, off, count, dest) memcpy(dest, cffBuf + off, count)

static BYTE *get_real(BYTE *p, ARGS *args, int argcount)
{
    const char *pattern = "0123456789.EE?-";
    BYTE v, w, string[128];
    int k, count = 0;

    // get the real as a string
    for (;;)
    {
        v = *p++;
        for (k = 0; k < 2; k++)
        {
            if (k == 0) w = v >> 4;
            else      w = v & 0xF;

            string[count++] = pattern[w];
            if (w == 0xc) string[count++] = '-';
            if (w == 0xF) break;
        }
        if (w == 0xF) break;
    }

    args->fval[argcount] = atof((char*)string);
    args->encodedAsFloat[argcount] = TRUE;

    return p;
}

static BYTE nextDictOPCode(BYTE** pdata, LONG* numargs, ARGS *args, const BYTE *ep)
{
    BYTE b0, b1, b2, b3, b4;
    USHORT us;
    SHORT s;
    BYTE *ptr = *pdata;
    LONG val, count = *numargs;

    for (;;)  /* while (1) */
    {
        if (ptr > ep)
            return 0xFF;

        b0 = *ptr++;
        if (b0 < 28)
        {
            *pdata = ptr;
            *numargs = count;
            return b0;
        }
        else if (b0 == 28)
        {
            b1 = *ptr++;
            b2 = *ptr++;
            us = (b1 << 8) | b2;
            s = (SHORT)us;
            args->val[count] = s;
            args->encodedAsFloat[count++] = FALSE;
        }
        else if (b0 == 29)
        {
            b1 = *ptr++;
            b2 = *ptr++;
            b3 = *ptr++;
            b4 = *ptr++;
            val = (b1 << 24) | (b2 << 16) | (b3 << 8) | b4;     //lint !e701
            args->val[count] = val;
            args->encodedAsFloat[count++] = FALSE;
        }
        else if (b0 == 30)
        {
            ptr = get_real(ptr, args, count++);
        }
        else if (32 <= b0 && b0 <= 246)
        {
            val = b0 - 139;
            args->val[count] = val;
            args->encodedAsFloat[count++] = FALSE;
        }
        else if (247 <= b0 && b0 <= 250)
        {
            b1 = *ptr++;
            val = (b0 - 247) * 256 + b1 + 108;
            args->val[count] = val;
            args->encodedAsFloat[count++] = FALSE;
        }
        else if (251 <= b0 && b0 <= 254)
        {
            b1 = *ptr++;
            val = -(b0 - 251) * 256 - b1 - 108;
            args->val[count] = val;
            args->encodedAsFloat[count++] = FALSE;
        }
    }
}

INLINE static LONG int_arg(const ARGS *args, int n)
{
    return ((args->encodedAsFloat[n] == TRUE) ? (LONG)args->fval[n] : args->val[n]);
}

INLINE static double real_arg(const ARGS *args, int n)
{
    return ((args->encodedAsFloat[n] == TRUE) ? args->fval[n] : (double)args->val[n]);
}

static void unloadTopDict(CFFTOPDICT* topdict)
{
    if (topdict)
    {
        free(topdict->BaseFontBlend);
        free(topdict->XUID);
        free(topdict);
    }
}

static CFFTOPDICT* copyTopDict(const CFFTOPDICT* topdict)
{
    CFFTOPDICT* newTopDict = (CFFTOPDICT*)malloc(sizeof(CFFTOPDICT));
    if (newTopDict == NULL)
        return NULL;

    memcpy(newTopDict, topdict, sizeof(CFFTOPDICT));

    if ((topdict->BaseFontBlend != NULL) && (topdict->numBaseFontBlendVals != 0))
    {
        newTopDict->BaseFontBlend = (int*)malloc(topdict->numBaseFontBlendVals*sizeof(int));
        if (newTopDict->BaseFontBlend == NULL)
        {
            free(newTopDict);
            return NULL;
        }

        for (int i = 0; i < topdict->numBaseFontBlendVals; i++)
            newTopDict->BaseFontBlend[i] = topdict->BaseFontBlend[i];
    }

    if ((topdict->XUID != NULL) && (topdict->numXUID != 0))
    {
        newTopDict->XUID = (int*)malloc(topdict->numXUID*sizeof(int));
        if (newTopDict->XUID == NULL)
        {
            free(newTopDict->BaseFontBlend);
            free(newTopDict);
            return NULL;
        }
        for (int i = 0; i < topdict->numXUID; i++)
            newTopDict->XUID[i] = topdict->XUID[i];
    }

    return newTopDict;
}

static CFF_ERROR loadTopDict(BYTE *ptr, LONG size, CFFTOPDICT** topdict)
{
    LONG i, argcount = 0;

    *topdict = NULL;

    if (ptr == 0)
        return CFF_ERR_BAD_PARAM;

    ARGS* args = (ARGS*)calloc(1, sizeof(ARGS));
    if (args == NULL)
        return CFF_ERR_MEMORY;

    // allocate a topdict object
    CFFTOPDICT* newTopDict = (CFFTOPDICT *)calloc(1, sizeof(CFFTOPDICT));
    if (newTopDict == NULL)
    {
        free(args);
        return CFF_ERR_MEMORY;
    }

    // set default values (that are not 0)
    newTopDict->fontmatrix[0] = 0.001;
    newTopDict->fontmatrix[3] = 0.001;
    newTopDict->underlineThickness = 50;
    newTopDict->underlinePosition = -100;
    newTopDict->charstringType = 2;

    BYTE *p = ptr;
    BYTE *ep = ptr + size;

    while (p < ep)
    {
        BYTE opcode = nextDictOPCode(&p, &argcount, args, ep);
        if (opcode == 0xFF)   // bad opcode
        {
            unloadTopDict(newTopDict);
            free(args);
            return CFF_ERR_BAD_TOP_FORMAT;
        }

        switch ((BYTE)opcode)
        {
        case 0:
            newTopDict->version = (cffSID)int_arg(args, 0);
            break;
        case 1:
            newTopDict->Notice = (cffSID)int_arg(args, 0);
            break;
        case 2:
            newTopDict->FullName = (cffSID)int_arg(args, 0);
            break;
        case 3:
            newTopDict->FamilyName = (cffSID)int_arg(args, 0);
            break;
        case 4:
            newTopDict->Weight = (cffSID)int_arg(args, 0);
            break;
        case 5:
            newTopDict->fontbbox[0] = int_arg(args, 0);
            newTopDict->fontbbox[1] = int_arg(args, 1);
            newTopDict->fontbbox[2] = int_arg(args, 2);
            newTopDict->fontbbox[3] = int_arg(args, 3);
            break;
        case 12:
            opcode = *p++;
            switch ((BYTE)opcode)
            {
            case 0:
                newTopDict->copyright = (cffSID)int_arg(args, 0);
                break;
            case 1:
                newTopDict->isFixedPitch = (boolean)int_arg(args, 0);
                break;
            case 2:
                newTopDict->italicAngle = real_arg(args, 0);
                break;
            case 3:
                newTopDict->underlinePosition = int_arg(args, 0);
                break;
            case 4:
                newTopDict->underlineThickness = int_arg(args, 0);
                break;
            case 5:
                newTopDict->PaintType = int_arg(args, 0);
                break;
            case 6:
                newTopDict->charstringType = int_arg(args, 0);
                break;
            case 7:
                for (i = 0; i < 6; i++)
                    newTopDict->fontmatrix[i] = real_arg(args, i);
                newTopDict->nonDefaultMatrix = TRUE;
                break;
            case 8:
                newTopDict->StrokeWidth = real_arg(args, 0);
                break;
            case 20:
                newTopDict->SyntheticBase = int_arg(args, 0);
                break;
            case 21:
                newTopDict->PostScript = (SHORT)int_arg(args, 0);
                break;
            case 22:
                newTopDict->BaseFontName = (SHORT)int_arg(args, 0);
                break;
            case 23:
                newTopDict->numBaseFontBlendVals = argcount;
                if ((newTopDict->numBaseFontBlendVals == 0) || (newTopDict->BaseFontBlend != NULL))
                {
                    // Should not have invalid count or duplicate encodings
                    unloadTopDict(newTopDict);
                    free(args);
                    return CFF_ERR_BAD_TOP_FORMAT;
                }

                newTopDict->BaseFontBlend = (int*)malloc(argcount * sizeof(int));
                if (newTopDict->BaseFontBlend == NULL)
                {
                    unloadTopDict(newTopDict);
                    free(args);
                    return CFF_ERR_MEMORY;
                }

                newTopDict->BaseFontBlend[0] = int_arg(args, 0);

                for (i = 1; i < argcount; i++)
                    newTopDict->BaseFontBlend[i] = int_arg(args, i) + newTopDict->BaseFontBlend[i - 1];
                break;
            case 30: /* ROS */
                newTopDict->ros.Registry = (cffSID)int_arg(args, 0);
                newTopDict->ros.Ordering = (cffSID)int_arg(args, 1);
                newTopDict->ros.Supplement = int_arg(args, 2);
                break;
            case 31:
                newTopDict->CIDFontVersion = real_arg(args, 0);
                break;
            case 32:
                newTopDict->CIDFontRevision = int_arg(args, 0);
                break;
            case 33:
                newTopDict->CIDFontType = int_arg(args, 0);
                break;
            case 34:
                newTopDict->CIDcount = int_arg(args, 0);
                break;
            case 35:
                newTopDict->UIDBase = int_arg(args, 0);
                break;
            case 36:
                newTopDict->FDArrayOffset = int_arg(args, 0);
                break;
            case 37:
                newTopDict->FDSelectOffset = int_arg(args, 0);
                break;
            case 38:
                newTopDict->FDFontName = (cffSID)int_arg(args, 0);
                break;
            default:
                break;
            }
            break;
        case 13:
            newTopDict->UniqueID = int_arg(args, 0);
            break;
        case 14:
            newTopDict->numXUID = argcount;
            if ((newTopDict->numXUID == 0) || (newTopDict->XUID != NULL))
            {
                unloadTopDict(newTopDict);      // Should not have invalid count or duplicate XUID encodings
                free(args);
                return CFF_ERR_BAD_TOP_FORMAT;
            }

            newTopDict->XUID = (int*)malloc(argcount * sizeof(int));
            if (newTopDict->XUID == NULL)
            {
                unloadTopDict(newTopDict);
                free(args);
                return CFF_ERR_MEMORY;
            }

            for (i = 0; i < argcount; i++)
                newTopDict->XUID[i] = int_arg(args, i);
            break;
        case 15:
            newTopDict->charsetOffset = int_arg(args, 0);
            break;
        case 16:
            newTopDict->encodingOffset = int_arg(args, 0);
            break;
        case 17:
            newTopDict->charStringsOffset = int_arg(args, 0);
            break;
        case 18:
            newTopDict->privateDictSize = int_arg(args, 0);
            newTopDict->privateDictOffset = int_arg(args, 1);
            break;
        default:
            break;
        }
        argcount = 0;
    }

    // now divide all elements of the fontmatrix by fontmatrix[0]
    if (newTopDict->nonDefaultMatrix == TRUE)
    {
        for (i = 1; i < 6; i++)
        {
            double d = newTopDict->fontmatrix[i] / newTopDict->fontmatrix[0];
            newTopDict->normalizedMatrix[i] = d;
        }
        newTopDict->normalizedMatrix[0] = 1.0f;
    } // else normalizedMatrix should not be accessed

    free(args);

    *topdict = newTopDict;

    return CFF_ERR_OK;
}

CFF_ERROR cff_encodeTopDict(const CFFTOPDICT* td, BYTE** encodedBuf, ULONG* encodedBufLen)
{
    if (encodedBuf != NULL)
        *encodedBuf = NULL;
    *encodedBufLen = 0;

    // a scratch buffer, not expecting top dict to be more than 1K
    BYTE* buf = calloc(1024, sizeof(BYTE));
    if (buf == NULL)
        return CFF_ERR_MEMORY;

    LF_STREAM tdStream;
    STREAM_initMemStream(&tdStream, buf, 1024);

    // go through the fields of the top dict and put non-default values into the stream

    // ROS must be first if it is a CID
    if (td->ros.Registry != 0)
    {
        STREAM_writeCffIntegerOperand(&tdStream, td->ros.Registry);
        STREAM_writeCffIntegerOperand(&tdStream, td->ros.Ordering);
        STREAM_writeCffIntegerOperand(&tdStream, td->ros.Supplement);
        STREAM_writeByte(&tdStream, 12);
        STREAM_writeByte(&tdStream, 30);
    }

    if (td->version != 0)
    {
        STREAM_writeCffIntegerOperand(&tdStream, (LONG)td->version);
        STREAM_writeByte(&tdStream, 0);
    }
    if (td->Notice != 0)
    {
        STREAM_writeCffIntegerOperand(&tdStream, (LONG)td->Notice);
        STREAM_writeByte(&tdStream, 1);
    }
    if (td->copyright != 0)
    {
        STREAM_writeCffIntegerOperand(&tdStream, (LONG)td->copyright);
        STREAM_writeByte(&tdStream, 12);
        STREAM_writeByte(&tdStream, 0);
    }
    if (td->FullName != 0)
    {
        STREAM_writeCffIntegerOperand(&tdStream, (LONG)td->FullName);
        STREAM_writeByte(&tdStream, 2);
    }
    if (td->FamilyName != 0)
    {
        STREAM_writeCffIntegerOperand(&tdStream, (LONG)td->FamilyName);
        STREAM_writeByte(&tdStream, 3);
    }
    if (td->Weight != 0)
    {
        STREAM_writeCffIntegerOperand(&tdStream, (LONG)td->Weight);
        STREAM_writeByte(&tdStream, 4);
    }
    if (td->isFixedPitch == TRUE)
    {
        STREAM_writeCffIntegerOperand(&tdStream, (LONG)1/* i.e. true */);
        STREAM_writeByte(&tdStream, 12);
        STREAM_writeByte(&tdStream, 1);
    }
    if (fabs(td->italicAngle - 0.0f) > 0.001f)
    {
        STREAM_writeCffRealOperand(&tdStream, (float)td->italicAngle);
        STREAM_writeByte(&tdStream, 12);
        STREAM_writeByte(&tdStream, 2);
    }
    if (td->underlinePosition != -100)
    {
        STREAM_writeCffIntegerOperand(&tdStream, td->underlinePosition);
        STREAM_writeByte(&tdStream, 12);
        STREAM_writeByte(&tdStream, 3);
    }
    if (td->underlineThickness != 50)
    {
        STREAM_writeCffIntegerOperand(&tdStream, td->underlineThickness);
        STREAM_writeByte(&tdStream, 12);
        STREAM_writeByte(&tdStream, 4);
    }
    if (td->PaintType != 0)
    {
        STREAM_writeCffIntegerOperand(&tdStream, td->PaintType);
        STREAM_writeByte(&tdStream, 12);
        STREAM_writeByte(&tdStream, 5);
    }
    if (td->charstringType != 2)
    {
        // should never get here
        STREAM_writeCffIntegerOperand(&tdStream, td->charstringType);
        STREAM_writeByte(&tdStream, 12);
        STREAM_writeByte(&tdStream, 6);
    }
    if (td->nonDefaultMatrix == TRUE)
    {
        for (int i = 0; i < 6; i++)
            STREAM_writeCffRealOperand(&tdStream, (float)td->fontmatrix[i]);
        STREAM_writeByte(&tdStream, 12);
        STREAM_writeByte(&tdStream, 7);
    }
    if (td->UniqueID != 0)
    {
        STREAM_writeCffIntegerOperand(&tdStream, td->UniqueID);
        STREAM_writeByte(&tdStream, 13);
    }
    if ((td->fontbbox[0] != 0) || (td->fontbbox[1] != 0) || (td->fontbbox[2] != 0) || (td->fontbbox[3] != 0))
    {
        STREAM_writeCffIntegerOperand(&tdStream, td->fontbbox[0]);
        STREAM_writeCffIntegerOperand(&tdStream, td->fontbbox[1]);
        STREAM_writeCffIntegerOperand(&tdStream, td->fontbbox[2]);
        STREAM_writeCffIntegerOperand(&tdStream, td->fontbbox[3]);
        STREAM_writeByte(&tdStream, 5);
    }
    if (fabs(td->StrokeWidth - 0.0f) > 0.001)
    {
        STREAM_writeCffRealOperand(&tdStream, (float)td->StrokeWidth);
        STREAM_writeByte(&tdStream, 12);
        STREAM_writeByte(&tdStream, 8);
    }
    if (td->XUID != NULL)
    {
        for (int i = 0; i < td->numXUID; i++)
            STREAM_writeCffIntegerOperand(&tdStream, td->XUID[i]);
        STREAM_writeByte(&tdStream, 14);
    }
    if (td->charsetOffset != 0)
    {
        STREAM_writeCffEncodedOffset(&tdStream, td->charsetOffset);
        STREAM_writeByte(&tdStream, 15);
    }
    if (td->encodingOffset != 0)
    {
        STREAM_writeCffEncodedOffset(&tdStream, td->encodingOffset);
        STREAM_writeByte(&tdStream, 16);
    }
    if (td->charStringsOffset != 0)
    {
        STREAM_writeCffEncodedOffset(&tdStream, td->charStringsOffset);
        STREAM_writeByte(&tdStream, 17);
    }
    if (td->privateDictOffset != 0)
    {
        STREAM_writeCffIntegerOperand(&tdStream, td->privateDictSize);
        STREAM_writeCffEncodedOffset(&tdStream, td->privateDictOffset);
        STREAM_writeByte(&tdStream, 18);
    }
    if (td->SyntheticBase != 0)
    {
        STREAM_writeCffIntegerOperand(&tdStream, td->SyntheticBase);
        STREAM_writeByte(&tdStream, 12);
        STREAM_writeByte(&tdStream, 20);
    }
    if (td->PostScript != 0)
    {
        STREAM_writeCffIntegerOperand(&tdStream, td->PostScript);
        STREAM_writeByte(&tdStream, 12);
        STREAM_writeByte(&tdStream, 21);
    }
    if (td->BaseFontName != 0)
    {
        STREAM_writeCffIntegerOperand(&tdStream, td->BaseFontName);
        STREAM_writeByte(&tdStream, 12);
        STREAM_writeByte(&tdStream, 22);
    }
    if (td->BaseFontBlend != NULL)
    {
        STREAM_writeCffIntegerOperand(&tdStream, td->BaseFontBlend[0]);
        for (int i = 1; i < td->numBaseFontBlendVals; i++)
            STREAM_writeCffIntegerOperand(&tdStream, td->BaseFontBlend[i] - td->BaseFontBlend[i - 1]);
        STREAM_writeByte(&tdStream, 12);
        STREAM_writeByte(&tdStream, 23);
    }

    // CID related fields
    if (td->CIDFontVersion != 0)
    {
        STREAM_writeCffRealOperand(&tdStream, (float)td->CIDFontVersion);
        STREAM_writeByte(&tdStream, 12);
        STREAM_writeByte(&tdStream, 31);
    }
    if (td->CIDFontRevision != 0)
    {
        STREAM_writeCffIntegerOperand(&tdStream, td->CIDFontRevision);
        STREAM_writeByte(&tdStream, 12);
        STREAM_writeByte(&tdStream, 32);
    }
    if (td->CIDFontType != 0)
    {
        STREAM_writeCffIntegerOperand(&tdStream, td->CIDFontType);
        STREAM_writeByte(&tdStream, 12);
        STREAM_writeByte(&tdStream, 33);
    }
    if (td->CIDcount > 0 && td->CIDcount != 8720)
    {
        STREAM_writeCffIntegerOperand(&tdStream, td->CIDcount);
        STREAM_writeByte(&tdStream, 12);
        STREAM_writeByte(&tdStream, 34);
    }
    if (td->UIDBase != 0)
    {
        STREAM_writeCffIntegerOperand(&tdStream, td->UIDBase);
        STREAM_writeByte(&tdStream, 12);
        STREAM_writeByte(&tdStream, 35);
    }

    if (td->FDFontName != 0)
    {
        STREAM_writeCffIntegerOperand(&tdStream, (LONG)td->FDFontName);
        STREAM_writeByte(&tdStream, 12);
        STREAM_writeByte(&tdStream, 38);
    }
    if (td->FDArrayOffset != 0)
    {
        STREAM_writeCffEncodedOffset(&tdStream, td->FDArrayOffset);
        STREAM_writeByte(&tdStream, 12);
        STREAM_writeByte(&tdStream, 36);
    }
    if (td->FDSelectOffset != 0)
    {
        STREAM_writeCffEncodedOffset(&tdStream, td->FDSelectOffset);
        STREAM_writeByte(&tdStream, 12);
        STREAM_writeByte(&tdStream, 37);
    }

    if (!STREAM_isValid(tdStream))
    {
        // an indication that the initial 1024 size was not enough
        free(buf);
        return CFF_ERR_INTERNAL;
    }

    *encodedBufLen = (ULONG)STREAM_streamPos(&tdStream);

    if (encodedBuf != NULL)
    {
        *encodedBuf = realloc(buf, *encodedBufLen);
        if (*encodedBuf == NULL)
            return CFF_ERR_MEMORY;
    }
    else
        free(buf);      // client just wanted the size

    return CFF_ERR_OK;
}

static CFF_ERROR loadFDSelect(const BYTE* rawcffBuf, CFF_TAB *cffTab)
{
    CFFTOPDICT *td = cffTab->mainTopDict;

    cffTab->fdSelect.fdIndexArray = (cffCard8*)calloc(cffTab->numGlyphs, sizeof(cffCard8));
    if (cffTab->fdSelect.fdIndexArray == NULL)
        return CFF_ERR_MEMORY;

    LONG curOffset = td->FDSelectOffset;

    // get the format
    cff_read_buf(rawcffBuf, curOffset++, 1, &cffTab->fdSelect.origFormat);

    if ((cffTab->fdSelect.origFormat != 0) && (cffTab->fdSelect.origFormat != 3))
        return CFF_ERR_BAD_FD_FORMAT;

    if (cffTab->fdSelect.origFormat == 0)
    {
        // format 0 just has a byte for each glyph
        memcpy(cffTab->fdSelect.fdIndexArray, rawcffBuf + curOffset, cffTab->numGlyphs);
    }
    else
    {
        // Format 3 has a number of Range3 items

        // Get number of ranges
        USHORT numRanges;
        cff_read_buf(rawcffBuf, curOffset, 2, (BYTE *)&numRanges);
        curOffset += 2;
        numRanges = SWAPW(numRanges);

        // Read the first glyph index of first range (must be zero)
        USHORT firstGID;
        cff_read_buf(rawcffBuf, curOffset, 2, (BYTE *)&firstGID);
        curOffset += 2;
        firstGID = SWAPW(firstGID);

        if (firstGID != 0)
        {
            free(cffTab->fdSelect.fdIndexArray);
            cffTab->fdSelect.fdIndexArray = NULL;
            return CFF_ERR_BAD_FD_FORMAT;
        }

        // Read fid for the first range
        cffCard8 fid;
        cff_read_buf(rawcffBuf, curOffset++, 1, &fid);

        for (size_t i = 0; i < numRanges; i++)
        {
            USHORT nextFirstGID;
            cff_read_buf(rawcffBuf, curOffset, 2, (BYTE *)&nextFirstGID);
            curOffset += 2;
            nextFirstGID = SWAPW(nextFirstGID);

            for (size_t j = firstGID; j < nextFirstGID; j++)
                cffTab->fdSelect.fdIndexArray[j] = fid;

            cff_read_buf(rawcffBuf, curOffset++, 1, &fid);
            firstGID = nextFirstGID;
        }

#if 1// debug
        cff_read_buf(rawcffBuf, curOffset, 2, (BYTE *)&firstGID);
        firstGID = SWAPW(firstGID);
        if (firstGID != cffTab->numGlyphs)
        {
            DEBUG_LOG_ERROR("incorrect FD Select sentinel");
        }
#endif
    }

    return CFF_ERR_OK;
}

static CFF_ERROR encodeFDSelect(const LF_MAP* charStringMap, const LF_MAP* fdMap, BYTE** encodedFDSelect, LONG* encodedFDSelectSize)
{
    cffAnalyzedCharstring* acs;

    // get the fid of the first glyph
    acs = (cffAnalyzedCharstring*)map_at(charStringMap, (void*)0);
    cffCard8 lastFDID = (cffCard8)(intptr_t)map_at(fdMap, (void*)(intptr_t)acs->fdi);

    LONG numGlyphs = (LONG)map_size(charStringMap);
    LONG i = -1;
    ULONG numRanges = 0;

    while (i < numGlyphs)
    {
        cffCard8 c8 = lastFDID;
        do
        {
            i++;

            if (i < numGlyphs)
            {
                acs = (cffAnalyzedCharstring*)map_at(charStringMap, (void*)(intptr_t)i);
                c8 = (cffCard8)(intptr_t)map_at(fdMap, (void*)(intptr_t)acs->fdi);
            }
        } while ((c8 == lastFDID) && (i < numGlyphs));

        lastFDID = c8;
        numRanges++;
    }

    LONG format0Size = 1 + numGlyphs;
    LONG format3Size = sizeof(cffCard8) /*format*/ + 2 * sizeof(cffCard16) /*nRanges and sentinel*/ + numRanges * (sizeof(cffCard16) + sizeof(cffCard8)) /*ranges*/;

    if (format0Size <= format3Size)
    {
        // create a format 0 FDSelect which has one byte for the format and a byte for each glyph
        *encodedFDSelectSize = format0Size;

        *encodedFDSelect = (BYTE*)malloc(*encodedFDSelectSize * sizeof(BYTE));
        if (*encodedFDSelect == NULL)
            return CFF_ERR_MEMORY;

        (*encodedFDSelect)[0] = 0;     // format 0

        // fill in the FDselect by using the map created above to look up the new index for each glyph
        for (i = 0; i < numGlyphs; i++)
        {
            acs = (cffAnalyzedCharstring*)map_at(charStringMap, (void*)(intptr_t)i);
            cffCard8 c8 = (cffCard8)(intptr_t)map_at(fdMap, (void*)(intptr_t)acs->fdi);
            (*encodedFDSelect)[i + 1] = (BYTE)c8;
        }
    }
    else
    {
        // create a format 3 FDSelect
        *encodedFDSelectSize = format3Size;

        *encodedFDSelect = (BYTE*)malloc(*encodedFDSelectSize * sizeof(BYTE));
        if (*encodedFDSelect == NULL)
            return CFF_ERR_MEMORY;

        (*encodedFDSelect)[0] = 3;                          // format 3
        (*encodedFDSelect)[1] = (BYTE)(numRanges >> 8);     // range count
        (*encodedFDSelect)[2] = (BYTE)(numRanges & 0xff);   // range count

        BYTE* fdsPtr = &(*encodedFDSelect)[3];

        cffCard8 curFDI, rangeFDI;
        LONG index = 0;

        while (index < numGlyphs)
        {
            *fdsPtr++ = (BYTE)(index >> 8);
            *fdsPtr++ = (BYTE)(index & 0xff);

            acs = (cffAnalyzedCharstring*)map_at(charStringMap, (void*)(intptr_t)index);
            curFDI = rangeFDI = (cffCard8)(intptr_t)map_at(fdMap, (void*)(intptr_t)acs->fdi);

            do
            {
                index++;
                if (index < numGlyphs)
                {
                    acs = (cffAnalyzedCharstring*)map_at(charStringMap, (void*)(intptr_t)index);
                    curFDI = (cffCard8)(intptr_t)map_at(fdMap, (void*)(intptr_t)acs->fdi);
                }
            } while ((curFDI == rangeFDI) && (index < numGlyphs));

            *fdsPtr++ = (BYTE)rangeFDI;
        }

        *fdsPtr++ = (BYTE)(numGlyphs >> 8);     // sentinel
        *fdsPtr   = (BYTE)(numGlyphs & 0xff);   // sentinel
    }

    return CFF_ERR_OK;
}

static CFF_ERROR loadCharSet(BYTE* cffBuf, CFF_TAB *cffTab)
{
    cffTab->charset = (cffSID*)calloc(cffTab->numGlyphs, sizeof(cffSID));
    if (cffTab->charset == NULL)
        return CFF_ERR_MEMORY;

    if (cffTab->mainTopDict->charsetOffset < 3)
    {
        // use predefined charset
        const cffSID *ranges;
        cffSID first, last;
        int i, k;
        switch (cffTab->mainTopDict->charsetOffset)
        {
        default:
        case 0:
            ranges = ISOAdobeSID;
            break;
        case 1:
            ranges = ExpertSID;
            break;
        case 2:
            ranges = ExpertSubsetSID;
            break;
        }

        i = 1; /* glyph index */
        k = 0; /* range index */
        first = ranges[k];
        last = ranges[k + 1];
        while (first != 0 && last != 0)
        {
            for (int j = first; j <= last && i < cffTab->numGlyphs; j++)
                cffTab->charset[i++] = (cffSID)j;

            k += 2;
            first = ranges[k];
            last = ranges[k + 1];
        }
    }
    else /* read charset data */
    {
        BYTE format;
        ULONG offset = (ULONG)cffTab->mainTopDict->charsetOffset;

        cff_read_buf(cffBuf, offset, 1, &format);
        offset += 1;

        if (format == 0)
        {
            USHORT i = 1, *sidPtr;

            sidPtr = (USHORT*)(void*)(cffBuf + cffTab->mainTopDict->charsetOffset + 1);
            while (i < cffTab->numGlyphs)
            {
                cffSID s = SWAPW((*sidPtr));
                cffTab->charset[i++] = s;
                sidPtr++;
            }
        }
        else if (format == 1 || format == 2)
        {
            USHORT i, nLeft;
            cffSID first;

            i = 1; /* missing glyph is omitted */
            while (i < cffTab->numGlyphs)
            {
                cff_read_buf(cffBuf, offset, 2, (BYTE *)&first);
                first = SWAPW(first);
                offset += 2;

                if (format == 1)
                {
                    BYTE bLeft;
                    cff_read_buf(cffBuf, offset, 1, &bLeft);
                    nLeft = (USHORT)bLeft;
                    offset += 1;
                }
                else /* format 2 */
                {
                    cff_read_buf(cffBuf, offset, 2, (BYTE *)&nLeft);
                    nLeft = SWAPW(nLeft);   /* nLeft stored in 2 bytes */
                    offset += 2;
                }
                for (USHORT j = first; j <= first + nLeft && i < cffTab->numGlyphs; j++)
                    cffTab->charset[i++] = j;
            }
        } /* else format 1 or 2 */
    } /* else read charset data */

    return CFF_ERR_OK;
}

CFF_ERROR cff_encodeCharset(const cffSID* charset, ULONG count, BYTE** encodedCharset, LONG* encodedCharsetSize)
{
    ULONG i, numRanges = 0, longestSequence = 0;
    ULONG curSeqLen = 1;

    // look for strings of sequential sids
    for (i = 2; i < count; i++)
    {
        if (charset[i] == charset[i - 1] + 1)
            curSeqLen++;
        else
        {
            numRanges++;
            if (curSeqLen > longestSequence)
                longestSequence = curSeqLen;
            curSeqLen = 1;
        }
    }
    if ((curSeqLen != 1) || (charset[i - 1] != charset[i - 2] + 1))
    {
        numRanges++;
        if (curSeqLen > longestSequence)
            longestSequence = curSeqLen;
    }

    ULONG format0Size = (ULONG)(1 + (sizeof(cffSID) * (count - 1)));
    ULONG format1Size = 0, format2Size = 0;

    if (longestSequence - 1 < 256)
        format1Size = (ULONG)(1 + (numRanges * (sizeof(cffSID) + sizeof(cffCard8))));   // we can use format 1
    else
        format2Size = (ULONG)(1 + (numRanges * (sizeof(cffSID) + sizeof(cffCard16))));  // we have to use format 2

    if ((format1Size != 0) && (format1Size < format0Size))
    {
        // encode as Format 1
        *encodedCharsetSize = format1Size;

        *encodedCharset = (BYTE*)malloc(*encodedCharsetSize *sizeof(BYTE));
        if (*encodedCharset == NULL)
            return CFF_ERR_MEMORY;

        (*encodedCharset)[0] = 1;

        BYTE* charSetPtr = &(*encodedCharset)[1];
        ULONG index = 1;

        while (index < count)
        {
            *charSetPtr++ = (BYTE)(charset[index] >> 8);
            *charSetPtr++ = (BYTE)(charset[index] & 0xff);

            index++;

            ULONG numLeft = 0;

            while ((index != count) && (charset[index] == charset[index - 1] + 1))
            {
                numLeft++;
                index++;
            }

            *charSetPtr++ = (BYTE)(numLeft);
        }
    }
    else if ((format2Size != 0) && (format2Size < format0Size))
    {
        // encode as Format 2
        *encodedCharsetSize = format2Size;

        *encodedCharset = (BYTE*)malloc(*encodedCharsetSize *sizeof(BYTE));
        if (*encodedCharset == NULL)
            return CFF_ERR_MEMORY;

        (*encodedCharset)[0] = 2;

        BYTE* charSetPtr = &(*encodedCharset)[1];
        ULONG index = 1;

        while (index < count)
        {
            *charSetPtr++ = (BYTE)(charset[index] >> 8);
            *charSetPtr++ = (BYTE)(charset[index] & 0xff);

            index++;

            ULONG numLeft = 0;

            while ((index != count) && (charset[index] == charset[index - 1] + 1))
            {
                numLeft++;
                index++;
            }

            *charSetPtr++ = (BYTE)((numLeft) >> 8);
            *charSetPtr++ = (BYTE)((numLeft) & 0xff);
        }
    }
    else
    {
        // encode as Format 0, which is a byte for the format plus nGlyphs-1 SIDs
        *encodedCharsetSize = format0Size;

        *encodedCharset = (BYTE*)malloc(*encodedCharsetSize *sizeof(BYTE));
        if (*encodedCharset == NULL)
            return CFF_ERR_MEMORY;

        (*encodedCharset)[0] = 0;

        BYTE* charSetPtr = &(*encodedCharset)[1];
        for (i = 1; i < count; i++)
        {
            *charSetPtr++ = (BYTE)(charset[i] >> 8);
            *charSetPtr++ = (BYTE)(charset[i] & 0xff);
        }
    }

    return CFF_ERR_OK;
}

static void unloadPrivateDict(PRIVATEDICT *pd)
{
    if (pd != NULL)
    {
        if (pd->BlueValues != NULL)
        {
            free(pd->BlueValues);
            pd->BlueValues = NULL;
        }
        if (pd->OtherBlues != NULL)
        {
            free(pd->OtherBlues);
            pd->OtherBlues = NULL;
        }
        if (pd->FamilyBlues != NULL)
        {
            free(pd->FamilyBlues);
            pd->FamilyBlues = NULL;
        }
        if (pd->FamilyOtherBlues != NULL)
        {
            free(pd->FamilyOtherBlues);
            pd->FamilyOtherBlues = NULL;
        }
        if (pd->StemSnapH != NULL)
        {
            free(pd->StemSnapH);
            pd->StemSnapH = NULL;
        }
        if (pd->StemSnapV != NULL)
        {
            free(pd->StemSnapV);
            pd->StemSnapV = NULL;
        }
    }
}

static CFF_ERROR loadPrivateDict(BYTE *ptr, LONG size, PRIVATEDICT *privatedict)
{
    LONG argcount = 0;
    BYTE opcode;
    BYTE *p = ptr;
    BYTE *ep = ptr + size;
    int i;
    CFF_ERROR retVal = CFF_ERR_OK;

    ARGS* args = (ARGS*)calloc(1, sizeof(ARGS));
    if (args == NULL)
        return CFF_ERR_MEMORY;

    memset(privatedict, 0, sizeof(PRIVATEDICT));

    // set default values (page 22 of CFF spec.), pointers in object NULL'd by above calloc
    privatedict->BlueScale = 0.039625;
    privatedict->BlueShift = 7;
    privatedict->BlueFuzz = 1;
    privatedict->ForceBold = FALSE;
    privatedict->LanguageGroup = 0;
    privatedict->ExpansionFactor = 0.06;
    privatedict->initialRandomSeed = 0;
    privatedict->defaultwidthX = 0.0f;
    privatedict->nominalwidthX = 0.0f;

    while ((p < ep) && (CFF_ERR_OK == retVal))
    {
        opcode = nextDictOPCode(&p, &argcount, args, ep);

        switch (opcode)
        {
        case 6:
            {
                privatedict->numBlueValues = argcount;
                if ((privatedict->numBlueValues == 0) || (privatedict->BlueValues != NULL))
                    retVal = CFF_ERR_BAD_PRIV_FORMAT; // Should not have invalid count or duplicate encodings
                else
                {
                    privatedict->BlueValues = (int*)malloc(argcount * sizeof(int));
                    if (privatedict->BlueValues == NULL)
                        retVal = CFF_ERR_MEMORY;
                    else
                    {
                        privatedict->BlueValues[0] = int_arg(args, 0);

                        for (i = 1; i < argcount; i++)
                            privatedict->BlueValues[i] = int_arg(args, i) + privatedict->BlueValues[i - 1];
                    }
                }
            }
            break;
        case 7:
            privatedict->numOtherBlues = argcount;

            if ((privatedict->numOtherBlues == 0) || (privatedict->OtherBlues != NULL))
                retVal = CFF_ERR_BAD_PRIV_FORMAT;
            else
            {
                privatedict->OtherBlues = (int*)malloc(argcount * sizeof(int));
                if (privatedict->OtherBlues == NULL)
                    retVal = CFF_ERR_MEMORY;
                else
                {
                    privatedict->OtherBlues[0] = int_arg(args, 0);
                    for (i = 1; i < argcount; i++)
                        privatedict->OtherBlues[i] = int_arg(args, i) + privatedict->OtherBlues[i - 1];
                }
            }
            break;
        case 8:
            privatedict->numFamilyBlues = argcount;

            if ((privatedict->numFamilyBlues == 0) || (privatedict->FamilyBlues != NULL))
                retVal = CFF_ERR_BAD_PRIV_FORMAT;
            else
            {
                privatedict->FamilyBlues = (int*)malloc(argcount * sizeof(int));
                if (privatedict->FamilyBlues == NULL)
                    retVal = CFF_ERR_MEMORY;
                else
                {
                    privatedict->FamilyBlues[0] = int_arg(args, 0);
                    for (i = 1; i < argcount; i++)
                        privatedict->FamilyBlues[i] = int_arg(args, i) + privatedict->FamilyBlues[i - 1];
                }
            }
            break;
        case 9:
            privatedict->numFamilyOtherBlues = argcount;

            if ((privatedict->numFamilyOtherBlues == 0) || (privatedict->FamilyOtherBlues != NULL))
                retVal = CFF_ERR_BAD_PRIV_FORMAT;
            else
            {
                privatedict->FamilyOtherBlues = (int*)malloc(argcount * sizeof(int));
                if (privatedict->FamilyOtherBlues == NULL)
                    retVal = CFF_ERR_MEMORY;
                else
                {
                    privatedict->FamilyOtherBlues[0] = int_arg(args, 0);
                    for (i = 1; i < argcount; i++)
                        privatedict->FamilyOtherBlues[i] = int_arg(args, i) + privatedict->FamilyOtherBlues[i - 1];
                }
            }
            break;
        case 10:
            privatedict->StdHW = real_arg(args, 0);
            break;
        case 11:
            privatedict->StdVW = real_arg(args, 0);
            break;
        case 12:
            opcode = *p++;

            switch (opcode)
            {
            case 9:
                privatedict->BlueScale = real_arg(args, 0);
                break;
            case 10:
                privatedict->BlueShift = real_arg(args, 0);
                break;
            case 11:
                privatedict->BlueFuzz = real_arg(args, 0);
                break;
            case 12:
                privatedict->numStemSnapH = argcount;

                if ((privatedict->numStemSnapH == 0) || (privatedict->StemSnapH != NULL))
                    retVal = CFF_ERR_BAD_PRIV_FORMAT;
                else
                {
                    privatedict->StemSnapH = (int*)malloc(argcount * sizeof(int));
                    if (privatedict->StemSnapH == NULL)
                        retVal = CFF_ERR_MEMORY;
                    else
                    {
                        privatedict->StemSnapH[0] = int_arg(args, 0);
                        for (i = 1; i < argcount; i++)
                            privatedict->StemSnapH[i] = int_arg(args, i) + privatedict->StemSnapH[i - 1];
                    }
                }
                break;
            case 13:
                privatedict->numStemSnapV = argcount;

                if ((privatedict->numStemSnapV == 0) || (privatedict->StemSnapV != NULL))
                    retVal = CFF_ERR_BAD_PRIV_FORMAT;
                else
                {
                    privatedict->StemSnapV = (int*)malloc(argcount * sizeof(int));
                    if (privatedict->StemSnapV == NULL)
                        retVal = CFF_ERR_MEMORY;
                    else
                    {
                        privatedict->StemSnapV[0] = int_arg(args, 0);
                        for (i = 1; i < argcount; i++)
                            privatedict->StemSnapV[i] = int_arg(args, i) + privatedict->StemSnapV[i - 1];
                    }
                }
                break;
            case 14:
                {
                LONG temp = int_arg(args, 0);
                privatedict->ForceBold = (temp == 0) ? FALSE : TRUE;
                }
                break;
            case 17:
                privatedict->LanguageGroup = int_arg(args, 0);
                break;
            case 18:
                privatedict->ExpansionFactor = real_arg(args, 0);
                break;
            case 19:
                privatedict->initialRandomSeed = real_arg(args, 0);
                break;
             default:
                 DEBUG_LOG_VALUE("skipping unknown opcode 12 ", opcode);
            }
            break;
        case 19:
            privatedict->subrsoff = int_arg(args, 0);
            break;
        case 20:
            privatedict->defaultwidthX = real_arg(args, 0);
            break;
        case 21:
            privatedict->nominalwidthX = real_arg(args, 0);
            break;
        default:
            retVal = CFF_ERR_BAD_PRIV_FORMAT;
        }

        argcount = 0;
    }

    if (retVal != CFF_ERR_OK)
        unloadPrivateDict(privatedict);

    free(args);

    return retVal;
}

static CFF_ERROR encodePrivateDict(const PRIVATEDICT* pd, BYTE** encodedBuf, LONG* encodedBufLen)
{
    if (encodedBuf != NULL)
        *encodedBuf = NULL;
    *encodedBufLen = 0;

    // a scratch buffer, not expecting private dict to be more than 1K
    BYTE* buf = calloc(1024, sizeof(BYTE));
    if (buf == NULL)
        return CFF_ERR_MEMORY;

    size_t i;
    LF_STREAM pdStream;
    STREAM_initMemStream(&pdStream, buf, 1024);

    // go through the fields of the private dict and put non-default values into the stream
    if (pd->BlueValues != NULL)
    {
        STREAM_writeCffIntegerOperand(&pdStream, pd->BlueValues[0]);
        for (i = 1; i < (size_t)pd->numBlueValues; i++)
            STREAM_writeCffIntegerOperand(&pdStream, pd->BlueValues[i] - pd->BlueValues[i - 1]);
        STREAM_writeByte(&pdStream, 6);
    }
    if (pd->OtherBlues != NULL)
    {
        STREAM_writeCffIntegerOperand(&pdStream, pd->OtherBlues[0]);
        for (i = 1; i < (size_t)pd->numOtherBlues; i++)
            STREAM_writeCffIntegerOperand(&pdStream, pd->OtherBlues[i] - pd->OtherBlues[i - 1]);
        STREAM_writeByte(&pdStream, 7);
    }
    if (pd->FamilyBlues != NULL)
    {
        STREAM_writeCffIntegerOperand(&pdStream, pd->FamilyBlues[0]);
        for (i = 1; i < (size_t)pd->numFamilyBlues; i++)
            STREAM_writeCffIntegerOperand(&pdStream, pd->FamilyBlues[i] - pd->FamilyBlues[i - 1]);
        STREAM_writeByte(&pdStream, 8);
    }
    if (pd->FamilyOtherBlues != NULL)
    {
        STREAM_writeCffIntegerOperand(&pdStream, pd->FamilyOtherBlues[0]);
        for (i = 1; i < (size_t)pd->numFamilyOtherBlues; i++)
            STREAM_writeCffIntegerOperand(&pdStream, pd->FamilyOtherBlues[i] - pd->FamilyOtherBlues[i - 1]);
        STREAM_writeByte(&pdStream, 9);
    }
    if (fabs(pd->BlueScale - 0.039625f) > 0.001f)
    {
        STREAM_writeCffRealOperand(&pdStream, (float)pd->BlueScale);
        STREAM_writeByte(&pdStream, 12);
        STREAM_writeByte(&pdStream, 9);
    }
    if (fabs(pd->BlueShift - 7.0f) > 0.001f)
    {
        STREAM_writeCffRealOperand(&pdStream, (float)pd->BlueShift);
        STREAM_writeByte(&pdStream, 12);
        STREAM_writeByte(&pdStream, 10);
    }
    if (fabs(pd->BlueFuzz - 1.0f) > 0.001f)
    {
        STREAM_writeCffRealOperand(&pdStream, (float)pd->BlueFuzz);
        STREAM_writeByte(&pdStream, 12);
        STREAM_writeByte(&pdStream, 11);
    }
    if (fabs(pd->StdHW - 0.0f) > 0.001f)
    {
        STREAM_writeCffRealOperand(&pdStream, (float)pd->StdHW);
        STREAM_writeByte(&pdStream, 10);
    }
    if (fabs(pd->StdVW - 0.0f) > 0.001f)
    {
        STREAM_writeCffRealOperand(&pdStream, (float)pd->StdVW);
        STREAM_writeByte(&pdStream, 11);
    }
    if (pd->StemSnapH != NULL)
    {
        STREAM_writeCffIntegerOperand(&pdStream, pd->StemSnapH[0]);
        for (i = 1; i < (size_t)pd->numStemSnapH; i++)
            STREAM_writeCffIntegerOperand(&pdStream, pd->StemSnapH[i] - pd->StemSnapH[i - 1]);
        STREAM_writeByte(&pdStream, 12);
        STREAM_writeByte(&pdStream, 12);
    }
    if (pd->StemSnapV != NULL)
    {
        STREAM_writeCffIntegerOperand(&pdStream, pd->StemSnapV[0]);
        for (i = 1; i < (size_t)pd->numStemSnapV; i++)
            STREAM_writeCffIntegerOperand(&pdStream, pd->StemSnapV[i] - pd->StemSnapV[i - 1]);
        STREAM_writeByte(&pdStream, 12);
        STREAM_writeByte(&pdStream, 13);
    }
    if (pd->ForceBold == TRUE)
    {
        STREAM_writeCffIntegerOperand(&pdStream, 1/* i.e TRUE */);
        STREAM_writeByte(&pdStream, 12);
        STREAM_writeByte(&pdStream, 14);
    }
    if (pd->LanguageGroup != 0)
    {
        STREAM_writeCffIntegerOperand(&pdStream, pd->LanguageGroup);
        STREAM_writeByte(&pdStream, 12);
        STREAM_writeByte(&pdStream, 17);
    }
    if (fabs(pd->ExpansionFactor - 0.06f) > 0.001f)
    {
        STREAM_writeCffRealOperand(&pdStream, (float)pd->ExpansionFactor);
        STREAM_writeByte(&pdStream, 12);
        STREAM_writeByte(&pdStream, 18);
    }
    if (fabs(pd->initialRandomSeed - 0.0f) > 0.001f)
    {
        STREAM_writeCffRealOperand(&pdStream, (float)pd->initialRandomSeed);
        STREAM_writeByte(&pdStream, 12);
        STREAM_writeByte(&pdStream, 19);
    }
    if (pd->subrsoff != 0)
    {
        STREAM_writeCffEncodedOffset(&pdStream, pd->subrsoff);
        STREAM_writeByte(&pdStream, 19);
    }

    STREAM_writeCffRealOperand(&pdStream, (float)pd->defaultwidthX);
    STREAM_writeByte(&pdStream, 20);

    STREAM_writeCffRealOperand(&pdStream, (float)pd->nominalwidthX);
    STREAM_writeByte(&pdStream, 21);

    if (!STREAM_isValid(pdStream))
    {
        // an indication that the initial 1024 size was not enough
        free(buf);
        return CFF_ERR_INTERNAL;
    }

    *encodedBufLen = (LONG)STREAM_streamPos(&pdStream);

    if (encodedBuf != NULL)
    {
        *encodedBuf = realloc(buf, *encodedBufLen);
        if (*encodedBuf == NULL)
            return CFF_ERR_MEMORY;
    }
    else
        free(buf);

    return CFF_ERR_OK;
}

CFF_ERROR cff_createPrivateDict(boolean isAsian, LONG defaultWidth, LONG nominalWidth,
                                BYTE** encodedPrivDict, LONG* encodedPrivDictSize)
{
    PRIVATEDICT* newPrivDict = (PRIVATEDICT*)calloc(1, sizeof(PRIVATEDICT));
    if (newPrivDict == NULL)
        return CFF_ERR_MEMORY;

    // set default values
    newPrivDict->BlueScale = 0.039625;
    newPrivDict->BlueShift = 7.0;
    newPrivDict->BlueFuzz = 1.0;
    newPrivDict->ForceBold = FALSE;         // (redundant)
    newPrivDict->LanguageGroup = 0;         // (redundant)
    newPrivDict->ExpansionFactor = 0.06;
    newPrivDict->initialRandomSeed = 0.0;   // (redundant)

    // set values
    if (isAsian == TRUE)
        newPrivDict->LanguageGroup = 1;
    newPrivDict->defaultwidthX = (double)defaultWidth;
    newPrivDict->nominalwidthX = (double)nominalWidth;

    CFF_ERROR cffErr = encodePrivateDict(newPrivDict, encodedPrivDict, encodedPrivDictSize);

    free(newPrivDict);

    return cffErr;
}

static CFF_ERROR loadFDArray(BYTE* rawCffBuf, CFF_TAB *cffTab)
{
    // read the FD index
    CFF_ERROR cffErr = cff_indexInitializeFromBuffer(rawCffBuf + cffTab->mainTopDict->FDArrayOffset, &cffTab->FDIndex);
    if (cffErr != CFF_ERR_OK)
        return cffErr;

    size_t numFDIndexes = cff_indexGetCount(cffTab->FDIndex);

    cffTab->fdInfo = (cffFDInfo*)calloc(numFDIndexes, sizeof(cffFDInfo));
    if (cffTab->fdInfo == NULL)
        return CFF_ERR_MEMORY;

    for (ULONG i = 0; i < numFDIndexes; i++)
    {
        cffIndexItem* td = cff_indexGetItem(cffTab->FDIndex, i);
        if (td == NULL)
            return CFF_ERR_INTERNAL;

        cffErr = loadTopDict(td->data, (LONG)td->length, &cffTab->fdInfo[i].topdict);
        if (cffErr != CFF_ERR_OK)
            return cffErr;

        cffTab->fdInfo[i].privateDict = (PRIVATEDICT*)calloc(1, sizeof(PRIVATEDICT));
        if (cffTab->fdInfo[i].privateDict == NULL)
            return CFF_ERR_MEMORY;

        cffErr = loadPrivateDict(rawCffBuf + cffTab->fdInfo[i].topdict->privateDictOffset,
                                 cffTab->fdInfo[i].topdict->privateDictSize, cffTab->fdInfo[i].privateDict);
        if (cffErr != CFF_ERR_OK)
        {
            free(cffTab->fdInfo[i].privateDict);
            cffTab->fdInfo[i].privateDict = NULL;
            return cffErr;
        }

        if (cffTab->fdInfo[i].privateDict->subrsoff != 0)
        {
            BYTE* ptrToLocalSubr = rawCffBuf + cffTab->fdInfo[i].topdict->privateDictOffset + cffTab->fdInfo[i].privateDict->subrsoff;

            cffErr = cff_indexInitializeFromBuffer(ptrToLocalSubr, &cffTab->fdInfo[i].localSubr);
            if (cffErr != CFF_ERR_OK)
                return cffErr;
        }
    }

    return CFF_ERR_OK;
}

static CFF_ERROR loadEncoding()
{
    return CFF_ERR_OK;
}

static CFF_ERROR grow_outline_points(const cffCharStringState *state, Simple_Outline *outl, USHORT amount)
{
    if (outl->np + amount > state->pointsSpaceAllocated)
    {
        // Should never get here. Indicates that the calculation of number of points is wrong
        ASSERT(outl->np + amount <= state->pointsSpaceAllocated);
        DEBUG_LOG_ERROR("error in grow_outline_points");
        return CFF_ERR_INTERNAL;
    }

    outl->np += amount;

    return CFF_ERR_OK;
}

INLINE static void grow_outline_contours(Simple_Outline *outl, USHORT amount)
{
    outl->nc += amount;
}

static CFF_ERROR close_contour(cffCharStringState *state, Simple_Outline *outl)
{
    int nc = state->numcontours;
    int np = state->numpoints;

    if (nc == 0 || np == 0)
        return CFF_ERR_OK; // no points yet

    /* ? close the current contour */
    if ((fabs((double)(outl->x[np - 1] - state->loopstartx)) > 0.001f) ||
        (fabs((double)(outl->y[np - 1] - state->loopstarty)) > 0.001f))
    {
        if ((np + 1) >= outl->np)
        {
            if (CFF_ERR_INTERNAL == grow_outline_points(state, outl, 1))
                return CFF_ERR_INTERNAL;
        }

        outl->x[np] = state->loopstartx;
        outl->y[np] = state->loopstarty;

        outl->types[np] = LINE_TO;
        outl->endPtsOfContours[nc-1] = (USHORT)np;
        state->numpoints++;
    }

    return CFF_ERR_OK;
}

static CFF_ERROR moveto(FIXED x, FIXED y, cffCharStringState *state, Simple_Outline *outl)
{
    if (state->operation == GENERATION)
    {
        int np, nc = outl->nc;
        CFF_ERROR ret;

        ret = close_contour(state, outl);
        if (ret != CFF_ERR_OK)
            return ret;

        /* now get np */
        np = state->numpoints;

        if ((np + 1) >= outl->np)
        {
            ret = grow_outline_points(state, outl, 1);
            if (ret != CFF_ERR_OK)
                return ret;
        }

        if ((nc + 1) >= outl->nc)
        {
            grow_outline_contours(outl, 1);

            state->numcontours++;
        }

        float xval, yval;

        /* modify the font coordinates by the fontmatrix[]  */
        /* if not .001 0 0 .001 0 0 ... this is unnecessary */
        if (state->cffTab->activeTopDict->nonDefaultMatrix == TRUE)
        {
            double *matrix = state->cffTab->activeTopDict->normalizedMatrix;

            xval = (float)(FIXED_TO_DOUBLE(x) * matrix[0] + FIXED_TO_DOUBLE(y) * matrix[2]);
            yval = (float)(FIXED_TO_DOUBLE(x) * matrix[1] + FIXED_TO_DOUBLE(y) * matrix[3]);
        }
        else
        {
            xval = FIXED_TO_FLOAT(x);
            yval = FIXED_TO_FLOAT(y);
        }

        /* add the moveto point to the new contour */
        outl->x[np] = state->loopstartx = xval;
        outl->y[np] = state->loopstarty = yval;

        outl->types[np] = MOVE_TO;
        outl->endPtsOfContours[outl->nc - 1] = (USHORT)np;
        state->numpoints++;
    }
    else
        state->numMovetos++;

    /* update bounding box with on-curve point */
    if (state->xMin > x) state->xMin = x;
    if (state->xMax < x) state->xMax = x;
    if (state->yMin > y) state->yMin = y;
    if (state->yMax < y) state->yMax = y;

    return CFF_ERR_OK;
}

static CFF_ERROR lineto(FIXED x, FIXED y, cffCharStringState *state, Simple_Outline *outl)
{
    if (state->operation == GENERATION)
    {
        int np = state->numpoints;

        if ((np + 1) >= outl->np)
        {
            if (CFF_ERR_INTERNAL == grow_outline_points(state, outl, 1))
                return CFF_ERR_INTERNAL;
        }

        float xval, yval;

        /* modify the font coordinates by the fontmatrix[] */
        if (state->cffTab->activeTopDict->nonDefaultMatrix == TRUE)
        {
            double *matrix = state->cffTab->activeTopDict->normalizedMatrix;

            xval = (float)(FIXED_TO_DOUBLE(x) * matrix[0] + FIXED_TO_DOUBLE(y) * matrix[2]);
            yval = (float)(FIXED_TO_DOUBLE(x) * matrix[1] + FIXED_TO_DOUBLE(y) * matrix[3]);
        }
        else
        {
            xval = FIXED_TO_FLOAT(x);
            yval = FIXED_TO_FLOAT(y);
        }

        /* add the point */
        outl->x[np] = xval;
        outl->y[np] = yval;

        outl->types[np] = LINE_TO;
        outl->endPtsOfContours[outl->nc - 1] = (USHORT)np;  /* keep end points up to date */
        state->numpoints++;
    }
    else
        state->numLinetos++;

    /* update bounding box with on-curve point */
    if (state->xMin > x) state->xMin = x;
    if (state->xMax < x) state->xMax = x;
    if (state->yMin > y) state->yMin = y;
    if (state->yMax < y) state->yMax = y;

    return CFF_ERR_OK;
}


//lint -e{578} suppress symbol y1 hides y1(double)

static CFF_ERROR curveto(/*FIXED x0, FIXED y0, */ FIXED x1, FIXED y1, FIXED x2, FIXED y2, FIXED x3, FIXED y3,
                         cffCharStringState *state, Simple_Outline *outl)
{
    if (state->operation == GENERATION)
    {
        int np = state->numpoints;

        if ((np + 3) >= outl->np)
        {
            if (CFF_ERR_INTERNAL == grow_outline_points(state, outl, 3))
                return CFF_ERR_INTERNAL;
        }

        float x1val, y1val, x2val, y2val, x3val, y3val;

        /* modify the font coordinates by the fontmatrix[] */
        if (state->cffTab->activeTopDict->nonDefaultMatrix == TRUE)
        {
            double *matrix = state->cffTab->activeTopDict->normalizedMatrix;

            x1val = (float)(FIXED_TO_DOUBLE(x1) * matrix[0] + FIXED_TO_DOUBLE(y1) * matrix[2]);
            y1val = (float)(FIXED_TO_DOUBLE(x1) * matrix[1] + FIXED_TO_DOUBLE(y1) * matrix[3]);
            x2val = (float)(FIXED_TO_DOUBLE(x2) * matrix[0] + FIXED_TO_DOUBLE(y2) * matrix[2]);
            y2val = (float)(FIXED_TO_DOUBLE(x2) * matrix[1] + FIXED_TO_DOUBLE(y2) * matrix[3]);
            x3val = (float)(FIXED_TO_DOUBLE(x3) * matrix[0] + FIXED_TO_DOUBLE(y3) * matrix[2]);
            y3val = (float)(FIXED_TO_DOUBLE(x3) * matrix[1] + FIXED_TO_DOUBLE(y3) * matrix[3]);
        }
        else
        {
            x1val = FIXED_TO_FLOAT(x1);
            y1val = FIXED_TO_FLOAT(y1);
            x2val = FIXED_TO_FLOAT(x2);
            y2val = FIXED_TO_FLOAT(y2);
            x3val = FIXED_TO_FLOAT(x3);
            y3val = FIXED_TO_FLOAT(y3);
        }

        /* add the points */
        outl->x[np] = x1val;
        outl->y[np] = y1val;
        outl->types[np++] = OFF_CURVE;

        outl->x[np] = x2val;
        outl->y[np] = y2val;
        outl->types[np++] = OFF_CURVE;

        outl->x[np] = x3val;
        outl->y[np] = y3val;
        outl->types[np] = ON_CURVE;
        outl->endPtsOfContours[outl->nc - 1] = (USHORT)np;  /* keep end points up to date */

        state->numpoints += 3;
    }
    else
        state->numCurvetos++;
    
    /* update bounding box */
    if (state->xMin > x1) state->xMin = x1;
    if (state->xMax < x1) state->xMax = x1;
    if (state->yMin > y1) state->yMin = y1;
    if (state->yMax < y1) state->yMax = y1;
    if (state->xMin > x2) state->xMin = x2;
    if (state->xMax < x2) state->xMax = x2;
    if (state->yMin > y2) state->yMin = y2;
    if (state->yMax < y2) state->yMax = y2;
    if (state->xMin > x3) state->xMin = x3;
    if (state->xMax < x3) state->xMax = x3;
    if (state->yMin > y3) state->yMin = y3;
    if (state->yMax < y3) state->yMax = y3;

    return CFF_ERR_OK;
}

static int adobestd(int ch)
{
    if (ch < 32 || ch > 255)
        return 0; /* not found */

    return adobestdvector[(ch - ADOBESTDENCODINGOFFSET)];
}

static int adobeindex(const CFF_TAB *cffTab, int ch)
{
    int i, sid;
    cffSID *charset = cffTab->charset;

    if (charset == 0)
        return ch;

    sid = adobestd(ch);

    /* quick return for standard encoding */
    if (charset[sid] == sid)
        return sid;

    for (i = 0; i < cffTab->numGlyphs; i++)
    {
        if (charset[i] == sid)
            return i;
    }
    return 0;
}

static CFF_ERROR stems(cffAnalyzedCharstring* acs, int i, cffCharStringState *state, int which)
{
    int curArgIndex = i;

    if (state->operation == FULL_ANALYSIS)
    {
        if (acs == NULL)
            return CFF_ERR_INTERNAL;

        FIXED *args = state->args;

        int numStems = (state->numargs - i);
        int numStemPairs = numStems / 2;

        LF_VECTOR* target = NULL;

        if (which == HSTEM)
        {
            if (acs->hstems == NULL)
            {
                target = acs->hstems = vector_create(numStemPairs, 1);
                if (acs->hstems == NULL)
                    return CFF_ERR_MEMORY;
            }
            else
            {
                acs->hasNonInitialHints = TRUE;
                return CFF_ERR_OK;
            }
        }
        else
        {
            if (acs->vstems == NULL)
            {
                target = acs->vstems = vector_create(numStemPairs, 1);
                if (acs->vstems == NULL)
                    return CFF_ERR_MEMORY;
            }
            else
            {
                acs->hasNonInitialHints = TRUE;
                return CFF_ERR_OK;
            }
        }

        for (int j = 0; j < numStemPairs; j++)
        {
            cffHint* hint = (cffHint*)calloc(1, sizeof(cffHint));
            if (hint == NULL)
                return CFF_ERR_MEMORY;
            hint->first = NEXTARGNONCOORD();
            hint->second = NEXTARGNONCOORD();

            vector_push_back(target, hint);
        }
    }

    // The hints are not made use of. The counts of the stems are used
    // in order to advance the current position in the raw buffer past
    // the stems data.
    int n = (state->numargs - curArgIndex) / 2;

    if (which == HSTEM)
        state->numhstems += n;
    else
        state->numvstems += n;

    return CFF_ERR_OK;
}

#define MOVETO(x,y,outl) \
    { err = moveto(x, y, state, outl); if (err) return err; }
#define LINETO(x,y,glyph) \
    { err = lineto(x, y, state, outl); if (err) return err; }
#define CURVETO(x0,y0,x1,y1,x2,y2,x3,y3,outl) \
    { (void)x0; (void)y0; err = curveto(x1, y1, x2, y2, x3, y3, state, outl); if (err) return err; }
#define FLEXPROC(fa,outl) \
    { err = flexproc(fa, state, outl); if (err) return err; }

static CFF_ERROR flexproc(const FLEXARGS *fa, cffCharStringState *state, Simple_Outline *outl)
{
    CFF_ERROR err;
    CURVETO(fa->x0, fa->y0, fa->x1, fa->y1, fa->x2, fa->y2, fa->x3, fa->y3, outl);
    CURVETO(fa->x3, fa->y3, fa->x4, fa->y4, fa->x5, fa->y5, fa->x6, fa->y6, outl);
    return err;
}





//lint -e{701} suppress Shift left of signed quantity (int)

static SHORT cff_nextCharStringOpCode(BYTE** pdata, int* numargs, int *args, const BYTE *ep)
{
    BYTE *ptr = *pdata;
    BYTE b0, b1, b2, b3, b4;
    LONG count = *numargs;
    LONG val;
    USHORT us;

    for (;;)  /* while (1) */
    {
        if (ptr > ep)
            return -1;

        b0 = *ptr++;
        if (b0 < 28)
        {
            *pdata = ptr;
            *numargs = count;
            return b0;
        }
        else if (b0 == 28)
        {
            b1 = *ptr++;
            b2 = *ptr++;
            us = (b1 << 8) | b2;
            val = (SHORT)us;
            args[count++] = val << 16;
        }
        else if (/*29 <= b0 && */ b0 <= 31)
        {
            *pdata = ptr;
            *numargs = count;
            return b0;
        }
        else if (/*32 <= b0 && */ b0 <= 246)
        {
            val = b0 - 139;
            args[count++] = val << 16;
        }
        else if (/* 247 <= b0 && */ b0 <= 250)
        {
            b1 = *ptr++;
            val = (b0 - 247) * 256 + b1 + 108;
            args[count++] = val << 16;
        }
        else if (/* 251 <= b0 && */ b0 <= 254)
        {
            b1 = *ptr++;
            val = -((b0 - 251) * 256) - b1 - 108;
            args[count++] = val << 16;
        }
        else //if (b0 == 255)
        {
            b1 = *ptr++;
            b2 = *ptr++;
            b3 = *ptr++;
            b4 = *ptr++;
            val = (b1 << 24) | (b2 << 16) | (b3 << 8) | b4;
            args[count++] = val;
        }
    }
}

//lint -e{702} suppress (Info -- Shift right of signed quantity (int) in this function

static CFF_ERROR processCharString(cffCharStringState *state, BYTE *charStrBuf, LONG size, cffAnalyzedCharstring* acs, Simple_Outline *outl)
{
    BYTE *p;
    BYTE *ep;
    int opcode;
    FIXED curx = state->prevx;
    FIXED cury = state->prevy;
    FIXED *args = state->args;
    int numargs;
    FLEXARGS fa;
    FIXED x0 = 0, y0 = 0, x1 = 0, y1 = 0, x2 = 0, y2 = 0;   //lint !e578
    FIXED px1 = 0, py1 = 0, px2 = 0, py2 = 0;
    FIXED dx1 = 0, dx2 = 0, dx3 = 0, dx6, dx;
    FIXED dy1 = 0, dy2 = 0, dy3 = 0, dy6, dy;
    int idx;
    FIXED v;
    int index;
    CFF_ERROR err; /* for LINETO and CURVETO macros */

    if (charStrBuf == 0)
        return CFF_ERR_OK;        /* in a strange sort of way */ // TODO should not get here

    if (((state->operation == ANALYSIS) && (acs == NULL)) || ((state->operation == FULL_ANALYSIS) && (acs == NULL)) ||
        ((state->operation == GENERATION) && (outl == NULL)))
    {
        return CFF_ERR_INTERNAL;
    }

    p = charStrBuf;
    ep = p + size;

    state->depth++;

    while (p < ep)
    {
        int i, tmp;

        opcode = cff_nextCharStringOpCode(&p, &state->numargs, args, ep);
        numargs = state->numargs;

        if (opcode < 0)
        {
            state->xMin = state->yMin = 0;
            state->xMax = state->yMax = 0;
            return CFF_ERR_BAD_OPCODE;
        }

        i = 0;

        switch ((BYTE)opcode)    // cast helps compiler to generate better switch table
        {
        case 1:  // hstem
        case 18: // hstemhm
            if ((state->haveAdvanceWidth == FALSE) && (numargs & 1))  // if argcount is odd, first thing is diff between escapement and nominal width
            {
                state->dx = NEXTARG();
                state->haveAdvanceWidth = TRUE;
                if (state->operation <= FULL_ANALYSIS)
                {
                    acs->advanceWidthAdj = state->dx;
                    acs->hasAdwAdj = TRUE;
                }
            }
            stems(acs, i, state, HSTEM);  // get the stems
            state->numargs = 0;
            break;
        case 3:
        case 23:
            if ((state->haveAdvanceWidth == FALSE) && (numargs & 1))
            {
                state->dx = NEXTARG();
                state->haveAdvanceWidth = TRUE;
                if (state->operation <= FULL_ANALYSIS)
                {
                    acs->advanceWidthAdj = state->dx;
                    acs->hasAdwAdj = TRUE;
                }
            }
            stems(acs, i, state, VSTEM); // get the stems
            state->numargs = 0;
            break;
        case 4: // vmoveto
            if ((state->haveAdvanceWidth == FALSE) && (numargs == 2))
            {
                state->dx = NEXTARG();
                state->haveAdvanceWidth = TRUE;
                if (state->operation <= FULL_ANALYSIS)
                {
                    acs->advanceWidthAdj = state->dx;
                    acs->hasAdwAdj = TRUE;
                }
            }
            cury += NEXTARG();
            MOVETO(curx, cury, outl);
            state->numargs = 0;
            break;
        case 5: // rlineto
            // syntax |- {dxa dya}+ rlineto (5)
            while (i < numargs)
            {
                curx += NEXTARG();
                cury += NEXTARG();
                LINETO(curx, cury, outl);
            }
            state->numargs = 0;
            break;
        case 6: // hlineto
            // syntax 1  |-  dx1 {dya dxb}* hlineto {6} |-
            // syntax 2  |- {dxa  dyb}* hlineto {6} |-
            while (i < numargs)
            {
                if (i & 1)
                    cury += NEXTARG();
                else
                    curx += NEXTARG();

                LINETO(curx, cury, outl);
            }
            state->numargs = 0;
            break;
        case 7: // vlineto
            // syntax 1 |-  dy1 {dxa dyb}* vlineto (7) |-
            // syntax 2 |- {dya  dxb}* vlineto (7) |-
            while (i < numargs)
            {
                if (i & 1)
                    curx += NEXTARG();
                else
                    cury += NEXTARG();

                LINETO(curx, cury, outl);
            }
            state->numargs = 0;
            break;
        case 8: // rrcurveto
            while (i < numargs)
            {
                x0 = curx;
                y0 = cury;
                x1 = curx + NEXTARG();
                y1 = cury + NEXTARG();
                x2 = x1 + NEXTARG();
                y2 = y1 + NEXTARG();
                curx = x2 + NEXTARG();
                cury = y2 + NEXTARG();

                CURVETO(x0, y0, x1, y1, x2, y2, curx, cury, outl);
            }
            state->numargs = 0;
            break;
        case 10: // callsubr
            {
                if (state->operation <= FULL_ANALYSIS)
                {
                    if (acs->subrArray == NULL)
                    {
                        acs->subrArray = vector_create(4, 4);
                        if (acs->subrArray == NULL)
                        {
                            //todo
                            return CFF_ERR_MEMORY;
                        }
                    }
                }

                index = state->args[state->numargs - 1] >> 16;
                state->numargs--;

                state->prevx = curx;
                state->prevy = cury;

                ULONG count = cff_indexGetCount(state->cffTab->localSubrIndex);

                if (count < 1240)
                    index = index + 107;
                else if (count < 33900)
                    index = index + 1131;
                else
                    index = index + 32768;

                if (state->operation <= FULL_ANALYSIS)
                    vector_push_back(acs->subrArray, (void*)(intptr_t)index);

                cffIndexItem* ii = cff_indexGetItem(state->cffTab->localSubrIndex, index);
                if (ii == NULL)
                {
                    if (state->operation <= FULL_ANALYSIS)
                    {
                        vector_free(acs->subrArray);
                        free(acs->subrArray);
                        acs->subrArray = NULL;
                    }
                    return CFF_ERR_INTERNAL;
                }

                CFF_ERROR cffErr = processCharString(state, ii->data, (LONG)ii->length, acs, outl);
                if (cffErr != CFF_ERR_OK)
                {
                    if (acs->subrArray != NULL)
                    {
                        if (state->operation <= FULL_ANALYSIS)
                        {
                            vector_free(acs->subrArray);
                            free(acs->subrArray);
                            acs->subrArray = NULL;
                        }
                    }
                    return cffErr;
                }

                curx = state->prevx;
                cury = state->prevy;
            }
            break;
        case 11: // return
            /* set these in case we are in a subr */
            state->prevx = curx;
            state->prevy = cury;
            state->depth--;
            return CFF_ERR_OK;
        case 14: // endchar
            if ((numargs == 1) && (state->haveAdvanceWidth == FALSE))
            {
                state->dx = NEXTARG();              // space character?
                state->haveAdvanceWidth = TRUE;
                state->xMin = state->xMax = 0;
                state->yMin = state->yMax = 0;
                if (state->operation <= FULL_ANALYSIS)
                {
                    acs->advanceWidthAdj = state->dx;
                    acs->hasAdwAdj = TRUE;
                }
            }
            if (numargs < 4)
            {
                /* set these in case we are in a subr */
                state->depth--;
                state->prevx = curx;
                state->prevy = cury;
                return CFF_ERR_OK;
            }
            else // numargs >= 4
            {
                // seac
                if (state->operation <= FULL_ANALYSIS)
                {
                    if (acs->seacInfo != NULL)
                    {
                        // seacs cannot be recursive
                        return CFF_ERR_BAD_FORMAT;
                    }

                    acs->seacInfo = (cffSeacInfo*)calloc(1, sizeof(cffSeacInfo));
                    if (acs->seacInfo == NULL)
                        return CFF_ERR_MEMORY;

                    FIXED asb = 0, temp2;

                    if (numargs == 5)
                    {
                        asb = NEXTARG();
                        acs->seacInfo->hasAdw = TRUE;
                        acs->seacInfo->adwOffset = asb;
                        state->haveAdvanceWidth = TRUE;
                        if (state->operation <= FULL_ANALYSIS)
                        {
                            acs->advanceWidthAdj = asb;
                            acs->hasAdwAdj = TRUE;
                        }
                    }
                    else
                        acs->seacInfo->adwOffset = -1;

                    acs->seacInfo->accentX = NEXTARG();     //adx
                    acs->seacInfo->accentY = NEXTARG();     //ady

                    temp2 = (GlyphID)NEXTARGNONCOORD();
                    acs->seacInfo->base = (GlyphID)adobeindex(state->cffTab, temp2);

                    temp2 = (GlyphID)NEXTARGNONCOORD();
                    acs->seacInfo->accent = (GlyphID)adobeindex(state->cffTab, temp2);

                    // TODO need to simulate processseac?

                    state->dx = asb;

                    state->depth--;
                    return CFF_ERR_OK;
                }
                else if (state->operation == GENERATION)
                {
                    // should not get here (since any glyph with seac is created as a composite in the glyf table
                    ASSERT(numargs == 0);
                }
            }
            break;
        case 12: // double byte opcodes
            opcode = *p++;
            switch ((BYTE)opcode)
            {
                // remember all arguments are fixed point
            case 3: /* AND */
                px2 = POPCFFARG();
                px1 = POPCFFARG();
                PUSHCFFARG((px1 && px2));
                break;
            case 4: /* OR */
                px2 = POPCFFARG();
                px1 = POPCFFARG();
                PUSHCFFARG((px1 || px2));
                break;
            case 5: /* NOT */
                px1 = POPCFFARG();
                PUSHCFFARG((px1 == 0));
                break;
            case 9: /*ABS */
                px1 = POPCFFARG();
                if (px1 < 0) px1 = -px1;
                PUSHCFFARG(px1);
                break;
            case 10: /* ADD */
                px2 = POPCFFARG();
                px1 = POPCFFARG();
                PUSHCFFARG((px1 + px2));
                break;
            case 11: /* SUB */
                px2 = POPCFFARG();
                px1 = POPCFFARG();
                PUSHCFFARG((px1 - px2));
                break;
            case 12: /* DIV */
                {
                px2 = POPCFFARG();
                px1 = POPCFFARG();
                double d = FIXED_TO_DOUBLE(px1) / FIXED_TO_DOUBLE(px2);
                PUSHCFFARG(DOUBLE_TO_FIXED(d));
                }
                break;
            case 14: /* NEG */
                px1 = POPCFFARG();
                PUSHCFFARG(-px1);
                break;
            case 15: /* EQ */
                px2 = POPCFFARG();
                px1 = POPCFFARG();
                PUSHCFFARG((px1 == px2));
                break;
            case 18: /* DROP */
                (void)POPCFFARG();
                break;
            case 20: /* PUT */
                idx = POPCFFARG() >> 16;
                v = POPCFFARG();
                if (idx >= 0 && idx < 32)
                    state->transient[idx] = v;
                break;
            case 21: /* GET */
                idx = POPCFFARG() >> 16;
                v = 0;
                if (idx >= 0 && idx < 32)
                    v = state->transient[idx];
                PUSHCFFARG(v);
                break;
            case 22: /* IFELSE */
                py2 = POPCFFARG();
                py1 = POPCFFARG();
                px1 = POPCFFARG();
                px2 = POPCFFARG();
                PUSHCFFARG(((py1 <= py2) ? px1 : px2));
                break;
            case 24: /* MUL */
                {
                px2 = POPCFFARG();
                px1 = POPCFFARG();
                double d = FIXED_TO_DOUBLE(px1) * FIXED_TO_DOUBLE(px2);
                PUSHCFFARG(DOUBLE_TO_FIXED(d));
                }
                break;
            case 26: /* SQRT */
                {
                px1 = POPCFFARG();
                double d = sqrt(FIXED_TO_DOUBLE(px1));
                PUSHCFFARG(DOUBLE_TO_FIXED(d));
                }
                break;
            case 27: /* DUP */
                px1 = POPCFFARG();
                PUSHCFFARG(px1);
                PUSHCFFARG(px1);
                break;
            case 28: /* EXCH */
                px2 = POPCFFARG();
                px1 = POPCFFARG();
                PUSHCFFARG(px2);
                PUSHCFFARG(px1);
                break;
            case 29: /* INDEX */
                px1 = POPCFFARG() >> 16;
                if (px1 >= 0 && px1 < numargs)
                {
                    /* remember top of stack is index==0 */
                    px2 = args[numargs - px1];
                    PUSHCFFARG(px2);
                }
                break;
            case 30: /* ROLL */
                {
                int J = POPCFFARG() >> 16;
                int N = POPCFFARG() >> 16;

                if (N > 0 && N < numargs)
                {
                    int temp[48] = { 0 };

                    for (i = 0; i < N; i++)
                        temp[i] = POPCFFARG();

                    for (i = 0; i < N; i++)
                    {
                        int k = (J + i) % N;
                        PUSHCFFARG(temp[k]);
                    }
                }
                }
                break;
            case 34: /* hflex */
                /* dx1 dx2 dy2 dx3 dx4 dx5 dx6 hflex */
                fa.x0 = curx;
                fa.y0 = cury;
                fa.x1 = fa.x0 + NEXTARG();
                fa.y1 = cury;
                fa.x2 = fa.x1 + NEXTARG();
                fa.y2 = fa.y1 + NEXTARG();
                fa.x3 = fa.x2 + NEXTARG();
                fa.y3 = fa.y2;
                fa.x4 = fa.x3 + NEXTARG();
                fa.y4 = fa.y2;
                fa.x5 = fa.x4 + NEXTARG();
                fa.y5 = cury;
                fa.x6 = fa.x5 + NEXTARG();
                fa.y6 = cury;
                fa.fd = 50;

                if (state->operation == GENERATION)
                {
                    FLEXPROC(&fa, outl);
                }
                else
                    state->numFlexprocs++;
                curx = fa.x6;
                cury = fa.y6;
                state->numargs = 0;
                break;
            case 35: /* flex */
                /* dx1 dy1 dx2 dy2 dx3 dy3 dx4 dy4 dx5 dy5 dx6 dy6 fd  flex */
                fa.x0 = curx;
                fa.y0 = cury;
                fa.x1 = fa.x0 + NEXTARG();
                fa.y1 = fa.y0 + NEXTARG();
                fa.x2 = fa.x1 + NEXTARG();
                fa.y2 = fa.y1 + NEXTARG();
                fa.x3 = fa.x2 + NEXTARG();
                fa.y3 = fa.y2 + NEXTARG();
                fa.x4 = fa.x3 + NEXTARG();
                fa.y4 = fa.y3 + NEXTARG();
                fa.x5 = fa.x4 + NEXTARG();
                fa.y5 = fa.y4 + NEXTARG();
                fa.x6 = fa.x5 + NEXTARG();
                fa.y6 = fa.y5 + NEXTARG();
                fa.fd = NEXTARGNONCOORD();

                if (state->operation == GENERATION)
                {
                    FLEXPROC(&fa, outl);
                }
                else
                    state->numFlexprocs++;
                curx = fa.x6;
                cury = fa.y6;
                state->numargs = 0;
                break;
            case 36: /* hflex1 */
                /* dx1 dy1 dx2 dy2 dx3 dx4 dx5 dy5 dx6 hflex1 */
                fa.x0 = curx;
                fa.y0 = cury;
                fa.x1 = fa.x0 + NEXTARG();
                fa.y1 = fa.y0 + NEXTARG();
                fa.x2 = fa.x1 + NEXTARG();
                fa.y2 = fa.y1 + NEXTARG();
                fa.x3 = fa.x2 + NEXTARG();
                fa.y3 = fa.y2;
                fa.x4 = fa.x3 + NEXTARG();
                fa.y4 = fa.y2;
                fa.x5 = fa.x4 + NEXTARG();
                fa.y5 = fa.y4 + NEXTARG();
                fa.x6 = fa.x5 + NEXTARG();
                fa.y6 = cury;
                fa.fd = 50;
                if (state->operation == GENERATION)
                {
                    FLEXPROC(&fa, outl);
                }
                else
                    state->numFlexprocs++;
                curx = fa.x6;
                cury = fa.y6;
                state->numargs = 0;
                break;
            case 37: /* flex1 */
                /* dx1 dy1 dx2 dy2 dx3 dy3 dx4 dy4 dx5 dy5 d6 flex1 */
                fa.x0 = curx;
                fa.y0 = cury;
                fa.x1 = fa.x0 + NEXTARG();
                fa.y1 = fa.y0 + NEXTARG();
                fa.x2 = fa.x1 + NEXTARG();
                fa.y2 = fa.y1 + NEXTARG();
                fa.x3 = fa.x2 + NEXTARG();
                fa.y3 = fa.y2 + NEXTARG();
                fa.x4 = fa.x3 + NEXTARG();
                fa.y4 = fa.y3 + NEXTARG();
                fa.x5 = fa.x4 + NEXTARG();
                fa.y5 = fa.y4 + NEXTARG();

                dx = fa.x5 - fa.x0;
                dy = fa.y5 - fa.y0;

                if (abs(dx) > abs(dy))
                {
                    dx6 = NEXTARG();
                    fa.x6 = fa.x5 + dx6;
                    fa.y6 = cury;
                }
                else
                {
                    dy6 = NEXTARG();
                    fa.x6 = curx;
                    fa.y6 = fa.y5 + dy6;
                }
                fa.fd = 50;

                if (state->operation == GENERATION)
                {
                    FLEXPROC(&fa, outl);
                }
                else
                    state->numFlexprocs++;
                curx = fa.x6;
                cury = fa.y6;
                state->numargs = 0;
                break;
            default:
                DEBUG_LOG_VALUE("processCharString : bad opcode 12 %d\n", opcode);
                break;
            }  /* end of case 12's switch */
            break; /* end of case 12: */
        case 19: /* hintmask */
            /* if there are any arguments they are VSTEMS */
            if (numargs)
            {
                stems(acs, 0, state, VSTEM);
                state->numargs = 0;
            }
            if (state->operation == FULL_ANALYSIS)
                acs->numHintmasks++;

            /* then the hintmask proper */
            int n = (state->numhstems + state->numvstems + 7) / 8;

            p += n;  // skip past the stems
            break;
        case 20: /* cntrmask */
            /* if there are any arguments they are VSTEMS */
            if (numargs)
            {
                stems(acs, 0, state, VSTEM);
                state->numargs = 0;
            }

            n = (state->numhstems + state->numvstems + 7) / 8;  // then the hintmask proper

            p += n; // skip past the stems
            state->numargs = 0;
            break;
        case 21: /* rmoveto */
            /* syntax |- dx1 dy1 rmoveto (21) |- */
            /* maybe get advance width */
            if ((state->haveAdvanceWidth == FALSE) && (numargs == 3))
            {
                /* get the difference from the escapement and the nominalWidth */
                state->dx = NEXTARG();
                state->haveAdvanceWidth = TRUE;
                if (state->operation <= FULL_ANALYSIS)
                {
                    acs->advanceWidthAdj = state->dx;
                    acs->hasAdwAdj = TRUE;
                }
            }
            curx += NEXTARG();
            cury += NEXTARG();

            MOVETO(curx, cury, outl);

            state->numargs = 0;
            break;
        case 22: /* hmoveto */
            /* syntax |- dx1 hmoveto |- */
            /* maybe get advance width  */
            if ((state->haveAdvanceWidth == FALSE) && (numargs == 2))
            {
                /* get the difference from the escapement and the nominalWidth */
                state->dx = NEXTARG();
                state->haveAdvanceWidth = TRUE;
                if (state->operation <= FULL_ANALYSIS)
                {
                    acs->advanceWidthAdj = state->dx;
                    acs->hasAdwAdj = TRUE;
                }
            }
            curx += NEXTARG();

            MOVETO(curx, cury, outl);

            state->numargs = 0;
            break;
        case 24: /* rcurveline */
            /* syntax |- {dxa dya dxb dyb dxc dyc}+ dxd dyd rcurveline (24) |- */
            tmp = numargs - 2;
            while (i < tmp)
            {
                x0 = curx;
                y0 = cury;
                x1 = curx + NEXTARG();
                y1 = cury + NEXTARG();
                x2 = x1 + NEXTARG();
                y2 = y1 + NEXTARG();
                curx = x2 + NEXTARG();
                cury = y2 + NEXTARG();

                CURVETO(x0, y0, x1, y1, x2, y2, curx, cury, outl);
            }
            curx += NEXTARG();
            cury += NEXTARG();

            LINETO(curx, cury, glyph);

            state->numargs = 0;
            break;
        case 25: /* rlinecurve */
            /* syntax |- {dxa dya}+ dxb dyb dxc dyc dxd dyd rlinecurve (25) |- */
            tmp = numargs - 6;
            while (i < tmp)
            {
                curx += NEXTARG();
                cury += NEXTARG();

                LINETO(curx, cury, glyph);
            }
            x0 = curx;
            y0 = cury;
            x1 = curx + NEXTARG();
            y1 = cury + NEXTARG();
            x2 = x1 + NEXTARG();
            y2 = y1 + NEXTARG();
            curx = x2 + NEXTARG();
            cury = y2 + NEXTARG();

            CURVETO(x0, y0, x1, y1, x2, y2, curx, cury, outl);

            state->numargs = 0;
            break;

        case 26: /* vvcurveto */
            /* syntax |- dx1? {dy1 dx2 dy2 dy3}+ vvcurveto (26) |-  */
            dx1 = dx3 = 0;
            if (numargs & 1)
                dx1 = NEXTARG();
            while (i < numargs)
            {
                dy1 = NEXTARG();
                dx2 = NEXTARG();
                dy2 = NEXTARG();
                dy3 = NEXTARG();
                x0 = curx;
                y0 = cury;
                x1 = curx + dx1;
                y1 = cury + dy1;
                x2 = x1 + dx2;
                y2 = y1 + dy2;
                curx = x2 + dx3;
                cury = y2 + dy3;

                CURVETO(x0, y0, x1, y1, x2, y2, curx, cury, outl);

                dx1 = 0;
            }
            state->numargs = 0;
            break;

        case 27: /* hhcurveto */
            /* syntax  |- dy1? {dx1 dx2 dy2 dx3}+ hhcurveto |- */
            dy1 = dy3 = 0;
            if (numargs & 1)
                dy1 = NEXTARG();
            while (i < numargs)
            {
                dx1 = NEXTARG();
                dx2 = NEXTARG();
                dy2 = NEXTARG();
                dx3 = NEXTARG();
                x0 = curx;
                y0 = cury;
                x1 = curx + dx1;
                y1 = cury + dy1;
                x2 = x1 + dx2;
                y2 = y1 + dy2;
                curx = x2 + dx3;
                cury = y2 + dy3;

                CURVETO(x0, y0, x1, y1, x2, y2, curx, cury, outl);

                dy1 = 0;
            }
            state->numargs = 0;
            break;

        case 29: /* call gsbr */
            {
                if (state->operation <= FULL_ANALYSIS)
                {
                    if (acs->gsubrArray == NULL)
                    {
                        acs->gsubrArray = vector_create(4, 4);
                        if (acs->gsubrArray == NULL)
                            return CFF_ERR_MEMORY;
                    }
                }

                index = state->args[--state->numargs] >> 16;

                state->prevx = curx;
                state->prevy = cury;

                ULONG count = cff_indexGetCount(state->cffTab->globalSubrIndex);

                //apply bias
                if (count < 1240)
                    index = index + 107;
                else if (count < 33900)
                    index = index + 1131;
                else
                    index = index + 32768;

                if (state->operation <= FULL_ANALYSIS)
                    vector_push_back(acs->gsubrArray, (void*)(intptr_t)index);

                cffIndexItem* ii = cff_indexGetItem(state->cffTab->globalSubrIndex, index);
                if (ii == NULL)
                {
                    if (state->operation <= FULL_ANALYSIS)
                    {
                        vector_free(acs->gsubrArray);
                        free(acs->gsubrArray);
                        acs->gsubrArray = NULL;
                    }
                    return CFF_ERR_INTERNAL;
                }

                err = processCharString(state, ii->data, (LONG)ii->length, acs, outl);
                if (err != CFF_ERR_OK)
                {
                    if (acs->gsubrArray != NULL)
                    {
                        if (state->operation <= FULL_ANALYSIS)
                        {
                            vector_free(acs->gsubrArray);
                            free(acs->gsubrArray);
                            acs->gsubrArray = NULL;
                        }
                    }
                    return err;
                }

                curx = state->prevx;
                cury = state->prevy;
            }
            break;

        case 30: /* vhcurveto */
            /* syntax1 |-  dy1 dx2 dy3 dx3 {dxa dxb dyb dyc  dyd dxe dye dxf}* dyf? vhcurveto|-  */
            /* syntax2 |- {dya dxb dyb dxc  dxd dxe dye dyf}+ dxf? vhcurveto |-   */
            while (i < numargs)
            {
                tmp = (i + 4) % 8;
                if (tmp == 4)
                {
                    dy1 = NEXTARG();
                    dx2 = NEXTARG();
                    dy2 = NEXTARG();
                    dx3 = NEXTARG();
                    dx1 = dy3 = 0;
                }
                else if (tmp == 0)
                {
                    dx1 = NEXTARG();
                    dx2 = NEXTARG();
                    dy2 = NEXTARG();
                    dy3 = NEXTARG();
                    dy1 = dx3 = 0;
                }
                /* optional last args */
                if ((numargs - i) == 1)
                {
                    if ((numargs % 8) == 1)
                        dx3 = NEXTARG();
                    else if ((numargs % 4) == 1)
                        dy3 = NEXTARG();
                }
                x0 = curx;
                y0 = cury;
                x1 = curx + dx1;
                y1 = cury + dy1;
                x2 = x1 + dx2;
                y2 = y1 + dy2;
                curx = x2 + dx3;
                cury = y2 + dy3;

                CURVETO(x0, y0, x1, y1, x2, y2, curx, cury, outl);
            }
            state->numargs = 0;
            break;
        case 31: /* hvcurveto */
            /* syntax1 |-  dx1 dx2 dy2 dy3 {dya dxb dyb dxc   dxd dxe dye dyf}* dxf? hvcurveto |- */
            /* syntax2 |- {dxa dxb dyb dyc  dyd dxe dye dxf}+ dyf? hvcurveto |-    */
            while (i < numargs)
            {
                tmp = (i + 4) % 8;
                if (tmp == 4)
                {
                    dx1 = NEXTARG();
                    dx2 = NEXTARG();
                    dy2 = NEXTARG();
                    dy3 = NEXTARG();
                    dy1 = dx3 = 0;
                }
                else if (tmp == 0)
                {
                    dy1 = NEXTARG();
                    dx2 = NEXTARG();
                    dy2 = NEXTARG();
                    dx3 = NEXTARG();
                    dx1 = dy3 = 0;
                }
                if ((numargs - i) == 1)
                {
                    if ((numargs % 8) == 1)
                        dy3 = NEXTARG();
                    else if ((numargs % 4) == 1)
                        dx3 = NEXTARG();
                }
                x0 = curx;
                y0 = cury;
                x1 = curx + dx1;
                y1 = cury + dy1;
                x2 = x1 + dx2;
                y2 = y1 + dy2;
                curx = x2 + dx3;
                cury = y2 + dy3;

                CURVETO(x0, y0, x1, y1, x2, y2, curx, cury, outl);
            }
            state->numargs = 0;
            break;

        default:
            DEBUG_LOG_VALUE("processCharString : bad opcode %d\n", opcode);
            break;
        }
    }

    return CFF_ERR_OK;
}

static void selectCIDdict(CFF_TAB *cffTab, int glyphIndex)
{
    ASSERT(cffTab->mainTopDict->ros.Registry != 0);  // This function is for CID fonts only

    cffCard8 newFDindex = cffTab->fdSelect.fdIndexArray[glyphIndex];
    if (cffTab->activeFDIndex != newFDindex)
    {
        cffTab->activeFDIndex = newFDindex;
        cffTab->activeTopDict = cffTab->fdInfo[newFDindex].topdict;
        cffTab->privateDict = cffTab->fdInfo[newFDindex].privateDict;
        cffTab->localSubrIndex = cffTab->fdInfo[newFDindex].localSubr;
    }
}

CFF_ERROR cff_load(BYTE* tableBuf, LONG tableBufLength, CFF_TAB **cffParsedTable)
{
    if ((tableBuf == NULL) || (cffParsedTable == NULL))
        return CFF_ERR_BAD_PARAM;

    *cffParsedTable = NULL;

    CFF_TAB* cffTab = (CFF_TAB *)calloc(1, sizeof(CFF_TAB));
    if (cffTab == NULL)
        return CFF_ERR_MEMORY;

    BYTE tmp[4];

    // read the header
    cff_read_buf(tableBuf, 0, 4, tmp);
    cffTab->header.major = tmp[0];
    cffTab->header.minor = tmp[1];
    cffTab->header.hdrSize = tmp[2];
    cffTab->header.offSize = tmp[3];

    // Read Name INDEX
    CFF_ERROR cffErr = cff_indexInitializeFromBuffer(tableBuf + cffTab->header.hdrSize, &cffTab->nameIndex);
    if (cffErr != CFF_ERR_OK)
    {
        cff_unload(cffTab);
        return cffErr;
    }

    // There can be only one entry in the name index, or we don't support it!
    if (cff_indexGetCount(cffTab->nameIndex) > 1)
    {
        cff_unload(cffTab);
        return CFF_ERR_UNSUPPORTED_FORMAT;
    }

    // read Top DICT INDEX
    size_t nameIndexLen = cff_indexGetLength(cffTab->nameIndex);

    cffErr = cff_indexInitializeFromBuffer(tableBuf + cffTab->header.hdrSize + nameIndexLen, &cffTab->topDictIndex);
    if (cffErr != CFF_ERR_OK)
    {
        cff_unload(cffTab);
        return cffErr;
    }

    cffIndexItem* tdi = cff_indexGetItem(cffTab->topDictIndex, 0);
    if (tdi == NULL)
    {
        cff_unload(cffTab);
        return CFF_ERR_BAD_FORMAT;
    }

    cffErr = loadTopDict(tdi->data, (LONG)tdi->length, &cffTab->mainTopDict);
    if (cffErr != CFF_ERR_OK)
    {
        cff_unload(cffTab);
        return cffErr;
    }
    if ((cffTab->mainTopDict->encodingOffset > tableBufLength) || (cffTab->mainTopDict->charsetOffset > tableBufLength) ||
        (cffTab->mainTopDict->charStringsOffset > tableBufLength) || (cffTab->mainTopDict->privateDictOffset > tableBufLength) ||
        (cffTab->mainTopDict->FDArrayOffset > tableBufLength) || (cffTab->mainTopDict->FDSelectOffset > tableBufLength))
    {
        cff_unload(cffTab);
        return CFF_ERR_BAD_TOP_FORMAT;
    }

    // we support only type 2 charstrings
    if (cffTab->mainTopDict->charstringType != 2)
    {
        cff_unload(cffTab);
        return CFF_ERR_UNSUPPORTED_FORMAT;
    }

    // We can now determine if its a CID
    cffTab->isCID = (cffTab->mainTopDict->ros.Registry != 0) ? TRUE : FALSE;

    // read String INDEX
    size_t topDictIndexLen = cff_indexGetLength(cffTab->topDictIndex);
    size_t offsetToStringIndex = cffTab->header.hdrSize + nameIndexLen + topDictIndexLen;

    cffErr = cff_indexInitializeFromBuffer(tableBuf + offsetToStringIndex, &cffTab->stringIndex);
    if (cffErr != CFF_ERR_OK)
    {
        cff_unload(cffTab);
        return cffErr;
    }

    // read Global subr INDEX
    size_t stringIndexLen = cff_indexGetLength(cffTab->stringIndex);
    size_t offsetToGlobalSubrIndex = offsetToStringIndex + stringIndexLen;

    cffErr = cff_indexInitializeFromBuffer(tableBuf + offsetToGlobalSubrIndex, &cffTab->globalSubrIndex);
    if (cffErr != CFF_ERR_OK)
    {
        cff_unload(cffTab);
        return cffErr;
    }

    // read the encoding
    if (cffTab->mainTopDict->encodingOffset != 0)
    {
        (void)loadEncoding();  // This doesn't do anything.

#if 0 // TODO - need to determine if we need to process the encoding
        cffErr = loadEncoding();
        if (cffErr != CFF_ERR_OK)
        {
            cff_unload(cffTab);
            return cffErr;
        }
#endif
    }

    // the charset is next in the table, but is read below

    // read the charstrings INDEX
    cffErr = cff_indexInitializeFromBuffer(tableBuf + cffTab->mainTopDict->charStringsOffset, &cffTab->charStringsIndex);
    if (cffErr != CFF_ERR_OK)
    {
        cff_unload(cffTab);
        return cffErr;
    }

    // number of glyphs in font is the count of the charstring index
    cffTab->numGlyphs = (USHORT)cff_indexGetCount(cffTab->charStringsIndex);

    // Read the charset (now that the numGlyphs is known)
    if (cffTab->mainTopDict->charsetOffset)
    {
        cffErr = loadCharSet(tableBuf, cffTab);
        if (CFF_ERR_OK != cffErr)
        {
            cff_unload(cffTab);
            return cffErr;
        }
    }

    if (cffTab->isCID == TRUE)
    {
        cffTab->activeFDIndex = 0xff;
        cffTab->activeTopDict = NULL;

        cffErr = loadFDSelect(tableBuf, cffTab);
        if (CFF_ERR_OK != cffErr)
        {
            cff_unload(cffTab);
            return cffErr;
        }

        cffErr = loadFDArray(tableBuf, cffTab);
        if (CFF_ERR_OK != cffErr)
        {
            cff_unload(cffTab);
            return cffErr;
        }
    }
    else
    {
        cffTab->activeTopDict = cffTab->mainTopDict;

        // only load private dict here for non-cid fonts
        if (cffTab->mainTopDict->privateDictSize != 0)
        {
            cffTab->privateDict = (PRIVATEDICT*)calloc(1, sizeof(PRIVATEDICT));
            if (cffTab->privateDict == NULL)
            {
                cff_unload(cffTab);
                return CFF_ERR_MEMORY;
            }

            cffErr = loadPrivateDict(tableBuf + cffTab->mainTopDict->privateDictOffset, cffTab->mainTopDict->privateDictSize, cffTab->privateDict);
            if (cffErr != CFF_ERR_OK)
            {
                cff_unload(cffTab);
                return cffErr;
            }

            // see if there is a local subr INDEX and read it if so
            if (cffTab->privateDict->subrsoff != 0)
            {
                size_t offsetToLocalSubrIndex = cffTab->mainTopDict->privateDictOffset + cffTab->privateDict->subrsoff;

                cffErr = cff_indexInitializeFromBuffer(tableBuf+offsetToLocalSubrIndex, &cffTab->localSubrIndex);
                if (cffErr != CFF_ERR_OK)
                {
                    cff_unload(cffTab);
                    return cffErr;
                }
            }
        }
    }

    *cffParsedTable = cffTab;

    return CFF_ERR_OK;
}

static void unloadFontDicts(const CFF_TAB *cffTab)
{
    // CID fonts only

    if (cffTab->fdInfo != NULL)
    {
        size_t numFDs = cff_indexGetCount(cffTab->FDIndex);

        for (size_t i = 0; i < numFDs; i++)
        {
            unloadPrivateDict(cffTab->fdInfo[i].privateDict);
            free(cffTab->fdInfo[i].privateDict);

            if (cffTab->fdInfo[i].localSubr != NULL)
                cff_indexDestroy(cffTab->fdInfo[i].localSubr);

            free(cffTab->fdInfo[i].topdict);
        }

        free(cffTab->fdInfo);
    }

    free(cffTab->fdSelect.fdIndexArray);

    if (cffTab->FDIndex != NULL)
        cff_indexDestroy(cffTab->FDIndex);
}

void cff_unload(CFF_TAB *cffTab)
{
    if (cffTab)
    {
        if (cffTab->mainTopDict != NULL)
        {
            if (cffTab->mainTopDict->ros.Registry == 0)
            {
                if (cffTab->privateDict != NULL)
                {
                    unloadPrivateDict(cffTab->privateDict);
                    free(cffTab->privateDict);
                }
                if (cffTab->localSubrIndex != NULL)
                    cff_indexDestroy(cffTab->localSubrIndex);
            }
            else
                unloadFontDicts(cffTab);
        }

        if (cffTab->charset)
            free(cffTab->charset);

        if (cffTab->nameIndex != NULL)
            cff_indexDestroy(cffTab->nameIndex);
        if (cffTab->topDictIndex != NULL)
            cff_indexDestroy(cffTab->topDictIndex);
        if (cffTab->stringIndex != NULL)
            cff_indexDestroy(cffTab->stringIndex);
        if (cffTab->globalSubrIndex != NULL)
            cff_indexDestroy(cffTab->globalSubrIndex);
        if (cffTab->charStringsIndex != NULL)
            cff_indexDestroy(cffTab->charStringsIndex);

        unloadTopDict(cffTab->mainTopDict);
        free(cffTab);
    }
}

static void computeBoundingBox(Glyph_Outline* go)
{
    float minX = 32766.f;
    float minY = 32766.f;
    float maxX = -32766.f;
    float maxY = -32766.f;

    Simple_Outline* so = &go->component.outline;

    for (int i = 0; i < go->component.outline.np - 2; i++)
    {
        if (minX > so->x[i])
            minX = so->x[i];
        if (minY > so->y[i])
            minY = so->y[i];
        if (maxX < so->x[i])
            maxX = so->x[i];
        if (maxY < so->y[i])
            maxY = so->y[i];
    }

    go->xMax = maxX;
    go->xMin = minX;
    go->yMax = maxY;
    go->yMin = minY;
}

static CFF_ERROR addSideBearings(const CFF_TAB* cffTab, const cffCharStringState* state, Glyph* cubicGlyph)
{
    Simple_Outline *outl = &cubicGlyph->glyphOutline.component.outline;

    CFF_ERROR err = grow_outline_points(state, outl, 2);
    if (err != CFF_ERR_OK)
    {
        conversion_freeGlyphOutline(cubicGlyph);
        return err;
    }

    // left side bearing
    outl->x[state->numpoints] = 0.0f;
    outl->y[state->numpoints] = 0.0f;
    outl->types[state->numpoints] = OFF_CURVE;

    // right side bearing
    float aw;

    if (cffTab->privateDict != NULL)
        aw = (float)((state->haveAdvanceWidth == TRUE) ? FIXED_TO_DOUBLE(state->dx) + cffTab->privateDict->nominalwidthX
                                                       : cffTab->privateDict->defaultwidthX);
    else
        aw = FIXED_TO_FLOAT(state->dx);

    outl->x[state->numpoints + 1] = aw;
    outl->y[state->numpoints + 1] = 0.0f;
    outl->types[state->numpoints + 1] = OFF_CURVE;

    cubicGlyph->glyphMetrics.aw = aw;

    return CFF_ERR_OK;
}

CFF_ERROR cff_loadSEACIntoGlyph(const cff_table* cffTable, USHORT index, Glyph* cubicGlyph)
{
    CFF_TAB* cffTab = cffTable->cffTable;

    cffAnalyzedCharstring* acs = (cffAnalyzedCharstring*)map_at(cffTable->charStringMap, (void*)(intptr_t)index);
    if (acs == NULL)
        return CFF_ERR_INTERNAL;

    if (acs->seacInfo == NULL)
        return CFF_ERR_INTERNAL;

    // find total points and contours
    cffAnalyzedCharstring* base = (cffAnalyzedCharstring*)map_at(cffTable->charStringMap, (void*)(intptr_t)acs->seacInfo->base);
    cffAnalyzedCharstring* accent = (cffAnalyzedCharstring*)map_at(cffTable->charStringMap, (void*)(intptr_t)acs->seacInfo->accent);

    Glyph baseGlyph;
    Glyph accentGlyph;

    memset(&baseGlyph, 0, sizeof(Glyph));
    memset(&accentGlyph, 0, sizeof(Glyph));

    LF_ERROR lfErr = conversion_allocateGlyphOutline(base->numPointsMax, base->numContours, &baseGlyph.glyphOutline.component.outline);
    if (lfErr != LF_ERROR_OK)
    {
        conversion_freeGlyphOutline(cubicGlyph);
        return CFF_ERR_MEMORY;
    }

    lfErr = conversion_allocateGlyphOutline(accent->numPointsMax, accent->numContours, &accentGlyph.glyphOutline.component.outline);
    if (lfErr != LF_ERROR_OK)
    {
        conversion_freeGlyphOutline(&accentGlyph);
        conversion_freeGlyphOutline(cubicGlyph);
        return CFF_ERR_MEMORY;
    }

    // base
    if (cffTab->isCID == TRUE)
        selectCIDdict(cffTab, acs->seacInfo->base);

    cffCharStringState cffData;
    memset(&cffData, 0, sizeof(cffCharStringState));
    cffData.operation = GENERATION;
    cffData.cffTab = cffTab;
    cffData.pointsSpaceAllocated = base->numPointsMax;
    cffData.contoursSpaceAllocated = base->numContours;

    cffData.xMin = cffData.yMin = MYINFINITY;
    cffData.xMax = cffData.yMax = -cffData.yMin;

    CFF_ERROR err = processCharString(&cffData, base->rawData, (LONG)base->rawLen, NULL, &baseGlyph.glyphOutline.component.outline);
    if (err != CFF_ERR_OK)
    {
        conversion_freeGlyphOutline(&baseGlyph);
        conversion_freeGlyphOutline(&accentGlyph);
        conversion_freeGlyphOutline(cubicGlyph);
        return err;
    }

    err = close_contour(&cffData, &baseGlyph.glyphOutline.component.outline);
    if (err != CFF_ERR_OK)
    {
        conversion_freeGlyphOutline(cubicGlyph);
        return err;
    }

    baseGlyph.glyphOutline.xMin = FIXED_TO_FLOAT(cffData.xMin);
    baseGlyph.glyphOutline.xMax = FIXED_TO_FLOAT(cffData.xMax);
    baseGlyph.glyphOutline.yMin = FIXED_TO_FLOAT(cffData.yMin);
    baseGlyph.glyphOutline.yMax = FIXED_TO_FLOAT(cffData.yMax);

    // accent
    if (cffTab->isCID == TRUE)
        selectCIDdict(cffTab, acs->seacInfo->accent);

    memset(&cffData, 0, sizeof(cffCharStringState));
    cffData.operation = GENERATION;
    cffData.cffTab = cffTab;
    cffData.pointsSpaceAllocated = accent->numPointsMax;
    cffData.contoursSpaceAllocated = accent->numContours;

    cffData.xMin = cffData.yMin = MYINFINITY;
    cffData.xMax = cffData.yMax = -cffData.yMin;

    err = processCharString(&cffData, accent->rawData, (LONG)accent->rawLen, NULL, &accentGlyph.glyphOutline.component.outline);
    if (err != CFF_ERR_OK)
    {
        conversion_freeGlyphOutline(&baseGlyph);
        conversion_freeGlyphOutline(&accentGlyph);
        conversion_freeGlyphOutline(cubicGlyph);
        return err;
    }

    err = close_contour(&cffData, &accentGlyph.glyphOutline.component.outline);
    if (err != CFF_ERR_OK)
    {
        conversion_freeGlyphOutline(cubicGlyph);
        return err;
    }

    accentGlyph.glyphOutline.xMin = FIXED_TO_FLOAT(cffData.xMin);
    accentGlyph.glyphOutline.xMax = FIXED_TO_FLOAT(cffData.xMax);
    accentGlyph.glyphOutline.yMin = FIXED_TO_FLOAT(cffData.yMin);
    accentGlyph.glyphOutline.yMax = FIXED_TO_FLOAT(cffData.yMax);

    // combine

    int totalPoints = base->numPointsMax + accent->numPointsMax + 2/*side bearings*/;
    int totalContours = base->numContours + accent->numContours;

    if (cffTab->isCID == TRUE)
    {
        selectCIDdict(cffTab, index);
        cubicGlyph->glyphOutline.FDid = cffTab->activeFDIndex;
    }

    lfErr = conversion_allocateGlyphOutline(totalPoints, totalContours, &cubicGlyph->glyphOutline.component.outline);
    if (lfErr != LF_ERROR_OK)
    {
        conversion_freeGlyphOutline(cubicGlyph);
        return CFF_ERR_MEMORY;
    }

    cubicGlyph->glyphOutline.xMin = (baseGlyph.glyphOutline.xMin < accentGlyph.glyphOutline.xMin) ? baseGlyph.glyphOutline.xMin : accentGlyph.glyphOutline.xMin;
    cubicGlyph->glyphOutline.xMax = (baseGlyph.glyphOutline.xMax > accentGlyph.glyphOutline.xMax) ? baseGlyph.glyphOutline.xMax : accentGlyph.glyphOutline.xMax;
    cubicGlyph->glyphOutline.yMin = (baseGlyph.glyphOutline.yMin < accentGlyph.glyphOutline.yMin) ? baseGlyph.glyphOutline.yMin : accentGlyph.glyphOutline.yMin;
    cubicGlyph->glyphOutline.yMax = (baseGlyph.glyphOutline.yMax > accentGlyph.glyphOutline.yMax) ? baseGlyph.glyphOutline.yMax : accentGlyph.glyphOutline.yMax;

    if (acs->seacInfo->hasAdw == TRUE)
    {
        cubicGlyph->glyphMetrics.aw = FIXED_TO_FLOAT(acs->seacInfo->adwOffset);
        
        if (cffTab->privateDict != NULL)
            cubicGlyph->glyphMetrics.aw += (float)cffTab->privateDict->nominalwidthX;
    }
    else
        cubicGlyph->glyphMetrics.aw = (cffTab->privateDict != NULL) ? (float)cffTab->privateDict->defaultwidthX : 0.0f;

    cubicGlyph->glyphOutline.sid = cffTab->charset[index];

    if (cffTab->isCID == TRUE)
        cubicGlyph->glyphOutline.FDid = cffTab->fdSelect.fdIndexArray[index];

    Simple_Outline* cso = &cubicGlyph->glyphOutline.component.outline;
    Simple_Outline* bso = &baseGlyph.glyphOutline.component.outline;
    Simple_Outline* aso = &accentGlyph.glyphOutline.component.outline;

    memcpy(cso->x, bso->x, sizeof(float) * bso->np);
    memcpy(cso->y, bso->y, sizeof(float) * bso->np);
    memcpy(cso->types, bso->types, sizeof(Point_Type) * bso->np);
    memcpy(cso->endPtsOfContours, bso->endPtsOfContours, sizeof(unsigned short) * bso->nc);

    float xoffset = FIXED_TO_FLOAT(acs->seacInfo->accentX);
    float yoffset = FIXED_TO_FLOAT(acs->seacInfo->accentY);

    int i;
    for (i = 0; i < aso->np; i++)
        cso->x[i + bso->np] = xoffset + aso->x[i];
    for (i = 0; i < aso->np; i++)
        cso->y[i + bso->np] = yoffset + aso->y[i];
    for (i = 0; i < aso->np; i++)
        cso->types[i + bso->np] = aso->types[i];
    for (i = 0; i < aso->nc; i++)
        cso->endPtsOfContours[i + bso->nc] = aso->endPtsOfContours[i] + bso->np;

    cso->np = aso->np + bso->np;
    cso->nc = aso->nc + bso->nc;

    // side bearings
    cffData.pointsSpaceAllocated = totalPoints;
    cffData.numpoints = totalPoints - 2;
    cffData.haveAdvanceWidth = acs->hasAdwAdj;
    cffData.dx = acs->advanceWidthAdj;

    err = addSideBearings(cffTab, &cffData, cubicGlyph);
    if (err != CFF_ERR_OK)
    {
        conversion_freeGlyphOutline(&baseGlyph);
        conversion_freeGlyphOutline(&accentGlyph);
        conversion_freeGlyphOutline(cubicGlyph);
        return err;
    }

    computeBoundingBox(&cubicGlyph->glyphOutline);

    conversion_freeGlyphOutline(&baseGlyph);
    conversion_freeGlyphOutline(&accentGlyph);

    return CFF_ERR_OK;
}

CFF_ERROR cff_loadCharStringIntoGlyph(const cff_table* cffTable, USHORT index, Glyph* cubicGlyph)
{
    CFF_TAB* cffTab = cffTable->cffTable;

    cffAnalyzedCharstring* acs = (cffAnalyzedCharstring*)map_at(cffTable->charStringMap, (void*)(intptr_t)index);
    if (acs == NULL)
        return CFF_ERR_INTERNAL;

    // <assuming passed in cubicGlyph has been memset to 0>

    // if it has seac then create a composite glyph, otherwise it is a simple glyph
    if (acs->seacInfo != NULL)
    {
        cubicGlyph->glyphType = eGlyph_CFF;
        cubicGlyph->glyphOutline.numberOfComponents = 2;
        cubicGlyph->glyphOutline.component.type = eIsComposite;
        cubicGlyph->glyphOutline.component.glyphIndex = acs->seacInfo->base;
        cubicGlyph->glyphOutline.component.xscale = 1.0f;
        cubicGlyph->glyphOutline.component.yscale = 1.0f;
        cubicGlyph->glyphOutline.component.xoffset = 0;
        cubicGlyph->glyphOutline.component.yoffset = 0;

        Glyph_Component* next = (Glyph_Component*)calloc(1, sizeof(Glyph_Component));
        if (next == NULL)
            return CFF_ERR_MEMORY;

        next->type = eIsComposite;
        next->glyphIndex = acs->seacInfo->accent;
        next->xscale = 1.0f;
        next->yscale = 1.0f;
        next->xoffset = FIXED_TO_FLOAT(acs->seacInfo->accentX);
        next->yoffset = FIXED_TO_FLOAT(acs->seacInfo->accentY);

        if (acs->seacInfo->hasAdw == TRUE)
        {
            cubicGlyph->glyphMetrics.aw = FIXED_TO_FLOAT(acs->seacInfo->adwOffset);
            if (cffTab->privateDict != NULL)
                cubicGlyph->glyphMetrics.aw += (float)cffTab->privateDict->nominalwidthX;
        }
        else
            cubicGlyph->glyphMetrics.aw = (cffTab->privateDict != NULL) ? (float)cffTab->privateDict->defaultwidthX : 0.0f;

        cubicGlyph->glyphOutline.component.next = next;
    }
    else
    {
        CFF_ERROR err;

        cubicGlyph->glyphOutline.numberOfComponents = 1;

        if (cffTab->isCID == TRUE)
        {
            // CID font - set glyph specific topdict and private dict
            selectCIDdict(cffTab, index);
            cubicGlyph->glyphOutline.FDid = cffTab->activeFDIndex;
        }

        LF_ERROR lfErr = conversion_allocateGlyphOutline(acs->numPointsMax, acs->numContours, &cubicGlyph->glyphOutline.component.outline);
        if (lfErr != LF_ERROR_OK)
        {
            conversion_freeGlyphOutline(cubicGlyph);
            return CFF_ERR_MEMORY;
        }

        cffCharStringState cffData;
        memset(&cffData, 0, sizeof(cffCharStringState));
        cffData.operation = GENERATION;
        cffData.cffTab = cffTab;
        cffData.pointsSpaceAllocated = acs->numPointsMax;
        cffData.contoursSpaceAllocated = acs->numContours;

        cffData.xMin = cffData.yMin = MYINFINITY;
        cffData.xMax = cffData.yMax = -cffData.yMin;

        err = processCharString(&cffData, acs->rawData, (LONG)acs->rawLen, NULL, &cubicGlyph->glyphOutline.component.outline);
        if (err != CFF_ERR_OK)
        {
            conversion_freeGlyphOutline(cubicGlyph);
            return err;
        }

        err = close_contour(&cffData, &cubicGlyph->glyphOutline.component.outline);
        if (err != CFF_ERR_OK)
        {
            conversion_freeGlyphOutline(cubicGlyph);
            return err;
        }

        cubicGlyph->glyphOutline.xMin = FIXED_TO_FLOAT(cffData.xMin);
        cubicGlyph->glyphOutline.xMax = FIXED_TO_FLOAT(cffData.xMax);
        cubicGlyph->glyphOutline.yMin = FIXED_TO_FLOAT(cffData.yMin);
        cubicGlyph->glyphOutline.yMax = FIXED_TO_FLOAT(cffData.yMax);

        cubicGlyph->glyphOutline.sid = cffTab->charset[index];

        if (cffTab->isCID == TRUE)
            cubicGlyph->glyphOutline.FDid = cffTab->fdSelect.fdIndexArray[index];

        // side bearings
        err = addSideBearings(cffTab, &cffData, cubicGlyph);
        if (err != CFF_ERR_OK)
        {
            conversion_freeGlyphOutline(cubicGlyph);
            return err;
        }

        computeBoundingBox(&cubicGlyph->glyphOutline);
    }

    return CFF_ERR_OK;
}

static CFF_ERROR cff_analyzedCharStringCreate(CFF_TAB* cffTab, parseReason reason, const BYTE* rawData, ULONG length, GlyphID index, cffAnalyzedCharstring** acs)
{
    *acs = NULL;

    if (index > cffTab->numGlyphs - 1)
        return CFF_ERR_INTERNAL;

    cffAnalyzedCharstring* newacs = calloc(1, sizeof(cffAnalyzedCharstring));
    if (newacs == NULL)
        return CFF_ERR_MEMORY;

    newacs->rawLen = length;
    newacs->rawData = (BYTE*)malloc(length * sizeof(BYTE));
    if (newacs->rawData == NULL)
    {
        free(newacs);
        return CFF_ERR_MEMORY;
    }

    memcpy(newacs->rawData, rawData, length);

    newacs->sid = cffTab->charset[index];

    CFF_ERROR cffErr;

    if (cffTab->isCID == TRUE)
    {
        /* CID font - set glyph specific topdict and private dict */
        selectCIDdict(cffTab, index);
        newacs->fdi = cffTab->fdSelect.fdIndexArray[index];
    }
    else
        newacs->fdi = 0xff;

    cffCharStringState info;
    memset(&info, 0, sizeof(cffCharStringState));

    info.operation = reason;
    info.cffTab = cffTab;

    info.xMin = info.yMin = MYINFINITY;
    info.xMax = info.yMax = -info.yMin;

    cffErr = processCharString(&info, newacs->rawData, (LONG)newacs->rawLen, newacs, NULL);
    if (cffErr != CFF_ERR_OK)
    {
        free(newacs->rawData);
        free(newacs);
        return cffErr;
    }

    // Calculate number of points in the glyph.
    newacs->numPointsMax =   2 * info.numMovetos        // times 2 to account for possible closing point of contour
                           + info.numLinetos
                           + 3 * info.numCurvetos
                           + 6 * info.numFlexprocs      // flexprocs are always processed as two cubics
                           + 2;                         // side bearings

    // There is a contour for each moveto
    newacs->numContours = info.numMovetos;

    if (((newacs->numPointsMax == 2) && (newacs->seacInfo == NULL)) ||
        (info.xMin == 0 && info.xMax == 0 && info.yMin == 0 && info.yMax == 0))
        newacs->isEmpty = TRUE;
    else if (newacs->numContours != 0)
    {
        newacs->bb.xMin = info.xMin;
        newacs->bb.xMax = info.xMax;
        newacs->bb.yMin = info.yMin;
        newacs->bb.yMax = info.yMax;
    }

    *acs = newacs;

    return cffErr;
}

CFF_ERROR cff_analyzeCharstrings(CFF_TAB* cffTable, LF_MAP* acsMap)
{
    ULONG numGlyphs = cff_indexGetCount(cffTable->charStringsIndex);

    for (ULONG i = 0; i < numGlyphs; i++)
    {
        cffIndexItem* ii = cff_indexGetItem(cffTable->charStringsIndex, i);

        cffAnalyzedCharstring* acs;

        CFF_ERROR cffErr = cff_analyzedCharStringCreate(cffTable, ANALYSIS, ii->data, ii->length, (GlyphID)i, &acs);
        if (cffErr != CFF_ERR_OK)
        {
            return cffErr;
        }

        map_insert(acsMap, (void*)(intptr_t)i, acs);
    }

    return CFF_ERR_OK;
}

CFF_ERROR cff_analyzeCharstringsFully(CFF_TAB* cffTable, LF_MAP* acsMap)
{
    ULONG numGlyphs = cff_indexGetCount(cffTable->charStringsIndex);

    for (ULONG i = 0; i < numGlyphs; i++)
    {
        cffIndexItem* ii = cff_indexGetItem(cffTable->charStringsIndex, i);

        cffAnalyzedCharstring* acs;

        CFF_ERROR cffErr = cff_analyzedCharStringCreate(cffTable, FULL_ANALYSIS, ii->data, ii->length, (GlyphID)i, &acs);
        if (cffErr != CFF_ERR_OK)
        {
            return cffErr;
        }

        map_insert(acsMap, (void*)(intptr_t)i, acs);
    }

    return CFF_ERR_OK;
}

void cff_analyzedCharStringDestroy(cffAnalyzedCharstring* acs)
{
    if (acs->gsubrArray != NULL)
    {
        vector_delete(acs->gsubrArray);
        free(acs->gsubrArray);
    }
    if (acs->subrArray != NULL)
    {
        vector_free(acs->subrArray);
        free(acs->subrArray);
    }
    if (acs->seacInfo != NULL)
        free(acs->seacInfo);

    if (acs->hstems != NULL)
    {
        for (size_t i = 0; i < acs->hstems->count; i++)
            free(vector_at(acs->hstems, i));
        vector_delete(acs->hstems);
        free(acs->hstems);
    }
    if (acs->vstems != NULL)
    {
        for (size_t i = 0; i < acs->vstems->count; i++)
            free(vector_at(acs->vstems, i));
        vector_delete(acs->vstems);
        free(acs->vstems);
    }

    free(acs->rawData);
    free(acs);
}

#ifdef SUBSET_SUBROUTINES

static CFF_ERROR updateSubroutineIndex(BYTE* charStrBuf, ULONG len, boolean global, ULONG numOrigSubrs,
                                       LF_MAP* subrIndexMap, BYTE** newCS, ULONG* newLen)
{
    cffCharStringState state;

    memset(&state, 0, sizeof(cffCharStringState));

    BYTE *p;
    BYTE *ep;
    int opcode;
    //FIXED curx = state->prevx;
    //FIXED cury = state->prevy;
    FIXED *args = state.args;
    int numargs;
    FLEXARGS fa;
    FIXED x0 = 0, y0 = 0, x1 = 0, y1 = 0, x2 = 0, y2 = 0;   //lint !e578
    FIXED px1 = 0, py1 = 0, px2 = 0, py2 = 0;
    FIXED dx1 = 0, dx2 = 0, dx3 = 0, dx6, dx;
    FIXED dy1 = 0, dy2 = 0, dy3 = 0, dy6, dy;
    int idx;
    FIXED v;
    int index;
    CFF_ERROR err; /* for LINETO and CURVETO macros */

    //if (((state->operation == ANALYSIS) && (acs == NULL)) || ((state->operation == FULL_ANALYSIS) && (acs == NULL)) ||
     //   ((state->operation == GENERATION) && (outl == NULL)))
    //{
    //    return CFF_ERR_INTERNAL;
    //}

    p = charStrBuf;
    ep = p + len;

    state.depth++;


    while (p < ep)
    {
        int i, tmp;

        opcode = cff_nextCharStringOpCode(&p, &state.numargs, args, ep);
        numargs = state.numargs;

        if (opcode < 0)
        {
            return CFF_ERR_BAD_OPCODE;
        }

        i = 0;

        switch ((BYTE)opcode)    // cast helps compiler to generate better switch table
        {
        case 1:  // hstem
        case 18: // hstemhm
            state.numargs = 0;
            break;
        case 3:
        case 23:
            state.numargs = 0;
            break;
        case 4: // vmoveto
            state.numargs = 0;
            break;
        case 5: // rlineto
            state.numargs = 0;
            break;
        case 6: // hlineto
            state.numargs = 0;
            break;
        case 7: // vlineto
            state.numargs = 0;
            break;
        case 8: // rrcurveto
            state.numargs = 0;
            break;
        case 10: // callsubr
        {

            if (global == FALSE)
            {
                index = state.args[state.numargs - 1] >> 16;

                if (numOrigSubrs < 1240)
                    index = index + 107;
                else if (numOrigSubrs < 33900)
                    index = index + 1131;
                else
                    index = index + 32768;

                ULONG newIndex = (long)map_at(subrIndexMap, (void*)(long)index);



            }
            else
            {
                state.numargs = 0;
                break;
            }

        }
        break;
        case 11: // return
            state.depth--;
            //return CFF_ERR_OK;
            break;
        case 14: // endchar
            if (numargs < 4)
            {
                state.depth--;
                //return CFF_ERR_OK;
                break;
            }
            else // numargs >= 4
            {
                // seac
                state.depth--;
                //return CFF_ERR_OK;
                break;
            }
            break;
        case 12: // double byte opcodes
            opcode = *p++;
            switch ((BYTE)opcode)
            {
                // remember all arguments are fixed point
            case 3: /* AND */
;
                break;
            case 4: /* OR */

                break;
            case 5: /* NOT */

                break;
            case 9: /*ABS */

                break;
            case 10: /* ADD */

                break;
            case 11: /* SUB */

                break;
            case 12: /* DIV */
            {
            }
            break;
            case 14: /* NEG */

                break;
            case 15: /* EQ */

                break;
            case 18: /* DROP */
                break;
            case 20: /* PUT */
                break;
            case 21: /* GET */
                break;
            case 22: /* IFELSE */
                break;
            case 24: /* MUL */
            {
            }
            break;
            case 26: /* SQRT */
            {
            }
            break;
            case 27: /* DUP */
                break;
            case 28: /* EXCH */
                break;
            case 29: /* INDEX */
                break;
            case 30: /* ROLL */
            {
            }
            break;
            case 34: /* hflex */
                state.numargs = 0;
                break;
            case 35: /* flex */
                state.numargs = 0;
                break;
            case 36: /* hflex1 */
                state.numargs = 0;
                break;
            case 37: /* flex1 */
                state.numargs = 0;
                break;
            default:
                DEBUG_LOG_VALUE("processCharString : bad opcode 12 %d\n", opcode);
                break;
            }  /* end of case 12's switch */
            break; /* end of case 12: */
        case 19: /* hintmask */
            /* if there are any arguments they are VSTEMS */
            if (numargs)
            {
                stems(acs, 0, state, VSTEM);
                state->numargs = 0;
            }
            if (state->operation == FULL_ANALYSIS)
                acs->numHintmasks++;

            /* then the hintmask proper */
            int n = (state->numhstems + state->numvstems + 7) / 8;

            p += n;  // skip past the stems
            break;
        case 20: /* cntrmask */
            /* if there are any arguments they are VSTEMS */
            if (numargs)
            {
                stems(acs, 0, state, VSTEM);
                state->numargs = 0;
            }

            n = (state->numhstems + state->numvstems + 7) / 8;  // then the hintmask proper

            p += n; // skip past the stems
            state->numargs = 0;
            break;
        case 21: /* rmoveto */
            /* syntax |- dx1 dy1 rmoveto (21) |- */
            /* maybe get advance width */
            if ((state->haveAdvanceWidth == FALSE) && (numargs == 3))
            {
                /* get the difference from the escapement and the nominalWidth */
                state->dx = NEXTARG();
                state->haveAdvanceWidth = TRUE;
                if (state->operation <= FULL_ANALYSIS)
                {
                    acs->advanceWidthAdj = state->dx;
                    acs->hasAdwAdj = TRUE;
                }
            }
            curx += NEXTARG();
            cury += NEXTARG();

            MOVETO(curx, cury, outl);

            state->numargs = 0;
            break;
        case 22: /* hmoveto */
            /* syntax |- dx1 hmoveto |- */
            /* maybe get advance width  */
            if ((state->haveAdvanceWidth == FALSE) && (numargs == 2))
            {
                /* get the difference from the escapement and the nominalWidth */
                state->dx = NEXTARG();
                state->haveAdvanceWidth = TRUE;
                if (state->operation <= FULL_ANALYSIS)
                {
                    acs->advanceWidthAdj = state->dx;
                    acs->hasAdwAdj = TRUE;
                }
            }
            curx += NEXTARG();

            MOVETO(curx, cury, outl);

            state->numargs = 0;
            break;
        case 24: /* rcurveline */
            /* syntax |- {dxa dya dxb dyb dxc dyc}+ dxd dyd rcurveline (24) |- */
            tmp = numargs - 2;
            while (i < tmp)
            {
                x0 = curx;
                y0 = cury;
                x1 = curx + NEXTARG();
                y1 = cury + NEXTARG();
                x2 = x1 + NEXTARG();
                y2 = y1 + NEXTARG();
                curx = x2 + NEXTARG();
                cury = y2 + NEXTARG();

                CURVETO(x0, y0, x1, y1, x2, y2, curx, cury, outl);
            }
            curx += NEXTARG();
            cury += NEXTARG();

            LINETO(curx, cury, glyph);

            state->numargs = 0;
            break;
        case 25: /* rlinecurve */
            /* syntax |- {dxa dya}+ dxb dyb dxc dyc dxd dyd rlinecurve (25) |- */
            tmp = numargs - 6;
            while (i < tmp)
            {
                curx += NEXTARG();
                cury += NEXTARG();

                LINETO(curx, cury, glyph);
            }
            x0 = curx;
            y0 = cury;
            x1 = curx + NEXTARG();
            y1 = cury + NEXTARG();
            x2 = x1 + NEXTARG();
            y2 = y1 + NEXTARG();
            curx = x2 + NEXTARG();
            cury = y2 + NEXTARG();

            CURVETO(x0, y0, x1, y1, x2, y2, curx, cury, outl);

            state->numargs = 0;
            break;

        case 26: /* vvcurveto */
            /* syntax |- dx1? {dy1 dx2 dy2 dy3}+ vvcurveto (26) |-  */
            dx1 = dx3 = 0;
            if (numargs & 1)
                dx1 = NEXTARG();
            while (i < numargs)
            {
                dy1 = NEXTARG();
                dx2 = NEXTARG();
                dy2 = NEXTARG();
                dy3 = NEXTARG();
                x0 = curx;
                y0 = cury;
                x1 = curx + dx1;
                y1 = cury + dy1;
                x2 = x1 + dx2;
                y2 = y1 + dy2;
                curx = x2 + dx3;
                cury = y2 + dy3;

                CURVETO(x0, y0, x1, y1, x2, y2, curx, cury, outl);

                dx1 = 0;
            }
            state->numargs = 0;
            break;

        case 27: /* hhcurveto */
            /* syntax  |- dy1? {dx1 dx2 dy2 dx3}+ hhcurveto |- */
            dy1 = dy3 = 0;
            if (numargs & 1)
                dy1 = NEXTARG();
            while (i < numargs)
            {
                dx1 = NEXTARG();
                dx2 = NEXTARG();
                dy2 = NEXTARG();
                dx3 = NEXTARG();
                x0 = curx;
                y0 = cury;
                x1 = curx + dx1;
                y1 = cury + dy1;
                x2 = x1 + dx2;
                y2 = y1 + dy2;
                curx = x2 + dx3;
                cury = y2 + dy3;

                CURVETO(x0, y0, x1, y1, x2, y2, curx, cury, outl);

                dy1 = 0;
            }
            state->numargs = 0;
            break;

        case 29: /* call gsbr */
        {
            if (state->operation <= FULL_ANALYSIS)
            {
                if (acs->gsubrArray == NULL)
                {
                    acs->gsubrArray = vector_create(4, 4);
                    if (acs->gsubrArray == NULL)
                        return CFF_ERR_MEMORY;
                }
            }

            index = state->args[--state->numargs] >> 16;

            state->prevx = curx;
            state->prevy = cury;

            ULONG count = cff_indexGetCount(state->cffTab->globalSubrIndex);

            //apply bias
            if (count < 1240)
                index = index + 107;
            else if (count < 33900)
                index = index + 1131;
            else
                index = index + 32768;

            if (state->operation <= FULL_ANALYSIS)
                vector_push_back(acs->gsubrArray, (void*)(long)index);

            cffIndexItem* ii = cff_indexGetItem(state->cffTab->globalSubrIndex, index);
            if (ii == NULL)
            {
                if (state->operation <= FULL_ANALYSIS)
                {
                    vector_free(acs->gsubrArray);
                    free(acs->gsubrArray);
                    acs->gsubrArray = NULL;
                }
                return CFF_ERR_INTERNAL;
            }

            err = processCharString(state, ii->data, (LONG)ii->length, acs, outl);
            if (err != CFF_ERR_OK)
            {
                if (acs->gsubrArray != NULL)
                {
                    if (state->operation <= FULL_ANALYSIS)
                    {
                        vector_free(acs->gsubrArray);
                        free(acs->gsubrArray);
                        acs->gsubrArray = NULL;
                    }
                }
                return err;
            }

            curx = state->prevx;
            cury = state->prevy;
        }
        break;

        case 30: /* vhcurveto */
            /* syntax1 |-  dy1 dx2 dy3 dx3 {dxa dxb dyb dyc  dyd dxe dye dxf}* dyf? vhcurveto|-  */
            /* syntax2 |- {dya dxb dyb dxc  dxd dxe dye dyf}+ dxf? vhcurveto |-   */
            while (i < numargs)
            {
                tmp = (i + 4) % 8;
                if (tmp == 4)
                {
                    dy1 = NEXTARG();
                    dx2 = NEXTARG();
                    dy2 = NEXTARG();
                    dx3 = NEXTARG();
                    dx1 = dy3 = 0;
                }
                else if (tmp == 0)
                {
                    dx1 = NEXTARG();
                    dx2 = NEXTARG();
                    dy2 = NEXTARG();
                    dy3 = NEXTARG();
                    dy1 = dx3 = 0;
                }
                /* optional last args */
                if ((numargs - i) == 1)
                {
                    if ((numargs % 8) == 1)
                        dx3 = NEXTARG();
                    else if ((numargs % 4) == 1)
                        dy3 = NEXTARG();
                }
                x0 = curx;
                y0 = cury;
                x1 = curx + dx1;
                y1 = cury + dy1;
                x2 = x1 + dx2;
                y2 = y1 + dy2;
                curx = x2 + dx3;
                cury = y2 + dy3;

                CURVETO(x0, y0, x1, y1, x2, y2, curx, cury, outl);
            }
            state->numargs = 0;
            break;
        case 31: /* hvcurveto */
            /* syntax1 |-  dx1 dx2 dy2 dy3 {dya dxb dyb dxc   dxd dxe dye dyf}* dxf? hvcurveto |- */
            /* syntax2 |- {dxa dxb dyb dyc  dyd dxe dye dxf}+ dyf? hvcurveto |-    */
            while (i < numargs)
            {
                tmp = (i + 4) % 8;
                if (tmp == 4)
                {
                    dx1 = NEXTARG();
                    dx2 = NEXTARG();
                    dy2 = NEXTARG();
                    dy3 = NEXTARG();
                    dy1 = dx3 = 0;
                }
                else if (tmp == 0)
                {
                    dy1 = NEXTARG();
                    dx2 = NEXTARG();
                    dy2 = NEXTARG();
                    dx3 = NEXTARG();
                    dx1 = dy3 = 0;
                }
                if ((numargs - i) == 1)
                {
                    if ((numargs % 8) == 1)
                        dy3 = NEXTARG();
                    else if ((numargs % 4) == 1)
                        dx3 = NEXTARG();
                }
                x0 = curx;
                y0 = cury;
                x1 = curx + dx1;
                y1 = cury + dy1;
                x2 = x1 + dx2;
                y2 = y1 + dy2;
                curx = x2 + dx3;
                cury = y2 + dy3;

                CURVETO(x0, y0, x1, y1, x2, y2, curx, cury, outl);
            }
            state->numargs = 0;
            break;

        default:
            DEBUG_LOG_VALUE("processCharString : bad opcode %d\n", opcode);
            break;
        }
    }




    return CFF_ERR_OK;
}

static CFF_ERROR remapSubroutines(cffIndex* index, LF_MAP* subrIndexMap, boolean global, ULONG numOrigSubrs)
{
    // index            - an index of charstrings
    // subrIndexMap     - map having index = old subr index; data = new subr index
    // global           - true if map refers to global subr index false for local subr index

    // loop over the items (charstrings) in the index; for each item. see if it calls any
    // subroutines in the indexmap, if it does, replace the charstring with one that has
    // new indexes

    ULONG i, numSubrs = cff_indexGetCount(index);

    for (i = 0; i < numSubrs; i++)
    {

        cffIndexItem* item = cff_indexGetItem(index, i);

        BYTE* newData = NULL;
        ULONG newLen = 0;

        CFF_ERROR err = updateSubroutineIndex(item->data, item->length, global, numOrigSubrs, subrIndexMap, &newData, &newLen);

        if (err != CFF_ERR_OK)
        {
            return err;
        }

        if (newData != NULL)
        {
            cffIndexItem newItem;
            newItem.data = newData;
            newItem.length = newLen;

            err = cff_indexReplaceCopy(index, i, &newItem);
            if (err != CFF_ERR_OK)
            {
                return err;
            }
        }
    }

    return CFF_ERR_OK;
}

#endif

CFF_ERROR createNewSubrIndex(CFF_TAB* cff, LF_MAP* charStringMap, boolean global, cffIndex** newSubrIndex)
{
    CFF_ERROR cffErr = CFF_ERR_OK;

    *newSubrIndex = NULL;

    ULONG numSubrs;

    if (global == TRUE)
    {
        // there must be a gsubr index, even if it is empty
        if (cff->globalSubrIndex == NULL)
            return CFF_ERR_INTERNAL;

        numSubrs = cff_indexGetCount(cff->globalSubrIndex);

        if (numSubrs == 0)
        {
            return cff_indexCopy(cff->globalSubrIndex, newSubrIndex);
            // *newSubrIndex = cff->globalSubrIndex;
            //cff->globalSubrIndex = NULL;
            //return CFF_ERR_OK;
        }
    }
    else
    {
        // ok if there is no local subr
        if (cff->localSubrIndex == NULL)
            return CFF_ERR_OK;

        numSubrs = cff_indexGetCount(cff->localSubrIndex);

        // should not be empty
        if (numSubrs == 0)
            return CFF_ERR_INTERNAL;
    }

    // create an array of bools, set to TRUE if corresponding subroutine is used.
    boolean* neededSubrsArray = calloc(numSubrs, sizeof(boolean));
    if (neededSubrsArray == NULL)
        return CFF_ERR_MEMORY;

    LF_MAP_ITER* mapIter = map_begin(charStringMap);
    if (mapIter == NULL)
    {
        free(neededSubrsArray);
        return CFF_ERR_MEMORY;
    }

    rb_tree_node* node = map_next(mapIter);

    while (node)
    {
        cffAnalyzedCharstring* acs = (cffAnalyzedCharstring*)node->data;

        LF_VECTOR* indexList = (global == TRUE) ? acs->gsubrArray : acs->subrArray;

        if (indexList != NULL)
        {
            for (size_t i = 0; i < indexList->count; i++)
            {
                size_t saveSubrIndex = (size_t)vector_at(indexList, i);
                neededSubrsArray[saveSubrIndex] = TRUE;
            }
        }

        node = map_next(mapIter);
    }

    map_free_iter(mapIter);

    // See how many are needed. If they are all needed, just use the original index, otherwise create a new one.
    ULONG i, numNeeded = 0;

    for (i = 0; i < numSubrs; i++)
    {
        if (neededSubrsArray[i] == TRUE)
            numNeeded++;
    }

    if (numNeeded < numSubrs)
    {
#ifndef SUBSET_SUBROUTINES
        cffIndex* newIndex;
        cffErr = cff_indexInitializeWithSize(numSubrs, &newIndex);
        if (cffErr != CFF_ERR_OK)
        {
            free(neededSubrsArray);
            return cffErr;
        }

        BYTE foo = 0x0b;                // this is just a return opcode
        cffIndexItem dummyItem;
        dummyItem.data = &foo;
        dummyItem.length = 1;

        // Copy over the ones that are needed, reduce the size of the ones that aren't.
        for (i = 0; i < numSubrs; i++)
        {
            if (neededSubrsArray[i] == TRUE)
            {
                cffIndexItem* curItem;
                if (global == TRUE)
                    curItem = cff_indexGetItem(cff->globalSubrIndex, i);
                else
                    curItem = cff_indexGetItem(cff->localSubrIndex, i);

                cffErr = cff_indexAppendCopy(newIndex, curItem);
            }
            else
                cffErr = cff_indexAppendCopy(newIndex, &dummyItem);

            if (cffErr != CFF_ERR_OK)
            {
                free(neededSubrsArray);
                cff_indexDestroy(newIndex);
                return cffErr;
            }
        }

#else
        cffIndex* newIndex;
        CFF_ERROR cffErr = cff_indexInitializeWithSize(numNeeded, &newIndex);
        if (cffErr != CFF_ERR_OK)
        {
            free(neededSubrsArray);
            return cffErr;
        }


        // Create a map where index = the original subr index and value = the new subr index
        LF_MAP subrIndexMap;

        map_init(&subrIndexMap, integer_compare);

        ULONG curIndex = 0;

        // Add the used subroutines to the new index
        for (i = 0; i < numSubrs; i++)
        {
            if (neededSubrsArray[i] == TRUE)
            {
                cffIndexItem* curItem;
                if (global == TRUE)
                    curItem = cff_indexGetItem(cff->globalSubrIndex, i);
                else
                    curItem = cff_indexGetItem(cff->localSubrIndex, i);

                cffErr = cff_indexAppendCopy(newIndex, curItem);

                if (cffErr != CFF_ERR_OK)
                {
                    free(neededSubrsArray);
                    cff_indexDestroy(newIndex);
                    return cffErr;
                }
            }

            map_insert(&subrIndexMap, (void*)i, (void*)curIndex);
            curIndex++;
        }

        // Now go through the charstrings again and update them with the new subroutine indexes
        mapIter = map_begin(charStringMap);
        if (mapIter == NULL)
        {
            free(neededSubrsArray);
            cff_indexDestroy(newIndex);
            return CFF_ERR_MEMORY;
        }

        node = map_next(mapIter);

        while (node)
        {
            cffAnalyzedCharstring* acs = (cffAnalyzedCharstring*)node->data;

            LF_VECTOR* indexList = (global == TRUE) ? acs->gsubrArray : acs->subrArray;

            if (indexList != NULL)
            {
                for (size_t i = 0; i < indexList->count; i++)
                {
                    USHORT oldSubrIndex = (USHORT)(long)vector_at(indexList, i);
                    USHORT newSubrIndex = (USHORT)(long)map_at(&subrIndexMap, (void*)(long)oldSubrIndex);

                    BYTE* newData = NULL;
                    ULONG newLen;
                    cffErr = updateSubroutineIndex(acs->rawData, acs->rawLen, global, oldSubrIndex, newSubrIndex, &newData, &newLen);

                    if (cffErr != CFF_ERR_OK)
                    {
                        free(neededSubrsArray);
                        cff_indexDestroy(newIndex);
                        return cffErr;
                    }

                    free(acs->rawData);
                    acs->rawData = newData;
                    acs->rawLen = newLen;
                }
            }

            node = map_next(mapIter);
        }

        map_free_iter(mapIter);


        // Go through the global subroutine index and update the indexes
        cffIndex* indexToUse;
        if (global == FALSE)
        {
            numSubrs = cff_indexGetCount(cff->globalSubrIndex);
            indexToUse = cff->globalSubrIndex;
        }
        else
        {
            numSubrs = cff_indexGetCount(newIndex);
            indexToUse = newIndex;
        }


        cffErr = remapSubroutines(indexToUse, subrIndexMap, global, numSubrs);
        if (cffErr != CFF_ERR_OK)
        {
            free(neededSubrsArray);
            cff_indexDestroy(newIndex);
            return cffErr;
        }


        for (i = 0; i < numSubrs; i++)
        {

            cffIndexItem* item = cff_indexGetItem(indexToUse, i);

        }


        // Go through the local subroutine index and update the indexes
        if (global == TRUE)
        {
            numSubrs = cff_indexGetCount(cff->localSubrIndex);
            indexToUse = cff->localSubrIndex;
        }
        else
        {
            numSubrs = cff_indexGetCount(newIndex);
            indexToUse = newIndex;
        }

        cffErr = remapSubroutines(indexToUse, subrIndexMap, global, numSubrs);
        if (cffErr != CFF_ERR_OK)
        {
            free(neededSubrsArray);
            cff_indexDestroy(newIndex);
            return cffErr;
        }

        for (i = 0; i < numSubrs; i++)
        {
            cffIndexItem* item = cff_indexGetItem(indexToUse, i);

        }


#endif

        *newSubrIndex = newIndex;
    }
    else
    {
        if (global == TRUE)
        {
            cffErr = cff_indexCopy(cff->globalSubrIndex, newSubrIndex);
        }
        else
        {
            cffErr = cff_indexCopy(cff->localSubrIndex, newSubrIndex);
        }
    }

    free(neededSubrsArray);

    return cffErr;
}

static CFF_ERROR createNewCIDSubrs(const CFF_TAB* cff, LF_MAP* charStringMap, LF_MAP* fdMap, cffBuiltFDInfo* FDinfoArray)
{
    ULONG numOrigFDs = cff_indexGetCount(cff->FDIndex);
    ULONG numRemainingFDs = map_size(fdMap);

    boolean** boolArray = (boolean**)calloc(numRemainingFDs, sizeof(boolean*));
    if (boolArray == NULL)
        return CFF_ERR_MEMORY;

    LF_MAP_ITER* mapIter = map_begin(charStringMap);
    if (mapIter == NULL)
    {
        for (ULONG j = 0; j < numRemainingFDs; j++)
            free(boolArray[j]);
        free(boolArray);
        return CFF_ERR_MEMORY;
    }

    rb_tree_node* node = map_next(mapIter);

    while (node)
    {
        cffAnalyzedCharstring*acs = (cffAnalyzedCharstring*)node->data;

        LF_VECTOR* indexList = acs->subrArray;

        if (indexList != NULL)
        {
            cffCard8 oldIndex = acs->fdi;
            cffCard8 newIndex = (cffCard8)(intptr_t)map_at(fdMap, (void*)(intptr_t)acs->fdi);

            if (boolArray[newIndex] == NULL)
                boolArray[newIndex] = calloc(cff_indexGetCount(cff->fdInfo[oldIndex].localSubr), sizeof(boolean));
            if (boolArray[newIndex] == NULL)
            {
                for (ULONG j = 0; j < numRemainingFDs; j++)
                    free(boolArray[j]);
                free(boolArray);
                return CFF_ERR_MEMORY;
            }

            for (size_t i = 0; i < indexList->count; i++)
            {
                size_t usedSubrIndex = (size_t)vector_at(indexList, i);

                boolArray[newIndex][usedSubrIndex] = TRUE;
            }
        }

        node = map_next(mapIter);
    }

    map_free_iter(mapIter);

    for (ULONG i = 0; i < numOrigFDs; i++)
    {
        if (map_key_exists(fdMap, (void*)(intptr_t)i))
        {
            ULONG newIndex = (ULONG)(intptr_t)map_at(fdMap, (void*)(intptr_t)i);
            ULONG numSubrs = cff_indexGetCount(cff->fdInfo[i].localSubr);
            ULONG numNeeded = 0;
            ULONG j;

            if (boolArray[newIndex] == NULL)
            {
                // no subroutines from this index are used, so we can remove the whole thing
                FDinfoArray[newIndex].localSubr = NULL;
                continue;
            }

            for (j = 0; j < numSubrs; j++)
            {
                if (boolArray[newIndex][j] == TRUE)
                    numNeeded++;
            }

            if (numNeeded < 7 * numSubrs / 8)
            {
                // create a new Index
                CFF_ERROR cffErr = cff_indexInitializeWithSize(numSubrs, &FDinfoArray[newIndex].localSubr);
                if (cffErr != CFF_ERR_OK)
                {
                    for (ULONG k = 0; k < numRemainingFDs; k++)
                        free(boolArray[k]);
                    free(boolArray);
                    return cffErr;
                }

                BYTE foo = 0x0b;
                cffIndexItem dummyItem;
                dummyItem.data = &foo;
                dummyItem.length = 1;

                // copy over the ones that are needed, reduce the size of the ones that aren't
                for (j = 0; j < numSubrs; j++)
                {
                    if (boolArray[newIndex][j] == TRUE)
                    {
                        cffIndexItem* curItem = cff_indexGetItem(cff->fdInfo[i].localSubr, j);

                        cffErr = cff_indexAppendCopy(FDinfoArray[newIndex].localSubr, curItem);
                    }
                    else
                        cffErr = cff_indexAppendCopy(FDinfoArray[newIndex].localSubr, &dummyItem);

                    if (cffErr != CFF_ERR_OK)
                    {
                        for (ULONG k = 0; k < numRemainingFDs; k++)
                            free(boolArray[k]);
                        free(boolArray);
                        return cffErr;
                    }
                }
            }
            else
            {
                // just use the original
                FDinfoArray[newIndex].localSubr = cff->fdInfo[i].localSubr;
                cff->fdInfo[i].localSubr = NULL;
            }
        }
    }

    for (ULONG j = 0; j < numRemainingFDs; j++)
        free(boolArray[j]);
    free(boolArray);

    return CFF_ERR_OK;
}

// structure to hold temporary items for the font dicts of CID fonts which don't need to be saved/returned to caller
typedef struct
{
    CFFTOPDICT* topDict;                    // un-encoded top dict
    ULONG       topDictsEncodedSize;        // size of encoded top dict
    PRIVATEDICT privDict;                   // un-encoded private dict
} CIDTempInfo;

static void freeCIDTempInfo(CIDTempInfo* p, int count)
{
    if (p)
    {
        for (int i = 0; i < count; i++)
        {
            if (p[i].topDict != NULL)
                unloadTopDict(p[i].topDict);
        }
        free(p);
    }
}

CFF_ERROR cff_buildCFF_TAB(CFF_TAB* cff, LF_MAP* SIDMap, LF_MAP* charStringMap, CFF_TAB_BUILD** builtCff)
{
    // Build the new indexes and dicts after a subset has been done.
    // Note that some indexes from the original CFF_TAB are transferred (instead of copied)
    // to the CFF_TAB_BUILD, leaving the original unusable. The CFF_TAB_BUILD is stored in the
    // cff_table, and used when the table is written.

    LONG numRemainingGlyphs = (LONG)map_size(charStringMap);

    if (numRemainingGlyphs == 0)
        return CFF_ERR_INTERNAL;

    *builtCff = NULL;

    CFF_TAB_BUILD* newCff = (CFF_TAB_BUILD*)calloc(1, sizeof(CFF_TAB_BUILD));
    if (newCff == NULL)
        return CFF_ERR_MEMORY;

    LONG i;
    CFF_ERROR cffErr;

    //
    // fill in the newCff
    //

    // Header
    newCff->header.major = 1;
    newCff->header.minor = 0;
    newCff->header.offSize = 4;         // offsets will always be written as 4 byte values (5 bytes to encode)
    newCff->header.hdrSize = 4;

    // Name INDEX
    // the name of the font doesn't change, so just use the original
    newCff->nameIndex = cff->nameIndex;
    cff->nameIndex = NULL;

    // Top DICT INDEX
    // The top dict index is the next thing in the table, but since the top dict
    // contains offsets which we don't know yet, we defer constructing it.

    // String INDEX
    // If the font has been subsetted, there may be unreferenced SIDs in the string index
    // so we remap the string index into a new one.
    if (SIDMap != NULL)
    {
        cffErr = cff_indexInitializeWithSize(map_size(SIDMap), &newCff->stringIndex);
        if (cffErr != CFF_ERR_OK)
        {
            cff_destroyCFF_TAB(newCff);
            return cffErr;
        }

        LONG origNumStrings = cff_indexGetCount(cff->stringIndex);
        size_t curSID = NUM_STD_STRINGS;

        for (i = 0; i < origNumStrings; i++)
        {
            if (map_key_exists(SIDMap, (void*)(curSID)))
            {
                cffIndexItem* stringItem = cff_indexGetItem(cff->stringIndex, i);
                cffErr = cff_indexAppendCopy(newCff->stringIndex, stringItem);
                if (cffErr != CFF_ERR_OK)
                {
                    cff_destroyCFF_TAB(newCff);
                    return cffErr;
                }
            }

            curSID++;
        }
    }
    else
    {
        // otherwise reuse the original index
        newCff->stringIndex = cff->stringIndex;
        cff->stringIndex = NULL;
    }

    newCff->numGlyphs = (USHORT)numRemainingGlyphs;

    // Global subroutine INDEX
    // create a new reduced in size gsubr index (if needed - this may reuse the existing one)
    cffErr = createNewSubrIndex(cff, charStringMap, TRUE, &newCff->globalSubrIndex);
    if (cffErr != CFF_ERR_OK)
    {
        cff_destroyCFF_TAB(newCff);
        return cffErr;
    }

    // Local subroutine index
    if ((cff->isCID == FALSE) && (cff->localSubrIndex != NULL))
    {
        cffErr = createNewSubrIndex(cff, charStringMap, FALSE, &newCff->localSubrIndex);
        if (cffErr != CFF_ERR_OK)
        {
            cff_destroyCFF_TAB(newCff);
            return cffErr;
        }
    }

    // Charstring INDEX
    // create a new charstring index by copying the ones left in the analyzedCharString map, figure the fonts BB as we go
    cffErr = cff_indexInitializeWithSize(numRemainingGlyphs, &newCff->charStringsIndex);
    if (cffErr != CFF_ERR_OK)
    {
        cff_destroyCFF_TAB(newCff);
        return cffErr;
    }

    LF_MAP_ITER* mapIter = map_begin(charStringMap);
    if (mapIter == NULL)
    {
        cff_destroyCFF_TAB(newCff);
        return CFF_ERR_MEMORY;
    }

    // init bb
    newCff->bb.xMin = newCff->bb.yMin = MYINFINITY;
    newCff->bb.xMax = newCff->bb.yMax = -newCff->bb.yMin;

    rb_tree_node* node = map_next(mapIter);

    while (node)
    {
        cffAnalyzedCharstring*acs = (cffAnalyzedCharstring*)node->data;

        if (acs->isEmpty == FALSE && acs->numContours != 0)
        {
            if (acs->bb.xMin < newCff->bb.xMin)
                newCff->bb.xMin = acs->bb.xMin;
            if (acs->bb.xMax > newCff->bb.xMax)
                newCff->bb.xMax = acs->bb.xMax;
            if (acs->bb.yMin < newCff->bb.yMin)
                newCff->bb.yMin = acs->bb.yMin;
            if (acs->bb.yMax > newCff->bb.yMax)
                newCff->bb.yMax = acs->bb.yMax;
        }
        else if (acs->seacInfo)
        {
            GlyphID baseID = acs->seacInfo->base;
            GlyphID accentID = acs->seacInfo->accent;
            cffAnalyzedCharstring* baseacs = (cffAnalyzedCharstring*)map_at(charStringMap, (void*)(intptr_t)baseID);
            cffAnalyzedCharstring* accentacs = (cffAnalyzedCharstring*)map_at(charStringMap, (void*)(intptr_t)accentID);
            FIXED accentXmin = accentacs->bb.xMin + acs->seacInfo->accentX;
            FIXED accentXmax = accentacs->bb.xMax + acs->seacInfo->accentX;
            FIXED accentYmin = accentacs->bb.yMin + acs->seacInfo->accentY;
            FIXED accentYmax = accentacs->bb.yMax + acs->seacInfo->accentY;
            if (accentXmin < newCff->bb.xMin)
                newCff->bb.xMin = accentXmin;
            if (accentXmax > newCff->bb.xMax)
                newCff->bb.xMax = accentXmax;
            if (accentYmin < acs->bb.yMin)
                acs->bb.yMin = accentYmin;
            if (accentYmax > newCff->bb.yMax)
                newCff->bb.yMax = accentYmax;
            if (baseacs->bb.xMin < newCff->bb.xMin)
                newCff->bb.xMin = baseacs->bb.xMin;
            if (baseacs->bb.xMax > newCff->bb.xMax)
                newCff->bb.xMax = baseacs->bb.xMax;
            if (baseacs->bb.yMin < acs->bb.yMin)
                acs->bb.yMin = baseacs->bb.yMin;
            if (baseacs->bb.yMax > newCff->bb.yMax)
                newCff->bb.yMax = baseacs->bb.yMax;
        }

        cffIndexItem item;
        item.length = acs->rawLen;
        item.data = acs->rawData;

        cffErr = cff_indexAppendCopy(newCff->charStringsIndex, &item);
        if (cffErr != CFF_ERR_OK)
        {
            cff_destroyCFF_TAB(newCff);
            return cffErr;
        }

        node = map_next(mapIter);
    }

    map_free_iter(mapIter);

    // Encodings
    //  for now the top dict will have 0 for the encoding (offset), meaning standard adobe encoding

    // Charset
    cffSID* charset = (cffSID*)malloc(numRemainingGlyphs * sizeof(cffSID));
    if (charset == NULL)
    {
        cff_destroyCFF_TAB(newCff);
        return CFF_ERR_MEMORY;
    }

    for (i = 0; i < numRemainingGlyphs; i++)
    {
        cffAnalyzedCharstring*acs = (cffAnalyzedCharstring*)map_at(charStringMap, (void*)(intptr_t)i);
        charset[i] = acs->sid; // the analyzed charstrings now have the updated SIDs (from when table was remapped)
    }

    cffErr = cff_encodeCharset(charset, numRemainingGlyphs, &newCff->encodedCharset, &newCff->encodedCharsetSize);

    free(charset);

    if (cffErr != CFF_ERR_OK)
    {
        cff_destroyCFF_TAB(newCff);
        return CFF_ERR_MEMORY;
    }

    CIDTempInfo* cidInfo = NULL;        // used only for CID fonts

    // Private dict
    if (cff->isCID == FALSE)
    {
        if (cff->privateDict != NULL)
        {
            cff->privateDict->subrsoff = 0;

            if (newCff->localSubrIndex != NULL)
            {
                // If there is a local subroutine index, it will be written right after the private dict.
                // Dry run encode it once with an invalid offset to get the size. It is encoded for real below.
                cff->privateDict->subrsoff = 1234;

                cffErr = encodePrivateDict(cff->privateDict, NULL, &newCff->encodedPrivateDictSize);
                if (cffErr != CFF_ERR_OK)
                {
                    cff_destroyCFF_TAB(newCff);
                    return cffErr;
                }

                cff->privateDict->subrsoff = newCff->encodedPrivateDictSize;
            }

            cffErr = encodePrivateDict(cff->privateDict, &newCff->encodedPrivateDict, &newCff->encodedPrivateDictSize);
            if (cffErr != CFF_ERR_OK)
            {
                cff_destroyCFF_TAB(newCff);
                return cffErr;
            }
        }
        else
        {
            newCff->encodedPrivateDictSize = 0;
        }
    }
    else
    {
        // Output will be a CID font, with possibly some of the font dicts removed.
        newCff->isCID = TRUE;

        // see which Font Dicts are still needed
        // create a map where the key is the old FD index and the data is the new FD index
        LF_MAP fdMap;
        map_init(&fdMap, integer_compare);

        cffCard8 nextFDI = 0;

        for (i = 0; i < numRemainingGlyphs; i++)
        {
            cffAnalyzedCharstring*acs = (cffAnalyzedCharstring*)map_at(charStringMap, (void*)(intptr_t)i);

            // renumber the needed font dicts from 0 to (num needed -1), based on the order in which
            // it first is used in the remaining glyphs
            if (FALSE == map_key_exists(&fdMap, (void*)(intptr_t)acs->fdi))
                map_insert(&fdMap, (void*)(intptr_t)acs->fdi, (void*)(intptr_t)nextFDI++);
        }

        cffErr = encodeFDSelect(charStringMap, &fdMap, &newCff->encodedFDSelect, &newCff->encodedFDSelectSize);
        if (cffErr != CFF_ERR_OK)
        {
            map_clear(&fdMap);
            cff_destroyCFF_TAB(newCff);
            return CFF_ERR_MEMORY;
        }

        // create new FD info
        newCff->FDcount = map_size(&fdMap);
        newCff->FDinfoArray = (cffBuiltFDInfo*)calloc(newCff->FDcount, sizeof(cffBuiltFDInfo));
        if (newCff->FDinfoArray == NULL)
        {
            map_clear(&fdMap);
            cff_destroyCFF_TAB(newCff);
            return CFF_ERR_MEMORY;
        }

        // 'subset' the local subroutine indexes and add them to the FDinfoArray
        cffErr = createNewCIDSubrs(cff, charStringMap, &fdMap, newCff->FDinfoArray);
        if (cffErr != CFF_ERR_OK)
        {
            map_clear(&fdMap);
            cff_destroyCFF_TAB(newCff);
            return cffErr;
        }

        cidInfo = (CIDTempInfo*)calloc(newCff->FDcount, sizeof(CIDTempInfo));
        if (cidInfo == NULL)
        {
            map_clear(&fdMap);
            cff_destroyCFF_TAB(newCff);
            return CFF_ERR_MEMORY;
        }

        // Encode each of the private dicts. Assumption is that the corresponding local
        // subroutine (if exists) will be written directly after each dict.
        LONG numOrigFDs = cff_indexGetCount(cff->FDIndex);

        for (i = 0; i < numOrigFDs; i++)
        {
            if (map_key_exists(&fdMap, (void*)(intptr_t)i))
            {
                size_t newIndex = (size_t)map_at(&fdMap, (void*)(intptr_t)i);

                memcpy(&cidInfo[newIndex].privDict, cff->fdInfo[i].privateDict, sizeof(PRIVATEDICT));
                if (newCff->FDinfoArray[newIndex].localSubr == NULL)
                    cidInfo[newIndex].privDict.subrsoff = 0;
                else
                    cidInfo[newIndex].privDict.subrsoff = 1234;    // set to invalid value for now

                cffErr = encodePrivateDict(&cidInfo[newIndex].privDict,
                                           &newCff->FDinfoArray[newIndex].encodedPrivateDict,
                                           &newCff->FDinfoArray[newIndex].encodedPrivateDictSize);
                if (cffErr != CFF_ERR_OK)
                {
                    map_clear(&fdMap);
                    freeCIDTempInfo(cidInfo, newCff->FDcount);
                    cff_destroyCFF_TAB(newCff);
                    return cffErr;
                }
            }
        }

        // loop over retained top dicts (aka font dict) and encode them with incorrect offsets so we can get the sizes of the topdicts
        for (i = 0; i < numOrigFDs; i++)
        {
            if (map_key_exists(&fdMap, (void*)(intptr_t)i))
            {
                size_t newIndex = (size_t)map_at(&fdMap, (void*)(intptr_t)i);

                cidInfo[newIndex].topDict = copyTopDict(cff->fdInfo[i].topdict);
                if (cidInfo[newIndex].topDict == NULL)
                {
                    map_clear(&fdMap);
                    freeCIDTempInfo(cidInfo, newCff->FDcount);
                    cff_destroyCFF_TAB(newCff);
                    return CFF_ERR_MEMORY;
                }

                if ((cff->fdInfo[i].topdict->FDFontName >= NUM_STD_STRINGS) && SIDMap != NULL)
                    cidInfo[newIndex].topDict->FDFontName = (cffSID)(intptr_t)map_at(SIDMap, (void*)(intptr_t)cff->fdInfo[i].topdict->FDFontName);
                else
                    cidInfo[newIndex].topDict->FDFontName = cff->fdInfo[i].topdict->FDFontName;

                cidInfo[newIndex].topDict->privateDictOffset = 1234;
                cidInfo[newIndex].topDict->privateDictSize = newCff->FDinfoArray[newIndex].encodedPrivateDictSize;

                // encode each top dict with the incorrect offsets, so that we can get the size of the top dicts
                cffErr = cff_encodeTopDict(cidInfo[newIndex].topDict, NULL, &cidInfo[newIndex].topDictsEncodedSize);
                if (cffErr != CFF_ERR_OK)
                {
                    map_clear(&fdMap);
                    freeCIDTempInfo(cidInfo, newCff->FDcount);
                    cff_destroyCFF_TAB(newCff);
                    return cffErr;
                }
            }
        }

        map_clear(&fdMap);
    }   // CID font

    // TOP DICT
    // now construct a new main top dict
    CFFTOPDICT* newTopDict = copyTopDict(cff->mainTopDict);
    if (newTopDict == NULL)
    {
        freeCIDTempInfo(cidInfo, newCff->FDcount);
        cff_destroyCFF_TAB(newCff);
        return CFF_ERR_MEMORY;
    }

    // remap the SIDs
    if (SIDMap != NULL)
    {
        CFFTOPDICT* t = cff->mainTopDict;

        newTopDict->version = (t->version >= NUM_STD_STRINGS) ? (cffSID)(intptr_t)map_at(SIDMap, (void*)(intptr_t)t->version) : t->version;
        newTopDict->Notice = (t->Notice >= NUM_STD_STRINGS) ? (cffSID)(intptr_t)map_at(SIDMap, (void*)(intptr_t)t->Notice) : t->Notice;
        newTopDict->copyright = (t->copyright >= NUM_STD_STRINGS) ? (cffSID)(intptr_t)map_at(SIDMap, (void*)(intptr_t)t->copyright) : t->copyright;
        newTopDict->FullName = (t->FullName >= NUM_STD_STRINGS) ? (cffSID)(intptr_t)map_at(SIDMap, (void*)(intptr_t)t->FullName) : t->FullName;
        newTopDict->FamilyName = (t->FamilyName >= NUM_STD_STRINGS) ? (cffSID)(intptr_t)map_at(SIDMap, (void*)(intptr_t)t->FamilyName) : t->FamilyName;
        newTopDict->Weight = (t->Weight >= NUM_STD_STRINGS) ? (cffSID)(intptr_t)map_at(SIDMap, (void*)(intptr_t)t->Weight) : t->Weight;
        newTopDict->PostScript = (t->PostScript >= NUM_STD_STRINGS) ? (cffSID)(intptr_t)map_at(SIDMap, (void*)(intptr_t)t->PostScript) : t->PostScript;
        newTopDict->BaseFontName = (t->BaseFontName >= NUM_STD_STRINGS) ? (cffSID)(intptr_t)map_at(SIDMap, (void*)(intptr_t)t->BaseFontName) : t->BaseFontName;
        newTopDict->FDFontName = (t->FDFontName >= NUM_STD_STRINGS) ? (cffSID)(intptr_t)map_at(SIDMap, (void*)(intptr_t)t->FDFontName) : t->FDFontName;
        newTopDict->ros.Registry = (t->ros.Registry >= NUM_STD_STRINGS) ? (cffSID)(intptr_t)map_at(SIDMap, (void*)(intptr_t)t->ros.Registry) : t->ros.Registry;
        newTopDict->ros.Ordering = (t->ros.Ordering >= NUM_STD_STRINGS) ? (cffSID)(intptr_t)map_at(SIDMap, (void*)(intptr_t)t->ros.Ordering) : t->ros.Ordering;
    }

    // The offsets will be encoded as 4 byte values, set them to a non-zero value for
    // now so that the bytes required for them is included in the topdict encoded buffer size
    if (cff->isCID == FALSE)
    {
        newTopDict->privateDictSize = newCff->encodedPrivateDictSize;
        newTopDict->privateDictOffset = 1234;

        newTopDict->FDArrayOffset = 0;
        newTopDict->FDSelectOffset = 0;
    }
    else
    {
        newTopDict->privateDictOffset = 0;
        newTopDict->privateDictSize = 0;

        newTopDict->ros = cff->mainTopDict->ros;
        newTopDict->FDSelectOffset = 1234;
        newTopDict->FDArrayOffset = 1234;
        newTopDict->CIDcount = numRemainingGlyphs;
    }

    newTopDict->encodingOffset = 0;
    newTopDict->charsetOffset = 1234;
    newTopDict->charStringsOffset = 1234;

    // update bounding box
    newTopDict->fontbbox[0] = (LONG)FIXED_TO_DOUBLE(newCff->bb.xMin);   // left
    newTopDict->fontbbox[1] = (LONG)FIXED_TO_DOUBLE(newCff->bb.yMin);   // bottom
    newTopDict->fontbbox[2] = (LONG)FIXED_TO_DOUBLE(newCff->bb.xMax);   // right
    newTopDict->fontbbox[3] = (LONG)FIXED_TO_DOUBLE(newCff->bb.yMax);   // top

    BYTE*   encodedTopDict;
    ULONG   encodedTopDictSize;

    // encode the top dict with the incorrect offsets, so that we can get the size of the top dict
    cffErr = cff_encodeTopDict(newTopDict, NULL, &encodedTopDictSize);
    if (cffErr != CFF_ERR_OK)
    {
        unloadTopDict(newTopDict);
        freeCIDTempInfo(cidInfo, newCff->FDcount);
        cff_destroyCFF_TAB(newCff);
        return cffErr;
    }

    LONG topDictIndexSize = cff_indexGetLengthForSingleItemIndex(encodedTopDictSize);

    // now calculate the correct offsets
    newTopDict->charsetOffset = 4                                                           // header
                                + cff_indexGetLength(newCff->nameIndex)                     // name index
                                + topDictIndexSize                                          // top dict
                                + cff_indexGetLength(newCff->stringIndex)                   // string index
                                + cff_indexGetLength(newCff->globalSubrIndex);              // global subroutine index

    newTopDict->charStringsOffset = newTopDict->charsetOffset                               // total so far
                                    + newCff->encodedCharsetSize;                           // charset

    if (cff->isCID == FALSE)
    {
        newTopDict->privateDictOffset = newTopDict->charStringsOffset + cff_indexGetLength(newCff->charStringsIndex);
    }
    else
    {
        newTopDict->FDSelectOffset = newTopDict->charStringsOffset + cff_indexGetLength(newCff->charStringsIndex);
        newTopDict->FDArrayOffset = newTopDict->FDSelectOffset + newCff->encodedFDSelectSize;
    }

    // now encode it for real
    cffErr = cff_encodeTopDict(newTopDict, &encodedTopDict, &encodedTopDictSize);
    if (cffErr != CFF_ERR_OK)
    {
        unloadTopDict(newTopDict);
        freeCIDTempInfo(cidInfo, newCff->FDcount);
        cff_destroyCFF_TAB(newCff);
        return cffErr;
    }

    // create Top Dict Index
    cffErr = cff_indexInitializeWithSize(1, &newCff->topDictIndex);
    if (cffErr != CFF_ERR_OK)
    {
        unloadTopDict(newTopDict);
        free(encodedTopDict);
        freeCIDTempInfo(cidInfo, newCff->FDcount);
        cff_destroyCFF_TAB(newCff);
        return cffErr;
    }

    cffIndexItem item;
    item.data = encodedTopDict;
    item.length = encodedTopDictSize;

    cffErr = cff_indexAppendCopy(newCff->topDictIndex, &item);
    if (cffErr != CFF_ERR_OK)
    {
        unloadTopDict(newTopDict);
        free(encodedTopDict);
        freeCIDTempInfo(cidInfo, newCff->FDcount);
        cff_destroyCFF_TAB(newCff);
        return cffErr;
    }

    free(encodedTopDict);

    if (newCff->isCID == TRUE)
    {
        if ((cidInfo == NULL) || (newCff->FDcount == 0))
        {
            unloadTopDict(newTopDict);
            cff_destroyCFF_TAB(newCff);
            return CFF_ERR_INTERNAL;
        }

        // create FD Array index
        cffErr = cff_indexInitializeWithSize(newCff->FDcount, &newCff->FDIndex);
        if (cffErr != CFF_ERR_OK)
        {
            freeCIDTempInfo(cidInfo, newCff->FDcount);
            unloadTopDict(newTopDict);
            cff_destroyCFF_TAB(newCff);
            return cffErr;
        }

        // Compute the size of the FDArray (index), then encode the top dicts for real and create the FDArray index
        ULONG* sizes = malloc(newCff->FDcount*sizeof(ULONG));
        if (sizes == NULL)
        {
            freeCIDTempInfo(cidInfo, newCff->FDcount);
            cff_destroyCFF_TAB(newCff);
            unloadTopDict(newTopDict);
            return CFF_ERR_MEMORY;
        }
        for (i = 0; i < newCff->FDcount; i++)
            sizes[i] = cidInfo[i].topDictsEncodedSize;

        LONG fdArrayIndexSize = cff_indexGetLengthForIndexWithSizes(sizes, newCff->FDcount);

        free(sizes);

        // In CID fonts, the FDSelect will be written after the Charstring index,
        // followed by the FDArray, followed by the private dict and local subroutine index
        // for each FD in the array (alternating)
        LONG offsetToPrivateDict = newTopDict->FDArrayOffset + fdArrayIndexSize;

        for (i = 0; i < newCff->FDcount; i++)
        {
            if (cidInfo[i].topDict == NULL)
            {
                freeCIDTempInfo(cidInfo, newCff->FDcount);
                unloadTopDict(newTopDict);
                cff_destroyCFF_TAB(newCff);
                return CFF_ERR_INTERNAL;
            }
            
            cidInfo[i].topDict->privateDictOffset = offsetToPrivateDict;

            // encode the top dict with the correct offset
            cffErr = cff_encodeTopDict(cidInfo[i].topDict, &item.data, &item.length);
            if (cffErr != CFF_ERR_OK)
            {
                freeCIDTempInfo(cidInfo, newCff->FDcount);
                unloadTopDict(newTopDict);
                cff_destroyCFF_TAB(newCff);
                return cffErr;
            }

            ASSERT(cidInfo[i].topDictsEncodedSize == item.length);

            offsetToPrivateDict += newCff->FDinfoArray[i].encodedPrivateDictSize;

            if (newCff->FDinfoArray[i].localSubr != NULL)
            {
                free(newCff->FDinfoArray[i].encodedPrivateDict);
                newCff->FDinfoArray[i].encodedPrivateDict = NULL;

                cidInfo[i].privDict.subrsoff = newCff->FDinfoArray[i].encodedPrivateDictSize;

                cffErr = encodePrivateDict(&cidInfo[i].privDict,
                                           &newCff->FDinfoArray[i].encodedPrivateDict,
                                           &newCff->FDinfoArray[i].encodedPrivateDictSize);
                if (cffErr != CFF_ERR_OK)
                {
                    free(item.data);
                    cff_destroyCFF_TAB(newCff);
                    freeCIDTempInfo(cidInfo, newCff->FDcount);
                    unloadTopDict(newTopDict);
                    return cffErr;
                }

                offsetToPrivateDict += cff_indexGetLength(newCff->FDinfoArray[i].localSubr);
            }

            // add to index
            cffErr = cff_indexAppendCopy(newCff->FDIndex, &item);
            if (cffErr != CFF_ERR_OK)
            {
                free(item.data);
                freeCIDTempInfo(cidInfo, newCff->FDcount);
                unloadTopDict(newTopDict);
                cff_destroyCFF_TAB(newCff);
                return cffErr;
            }

            free(item.data);
        }
    }

    freeCIDTempInfo(cidInfo, newCff->FDcount);  // moved outside of above block to quiet lint
    unloadTopDict(newTopDict);

    *builtCff = newCff;

    return CFF_ERR_OK;
}

void cff_destroyCFF_TAB(CFF_TAB_BUILD* builtCff)
{
    if (builtCff)
    {
        if (builtCff->encodedCharset != NULL)
            free(builtCff->encodedCharset);

        if (builtCff->isCID == FALSE)
        {
            if (builtCff->encodedPrivateDict != NULL)
                free(builtCff->encodedPrivateDict);

            if (builtCff->localSubrIndex != NULL)
                cff_indexDestroy(builtCff->localSubrIndex);
        }
        else
        {
            for (LONG i = 0; i < builtCff->FDcount; i++)
            {
                if (builtCff->FDinfoArray[i].localSubr != NULL)
                    cff_indexDestroy(builtCff->FDinfoArray[i].localSubr);

                free(builtCff->FDinfoArray[i].encodedPrivateDict);
            }

            free(builtCff->FDinfoArray);
            free(builtCff->encodedFDSelect);

            if (builtCff->FDIndex != NULL)
                cff_indexDestroy(builtCff->FDIndex);
        }

        if (builtCff->nameIndex != NULL)
            cff_indexDestroy(builtCff->nameIndex);
        if (builtCff->topDictIndex != NULL)
            cff_indexDestroy(builtCff->topDictIndex);
        if (builtCff->stringIndex != NULL)
            cff_indexDestroy(builtCff->stringIndex);
        if (builtCff->globalSubrIndex != NULL)
            cff_indexDestroy(builtCff->globalSubrIndex);
        if (builtCff->charStringsIndex != NULL)
            cff_indexDestroy(builtCff->charStringsIndex);

        free(builtCff);
    }
}

///////////////////////////////////////////////////////////////////////////////

//
// Functions relating to dumping the cff table
//

static void printIndent(const cffCharStringState* info)
{
    const char depth1str[] = "            ";
    const char depth2str[] = "                ";
    const char depth3str[] = "                    ";
    const char depth4str[] = "                        ";
    const char depth5str[] = "                            ";
    const char depth6str[] = "                                ";

    switch (info->depth)
    {
    case 1: printf("%s", depth1str); return;
    case 2: printf("%s", depth2str); return;
    case 3: printf("%s", depth3str); return;
    case 4: printf("%s", depth4str); return;
    case 5: printf("%s", depth5str); return;
    default: printf("%s", depth6str); return;
    }
}

//lint -e{702} suppress Shift right of signed quantity (int) for this function

static CFF_ERROR dumpCharStringInternal(cffCharStringState* state, BYTE* charString, size_t len, boolean isSubroutine)
{
    SHORT opcode;
    int numargs = 0;
    int *args = state->args;
    int i, j, temp, temp2;
    boolean  firstOp = TRUE;

    BYTE* curPtr = charString;
    BYTE* endPtr = charString + len;

    state->depth++;

    while (curPtr < endPtr)
    {
        i = 0;

        opcode = cff_nextCharStringOpCode(&curPtr, &state->numargs, args, endPtr);
        numargs = state->numargs;

        switch ((BYTE)opcode)    // cast helps compiler to generate better switch table
        {
        case 1:  // hstem
            printIndent(state);
            if ((state->haveAdvanceWidth == FALSE) && (numargs & 1)) // if argcount is odd, first thing is diff between escapement and nominal width
            {
                temp = NEXTARG();
                printf("adw adj      %1.2f\n", FIXED_TO_FLOAT(temp));
                state->haveAdvanceWidth = TRUE;
                printIndent(state);
            }
            printf("hstem        ");
            stems(NULL, i, state, HSTEM);
            if ((isSubroutine) && (firstOp))
                printf("<no context>");
            else if (numargs == 0)
                printf("<no args?>");
            else
            {
                for (j = i; j < numargs; j += 2)
                {
                    temp = NEXTARG();
                    temp2 = NEXTARG();
                    printf("%1.2f, %1.2f", FIXED_TO_FLOAT(temp), FIXED_TO_FLOAT(temp2));
                    if (j < numargs - 2)
                        printf(",  ");
                }
            }
            printf("\n");
            state->numargs = 0;
            break;
        case 3:  // vstem
            printIndent(state);
            if ((state->haveAdvanceWidth == FALSE) && (numargs & 1))
            {
                temp = NEXTARG();
                printf("adw adj      %1.2f\n", FIXED_TO_FLOAT(temp));
                state->haveAdvanceWidth = TRUE;
                printIndent(state);
            }
            printf("vstem        ");
            if ((isSubroutine) && (firstOp))
                printf("<no context>");
            else
            {
                stems(NULL, i, state, VSTEM);
                for (j = i; j < numargs; j += 2)
                {
                    temp = NEXTARG();
                    temp2 = NEXTARG();
                    printf("%1.2f, %1.2f", FIXED_TO_FLOAT(temp), FIXED_TO_FLOAT(temp2));
                    if (j < numargs - 2)
                        printf(",  ");
                }
            }
            printf("\n");
            state->numargs = 0;
            break;
        case 4:  // vmoveto
            printIndent(state);
            if ((state->haveAdvanceWidth == FALSE) && (numargs == 2))
            {
                temp = NEXTARG();
                printf("adw adj      %1.2f\n", FIXED_TO_FLOAT(temp));
                state->haveAdvanceWidth = TRUE;
                printIndent(state);
            }
            printf("vmoveto      ");
            temp = NEXTARG();
            printf("%1.2f\n", FIXED_TO_FLOAT(temp));
            state->numargs = 0;
            break;
        case 5:  // rlineto
            printIndent(state);
            printf("rlineto      ");
            if ((numargs < 2) && (isSubroutine) && (firstOp))
                printf("<no context>");
            else
            {
                for (j = 0; j < numargs; j += 2)
                {
                    temp = NEXTARG(); temp2 = NEXTARG();
                    printf("%1.2f, %1.2f", FIXED_TO_FLOAT(temp), FIXED_TO_FLOAT(temp2));
                    if (j < numargs - 2)
                        printf(",  ");
                }
            }
            printf("\n");
            state->numargs = 0;
            break;
        case 6:  // hlineto
            printIndent(state);
            printf("hlineto      ");
            if ((numargs == 0) && (isSubroutine) && (firstOp))
                printf("<no context>");
            else if (numargs == 0)
                printf("<no args?>");
            else if (numargs & 1)
            {
                // odd number of args
                temp = NEXTARG();  // dx
                printf("dx: %1.2f", FIXED_TO_FLOAT(temp));
                if (numargs > 1)
                {
                    printf("  lines: ");
                    for (j = 1; j < numargs; j += 2)
                    {
                        temp = NEXTARG();
                        temp2 = NEXTARG();
                        printf("%1.2f, %1.2f", FIXED_TO_FLOAT(temp), FIXED_TO_FLOAT(temp2));
                        if (j < numargs - 2)
                            printf(",  ");
                    }
                }
            }
            else
            {
                // even number of args
                printf("lines: ");
                for (j = 0; j < numargs; j += 2)
                {
                    temp = NEXTARG();
                    temp2 = NEXTARG();
                    printf("%1.2f, %1.2f", FIXED_TO_FLOAT(temp), FIXED_TO_FLOAT(temp2));
                    if (j < numargs - 2)
                        printf(",  ");
                }
            }
            printf("\n");
            state->numargs = 0;
            break;
        case 7:  // vlineto
            printIndent(state);
            printf("vlineto      ");
            if ((numargs == 0) && (isSubroutine) && (firstOp))
                printf("<no context>");
            else if (numargs == 0)
                printf("<no data?>");
            else if (numargs & 1)
            {
                // odd number of args
                temp = NEXTARG();  // dy
                printf("dy: %1.2f  ", FIXED_TO_FLOAT(temp));
                if (numargs > 1)
                {
                    printf("lines: ");
                    for (j = 1; j < numargs; j += 2)
                    {
                        temp = NEXTARG();
                        temp2 = NEXTARG();
                        printf("%1.2f, %1.2f", FIXED_TO_FLOAT(temp), FIXED_TO_FLOAT(temp2));
                        if (j < numargs - 2)
                            printf(",  ");
                    }
                }
            }
            else
            {
                // even number of args
                printf("lines: ");
                for (j = 0; j < numargs; j += 2)
                {
                    temp = NEXTARG();
                    temp2 = NEXTARG();
                    printf("%1.2f, %1.2f", FIXED_TO_FLOAT(temp), FIXED_TO_FLOAT(temp2));
                    if (j < numargs - 2)
                        printf(",  ");
                }
            }
            printf("\n");
            state->numargs = 0;
            break;
        case 8:  // rrcurveto
            printIndent(state);
            printf("rrcurveto    ");
            for (j = 0; j < numargs; j += 6)
            {
                printf("{");
                for (int k = j; k < j+6; k += 2)
                {
                    temp = NEXTARG(); temp2 = NEXTARG();
                    printf("%1.2f, %1.2f", FIXED_TO_FLOAT(temp), FIXED_TO_FLOAT(temp2));
                    if (k < j+3)
                        printf(", ");
                }
                printf("}");
                if (j < numargs - 6)
                    printf(", ");
            }
            printf("\n");
            state->numargs = 0;
            break;
        case 10:  // callsubr
            printIndent(state);
            printf("callsubr     ");
            int index = args[state->numargs - 1] >> 16;
            state->numargs--;

            size_t count = cff_indexGetCount(state->cffTab->localSubrIndex);

            if (count < 1240)
                index = index + 107;
            else if (count < 33900)
                index = index + 1131;
            else
                index = index + 32768;

            printf("%d\n", index);

            cffIndexItem* obj = cff_indexGetItem(state->cffTab->localSubrIndex, index);
            if (obj == NULL)
                return CFF_ERR_BAD_FORMAT;
            CFF_ERROR err = dumpCharStringInternal(state, obj->data, obj->length, (boolean)((isSubroutine) && (firstOp)));
            if (err != CFF_ERR_OK)
                return err;
            break;
        case 11:  // return
            printIndent(state);
            printf("return\n");
            state->depth--;
            return CFF_ERR_OK; //check
        case 14:  // endchar
            printIndent(state);
            if ((state->haveAdvanceWidth == FALSE) && (numargs == 1))
            {
                temp = NEXTARG();
                printf("adw adj      %1.2f\n", FIXED_TO_FLOAT(temp));
                state->haveAdvanceWidth = TRUE;
                printIndent(state);
            }
            if (numargs == 5)
            {
                temp = NEXTARG();
                printf("adw adj      %1.2f\n", FIXED_TO_FLOAT(temp));
                state->haveAdvanceWidth = TRUE;
                printIndent(state);
            }
            printf("endchar");
            if (numargs < 4)
            {
                printf("\n");
                state->depth--;
                return CFF_ERR_OK;
            }
            else
            {
                int adx = NEXTARG();
                int ady = NEXTARG();
                int baseChar = NEXTARGNONCOORD();
                int accentChar = NEXTARGNONCOORD();
                int basegid = adobeindex(state->cffTab, baseChar);
                int accentgid = adobeindex(state->cffTab, accentChar);
                printf("      <seac>    base: %d (gid %d)  accent: %d (gid %d)   dx=%1.2f dy=%1.2f\n",
                        baseChar, basegid, accentChar, accentgid, FIXED_TO_FLOAT(adx), FIXED_TO_FLOAT(ady));

                state->depth--;
                return CFF_ERR_OK;
            }

        case 12:  // double byte opcodes
            opcode = *curPtr++;
            switch ((BYTE)opcode)
            {
            case 3: /* AND */
                printIndent(state);
                printf("AND        ");
                temp = POPCFFARG();
                temp2 = POPCFFARG();
                PUSHCFFARG((temp && temp2));
                printf("%d  %d : %d\n", temp, temp2, (temp && temp2) ? 1 : 0);
                break;
            case 4:  // OR
                printIndent(state);
                printf("OR          ");
                temp = POPCFFARG();
                temp2 = POPCFFARG();
                PUSHCFFARG((temp || temp2));
                printf("%d  %d : %d\n", temp, temp2, (temp || temp2) ? 1 : 0);
                break;
            case 5:  // NOT
                printIndent(state);
                printf("NOT         ");
                temp = POPCFFARG();
                PUSHCFFARG((temp == 0));
                printf("%d : %d\n", temp, (temp == 0) ? 1 : 0);
                break;
            case 9:  // ABS
                printIndent(state);
                printf("ABS        ");
                temp = POPCFFARG();
                temp2 = temp;
                if (temp < 0) temp = -temp;
                PUSHCFFARG(temp);
                printf("%d : %d\n", temp2, temp);
                break;
            case 10:  // ADD
                printIndent(state);
                printf("ADD        ");
                temp2 = POPCFFARG();
                temp = POPCFFARG();
                PUSHCFFARG((temp + temp2));
                printf("%d  %d : %d\n", temp2, temp, temp2 + temp);
                break;
            case 11:  // SUB
                printIndent(state);
                printf("SUB         ");
                temp2 = POPCFFARG();
                temp = POPCFFARG();
                PUSHCFFARG((temp - temp2));
                printf("%d  %d : %d\n", temp2, temp, temp - temp2);
                break;
            case 12:  // DIV
                {
                printIndent(state);
                printf("DIV          ");
                temp2 = POPCFFARG();
                temp = POPCFFARG();
                double d = FIXED_TO_DOUBLE(temp) / FIXED_TO_DOUBLE(temp2);
                PUSHCFFARG(DOUBLE_TO_FIXED(d));
                printf("%d  %d   : %1.3f (%d)\n", temp2, temp, d, DOUBLE_TO_FIXED(d));
                }
                break;
            case 14:  // NEG
                printIndent(state);
                printf("NEG         ");
                temp = POPCFFARG();
                PUSHCFFARG(-temp);
                printf("  %d : %d\n", temp, -temp);
                break;
            case 15:  // EQ
                printIndent(state);
                printf("EQ             ");
                temp2 = POPCFFARG();
                temp = POPCFFARG();
                PUSHCFFARG((temp == temp2));
                printf("%d  %d : %d\n", temp2, temp, (temp == temp2) ? 1 : 0);
                break;
            case 18:  // DROP
                printIndent(state);
                printf("DROP       ");
                temp2 = POPCFFARG();
                printf("%d\n", temp2);
                break;
            case 20:  // PUT
                printIndent(state);
                printf("PUT       ");
                temp = POPCFFARG() >> 16;
                temp2 = POPCFFARG();
                printf("%d  %d\n", temp2, temp);
                break;
            case 21:  // GET
                printIndent(state);
                printf("GET         ");
                temp = POPCFFARG() >> 16;
                //if (idx >= 0 && idx < 32)
                //    v = cffoutl->transient[idx];
                PUSHCFFARG(temp);
                printf("%d\n", temp);
                break;
            case 22:  // IFELSE
                printIndent(state);
                printf("IFELSE\n");
                //py2 = POPCFFARG();
                //py1 = POPCFFARG();
                //px1 = POPCFFARG();
                //px2 = POPCFFARG();
                //PUSHCFFARG(((py1 <= py2) ? px1 : px2));
                break;
            case 24:  // MUL
                printIndent(state);
                printf("MUL\n");
                break;
            case 26:  // SQRT
                printIndent(state);
                printf("SQRT\n");
                break;
            case 27:  // DUP
                printIndent(state);
                printf("DUP\n");
                break;
            case 28:  // EXCH
                printIndent(state);
                printf("EXCH\n");
                break;
            case 29:  // INDEX
                printIndent(state);
                printf("INDEX\n");
                break;
            case 30:  // ROLL
                printIndent(state);
                printf("ROLL\n");
                break;
            case 34:  // hflex
                {
                printIndent(state);
                // hflex |- dx1 dx2 dy2 dx3 dx4 dx5 dx6 hflex (12 34) |-
                printf("hflex        ");
                temp = NEXTARG(); temp2 = NEXTARG();
                int t3, t4, t5, t6, t7;
                t3 = NEXTARG(); t4 = NEXTARG(); t5 = NEXTARG(); t6 = NEXTARG(); t7 = NEXTARG();
                printf("dx1:%1.2f dx2:%1.2f dy2:%1.2f dx3:%1.2f dx4:%1.2f dx5:%1.2f dx6:%1.2f",
                       FIXED_TO_DOUBLE(temp), FIXED_TO_DOUBLE(temp2), FIXED_TO_DOUBLE(t3), FIXED_TO_DOUBLE(t4),
                       FIXED_TO_DOUBLE(t5), FIXED_TO_DOUBLE(t6), FIXED_TO_DOUBLE(t7));
                printf("\n");
                state->numargs = 0;
                }
                break;
            case 35:  // flex
                printIndent(state);
                printf("flex (opcode 35) { ");
                temp = NEXTARG(); temp2 = NEXTARG();
                printf("(%1.2f,%1.2f), ", FIXED_TO_DOUBLE(temp), FIXED_TO_DOUBLE(temp2));
                temp = NEXTARG(); temp2 = NEXTARG();
                printf("(%1.2f,%1.2f), ", FIXED_TO_DOUBLE(temp), FIXED_TO_DOUBLE(temp2));
                temp = NEXTARG(); temp2 = NEXTARG();
                printf("(%1.2f,%1.2f), ", FIXED_TO_DOUBLE(temp), FIXED_TO_DOUBLE(temp2));
                temp = NEXTARG(); temp2 = NEXTARG();
                printf("(%1.2f,%1.2f) }", FIXED_TO_DOUBLE(temp), FIXED_TO_DOUBLE(temp2));
                temp = NEXTARG();
                printf("  fd: %d", temp);
                printf("\n");
                state->numargs = 0;
                break;
            case 36:  // hflex1
            {
                printIndent(state);
                // |- dx1 dy1 dx2 dy2 dx3 dx4 dx5 dy5 dx6 hflex1 (12 36) |-
                printf("hflex1       ");
                if ((numargs < 9) /*&& (isSubroutine) && (firstOp)*/)
                    printf("<insufficient context>");
                else
                {
                    temp = NEXTARG(); temp2 = NEXTARG();
                    int t3, t4, t5, t6, t7, t8;
                    t3 = NEXTARG(); t4 = NEXTARG(); t5 = NEXTARG(); t6 = NEXTARG(); t7 = NEXTARG(); t8 = NEXTARG();
                    printf("dx1:%1.2f dy1:%1.2f dx2:%1.2f dy2:%1.2f dx3:%1.2f dx4:%1.2f dx5:%1.2f, dx5:%1.2f",
                           FIXED_TO_DOUBLE(temp), FIXED_TO_DOUBLE(temp2), FIXED_TO_DOUBLE(t3), FIXED_TO_DOUBLE(t4),
                           FIXED_TO_DOUBLE(t5), FIXED_TO_DOUBLE(t6), FIXED_TO_DOUBLE(t7), FIXED_TO_DOUBLE(t8));
                }
                printf("\n");
                state->numargs = 0;
                }
                break;
            case 37:  // flex1
                {
                printIndent(state);
                // |- dx1 dy1 dx2 dy2 dx3 dy3 dx4 dy4 dx5 dy5 d6 flex1 (12 37) |-
                printf("flex1        ");
                temp = NEXTARG(); temp2 = NEXTARG();
                int t3 = NEXTARG();
                int t4 = NEXTARG();
                int t5 = NEXTARG();
                int t6 = NEXTARG();
                int t7 = NEXTARG();
                int t8 = NEXTARG();
                int t9 = NEXTARG();
                int t10= NEXTARG();
                int t11= NEXTARG();
                printf("dx1:%1.2f dy1:%1.2f dx2:%1.2f dy2:%1.2f dx3:%1.2f dy3:%1.2f dx4:%1.2f dy4:%1.2f dx5:%1.2f dy5:%1.2f dx6:%1.2f ",
                       FIXED_TO_DOUBLE(temp), FIXED_TO_DOUBLE(temp2), FIXED_TO_DOUBLE(t3), FIXED_TO_DOUBLE(t4),
                       FIXED_TO_DOUBLE(t5), FIXED_TO_DOUBLE(t6), FIXED_TO_DOUBLE(t7), FIXED_TO_DOUBLE(t8),
                       FIXED_TO_DOUBLE(t9), FIXED_TO_DOUBLE(t10), FIXED_TO_DOUBLE(t11));
                printf("\n");
                state->numargs = 0;
                }
                break;
            default:
                printIndent(state);
                printf("bad opcode 12 %d\n",opcode);
                break;
            }  // end of case 12's switch
            break;
        case 18: // hstemhm
            printIndent(state);
            if ((state->haveAdvanceWidth == FALSE) && (numargs & 1))
            {
                temp = NEXTARG();
                printf("adw adj      %1.2f\n", FIXED_TO_FLOAT(temp));
                state->haveAdvanceWidth = TRUE;
                printIndent(state);
            }
            printf("hstemhm      ");
            for (j = i; j < numargs; j += 2)
            {
                temp = NEXTARG();
                temp2 = NEXTARG();
                printf("%1.2f, %1.2f", FIXED_TO_FLOAT(temp), FIXED_TO_FLOAT(temp2));
                if (j < numargs - 2)
                    printf(",  ");
            }
            printf("\n");
            stems(NULL, i, state, HSTEM);
            state->numargs = 0;
            break;
        case 19:   // hintmask
            printIndent(state);
            printf("hintmask     ");
            if ((numargs == 0) && (isSubroutine) && (firstOp))
                printf("<no context>");
            else if (numargs == 0)
                printf("<no args?>");
            if (numargs)
            {
                stems(NULL, 0, state, VSTEM);
                state->numargs = 0;
            }
            for (j = 0; j < numargs; j++)
            {
                temp = NEXTARG();
                printf("0x%x ", temp);
            }
            printf("\n");
            int n = (state->numhstems + state->numvstems + 7) / 8;
            curPtr += n;  // skip past the stems
            break;
        case 20:   // cntrmask
            printIndent(state);
            printf("cntrmask     ");
            if ((numargs == 0) && (isSubroutine) && (firstOp))
                printf("<no context>");
            else
            {
                if (numargs)
                {
                    stems(NULL, 0, state, VSTEM);
                    state->numargs = 0;
                }
                n = (state->numhstems + state->numvstems + 7) / 8;
                curPtr += n; // skip past the stems
                for (j = 0; j < numargs; j++)
                {
                    temp = NEXTARG();
                    printf("0x%x ", temp);
                }
            }
            printf("\n");
            state->numargs = 0;
            break;
        case 21:   // rmoveto
            printIndent(state);
            if ((state->haveAdvanceWidth == FALSE) && (numargs == 3))
            {
                temp = NEXTARG();
                printf("adw adj      %1.2f\n", FIXED_TO_FLOAT(temp));
                state->haveAdvanceWidth = TRUE;
                printIndent(state);
            }
            printf("rmoveto      ");
            if ((numargs < 2) && (isSubroutine) && (firstOp))
                printf("<insufficient context>");
            else
            {
                temp = NEXTARG();
                temp2 = NEXTARG();
                printf("%1.2f, %1.2f", FIXED_TO_FLOAT(temp), FIXED_TO_FLOAT(temp2));
            }
            printf("\n");
            state->numargs = 0;
            break;
        case 22:   // hmoveto
            printIndent(state);
            if ((numargs == 0) && (isSubroutine) && (firstOp))
                printf("<no context>");
            else
            {
                if ((state->haveAdvanceWidth == FALSE) && (numargs == 2))
                {
                    temp = NEXTARG();
                    printf("adw adj      %1.2f\n", FIXED_TO_FLOAT(temp));
                    state->haveAdvanceWidth = TRUE;
                    printIndent(state);
                }
                printf("hmoveto      ");
                temp = NEXTARG();
                printf("%1.2f\n", FIXED_TO_FLOAT(temp));
            }
            state->numargs = 0;
            break;
        case 23:   // vstemhm
            printIndent(state);
            if ((numargs == 0) && (isSubroutine) && (firstOp))
                printf("<no context>");
            else
            {
                if ((state->haveAdvanceWidth == FALSE) && (numargs & 1))
                {
                    temp = NEXTARG();
                    printf("adw adj      %1.2f\n", FIXED_TO_FLOAT(temp));
                    state->haveAdvanceWidth = TRUE;
                    printIndent(state);
                }
                printf("vstemhm      ");
                for (j = i; j < numargs; j += 2)
                {
                    temp = NEXTARG();
                    temp2 = NEXTARG();
                    printf("%1.2f, %1.2f", FIXED_TO_FLOAT(temp), FIXED_TO_FLOAT(temp2));
                    if (j < numargs - 2)
                        printf(",  ");
                }
            }
            printf("\n");
            stems(NULL, i, state, VSTEM);
            state->numargs = 0;
            break;
        case 24:   // rcurveline
            printIndent(state);
            printf("rcurveline   ");
            if ((numargs < 6) && (isSubroutine) && (firstOp))
                printf("<insufficient context>");
            else
            {
                for (j = 0; j < numargs - 2; j += 6)
                {
                    printf("{");
                    for (int k = j; k < 6; k += 2)
                    {
                        temp = NEXTARG(); temp2 = NEXTARG();
                        printf("%1.2f, %1.2f", FIXED_TO_FLOAT(temp), FIXED_TO_FLOAT(temp2));
                        if (k < j + 4)
                            printf(", ");
                    }
                    printf("}");
                    if (j < numargs - 6)
                        printf(",  ");
                }
                temp = NEXTARG();
                temp2 = NEXTARG();
                printf(" %1.2f, %1.2f", FIXED_TO_FLOAT(temp), FIXED_TO_FLOAT(temp2));
            }
            printf("\n");
            state->numargs = 0;
            break;
        case 25:   // rlinecurve
            printIndent(state);
            printf("rlinecurve   ");
            if ((numargs < 6) && (isSubroutine) && (firstOp))
                printf("<insufficient context>");
            else
            {
                for (j = 0; j < numargs - 6; j += 2)
                {
                    temp = NEXTARG();
                    temp2 = NEXTARG();
                    printf("%1.2f, %1.2f, ", FIXED_TO_FLOAT(temp), FIXED_TO_FLOAT(temp2));
                }
                printf(" curve: ");
                for (int k = j; k < j + 6; k += 2)
                {
                    temp = NEXTARG(); temp2 = NEXTARG();
                    printf("%1.2f, %1.2f", FIXED_TO_FLOAT(temp), FIXED_TO_FLOAT(temp2));
                    if (k < j + 4)
                        printf(", ");
                }
            }
            printf("\n");
            state->numargs = 0;
            break;
        case 26:   // vvcurveto
            {
            printIndent(state);
            printf("vvcurveto    ");
            if ((numargs == 0) && (isSubroutine) && (firstOp))
                printf("<no context>");
            else if (numargs == 0)
                printf("<no data?>");
            else if (numargs < 4)
                printf("<insufficient args?>");
            else
            {
                if (numargs & 1)
                {
                    temp = NEXTARG();
                    printf("dx1:%1.2f  ", FIXED_TO_FLOAT(temp));
                }
                int numSets = (numargs & 1) ? (numargs - 1) / 4 : numargs / 4;
                int t3, t4;
                printf("data: {");
                for (j = 0; j < numSets; j++)
                {
                    temp = NEXTARG(); temp2 = NEXTARG();
                    t3 = NEXTARG(); t4 = NEXTARG();
                    printf("%1.2f, %1.2f, %1.2f, %1.2f", FIXED_TO_FLOAT(temp), FIXED_TO_FLOAT(temp2), FIXED_TO_FLOAT(t3), FIXED_TO_FLOAT(t4));
                    if (j == numSets - 1)
                        printf("}");
                    else
                        printf("}, {");
                }
            }
            printf("\n");
            state->numargs = 0;
            }
            break;
        case 27:   // hhcurveto
            {
            printIndent(state);
            printf("hhcurveto    ");
            if ((numargs == 0) && (isSubroutine) && (firstOp))
                printf("<no context>");
            else if (numargs == 0)
                printf("<no data?>");
            else
            {
                if (numargs & 1)
                {
                    temp = NEXTARG();
                    printf("dy1: %1.2f  ", FIXED_TO_FLOAT(temp));
                }

                int numSets = (numargs & 1) ? (numargs - 1) / 4 : numargs / 4;
                int t3, t4;
                if (numSets == 0)
                    printf("<no data?>");
                else
                {
                    printf("Bezier data: {");
                    for (j = 0; j < numSets; j++)
                    {
                        temp = NEXTARG(); temp2 = NEXTARG();
                        t3 = NEXTARG(); t4 = NEXTARG();
                        printf("dx1:%1.2f dx2:%1.2f dy2:%1.2f dx3:%1.2f", FIXED_TO_FLOAT(temp), FIXED_TO_FLOAT(temp2), FIXED_TO_FLOAT(t3), FIXED_TO_FLOAT(t4));
                        if (j == numSets - 1)
                            printf("}");
                        else
                            printf("} , {");
                    }
                }
            }
            printf("\n");
            state->numargs = 0;
            }
            break;

        case 29:   // call gsbr
            {
                printIndent(state);
                printf("call gsbr   ");

                index = args[--state->numargs] >> 16;

                size_t count2 = cff_indexGetCount(state->cffTab->globalSubrIndex);

                //apply bias
                if (count2 < 1240)
                    index = index + 107;
                else if (count2 < 33900)
                    index = index + 1131;
                else
                    index = index + 32768;

                printf(" %d\n", index);

                cffIndexItem* ii = cff_indexGetItem(state->cffTab->globalSubrIndex, index);
                if (ii == NULL)
                    return CFF_ERR_BAD_FORMAT;
                CFF_ERROR cffErr = dumpCharStringInternal(state, ii->data, ii->length, (boolean)((isSubroutine) && (firstOp)));
                if (cffErr != CFF_ERR_OK)
                    return cffErr;
            }
            break;
        case 30:   // vhcurveto
            printIndent(state);
            if ((numargs == 0) && (isSubroutine) && (firstOp))
                printf("<no context>");
            else
            {
                printf("vhcurveto    data:");
                while (i < numargs)
                {
                    temp = NEXTARG();
                    printf("%1.2f ", FIXED_TO_FLOAT(temp));
                }
            }
            printf("\n");
            state->numargs = 0;
            break;
        case 31:   // hvcurveto
            printIndent(state);
            printf("hvcurveto    data:");
            if ((numargs == 0) && (isSubroutine) && (firstOp))
                printf("<no context>");
            else if (numargs == 0)
                printf("<no data?>");
            else
            {
                while (i < numargs)
                {
                    temp = NEXTARG();
                    printf("%1.2f ", FIXED_TO_FLOAT(temp));
                }
            }
            printf("\n");
            state->numargs = 0;
            break;

        default:
            printIndent(state);
            printf("ERROR! bad opcode %d\n", opcode);
            return CFF_ERR_BAD_OPCODE;
        }

        firstOp = FALSE;
    }

    state->depth--;

    return CFF_ERR_OK;
}

CFF_ERROR cff_dumpCharString(CFF_TAB* cffTab, BYTE* charString, size_t len, LONG index, boolean isSubroutine)
{
    cffCharStringState info;

    info.cffTab = cffTab;
    info.haveAdvanceWidth = FALSE;
    info.numargs = 0;
    info.depth = 0;
    info.numhstems = 0;
    info.numvstems = 0;
    info.operation = DUMPING;

    if ((cffTab->isCID == TRUE) && (index != -1))
        selectCIDdict(cffTab, index);

    return dumpCharStringInternal(&info, charString, len, isSubroutine);
}
