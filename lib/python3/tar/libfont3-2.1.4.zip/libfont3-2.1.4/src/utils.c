// Copyright (C) 2014, 2015, 2016 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// utils.c

#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <memory.h>
#include <math.h>
#include "data_types.h"
#include "utils.h"
#include "lf_error.h"

//
// Globals for logging and dumping of OpenType data
//

// To enable logging, you must define LF_LOGGING in the project settings.
// A file will be created in the input font folder called <font>.log.
//
// To enable dumping of OpenType table information, you must define
// LF_OT_DUMP in the project settings and then add calls in the code to the
// appropriate dump routine for the object(s) you wish to dump.
// A file will be created in the input font folder called <font>.xml.

#ifdef LF_LOGGING
static FILE*    hLogfile = NULL;                    // File handle for log file.
#endif
#ifdef LF_OT_DUMP
static FILE*    hXMLfile = NULL;                    // File handle for xml for OpenType data.
static int      nXmlIndex = 0;                      // Current indent depth in OT dump xml file.
#endif

// You can also set LF_VERBOSITY in the project settings to one of the below levels:
//  LIBFONT_VERBOSE_NONE = 0
//  LIBFONT_VERBOSE_ERRORS = 1
//  LIBFONT_VERBOSE_INFO = 2
//  LIBFONT_VERBOSE_WARNINGS = 3
//  LIBFONT_VERBOSE_ALL = 4             (default)
//
#if defined(LF_LOGGING) || defined(LF_OT_DUMP)
#ifdef LF_VERBOSITY
static int      nVerbose = LF_VERBOSITY;            // Logging verbosity
#else
static int      nVerbose = LIBFONT_VERBOSE_ALL;     // Logging verbosity
#endif
#endif



//
// Math routines
//

static INLINE double ceil0(const double value)
{
    double result = ceil(fabs(value));
    return (value < 0.0) ? -result : result;
}

static INLINE double roundhalfup(const double value)
{
    return floor(value + 0.5);
}

static INLINE double roundhalfup0(const double value)
{
    double result = roundhalfup(fabs(value));
    return (value < 0.0) ? -result : result;
}

double UTILS_roundhalfeven(double value, double epsilon)
{
    double ipart;

    if (value < 0.0) 
        return -UTILS_roundhalfeven(-value, epsilon);

    (void)modf(value, &ipart);

    //if (fraction <= 0.5)
    //    return ipart;

    //return ipart + 1;

    if ((value - ipart) == 0)
        return value;

    // If 'value' is exctly halfway between two integers
    if (fabs(value - (ipart + 0.5)) < epsilon)
    {
        // If 'ipart' is even then return 'ipart'
        if (fmod(ipart, 2.0) < epsilon)
            return ipart;

        // Else return the nearest even integer
        return ceil0(ipart + 0.5);
    }

    // Otherwise use the usual round to closest
    // (Either symmetric half-up or half-down will do0
    return roundhalfup0(value);
}



//
// Table calculation routines
//

ULONG UTILS_CalcTableChecksum(BYTE* table, size_t Length)
{
    ULONG Sum = 0L;
    ULONG* Ptr = (ULONG*)(void*)table;
    ULONG* EndPtr = Ptr+((Length+3) & ~3) / sizeof(ULONG);
    while (Ptr < EndPtr)
    {
        Sum += SWAP_ULONG(*Ptr);
        Ptr++;
    }

    return Sum;
}

ULONG UTILS_CalcTableRecordChecksum(BYTE* table, size_t Length)
{
    ULONG Sum = 0L;
    ULONG* Ptr = (ULONG*)(void*)table;
    ULONG* EndPtr = Ptr+(Length/sizeof(ULONG));
    while (Ptr < EndPtr)
    {
        Sum += *Ptr;
        Ptr++;
    }
    return Sum;
}

#define SWAP_WORDS(x)    (ULONG)(((x) >> 16) | (((x) & 0x0000FFFF) << 16) )

ULONG UTILS_CalcHeaderChecksum(BYTE* header)
{
    ULONG  Sum = 0L;
    ULONG* pLong = (ULONG*)(void*)header;
    ULONG  value;

    Sum += *pLong++;  // version

    value = *pLong++;  // numTables and searchRange
    value = SWAP_WORDS(value);
    Sum += value;

    value = *pLong;  // entrySelector and rangeShift
    value = SWAP_WORDS(value);
    Sum += value;

    return Sum;
}

BYTE* UTILS_AllocTable(size_t* length)
{
    size_t padLen = (ULONG)((*length + 3) & ~3);
    BYTE* buffer = (BYTE*)malloc(padLen);
    if (buffer != NULL)
    {
        memset(buffer + *length, 0, padLen - *length);
        *length = padLen;
    }
    return buffer;
}

BYTE* UTILS_PadTable(BYTE **table, size_t length, ULONG* padLen)
{
    *padLen = (ULONG)((length + 3) & ~3);  // length of a table should never exceed 32 bits.

    if(*padLen != length)
    {
        *table = (BYTE*)realloc(*table, *padLen);
        memset(*table + length, 0, *padLen - length);
    }

    return *table;
}

/* ----------------------------------------------------------------------------
@summary
return the count in a table.  this method checks to ensure
it is within 16bit value (the standard for font files) and
returns it to the caller.

@param
v = pointer to the vector array.

@return
the 16bit size of the vector
---------------------------------------------------------------------------- */
USHORT UTILS_getCount(LF_VECTOR* v)
{
    size_t count;

    ASSERT(v);

    count = vector_size(v);

    if (count > 65535)
    {
        DEBUG_LOG_WARNING("count exceeds limits of 16bit count");
    }
    return (USHORT)count;
}



//
// Error message routine
//

char* UTILS_getErrorMessage(LF_ERROR e)
{
    switch (e)
    {
    case LF_ERROR_OK:           return "LF_ERROR_OK";
    case LF_ADDED_GLYPH:        return "LF_ADDED_GLYPH";
    case LF_BAD_FORMAT:         return "LF_BAD_FORMAT";
    case LF_NOT_COVERED:        return "LF_NOT_COVERED";
    case LF_EMPTY_TABLE:        return "LF_EMPTY_TABLE";
    case LF_OUT_OF_MEMORY:      return "LF_OUT_OF_MEMORY";
    case LF_INVALID_SUBTABLE:   return "LF_INVALID_SUBTABLE";
    case LF_INVALID_OFFSET:     return "LF_INVALID_OFFSET";
    case LF_INVALID_LENGTH:     return "LF_INVALID_LENGTH";
    case LF_INVALID_INDEX:      return "LF_INVALID_INDEX";
    case LF_INVALID_TYPE:       return "LF_INVALID_TYPE";
    case LF_FILE_OPEN_FAIL:     return "LF_FILE_OPEN_FAIL";
    case LF_FILE_OPEN_WRITE:    return "LF_FILE_OPEN_WRITE";
    case LF_TABLE_MISSING:      return "LF_TABLE_MISSING";
    case LF_MAXP_CFF_MISMATCH:  return "LF_MAXP_CFF_MISMATCH";
    case LF_UNSUPPORTED:        return "LF_UNSUPPORTED";
    case LF_INVALID_PARAM:      return "LF_INVALID_PARAM";
    case LF_STREAM_OVERRUN:     return "LF_STREAM_OVERRUN";
    case LF_COMPRESSION:        return "LF_COMPRESSION";
    case LF_CONVERSION:         return "LF_CONVERSION";
    case LF_REFIT:              return "LF_REFIT";
    case LF_COMPONENTIZE:       return "LF_COMPONENTIZE";
    case LF_UNIMPLEMENTED:      return "LF_UNIMPLEMENTED";

    case LF_HARMONIZE_PATHS:        return "LF_HARMONIZE_PATHS";        // The output path must be different from the input path.
    case LF_HARMONIZE_NUM_GLYPHS:   return "LF_HARMONIZE_NUM_GLYPHS";   // All the input fonts must have the same number of glyphs.
    case LF_HARMONIZE_CMAP:         return "LF_HARMONIZE_CMAP";         // The fonts do not have the glyphs in the same order.
    case LF_HARMONIZE_COMPOSITES:   return "LF_HARMONIZE_COMPOSITES";   // The font do not have composites at the same indexes, or components are different
    case LF_HARMONIZE_POST_NAMES:   return "LF_HARMONIZE_POST_NAMES";   // The post table names of glyphs are nto the same in all the fonts
    case LF_HARMONIZE_POST_VERS:    return "LF_HARMONIZE_POST_VERS";    // The fonts do not all have the same post table version, or have an unsupported version
    case LF_HARMONIZE_CONTOURS:     return "LF_HARMONIZE_CONTOURS";     // The fonts do not all have the same number of contours in the glyphs
    case LF_HARMONIZE_UPM:          return "LF_HARMONIZE_UPM";          // The fonts do not all have the same unitsPerEm
    case LF_HARMONIZE_ALGORITHM:    return "LF_HARMONIZE_ALGORITHM";    // An error occurred in the harmonzer algorithm
    case LF_HARMONIZE_FONT_TYPES:   return "LF_HARMONIZE_FONT_TYPES";   // The input fonts do not all have the same type
    default:                    return "<unknown error>";
    }
}



//
// Formatted string routine
//

int UTILS_snprintf(char *str, size_t size, const char *format, ...)
{
    va_list vl;
    memset(&vl, 0, sizeof(va_list));
    va_start(vl, format);
    int count = vsnprintf(str, size, format, vl);
    va_end(vl);
    return count; //lint !e438
}



//
// Quicksort support
//

static void UTILS_swapUShort(USHORT* x, USHORT* y)
{
    USHORT temp = *x;
    *x = *y;
    *y = temp;
}

void UTILS_quicksortGlyphID(USHORT list[], LONG m, LONG n)
{
    LONG key;

    if( m < n)
    {
        LONG k = (m + n) / 2;
        LONG i = m + 1;
        LONG j = n;
        UTILS_swapUShort(&list[m], &list[k]);
        key = list[m];

        while(i <= j)
        {
            while((i <= n) && (list[i] <= key))
                i++;

            while((j >= m) && (list[j] > key))
                j--;

            if( i < j)
                UTILS_swapUShort(&list[i],&list[j]);
        }

        /* swap two elements */
        UTILS_swapUShort(&list[m],&list[j]);

        /* recursively sort the lesser list */
        UTILS_quicksortGlyphID(list,m,j-1);
        UTILS_quicksortGlyphID(list,j+1,n);
    }
}



//
// Assertion support
//

#if _DEBUG
/* ----------------------------------------------------------------------------
    @brief
        debugging assert.

        displays the filename, and line number of an assert.  You need to
        flush to write out any buffered output before you execute the
        abort().  The call to flush(NULL) is important because it ensures
        that the error message will be displayed only after all other
        buffers have been written out.

    @param
        strFile = pointer to the string containing the filename
        uline   = the line number that the assert was triggered at.

---------------------------------------------------------------------------- */
void UTILS_Assert(char* strFile, unsigned uline)
{
    fflush(NULL);
    fprintf(stderr, "\nAssertion failed: %s, line %u\n", strFile, uline);
    fflush(stderr);

    LOG_ASSERT(strFile, uline, "Assertion failed!!");

    abort();
}

void UTILS_AssertMsg(char* msg, char* strFile, unsigned uline)
{
    fflush(NULL);
    fprintf(stderr, "%s\n", msg);
    fprintf(stderr, "\nAssertion failed: %s, line %u\n", strFile, uline);
    fflush(stderr);

    LOG_ASSERT(strFile, uline, msg);

    abort();
}
#endif



//
// Logging routines
//

#ifdef LF_LOGGING
/* ----------------------------------------------------------------------------
@summary
create a log file to write out warnings, errors, and any other
types of system messages.

@param
file = pointer to the log file handle
---------------------------------------------------------------------------- */
void UTILS_openLog(const char* logfilename)
{
    /*lint -size(a,2049) */
    char logname[2048];
    /*lint +size(a,0) */

    if (hLogfile != NULL)
        fclose(hLogfile);

    UTILS_snprintf(logname, 2048, "%s.log", logfilename);

    hLogfile = fopen(logname, "w");

    DEBUG_LOG("Starting LOG file");
}

void UTILS_closeLog()
{
    if (hLogfile != NULL)
        fclose(hLogfile);
}

void UTILS_LogMsg(char* msg, char* file, unsigned uline)
{
    if (nVerbose >= LIBFONT_VERBOSE_INFO)
    {
        printf("[INFO] %s : %d - %s\n", file, (int)uline, msg );
        if (hLogfile)
        {
            fprintf(hLogfile, "[INFO] %s : %d - %s\n", file, (int)uline, msg);
        }
    }
}

void UTILS_LogMsgValue(char* msg, char* file, unsigned uline, int param)
{
    if (nVerbose >= LIBFONT_VERBOSE_INFO)
    {
        printf("[INFO] %s : %d - %s (%d)\n", file, (int)uline, msg, param );

        if (hLogfile)
        {
            fprintf(hLogfile, "[INFO] %s : %d - %s (%d)\n", file, (int)uline, msg, param );
        }
    }
}

void UTILS_LogError(char* error, char* file, unsigned uline)
{
    if (nVerbose >= LIBFONT_VERBOSE_ERRORS)
    {
        printf("[ERROR] %s : %d - %s\n", file, (int)uline, error);

        if (hLogfile)
        {
            fprintf(hLogfile, "[ERROR] %s : %d - %s\n", file, (int)uline, error);
        }
    }
}

void UTILS_LogWarning(char* warning, char* file, unsigned uline)
{
    if (nVerbose >= LIBFONT_VERBOSE_WARNINGS)
    {
        printf("[WARNING] %s : %d - %s\n", file, (int)uline, warning);

        if (hLogfile)
        {
            fprintf(hLogfile, "[WARNING] %s : %d - %s\n", file, (int)uline, warning);
        }
    }
}

void UTILS_LogErrorStatus(char* error, char* file, unsigned uline, LF_ERROR status)
{
    if (nVerbose >= LIBFONT_VERBOSE_ERRORS)
    {
        printf("[ERROR] %s : %d - [%s] %s \n", file, (int)uline, UTILS_getErrorMessage(status), error);

        if (hLogfile)
        {
            fprintf(hLogfile, "[ERROR] %s : %d - [%s] %s\n", file, (int)uline, UTILS_getErrorMessage(status), error);
        }
    }
}
#endif



//
// OpenType dumping routines
//

#ifdef LF_OT_DUMP
void UTILS_openXML(const char* xmlfilename)
{
    char xmlname[2048];

    UTILS_snprintf(xmlname, 2048, "%s.xml", xmlfilename);

    if (hXMLfile != NULL)
        fclose(hXMLfile);

    hXMLfile = fopen(xmlname, "w");
}

void UTILS_closeXML()
{
    if (hXMLfile != NULL)
        fclose(hXMLfile);
}

void UTILS_xmlData(char* msg)
{
    if (hXMLfile)
    {
        fprintf(hXMLfile, "%s", msg);
    }
}

void UTILS_xmlNode(char* node, char* msg)
{
    int n;

    if (hXMLfile)
    {
        for (n = 0; n < nXmlIndex; n++)
            fprintf(hXMLfile, "    ");

        fprintf(hXMLfile, "<%s>%s</%s>\n", node, msg, node );
    }
}

void UTILS_xmlDataNode(char* node, int data)
{
    int n;
    if (hXMLfile)
    {
        for (n = 0; n < nXmlIndex; n++)
            fprintf(hXMLfile, "    ");

        fprintf(hXMLfile, "<%s>%d</%s>\n", node, data, node );
    }
}

void UTILS_xmlOpenNode(char* node)
{
    int n;
    if (hXMLfile)
    {
        for (n = 0; n < nXmlIndex; n++)
            fprintf(hXMLfile, "    ");

        fprintf(hXMLfile, "<%s>\n", node );
    }
    nXmlIndex++;
}

void UTILS_xmlCloseNode(char* node)
{
    int n;
    nXmlIndex--;

    if (hXMLfile)
    {
        for (n = 0; n < nXmlIndex; n++)
            fprintf(hXMLfile, "    ");

        fprintf(hXMLfile, "</%s>\n", node );
    }
}

void UTILS_xmlStartCommentIndex(char* node, int index, int total)
{
    int n;
    if (hXMLfile)
    {
        for (n = 0; n < nXmlIndex; n++)
            fprintf(hXMLfile, "    ");

        fprintf(hXMLfile, "<%s>    <!-- %s[%d / %d] -->\n", node, node, index, total );
    }
    nXmlIndex++;
}

void UTILS_xmlEndCommentIndex(char* node, int index, int total)
{
    int n;
    nXmlIndex--;

    if (hXMLfile)
    {
        for (n = 0; n < nXmlIndex; n++)
            fprintf(hXMLfile, "    ");
        fprintf(hXMLfile, "</%s>    <!-- %s[%d / %d] -->\n", node, node, index, total );
    }
}

void UTILS_xmlStartCommentMsgIndex(char* node, char* msg, int index, int total)
{
    int n;
    if (hXMLfile)
    {
        for (n = 0; n < nXmlIndex; n++)
            fprintf(hXMLfile, "    ");

        fprintf(hXMLfile, "<%s>    <!-- %s[%d / %d] -->\n", node, msg, index, total);
    }
    nXmlIndex++;
}

void UTILS_xmlComment(char* comment, int param)
{
    if (nVerbose >= LIBFONT_VERBOSE_INFO)
    {
        int n;

        if (hXMLfile)
        {
            for (n = 0; n < nXmlIndex; n++)
                fprintf(hXMLfile, "    ");
            fprintf(hXMLfile, "<!-- %s[%d] -->\n", comment, param );
        }
    }
}

void UTILS_xmlCommentIndex(char* comment, int index, int total)
{
    if (nVerbose >= LIBFONT_VERBOSE_INFO)
    {
        int n;

        if (hXMLfile)
        {
            for (n = 0; n < nXmlIndex; n++)
                fprintf(hXMLfile, "    ");
            fprintf(hXMLfile, "<!-- %s[%d / %d] -->\n", comment, index, total);
        }
    }
}
#endif
