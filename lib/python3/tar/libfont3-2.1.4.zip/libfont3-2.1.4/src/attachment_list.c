// Copyright (C) 2014 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// attachment_list.c

#include <stdlib.h>
#include "attachment_list.h"
#include "coverage_table.h"
#include "lf_vector.h"
#include "utils.h"

static LF_VECTOR* AttachmentList_readPointTable(LF_STREAM* stream)
{
    USHORT pointCount = STREAM_readUShort(stream);
    USHORT i;
    LF_VECTOR* pointTable = vector_create(pointCount, 4);

    for(i = 0; i < pointCount; i++)
    {
        vector_push_back(pointTable, (void*)(intptr_t)STREAM_readUShort(stream));
    }

    return pointTable;
}

LF_ERROR AttachmentList_readTable(attachment_list* list, LF_STREAM* stream)
{
    USHORT      glyphCount;
    USHORT      i;
    size_t      tableStart = STREAM_streamPos(stream);
    LF_ERROR    status;

    OFFSET coverageOffset = STREAM_readOffset(stream);
    size_t current = STREAM_streamPos(stream);
    STREAM_streamSeek(stream, tableStart + coverageOffset);
    status = Coverage_readTable(&list->Coverage, stream);
    if (status != LF_ERROR_OK)
    {
        if (status == LF_EMPTY_TABLE)
        {
            DEBUG_LOG_ERROR("Attachment List coverage table is empty");
        }
        else
        {
            DEBUG_LOG_ERROR("coverage table format is corrupt");
        }

        return status;
    }

    STREAM_streamSeek(stream, current);

    glyphCount = STREAM_readUShort(stream);

    if (glyphCount != Coverage_getCoverageCount(&list->Coverage))
    {
        DEBUG_LOG_ERROR("coverage count != AttachPoints glyphCount");
        Coverage_deleteTable(&list->Coverage);
        memset(list, 0, sizeof(attachment_list));
        return LF_INVALID_INDEX;
    }

    vector_init(&list->AttachPoints, glyphCount, 4);

    for(i = 0; i < glyphCount; i++)
    {
        OFFSET attachOffset = STREAM_readOffset(stream);
        current = STREAM_streamPos(stream);
        STREAM_streamSeek(stream, tableStart + attachOffset);
        vector_push_back(&list->AttachPoints, AttachmentList_readPointTable(stream));
        STREAM_streamSeek(stream, current);
    }

    return LF_ERROR_OK;
}

LF_ERROR AttachmentList_getTableSize(attachment_list* list, size_t* tableSize)
{
    size_t subSize = 0;
    ULONG i;

    *tableSize = sizeof(OFFSET) + sizeof(USHORT) + sizeof(OFFSET) * list->AttachPoints.count;

    Coverage_getTableSize(&list->Coverage, &subSize);
    *tableSize += subSize;

    for(i = 0; i < list->AttachPoints.count; i++)
    {
        LF_VECTOR* pointTable = (LF_VECTOR*)vector_at(&list->AttachPoints, i);
        *tableSize += sizeof(USHORT) * (pointTable->count + 1);
    }

    return LF_ERROR_OK;
}

LF_ERROR AttachmentList_buildTable(attachment_list* list, LF_STREAM* stream)
{
    size_t tableStart = STREAM_streamPos(stream);
    size_t current;
    size_t endSeek;
    ULONG i;

    OFFSET tableOffset = (OFFSET)(sizeof(OFFSET) + sizeof(USHORT) + sizeof(OFFSET) * (OFFSET)list->AttachPoints.count);

    //write coverage table
    STREAM_writeOffset(stream, tableOffset);
    current = STREAM_streamPos(stream);
    STREAM_streamSeek(stream, (OFFSET)tableStart + tableOffset);
    Coverage_buildTable(&list->Coverage, stream);
    tableOffset = (OFFSET)(STREAM_streamPos(stream) - tableStart);
    STREAM_streamSeek(stream, current);

    STREAM_writeUShort(stream, (USHORT)list->AttachPoints.count);
    endSeek = STREAM_streamPos(stream);

    for(i = 0; i < list->AttachPoints.count; i++)
    {
        LF_VECTOR* pointTable = (LF_VECTOR*)vector_at(&list->AttachPoints, i);
        ULONG j;

        STREAM_writeOffset(stream, (OFFSET)tableOffset);
        current = STREAM_streamPos(stream);
        STREAM_streamSeek(stream, (OFFSET)tableStart + tableOffset);

        STREAM_writeUShort(stream, (USHORT)pointTable->count);

        for(j = 0; j < pointTable->count; j++)
        {
            STREAM_writeUShort(stream, (USHORT)(intptr_t)vector_at(pointTable, j));
        }

        tableOffset = (OFFSET)(STREAM_streamPos(stream) - tableStart);
        endSeek = STREAM_streamPos(stream);
        STREAM_streamSeek(stream, current);
    }

    STREAM_streamSeek(stream, endSeek);

    return LF_ERROR_OK;
}

LF_ERROR AttachmentList_freeTable(attachment_list* list)
{
    ULONG i;

    for (i = 0; i < list->AttachPoints.count; i++)
    {
        LF_VECTOR* pointTable = (LF_VECTOR*)vector_at(&list->AttachPoints, i);
        vector_free(pointTable);
        free(pointTable);
    }

    Coverage_deleteTable(&list->Coverage);
    vector_delete(&list->AttachPoints);

    return LF_ERROR_OK;
}
