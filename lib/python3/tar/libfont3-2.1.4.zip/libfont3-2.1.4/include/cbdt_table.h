// Copyright (C) 2016 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// cbdt_table.h

#include <stdio.h>
#include "data_types.h"
#include "offset_table_sfnt.h"
#include "lf_core.h"
#include "ebitmap_types.h"
#include "keep_table.h"

#ifndef __CBDT_TABLE_H__
#define __CBDT_TABLE_H__

#ifdef __cplusplus
extern "C" {
#endif

typedef embedded_data_table cbdt_table;

LF_ERROR CBDT_readTable(LF_FONT* lfFont, const sfnt_table_record* record, LF_STREAM* stream);
LF_ERROR CBDT_keepGlyphs(const LF_FONT* lfFont, GlyphList* keepList);
LF_ERROR CBDT_removeGlyph(LF_FONT* lfFont, ULONG index);
LF_ERROR CBDT_isTableEmpty(LF_FONT* lfFont);
LF_ERROR CBDT_remapTable(LF_FONT* lfFont, LF_MAP *remap);
LF_ERROR CBDT_getCount(LF_FONT* lfFont, USHORT* numGlyphs);
LF_ERROR CBDT_getTableSize(LF_FONT* lfFont, size_t* tableSize);
LF_ERROR CBDT_writeTable(LF_FONT* lfFont, sfnt_table_record* record, LF_STREAM* stream);
LF_ERROR CBDT_freeTable(LF_FONT* lfFont);

#ifdef __cplusplus
}
#endif

#endif //__CBDT_TABLE_H__
