// Copyright (C) 2014 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// lf_vector.h

#ifndef __LF_VECTOR_H__
#define __LF_VECTOR_H__

#include <stdio.h>
#include "data_types.h"
#include "lf_error.h"

#ifdef __cplusplus
extern "C" {
#endif

typedef struct _lf_vector
{
    void**   vector_array;
    size_t   count;
    size_t   max_size;
    size_t   grow_size;
} LF_VECTOR;

typedef void** VECTOR_ITER;

LF_VECTOR*  vector_create(size_t size, size_t grow);
LF_ERROR    vector_init(LF_VECTOR* vector, size_t size, size_t grow);
void        vector_free(LF_VECTOR* vector);
boolean     vector_empty(LF_VECTOR* vector);
void        vector_clear(LF_VECTOR* vector);
void*       vector_at(const LF_VECTOR* vector, size_t index);
LF_ERROR    vector_resize(LF_VECTOR* vector, size_t size);
LF_ERROR    vector_push_back(LF_VECTOR* vector, void* data);
void*       vector_pop_back(LF_VECTOR* vector);
LF_ERROR    vector_erase(LF_VECTOR* vector, size_t index);
LF_ERROR    vector_set_data(LF_VECTOR* vector, size_t index, void* data);
LF_ERROR    vector_insert(LF_VECTOR* vector, size_t index, void* data);
void        vector_delete(LF_VECTOR* vector);
size_t      vector_size(const LF_VECTOR* vector);

#if 0 // The below functions are not used.
void        vector_append(LF_VECTOR* vector, LF_VECTOR* vector2);
void**      vector_data(LF_VECTOR* vector);
VECTOR_ITER vector_begin(LF_VECTOR* vector);
VECTOR_ITER vector_end(LF_VECTOR* vector);
#endif

#ifdef __cplusplus
}
#endif

#endif //__LF_VECTOR_H__
