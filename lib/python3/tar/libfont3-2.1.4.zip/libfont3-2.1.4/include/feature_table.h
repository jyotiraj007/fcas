// Copyright (C) 2014 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// feature_table.h

#ifndef __FEATURE_TABLE_H__
#define __FEATURE_TABLE_H__

#include "data_types.h"
#include "stream.h"
#include "lf_vector.h"
#include "base_table.h"

#ifdef __cplusplus
extern "C" {
#endif

typedef struct _optical_size
{
    USHORT designSize;              // design size in 720/inch units (decipoints). The design size entry must be non-zero. When there is a design size but no recommended size range, the rest of the array will consist of zeros.
    USHORT subfamilyID;             // value has no independent meaning, but serves as an identifier that associates fonts in a subfamily. If this value is zero, the remaining fields in the array will be ignored.
    USHORT subfamilyNameID;         // value enables applications to use a single name for the subfamily identified by the second value. If the preceding value is non-zero, this value must be set in the range 256 - 32767 (inclusive). It records the value of a field in the name table, which must contain English-language strings encoded in Windows Unicode and Macintosh Roman, and may contain additional strings localized to other scripts and languages.
    USHORT minSize;                 // small end of the recommended usage range (exclusive) stored in 720/inch units (decipoints).
    USHORT maxSize;                 // large end of the recommended usage range (inclusive), stored in 720/inch units (decipoints).
} optical_size_params;

typedef struct _feature_list
{
    boolean hasGPOSSizeFeature;     // TRUE if the feature list contains one or more GPOS optical size features.
    optical_size_params optSize;    // The optical size params for all the GPOS size features.
    LF_VECTOR features;             // a list of (pointers to) feature_table objects
} feature_list;

typedef struct _feature_table
{
    base_table    Base;
    TAG           FeatureTag;         //4-byte feature identification tag
    OFFSET        FeatureParams;      //= NULL (reserved for offset to FeatureParams)
    USHORT        LookupCount;        //Number of LookupList indices for this feature
    LF_VECTOR     LookupListIndex;    //Array of LookupList indices for this feature -zero-based (first lookup is LookupListIndex = 0)
} feature_table;


#define FEATURE_RECORD_SIZE        (sizeof(TAG) + sizeof(OFFSET))

size_t          Feature_getDataSize(TABLE_HANDLE hTable);
LF_ERROR        Feature_readListTable(LF_STREAM* stream, boolean isGPOS, TABLE_HANDLE* featureTable);
BYTE*           Feature_buildTable(TABLE_HANDLE hTable, boolean isGPOS, size_t* tableSize);
void            Feature_deleteTable(TABLE_HANDLE featureList);
LF_ERROR        Feature_removeLookupIndex(TABLE_HANDLE hTable, TABLE_HANDLE hScript, USHORT lookupIndex, SHORT deltaIndex);
LF_ERROR        Feature_pruneTable(TABLE_HANDLE hTable);
void            Feature_cleanupLookups(TABLE_HANDLE hTable, TABLE_HANDLE hLookups, boolean isGPOS);
LF_ERROR        Feature_collectGlyphs(GlyphList* keepList, TABLE_HANDLE hTable, USHORT featureIndex);


#ifdef __cplusplus
}
#endif

#endif //__FEATURE_TABLE_H__
