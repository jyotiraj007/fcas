// Copyright (C) 2016 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// fmtx_table.h

#include <stdio.h>
#include "data_types.h"
#include "offset_table_sfnt.h"
#include "lf_core.h"

#ifndef __FMTX_TABLE_H__
#define __FMTX_TABLE_H__

#ifdef __cplusplus
extern "C" {
#endif


typedef struct _fmtx_table_
{
    FIXED version;              // Version(set to 0x00020000).
    ULONG glyphIndex;           // The glyph whose points represent the metrics.
    BYTE horizontalBefore;      // Point number for the horizontal ascent.
    BYTE horizontalAfter;       // Point number for the horizontal descent.
    BYTE horizontalCaretHead;   // Point number for the horizontal caret head.
    BYTE horizontalCaretBase;   // Point number for the horizontal caret base.
    BYTE verticalBefore;        // Point number for the vertical ascent.
    BYTE verticalAfter;         // Point number for the vertical descent.
    BYTE verticalCaretHead;     // Point number for the vertical caret head.
    BYTE verticalCaretBase;     // Point number for the vertical caret base.

} fmtx_table;

#define FMTX_TABLE_SIZE (sizeof(FIXED) + sizeof(ULONG) + (8 * sizeof(BYTE)))


LF_ERROR FMTX_readTable(LF_FONT* lfFont, const sfnt_table_record* record, LF_STREAM* stream);
LF_ERROR FMTX_getMetricsGlyph(LF_FONT* lfFont, GlyphID* gid);
LF_ERROR FMTX_getTableSize(LF_FONT* lfFont, size_t* tableSize);
LF_ERROR FMTX_remapTable(LF_FONT* lfFont, LF_MAP *glyphIndexMap);
LF_ERROR FMTX_writeTable(LF_FONT* lfFont, sfnt_table_record* record, LF_STREAM* stream);
LF_ERROR FMTX_freeTable(LF_FONT* lfFont);

#ifdef __cplusplus
}
#endif

#endif //__FMTX_TABLE_H__
