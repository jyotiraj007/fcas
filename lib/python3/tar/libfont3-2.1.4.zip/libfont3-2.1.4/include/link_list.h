// Copyright (C) 2014 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// link_list.h

#ifndef __LINK_LIST_H__
#define __LINK_LIST_H__

#include <stdio.h>
#include <stdlib.h>

#ifdef __cplusplus
extern "C" {
#endif

typedef struct _link_node {
    void* data;
    struct _link_node* prev;
    struct _link_node* next;
} link_node;

typedef struct _link_list 
{
    struct _link_node* head;
    struct _link_node* last;
    unsigned long count;
} link_list;

void        list_init(link_list* list);
link_node*  list_at(const link_list* list, int index);
link_node*  list_insert(link_list* list, void* data, link_node* after);
link_node*  list_append(link_list* list, void* data);
void        list_delete(link_list* list, link_node* node);

#ifdef __cplusplus
}
#endif

#endif //__LINK_LIST_H__
