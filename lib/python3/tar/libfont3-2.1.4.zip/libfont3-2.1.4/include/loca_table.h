// Copyright (C) 2014, 2015 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// loca_table.h


#ifndef __LOCA_TABLE_H__
#define __LOCA_TABLE_H__

#include <stdio.h>
#include "data_types.h"
#include "lf_core.h"
#include "stream.h"
#include "offset_table_sfnt.h"

#ifdef __cplusplus
extern "C" {
#endif

#define LOCA_MARK_REMOVED 0xFFFFFFFF

typedef struct _loca_table
{
    LF_VECTOR   locaData;
    size_t      numRemoved;
} loca_table;

void        LOCA_printTable(USHORT numGlyphs);
LF_ERROR    LOCA_readTable(LF_FONT* lfFont, const sfnt_table_record* record, LF_STREAM* stream);
LF_ERROR    LOCA_getTableSize(LF_FONT* lfFont, size_t* tableSize);
LF_ERROR    LOCA_writeTable(LF_FONT* lfFont, sfnt_table_record* record, LF_STREAM* stream);
void        LOCA_setOffset(LF_FONT* lfFont, USHORT index, ULONG offset);
void        LOCA_removeGlyph(const LF_FONT* lfFont, ULONG index);
LF_ERROR    LOCA_shrinkFormat(LF_FONT* lfFont);
LF_ERROR    LOCA_freeTable(const LF_FONT* lfFont);
LF_ERROR    LOCA_createTable(LF_FONT* lfFont, ULONG numGlyphs);


typedef struct
{
    loca_table* table;
    USHORT curIndex;
    SHORT format;
    ULONG nextOffset;
} locaIterator;

locaIterator* LOCA_iteratorCreate(LF_FONT* lfFont);
LF_ERROR LOCA_iteratorNext(locaIterator* iter, ULONG* offset, ULONG* size);
void LOCA_iteratorDelete(locaIterator* iter);

#ifdef __cplusplus
}
#endif

#endif // __LOCA_TABLE_H__
