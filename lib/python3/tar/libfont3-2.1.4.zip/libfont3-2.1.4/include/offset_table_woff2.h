// Copyright (C) 2014 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// offset_table_woff2.h

#ifndef __OFFSET_WOFF2_H__
#define __OFFSET_WOFF2_H__

#include <stdio.h>
#include "data_types.h"
#include "lf_vector.h"
#include "stream.h"
#include "lf_core.h"

#ifdef __cplusplus
extern "C" {
#endif

typedef struct _woff2_header
{
    ULONG   signature;              // 0x774F4632 'wOF2'
    ULONG   flavor;                 // sfnt version of the input font.
    ULONG   length;                 // Total size of the WOFF file.
    USHORT  numTables;              // Number of tables.
    USHORT  reserved;               // Reserverd, set to zero.
    ULONG   totalSfntSize;          // Total size needed for the uncompressed fontdata, including sfnt header, directory, and tables (including padding)
    ULONG   totalCompressedSize;    // Total length of the compressed data block.
    USHORT  majorVersion;           // Major version of the WOFF file.
    USHORT  minorVersion;           // Minor version of the WOFF file.
    ULONG   metaOffset;             // Offset to metadata block, from beginning of WOFF file.
    ULONG   metaLength;             // Length of compressed metadata block.
    ULONG   metaOrigLength;         // Uncompressed size of metadata block.
    ULONG   privOffset;             // Offset to private data block, from beginning of WOFF file.
    ULONG   privLength;             // Length of private data block.
} LF_WOFF2_HEADER;

typedef struct _woff2_offset_table
{
    LF_WOFF2_HEADER woffHeader;

    //INTERNAL
    size_t     compressedFontDataOffset;
    LF_VECTOR record_list;
} woff2_offset_table;


typedef ULONG UIntBase128;

typedef struct _woff2_table_record
{
    BYTE        flags;              // table type and flags
    ULONG       tag;                // 4-byte tag (optional)
    UIntBase128 origLength;         // length of original table
    UIntBase128 transformLength;    // transformed length (optional)

    //INTRENAL
    ULONG       offset;
} woff2_table_record;


/*
Known Table Tags
Flag    Tag     Flag    Tag     Flag    Tag     Flag    Tag
0       cmap    16      EBLC    32      CBDT    48      gvar
1       head    17      gasp    33      CBLC    49      hsty
2       hhea    18      hdmx    34      COLR    50      just
3       hmtx    19      kern    35      CPAL    51      lcar
4       maxp    20      LTSH    36      SVG     52      mort
5       name    21      PCLT    37      sbix    53      morx
6       OS/2    22      VDMX    38      acnt    54      opbd
7       post    23      vhea    39      avar    55      prop
8       cvt     24      vmtx    40      bdat    56      trak
9       fpgm    25      BASE    01      bloc    57      Zapf
10      glyf    26      GDEF    42      bsln    58      Silf
11      loca    27      GPOS    43      cvar    59      Glat
12      prep    28      GSUB    44      fdsc    60      Gloc
13      CFF     29      EBSC    45      feat    61      Feat
14      VORG    30      JSTF    46      fmtx    62      Sill
15      EBDT    31      MATH    47      fvar    63      arbitrary tag follows
*/

typedef enum _woff2_table_flag_
{
    etf_cmap = 0,   etf_head,   etf_hhea,    etf_hmtx,      etf_maxp,
    etf_name,       etf_OS2,    etf_post,    etf_cvt,       etf_fpgm,
    etf_glyf,       etf_loca,   etf_prep,    etf_CFF,       etf_VORG,
    etf_EBDT,       etf_EBLC,   etf_gasp,    etf_hdmx,      etf_kern,
    etf_LTSH,       etf_PCLT,   etf_VDMX,    etf_vhea,      etf_vmtx,
    etf_BASE,       etf_GDEF,   etf_GPOS,    etf_GSUB,      etf_EBSC,
    etf_JSTF,       etf_MATH,   etf_CBDT,    etf_CBLC,      etf_COLR,
    etf_CPAL,       etf_SVG,    etf_sbix,    etf_acnt,      etf_avar,
    etf_bdat,       etf_bloc,   etf_bsln,    etf_cvar,      etf_fdsc,
    etf_feat,       etf_fmtx,   etf_fvar,    etf_gvar,      etf_hsty,
    etf_just,       etf_lcar,   etf_mort,    etf_morx,      etf_opbd,
    etf_prop,       etf_trak,   etf_Zapf,    etf_Silf,      etf_Glat,
    etf_Gloc,       etf_Feat,   etf_Sill,    etf_arbitrary
} woff2_table_flag;

woff2_offset_table* offset_woff2_readTable(LF_STREAM* stream, int keepFlags);
size_t              offset_woff2_writeTable(woff2_offset_table* table, LF_STREAM* stream);
LF_ERROR            offset_woff2_freeTable(woff2_offset_table* table);
woff2_table_flag    offset_woff2_getTableFlag(ULONG tag);

#ifdef __cplusplus
}
#endif

#endif //__OFFSET_WOFF2_H__
