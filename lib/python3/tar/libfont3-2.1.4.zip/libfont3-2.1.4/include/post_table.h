// Copyright (C) 2014 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// post_table.h

#include "lf_core.h"
#include "offset_table_sfnt.h"
#include "table_tags.h"

#ifndef __POST_TABLE_H__
#define __POST_TABLE_H__

#ifdef __cplusplus
extern "C" {
#endif


typedef struct _post_table
{
    FIXED    Version;    //0x00010000 for version 1.0 
                         //0x00020000 for version 2.0 
                         //0x00025000 for version 2.5 (deprecated)
                         //0x00030000 for version 3.0
    FIXED    italicAngle;           //Italic angle in counter-clockwise degrees from the vertical. Zero for upright text, negative for text that leans to the right (forward).
    FWORD    underlinePosition;     //This is the suggested distance of the top of the underline from the baseline (negative values indicate below baseline). 
                                    //The PostScript definition of this FontInfo dictionary key (the y coordinate of the center of the stroke) is not used for historical reasons. The value of the PostScript key may be calculated by subtracting half the underlineThickness from the value of this field.
    FWORD    underlineThickness;    //Suggested values for the underline thickness.
    ULONG    isFixedPitch;          //Set to 0 if the font is proportionally spaced, non-zero if the font is not proportionally spaced (i.e. monospaced).
    ULONG    minMemType42;          //Minimum memory usage when an OpenType font is downloaded.
    ULONG    maxMemType42;          //Maximum memory usage when an OpenType font is downloaded.
    ULONG    minMemType1;           //Minimum memory usage when an OpenType font is downloaded as a Type 1 font.
    ULONG    maxMemType1;           //Maximum memory usage when an OpenType font is downloaded as a Type 1 font.

    //Version 2.0 data
    LF_VECTOR   glyphNameIndex;
    LF_VECTOR   names;

    //INTERNAL
    boolean     namesParsed;
    boolean     subsetted;
    BYTE        *data;
    ULONG       length;
    LF_VECTOR   removedGIDs;
    size_t      calculatedTableSize;        // size in bytes of table if written, 0 if table is dirty
    ULONG       calculatedSizeVersion;      // version of table above calculated for
    size_t      calculatedNumGlyphs;
} post_table;

LF_API LF_ERROR POST_readTable(LF_FONT* lfFont, const sfnt_table_record* record, LF_STREAM* stream);
LF_API LF_ERROR POST_getTableSize(const LF_FONT* lfFont, ULONG version, size_t* tableSize);
LF_API LF_ERROR POST_writeTable(const LF_FONT* lfFont, ULONG version, sfnt_table_record* record, LF_STREAM* stream);
LF_API LF_ERROR POST_freeTable(const LF_FONT* lfFont);
LF_API LF_ERROR POST_removeGlyph(const LF_FONT* lfFont, GlyphID index);
LF_API CHAR*    POST_getGlyfNameFromIndex(const LF_FONT* lfFont, GlyphID index);
LF_API ULONG    POST_getVersion(const LF_FONT* lfFont);

#ifdef __cplusplus
}
#endif

#endif //__POST_TABLE_H__
