// Copyright (C) 2016 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// ebdt_table.h

#include <stdio.h>
#include "data_types.h"
#include "offset_table_sfnt.h"
#include "lf_core.h"
#include "ebitmap_types.h"
#include "keep_table.h"

#ifndef __EBDT_TABLE_H__
#define __EBDT_TABLE_H__

#ifdef __cplusplus
extern "C" {
#endif

typedef embedded_data_table ebdt_table;

LF_ERROR EBDT_readTable(LF_FONT* lfFont, const sfnt_table_record* record, LF_STREAM* stream);
LF_ERROR EBDT_keepGlyphs(const LF_FONT* lfFont, GlyphList* keepList);
LF_ERROR EBDT_removeGlyph(LF_FONT* lfFont, ULONG index);
LF_ERROR EBDT_isTableEmpty(LF_FONT* lfFont);
LF_ERROR EBDT_remapTable(LF_FONT* lfFont, LF_MAP *remap);
LF_ERROR EBDT_getCount(LF_FONT* lfFont, USHORT* numGlyphs);
LF_ERROR EBDT_getTableSize(LF_FONT* lfFont, size_t* tableSize);
LF_ERROR EBDT_writeTable(LF_FONT* lfFont, sfnt_table_record* record, LF_STREAM* stream);
LF_ERROR EBDT_freeTable(LF_FONT* lfFont);

// private, used by CBDT code
LF_ERROR EBDT_parseTable(embedded_data_table* table, embedded_loc_table* locTable, const sfnt_table_record* record, LF_STREAM* stream);
LF_ERROR EBDT_internalRemoveGlyph(embedded_data_table* table, ULONG index);
LF_ERROR EBDT_internalIsTableEmpty(embedded_data_table* table);
LF_ERROR EBDT_internalRemap(LF_FONT* lfFont, embedded_data_table* table, LF_MAP *remap);
LF_ERROR EBDT_internalCount(embedded_data_table* table, USHORT* numGlyphs);
LF_ERROR EBDT_internalGetSize(embedded_data_table* table, size_t* tableSize);
LF_ERROR EBDT_buildTable(embedded_data_table* table, ULONG version, BYTE** tableData, size_t* tableSize);
void     EBDT_freeGlyph(bitmap_glyph* glyph);
LF_ERROR EBDT_internalFree(embedded_data_table* table);

#ifdef __cplusplus
}
#endif

#endif //__EBDT_TABLE_H__
