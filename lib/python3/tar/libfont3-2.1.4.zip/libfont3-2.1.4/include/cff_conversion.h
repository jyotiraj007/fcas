// Copyright (C) 2014, 2017 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// cff_conversion.h

#ifndef __CFF_CONVERSION_H__
#define __CFF_CONVERSION_H__

#include "lf_core.h"
#include "cff_core.h"
#include "cff_table.h"
#include "glyf_table.h"
#include "loca_table.h"
#include "Conversion.h"

#ifdef __cplusplus
extern "C" {
#endif


// structure to hold the flags and (compressed) point data for each glyph
// when creating a glyf table. This is used instead of allocating / freeing
// the arrays for each glyph.
typedef struct _glyfBuildScratchSpace_
{
    size_t allocated;
    BYTE* flags;
    BYTE* xCoords;
    BYTE* yCoords;

} glyfBuildScratchSpace;



LF_ERROR conversion_populateGLYFTable(LF_FONT *lfFont, float tolerance, USHORT outputUnitsPerEm);
LF_ERROR conversion_populatePOSTTable(const LF_FONT *lfFont);
LF_ERROR conversion_populateCFFTable(LF_FONT *lfFont, float tolerance, USHORT outputUnitsPerEm);

LF_ERROR conversion_allocateGlyphOutline(int numPoints, int numContours, Simple_Outline* outl);
void     conversion_freeGlyphOutline(Glyph *glyph);

int      conversion_allocateScratchSpace(glyfBuildScratchSpace* ss, size_t size);
void     conversion_freeScratchSpace(const glyfBuildScratchSpace* ss);
int      conversion_reallocateScratchSpace(glyfBuildScratchSpace* ss, size_t size);

void     conversion_setGlyphOutlineParams(Glyph_Outline* quadGlyphOutline, size_t index);
LF_ERROR conversion_addPointsToGlyphOutline(LF_VECTOR* pointsData, Glyph_Outline* quadGlyphOutline);
LF_ERROR conversion_addPointsToGlyphOutlineV2(LF_VECTOR* pointsData, Glyph_Outline* quadGlyphOutline);
void     conversion_removeSinglePointContours(Glyph_Outline* glyphOutline);
void     conversion_computeQuadBoundingBox(Glyph * quadGlyph);
void     conversion_computeCubicBoundingBox(Glyph* cubicGlyph);

LF_ERROR conversion_convertGlyphToCompressedGlyf(Glyph *glyph, const glyfBuildScratchSpace* ss, glyf *glyf_object);
LF_ERROR conversion_getCFFGlyph(const cff_table* cffTable, USHORT index, Glyph* cubicGlyph);
LF_ERROR conversion_convertCharstringsToGlyphs(const cff_table* cffTable, LF_MAP* glyphMap, Glyph* glyphDataBlock);

LF_ERROR conversion_createCharstring(LF_FONT *lfFont, USHORT index, Glyph *glyph, cffAnalyzedCharstring** cs);

#ifdef __cplusplus
}
#endif

#endif //__CFF_CONVERSION_H__
