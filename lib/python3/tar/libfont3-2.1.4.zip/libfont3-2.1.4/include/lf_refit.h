// Copyright (C) 2015 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
//
/// \file lf_refit.h

#ifndef __LF_REFIT_H__
#define __LF_REFIT_H__

#include "lf_core.h"

#ifdef __cplusplus
extern "C" {
#endif

typedef LF_ERROR (*refitProgCB)(void* userState, USHORT progress);

typedef struct
{
    void* userState;
    refitProgCB progressCB;
} refitCBInfo;

LF_API LF_ERROR LF_refitFont(LF_FONT* lfFont, float fitTolerance, boolean replaceAll, refitCBInfo* progresInfo);

#ifdef __cplusplus
}
#endif


#endif // __LF_REFIT_H__
