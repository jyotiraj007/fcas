// Copyright (C) 2016 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
//
/// \file lf_harmonize.h

#ifndef __LF_HARMONIZE_H__
#define __LF_HARMONIZE_H__

#include "lf_core.h"

#ifdef __cplusplus
extern "C" {
#endif

//! Typedef for a progress callback function
typedef LF_ERROR(*harmonizeProgCB)(void* userState, USHORT progress);

//! Typedef for harmonizer progress callback
typedef struct
{
    void* userState;                    // User object passed to callback function
    harmonizeProgCB progressCB;         // Progress callback functions
} harmonizeProgressInfo;

//! Typedef for harmonizer options
typedef struct
{
    boolean outputCFF;                  // Output cff fonts instead of ttf fonts
    boolean forceReplacement;           // if TRUE, when glyphs have different numbers of contours across the fonts,
                                        // put the glyph from the first font into the output fonts.
    boolean suppressContourCheck;       // skip checking of contour order
    boolean suppressExtremaAddition;    // do not add missing extrema points to contours
    boolean suppressStartPointCheck;    // do not adjust starting points of contours

    FILE* logFile;                      // user log file (can be NULL)
    harmonizeProgressInfo* prog;        // progress data (can be NULL)
    boolean verbose;                    // for debugging algorithm - true for output printed to screen
} harmonizeOptions;




// Public API for the harmonizer process.
LF_API LF_ERROR LF_harmonizeFonts(const LF_VECTOR* inputFonts, const char* outputPath, harmonizeOptions* harmonizerOptions);


#ifdef __cplusplus
}
#endif

#endif // __LF_HARMONIZE_H__
