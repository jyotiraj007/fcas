// Copyright (C) 2014 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// common_table.h


/* ===================================================================================
    common glyph list structures that are used to manage files as they
    are parsed in.

=================================================================================== */
#ifndef __COMMON_TABLE_H__
#define __COMMON_TABLE_H__

#include "data_types.h"
#include "lf_error.h"
#include "lf_vector.h"
#include "stream.h"
#include "classdef.h"
#include "keep_table.h"

/* ----------------------------------------------------------------------------
    All three formats of ContextSubst subtables specify substitution data in 
    a SubstLookupRecord. A description of that record follows.

    The SequenceIndex in a SubstLookupRecord must take into consideration the
    order in which lookups are applied to the entire glyph sequence.  Because
    multiple substitutions may occur per context, the SequenceIndex and
    LookupListIndex refer to the glyph sequence after the text-processing 
    client has applied any previous lookups.  In other words, the SequenceIndex
    identifies the location for the substitution at the time that the lookup 
    is to be applied.

    For example, consider an input glyph sequence of four glyphs.  The first
    glyph does not have a substitute, but the middle two glyphs will be
    replaced with a ligature, and a single glyph will replace the fourth
    glyph.

    The first glyph is in position 0.  No lookups will be applied at
    position 0, so no SubstLookupRecord is defined.

    The SubstLookupRecord defined for the ligature substitution specifies
    the Sequence index as position 1, which is the position of the first
    glyph component in the ligature string.  After the ligature replaces
    the glyphs in positions 1 and 2 however, the input glyph sequence consists
    of only three glyphs, not the original four.

    To replace the last glyph in the sequence, the SubstLookupRecord defines
    the SequenceIndex as position 2 instead of 3.  This position reflects the
    effect of the ligature substitution applied before this single 
    substitution.

---------------------------------------------------------------------------- */
typedef struct __SubstLookupRecord__
{
    USHORT            SequenceIndex;            // Index into current glyph sequence-first
                                            // glyph = 0

    USHORT            LookupListIndex;        // Lookup to apply to that position-zero-
                                            // based.

} context_lookup_record;




/* ----------------------------------------------------------------------------
    This structure is used in the chained context_classes, as a shortcut
    for the parameter lists.  many of the prune functions require all
    of these structures, so instead of putting them all in a parameter
    call, I have created this to store all of the relevant data.

---------------------------------------------------------------------------- */
typedef struct __context_classes__
{
    class_def*           Input;
    class_def*           LookAhead;
    class_def*           Backtrack;
    void*                Coverage;

    ULONG                totalClasses;

    LF_VECTOR*           validClasses;

} context_classes;



/* ----------------------------------------------------------------------------

    Used for removing unused classes for chained context rules.  this
    structure contains whether the class is referenced or not in the
    class context sequences.

    This structure is used in the context_classes, validClasses
    vector collection.

    The context sequences for chained are for Input, Backtrack, and
    Input.

    The Class represents the id we are looking for a reference for.

    If the Input value is 1, then that means the Class element was
    found in one of the Input context sequences in the ClassRules
    for the Chained Context rule.  Similarly, that means the same
    for LookAhead, and Backtrack.

---------------------------------------------------------------------------- */
typedef struct __context_define__
{
    USHORT                Class;                        // the Class id associated with the below elements
    USHORT                Input;                        // TRUE - if Class referenced otherwise FALSE
    USHORT                LookAhead;                    // TRUE - if Class referenced otherwise FALSE
    USHORT                Backtrack;                    // TRUE - if Class referenced otherwise FALSE

} context_define;


LF_ERROR        Common_readSubstLookupRecords(LF_VECTOR* array, USHORT count, LF_STREAM* stream);
LF_ERROR        Common_readSubstLookupRecord(context_lookup_record* slr, LF_STREAM* stream);
void            Common_freeSubstLookupRecord(context_lookup_record* slr);
size_t          Common_buildSubstLookupRecord(context_lookup_record* slr, LF_STREAM* stream);
ULONG           Common_sizeSubstLookupRecord(context_lookup_record* slr);
LF_ERROR        Common_buildSubstLookupRecords(LF_VECTOR* records, LF_STREAM* stream);
void            Common_freeSubstLookupRecords(LF_VECTOR* records);
ULONG           Common_sizeSubstLookupRecords(LF_VECTOR* records);
LF_ERROR        Common_removeLookupListIndex(LF_VECTOR* records, USHORT refIndex, SHORT deltaIndex);

#ifdef LF_OT_DUMP
void            Common_dumpSubstLookupRecords(LF_VECTOR* records);
#endif

void            Common_buildGlyphArray(LF_VECTOR* glyphs, LF_STREAM* stream);
void            Common_buildGlyphCountArray(LF_VECTOR* glyphs, LF_STREAM* stream, USHORT adjustment);

void            Common_buildClassDef(class_def* cd, LF_STREAM* stream, ULONG arrayOffset, ULONG baseOffset);
void            Common_buildClassArray(LF_VECTOR* classes, LF_STREAM* stream);
void            Common_buildClassCountArray(LF_VECTOR* classes, LF_STREAM* stream, USHORT adjustment);

size_t          Common_buildEmptyArray(LF_STREAM* stream, USHORT count);
LF_ERROR        Common_remapGlyph(LF_MAP* remap, GlyphID oldid, GlyphID* newid);

void            Common_cleanupLookups(LF_VECTOR* records, TABLE_HANDLE hLookup);
LF_ERROR        Common_collectLookupRecordGlyphs(LF_VECTOR* records, GlyphList* keepList, TABLE_HANDLE hTable);

/* ==================================================================
    @desc
        useful common functions that are used throughout the 
        build or stream process.

================================================================== */
ULONG           Common_writeOffset(LF_STREAM* stream, ULONG arrayOffset, ULONG baseOffset);

#endif // end of __COMMON_TABLE_H__
