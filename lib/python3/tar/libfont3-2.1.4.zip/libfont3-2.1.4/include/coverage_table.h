// Copyright (C) 2014 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// coverage_table.h

#ifndef __COVERAGE_TABLE_H__
#define __COVERAGE_TABLE_H__

#ifdef __cplusplus
extern "C" {
#endif

#include "data_types.h"
#include "lf_error.h"
#include "stream.h"
#include "lf_vector.h"
#include "lf_map.h"
#include "keep_table.h"

/* ------------------------------------------------------------------
    Coverage Format 1

    Coverage Format 1 consists of a format code (CoverageFormat) 
    and a count of covered glyphs (GlyphCount), followed by an array 
    of glyph indices (GlyphArray). The glyph indices must be in 
    numerical order for binary searching of the list. When a glyph 
    is found in the Coverage table, its position in the GlyphArray 
    determines the Coverage Index that is returned-the first glyph 
    has a Coverage Index = 0, and the last glyph has a Coverage 
    Index = GlyphCount -1.

------------------------------------------------------------------ */
typedef struct _coverage_table_1
{
    USHORT      GlyphCount;                //Number of glyphs in the GlyphArray
    GlyphID*    GlyphArray;
} coverage_table_1;



/* ------------------------------------------------------------------
    Coverage Format 2

    Format 2 consists of a format code (CoverageFormat) and a count 
    of glyph index ranges (RangeCount), followed by an array of 
    records (RangeRecords). Each RangeRecord consists of a start 
    glyph index (Start), an end glyph index (End), and the Coverage 
    Index associated with the range's Start glyph. Ranges must be 
    in GlyphID order, and they must be distinct, with no 
    overlapping.

    The Coverage Indexes for the first range begin with zero (0), 
    and the Start Coverage Indexes for each succeeding range are 
    determined by adding the length of the preceding range (End 
    GlyphID - Start GlyphID + 1) to the array Index. This allows 
    for a quick calculation of the Coverage Index for any glyph 
    in any range using the formula: 

    Coverage Index (GlyphID) = StartCoverageIndex + GlyphID - Start GlyphID.

------------------------------------------------------------------ */
typedef struct _range_record
{
    GlyphID               Start;                  // first glyph ID in the range
    GlyphID               End;                    // last glyph ID in the range
    USHORT                StartCoverageIndex;     // coverage index of first glyph ID in the range
} range_record;

#define RANGE_RECORD_SIZE (2 * sizeof(GlyphID) + sizeof(USHORT))

typedef struct _coverage_table_2
{
    //USHORT           RangeCount;        // Number of RangeRecords
    //range_record*    RangeRecord;       // Array of glyph ranges-ordered by Start GlyphID
    LF_VECTOR        RangeRecords;
} coverage_table_2;



/* ------------------------------------------------------------------
    Coverage table

    Each subtable (except an Extension LookupType subtable) in a lookup 
    references a Coverage table (Coverage), which specifies all the glyphs 
    affected by a substitution or positioning operation described in the 
    subtable. The GSUB, GPOS, and GDEF tables rely on this notion of 
    coverage. If a glyph does not appear in a Coverage table, the client 
    can skip that subtable and move immediately to the next subtable.
    
    A Coverage table identifies glyphs by glyph indices (GlyphIDs) either 
    of two ways:
        As a list of individual glyph indices in the glyph set.
        
        As ranges of consecutive indices. The range format gives a number 
        of start-glyph and end-glyph index pairs to denote the consecutive 
        glyphs covered by the table.
    
    In a Coverage table, a format code (CoverageFormat) specifies the 
    format as an integer: 1 = lists, and 2 = ranges.
    
    A Coverage table defines a unique index value (Coverage Index) for 
    each covered glyph. This unique value specifies the position of the 
    covered glyph in the Coverage table. The client uses the Coverage 
    Index to look up values in the subtable for each glyph.

----------------------------------------------------------------- */
typedef struct _coverage_table
{
    USHORT                CoverageFormat;       // original format read in

    union _coverage_format
    {
        coverage_table_1 format_1;              // original data read from file
        coverage_table_2 format_2;              // original data read from file
    } coverage_format;


    // LibFont - working data structures
    LF_VECTOR           CoverageMap;            // contains working data of all coverages

    USHORT              build_format;           // which format

    coverage_table_1    build_1;                // build format 1
    coverage_table_2    build_2;                // build format 2

    USHORT              size_build_1;           // size of build_1
    USHORT              size_build_2;           // size of build_2

    ULONG               ReadSize;
    USHORT              ReadFormat;

    GlyphID             minGlyph;
    GlyphID             maxGlyph;
    USHORT              curIndex;

    LF_MAP              sortedMap;

    boolean             isAscending;            // TRUE if values in coverage are in ascending order.
                                                // The spec requires that the values be in ascending order
                                                // so that a binary search can be done. But there are
                                                // fonts which have out of order coverage lists, so this
                                                // is an attempt to deal with that without rejecting the font outright.
} coverage_table;



LF_ERROR    Coverage_readTable(coverage_table* table, LF_STREAM* stream);
LF_ERROR    Coverage_buildTable(coverage_table* table, LF_STREAM* stream);
LF_ERROR    Coverage_getTableSize(coverage_table* table, size_t* tableSize);
void        Coverage_deleteTable(coverage_table* table);
LF_ERROR    Coverage_removeGlyphIndex(coverage_table* table, GlyphID glyphID, ULONG* index);
//size_t    Coverage_getCoverageCount(coverage_table* table);
#define     Coverage_getCoverageCount(t) ((t)->CoverageMap.count)
LF_ERROR    Coverage_getCoverageAt(coverage_table* ct, USHORT offset, USHORT* glyph);


// Functions that use LF_VECTOR of coverage tables
LF_ERROR    Coverage_buildTables(LF_VECTOR* coverages, LF_STREAM* stream, ULONG baseOffset, ULONG arrayOffset);
size_t      Coverage_sizeCoverages(LF_VECTOR* coverages);
void        Coverage_deleteCoverageTables(LF_VECTOR* coverages);
LF_ERROR    Coverage_removeCoveragesGlyphIndex(LF_VECTOR* coverages, GlyphID glyphid);


// Helper Functions that build out coverage table and update array offsets.
LF_ERROR    Coverage_buildCoverage(coverage_table* ct, LF_STREAM* stream, ULONG arrayOffset, ULONG baseOffset);
LF_ERROR    Coverage_readArray(LF_VECTOR* array, USHORT count, LF_STREAM* stream, ULONG baseOffset);
LF_ERROR    Coverage_eraseIndex(coverage_table* table, USHORT index);
LF_ERROR    Coverage_remapAll(coverage_table* table, LF_MAP* remap);
LF_ERROR    Coverage_remapTables(LF_VECTOR* coverages, LF_MAP* remap);
LF_ERROR    Coverage_existsInKeepList(coverage_table* coverage, GlyphList* keepTable);
LF_ERROR    Coverages_existsInKeepList(LF_VECTOR* coverages, GlyphList* keepTable);
LF_ERROR    Coverage_findGlyphIndex(coverage_table* table, GlyphID glyphID, ULONG* index);
LF_ERROR    Coverage_done(coverage_table* table);
LF_ERROR    Coverage_addGlyph(coverage_table* table, GlyphID glyph);
LF_ERROR    Coverage_create(coverage_table* table, USHORT glyphCount);

#ifdef LF_OT_DUMP
void        Coverage_dumpTables(LF_VECTOR* coverages);
void        Coverage_dumpTable(coverage_table* ct);
#endif

#ifdef __cplusplus
}
#endif

#endif //__COVERAGE_TABLE_H__
