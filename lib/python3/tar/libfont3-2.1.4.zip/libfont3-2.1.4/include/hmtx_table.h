// Copyright (C) 2014 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// hmtx_table.h

#ifndef __HMTX_TABLE_H__
#define __HMTX_TABLE_H__

#include <stdio.h>
#include "lf_core.h"
#include "stream.h"
#include "offset_table_sfnt.h"

#ifdef __cplusplus
extern "C" {
#endif

#define HMTX_MARK_REMOVED 0x00000000FFFFFFFF

typedef struct     _longHorMetric {
    USHORT    advanceWidth;
    SHORT    lsb;
} longHorMetric;

#define LONGHORMETRIC_SIZE (sizeof(USHORT) + sizeof(SHORT))

typedef struct _hmtx_table
{
    USHORT      numHMetrics;
    LF_VECTOR   metricsVector;

    boolean     numMetricsCalculated;
    boolean     subsetted;
    size_t      calculatedTableSize;
} hmtx_table;

LF_API USHORT      HMTX_getAdvanceWidth(LF_FONT* lfFont, size_t index);
LF_API LF_ERROR    HMTX_readTable(LF_FONT* lfFont, const sfnt_table_record* record, LF_STREAM* stream);
LF_API LF_ERROR    HMTX_getTableSize(LF_FONT* lfFont, size_t* tableSize);
LF_API LF_ERROR    HMTX_writeTable(LF_FONT* lfFont, sfnt_table_record* record, LF_STREAM* stream);
LF_API LF_ERROR    HMTX_removeGlyph(LF_FONT* lfFont, ULONG index);
LF_API LF_ERROR    HMTX_updateSidebearings(LF_FONT* lfFont, LF_FONT_TYPE type, 
                                           FWORD *minlsb, FWORD *minrsb, FWORD *maxadvance);
LF_API UFWORD      HMTX_getAdvanceWidthMax(LF_FONT* lfFont);
LF_API FWORD       HMTX_getAdvanceWidthAvg(LF_FONT* lfFont);
LF_API USHORT      HMTX_getNumHMetrics(LF_FONT* lfFont);
LF_API LF_ERROR    HMTX_freeTable(LF_FONT* lfFont);
LF_API LF_ERROR    HMTX_remapTable(LF_FONT* lfFont, LF_MAP *remap);
LF_API LF_ERROR    HMTX_expandTable(LF_FONT* lfFont, USHORT numGlyphs);
LF_API LF_ERROR    HMTX_setMetric(LF_FONT* lfFont, size_t index, USHORT advanceWidth, SHORT lsb);

#ifdef __cplusplus
}
#endif

#endif //__HMTX_TABLE_H__
