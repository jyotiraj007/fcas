// Copyright (C) 2014 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// base_table.h

#ifndef __BASE_TABLE_H__
#define __BASE_TABLE_H__

#include "data_types.h"
#include "offset_table_sfnt.h"
#include "keep_table.h"

#ifdef __cplusplus
extern "C" {
#endif

/* ----------------------------------------------------------------------------
    @summary

---------------------------------------------------------------------------- */
typedef enum __base_subtable_types__
{
    SUBTABLE_TYPE_NONE,
    SUBTABLE_TYPE_GSUB_SINGLE,
    SUBTABLE_TYPE_GSUB_MULTIPLE,
    SUBTABLE_TYPE_GSUB_ALTERNATE,
    SUBTABLE_TYPE_GSUB_LIGATURE,
    SUBTABLE_TYPE_GSUB_CONTEXT,
    SUBTABLE_TYPE_GSUB_EXTENSION,
    SUBTABLE_TYPE_GSUB_REVERSE_CHAIN,

    SUBTABLE_TYPE_GPOS_SINGLE,
    SUBTABLE_TYPE_GPOS_PAIR,
    SUBTABLE_TYPE_GPOS_CURSIVE,
    SUBTABLE_TYPE_GPOS_MARK_TO_BASE,
    SUBTABLE_TYPE_GPOS_MARK_TO_LIGATURE,
    SUBTABLE_TYPE_GPOS_MARK_TO_MARK,
    SUBTABLE_TYPE_GPOS_CONTEXT,
    SUBTABLE_TYPE_GPOS_CHAINED_CONTEXT,
    SUBTABLE_TYPE_GPOS_EXTENSION

} eBaseSubTableTypes;


typedef enum __base_table_types__
{
    TABLETYPE_UNKNOWN,
    TABLETYPE_GPOS,
    TABLETYPE_GSUB,
    TABLETYPE_FEATURE,
    TABLETYPE_SCRIPT,
    TABLETYPE_LOOKUP

} eBaseTableTypes;

/* ----------------------------------------------------------------------------
    @summary
        This structure is used as a parent structure to all of the
        GPOS/GSUB rules.  It can be used as a working structure that
        is common to all of the rules and build associations between
        the different rules.

        An example would be to link the different tables together such
        as a context rule may use several lookup records which are attached
        to that context rule.  however those rules in the lookup records
        are not associated with the feature table and therefore we can
        build the relationship of those rules to be only with the context
        rule.
---------------------------------------------------------------------------- */
typedef struct __gsub_base__
{
    //LF_FONT*                    font;                   // pointer to LF_FONT

    struct __gsub_base__*       parent;                 // parent table - null if no parent
    LF_VECTOR*                  children;               // children associated with this
                                                        // table. vector of pointers to
                                                        // BaseTable structures.

    eBaseTableTypes             type;                   // type of structure
    eBaseSubTableTypes          subType;                // subtype of structure

#ifdef LF_OT_DUMP
    USHORT                      dump;
#endif

    USHORT                      refCount;                // referencing count
    boolean                     collected;               // TRUE if the subtables in this lookup have been checked
                                                         // to see if any referneced glyphs need to be kept
    ULONG                       ignore;
    ULONG                       prevLookupIndex;         // previous lookup value (before subset)
    ULONG                       nextLookupIndex;         // remapped lookup value (after subset)

} base_table;


void                BaseTable_init(TABLE_HANDLE table, TABLE_HANDLE parent);
void                BaseTable_setType(TABLE_HANDLE table, eBaseTableTypes type, eBaseSubTableTypes subtype);
eBaseSubTableTypes  BaseTable_getSubType(TABLE_HANDLE table);
void                BaseTable_setParent(TABLE_HANDLE table, TABLE_HANDLE parent);
void                BaseTable_setPrevLookup(TABLE_HANDLE table, ULONG index);
void                BaseTable_setNextLookup(TABLE_HANDLE table, ULONG index);

#ifdef LF_OT_DUMP
void                BaseTable_dump(TABLE_HANDLE table);
USHORT              BaseTable_isDump(TABLE_HANDLE table);
#endif

#ifdef __cplusplus
}
#endif

#endif // __BASE_TABLE_H__
