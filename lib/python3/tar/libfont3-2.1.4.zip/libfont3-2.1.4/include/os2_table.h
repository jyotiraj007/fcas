// Copyright (C) 2014, 2015, 2016, 2017 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// os2_table.h

#include "lf_core.h"
#include "offset_table_sfnt.h"
#include "table_tags.h"

#ifndef __OS2_TABLE_H__
#define __OS2_TABLE_H__

#ifdef __cplusplus
extern "C" {
#endif

// See http://www.microsoft.com/typography/otspec/os2.htm for description of the OS/2 table.

// versions 1 through 5 are handled. version 0 is not handled.

typedef struct _os2_table_5
{
    USHORT  version;
    SHORT   xAvgCharWidth;
    USHORT  usWeightClass;
    USHORT  usWidthClass;
    USHORT  fsType;
    SHORT   ySubscriptXSize;
    SHORT   ySubscriptYSize;
    SHORT   ySubscriptXOffset;
    SHORT   ySubscriptYOffset;
    SHORT   ySuperscriptXSize;
    SHORT   ySuperscriptYSize;
    SHORT   ySuperscriptXOffset;
    SHORT   ySuperscriptYOffset;
    SHORT   yStrikeoutSize;
    SHORT   yStrikeoutPosition;
    SHORT   sFamilyClass;
    BYTE    panose[10];
    ULONG   ulUnicodeRange1;    //Bits 0-31
    ULONG   ulUnicodeRange2;    //Bits 32-63
    ULONG   ulUnicodeRange3;    //Bits 64-95
    ULONG   ulUnicodeRange4;    //Bits 96-127
    CHAR    achVendID[4];
    USHORT  fsSelection;
    USHORT  usFirstCharIndex;
    USHORT  usLastCharIndex;
    SHORT   sTypoAscender;
    SHORT   sTypoDescender;
    SHORT   sTypoLineGap;
    USHORT  usWinAscent;
    USHORT  usWinDescent;
    ULONG   ulCodePageRange1;   //Bits 0-31
    ULONG   ulCodePageRange2;   //Bits 32-63
    // The below fields were added with version 1
    SHORT   sxHeight;
    SHORT   sCapHeight;
    USHORT  usDefaultChar;
    USHORT  usBreakChar;
    USHORT  usMaxContext;
    // The below fields were added with version 5
    USHORT  usLowerOpticalPointSize;
    USHORT  usUpperOpticalPointSize;
} os2_table_5;

typedef struct _os2_table_
{
    os2_table_5 v5;

    //INTERNAL
    BYTE *data;
    ULONG length;
    boolean isParsed;
    boolean modified;
} os2_table;

#define OS2_V1_TABLE_SIZE (9 *sizeof(USHORT) + 15*sizeof(SHORT) + 10*sizeof(BYTE) + 6*sizeof(ULONG) + 4*sizeof(CHAR))
#define OS2_V2_TABLE_SIZE (12*sizeof(USHORT) + 17*sizeof(SHORT) + 10*sizeof(BYTE) + 6*sizeof(ULONG) + 4*sizeof(CHAR))
#define OS2_V3_TABLE_SIZE OS2_V2_TABLE_SIZE
#define OS2_V4_TABLE_SIZE OS2_V2_TABLE_SIZE
#define OS2_V5_TABLE_SIZE (14*sizeof(USHORT) + 17*sizeof(SHORT) + 10*sizeof(BYTE) + 6*sizeof(ULONG) + 4*sizeof(CHAR))

LF_API LF_ERROR OS2_readTable(LF_FONT* lfFont, const sfnt_table_record* record, LF_STREAM* stream);
LF_API LF_ERROR OS2_getTableSize(LF_FONT* lfFont, size_t* tableSize);
LF_API LF_ERROR OS2_writeTable(LF_FONT* lfFont, sfnt_table_record* record, LF_STREAM* stream);
LF_API LF_ERROR OS2_freeTable(LF_FONT* lfFont);

LF_API LF_ERROR OS2_setCharIndex(LF_FONT* lfFont, USHORT firstIndex, USHORT lastIndex);
LF_API LF_ERROR OS2_setAvgCharWidth(LF_FONT* lfFont, SHORT avgWidth);
LF_API LF_ERROR OS2_setFsType(LF_FONT* lfFont, USHORT value);
LF_API LF_ERROR OS2_setFsSelection(LF_FONT* lfFont, USHORT fsSelection);
LF_API LF_ERROR OS2_setWeightClass(LF_FONT* lfFont, USHORT usWeightClass);
LF_API LF_ERROR OS2_upgradeTable(LF_FONT* lfFont);
LF_API LF_ERROR OS2_updateHeights(LF_FONT* lfFont);
#if 0 // not in use
LF_API LF_ERROR OS2_updateMaxContent(LF_FONT* lfFont);
#endif

LF_API LF_ERROR OS2_getVersion(LF_FONT* lfFont, USHORT* version);
LF_API LF_ERROR OS2_getFsType(LF_FONT* lfFont, USHORT* value);
LF_API LF_ERROR OS2_getPanoseValues(LF_FONT* lfFont, BYTE* values);
LF_API LF_ERROR OS2_getFsSelection(LF_FONT* lfFont, USHORT* fsSelection);
LF_API LF_ERROR OS2_getWeightClass(LF_FONT* lfFont, USHORT* usWeightClass);
LF_API LF_ERROR OS2_getUnicodeRange(LF_FONT* lfFont, ULONG* range1, ULONG* range2, ULONG* range3, ULONG* range4);
LF_API LF_ERROR OS2_getCodePageRange(LF_FONT* lfFont, ULONG* range1, ULONG* range2);
LF_API LF_ERROR OS2_getAvgCharWidth(LF_FONT* lfFont, USHORT* value);
LF_API LF_ERROR OS2_getAscent(LF_FONT* lfFont, FWORD* ascent);
LF_API LF_ERROR OS2_getDescent(LF_FONT* lfFont, FWORD* descent);
LF_API LF_ERROR OS2_getVendor(LF_FONT* lfFont, CHAR vendor[4]);

#ifdef __cplusplus
}
#endif

#endif //__OS2_TABLE_H__
