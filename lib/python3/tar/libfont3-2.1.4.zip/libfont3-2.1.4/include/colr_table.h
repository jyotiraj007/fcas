// Copyright (C) 2016 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// colr_table.h

#include "data_types.h"
#include "offset_table_sfnt.h"
#include "lf_core.h"
#include "keep_table.h"

#ifndef __COLR_TABLE_H__
#define __COLR_TABLE_H__

#ifdef __cplusplus
extern "C" {
#endif


typedef struct _base_glyph_record_
{
    //USHORT GID;                   // Glyph ID of reference glyph.This glyph is for reference only and is not rendered for color.
    USHORT firstLayerIndex;         // Index(from beginning of the Layer Records) to the layer record.There will be numLayers consecutive entries for this base glyph.
    USHORT numLayers;               // Number of color layers associated with this glyph.
} base_glyph_record;

typedef struct _layer_record_
{
    USHORT GID;                     // Glyph ID of layer glyph(must be in z - order from bottom to top).
    USHORT paletteIndex;            // Index value to use with a selected color palette.This value must be less than numPaletteEntries
                                    // in the CPAL table.A palette entry index value of 0xFFFF is a special case indicating that the text
                                    // foreground color(defined by a higher - level client) should be used and shall not be treated as actual
                                    // index into CPAL ColorRecord array.

    boolean retain;                 // TRUE if this record is kept during a subset.
} layer_record;

typedef struct _colr_table_
{
    USHORT version;                 // Table version number(starts at 0).
    USHORT numBaseGlyphRecords;     // Number of Base Glyph Records.
    ULONG  offsetBaseGlyphRecord;   // Offset(from beginning of COLR table) to Base Glyph records.
    ULONG  offsetLayerRecord;       // Offset(from beginning of COLR table) to Layer Records.
    USHORT numLayerRecords;         // Number of Layer Records.

    LF_MAP  baseGlyphsMap;          // map of key = GID data = base_glyph_record*
    LF_VECTOR layerRecords;         // array of layer_record*
    boolean remapped;               // TRUE if the table has been remapped after subsetting

} colr_table;


LF_ERROR COLR_readTable(LF_FONT* lfFont, const sfnt_table_record* record, LF_STREAM* stream);
LF_ERROR COLR_keepGlyphs(const LF_FONT* lfFont, GlyphList* keepList);
LF_ERROR COLR_removeGlyph(LF_FONT* lfFont, ULONG index);
LF_ERROR COLR_isTableEmpty(LF_FONT* lfFont);
LF_ERROR COLR_remapTable(LF_FONT* lfFont, LF_MAP *remap);
LF_ERROR COLR_getTableSize(LF_FONT* lfFont, size_t* tableSize);
LF_ERROR COLR_writeTable(LF_FONT* lfFont, sfnt_table_record* record, LF_STREAM* stream);
LF_ERROR COLR_freeTable(LF_FONT* lfFont);

#ifdef __cplusplus
}
#endif

#endif //__COLR_TABLE_H__
