// Copyright (C) 2014 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// anchor.h

#ifndef __ANCHOR_TABLE_H__
#define __ANCHOR_TABLE_H__

#include "data_types.h"
#include "stream.h"
#include "lf_error.h"
#include "device_table.h"

#ifdef __cplusplus
extern "C" {
#endif

typedef struct _anchor_format2
{
    USHORT    AnchorPoint;
} anchor_format2;

typedef struct _anchor_format3
{
    device_table    XDeviceTable;
    device_table    YDeviceTable;
} anchor_format3;

typedef struct _anchor_table
{
    USHORT   AnchorFormat;
    SHORT    XCoordinate;
    SHORT    YCoordinate;

    union _anchor_format
    {
        anchor_format2    format_2;
        anchor_format3    format_3;
    } anchor_format;
} anchor_table;


LF_ERROR    Anchor_readTable(anchor_table* table, LF_STREAM* stream);
LF_ERROR    Anchor_getTableSize(const anchor_table* table, size_t* tableSize);
LF_ERROR    Anchor_buildTable(anchor_table* table, LF_STREAM* stream);
LF_ERROR    Anchor_freeTable(anchor_table* table);

#ifdef LF_OT_DUMP
void        Anchor_dumpTable(anchor_table* table);
#endif

#ifdef __cplusplus
}
#endif

#endif //__ANCHOR_TABLE_H__
