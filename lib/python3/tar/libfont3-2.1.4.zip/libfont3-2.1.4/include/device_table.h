// Copyright (C) 2014 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// device_table.h

#include "data_types.h"
#include "stream.h"
#include "lf_error.h"
#include "coverage_table.h"
#include "lf_vector.h"
#include "stream.h"

#ifndef __DEVICE_TABLE_H__
#define __DEVICE_TABLE_H__

#ifdef __cplusplus
extern "C" {
#endif

typedef struct _device_table
{
    USHORT       StartSize;      //Smallest size to correct - in ppem
    USHORT       EndSize;        //Largest size to correct - in ppem
    USHORT       DeltaFormat;    //Format of DeltaValue array data: 1, 2, or 3
    LF_VECTOR    DeltaValue;     //Array of compressed data
} device_table;

LF_ERROR DeviceTable_readTable(device_table* table, LF_STREAM* stream);
LF_ERROR DeviceTable_getTableSize(const device_table* table, size_t* tableSize);
LF_ERROR DeviceTable_buildTable(device_table* table, LF_STREAM* stream);
LF_ERROR DeviceTable_freeTable(device_table* table);
#ifdef LF_OT_DUMP
void     DeviceTable_dumpTable(device_table* table);
#endif

#ifdef __cplusplus
}
#endif

#endif //__DEVICE_TABLE_H__
