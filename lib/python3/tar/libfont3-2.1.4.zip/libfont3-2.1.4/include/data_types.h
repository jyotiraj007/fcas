// Copyright (C) 2014, 2016 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// data_types.h

/*
 * 
 * This is part of LibFont, an OpenType format parsing library.
 *
 */

#ifndef __DATA_TYPES_H__
#define __DATA_TYPES_H__

#include <stdlib.h>

#ifdef _MSC_VER
  // This is needed for building the Python bridge.
  #if (_MSC_VER == 1500)
    typedef signed char        int8_t;
    typedef short              int16_t;
    typedef int                int32_t;
    typedef long long          int64_t;
    typedef unsigned char      uint8_t;
    typedef unsigned short     uint16_t;
    typedef unsigned int       uint32_t;
    typedef unsigned long long uint64_t;
  #else
    #include <stdint.h>
  #endif
  #define INLINE __inline /* use __forceinline (VC++ specific) */
#else
  #include <stdint.h>
  #define INLINE inline   /* use standard inline */
#endif

#ifndef _WINDLL
#define LF_API
#else
#define LF_API __declspec( dllexport )
#endif


typedef int32_t         FIXED;           //32-bit signed fixed-point number (16.16)
typedef int16_t         SHORTFIXED;      //16-bit signed fixed-point number (2.14)
typedef uint16_t        OFFSET;
typedef uint8_t         BYTE;            //8-bit unsigned integer.
typedef uint16_t        USHORT;          //16-bit unsigned integer.
typedef uint32_t        ULONG;           //32-bit unsigned integer.
typedef uint32_t        TAG;
typedef int32_t         LONG;
typedef int16_t         SHORT;           //16-bit signed integer.
typedef int8_t          CHAR;            //8-bit signed integer.
typedef int64_t         LONGDATETIME;    //Date represented in number of seconds since 12:00 midnight, January 1, 1904. The value is represented as a signed 64-bit integer.
typedef SHORT           FWORD;           //16-bit signed integer (SHORT) that describes a quantity in FUnits.
typedef USHORT          UFWORD;          //16-bit unsigned integer (USHORT) that describes a quantity in FUnits.
typedef int16_t         F2DOT14;         //16-bit signed fixed number with the low 14 bits of fraction (2.14).
typedef int32_t         F2DOT30;         //32-bit signed fixed number with the low 30 bits of fraction (2.30).
typedef void*           TABLE_HANDLE;

// references that reflect the correct naming conventions of the documentation as supplied by both Microsoft and Adobe.
typedef USHORT          uint16;
typedef USHORT          GlyphID;


#ifdef TRUE
#undef TRUE
#endif
#ifdef FALSE
#undef FALSE
#endif

typedef enum _boolean { FALSE, TRUE } boolean;

// Macros

// This library is intended for little endian machines.
#define SWAP_SHORT(x)    (SHORT)((((x) & 0xFF00) >> 8)  | (((x) & 0x00FF) << 8))
#define SWAP_USHORT(x)   (USHORT)((((x) & 0xFF00) >> 8) | (((x) & 0x00FF) << 8))
#define SWAP_LONG(x)     (LONG)(((x) >> 24)  | (((x) & 0x00FF0000) >> 8) | (((x) & 0x0000FF00) << 8) | ((x) << 24))
#define SWAP_ULONG(x)    (ULONG)(((x) >> 24) | (((x) & 0x00FF0000) >> 8) | (((x) & 0x0000FF00) << 8) | ((x) << 24))

#define UNUSED(x) (void)x;

#endif //__DATA_TYPES_H__
