// Copyright (C) 2014, 2016, 2017 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// sfnt_core.h

#ifndef __SFNT_CORE_H__
#define __SFNT_CORE_H__

#include "data_types.h"
#include "lf_core.h"
#include "lf_harmonize.h"
#include "lf_error.h"
#include "offset_table_sfnt.h"

#ifdef __cplusplus
extern "C" {
#endif

LF_ERROR SFNT_readOffsetTable(LF_FONT* lfFont, LF_STREAM* stream, int keepFlags);
LF_API LF_ERROR SFNT_unpackTables(LF_FONT* lfFont);
LF_ERROR SFNT_constructSFNT(LF_FONT* lfFont, const LF_WRITE_PARAMS *params);
LF_ERROR SFNT_clearSFNT(LF_FONT* lfFont);
LF_ERROR SFNT_writeToStream(LF_FONT* lfFont, const LF_WRITE_PARAMS *params, LF_STREAM* stream);
boolean  SFNT_tableInOffsetTable(LF_FONT* lfFont, ULONG tag);
LF_ERROR SFNT_removeTable(LF_FONT* lfFont, ULONG tag);
LF_ERROR SFNT_removeHints(LF_FONT* lfFont);
LF_ERROR SFNT_getSFNTSize(LF_FONT* lfFont, const LF_WRITE_PARAMS *params, size_t* size);
LF_ERROR SFNT_getTablesSize(LF_FONT* lfFont, const LF_WRITE_PARAMS *params, size_t* size);
LF_ERROR SFNT_writeTable(LF_FONT* lfFont, const LF_WRITE_PARAMS *params, sfnt_table_record* record, LF_STREAM* stream);
LF_ERROR SFNT_freeFont(LF_FONT* lfFont);
LF_ERROR SFNT_obfuscateFont(LF_FONT* lfFont);
LF_ERROR SFNT_getNameString(LF_FONT* lfFont, boolean isMac, USHORT nameID, BYTE** name, USHORT* length);
LF_ERROR SFNT_setNameString(LF_FONT* lfFont, boolean isMac, USHORT nameID, const BYTE *buffer, USHORT length);
boolean  SFNT_tablesUnpacked(LF_FONT* lfFont);
LF_ERROR SFNT_unpackVAlignTable(LF_FONT* lfFont);
LF_ERROR SFNT_packVAlignTable(LF_FONT* lfFont);
LF_ERROR SFNT_checkGlyphTable(LF_FONT* lfFont, LF_FONT_TYPE outputType, const LF_WRITE_PARAMS *params);
LF_ERROR SFNT_getGlyphID(LF_FONT* lfFont, ULONG unicode, GlyphID* glyphID);
LF_ERROR SFNT_getVendorID(LF_FONT* lfFont, CHAR achVendID[4]);
LF_ERROR SFNT_getFsType(LF_FONT* lfFont, USHORT* embedding);
LF_ERROR SFNT_setFsType(LF_FONT* lfFont, USHORT embedding);
LF_ERROR SFNT_getFsSelection(LF_FONT* lfFont, USHORT* selection);
LF_ERROR SFNT_setFsSelection(LF_FONT* lfFont, USHORT selection);
LF_ERROR SFNT_getUsWeightClass(LF_FONT* lfFont, USHORT* usWeightClass);
LF_ERROR SFNT_setUsWeightClass(LF_FONT* lfFont, USHORT usWeightClass);
LF_ERROR SFNT_getMacStyle(LF_FONT* lfFont, USHORT* macStyle);
LF_ERROR SFNT_setMacStyle(LF_FONT* lfFont, USHORT macStyle);
LF_ERROR SFNT_insertCFF(LF_FONT* lfFont);
LF_ERROR SFNT_insertGLYFAndLOCA(LF_FONT* lfFont, boolean populateMap);
LF_ERROR SFNT_getGlyph(LF_FONT* lfFont, GlyphID index, LF_GLYPH** glyphData);
LF_ERROR SFNT_freeGlyph(LF_GLYPH* glyphData);
LF_ERROR SFNT_setGlyph(LF_FONT* lfFont, GlyphID index, LF_GLYPH* glyphData);
LF_ERROR SFNT_updateFont(LF_FONT* lfFont);

#ifdef __cplusplus
}
#endif

#endif //__SFNT_CORE_H__
