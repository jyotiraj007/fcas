// Copyright (C) 2014 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// fpgm_table.h

#ifndef __FPGM_TABLE_H__
#define __FPGM_TABLE_H__

#include <stdio.h>
#include "data_types.h"
#include "offset_table_sfnt.h"
#include "lf_core.h"

#ifdef __cplusplus
extern "C" {
#endif



#if 0 // The functions below are not yet implemented.
LF_ERROR    FPGM_readTable(LF_FONT* lfFont, const sfnt_table_record* record, LF_STREAM* stream);
LF_ERROR    FPGM_getTableSize(LF_FONT* lfFont, size_t* tableSize);
LF_ERROR    FPGM_writeTable(LF_FONT* lfFont, sfnt_table_record* record, LF_STREAM* stream);
LF_ERROR    FPGM_freeTable(LF_FONT* lfFont, const sfnt_table_record* record);
#endif

#ifdef __cplusplus
}
#endif

#endif //__FPGM_TABLE_H__
