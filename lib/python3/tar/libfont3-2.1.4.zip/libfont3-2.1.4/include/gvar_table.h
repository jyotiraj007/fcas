// Copyright (C) 2016 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// gvar_table.h

#include <stdio.h>
#include "data_types.h"
#include "offset_table_sfnt.h"
#include "lf_core.h"

#ifndef __GVAR_TABLE_H__
#define __GVAR_TABLE_H__

#ifdef __cplusplus
extern "C" {
#endif

typedef struct _glyph_variation_
{
    ULONG length;
    BYTE* data;
} glyph_variation;

typedef struct _gvar_table
{
    USHORT version;                     // Version number of the glyph variations table(1 for the current version).
    USHORT reserved;                    // Currently unused; set to 0.
    USHORT axisCount;                   // The number of style axes for this font.This must be the same number as axisCount in the 'fvar' table.
    USHORT sharedCoordCount;            // The number of shared coordinates.
    ULONG offsetToCoord;                // Byte offset from the beginning of this table to the list of shared style coordinates.
    USHORT glyphCount;                  // The number of glyphs in this font; this should match the number of the glyphs store elsewhere in the font.
    USHORT flags;                       // Bit - field that gives the format of the offset array that follows.If the flag is 0, the type is uint16.If the flag is 1, the type is unit 32.
    ULONG offsetToData;                 // Byte offset from the beginning of this table to the first glyph glyphVariationData.

    LF_VECTOR sharedCoords;             // vector of sharedCoordCount * axisCount SHORTFIXEDs
    LF_MAP variationMap;                // map of key = glyphID, data = glyph_variation*
} gvar_table;


LF_ERROR GVAR_readTable(LF_FONT* lfFont, const sfnt_table_record* record, LF_STREAM* stream);
LF_ERROR GVAR_removeGlyph(LF_FONT* lfFont, ULONG index);
LF_ERROR GVAR_remapTable(LF_FONT* lfFont, LF_MAP *glyphIndexMap);
LF_ERROR GVAR_isTableEmpty(LF_FONT* lfFont);
LF_ERROR GVAR_getTableSize(LF_FONT* lfFont, size_t* tableSize);
LF_ERROR GVAR_writeTable(LF_FONT* lfFont, sfnt_table_record* record, LF_STREAM* stream);
LF_ERROR GVAR_freeTable(LF_FONT* lfFont);

#ifdef __cplusplus
}
#endif

#endif //__GVAR_TABLE_H__
