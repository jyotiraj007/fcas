// Copyright (C) 2014 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// woff2_core.h

#ifndef __WOFF2_CORE_H__
#define __WOFF2_CORE_H__

#include "data_types.h"
#include "lf_error.h"
#include "stream.h"
#include "offset_table_woff2.h"

#ifdef __cplusplus
extern "C" {
#endif

LF_ERROR WOFF2_readOffsetTable(LF_FONT* lfFont, LF_STREAM* stream, int keepFlags);
LF_ERROR WOFF2_getData(LF_FONT* lfFont, LF_STREAM* stream);
LF_ERROR WOFF2_to_SFNT(LF_FONT* lfFont, LF_STREAM* stream);
LF_ERROR WOFF2_writeToStream(LF_FONT* lfFont, const LF_WRITE_PARAMS *params, LF_STREAM* stream);
boolean  WOFF2_decompress(const BYTE* src, ULONG srcLen, BYTE* dest, size_t* destLen);
LF_ERROR WOFF2_getMaxSize(LF_FONT* lfFont, const LF_WRITE_PARAMS *params, size_t* size);

#ifdef __cplusplus
}
#endif

#endif //__WOFF2_CORE_H__
