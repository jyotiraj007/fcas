// Copyright (C) 2014 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// hhea_table.h

#include <stdio.h>
#include "data_types.h"
#include "lf_core.h"
#include "stream.h"
#include "offset_table_sfnt.h"
#include "table_tags.h"

#ifndef __HHEA_TABLE_H__
#define __HHEA_TABLE_H__

#ifdef __cplusplus
extern "C" {
#endif


typedef struct _hhea_table
{
    FIXED    version;               //0x00010000 for version 1.0.
    FWORD    Ascender;              //Typographic ascent. (Distance from baseline of highest ascender)
    FWORD    Descender;             //Typographic descent. (Distance from baseline of lowest descender)
    FWORD    LineGap;               //Typographic line gap. 
                                    //Negative LineGap values are treated as zero 
                                    //in Windows 3.1, System 6, and 
                                    //System 7.
    UFWORD   advanceWidthMax;       //Maximum advance width value in 'hmtx' table.
    FWORD    minLeftSideBearing;    //Minimum left sidebearing value in 'hmtx' table.
    FWORD    minRightSideBearing;   //Minimum right sidebearing value; calculated as Min(aw - lsb - (xMax - xMin)).
    FWORD    xMaxExtent;            //Max(lsb + (xMax - xMin)).
    SHORT    caretSlopeRise;        //Used to calculate the slope of the cursor (rise/run); 1 for vertical.
    SHORT    caretSlopeRun;         //0 for vertical.
    SHORT    caretOffset;           //The amount by which a slanted highlight on a glyph needs to be shifted to produce the best appearance. Set to 0 for non-slanted fonts
    SHORT    reserved1;             //set to 0
    SHORT    reserved2;             //set to 0
    SHORT    reserved3;             //set to 0
    SHORT    reserved4;             //set to 0
    SHORT    metricDataFormat;      //0 for current format.
    USHORT   numberOfHMetrics;      //Number of hMetric entries in 'hmtx' table
} hhea_table;

#define HHEA_TABLE_SIZE (sizeof(FIXED) + sizeof(FWORD) * 7 + sizeof(SHORT) * 9)

LF_API LF_ERROR    HHEA_readTable(LF_FONT* lfFont, const sfnt_table_record* record, LF_STREAM* stream);
LF_API LF_ERROR    HHEA_getTableSize(LF_FONT* lfFont, size_t* tableSize);
LF_API LF_ERROR    HHEA_writeTable(LF_FONT* lfFont, sfnt_table_record* record, LF_STREAM* stream);
LF_API USHORT      HHEA_getNumHMetrics(LF_FONT* lfFont);
LF_API void        HHEA_setNumHMetrics(LF_FONT* lfFont, USHORT numHMetrics);
LF_API void        HHEA_setAdvanceWidthMax(LF_FONT* lfFont, UFWORD advanceWidthMax);
LF_API void        HHEA_setLeftSidebearingMin(LF_FONT* lfFont, UFWORD leftSidebearingMin);
LF_API void        HHEA_setRightSidebearingMin(LF_FONT* lfFont, UFWORD rightSidebearingMin);
LF_API void        HHEA_setXMaxExtent(LF_FONT* lfFont, SHORT xMaxExtent);
LF_API LF_ERROR    HHEA_freeTable(LF_FONT* lfFont);


LF_API FWORD        HHEA_getAscender(LF_FONT* lfFont);
LF_API void         HHEA_setAscender(LF_FONT* lfFont, FWORD ascender);
LF_API FWORD        HHEA_getDescender(LF_FONT* lfFont);
LF_API void         HHEA_setDescender(LF_FONT* lfFont, FWORD descender);
LF_API FWORD        HHEA_getLineGap(LF_FONT* lfFont);
LF_API void         HHEA_setLineGap(LF_FONT* lfFont, FWORD linegap);


// overwriteTable will overwrite into the original stream file
LF_API LF_ERROR     HHEA_overwriteTable(LF_FONT* lfFont, sfnt_table_record* record, LF_STREAM* stream);

#ifdef __cplusplus
}
#endif

#endif //__HHEA_TABLE_H__
