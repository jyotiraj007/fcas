// Copyright (C) 2014 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// lookup_table.h

#ifndef __LOOKUP_TABLE_H__
#define __LOOKUP_TABLE_H__

#include "data_types.h"
#include "lf_vector.h"
#include "stream.h"
#include "base_table.h"

#ifdef __cplusplus
extern "C" {
#endif
     
#define RIGHT_TO_LEFT          0x0001    //This bit relates only to the correct processing of the cursive attachment lookup type (GPOS lookup type 3). When this bit is set, the last glyph in a given sequence to which the cursive attachment lookup is applied, will be positioned on the baseline. 
                                         //Note: Setting of this bit is not intended to be used by operating systems or applications to determine text direction. 
#define IGNORE_BASE_GLYPHS     0x0002    //If set, skips over base glyphs
#define IGNORE_LIGATURES       0x0004    //If set, skips over ligatures
#define IGNORE_MARKS           0x0008    //If set, skips over all combining marks
#define USEMARKFILTERINGSET    0x0010    //If set, indicates that the lookup table structure is followed by a MarkFilteringSet field. The layout engine skips over all mark glyphs not in the mark filtering set indicated.
#define LOOKUP_RESERVED        0x00E0    //For future use (Set to zero)
#define MARK_ATTACHMENT_TYPE   0xFF00    //If not zero, skips over all marks of attachment type different from specified.

typedef struct _lookup_table
{
    base_table       Base;
    USHORT           LookupType;         // Different enumerations for GSUB and GPOS
    USHORT           LookupFlag;         // Lookup qualifiers
    LF_VECTOR        SubTables;          // Collection of GSUB or GPOS tables
    USHORT           MarkFilteringSet;   // Index (base 0) into GDEF mark glyph sets structure. This field is only present if bit UseMarkFilteringSet of lookup flags is set.
} lookup_table;

size_t       Lookup_getDataSize(TABLE_HANDLE hTable, boolean isGPOS);
TABLE_HANDLE Lookup_readListTable(LF_STREAM* stream, boolean isGPOS);
LF_ERROR     Lookup_buildTable(TABLE_HANDLE hTable, boolean isGPOS, size_t* tableSize, BYTE** table);
LF_ERROR     Lookup_removeGlyph(TABLE_HANDLE hTable, TABLE_HANDLE hFeature, ULONG index, boolean isGPOS);
LF_ERROR     Lookup_freeTableList(TABLE_HANDLE hTable, boolean isGPOS);
LF_ERROR     Lookup_pruneLookups(TABLE_HANDLE hTable, TABLE_HANDLE hFeature, boolean isGPOS);
LF_ERROR     Lookup_remapTables(TABLE_HANDLE hTable, LF_MAP* remap, boolean isGPOS);
#ifdef LF_OT_DUMP
LF_ERROR     Lookup_dumpTables(TABLE_HANDLE hTable, boolean isGPOS);
#endif
TABLE_HANDLE Lookup_getFeatureTable(TABLE_HANDLE hHandle, boolean isGPOS);
TABLE_HANDLE Lookup_getScriptTable(TABLE_HANDLE hHandle, boolean isGPOS);
void         Lookup_cleanupLookups(TABLE_HANDLE hLookups, USHORT lookupIndex);
LF_ERROR     Lookup_removeUnReferencedLookups(TABLE_HANDLE hTable, TABLE_HANDLE hHeader, boolean isGPOS);
LF_ERROR     Lookup_collectGlyphs(GlyphList* keepList, TABLE_HANDLE hTable, USHORT lookupIndex);
LF_ERROR     Lookup_collectUncollectedAlternateGlyphs(GlyphList* keepList, TABLE_HANDLE hTable);
void         Lookup_clearCollectFlags(TABLE_HANDLE hTable);
LF_ERROR     Lookup_clearGDEFFlags(TABLE_HANDLE hTable);

#ifdef __cplusplus
}
#endif

#endif //__LOOKUP_TABLE_H__
