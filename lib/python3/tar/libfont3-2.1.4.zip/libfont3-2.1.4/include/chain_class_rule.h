// Copyright (C) 2014 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// chain_class_rule.h

#ifndef __CHAIN_CLASS_RULE_H__
#define __CHAIN_CLASS_RULE_H__

#include "data_types.h"
#include "stream.h"
#include "lf_error.h"
#include "lf_vector.h"
#include "common_table.h"
#include "class_rule.h"
#include "classdef.h"

#ifdef __cplusplus
extern "C" {
#endif


/* ----------------------------------------------------------------------------

    Class rule contains a count for substitutions to be performed on
    the context (LookupCount) and an array of lookup records (LookupRecords) 
    that supply the lookup record script data.  For each position in the 
    context that requires a substitution or position, a LookupRecord specifies 
    a LookupList index and a position in the input glyph sequence where the 
    lookup is applied.  The LookupRecord array lists LookupRecords in design 
    order-that is, the order in which lookups should be applied to the 
    entire glyph sequence.

---------------------------------------------------------------------------- */
typedef struct __chain_class_rule__
{
    USHORT           InputClass;

    class_rule       Input;

    LF_VECTOR        Backtrack;

    LF_VECTOR        LookAhead;

} chain_class_rule;


// Chain Class Rules
void        ChainClassRule_freeRule(chain_class_rule* ccr);
LF_ERROR    ChainClassRule_readRule(class_def* input, class_def* backtrack, class_def* lookahead, 
                                    chain_class_rule* ccr, LF_STREAM* stream);

size_t      ChainClassRule_sizeRule(chain_class_rule* ccr);
size_t      ChainClassRule_buildRule(chain_class_rule* ccr, LF_STREAM* stream);

LF_ERROR    ChainClassRule_pruneLookupRecords(chain_class_rule* ccr, context_classes* context);
LF_ERROR    ChainClassRule_validClassRules(chain_class_rule* ccr);

LF_ERROR    ChainClassRule_findValidClasses(chain_class_rule* ccr, context_classes* context);
LF_ERROR    ChainClassRule_remapClasses(LF_VECTOR* sequence, USHORT classref, SHORT delta);
LF_ERROR    ChainClassRule_collectGlyphs(chain_class_rule* ccr, context_classes* context, GlyphList* keepList, TABLE_HANDLE hTable);

#ifdef LF_OT_DUMP
void        ChainClassRule_dumpRule(chain_class_rule* ccr);
#endif

#ifdef __cplusplus
}
#endif

#endif //__CHAIN_CLASS_RULE_H__
