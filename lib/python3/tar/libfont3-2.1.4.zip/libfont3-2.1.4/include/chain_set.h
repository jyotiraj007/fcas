// Copyright (C) 2014 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// chain_set.h

#include "data_types.h"
#include "stream.h"
#include "lf_error.h"
#include "lf_vector.h"
#include "coverage_table.h"
#include "chain_rule.h"

#ifndef __CHAIN_SET_H__
#define __CHAIN_SET_H__

#ifdef __cplusplus
extern "C" {
#endif

typedef struct __chain_set__
{
    LF_VECTOR    ChainSet;          // Array collection of context_rule tables-from
                                    // beginning of RuleSet table-ordered
} chain_set;

LF_ERROR    ChainSets_readRuleSets(LF_VECTOR* css, USHORT numSets, LF_STREAM* stream, ULONG baseOffset);
void        ChainSets_freeRuleSets(LF_VECTOR* css);
size_t      ChainSets_sizeRuleSets(LF_VECTOR* css);
LF_ERROR    ChainSets_removeLookupRecordIndex(LF_VECTOR* css, USHORT lookupIndex, SHORT deltaIndex);
LF_ERROR    ChainSets_pruneRuleSets(LF_VECTOR* css, coverage_table* table, GlyphID glyphid);
LF_ERROR    ChainSet_remapRulesSets(LF_VECTOR* css, LF_MAP *remap);

LF_ERROR    ChainSet_readRuleSet(chain_set* cs, LF_STREAM* stream);
void        ChainSet_freeRuleSet(chain_set* cs);
size_t      ChainSet_sizeRuleSet(chain_set* cs);
size_t      ChainSet_buildRuleSet(chain_set* cs, LF_STREAM* stream);

LF_ERROR    ChainSet_removeLookupRecordIndex(chain_set* pcs, USHORT lookupIndex, SHORT deltaIndex);

LF_ERROR    ChainSets_cleanupLookups(LF_VECTOR* css, TABLE_HANDLE hLookup);
LF_ERROR    ChainSets_collectGlyphs(LF_VECTOR* css, GlyphList* keepList, TABLE_HANDLE hTable);

#ifdef LF_OT_DUMP
void        ChainSets_dumpRuleSets(LF_VECTOR* css);
void        ChainSet_dumpRuleSet(chain_set* cs);
#endif

#ifdef __cplusplus
}
#endif

#endif //__CHAIN_SET_H__
