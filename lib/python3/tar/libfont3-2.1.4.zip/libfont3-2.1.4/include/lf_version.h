// Copyright (C) 2014, 2015, 2016, 2017, 2018 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
/// \file lf_version.h

#include <string.h>

//! Main library version
/*!
    LIBFONT_VERSION represents the major/minor version number for the library.
*/
#define LIBFONT_VERSION "2.1.4"

//! Library version string definition
/*!
    VERSION_STRING represents a character string that contains a version number.
*/
typedef char VERSION_STRING[20];

