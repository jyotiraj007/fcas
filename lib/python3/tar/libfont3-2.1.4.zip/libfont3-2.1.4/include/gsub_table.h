// Copyright (C) 2014, 2015 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// gsub_table.h

#ifndef __GSUB_TABLE_H__
#define __GSUB_TABLE_H__

#include <stdio.h>
#include "data_types.h"
#include "offset_table_sfnt.h"
#include "script_list.h"
#include "feature_table.h"
#include "lookup_table.h"
#include "gsub_lookup/gsub_single.h"    // used by svg code

#ifdef __cplusplus
extern "C" {
#endif


/* ----------------------------------------------------------------------------
    @summary
        The GSUB table begins with a header that contains a version number
        for the table (Version) and offsets to a three tables:
            ScriptList
            FeatureList
            LookupList.

        For descriptions of each of these tables, see the chapter,
        OpenType Common Table Formats. Example 1 at the end of this
        chapter shows a GSUB Header table definition.

        The following gsub header structure is used for reading in
        the script, feature and lookup lists and storing them in
        a common header location.


    @notes
        base_table structure has been added to allow for a form of
        reflecton when parsing through tables.  this will allow a
        lookup table to find it's parent, and therefore retrieve
        the lookup, feature, or script table that are associated 
        with the table.

        also a feature table will be able to get to the script
        or other table.
---------------------------------------------------------------------------- */
typedef struct _gsub_header
{
    base_table      Base;
    FIXED           Version;                // Version of the GSUB table-initially set to 0x00010000
    TABLE_HANDLE    ScriptList;             // ScriptList (LF_VECTOR) of scripts in the GSUB table
    TABLE_HANDLE    FeatureList;            // FeatureList (feature_list) of features in the GSUB table
    TABLE_HANDLE    LookupList;             // LookupList  (LF_VECTOR) of Lookups in the GSUB table

    boolean         isValid;                // Whether the table is valid (only feature offset and lookup offset are checked so far)
    size_t          calculatedTableSize;    // size in bytes of table if written, 0 if table is dirty
} gsub_header;


LF_ERROR        GSUB_readTable(LF_FONT* lfFont, const sfnt_table_record* record, LF_STREAM* stream);
LF_ERROR        GSUB_getTableSize(LF_FONT* lfFont, size_t* tableSize);
LF_ERROR        GSUB_writeTable(LF_FONT* lfFont, sfnt_table_record* record, LF_STREAM* stream);
boolean         GSUB_isValid(LF_FONT* lfFont);
LF_ERROR        GSUB_isTableEmpty(LF_FONT* lfFont);
LF_ERROR        GSUB_getMaxLigaDepth(LF_FONT* lfFont, USHORT* depth);
LF_ERROR        GSUB_freeTable(LF_FONT* lfFont);

LF_API LF_ERROR GSUB_removeGlyph(LF_FONT* lfFont, ULONG i);
LF_ERROR        GSUB_collectGlyphs(LF_FONT* lfFont, GlyphList* keepList);
LF_ERROR        GSUB_updateLookupFlags(LF_FONT* lfFont);
LF_ERROR        GSUB_remapTable(LF_FONT* lfFont, LF_MAP* remap);
LF_ERROR        GSUB_pruneLookupRecords(USHORT lookupType, TABLE_HANDLE table);
LF_ERROR        GSUB_pruneLookups(LF_FONT* lfFont);
LF_ERROR        GSUB_removeUnReferencedLookups(LF_FONT* lfFont);
LF_ERROR        GSUB_cleanupLookups(LF_FONT* lfFont);
LF_ERROR        GSUB_removeAllTables(LF_FONT* lfFont);

TABLE_HANDLE    GSUB_readSubtable(USHORT lookupType, LF_STREAM* stream);
size_t          GSUB_buildSubTable(USHORT lookupType, TABLE_HANDLE hTable, LF_STREAM* stream);
size_t          GSUB_getSubtableSize(USHORT lookupType, TABLE_HANDLE hTable);
LF_ERROR        GSUB_subtableRemoveGlyph(USHORT lookupType, TABLE_HANDLE hTable, ULONG index);
void            GSUB_freeSubtable(USHORT lookupType, TABLE_HANDLE table);
LF_ERROR        GSUB_removeLookupIndexSubtable(USHORT lookupType, TABLE_HANDLE table, USHORT refIndex, SHORT deltaIndex);

LF_ERROR        GSUB_subtableRemapGlyph(USHORT lookupType, TABLE_HANDLE table, LF_MAP* remap);
LF_ERROR        GSUB_cleanupLookupSubtables(USHORT lookupType, TABLE_HANDLE subtable, TABLE_HANDLE hLookup);
LF_ERROR        GSUB_collectSubtableGlyphs(GlyphList* keepList, TABLE_HANDLE hTable, USHORT lookupType, TABLE_HANDLE hSubTable);

script_table*   GSUB_getScriptTable(LF_FONT* lfFont, TAG tag);
feature_table*  GSUB_getFeatureTable(LF_FONT* lfFont, langsys_table* langTable, TAG tag);
lookup_table*   GSUB_getLookupTable(LF_FONT* lfFont, feature_table* featureTable, ULONG index);

#ifdef LF_OT_DUMP
LF_ERROR        GSUB_dumpTable(LF_FONT* lfFont);
LF_ERROR        GSUB_dumpSubtable(USHORT lookupType, TABLE_HANDLE table);
#endif

#ifdef __cplusplus
}
#endif

#endif // __GSUB_TABLE_H__
