// Copyright (C) 2015 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// cff_core_prv.h

#ifndef __CFF_CORE_PRV_H__
#define __CFF_CORE_PRV_H__

#include "data_types.h"

#ifdef __cplusplus
extern "C" {
#endif

typedef struct
{
    double fval[48];
    LONG val[48];
    boolean encodedAsFloat[48];
} ARGS;

typedef struct
{
    FIXED x0, y0;
    FIXED x1, y1;
    FIXED x2, y2;
    FIXED x3, y3;
    FIXED x4, y4;
    FIXED x5, y5;
    FIXED x6, y6;
    int fd;

} FLEXARGS;

#define SWAPW(x) ( (((USHORT)(x) >> 8) & 0x00FFU) | (((USHORT)(x) << 8) & 0xFF00U) )
#define SWAPL(x) ( (((x) >> 24) & 0x000000FF) | (((x) >> 8) & 0x0000FF00) | (((x) << 8) & 0x00FF0000) | (((x) << 24) & 0xFF000000) )

#define NEXTARG() (args[i++])
#define NEXTARGNONCOORD() (args[i++] >> 16/*lint !e702*/)

#define MYINFINITY              2147483647L
#define LF_FIXED_ONE            (FIXED)(1L << 16)
#define DOUBLE_TO_FIXED(x)      (FIXED)((x < 0) ? (-(long)((-x * (double)LF_FIXED_ONE) + 0.5)) : ((long)((x * (double)LF_FIXED_ONE) + 0.5)))
#define FIXED_TO_DOUBLE(x)      ((double)x / (double)LF_FIXED_ONE)
#define FLOAT_TO_FIXED(x)       (FIXED)((x < 0) ? (-(long)((-x * (float)LF_FIXED_ONE) + 0.5)) : ((long)((x * (float)LF_FIXED_ONE) + 0.5)))
#define FIXED_TO_FLOAT(x)       ((float)x / (float)LF_FIXED_ONE)

#define HSTEM 1
#define VSTEM 2

#define POPCFFARG()   args[--state->numargs]
#define PUSHCFFARG(x) args[state->numargs++] = x;

typedef struct
{
    CFF_TAB *cffTab;
    parseReason operation;
    int depth;
    int numcontours;
    int numpoints;
    FIXED args[48];
    int numargs;
    FIXED prevx;
    FIXED prevy;
    boolean haveAdvanceWidth;
    float loopstartx;
    float loopstarty;
    int numhstems;
    int numvstems;
    FIXED dx;
    LONG transient[32];
    FIXED xMin;
    FIXED yMin;
    FIXED xMax;
    FIXED yMax;
    int numMovetos;
    int numLinetos;
    int numCurvetos;
    int numFlexprocs;
    int pointsSpaceAllocated;
    int contoursSpaceAllocated;

} cffCharStringState;

// enums for various types of charstrings that are created for glyphs
typedef enum
{
    eCSRegular = 0,         // a glyph will be converted to a charstring
    eCSSubroutinized,       // a glyph's contours will each be encoded as a subroutine, the charstring for the glyph will reference the subroutines
    eCSCompositeSubr,       // charstring for a composite glyph will reference subroutines of the contours of its components, with needed offsets
    eCSCompositeFlat        // components of a composite glyph will be flattened into a single charstring, unable to subroutinize due to scaling or depth
} CharStringType;

// linked list of info about contours of glyphs which will be subroutinzied. We need
// to know where each contour starts in order to encode correct deltas in the charstring.
struct _subr_info_
{
    int subrIndex;
    int startx;
    int starty;
    struct _subr_info_ *next;
};

typedef struct _subr_info_ subrInfo;

// structure for info about a glyph during conversion to a charstring
typedef struct
{
    CharStringType type;
    struct _subr_info_ *info;
} CSInfo;

#ifdef __cplusplus
}
#endif

#endif // __CFF_CORE_PRV_H__
