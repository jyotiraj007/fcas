// Copyright (C) 2014 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// gpos_marktobase.h


/* ============================================================================
    @summary

============================================================================ */
#ifndef __GPOS_LOOKUP_MARKTOBASE_ATTACHMENT_H__
#define __GPOS_LOOKUP_MARKTOBASE_ATTACHMENT_H__

#include "data_types.h"
#include "lf_vector.h"
#include "coverage_table.h"
#include "offset_table_sfnt.h"
#include "base_table.h"

#ifdef __cplusplus
extern "C" {
#endif

typedef struct _gpos_marktobase
{
    base_table        Base;
    USHORT            PosFormat;
    coverage_table    MarkCoverage;
    coverage_table    BaseCoverage;
    USHORT            ClassCount;
    LF_VECTOR         MarkArray;
    LF_VECTOR         BaseArray;
} gpos_marktobase;


TABLE_HANDLE    GPOS_readMarkToBase(LF_STREAM* stream);
size_t          GPOS_getMarkToBaseSize(gpos_marktobase* table);
size_t          GPOS_buildMarkToBase(gpos_marktobase* table, LF_STREAM* stream);
LF_ERROR        GPOS_markToBaseRemoveGlyph(gpos_marktobase* table, GlyphID glyphID);
LF_ERROR        GPOS_markToBaseRemapTable(gpos_marktobase* table, LF_MAP *remap);
LF_ERROR        GPOS_markToBaseSetAnchorFmt1(gpos_marktobase* table);
void            GPOS_freeMarkToBase(gpos_marktobase* table);

#ifdef LF_OT_DUMP
LF_ERROR        GPOS_dumpMarkToBase(gpos_marktobase* table);
#endif

#ifdef __cplusplus
}
#endif

#endif    // end of __GPOS_LOOKUP_MARKTOBASE_ATTACHMENT_H__
