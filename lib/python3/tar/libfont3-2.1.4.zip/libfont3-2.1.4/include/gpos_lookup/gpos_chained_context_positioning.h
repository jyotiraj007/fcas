// Copyright (C) 2014 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// gpos_chained_context_positioning.h

#include <stdio.h>
#include "data_types.h"
#include "offset_table_sfnt.h"
#include "utils.h"
#include "coverage_table.h"
#include "classdef.h"
#include "base_table.h"

#ifndef __GPOS_CHAINED_CONTEXT_POSITIONING_H__
#define __GPOS_CHAINED_CONTEXT_POSITIONING_H__




/* ----------------------------------------------------------------------------
    @brief
        Lookup type 8: Chaining Contextual Positioning Subtable.
        
    @description
        A Chaining Contextual Positioning subtable(ChainContextPos)describes 
        glyph positioning in context with an ability to look back and/or look 
        ahead in the sequence of glyphs. The design of the Chaining Contextual 
        Positioning subtable is parallel to that of the Contextual Positioning 
        subtable, including the availability of three formats.
        
        To specify the context, the coverage table lists the first glyph in the 
        input sequence, and the ChainPosRule subtable defines the rest. Once a 
        covered glyph is found at position i, the client reads the corresponding 
        ChainPosRuleSet table and examines each table to determine if it matches 
        the surrounding glyphs in the text. There is a match if the string 
        <backtrack sequence>+<input sequence>+<lookahead sequence> matches with 
        the glyphs at position i - BacktrackGlyphCount in the text.
        
        If there is a match, then the client finds the target glyphs for 
        positioning and performs the operations. Please note that (just like 
        in the ContextPosFormat1 subtable) these lookups are required to operate 
        within the range of text from the covered glyph to the end of the input 
        sequence. No positioning operations can be defined for the backtracking 
        sequence or the lookahead sequence.
        
        To clarify the ordering of glyph arrays for input, backtrack and 
        lookahead sequences, the following illustration is provided. Input 
        sequence match begins at i where the input sequence match begins. The 
        backtrack sequence is ordered beginning at i - 1 and increases in 
        offset value as one moves away from i. The lookahead sequence begins 
        after the input sequence and increases in logical order.
        
        Logical order -            a     b     c     d     e     f     g     h     i     j 
                                                i                          
        Input sequence -                           0     1                     
        Backtrack sequence -    3     2     1     0                               
        Lookahead sequence -                                 0     1     2     3 

---------------------------------------------------------------------------- */
#ifdef __cplusplus
extern "C" {
#endif


/* ----------------------------------------------------------------------------
    @description
        This Format is identical to Format 1 of Context Positioning lookup except 
        that the PosRule table is replaced with a ChainPosRule table. (Correspondingly, 
        the ChainPosRuleSet table differs from the PosRuleSet table only in that 
        it lists offsets to ChainPosRule subtables instead of PosRule tables; and 
        the ChainContextPosFormat1 subtable lists offsets to ChainPosRuleSet subtables
        instead of PosRuleSet subtables.)
---------------------------------------------------------------------------- */
typedef struct __chain_context_pos_format1__ 
{
    coverage_table    Coverage;                    // Offset to Coverage table-from 
                                                // beginning of ContextPos subtable.

    LF_VECTOR        ChainPosRuleSet;            // Array of offsets to ChainPosRule 
                                                // tables-from beginning of ContextPos
                                                // subtable-ordered by Coverage Index.
} chain_context_pos_format1;




typedef struct __chain_context_pos_format2__ 
{
    coverage_table           Coverage;              // Coverage table beginning of 
                                                    // ChainContextPos subtable

    class_def                BacktrackClassDef;


    class_def                InputClassDef;


    class_def                LookaheadClassDef;



    LF_VECTOR                ChainPosClassSet;

} chain_context_pos_format2;




typedef struct __chain_context_pos_format3__ 
{
    LF_VECTOR                BacktrackGlyphCoverage;

    LF_VECTOR                InputGlyphCoverage;

    LF_VECTOR                LookaheadGlyphCoverage;

    LF_VECTOR                PosLookupRecord;

} chain_context_pos_format3;



typedef struct __ChainPosClassSet__ 
{
    LF_VECTOR    ChainPosClassRule;         // array of Chain Pos class Rules tables from beginning 
                                            // of ChainPosRuleSet-ordered by preference.
} chain_pos_class_set;



typedef struct __chain_pos_class_rule__ 
{
    LF_VECTOR    Backtrack;                 // [BacktrackGlyphCount] Array of backtracking 
                                            // GlyphID's (to be matched before the input 
                                            // sequence)
                                            
    LF_VECTOR    Input;                     // [InputGlyphCount - 1] Array of input GlyphIDs 
                                            // (start with second glyph)
                                            
    LF_VECTOR    LookAhead;                 // [LookAheadGlyphCount] Array of lookahead 
                                            // GlyphID's (to be matched after the input 
                                            // sequence)
                                            
    LF_VECTOR    PosLookupRecord;           // [PosCount]    Array of PosLookupRecords (in design order)

} chain_pos_class_rule;


typedef struct __gpos_chain_context_pos__ 
{
    base_table        Base;
    USHORT            PosFormat;            // Format identifier - format

    union
    {
        chain_context_pos_format1    f1;
        chain_context_pos_format2    f2;
        chain_context_pos_format3    f3;

    } ccp;
} gpos_chain_context_positioning;



TABLE_HANDLE    GPOS_readChainContextPositioning(LF_STREAM* stream);
void            GPOS_freeChainContextPositioning(gpos_chain_context_positioning* ccp);
size_t          GPOS_buildChainContextPositioning(gpos_chain_context_positioning* ccp, LF_STREAM* stream);
size_t          GPOS_sizeChainContextPositioning(gpos_chain_context_positioning* ccp);
LF_ERROR        GPOS_removeChainContextPositioning(gpos_chain_context_positioning* ccp, GlyphID glyphid);
LF_ERROR        GPOS_removeChainContextPositioningLookupIndex(gpos_chain_context_positioning* ccp, USHORT refIndex, SHORT deltaIndex);
LF_ERROR        GPOS_ChainContextPositioningRemapTable(gpos_chain_context_positioning* ccp, LF_MAP *remap);
LF_ERROR        GPOS_pruneChainContextPosLookupRecords(gpos_chain_context_positioning* ccp);
LF_ERROR        GPOS_cleanupChainContextLookups(gpos_chain_context_positioning* ccp, TABLE_HANDLE hLookup);


#ifdef __cplusplus
}
#endif

#endif //__GPOS_CHAINED_CONTEXT_POSITIONING_H__

