// Copyright (C) 2014 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// gpos_context_positioning.h


/* ============================================================================
    @summary

============================================================================ */
#ifndef __GPOS_LOOKUP_CONTEXT_POSITIONING_H__
#define __GPOS_LOOKUP_CONTEXT_POSITIONING_H__

#include "data_types.h"
#include "offset_table_sfnt.h"
#include "utils.h"
#include "coverage_table.h"
#include "classdef.h"
#include "base_table.h"

#include "class_set.h"
#include "class_rule.h"

#include "context_set.h"
#include "context_rule.h"

#ifdef __cplusplus
extern "C" {
#endif

/* ----------------------------------------------------------------------------
    A PosRule table consists of a count of the glyphs to be matched in the 
    input context sequence (GlyphCount), including the first glyph in the 
    sequence, and an array of glyph indices that describe the context (Input). 
    The Coverage table specifies the index of the first glyph in the context, 
    and the Input array begins with the second glyph in the context sequence. 
    As a result, the first index position in the array is specified with the 
    number one (1), not zero (0). The Input array lists the indices in the 
    order the corresponding glyphs appear in the text. For text written from 
    right to left, the right-most glyph will be first; conversely, for text 
    written from left to right, the left-most glyph will be first.

    A PosRule table also contains a count of the positioning operations to 
    be performed on the input glyph sequence (PosCount) and an array of 
    PosLookupRecords (PosLookupRecord). Each record specifies a position in 
    the input glyph sequence and a LookupList index to the positioning 
    lookup to be applied there. The array should list records in design 
    order, or the order the lookups should be applied to the entire glyph 
    sequence.

---------------------------------------------------------------------------- */

typedef struct __gpos_context_position_f1__
{
    USHORT           PosRuleSetCount;
    coverage_table   Coverage;
    LF_VECTOR        PosRuleSet;                    // PosRuleSet[PosRuleSetCount]

} gpos_context_position_f1;

typedef struct __gpos_context_position_f2__
{
    coverage_table    Coverage;
    class_def        ClassDef;
    LF_VECTOR        PosClassSet;
} gpos_context_position_f2;


typedef struct __gpos_context_position_f3__
{
    LF_VECTOR    Coverage;
    LF_VECTOR    PosLookupRecord;

} gpos_context_position_f3;


typedef struct __gpos_context_positioning__
{
    base_table        Base;
    USHORT            PosFormat;                // 1, 2, or 3
    
    union
    {
        gpos_context_position_f1    cpf1;
        gpos_context_position_f2    cpf2;
        gpos_context_position_f3    cpf3;
    } csf;

} gpos_context_positioning;



LF_ERROR        GPOS_removeContextPositioningGlyphIndex(gpos_context_positioning* cp, GlyphID glyphid);
TABLE_HANDLE    GPOS_readContextPositioning(LF_STREAM* stream);
size_t          GPOS_buildContextPositioning(gpos_context_positioning* cp, LF_STREAM* stream);
size_t          GPOS_sizeContextPositioning(gpos_context_positioning* cp);
void            GPOS_freeContextPositioning(gpos_context_positioning* cp);
LF_ERROR        GPOS_removeContextPositioningLookupIndex(gpos_context_positioning* cp, USHORT lookupIndex, SHORT deltaIndex);
LF_ERROR        GPOS_pruneContextPositioningLookupRecords(gpos_context_positioning* cp);
LF_ERROR        GPOS_contextPositioningRemapTable(gpos_context_positioning* cp, LF_MAP *remap);
LF_ERROR        GPOS_cleanupContextLookups(gpos_context_positioning* cp, TABLE_HANDLE hLookup);

#ifdef __cplusplus
}
#endif

#endif    // end of __GPOS_LOOKUP_CONTEXT_POSITIONING_H__
