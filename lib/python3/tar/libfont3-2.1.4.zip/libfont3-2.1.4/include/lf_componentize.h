// Copyright (C) 2015 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
//
/// \file lf_componentize.h

#ifndef __LF_COMPONENTIZE_H__
#define __LF_COMPONENTIZE_H__

#include "lf_core.h"

#ifdef __cplusplus
extern "C" {
#endif

typedef LF_ERROR(*componentizeProgCB)(void* userState, USHORT progress);

typedef struct
{
    void* userState;
    componentizeProgCB progressCB;
} componentizeCBInfo;

LF_API LF_ERROR LF_componentizeFont(LF_FONT* lfFont, float tolerance, componentizeCBInfo* progresInfo);

#ifdef __cplusplus
}
#endif


#endif // __LF_COMPONENTIZE_H__
