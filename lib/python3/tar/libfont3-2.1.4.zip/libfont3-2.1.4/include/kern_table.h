// Copyright (C) 2014 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// kern_table.h

#include <stdio.h>
#include "lf_core.h"
#include "offset_table_sfnt.h"

#ifndef __KERN_TABLE_H__
#define __KERN_TABLE_H__

#ifdef __cplusplus
extern "C" {
#endif

typedef struct _kern_table_header
{
    USHORT      version;                // Table version number (0)
    USHORT      nTables;                // Number of subtables in the kerning table.

    // INTERNAL
    BYTE*       data;                   // raw data of table if not parsed
    ULONG       length;                 // length of table

    LF_VECTOR   subtables;              // list of subtables

    boolean     isParsed;               // whether this table has been parsed (only tables with format 0 subtables are parsed)
    size_t      calculatedTableSize;    // size in bytes of table if written, 0 if table is dirty
} kern_table_header;


typedef struct _kern_subtable_header
{
    USHORT version;        // Kern subtable version number
    USHORT length;         // Length of the subtable, in bytes (including this header).
    USHORT coverage;       // What type of information is contained in this table.
} kern_subtable_header;


typedef struct _kern_pair
{
    USHORT left;     // The glyph index for the left-hand glyph in the kerning pair.
    USHORT right;    // The glyph index for the right-hand glyph in the kerning pair.
    FWORD  value;    // The kerning value for the above pair, in FUnits.
} kern_pair;


typedef struct _kern_subtable_format0_info
{
    USHORT nPairs;            // This gives the number of kerning pairs in the table.
    USHORT searchRange;       // The largest power of two less than or equal to the value of nPairs, multiplied by the size in bytes of an entry in the table.
    USHORT entrySelector;     // This is calculated as log2 of the largest power of two less than or equal to the value of nPairs.
    USHORT rangeShift;        // The value of nPairs minus the largest power of two less than or equal to nPairs, and then multiplied by the size in bytes of an entry in the table.

    // INTERNAL
    LF_VECTOR pairs;          // list of pairs for this subtable
} kern_subtable_format0_info;


// note: format 2 subtable is not handled
typedef struct _kern_subtable_format2_info
{
    int placeholder;
} kern_subtable_format2_info;

typedef struct _kern_subtable
{
    kern_subtable_header header;

    union
    {
        kern_subtable_format0_info f0;
        kern_subtable_format2_info f2;
    } info;
} kern_subtable;


LF_API LF_ERROR    KERN_readTable(LF_FONT* lfFont, const sfnt_table_record* record, LF_STREAM* stream);
LF_API LF_ERROR    KERN_isTableEmpty(LF_FONT* lfFont);
LF_API LF_ERROR    KERN_getTableSize(LF_FONT* lfFont, size_t* tableSize);
LF_API LF_ERROR    KERN_writeTable(LF_FONT* lfFont, sfnt_table_record* record, LF_STREAM* stream);
LF_API LF_ERROR    KERN_freeTable(LF_FONT* lfFont);
LF_API LF_ERROR    KERN_removeGlyph(LF_FONT* lfFont, ULONG index);
LF_API LF_ERROR    KERN_remapTable(LF_FONT* lfFont, LF_MAP *glyphIndexMap);

#ifdef __cplusplus
}
#endif

#endif //__KERN_TABLE_H__
