// Copyright (C) 2014 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// offset_table_sfnt.h

#ifndef __OFFSET_SFNT_H__
#define __OFFSET_SFNT_H__

#include <stdio.h>
#include "data_types.h"
#include "lf_vector.h"
#include "stream.h"
#include "lf_core.h"

#ifdef __cplusplus
extern "C" {
#endif

#define TableExcludedFromCFFFont(tag)                             \
    (((tag == TAG_GLYF) || (tag == TAG_LOCA) ||                   \
      (tag == TAG_AVAR) || (tag == TAG_FVAR) ||                   \
      (tag == TAG_CVAR) || (tag == TAG_GVAR) ||                   \
      (tag == TAG_FMTX) || (tag == TAG_CVT ) ||                   \
      (tag == TAG_HDMX) || (tag == TAG_VDMX) ||                   \
      (tag == TAG_FPGM) || (tag == TAG_PREP) ||                   \
      (tag == TAG_KERN)) ? TRUE : FALSE)


typedef struct _sfnt_header
{
    FIXED   sfnt_version;   //0x00010000 for version 1.0.
    USHORT  numTables;      //Number of tables.
    USHORT  searchRange;    //(Maximum power of 2 <= numTables) x 16.
    USHORT  entrySelector;  //Log2(maximum power of 2 <= numTables).
    USHORT  rangeShift;     //NumTables x 16-searchRange.

} LF_SFNT_HEADER;

#define SFNT_HEADER_SIZE (sizeof(FIXED) + (sizeof(USHORT) * 4))

typedef struct _sfnt_offset_table 
{
    LF_SFNT_HEADER sfntHeader;

    //INTERNAL
    LF_VECTOR record_list;

} sfnt_offset_table;

typedef struct _sfnt_table_record
{
    ULONG    tag;           // 4 - byte identifier.
    ULONG    checkSum;      // CheckSum for this table.
    ULONG    offset;        // Offset from beginning of TrueType font file.
    ULONG    length;        // Length of this table.
} sfnt_table_record;

#define OFFSET_TABLE_SIZE  (sizeof(FIXED) + (sizeof(USHORT) * 4))

sfnt_offset_table*  offset_createTable(void);
sfnt_offset_table*  offset_copyTable(sfnt_offset_table* table);
boolean             offset_readFontHeader(const LF_FONT* lfFont, LF_STREAM* stream);
boolean             offset_readTable(const LF_FONT* lfFont, LF_STREAM* stream, int keepFlags);
sfnt_table_record*  offset_readRecord(LF_STREAM* stream);
sfnt_table_record*  offset_createRecord(void);
USHORT              offset_getNumTables(const LF_FONT* lfFont);

sfnt_table_record*  offset_getRecord(const LF_FONT* lfFont, size_t index);
LF_ERROR            offset_setSignature(const LF_FONT* lfFont, ULONG signature);

sfnt_table_record*  offset_findRecord(const LF_FONT* lfFont, ULONG tag);
sfnt_table_record*  offset_findRecordEx(sfnt_offset_table* table, ULONG tag);
boolean             offset_recordExists(const LF_FONT* lfFont, ULONG tag);
LF_ERROR            offset_insertNewRecord(const LF_FONT* lfFont, ULONG tag);
void                offset_deleteRecord(const LF_FONT* lfFont, ULONG tag);
LF_ERROR            offset_writeTable(const LF_FONT* lfFont, LF_STREAM* stream);
LF_ERROR            offset_writeRecords(const LF_FONT* lfFont, LF_STREAM* stream);
LF_ERROR            offset_freeTable(LF_FONT* lfFont);
LF_ERROR            offset_freeTableEx(sfnt_offset_table* table);
USHORT              offset_log2Floor(size_t tableCount);

#ifdef __cplusplus
}
#endif

#endif //__OFFSET_SFNT_H__
