// Copyright (C) 2014 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// norm_nfd.h

#ifndef __NORM_NFD_H__
#define __NORM_NFD_H__

#include "data_types.h"
#include "norm_nrmtxt.h"


#ifdef __cplusplus
extern "C" {
#endif


/*****************************************************************************
 *
 *  Decomposes a string to Normalization Form D (NFD).
 *
 *  Parameters:
 *      inputTextObj    - [in] the input text object
 *      inputStartIndex - [in] the start index for the input text
 *      inputEndIndex   - [in] the end index for the input text
 *
 *      outputTextObj    - [out] the output text object
 *      outputStartIndex - [in]  the start index for the output text
 *      outputEndIndex   - [out] the actual end index of the NFD decomposed text (this is an "out" only, not an "in" -- the "in" end index is (size-1) and can grow)
 *
 *  Return value:
 *      Result code -- TS_OK if all went well, error code otherwise.
 *
 *  <GROUP normalization>
 */
LF_API LF_ERROR TsNorm_decomposeStringToNFD(
    const TsNormTextObj *inputTextObj,
    LONG       inputStartIndex,
    LONG       inputEndIndex,
    TsNormTextObj *outputTextObj,
    LONG       outputStartIndex,
    LONG       *outputEndIndex
);


/*****************************************************************************
 *
 *  Decomposes a composite character into two component characters.
 *
 *  Parameters:
 *      inputChar       - [in] the input character to decompose
 *      pDecompChar1    - [out] the first of two decomposed characters
 *      pDecompChar2    - [out] the second of two decomposed characters
 *
 *  Return value:
 *      TRUE if character decomposed, FALSE otherwise.
 *
 *  <GROUP normalization>
 */
LF_API boolean TsNorm_decomposeChar(ULONG inputChar, ULONG * pDecompChar1, ULONG * pDecompChar2);

#ifdef __cplusplus
}
#endif


#endif /* __NORM_NFD_H__ */

