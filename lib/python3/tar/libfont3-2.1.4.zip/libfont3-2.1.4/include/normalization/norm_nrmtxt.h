// Copyright (C) 2014 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// norm_nrmtxt.h

#ifndef __NORM_NRMTXT_H__
#define __NORM_NRMTXT_H__

#include "data_types.h"
#include "lf_error.h"

#ifdef __cplusplus
extern "C" {
#endif


/*****************************************************************************
 * Macro to safely divide an integer by 2 using bit shifting.
 *
 * Watch out for side effects!
 *
 */
#define NORM_INT32_DIV2(x) (((x) < 0) ? -(LONG)(((ULONG)-(x)) >> 1) : (LONG)(((ULONG)(x)) >> 1))


#define LF_CHECK_RESULT(result) {if (result != LF_ERROR_OK) return result;}


/*****************************************************************************
 *
 *  The normalization text object.
 *
 *  Description:
 *
 *      The TsNormText object provides an abstracted interface to the
 *      normalization code.  The user must populate the object with a
 *      pointer to text and pointers to functions which can set characters
 *      and get characters in that text.
 *
 *      <PRE>
 *
 *      text
 *          -Description:
 *              pointer to the user's normalization text data which must
 *              be capable of storing characters and (if desired) the
 *              original index of those characters in the source text
 *      memMgr
 *          -Description:
 *              memory manager object (or NULL). Used in increaseSize function.
 *      size
 *          -Description:
 *              current size of the buffer (in entries, not bytes!)
 *      growth
 *          -Description:
 *              the size (in entries) by which to grow the buffer
 *      getChar
 *          -Description:
 *              retrieves a character and (if desired) a source index
 *          -Parameters:
 *              textObj     - [in] the normalization text object
 *              index       - [in] the index from which to retrieve a char
 *              charData    - [out] the actual character
 *              sourceIndex - [out] the index of the char in the original text
 *          -Returns:
 *              none
 *      setChar
 *          -Description:
 *              stores a character and (if desired) a source index
 *          -Parameters:
 *              textObj     - [in/out] the normalization text object
 *              index       - [in] the index at which to store a char
 *              charData    - [in] the actual character
 *              sourceIndex - [in] the index of the char in the original text
 *          -Returns:
 *              none
 *      increaseSize
 *          -Description:
 *              increases the size by the number of characters specified
 *          -Parameters:
 *              textObj     - [in/out] the normalization text object
 *              charsToAdd  - [in] the number of characters by which to increase
 *
 *      </PRE>
 *
 *  <GROUP normalization>
 */

typedef struct TsNormTextObj_
{
    void *text;
    //TsMemMgr *memMgr;
    LONG size;
    LONG growth;
    LF_ERROR (*getChar)(const struct TsNormTextObj_ *textObj, LONG index, ULONG *charData, LONG *sourceIndex);
    LF_ERROR (*setChar)(struct TsNormTextObj_ *textObj, LONG index, ULONG  charData, LONG  sourceIndex);
    LF_ERROR (*increaseSize)(struct TsNormTextObj_ *textObj, ULONG charsToAdd);
} TsNormTextObj;

#ifdef __cplusplus
}
#endif

#endif /* __NORM_NRMTXT_H__ */
