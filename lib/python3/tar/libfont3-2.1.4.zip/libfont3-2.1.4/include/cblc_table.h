// Copyright (C) 2016 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// cblc_table.h

#include <stdio.h>
#include "data_types.h"
#include "offset_table_sfnt.h"
#include "ebitmap_types.h"
#include "lf_core.h"

#ifndef __CBLC_TABLE_H__
#define __CBLC_TABLE_H__

#ifdef __cplusplus
extern "C" {
#endif


typedef embedded_loc_table cblc_table;


LF_ERROR CBLC_readTable(LF_FONT* lfFont, const sfnt_table_record* record, LF_STREAM* stream);
LF_ERROR CBLC_removeGlyph(const LF_FONT* lfFont, ULONG index);
LF_ERROR CBLC_remapTable(LF_FONT* lfFont, LF_MAP *remap);
LF_ERROR CBLC_updateMetrics(LF_FONT* lfFont);
LF_ERROR CBLC_getTableSize(LF_FONT* lfFont, size_t* tableSize);
LF_ERROR CBLC_writeTable(LF_FONT* lfFont, sfnt_table_record* record, LF_STREAM* stream);
LF_ERROR CBLC_freeTable(LF_FONT* lfFont);


#ifdef __cplusplus
}
#endif

#endif //__CBLC_TABLE_H__
