// Copyright (C) 2014 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// hdmx_table.h

#ifndef __HDMX_TABLE_H__
#define __HDMX_TABLE_H__

#include <stdio.h>
#include "lf_core.h"
#include "stream.h"
#include "offset_table_sfnt.h"


#ifdef __cplusplus
extern "C" {
#endif


typedef struct _device_record
{
    BYTE        pixelSize;          //Pixel size for following widths (as ppem).
    BYTE        maxWidth;           //Maximum width.

    USHORT*     widthsArray;        //Array of widths
    ULONG       widthsArrayLen;     //Length of widthsArray

    ULONG       totalGlyphs;        //Number of valid glyphs in widthsArray
} device_record;

typedef struct _hdmx_table
{
    USHORT  version;             //Table version number (0)
    SHORT   numRecords;          //Number of device records.
    LONG    sizeDeviceRecord;    //Size of a device record, long aligned.

    LF_VECTOR deviceRecordList;  //List of device records
} hdmx_table;

LF_API LF_ERROR    HDMX_readTable(LF_FONT* lfFont, const sfnt_table_record* record, LF_STREAM* stream);
LF_API LF_ERROR    HDMX_getTableSize(LF_FONT* lfFont, size_t* tableSize);
LF_API LF_ERROR    HDMX_writeTable(LF_FONT* lfFont, sfnt_table_record* record, LF_STREAM* stream);
LF_API LF_ERROR    HDMX_removeGlyph(LF_FONT* lfFont, ULONG index);
LF_API LF_ERROR    HDMX_freeTable(LF_FONT* lfFont);

#ifdef __cplusplus
}
#endif

#endif //__HDMX_TABLE_H__
