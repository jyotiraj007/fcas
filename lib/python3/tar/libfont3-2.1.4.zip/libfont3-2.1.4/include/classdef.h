// Copyright (C) 2014, 2015 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// classdef.h

#ifndef __CDEF_TABLE_H__
#define __CDEF_TABLE_H__

#include "data_types.h"
#include "stream.h"
#include "lf_error.h"
#include "lf_vector.h"
#include "lf_map.h"

#ifdef __cplusplus
extern "C" {
#endif

#define CLASSDEF_LIMITS         65535
#define MAX_CLASSDEF            CLASSDEF_LIMITS
#define IGNORE_STARTCLASS       0
//#define OPTIMIZED_LOOKUP

typedef struct __class_map__
{
    GlyphID       Glyph;
    USHORT        Class;
    USHORT        Defined;

} class_map;


/* ----------------------------------------------------------------------------
    ClassDefFormat1 specifies a range of consecutive glyph indices and a list 
    of corresponding glyph class values. This table is useful for assigning 
    each glyph to a different class because the glyph indices in each class 
    are not grouped together.

---------------------------------------------------------------------------- */
typedef struct _class_format1
{
    GlyphID      StartGlyph;                // First GlyphID of the ClassValueArray
    USHORT       GlyphCount;                // Size of the ClassValueArray

    LF_VECTOR    ClassValueArray;           // Array of Class Values-one per GlyphID
                                            // ClassValueArray[GlyphCount]

} class_format1;



/* ----------------------------------------------------------------------------
    ClassRangeRecord consists of a Start glyph index, an End glyph index, 
    and a Class value. All GlyphIDs in a range, from Start to End inclusive, 
    constitute the class identified by the Class value. Any glyph not covered 
    by a ClassRangeRecord is assumed to belong to Class 0.

---------------------------------------------------------------------------- */
typedef struct _class_range_record
{
    GlyphID       Start;                      // First GlyphID in the range
    GlyphID       End;                        // Last GlyphID in the range
    USHORT        Class;                      // Applied to all glyphs in the range

} class_range_record;


/* ----------------------------------------------------------------------------
    ClassDefFormat2 defines multiple groups of glyph indices that belong to 
    the same class. Each group consists of a discrete range of glyph indices 
    in consecutive order (ranges cannot overlap).

---------------------------------------------------------------------------- */
typedef struct _class_format2
{
    LF_VECTOR    ClassRangeRecord;                // Array of ClassRangeRecords-ordered by Start GlyphID

} class_format2;


typedef struct _class_def
{
    USHORT               ClassFormat;            // original read in class format

    LF_VECTOR            MapGlyph;               // vector of class_map*'s General class definition collection.  In sequence as it was read in.
    ULONG                Size;                   // the smaller size
    ULONG                Count;

    union _class_format
    {
        class_format1 format_1;
        class_format2 format_2;
    } class_format;


    // original read in format
    USHORT               ReadFormat;
    size_t               ReadSize;
    ULONG                TotalCount;

    USHORT              MaxClassValue;          // maximum class value in the class definition structure.
    USHORT              DirtyClassValue;        // if TRUE, then MaxClassValue may be invalid.

#ifdef OPTIMIZED_LOOKUP
    // organized search collections
    LF_MAP              ClassGlyphMap;
    LF_VECTOR           ClassIDArray;
    LF_VECTOR           ClassIDRemap;
#endif
} class_def;


LF_ERROR    ClassDef_readTable(class_def* table, LF_STREAM* stream);
LF_ERROR    ClassDef_getTableSize(class_def* table, size_t* tableSize);
LF_ERROR    ClassDef_buildTable(class_def* table, LF_STREAM* stream);
void        ClassDef_freeTable(class_def* table);
LF_ERROR    ClassDef_removeGlyph(class_def* cd, GlyphID glyphid, USHORT* remove);
LF_ERROR    ClassDef_remapGlyphs(class_def* cd, LF_MAP *glyphIndexMap);
LF_ERROR    ClassDef_readEmptyOrClassDefinition(class_def* cd, USHORT limit, ULONG classOffset, ULONG baseOffset, LF_STREAM* stream);
LF_ERROR    ClassDef_isClassFormatReferenced(class_def* cd, USHORT classid);

#define     ClassDef_isTableEmpty(cd) (((cd)->TotalCount == 0) ? TRUE : FALSE)
LF_ERROR    ClassDef_isClassReferenced(class_def* cd, USHORT classid);
ULONG       ClassDef_getMaxClass(class_def* cd);
LF_VECTOR*  ClassDef_getGlyphsByClass(class_def* cd, USHORT classref);
LF_ERROR    ClassDef_removeClassID(class_def* cd, USHORT refClass, SHORT deltaIndex);
USHORT      ClassDef_getCount(class_def* cd);

// functions that determine the smallest usable format ...
LF_ERROR    ClassDef_buildTableFormat(class_def* table, LF_STREAM* stream);
LF_ERROR    ClassDef_sizeTableFormat(class_def* table, size_t* tableSize);

LF_ERROR    ClassDef_classExists(class_def* cd, TABLE_HANDLE keepList, USHORT classID);
LF_ERROR    ClassDef_classesExists(class_def* cd, TABLE_HANDLE keepList, USHORT startClassID, LF_VECTOR* classIDs);

#ifdef LF_OT_DUMP
void        ClassDef_dump(class_def* cd);
#endif

#ifdef __cplusplus
}
#endif

#endif //__CDEF_TABLE_H__
