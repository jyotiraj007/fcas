// Copyright (C) 2014 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// gsub_chaining_context.h

#ifndef __GSUB_LOOKUP_CHAINING_CONTEXT_H__
#define __GSUB_LOOKUP_CHAINING_CONTEXT_H__

#include "data_types.h"
#include "offset_table_sfnt.h"
#include "lf_vector.h"
#include "classdef.h"
#include "base_table.h"

#ifdef __cplusplus
extern "C" {
#endif

/* ----------------------------------------------------------------------------
    @description

---------------------------------------------------------------------------- */
typedef struct __chain_subclass_rule__
{
    uint16       BacktrackGlyphCount;        // Total number of glyphs in the backtrack sequence (number of glyphs to be matched before the first glyph)
    LF_VECTOR    Backtrack;                  // [BacktrackGlyphCount] Array of backtracking classes(to be matched before the input sequence)
    
    uint16       InputGlyphCount;            // Total number of classes in the input sequence (includes the first class)
    LF_VECTOR    Input;                      // [InputGlyphCount - 1] Array of input classes(start with second class; to be matched with the input glyph sequence)
    
    uint16       LookaheadGlyphCount;        // Total number of classes in the look ahead sequence (number of classes to be matched after the input sequence)
    LF_VECTOR    LookAhead;                  // [LookAheadGlyphCount]    Array of lookahead classes(to be matched after the input sequence)
    
    uint16       SubstCount;                 // Number of SubstLookupRecords
    LF_VECTOR    SubstLookupRecord;          // [SubstCount]    Array of SubstLookupRecords (in design order)

} gsub_chain_subclass_rule;


/* ----------------------------------------------------------------------------
    @description
        Each ChainSubClassSet table has a count and a collection
        of ChainSubClassRule structures.
---------------------------------------------------------------------------- */
typedef struct __chain_subclass_set__
{
    USHORT           ChainSubClassRuleCnt;
    LF_VECTOR        ChainSubClassRule;

} gsub_chain_subclass_set;

typedef struct __gsub_chain_context_format1__
{
    coverage_table    Coverage;
    USHORT            ChainSubRuleSetCount;
    LF_VECTOR         ChainSubRuleSet;

} gsub_chain_context_format1;


typedef struct __gsub_chain_context_format2__
{
    coverage_table        Coverage;

    class_def            BacktrackClassDef;          // Offset to glyph ClassDef table containing backtrack sequence data-from beginning of Substitution table
    class_def            InputClassDef;              // Offset to glyph ClassDef table containing input sequence data-from beginning of Substitution table
    class_def            LookaheadClassDef;          // Offset to glyph ClassDef table containing lookahead sequence data-from beginning of Substitution table
    USHORT               ChainSubClassSetCnt;        // Number of ChainSubClassSet tables
    LF_VECTOR            ChainSubClassSet;           // [ChainSubClassSetCnt] Array of offsets to ChainSubClassSet tables-from beginning of Substitution table-ordered by input class-may be NULL

} gsub_chain_context_format2;


typedef struct __gsub_chain_context_format3__
{
    USHORT       BacktrackGlyphCount;            // Number of glyphs in the backtracking sequence
    LF_VECTOR    BacktrackGlyphCoverage;         // [BacktrackGlyphCount]    Array of offsets to coverage tables in backtracking sequence, in glyph sequence order

    USHORT       InputGlyphCount;                //    Number of glyphs in input sequence
    LF_VECTOR    InputGlyphCoverage;             // [InputGlyphCount]    Array of offsets to coverage tables in input sequence, in glyph sequence order

    USHORT       LookaheadGlyphCount;            // Number of glyphs in lookahead sequence
    LF_VECTOR    LookaheadGlyphCoverage;         // [LookaheadGlyphCount]    Array of offsets to coverage tables in lookahead sequence, in glyph sequence order

    USHORT       SubstCount;                     // Number of SubstLookupRecords
    LF_VECTOR    SubstLookupRecord;              // [SubstCount]    Array of SubstLookupRecords, in design order

} gsub_chain_context_format3;

typedef struct __gsub_chain_context_substitution__
{
    base_table        Base;
    USHORT            SubstFormat;

    union
    {
        gsub_chain_context_format1        ccf1;
        gsub_chain_context_format2        ccf2;
        gsub_chain_context_format3        ccf3;
    } ccs;

} gsub_chain_context_substitution;


TABLE_HANDLE    GSUB_readChainContextSubst(LF_STREAM* stream);
size_t          GSUB_buildChainContextSubst(gsub_chain_context_substitution* ccs, LF_STREAM* stream);
size_t          GSUB_sizeChainContextSubst(gsub_chain_context_substitution* ccs);
void            GSUB_freeChainContextSubst(gsub_chain_context_substitution* ccs);
LF_ERROR        GSUB_removeChainContextSubst(gsub_chain_context_substitution* ccs, GlyphID glyphid);
LF_ERROR        GSUB_removeChainContextSubstLookupIndex(gsub_chain_context_substitution* table, USHORT refIndex, SHORT deltaIndex);    

LF_ERROR        GSUB_pruneChainContextSubstLookupRecords(gsub_chain_context_substitution* ccs);
LF_ERROR        GSUB_remapChainContextGlyphs(gsub_chain_context_substitution* ccs, LF_MAP* remap);
LF_ERROR        GSUB_cleanupChainContextLookups(gsub_chain_context_substitution* ccs, TABLE_HANDLE hLookup);
LF_ERROR        GSUB_collectChainContextGlyphs(GlyphList* keepList, TABLE_HANDLE hTable, gsub_chain_context_substitution* ccs);

#ifdef LF_OT_DUMP
void            GSUB_dumpChainContext(gsub_chain_context_substitution* ccs);
#endif

#ifdef __cplusplus
}
#endif

#endif    // end of __GSUB_LOOKUP_CHAINING_CONTEXT_H__
