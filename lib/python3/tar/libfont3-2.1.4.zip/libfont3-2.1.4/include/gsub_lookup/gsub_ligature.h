// Copyright (C) 2014 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// gsub_ligature.h

#ifndef __GSUB_LOOKUP_LIGATURE_H__
#define __GSUB_LOOKUP_LIGATURE_H__

#include "data_types.h"
#include "offset_table_sfnt.h"
#include "utils.h"
#include "coverage_table.h"
#include "base_table.h"

#ifdef __cplusplus
extern "C" {
#endif

/* ----------------------------------------------------------------------------
    @summary
        Glyph components for one ligature

        For each ligature in the set, a Ligature table specifies the GlyphID
        of the output ligature glyph (LigGlyph); a count of the total number
        of component glyphs in the ligature, including the first component
        (CompCount); and an array of GlyphIDs for the components (Component).
        The array starts with the second component glyph (array index = 1)
        in the ligature because the first component glyph is specified in
        the Coverage table.

    @note
        The Component array lists GlyphIDs according to the writing direction
        of the text. For text written right to left, the right-most glyph
        will be first. Conversely, for text written left to right, the
        left-most glyph will be first.

---------------------------------------------------------------------------- */
typedef struct _gsub_ligature_table_
{
    GlyphID          LigGlyph;                        // GlyphID of ligature to substitute
    USHORT           CompCount;                       // Number of components in the ligature

    LF_VECTOR        Component;                       // Array of component GlyphIDs - start
                                                      // the second component-ordered in
                                                      // writing direction

    GlyphID          minComponent;                    // the minimum glyph ID in the component vector
    GlyphID          maxComponent;                    // the maximum glyph ID in the component 

} gsub_ligature_table;


/* ----------------------------------------------------------------------------
    @summary
        All ligatures beginning with the same glyph.

        A LigatureSet table, one for each covered glyph, specifies all the 
        ligature strings that begin with the covered glyph. For example, if 
        the Coverage table lists the glyph index for a lowercase "f," then a 
        LigatureSet table will define the "ffl," "fl," "ffi," "fi," and "ff" 
        ligatures. If the Coverage table also lists the glyph index for a 
        lowercase "e," then a different LigatureSet table will define the 
        "etc" ligature.

        A LigatureSet table consists of a count of the ligatures that begin 
        with the covered glyph (LigatureCount) and an array of offsets to 
        Ligature tables, which define the glyphs in each ligature (Ligature). 
        The order in the Ligature offset array defines the preference for 
        using the ligatures. For example, if the "ffl" ligature is preferable 
        to the "ff" ligature, then the Ligature array would list the offset 
        to the "ffl" Ligature table before the offset to the "ff" Ligature 
        table.

---------------------------------------------------------------------------- */
typedef struct _gsub_ligature_set_table_
{
    USHORT                   LigatureCount;         // Number of Ligature Tables

    LF_VECTOR                LigatureList;          // vector to Ligature tables-from
                                                    // beginning of the LigatureSet table-ordered
                                                    // by preference.
} gsub_ligature_set_table;


/* ----------------------------------------------------------------------------
    @brief
        the working substitution structure which is used to allocate
        resources and store them.  this structure is passed around
        the interface when parsing the rules, or lookups.

---------------------------------------------------------------------------- */
typedef struct _gsub_ligature_
{
    base_table               Base;

    USHORT                   SubstFormat;        // format identifier - format is always 1
    coverage_table           Coverage;           // The Coverage Table
    LF_VECTOR                LigatureSetList;    // vector of Ligature Set tables from
                                                 // beginning of Substitution table ordered
                                                 // by Coverage Index.
} gsub_ligature;


TABLE_HANDLE    GSUB_readLigatureSubst( LF_STREAM* stream);
size_t          GSUB_buildLigatureSubst(gsub_ligature* lig, LF_STREAM* stream);
size_t          GSUB_getLigatureSubstSize(gsub_ligature* lig);
LF_ERROR        GSUB_getMaxComponentCount(gsub_ligature* lig, USHORT* max);
void            GSUB_freeLigatureSubst(gsub_ligature* lig);
LF_ERROR        GSUB_removeLigatureGlyphIndex(gsub_ligature* lig, GlyphID glyph);
LF_ERROR        GSUB_remapLigatureSubstGlyphs(gsub_ligature* lig, LF_MAP* remap);
LF_ERROR        GSUB_keepLigSubstGlyphs(gsub_ligature* lig, GlyphList* keepList);

#ifdef LF_OT_DUMP
void            GSUB_dumpLigatureSubst(gsub_ligature* lig);
#endif

#ifdef __cplusplus
}
#endif

#endif    // end of __GSUB_LOOKUP_LIGATURE_H__
