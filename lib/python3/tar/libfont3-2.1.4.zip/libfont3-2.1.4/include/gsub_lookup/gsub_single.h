// Copyright (C) 2014 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// gsub_single.h


/* ============================================================================
    @summary
        Single substitution (SingleSubst) subtables tell a client to replace a
        single glyph with another glyph. The subtables can be either of two
        formats. Both formats require two distinct sets of glyph indices: one
        that defines input glyphs (specified in the Coverage table), and one
        that defines the output glyphs. Format 1 requires less space than
        Format 2, but it is less flexible.

============================================================================ */
#ifndef __GSUB_LOOKUP_SINGLE_H__
#define __GSUB_LOOKUP_SINGLE_H__

#include "data_types.h"
#include "offset_table_sfnt.h"
#include "utils.h"
#include "coverage_table.h"
#include "base_table.h"

#ifdef __cplusplus
extern "C" {
#endif

/* ----------------------------------------------------------------------------
    @summary
        Format 1 calculates the indices of the output glyphs, which are not
        explicitly defined in the subtable. To calculate an output glyph
        index, Format 1 adds a constant delta value to the input glyph index.
        For the substitutions to occur properly, the glyph indices in the
        input and output ranges must be in the same order. This format does
        not use the Coverage Index that is returned from the Coverage table.

        The SingleSubstFormat1 subtable begins with a format identifier
        (SubstFormat) of 1. An offset references a Coverage table that specifies
        the indices of the input glyphs. DeltaGlyphID is the constant value
        added to each input glyph index to calculate the index of the
        corresponding output glyph.

        Format Identifier = 1
---------------------------------------------------------------------------- */
typedef struct _gsub_single_substitution_1
{
    SHORT                DeltaGlyphID;        // Add to original GlyphID to get substitute GlyphID                
} gsub_single_substitution_1;


/* ----------------------------------------------------------------------------
    @summary
        Format 2 is more flexible than Format 1, but requires more space. It 
        provides an array of output glyph indices (Substitute) explicitly 
        matched to the input glyph indices specified in the Coverage table.

        The SingleSubstFormat2 subtable specifies a format identifier 
        (SubstFormat), an offset to a Coverage table that defines the input 
        glyph indices, a count of output glyph indices in the Substitute 
        array (GlyphCount), and a list of the output glyph indices in the 
        Substitute array (Substitute).

        The Substitute array must contain the same number of glyph indices as 
        the Coverage table. To locate the corresponding output glyph index in 
        the Substitute array, this format uses the Coverage Index returned 
        from the Coverage table.

        Format Identifier = 2
---------------------------------------------------------------------------- */
typedef struct _gsub_single_substitution_2
{
    LF_VECTOR            Substitute;
} gsub_single_substitution_2;


/* ----------------------------------------------------------------------------
    @summary
        a runtime instance of the single substitution structure.  This is
        used when reading in the stream.

---------------------------------------------------------------------------- */
typedef struct _gsub_single_substitution
{
    base_table                        Base;           // the parent class for GSUB rules

    USHORT                            SubstFormat;    // single substitution format
    coverage_table                    Coverage;       // pointer to the coverage table

    union
    {
        gsub_single_substitution_1    f1;             // single substitution format 1
        gsub_single_substitution_2    f2;             // single substitution format 2
    } format;
} gsub_single_substitution;


TABLE_HANDLE    GSUB_readSingleSubst(LF_STREAM* stream);
size_t          GSUB_buildSingleSubstitution(gsub_single_substitution* table, LF_STREAM* stream);
size_t          GSUB_getSingleSubstitutionSize(gsub_single_substitution* table);
void            GSUB_freeSingleSubst(gsub_single_substitution* table);
LF_ERROR        GSUB_removeGlyphIndex(gsub_single_substitution* ss, GlyphID index);
LF_ERROR        GSUB_remapSingleSubstGlyphs(gsub_single_substitution* ss, LF_MAP* remap);
LF_ERROR        GSUB_keepSingleSubstGlyphs(gsub_single_substitution* ss, GlyphList* keepList);

#ifdef LF_OT_DUMP
void            GSUB_dumpSingleSubst(gsub_single_substitution* ss);
#endif

#ifdef __cplusplus
}
#endif

#endif //__GSUB_LOOKUP_SINGLE_H__
