// Copyright (C) 2014 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// gsub_context.h


#ifndef __GSUB_LOOKUP_CONTEXT_H__
#define __GSUB_LOOKUP_CONTEXT_H__

#include "data_types.h"
#include "offset_table_sfnt.h"
#include "utils.h"
#include "coverage_table.h"
#include "base_table.h"
#include "classdef.h"

#include "class_set.h"
#include "class_rule.h"

#include "context_set.h"
#include "context_rule.h"

#ifdef __cplusplus
extern "C" {
#endif

/* ----------------------------------------------------------------------------
    A SubRule table consists of a count of the glyphs to be matched in the 
    input context sequence (GlyphCount), including the first glyph in the 
    sequence, and an array of glyph indices that describe the context (Input). 
    The Coverage table specifies the index of the first glyph in the context, 
    and the Input array begins with the second glyph (array index = 1) in the 
    context sequence.

    Note: The Input array lists the indices in the order the corresponding 
    glyphs appear in the text. For text written from right to left, the 
    right-most glyph will be first; conversely, for text written from left 
    to right, the left-most glyph will be first.
    
    A SubRule table also contains a count of the substitutions to be 
    performed on the input glyph sequence (SubstCount) and an array of 
    SubstitutionLookupRecords (SubstLookupRecord). Each record specifies a 
    position in the input glyph sequence and a LookupListIndex to the 
    substitution lookup that is applied at that position. The array should 
    list records in design order, or the order the lookups should be applied 
    to the entire glyph sequence.

---------------------------------------------------------------------------- */
typedef struct __gsub_context_subst_f1__
{
    coverage_table   Coverage;                // the coverage table
    LF_VECTOR        SubRuleSet;                // SubRuleSet[RuleCount] - context_rule

} gsub_context_subst_f1;


/* ----------------------------------------------------------------------------
    @description
        format2 describes class-based context substitution.  A specific
        integer, called a class value, must be assigned to each glyph
        component in all context glyph sequences.  Contexts are then
        defined as sequences of glyph class values.

---------------------------------------------------------------------------- */
typedef struct __gsub_context_subst_f2__
{
    coverage_table    Coverage;
    class_def         ClassDef;
    USHORT            SubClassSetCnt;
    LF_VECTOR         SubClassSet;                // Array of offsets to SubClassSet tables.  Offsets
                                                  // that are NULL have no rules applied
} gsub_context_subst_f2;

/* ----------------------------------------------------------------------------
    @description
        Format 3, coverage-based context substitution, defines a context rule 
        as a sequence of coverage tables. Each position in the sequence may 
        define a different Coverage table for the set of glyphs that matches 
        the context pattern. With Format 3, the glyph sets defined in the 
        different Coverage tables may intersect, unlike Format 2 which 
        specifies fixed class assignments (identical for each position in 
        the context sequence) and exclusive classes (a glyph cannot be in 
        more than one class at a time).

---------------------------------------------------------------------------- */
typedef struct __gsub_context_subst_f3__
{
    USHORT           GlyphCount;                    // number of glyphs in the input glyph sequence
    USHORT           SubstCount;                    // Number of SubstLookup Records in the array

    LF_VECTOR        Coverage;                      // Array of Coverage tables-from beginning of 
                                                    // substitution table-in glyph sequence order
    
    LF_VECTOR        SubstLookupRecord;             // Array of SubstLookup Records-in design order

} gsub_context_subst_f3;


typedef struct
{
    base_table        Base;
    USHORT            SubstFormat;                // 1, 2, or 3

    union
    {
        gsub_context_subst_f1        csf1;
        gsub_context_subst_f2        csf2;
        gsub_context_subst_f3        csf3;
    } csf;

} gsub_context_substitution;

TABLE_HANDLE    GSUB_readContextSubst(LF_STREAM* stream);
size_t          GSUB_buildContextSubst(gsub_context_substitution* cs, LF_STREAM* stream);
size_t          GSUB_getContextSubstSize(gsub_context_substitution* cs);
void            GSUB_freeContextSubst(gsub_context_substitution* cs);
LF_ERROR        GSUB_removeContextGlyphIndex(gsub_context_substitution* cs, GlyphID glyphid);
LF_ERROR        GSUB_removeContextSubstLookupIndex(gsub_context_substitution* table, USHORT refIndex, SHORT deltaIndex);
LF_ERROR        GSUB_pruneContextSubstLookupRecords(gsub_context_substitution* cs);

LF_ERROR        GSUB_remapContextSubstGlyphs(gsub_context_substitution* cs, LF_MAP* remap);
#ifdef LF_OT_DUMP
void            GSUB_dumpContextSubst(gsub_context_substitution* cs);
#endif
LF_ERROR        GSUB_cleanupContextLookups(gsub_context_substitution* cs, TABLE_HANDLE hLookup);
LF_ERROR        GSUB_collectContextSubstGlyphs(GlyphList* keepList, TABLE_HANDLE hTable, gsub_context_substitution* table);


#ifdef __cplusplus
}
#endif

#endif    // end of __GSUB_LOOKUP_CONTEXT_H__
