#ifndef __GSUB_BASE_H__
#define __GSUB_BASE_H__

#include "data_types.h"
#include "offset_table.h"
#include "lf_core.h"
#include "common_table.h"

#ifdef __cplusplus
extern "C" {
#endif


/* ----------------------------------------------------------------------------
	@summary

---------------------------------------------------------------------------- */
typedef enum __base_subtable_types__
{
	SUBTABLE_TYPE_GSUB_SINGLE,
	SUBTABLE_TYPE_GSUB_MULTIPLE,
	SUBTABLE_TYPE_GSUB_ALTERNATE,
	SUBTABLE_TYPE_GSUB_LIGATURE,
	SUBTABLE_TYPE_GSUB_CONTEXT,
	SUBTABLE_TYPE_GSUB_EXTENSION,
	SUBTABLE_TYPE_GSUB_REVERSE_CHAIN,

	SUBTABLE_TYPE_GPOS_SINGLE,
	SUBTABLE_TYPE_GPOS_PAIR,
	SUBTABLE_TYPE_GPOS_CURSIVE,
	SUBTABLE_TYPE_GPOS_MARK_TO_BASE,
	SUBTABLE_TYPE_GPOS_MARK_TO_LIGATURE,
	SUBTABLE_TYPE_GPOS_MARK_TO_MARK,
	SUBTABLE_TYPE_GPOS_CONTEXT,
	SUBTABLE_TYPE_GPOS_CHAINED_CONTEXT,
	SUBTABLE_TYPE_GPOS_EXTENSION,

} eBaseSubTableTypes;



typedef enum __base_table_types__
{
	TABLETYPE_GPOS,
	TABLETYPE_GSUB,
	TABLETYPE_FEATURE,
	TABLETYPE_SCRIPT,
	TABLETYPE_LOOKUP,

} eBaseTableTypes;

/* ----------------------------------------------------------------------------
	@summary
		This structure is used as a parent structure to all of the
		GPOS/GSUB rules.  It can be used as a working structure that
		is common to all of the rules and build associations between
		the different rules.

		An example would be to link the different tables together such
		as a context rule may use several lookup records which are attached
		to that context rule.  however those rules in the lookup records 
		are not associated with the feature table and therefore we can 
		build the relationship of those rules to be only with the context
		rule.
---------------------------------------------------------------------------- */
typedef struct __gsub_base__
{
	LF_FONT*					font;					// pointer to LF_FONT
	GlyphList*					list_glyphs;			// stores off keepList pointer

	eBaseTableTypes				type;					// type of structure
	eBaseSubTableTypes			subType;				// subtype of structure

	eBaseTableTypes				parentType;
	struct __gsub_base__*		parent;					// parent table - null if no parent

	LF_VECTOR*					children;				// children associated with this
														// table. vector of pointers to
														// BaseTable structures.

	USHORT						dump;

} gsub_base;



void			GSUB_initBase(LF_FONT* font, TABLE_HANDLE gsub);

GlyphList*		BaseTable_getKeepList(TABLE_HANDLE base);
void			BaseTable_setKeepList(TABLE_HANDLE table, GlyphList* list);


#ifdef __cplusplus
}
#endif


#endif // __GSUB_BASE_H__

