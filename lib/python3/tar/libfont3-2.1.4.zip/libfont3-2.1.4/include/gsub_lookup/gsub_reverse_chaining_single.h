// Copyright (C) 2014 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// gsub_reverse_chaining_single.h


#ifndef __GSUB_LOOKUP_REVERSE_CHAINING_SINGLE_H__
#define __GSUB_LOOKUP_REVERSE_CHAINING_SINGLE_H__

#include "data_types.h"
#include "offset_table_sfnt.h"
#include "lf_vector.h"
#include "coverage_table.h"
#include "base_table.h"

#ifdef __cplusplus
extern "C" {
#endif

typedef struct __gsub_reverse_chain_single_substitution__
{
    base_table        Base;
    USHORT            SubstFormat;
    coverage_table    Coverage;

    USHORT            BacktrackGlyphCount;
    LF_VECTOR         BacktrackGlyphCoverage;

    USHORT            LookaheadGlyphCount;
    LF_VECTOR         LookaheadGlyphCoverage;

    USHORT            GlyphCount;
    LF_VECTOR         Substitute;

} gsub_reverse_chain_single_substitution;


TABLE_HANDLE    GSUB_readReverseChainSingleSubst(LF_STREAM* stream);
size_t          GSUB_buildReverseChainSingleSubst(gsub_reverse_chain_single_substitution* rcs, LF_STREAM* stream);
size_t          GSUB_sizeReverseChainSingleSubst(gsub_reverse_chain_single_substitution* rcs);
void            GSUB_freeReverseChainSingleSubst(gsub_reverse_chain_single_substitution* rcs);
LF_ERROR        GSUB_removeReverseChainSingleSubst(gsub_reverse_chain_single_substitution* rcs, GlyphID glyphid);
LF_ERROR        GSUB_removeReverseChainSingleSubstLookupIndex(gsub_reverse_chain_single_substitution* table, USHORT refIndex, SHORT deltaIndex);
LF_ERROR        GSUB_remapReverseChainSingleSubstGlyphs(gsub_reverse_chain_single_substitution* ss, LF_MAP* remap);

#ifdef __cplusplus
}
#endif

#endif    // end of __GSUB_LOOKUP_REVERSE_CHAINING_SINGLE_H__
