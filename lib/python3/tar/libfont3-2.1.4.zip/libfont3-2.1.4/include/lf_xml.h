// Copyright (C) 2014 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// lf_xml.h

#include "data_types.h"
#include "lf_error.h"
#include "stream.h"

#ifndef __LF_XML_H__
#define __LF_XML_H__

#ifdef __cplusplus
extern "C" {
#endif

#define XML_DECLARATION_FORMAT              "<?xml version=\"%s\" encoding=\"%s\"?>\n"
#define XML_DOCUMENT_TYPE_FORMAT            "<!DOCTYPE %s PUBLIC %s %s>\n"

#define XML_VERSION_10                      "1.0"

#define XML_PROCESSING_INSTRUCTION_START    "<?"
#define XML_PROCESSING_INSTRUCTION_END      "?>"
#define XML_DOCTYPE_START                   "<!"
#define XML_CLOSE_TAG_NO_CHILDREN           " />"
#define XML_END_TAG                         "</"
#define XML_CDATA_BEGIN                     "<![CDATA["
#define XML_CDATA_END                       "]]>"

#define XML_PREFIX                          "xml"
#define XMLNS_PREFIX                        "xmlns"
#define XML_DOCTYPE_NAME                    "DOCTYPE"
#define XML_PUBLIC_ID_NAME                  "PUBLIC"

#define XML_SPACE                           ' '
#define XML_EQUAL_SIGN                      '='
#define XML_CHAR_QUOTE                      '\"'
#define XML_CHAR_LT                         '<'
#define XML_CHAR_GT                         '>'
#define XML_NEWLINE                         '\n'
#define XML_CHAR_APOS                       '\''
#define XML_CHAR_AMP                        '&'
#define XML_CHAR_COMMA                      ','
#define XML_CHAR_SEMICOLON                  ';'

#define XML_ENCODING                        "UTF-8"
#define XML_VERSION_ATTRIBUTE               "version"
#define XML_ENCODING_ATTRIBUTE              "encoding"
#define XML_ID_ATTRIBUTE                    "id"

#define XML_CHAR_REF_PREFIX                 "&#x"

#define XML_ENTITY_QUOT                     "&quot;"
#define XML_ENTITY_LT                       "&lt;"
#define XML_ENTITY_GT                       "&gt;"
#define XML_ENTITY_APOS                     "&apos;"
#define XML_ENTITY_AMP                      "&amp;"
#define XML_ENTITY_COMMA                    "&#x2c;"

#define XML_DECL_SIZE(ver, enc, stand)          (8 + strlen(ver) + strlen(enc) + strlen(stand))
#define XML_DOCTYPE_SIZE(name, pubid, sysid)    (21 + strlen(name) + strlen(pubid)+ strlen(sysid))
#define XML_ATTR_SIZE(attr, value)              (4 + strlen(attr) + strlen(value))
#define XML_STARTAG_SIZE(name, newline)         (2 + strlen(name) + (newline ? 1 : 0))
#define XML_ENDTAG_SIZE(name)                   (4 + strlen(name))

LF_ERROR XML_WriteStartTag(LF_STREAM* stream, const char* name, boolean newLine, size_t* size);
LF_ERROR XML_WriteEndTag(LF_STREAM* stream, const char* name, size_t* size);
LF_ERROR XML_WriteAttribute(LF_STREAM* stream, const char* attribute, const char* value, size_t* size);
LF_ERROR XML_WriteXMLDeclaration(LF_STREAM* stream, const char* version, const char* encoding, const char* standalone, size_t* size);
LF_ERROR XML_WriteXMLDocumentType(LF_STREAM* stream, const char* name, const char* publicID, const char* systemID, size_t* size);

#ifdef __cplusplus
}
#endif

#endif //__LF_XML_H__
