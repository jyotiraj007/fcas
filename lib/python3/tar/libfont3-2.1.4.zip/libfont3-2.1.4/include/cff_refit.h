// Copyright (C) 2015 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// cff_refit.h

#ifndef __CFF_REFIT_H__
#define __CFF_REFIT_H__

#include "lf_core.h"
#include "lf_refit.h"

LF_ERROR cff_refit(LF_FONT* lfFont, float fitTolerance, boolean replaceAll, refitCBInfo* progressCB);

#endif // __CFF_REFIT_H__
