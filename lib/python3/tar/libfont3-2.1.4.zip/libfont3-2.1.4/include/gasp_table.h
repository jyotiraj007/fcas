// Copyright (C) 2014 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// gasp_table.h

#ifndef __GASP_TABLE_H__
#define __GASP_TABLE_H__

#include <stdio.h>
#include "data_types.h"
#include "lf_core.h"
#include "stream.h"
#include "offset_table_sfnt.h"

#ifdef __cplusplus
extern "C" {
#endif


#if 0 // The below functions are not yet implemented/used
#define GASP_DOGRAY                 0x0002    //Use grayscale rendering
#define GASP_GRIDFIT                0x0001    //Use gridfitting
#define GASP_SYMMETRIC_SMOOTHING    0x0008    //Use smoothing along multiple axes with ClearType� 
                                              //Only supported in version 1 gasp
#define GASP_SYMMETRIC_GRIDFIT      0x0004    //Use gridfitting with ClearType symmetric smoothing 
                                              //Only supported in version 1 gasp
struct gasp_range
{
    USHORT    rangeMaxPPEM;         //Upper limit of range, in PPEM
    USHORT    rangeGaspBehavior;    //Flags describing desired rasterizer behavior.
};

struct gasp_header
{
    USHORT               version;         //Version number (set to 1)
    USHORT               numRanges;       //Number of records to follow
    struct gasp_range    gaspRange[1];    //Sorted by ppem
};

LF_ERROR    GASP_readTable(LF_FONT* lfFont, const sfnt_table_record* record, LF_STREAM* stream);
LF_ERROR    GASP_getTableSize(LF_FONT* lfFont, size_t* tableSize);
LF_ERROR    GASP_writeTable(LF_FONT* lfFont, sfnt_table_record* record, LF_STREAM* stream);
LF_ERROR    GASP_freeTable(LF_FONT* lfFont, const sfnt_table_record* record);
#endif

#ifdef __cplusplus
}
#endif

#endif //__GASP_TABLE_H__
