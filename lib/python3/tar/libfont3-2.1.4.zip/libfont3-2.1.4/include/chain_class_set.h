// Copyright (C) 2014 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// chain_class_set.h

#include "data_types.h"
#include "stream.h"
#include "lf_error.h"
#include "lf_vector.h"
#include "coverage_table.h"
#include "classdef.h"
#include "chain_class_rule.h"

#ifndef __CHAIN_CLASS_SET_H__
#define __CHAIN_CLASS_SET_H__

#ifdef __cplusplus
extern "C" {
#endif

/* ----------------------------------------------------------------------------
    @description
        Each ChainSubClassSet table has a count and a collection
        of ChainSubClassRule structures.
---------------------------------------------------------------------------- */
typedef struct __chain_class_set__
{
    USHORT           InputClass;
    USHORT           InputClassDefined;
    USHORT           ChainClassRuleCount;
    LF_VECTOR        ChainClassRule;

} chain_class_set;


LF_ERROR    ChainClassSets_readSets(class_def* input, class_def* backtrack, class_def* lookahead, 
                                    LF_VECTOR* ccss, USHORT count, LF_STREAM* stream, ULONG baseOffset);
void        ChainClassSets_freeSets(LF_VECTOR* ccss);
size_t      ChainClassSets_sizeSets(LF_VECTOR* ccss);
LF_ERROR    ChainClassSets_removeLookupRecordIndex(LF_VECTOR* ccss, USHORT lookupIndex, SHORT deltaIndex);
size_t      ChainClassSets_buildSets(LF_VECTOR* ccss, LF_STREAM* stream, ULONG baseOffset, ULONG arrayOffset);
LF_ERROR    ChainClassSets_pruneLookupRecords(LF_VECTOR* ccss, context_classes* context);
LF_ERROR    ChainClassSets_validClassRules(LF_VECTOR* ccss);
LF_ERROR    ChainClassSets_removeUnusedClasses(LF_VECTOR* ccss, context_classes* f2);

LF_ERROR    ChainClassSet_readSet(class_def* input, class_def* backtrack, class_def* lookahead, 
                                  chain_class_set* ccs, LF_STREAM* stream);
void        ChainClassSet_freeSet(chain_class_set* ccs);
size_t      ChainClassSet_buildSet(chain_class_set* ccs, LF_STREAM* stream);
size_t      ChainClassSet_sizeSet(chain_class_set* ccs);
LF_ERROR    ChainClassSet_removeLookupRecordIndex(chain_class_set* ccs, USHORT lookupIndex, SHORT deltaIndex);
LF_ERROR    ChainClassSet_pruneLookupRecords(chain_class_set* ccs, context_classes* context);
LF_ERROR    ChainClassSet_validClassRules(chain_class_set* ccs);

void        ChainClassSet_freeValidClasses(context_classes* f2);
LF_ERROR    ChainClassSet_removeUnusedClasses(chain_class_set* ccs, context_classes* context);
LF_ERROR    ChainClassSet_findUnusedClasses(chain_class_set* ccs, context_classes* context);

LF_ERROR    ChainClassSets_cleanupLookups(LF_VECTOR* ccss, TABLE_HANDLE hLookup);
LF_ERROR    ChainClassSets_collectGlyphs(LF_VECTOR* ccss, context_classes* classes, GlyphList* keepList, TABLE_HANDLE hTable);

#ifdef LF_OT_DUMP
void        ChainClassSets_dumpSets(LF_VECTOR* ccss);
void        ChainClassSet_dumpSet(chain_class_set* ccs);
void        ChainClassSet_dumpValidClasses(context_classes* context);
#endif

#ifdef __cplusplus
}
#endif

#endif //__CHAIN_CLASS_SET_H__
