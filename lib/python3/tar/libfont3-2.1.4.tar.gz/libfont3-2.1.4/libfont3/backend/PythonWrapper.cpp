// Copyright(C) 2015, 2016, 2017 Monotype Imaging Inc.All rights reserved.
// Confidential information of Monotype Imaging Inc.
//
// PythonWrapper.cpp

extern "C" {
#include <Python.h>
#include <sys/stat.h>
#include "lf_core.h"
#include "lf_subset.h"
#include "sfnt_core.h"
#include "name_table.h"


/* some macros to make extension code work for both Python2 and 3.
 * See http://python3porting.com/cextensions.html
 */
#if PY_MAJOR_VERSION >= 3
#define MOD_ERROR_VAL NULL
#define MOD_SUCCESS_VAL(val) val
#define MOD_INIT(name) PyMODINIT_FUNC PyInit_##name(void)
#define PY_INT(name) PyLong_##name
#define MOD_DEF(ob, name, doc, methods) \
static struct PyModuleDef moduledef = { \
PyModuleDef_HEAD_INIT, name, doc, -1, methods, }; \
ob = PyModule_Create(&moduledef);
#else
#define MOD_ERROR_VAL
#define MOD_SUCCESS_VAL(val)
#define MOD_INIT(name) void init##name(void)
#define PY_INT(name) PyInt_##name
#define MOD_DEF(ob, name, doc, methods) \
ob = Py_InitModule3(name, methods, doc);
#endif


static PyObject* lfapi_createFont(PyObject* self);
static PyObject* lfapi_destroyFont(PyObject* self, PyObject* args);
static PyObject* lfapi_readFont(PyObject* self, PyObject* args);
static PyObject* lfapi_getFontType(PyObject* self, PyObject* args);
static PyObject* lfapi_getFontFlavor(PyObject* self, PyObject* args);
static PyObject* lfapi_subsetFont(PyObject* self, PyObject* args, PyObject* keywds);
static PyObject* lfapi_writeFont(PyObject* self, PyObject* args, PyObject* keywds);
static PyObject* lfapi_writeFontToMemory(PyObject* self, PyObject* args, PyObject* keywds);
static PyObject* lfapi_writeCSSFile(PyObject* self, PyObject* args, PyObject* keywds);
static PyObject* sfnt_unpack(PyObject* self, PyObject* args);
static PyObject* name_getString(PyObject* self, PyObject* args);


static PyMethodDef LibFontMethods[] = {
    {"lfapi_createFont",           (PyCFunction)lfapi_createFont,           METH_NOARGS,  NULL },
    {"lfapi_destroyFont",                       lfapi_destroyFont,          METH_VARARGS, NULL },
    {"lfapi_readFont",                          lfapi_readFont,             METH_VARARGS, NULL },
    {"lfapi_getFontType",                       lfapi_getFontType,          METH_VARARGS, NULL },
    {"lfapi_getFontFlavor",                     lfapi_getFontFlavor,        METH_VARARGS, NULL },    
    {"lfapi_writeFont",            (PyCFunction)lfapi_writeFont,            METH_VARARGS | METH_KEYWORDS, NULL },
    {"lfapi_writeFontToMemory",    (PyCFunction)lfapi_writeFontToMemory,    METH_VARARGS | METH_KEYWORDS, NULL },
    {"lfapi_subsetFont",           (PyCFunction)lfapi_subsetFont,           METH_VARARGS | METH_KEYWORDS, NULL },
    {"lfapi_writeCSSFile",         (PyCFunction)lfapi_writeCSSFile,         METH_VARARGS | METH_KEYWORDS, NULL },
    {"sfnt_unpack",                             sfnt_unpack,                METH_VARARGS, NULL },
    {"name_getString",                          name_getString,             METH_VARARGS, NULL },
    {NULL, NULL, 0, NULL}
};

// Creates an LF_FONT object
// Returns:
//      handle to an LF_FONT
static PyObject* lfapi_createFont(PyObject* self)
{
    LF_FONT* font = LF_createFont();

    return PyLong_FromVoidPtr(font);
}

// Destroys an LF_FONT object
// Expected args:
//      font handle
// Returns:
//      on success: 0 (integer)
//      on failure: (integer) - -1 if parse error; or an LF_ERROR code
static PyObject* lfapi_destroyFont(PyObject* self, PyObject* args)
{
    PyObject *python_handle;

    int ok = PyArg_ParseTuple(args, "O", &python_handle);
    if (!ok)
        return Py_BuildValue("i", -1);

    LF_FONT* font = (LF_FONT*)PyLong_AsVoidPtr(python_handle);

    if (font == NULL)
        return Py_BuildValue("i", LF_INVALID_PARAM);

    LF_ERROR error = LF_destroyFont(font);

    return Py_BuildValue("i", error);
}

// Reads a font into an LF_FONT object
// Expected args:
//      font handle, path to font (string), boolean flag - true to preserve all tables
// Returns:
//      on success: 0 (integer)
//      on failure: (integer) - -1 if parse error; or an LF_ERROR code
static PyObject* lfapi_readFont(PyObject* self, PyObject* args)
{
    PyObject *python_handle;
    char *filename;
    int keepAll = 0;

    int ok = PyArg_ParseTuple(args, "Osi", &python_handle, &filename, &keepAll);
    if (!ok)
        return Py_BuildValue("i", -1);

    LF_FONT* lfFont = (LF_FONT*)PyLong_AsVoidPtr(python_handle);
    if (lfFont == NULL)
        return Py_BuildValue("i", LF_INVALID_PARAM);

    LF_ERROR error = LF_readFontFromFile(lfFont, filename, keepAll==0 ? LF_KEEP_DEFAULT_TABLES : LF_KEEP_ALL_TABLES);
    return Py_BuildValue("i", error);
}


// Returns the type of the font.
// Expected args:
//      font handle
// Returns:
//      on success: a string, one of "TTF", "OTF", "EOT", "WOFF", "WOFF2", "SVG"
//      on failure: -1 (integer) on parse error; LF_ERROR code (integer)
static PyObject* lfapi_getFontType(PyObject* self, PyObject* args)
{
    char *type;
    PyObject *fontObj;

    int ok = PyArg_ParseTuple(args, "O", &fontObj);
    if (!ok)
        return Py_BuildValue("i", -1);

    LF_FONT* lfFont = (LF_FONT*)PyLong_AsVoidPtr(fontObj);

    if (lfFont == NULL)
        return Py_BuildValue("i", LF_INVALID_PARAM);

    switch (lfFont->origType)
    {
        case eLF_UNDETERMINED:
            type = "ERROR";
            break;
        case eLF_SFNT_FONT:
            type = "TTF";
            break;
        case eLF_EOT_FONT:
            type = "EOT";
            break;
        case eLF_WOFF_FONT:
            type = "WOFF";
            break;
        case eLF_WOFF2_FONT:
            type = "WOFF2";
            break;
        case eLF_SVG_FONT:
            type = "SVG";
            break;
        case eLF_CFF_FONT:
            type = "OTF";
            break;
    }

    return Py_BuildValue("s", type);
}


// Returns the flavor of the font as a string.
// Expected args:
//      font handle
// Returns:
//      on success: a string, one of "VERSION1", "VERSION2", "VERSION2.1", 
//      "VERSION2.2", "TRUETYPE", "CFF", "WOFF", "WOFF2", "UNKONWN".
//      on failure: -1 (integer) on parse error; LF_ERROR code (integer)
static PyObject* lfapi_getFontFlavor(PyObject* self, PyObject* args)
{
    char *sig;
    PyObject *fontObj;

    int ok = PyArg_ParseTuple(args, "O", &fontObj);
    if (!ok)
        return Py_BuildValue("i", -1);

    LF_FONT* lfFont = (LF_FONT*)PyLong_AsVoidPtr(fontObj);

    if (lfFont == NULL)
        return Py_BuildValue("i", LF_INVALID_PARAM);

    LF_FONT_TYPE origType;
    ULONG flavor;

    LF_ERROR error = LF_getFontInfo(lfFont, &origType, &flavor);
    if (error != LF_ERROR_OK)
        return Py_BuildValue("i", error);

    switch (flavor)
    {
        case SIG_VERSION1:
            sig = "VERSION1";
            break;
        case SIG_VERSION2:
            sig = "VERSION2";
            break;
        case SIG_VERSION2_1:
            sig = "VERSION2.1";
            break;
        case SIG_VERSION2_2:
            sig = "VERSION2.2";
            break;
        case SIG_TRUETYPE:
            sig = "TRUETYPE";
            break;
        case SIG_CFF:
            sig = "CFF";
            break;
        case SIG_WOFF:
            sig = "WOFF";
            break;
        case SIG_WOFF2:
            sig = "WOFF2";
            break;
        default:
        case SIG_UNKONWN:
            sig = "UNKONWN";
            break;
    }

    return Py_BuildValue("s", sig);
}

// Subsets a font.
// Expected args:
//      font handle, a python list of Unicodes (integers), optional subset params
// Returns:
//      on success: 0 (integer)
//      on failure: -1 if parse error; or an LF_ERROR code (integer)
static PyObject* lfapi_subsetFont(PyObject* self, PyObject* args, PyObject* keywds)
{
    static char *kwlist[] = { "fontplaceholder", "unilistplaceholder", "normalize", NULL };
    PyObject *fontObj;
    PyObject *uniArrayObj;
    int normalize;

    int ok = PyArg_ParseTupleAndKeywords(args, keywds, "OO!|i", kwlist, &fontObj, &PyList_Type, &uniArrayObj, &normalize);
    if (!ok)
    {
        return Py_BuildValue("i", -1);
    }

    ULONG numUnicodes = (ULONG)PyList_Size(uniArrayObj);
    //printf("numUnicodes = %d\n", numUnicodes);

    LF_FONT* lfFont = (LF_FONT*)PyLong_AsVoidPtr(fontObj);
    if (lfFont == NULL)
        return Py_BuildValue("i", LF_INVALID_PARAM);

    ULONG* unicodesBuf = (ULONG*)malloc(numUnicodes * sizeof(ULONG));
    if (unicodesBuf == NULL)
        return Py_BuildValue("i", LF_OUT_OF_MEMORY);

    for (ULONG i = 0; i < numUnicodes; i++)
    {
        PyObject* intObj = PyList_GetItem(uniArrayObj, i); /* Can't fail */

        unicodesBuf[i] = (ULONG)PyLong_AsLong(intObj);
    }

    LF_SUBSET_PARAMS params;
    memset(&params, 0, sizeof(LF_SUBSET_PARAMS));
    params.normalize = normalize ? TRUE : FALSE;
    params.optimize = SUBSET_OPT_REMOVE_EMPTY_LOOKUPS;

    LF_ERROR error = LF_subsetFont(lfFont, unicodesBuf, numUnicodes, &params);

    free(unicodesBuf);

    return Py_BuildValue("i", error);
}

static LF_ERROR processDataFiles(LF_FONT* lfFont, const char *metaPath, const char *privPath)
{
    LF_ERROR error = LF_ERROR_OK;
    struct stat buffer;

    if ((metaPath != NULL) && (0 != strlen(metaPath)))
    {
        if ((strncmp(metaPath, "NULL", 4) == 0) ||
            (strncmp(metaPath, "null", 4) == 0))
        {
            error = LF_clearMetaData(lfFont);
        }
        else
        {
            if (0 == stat(metaPath, &buffer))
            {
                error = LF_setMetaData(lfFont, metaPath);
            }
            else
            {
                error = LF_writeMetaDataFile(lfFont, metaPath);
            }
        }
    }

    if ((privPath != NULL) && (0 != strlen(privPath)))
    {
        if ((strncmp(privPath, "NULL", 4) == 0) ||
            (strncmp(privPath, "null", 4) == 0))
        {
            error = LF_clearPrivateData(lfFont);
        }
        else
        {
            if (0 == stat(privPath, &buffer))
            {
                error = LF_setPrivateData(lfFont, privPath);
            }
            else
            {
                error = LF_writePrivateDataFile(lfFont, privPath);
            }
        }
    }

    return error;
}

// Writes a font
// Expected args:
//      font handle, path to output font, type of font to write, optional output params
// Returns:
//      on success: 0 (integer)
//      on failure: -1 if parsing error, or an LF_ERROR code (integer)
static PyObject* lfapi_writeFont(PyObject* self, PyObject* args, PyObject* keywds)
{
    // Initialize output params to default values.
    LF_WRITE_PARAMS params;
    LF_defaultWriteParams(&params);

    int keepall_ingnored      = 0;
    int normalize_ignored     = 0;
    int force_glyf_loca       = 0;
    int force_cff             = 0;
    int woffCompressionLevel  = (int)params.woffCompressionLevel;
    int woffMinTableSize      = (int)params.woffMinTableSize;
    int woff2CompressionLevel = (int)params.woff2CompressionLevel;
    float conversionTolerance = params.conversionTolerance;
    int postTableVersion      = 0;  // setting to zero preserves original post table version
    int unitsPerEm            = (int)params.unitsPerEm;
    const char *svgID = NULL;
    const char *metaPath = NULL;
    const char *privPath = NULL;

    // parse the inputs
    PyObject *fontObj;
    char *filename;
    int type;

    static char *kwlist[] = { "fontplaceholder", "nameplaceholder", "typeplaceholder",
                              "alltables", "normalize",
                              "sfnt_ttf", "sfnt_cff", "woff", "woffminsize", "woff2",
                              "convtol", "post", "upm",
                              "svgid", "metadata", "privatedata", NULL };

    int ok = PyArg_ParseTupleAndKeywords(args, keywds, "Osi|iiiiiiidiisss", kwlist, &fontObj, &filename, &type,
                                         &keepall_ingnored, &normalize_ignored,
                                         &force_glyf_loca, &force_cff, &woffCompressionLevel,
                                         &woffMinTableSize, &woff2CompressionLevel,
                                         &conversionTolerance, &postTableVersion, &unitsPerEm, &svgID,
                                         &metaPath, &privPath);
    if (!ok)
        return Py_BuildValue("i", -1);

    LF_FONT* lfFont = (LF_FONT*)PyLong_AsVoidPtr(fontObj);
    if (lfFont == NULL)
        return Py_BuildValue("i", LF_INVALID_PARAM);

    params.sfnt_ttf = (boolean)force_glyf_loca;
    params.sfnt_cff = (boolean)force_cff;
    params.woffCompressionLevel = (ULONG)woffCompressionLevel;
    params.woffMinTableSize = (ULONG)woffMinTableSize;
    params.woff2CompressionLevel = (ULONG)woff2CompressionLevel;
    params.conversionTolerance = conversionTolerance;
    params.postTableVersion = (ULONG)postTableVersion;
    params.unitsPerEm = (USHORT)unitsPerEm;
    if (svgID != NULL)
        strcpy(params.svgID, svgID);

    LF_ERROR error = processDataFiles(lfFont, metaPath, privPath);

    if (error == LF_ERROR_OK)
        error = LF_writeFontToFile(lfFont, filename, (LF_FONT_TYPE)type, &params);

    return Py_BuildValue("i", error);
}

// Writes a font to memory
// Expected args:
//      font handle, type of font to write, optional output params
// Returns:
//      on success: a bytestring
//      on failure: -1 if parsing error, or an LF_ERROR code (integer)
static PyObject* lfapi_writeFontToMemory(PyObject* self, PyObject* args, PyObject* keywds)
{
    // Initialize output params to default values.
    LF_WRITE_PARAMS params;
    LF_defaultWriteParams(&params);

    int keepAll_ignored = 0;
    int normalize_ignored = 0;
    int force_glyf_loca = 0;
    int force_cff = 0;    
    int woffCompressionLevel = (int)params.woffCompressionLevel;
    int woffMinTableSize = (int)params.woffMinTableSize;
    int woff2CompressionLevel = (int)params.woff2CompressionLevel;
    float conversionTolerance = params.conversionTolerance;
    int postTableVersion = 0;  // setting to zero preserves original post table version
    int unitsPerEm = (int)params.unitsPerEm;
    const char *svgID = NULL;
    const char *metaPath = NULL;
    const char *privPath = NULL;

    // parse the inputs
    PyObject *fontObj;
    int type;

    static char *kwlist[] = { "fontplaceholder",  "typeplaceholder", "alltables", "normalize",
                              "sfnt_ttf", "sfnt_cff", "woff", "woffminsize",
                              "woff2", "convtol", "post", "upm", "svgid", "metadata", "privatedata", NULL };

    int ok = PyArg_ParseTupleAndKeywords(args, keywds, "Oi|iiiiiiidiisss", kwlist, &fontObj, &type,
                                         &keepAll_ignored, &normalize_ignored,
                                         &force_glyf_loca, &force_cff,
                                         &woffCompressionLevel, &woffMinTableSize, &woff2CompressionLevel,
                                         &conversionTolerance, &postTableVersion, &unitsPerEm, &svgID,
                                         &metaPath, &privPath);
    if (!ok)
        return Py_BuildValue("i", -1);

    LF_FONT* lfFont = (LF_FONT*)PyLong_AsVoidPtr(fontObj);
    if (lfFont == NULL)
        return Py_BuildValue("i", LF_INVALID_PARAM);

    params.sfnt_ttf = (boolean)force_glyf_loca;
    params.sfnt_cff = (boolean)force_cff;
    params.woffCompressionLevel = (ULONG)woffCompressionLevel;
    params.woffMinTableSize = (ULONG)woffMinTableSize;
    params.woff2CompressionLevel = (ULONG)woff2CompressionLevel;
    params.conversionTolerance = conversionTolerance;
    params.postTableVersion = (ULONG)postTableVersion;
    params.unitsPerEm = (USHORT)unitsPerEm;
    if (svgID != NULL)
        strcpy(params.svgID, svgID);

    size_t requiredSize;

    LF_ERROR error = LF_getMaxFontSize(lfFont, (LF_FONT_TYPE)type, &params, &requiredSize);

    if (error != LF_ERROR_OK)
        return Py_BuildValue("i", error);

    BYTE* fontBuf = (BYTE*)malloc(requiredSize * sizeof(BYTE));
    if (fontBuf == NULL)
        return Py_BuildValue("i", LF_OUT_OF_MEMORY);

    error = processDataFiles(lfFont, metaPath, privPath);

    if (error == LF_ERROR_OK)
        error = LF_writeFontToMemory(lfFont, (LF_FONT_TYPE)type, &params, fontBuf, &requiredSize);

    if (error != LF_ERROR_OK)
    {
        free(fontBuf);
        return Py_BuildValue("i", error);
    }

    PyObject* retVal = PyByteArray_FromStringAndSize((const char*)fontBuf, requiredSize);

    free(fontBuf);

    return retVal;
}

static PyObject* lfapi_writeCSSFile(PyObject* self, PyObject* args, PyObject* keywds)
{
    PyObject *fontObj;
    char *base;
    char *cssFilename;

    const char *types = NULL;
    const char *svgID = NULL;
    const char *userbase = NULL;

    static char *kwlist[] = { "fontplaceholder", "baseplaceholder", "cssfileplaceholder", "types", "svgID", "basename", NULL };

    int ok = PyArg_ParseTupleAndKeywords(args, keywds, "Oss|sss", kwlist,
                                         &fontObj, &base, &cssFilename,
                                         &types, &svgID, &userbase);
    if (!ok)
        return Py_BuildValue("i", -1);

    LF_FONT* lfFont = (LF_FONT*)PyLong_AsVoidPtr(fontObj);
    if (lfFont == NULL)
        return Py_BuildValue("i", LF_INVALID_PARAM);

    const char* thebase = NULL;

    if (strlen(base) == 0)
        thebase = userbase;
    else
        thebase = base;

    LF_FONT_TYPE fontTypes[6];

    if (types == NULL)
    { 
        fontTypes[0] = eLF_SFNT_FONT;
        fontTypes[1] = eLF_WOFF_FONT;
        fontTypes[2] = eLF_WOFF2_FONT;
        fontTypes[3] = eLF_EOT_FONT;
        fontTypes[4] = eLF_UNDETERMINED;
        fontTypes[5] = eLF_UNDETERMINED;
    }
    else
    {
        int i, cur = 0;
        char* comma;
        char* ptr = (char*)types;

        do
        {
             if (0 == strncmp(ptr, "WOFF2", 5))
                fontTypes[cur++] = eLF_WOFF2_FONT;
            else if (0 == strncmp(ptr, "WOFF", 4))
                fontTypes[cur++] = eLF_WOFF_FONT;
            else if (0 == strncmp(ptr, "SVG", 3))
                fontTypes[cur++] = eLF_SVG_FONT;
            else if (0 == strncmp(ptr, "EOT", 3))
                fontTypes[cur++] = eLF_EOT_FONT;
            else if (0 == strncmp(ptr, "TTF", 3))
                fontTypes[cur++] = eLF_SFNT_FONT;
            else if (0 == strncmp(ptr, "OTF", 3))
                fontTypes[cur++] = eLF_CFF_FONT;

            comma = strchr(ptr, ',');
            if (comma != NULL)
                ptr = comma+1;
        } while ((comma != NULL) && (cur < 6));

        for (i = cur; i < 6; i++)
            fontTypes[i] = eLF_UNDETERMINED;
    }

    LF_ERROR error = LF_writeCSSFile(lfFont, thebase, fontTypes, svgID, cssFilename);

    return Py_BuildValue("i", error);
}

// Unpacks the font's tables.
// Expected args: font handle
// Returns:
//      integer (an LF_ERROR code). 0 = success.
static PyObject* sfnt_unpack(PyObject* self, PyObject* args)
{
    PyObject *fontObj;

    PyArg_ParseTuple(args, "O", &fontObj);

    LF_FONT* lfFont = (LF_FONT*)PyLong_AsVoidPtr(fontObj);

    if (lfFont == NULL)
        return Py_BuildValue("i", LF_INVALID_PARAM);

    LF_ERROR error = SFNT_unpackTables(lfFont);

    return Py_BuildValue("i", error);
}

// Gets a name string.
// Expected args:
//      font handle, name ID, platformID, encodingID langaugeID
// Returns:
//      on success: a unicode string
//      on failure: an integer (an LF_ERROR code). 0 = success
static PyObject* name_getString(PyObject* self, PyObject* args)
{
    PyObject *fontObj;
    int nameID, platformID, encodingID, languageID;

    PyArg_ParseTuple(args, "Oiiii", &fontObj, &nameID, &platformID, &encodingID, &languageID);

    LF_FONT* lfFont = (LF_FONT*)PyLong_AsVoidPtr(fontObj);

    if (lfFont == NULL)
        return Py_BuildValue("i", LF_INVALID_PARAM);

    USHORT length;

    LF_ERROR error = NAME_parseTable(lfFont);
    if (error == LF_ERROR_OK)
    {
        error = NAME_getNameStringLength(lfFont, (USHORT)nameID, &length);
        if (error == LF_ERROR_OK)
        {
            BYTE* buffer = (BYTE*)malloc(sizeof(BYTE) * length);
            if (buffer == NULL)
                return Py_BuildValue("i", LF_OUT_OF_MEMORY);

            error = NAME_getNameString(lfFont, (USHORT)nameID, buffer, length);
            if (error == LF_ERROR_OK)
            {
                int numChars = length/2;

                wchar_t *auxBuf = (wchar_t*)calloc(sizeof(wchar_t), numChars);
                if (auxBuf == NULL)
                {
                    free(buffer);
                    return Py_BuildValue("i", LF_OUT_OF_MEMORY);
                }
                if (sizeof(wchar_t) == 4)
                {
                    short *ptr = (short*)buffer;
                    for (int i = 0; i < numChars; i++)
                        auxBuf[i] = (wchar_t)*ptr++;
                }
                else
                    memcpy(auxBuf, buffer, length);

                PyObject* retVal = PyUnicode_FromWideChar(auxBuf, numChars);
                free(buffer);
                free(auxBuf);
                return retVal;
            }
        }
    }

    return Py_BuildValue("i", error);
}

/*** MODULE CREATION ***/
MOD_INIT(libfont3backend)
{
    PyObject *m;

    MOD_DEF(m, "libfont3backend", NULL, LibFontMethods)

    if (m == NULL)
        return MOD_ERROR_VAL;

    PyModule_AddStringConstant(m, "__version__", LIBFONT_VERSION);

    return MOD_SUCCESS_VAL(m);

    }
}
