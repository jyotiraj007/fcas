// Copyright (C) 2016 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// H_OffsetContour.h

#ifndef H_OFFSET_CONTOUR_H
#define H_OFFSET_CONTOUR_H

#include "H_Contour.h"
#include "H_ScaleOffset.h"
#include <stdlib.h>
#include <math.h>

class H_Offset
{
    public:

		H_Offset()
            :   m_Data(0)
        {};
        
		H_Offset(float x, float y, bool onCurve)
        {
            m_Shorts.m_OnCurve = onCurve;
            m_Shorts.m_X = (signed int) floor(x);   //bb check we don't quantize fp precision error.
            m_Shorts.m_Y = (signed int) floor(y);
        }

        operator int() { return m_Data; };

        union
        {
            int   m_Data;

            struct
            {
                  signed int m_OnCurve : 2;
                  signed int m_X       : 15;
                  signed int m_Y       : 15;
            } m_Shorts;
        };
};


class H_OffsetContour
{
    public:
        /* CTOR */      H_OffsetContour        ();
        /* CTOR */      H_OffsetContour        (H_Contour& contour);

       H_ArrayList<H_Offset>&                GetOffsets();

    protected:

        H_ArrayList<H_Offset> m_Points;
};



#endif
