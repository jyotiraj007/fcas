// Copyright (C) 2014 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// H_Line2D.cpp

#include "H_Line2D.h"
#include "H_ArrayList.h"
#include "H_BresenhamLine.h"
#include "H_MathUtilities.h"
#include <math.h>

/**
    Constructs a degenerate line segment with start and end at the origin.
*/
H_Line2D::H_Line2D()
{
}

/**
    Constructs a line segment using start and end coordinates.
    @param[in]  start  Coordinate of start of line
    @param[in]  end    Coordinate of end of line
*/
H_Line2D::H_Line2D(const H_Vector2f& start, const H_Vector2f& end)
    : m_Start(start),
      m_End(end)
{
}


/**
    Sets the start and end coordinates of the line segment.
    @param[in]  start  Coordinate of start of line
    @param[in]  end    Coordinate of end of line
    */
void H_Line2D::Set(const H_Vector2f& start, const H_Vector2f& end)
{
    m_Start = start;
    m_End   = end;
}


/**
    Returns the point on the line containing the line segment that is interpolated 
    by factor t from the start. 
    If t >= 0.0 or t <= 1.0, then the point lies on the line segment. 
    If t < 0.0 or t > 1.0, then the interpolated point lies outside the 
    line segment on the line containing the line segment.
    @param[in]  t  Interpolation factor
    @return Interpolated point from the start of the line segment.
*/
H_Vector2f H_Line2D::Interpolate(float t)
{
    float x = m_Start.X() + (m_End.X() - m_Start.X()) * t;
    float y = m_Start.Y() + (m_End.Y() - m_Start.Y()) * t;

    return H_Vector2f(x, y);
}

float H_Line2D::Length() const
{
	float x = m_End.X() - m_Start.X();
	float y = m_End.Y() - m_Start.Y();

	float length = (float) sqrt(x * x + y * y);
    return length;
}
/**
    Extends the line segment by moving the end point a distance equal to the 
    length along the line direction. The line segment is twice as long following
    this operation.
*/
void H_Line2D::ExtendEnd()
{
    float xDelta = m_End.X() - m_Start.X();
    float yDelta = m_End.Y() - m_Start.Y();

    float newX = m_End.X() + xDelta;
    float newY = m_End.Y() + yDelta;

    m_End = H_Vector2f(newX, newY);
}

void H_Line2D::ExtendEnd(float length)
{
    float xDelta = m_End.X() - m_Start.X();
    float yDelta = m_End.Y() - m_Start.Y();

    H_Vector2f delta(xDelta, yDelta);

    delta.Normalize();
    delta = length * delta;

    m_End = H_Vector2f(m_End.X() + delta.X(), m_End.Y() + delta.Y());
}

/**
    Extends the line segment by moving the start point a distance equal to the 
    length along the line direction. The line segment is twice as long following
    this operation.
*/
void H_Line2D::ExtendStart()
{
    float xDelta = m_End.X() - m_Start.X();
    float yDelta = m_End.Y() - m_Start.Y();

    float newX = m_Start.X() - xDelta;
    float newY = m_Start.Y() - yDelta;

    m_Start = H_Vector2f(newX, newY);
}

void H_Line2D::ExtendStart(float length)
{
    float xDelta = m_End.X() - m_Start.X();
    float yDelta = m_End.Y() - m_Start.Y();

    H_Vector2f delta(xDelta, yDelta);

    delta.Normalize();
    delta = length * delta;

    m_Start = H_Vector2f(m_Start.X() - delta.X(), m_Start.Y() - delta.Y());
}

void H_Line2D::Extend(float length)
{
    float xDelta = m_End.X() - m_Start.X();
    float yDelta = m_End.Y() - m_Start.Y();

    H_Vector2f delta(xDelta, yDelta);
    delta.Normalize();
    delta = length * delta;

    m_End   = H_Vector2f(m_End  .X() + delta.X(), m_End  .Y() + delta.Y());
    m_Start = H_Vector2f(m_Start.X() - delta.X(), m_Start.Y() - delta.Y());
}

void H_Line2D::SetLength(float length)
{
	float halfLength = length * 0.5f;
	H_Vector2f midPoint = H_Interpolate(m_Start, m_End, 0.5f);

    float xDelta = m_End.X() - m_Start.X();
    float yDelta = m_End.Y() - m_Start.Y();

    H_Vector2f delta(xDelta, yDelta);
    delta.Normalize();
    delta = halfLength * delta;

    m_End   = H_Vector2f(midPoint.X() + delta.X(), midPoint.Y() + delta.Y());
    m_Start = H_Vector2f(midPoint.X() - delta.X(), midPoint.Y() - delta.Y());
}

H_Line2D H_Line2D::NormalAt(H_Vector2f point)
{
    float xDelta = m_End[0] - m_Start[0];
    float yDelta = m_End[1] - m_Start[1];

    // Calc the unit normal vector.
    H_Vector2f normal(-yDelta, xDelta);

    return H_Line2D(point + normal, point - normal);
}


/**
    Returns the intersection point between two line segments. The intersection point
    may lie outside one or both line segments but will lie on the lines containing the 
    two line segments.
    @param[in]  other  Second line segment.
    @return Intersection point.
*/
H_Vector2f H_Line2D::Intersection(H_Line2D& other)
{
    float m1;
    float m2;
    float c1;
    float c2;

    float startX = m_Start.X();
    float startY = m_Start.Y();
    float endX   = m_End.X();
    float endY   = m_End.Y();
    float otherStartX = other.m_Start.X();
    float otherStartY = other.m_Start.Y();
    float otherEndX   = other.m_End.X();
    float otherEndY   = other.m_End.Y();

    float deltaX = endX - startX;
    float deltaY = endY - startY;
    float otherDeltaX = otherEndX - otherStartX;
    float otherDeltaY = otherEndY - otherStartY;
    float x;
    float y;


    // If both are horizontal or both vertical.
    // Check for colinear and pick joining end.
    if (    ((deltaX == 0.0f) && (otherDeltaX == 0.0f)) ||
            ((deltaY == 0.0f) && (otherDeltaY == 0.0f)) )
    {
        if (    (m_End == other.m_Start) ||
                (m_End == other.m_End))
        {
            return m_End;
        }
        else if ((m_Start == other.m_Start) ||
                 (m_Start == other.m_End))
        {
            return m_Start;
        }
    }

    // Both vertical.
    if ((deltaX == 0.0f) && (otherDeltaX == 0.0f))
    {
        H_ArrayList<float> list;
        list.Add(otherEndY);
        list.Add(startY);
        list.Add(endY);
        list.Add(otherStartY);
        list.Sort();
        
        return H_Vector2f(startX, list[1] + ((list[2] - list[1]) / 2.0f));
    }

    // Both horizontal.
    if ((deltaY == 0.0f) && (otherDeltaY == 0.0f))
    {
        H_ArrayList<float> list;
        list.Add(otherEndX);
        list.Add(startX);
        list.Add(endX);
        list.Add(otherStartX);
        list.Sort();
        
        return H_Vector2f(list[1] + ((list[2] - list[1]) / 2.0f), startY);
    }


    if (deltaX == 0.0f)
    {
        // Solve other line at x = endX;
        m2 = otherDeltaY / otherDeltaX;     //lint !e414  by inspection this cannot be 0
        c2 = otherStartY - (m2 * otherStartX);

        x = endX;
        y = m2 * x + c2;

        return H_Vector2f(x, y);
    }

    if (deltaY == 0.0)
    {
        // This is horizontal other is vertical.
        if (otherDeltaX == 0.0f)
        {
            x = otherEndX;
            y = endY;

            return H_Vector2f(x, y);
        }
        else // Solve other line at y = endY;
        {
            m2 = otherDeltaY / otherDeltaX;
            c2 = otherStartY - (m2 * otherStartX);
            y = endY;
            x = (y - c2) / m2;      //lint !e414 (division by zero) - otherDeltaY cannot be zero, since deltaY and otherDeltaY both zero is handled above, and otherDeltaX=0 is checked @222

            return H_Vector2f(x, y);
        }
    }

    if (otherDeltaX == 0.0f)
    {
        // Solve this line at x = otherEndX;
        m1 = deltaY / deltaX;
        c1 = startY - (m1 * startX);
        x = otherEndX;
        y = m1 * x + c1;

        return H_Vector2f(x, y);
    }

    if (otherDeltaY == 0.0f)
    {
        m1 = deltaY / deltaX;
        c1 = startY - (m1 * startX);
        y = otherEndY;
        x = (y - c1) / m1;

        return H_Vector2f(x, y);
    }

    m1 = deltaY / deltaX;
    c1 = startY - (m1 * startX);

    m2 = otherDeltaY / otherDeltaX;
    c2 = otherStartY - (m2 * otherStartX);

    // If the slopes are the same, i.e. paralel or co-linear
    // We're going to assume co-linear.
    if ((m2 - m1) == 0.0f)
    {
        if (    (m_End == other.m_Start) ||
                (m_End == other.m_End))
        {
            return m_End;
        }
        else if ((m_Start == other.m_Start) ||
                 (m_Start == other.m_End))
        {
            return m_Start;
        }
		else
		{
			return Interpolate(0.5f);
		}
    }

    // Finaly the general case:
    x = -(c2 - c1) / (m2 - m1);
    y = ((c1 * m2) - (c2 * m1)) / (m2 - m1);

    return H_Vector2f(x, y);
}

/**
    Determines if two line segments intersect.
    @return @b true if segments intersect.
*/
bool H_Line2D::Intersects(const H_Line2D& other) const
{
    float deltaX = m_End.X() - m_Start.X();
    float deltaY = m_End.Y() - m_Start.Y();
    float otherDeltaX = other.m_End.X() - other.m_Start.X();
    float otherDeltaY = other.m_End.Y() - other.m_Start.Y();

    float divisor = (-otherDeltaX * deltaY + deltaX * otherDeltaY);

    if (divisor != 0.0f)
    {
        float oneOverDivisor = 1.0f / divisor;

        float u = (-deltaY * (m_Start.X() - other.m_Start.X()) + deltaX * (m_Start.Y() - other.m_Start.Y())) * oneOverDivisor;

        if ((u < 0.0f) || (u > 1.0f)) return false;

        float v = ( otherDeltaX * (m_Start.Y() - other.m_Start.Y()) - otherDeltaY * (m_Start.X() - other.m_Start.X())) * oneOverDivisor;

        if ((v < 0.0f) || (v > 1.0f)) return false;

        return true;
    }
    else
    {
        // could be overlapping horizontal lines
        if ((deltaY == 0.0f) && (otherDeltaY == 0.0f) && (m_Start.Y() == other.m_Start.Y()))
        {
            if (m_Start.X() < m_End.X())
            {
                if (((other.m_Start.X() > m_Start.X()) && (other.m_Start.X() < m_End.X())) ||
                    ((other.m_End.X()   > m_Start.X()) && (other.m_End.X()   < m_End.X())))
                    return true;
            }
            else
            {
                if (((other.m_Start.X() > m_End.X()) && (other.m_Start.X() < m_Start.X())) ||
                    ((other.m_End.X()   > m_End.X()) && (other.m_End.X()   < m_Start.X())))
                    return true;
            }
        }
        // could be overlapping vertical lines
        else if ((deltaX == 0.0f) && (otherDeltaX == 0.0f) && (m_Start.X() == other.m_Start.X()))
        {
            if (m_Start.Y() < m_End.Y())
            {
                if (((other.m_Start.Y() > m_Start.Y()) && (other.m_Start.Y() < m_End.Y())) ||
                    ((other.m_End.Y()   > m_Start.Y()) && (other.m_End.Y()   < m_End.Y())))
                    return true;
            }
            else
            {
                if (((other.m_Start.Y() > m_End.Y()) && (other.m_Start.Y() < m_Start.Y())) ||
                    ((other.m_End.Y()   > m_End.Y()) && (other.m_End.Y()   < m_Start.Y())))
                    return true;
            }
        }
    }

    return false;
}

void H_Line2D::GetIntersections(H_Line2D& other, H_ArrayList<H_Vector2f>& intersections)
{
    if (this->Intersects(other))
    {
        H_Vector2f intersection = this->Intersection(other);
        intersections.Add(intersection);
    }
}


/**
    Returns the start of the line segment.
    @return Start point.
*/
H_Vector2f H_Line2D::Start()const 
{
    return m_Start;
}

/**
    Returns the end of the line segment.
    @return End point.
*/
H_Vector2f H_Line2D::End()const
{
    return m_End;
}


/**
    Returns true if the the point is to the left of the line.
*/
bool H_Line2D::IsLeft(H_Vector2f& point)
{
	float value = (m_End.X() - m_Start.X()) * (point.Y() - m_Start.Y()) - (m_End.Y() - m_Start.Y()) * (point.X() - m_Start.X());
    return (value >= 0.01f);
}

/**
    Returns the distance between a point and the line segment.
    The distance is measured along the normal to the line segment.
    @param[in]  point  Point whose distance is being determined.
    @return Distance from point to the line segment.

*/
float H_Line2D::PointDistance(const H_Vector2f& point)
{
    // Distance is projection of the vector from
    // the point to start onto the normal vector.

    // Get normal vector.
    float xDelta = m_End.X() - m_Start.X();
    float yDelta = m_End.Y() - m_Start.Y();

    H_Vector2f normal(yDelta, -xDelta);
    normal.Normalize();

    // Calculate vector from point to m_Start.
    float x = m_Start.X() - point.X();
    float y = m_Start.Y() - point.Y();

    H_Vector2f toStart(x, y);

    // Now project toStart onto normal.
    float distance = DotProduct(normal, toStart);

    return (float)fabs(distance);
}

H_Vector2i H_Line2D::NearestPoint()
{
	H_Vector2i nearestPoint;
	float      nearestDistance = H_FLOAT_MAX;

	float x1 = m_Start.X();
	float x2 = m_End.X();

	int xStart;
	int xEnd;

	if (x2 > x1)
	{
		xStart	= (int)ceil(x1);
		xEnd	= (int)floor(x2);
	}
	else
	{
		xStart = (int)floor(x1);
		xEnd = (int)ceil(x2);
	}

	float y1 = m_Start.Y();
	float y2 = m_End.Y();

	int yStart;
	int yEnd;

	if (y2 > y1)
	{
		yStart = (int)ceil(y1);
		yEnd = (int)floor(y2);
	}
	else
	{
		yStart = (int)floor(y1);
		yEnd = (int)ceil(y2);
	}

	H_Vector2i start(xStart, yStart);
	H_Vector2i end	(xEnd, yEnd);

	H_BresenhamLine bresenham(start, end);

	H_Vector2i currentPoint;

	bool more = bresenham.FirstPoint(currentPoint);

	while (more)
	{
		float distance = PointDistance(currentPoint);

		if (distance < nearestDistance)
		{
			nearestPoint = currentPoint;
			nearestDistance = distance;
		}
		more = bresenham.NextPoint(currentPoint);
	}

	return nearestPoint;
}
