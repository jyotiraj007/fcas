// Copyright (C) 2015 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// H_QuadGlyph.cpp

#include "H_QuadGlyph.h"
#include "H_BoundingBox.h"
#include <stdlib.h>

H_QuadGlyph::H_QuadGlyph()
: m_GlyphId((unsigned int)-1)
{
}

H_QuadGlyph::H_QuadGlyph(unsigned int glyphId)
: m_GlyphId(glyphId)
{
}

H_QuadGlyph::H_QuadGlyph(H_LinkedList<H_QuadContour>& contours)
: m_GlyphId((unsigned int)-1)
{
    H_QuadContour* pContour = contours.First();

    while (pContour)
    {
        AddContour(*pContour);
        pContour = contours.Next();
    }
}

/*
H_QuadGlyph::H_QuadGlyph(H_QuadGlyph& other)
{
	m_GlyphId = other.m_GlyphId;

    H_QuadContour* pContour = other.FirstContour();

    while (pContour)
    {
        AddContour(*pContour);
        pContour = other.NextContour();
    }
}
*/

void H_QuadGlyph::Interpolate(H_QuadGlyph& A, H_QuadGlyph& B, float percent)
{
	m_Contours.RemoveAll();

	/*
	if (A.NumContours() != B.NumContours())
	{
		return;
	}
	*/

	H_QuadContour* pA_Contour = A.FirstContour();
	H_QuadContour* pB_Contour = B.FirstContour();

	while (pA_Contour && pB_Contour)
    {
		if (pA_Contour->NumPoints() == pB_Contour->NumPoints())
		{
			H_QuadContour contour;

			for (int i = 0; i < pA_Contour->NumPoints(); i++)
			{
				H_ContourPoint aPoint = pA_Contour->GetPoint(i);
				H_ContourPoint bPoint = pB_Contour->GetPoint(i);

				H_Vector2f  newPosition = H_Interpolate(aPoint.m_Point, bPoint.m_Point, percent);

				H_ContourPoint newPoint(aPoint.m_Type, newPosition);

				contour.AddPoint(newPoint);
			}

			AddContour(contour);
		}

		pA_Contour = A.NextContour();
		pB_Contour = B.NextContour();
    }
}


H_LinkedList<H_QuadContour>& H_QuadGlyph::Contours()
{
	return m_Contours;
}


H_QuadContour* H_QuadGlyph::GetContour(int index)
{
	int currentIndex = 0;

	H_QuadContour* pContour = NULL;

	H_QuadContour* pCurrentContour = FirstContour();

	while (pCurrentContour)
	{
		if (currentIndex == index)
		{
			pContour = pCurrentContour;
			break;
		}

		pCurrentContour = NextContour();
		currentIndex++;
	}

	return pContour;
}

void H_QuadGlyph::SetGlyphId(unsigned int glyphId)
{
    m_GlyphId = glyphId;
}


unsigned int H_QuadGlyph::GetGlyphId() const
{
    return m_GlyphId;
}


void H_QuadGlyph::Scale(float xScale, float yScale)
{
    H_QuadContour* pContour = FirstContour();

    while (pContour)
    {
        pContour->Scale(xScale, yScale);
        pContour = NextContour();
    }
}

void H_QuadGlyph::Clear()
{
    m_Contours  .RemoveAll();
}

void H_QuadGlyph::AddContour(H_QuadContour& contour)
{
    m_Contours.Add(contour);
}

void H_QuadGlyph::MakePoints()
{
    H_QuadContour* pContour = FirstContour();

    while (pContour)
    {
        pContour->MakePoints();
        pContour = NextContour();
    }
}

void H_QuadGlyph::CheckWinding()
{
	CalcNesting();
    H_QuadContour* pContour = FirstContour();

    while (pContour)
    {
        pContour->CheckWinding();
        pContour = NextContour();
    }
}


void H_QuadGlyph::FindFirstPoints()
{
    H_QuadContour* pContour = FirstContour();

    while (pContour)
    {
        pContour->FindFirstPoint();
        pContour = NextContour();
    }
}

void H_QuadGlyph::RemoveRedundantPoints()
{
    H_QuadContour* pContour = FirstContour();

    while (pContour)
    {
        pContour->RemoveRedundantPoints();
        pContour = NextContour();
    }
}


void H_QuadGlyph::RemoveLinearBeziers()
{
    H_QuadContour* pContour = FirstContour();

    while (pContour)
    {
        pContour->RemoveLinearBezier();
        pContour = NextContour();
    }
}

void H_QuadGlyph::CreateUnMatchedSections()
{
    H_QuadContour* pContour = FirstContour();

    while (pContour)
    {
        pContour->CreateUnMatchedSections();
        pContour = NextContour();
    }
}

void H_QuadGlyph::LabelIndices()
{
    H_QuadContour* pContour = FirstContour();

    while (pContour)
    {
		pContour->ReOrder();
        pContour->LabelIndices();
        pContour = NextContour();
    }
}

void H_QuadGlyph::AddMissingExtrema()
{
    H_QuadContour* pContour = FirstContour();

    while (pContour)
    {
        pContour->AddMissingExtrema();
        pContour = NextContour();
    }
}

void H_QuadGlyph::FindDirections()
{
    H_QuadContour* pContour = FirstContour();

    while (pContour)
    {
        pContour->FindDirections();
        pContour = NextContour();
    }
}

void H_QuadGlyph::FindAngles()
{
	H_QuadContour* pContour = FirstContour();

	while (pContour)
	{
		pContour->FindAngles();
		pContour = NextContour();
	}
}

void H_QuadGlyph::FindPositions()
{
	H_QuadContour* pContour = FirstContour();

	while (pContour)
	{
		pContour->FindPositions();
		pContour = NextContour();
	}
}

void H_QuadGlyph::ReOrderPoints()
{
    H_QuadContour* pContour = FirstContour();

    while (pContour)
    {
        pContour->ReOrder();

        pContour = NextContour();
    }
}

void H_QuadGlyph::FindExtrema()
{
    H_QuadContour* pContour = FirstContour();

    while (pContour)
    {
        pContour->FindExtrema();

        pContour = NextContour();
    }
}

void H_QuadGlyph::CalcNesting()
{
    H_QuadContour* pContour = FirstContour();

    while (pContour)
    {
        pContour->ClearNestingLevel();

        pContour = NextContour();
    }

    H_ListElem<H_QuadContour>* pCurrentContour = m_Contours.GetFirstElement();

    while (pCurrentContour)
    {
        H_ListElem<H_QuadContour>* pNextContour = m_Contours.GetNext(pCurrentContour);

        while (pNextContour)
        {
            if (pCurrentContour->m_Data.Contains(pNextContour->m_Data))
            {
                pNextContour->m_Data.IncNestingLevel();
            }

            if (pNextContour->m_Data.Contains(pCurrentContour->m_Data))
            {
                pCurrentContour->m_Data.IncNestingLevel();
            }

            pNextContour = m_Contours.GetNext(pNextContour);
        }
        pCurrentContour = m_Contours.GetNext(pCurrentContour);
    }
}


H_QuadContour* H_QuadGlyph::FirstContour()
{
    return m_Contours.First();
}

H_QuadContour* H_QuadGlyph::NextContour()
{
    return m_Contours.Next();
}


bool H_QuadGlyph::operator==(H_QuadGlyph& other)
{
    if (NumContours() != other.NumContours())
    {
        return false;
    }

	ClearTags();
    H_QuadContour* pOtherContour = other.FirstContour();

    while (pOtherContour)
    {
        int sequenceId = pOtherContour->GetId();

        H_QuadContour* pContour = GetSequence(sequenceId);

        if (NULL == pContour)
        {
            return false;
        }
		pContour->SetTag(true);

        pOtherContour = other.NextContour();
    }

    return true;
}

int H_QuadGlyph::NumContours()
{
    return m_Contours.NumElements();
}


H_QuadContour* H_QuadGlyph::RemoveContour(int sequenceId)
{
    H_QuadContour* pQuadContour = NULL;

    H_ListElem<H_QuadContour>* pContour = m_Contours.GetFirstElement();

    while (pContour)
    {
        if (pContour->m_Data.GetId() == sequenceId)
        {
            pQuadContour = &pContour->m_Data;
            m_Contours.Remove(pContour);
            break;
        }
        pContour = m_Contours.GetNextElement();
    }

    return pQuadContour;
}

int H_QuadGlyph::NumPoints(int sequenceId)
{
    int numPoints = 0;

    H_QuadContour* pContour = m_Contours.First();

    while (pContour)
    {
        if (pContour->GetId() == sequenceId)
        {
            numPoints = pContour->NumPoints();
            break;
        }
        pContour = m_Contours.Next();
    }

    return numPoints;
}

H_QuadContour* H_QuadGlyph::GetSequence(int sequenceId)
{
    H_QuadContour* pContour = m_Contours.First();

    while (pContour)
    {
        if (    (pContour->Tag() == false) &&
                (pContour->GetId() == sequenceId))
        {
            return pContour;
        }
        pContour = m_Contours.Next();
    }

    return NULL;
}

void H_QuadGlyph::FindScaledBounds(H_ScaleOffset& scaleOffset)
{
    H_QuadContour* pContour = m_Contours.First();

    while (pContour)
    {
        pContour->SetScaledBounds(scaleOffset);
        pContour = m_Contours.Next();
    }
}


H_Vector2f H_QuadGlyph::GetBoundsOffset()
{
	H_BoundingBox bounds;

	GetBounds(bounds);

	return H_Vector2f(bounds.Left(), bounds.Bottom());
}


H_ScaleOffset H_QuadGlyph::GetScaleOffset(H_QuadGlyph& other)
{
	H_BoundingBox thisBounds;
	H_BoundingBox otherBounds;

	GetBounds(thisBounds);
	other.GetBounds(otherBounds);

	H_ScaleOffset scaleOffset = thisBounds.GetScaleOffset(otherBounds);

	return scaleOffset;
}


bool H_QuadGlyph::GetBounds(H_BoundingBox& bounds)
{
    bool onCurveAtExtrema = true;

    bounds.Reset();

    H_QuadContour* pContour = m_Contours.First();

    while (pContour)
    {
        onCurveAtExtrema &= pContour->GetBounds(bounds);
        pContour = m_Contours.Next();
    }

    return onCurveAtExtrema;
}

void H_QuadGlyph::SetBoundsOnContours()
{
	H_BoundingBox glyphBounds;

	GetBounds(glyphBounds);

    H_QuadContour* pContour = m_Contours.First();

    while (pContour)
    {
		pContour->SetGlyphBounds(glyphBounds);
        pContour = m_Contours.Next();
    }
}

bool H_QuadGlyph::Contains(H_QuadGlyph& other)
{
    //bool contains = false;

    if (FirstContour() == NULL || other.FirstContour() == NULL)
    {
        return false;
    }

    if (NumContours() < other.NumContours())
    {
        return false;
    }

    H_QuadContour* pContour = other.FirstContour();

    while (pContour)
    {
        int sequenceId = pContour->GetId();

        if (NULL == GetSequence(sequenceId))
        {
            return false;
        }

        pContour = other.NextContour();
    }

    return true;
}

void H_QuadGlyph::NumberContours()
{
	int count = 0;

	H_QuadContour* pContour = m_Contours.First();

    while (pContour)
    {
		pContour->SetNumber(count);

		count++;
		pContour = m_Contours.Next();
    }
}

bool H_QuadGlyph::IsValid()
{
	bool isValid = true;

	H_QuadContour* pContour = m_Contours.First();

    while (pContour)
    {
		isValid &= pContour->IsValid();

        pContour = m_Contours.Next();
    }

	if (false == isValid)
	{
		//printf("Invalid Glyph.\n");
	}
	return isValid;
}

void H_QuadGlyph::ClearHeap()
{
    H_LinkedList<H_QuadContour>::ClearHeap();
    H_LinkedList<H_Component>::ClearHeap();
}


void H_QuadGlyph::ClearTags()
{
    H_QuadContour* pContour = m_Contours.First();

    while (pContour)
    {
        pContour->SetTag(false);

        pContour = m_Contours.Next();
    }
}

int H_QuadGlyph::SizeBytes()
{
    int total = 0;

    H_QuadContour* pContour = m_Contours.First();

    while (pContour)
    {
        total += pContour->SizeBytes();    
        pContour = m_Contours.Next();
    }

    return total;
}
