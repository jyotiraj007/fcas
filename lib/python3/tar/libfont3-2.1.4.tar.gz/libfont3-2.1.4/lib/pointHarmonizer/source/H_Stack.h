// Copyright (C) 2014 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// H_Stack.h

#ifndef H_STACK_H
#define H_STACK_H

#include "H_Array.h"

template <class T> class H_Stack
{
    public:
        /* Ctor */ H_Stack    ();
        /* Dtor */~H_Stack    ();

        void       Push     (T element);
        T          Pop      ();
        bool       IsEmpty  ();
        void       Reset    ();

        int        NumElements();
        T&         ElementAt(int index);

    protected:

        H_Array<T> m_Elements;

        int             m_StackIndex;
        int             m_StackHighWater;

        int             m_Interator;
};

template <class T>
H_Stack<T>::H_Stack()
{
    m_StackIndex = 0;
    m_StackHighWater = 0;
}

template <class T>
H_Stack<T>::~H_Stack()
{
    m_Elements.Clear();
}

template <class T>
void H_Stack<T>::Reset()
{
    m_StackIndex = 0;
    m_StackHighWater = 0;
    m_Elements.Clear();
}

template <class T>
void H_Stack<T>::Push(T element)
{
    // Does the array need to grow?
    if (m_StackIndex >= m_StackHighWater)
    {
        m_Elements.Add(element);
        m_StackHighWater++;
    }
    else
    {
       m_Elements[m_StackIndex] = element;
    }

    m_StackIndex++;
}

template <class T>
T H_Stack<T>::Pop()
{
    T element = T();

    if (false == IsEmpty())
    {
        m_StackIndex--;
        element = m_Elements[m_StackIndex];
    }
    return element;
}

template <class T>
int H_Stack<T>::NumElements()
{
    return m_StackIndex;
}

template <class T>
T& H_Stack<T>::ElementAt(int index)
{
    return m_Elements[index];
}

template <class T>
bool H_Stack<T>::IsEmpty()
{
    bool isEmpty = (m_StackIndex == 0);

    return isEmpty;
}

#endif
