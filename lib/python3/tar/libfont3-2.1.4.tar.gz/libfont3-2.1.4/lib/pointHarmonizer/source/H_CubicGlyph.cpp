// Copyright (C) 2015 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// H_CubicGlyph.cpp

#include "H_CubicGlyph.h"

H_CubicGlyph::H_CubicGlyph(int designUnits /* = DEFAULT_CUBIC_UNITS */)
: m_DesignUnits(designUnits)
{
}

void H_CubicGlyph::Clear()
{
    m_Contours.RemoveAll();
}

void H_CubicGlyph::AddContour(H_CubicContour& contour)
{
//    contour.SetDesignUnits(m_DesignUnits);
    m_Contours.Add(contour);
}

int H_CubicGlyph::NumContours()
{
    return m_Contours.NumElements();
}

H_CubicContour* H_CubicGlyph::GetContour(int index)
{
	int currentIndex = 0;

	H_CubicContour* pContour = NULL;

	H_CubicContour* pCurrentContour = FirstContour();

	while (pCurrentContour)
	{
		if (currentIndex == index)
		{
			pContour = pCurrentContour;
			break;
		}

		pCurrentContour = NextContour();
		currentIndex++;
	}

	return pContour;
}


int H_CubicGlyph::GetDesignUnits()
{
    return m_DesignUnits;
}

H_CubicContour* H_CubicGlyph::FirstContour()
{
    return m_Contours.First();
}

H_CubicContour* H_CubicGlyph::NextContour()
{
    return m_Contours.Next();
}

