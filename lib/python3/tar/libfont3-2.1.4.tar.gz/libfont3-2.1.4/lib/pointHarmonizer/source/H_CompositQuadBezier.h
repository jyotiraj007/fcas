// Copyright (C) 2015 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
/// \file CompositQuadBezier.h

#ifndef COMPOSIT_QUAD_BEZIER_H
#define COMPOSIT_QUAD_BEZIER_H

#include "H_Vector2f.h"
#include "H_QuadContour.h"
#include "H_QuadBezier.h"
#include "H_QuadPoints.h"
#include "H_Line2D.h"
#include "H_Stack.h"

class CubicBezier;
enum H_Comparision { H_EQUALS = 0, H_LESS_THAN, H_ANY };

class H_CompositQuadBezier : public H_QuadBezier
{
    public:

        /* CTOR */  H_CompositQuadBezier	();
		/* CTOR */	H_CompositQuadBezier	(H_ArrayList<H_ContourPoint>& quadList);

		void        AddResolvedPoints       (H_ArrayList<H_ContourPoint>& points);

		void        Evaluate(float flatness);

        void        Clear                ();

        bool        Match                (H_ArrayList<H_ContourPoint>& points, int numPoints,  float tolerance, H_Comparision comparision = H_EQUALS);
		bool		MatchStartTarget	 (H_ArrayList<H_ContourPoint>& points, int numPoints, float tolerance, H_Comparision comparision, H_Line2D startTarget);

		void        Split                (	H_ArrayList<H_ContourPoint>& pointsA,
											H_ArrayList<H_ContourPoint>& pointsB,
											int numPointsA,
											int numPointsB,
											float distance,
											float tolerance);

		bool        SplitAtIndex		(	H_ArrayList<H_ContourPoint>& pointsA,
											H_ArrayList<H_ContourPoint>& pointsB,
											int numPointsA,
											int numPointsB,
											int splitIndex,
											float tolerance);

		bool        SplitAtFirstExtrema (	H_ArrayList<H_ContourPoint>& points,
											int numPoints,
											float tolerance);

		bool		GetFirstExtremaIndex(int& index, bool& horizontal);


		bool       HasInflection	();
		H_Vector2f GetInfectionVector();

    protected:

		bool		MatchPoints			(H_ArrayList<H_ContourPoint>& points, int numPoints, float tolerance);

		void        CalcPathLengths		();

        void        CreateNormals       ();
        void        CreateTangents      ();
        void        CreateSegments      (float flatness = 0.5f);
        bool        WithinTolerance     (H_QuadBezier& quad, float& distance);
        double      SplineDistance      (H_QuadBezier& quad, bool& anyIntersections, int startIndex, int stopIndex);
        bool        Search              (H_ArrayList<H_ContourPoint>& points);
        bool        CheckRight          (H_Line2D& startTangent, H_Line2D& startTarget, int startIndex, int endIndex);
        int         FindFirst           (H_Line2D& startTangent, int startIndex, int endIndex);
        bool        Score               ();

		int			IndexAt				(float position);

        double      SplineDistance      (CubicBezier& cubic);

        double      CheckIndex          (CubicBezier& cubic, int index);
        double      MiddleDistance      (CubicBezier& cubic);

        bool        IsLinear            (float tolerance);


		H_Comparision                   m_Comparision;
		int								m_NumPoints;

        H_ArrayList<H_Line2D>			m_NormalLines; // Normals to the segments;
        H_ArrayList<H_Vector2f>			m_MidPoints;

		H_ArrayList<float>				m_PathLengths;
		H_ArrayList<H_Vector2f>         m_Angles;

        H_Line2D						m_StartTangent;
        H_Line2D						m_EndTangent;
        H_Line2D						m_StartTarget;


        float							m_Tolerance;
        int								m_Depth;
        H_ArrayList<H_QuadBezier>		m_BestBeziers;
        float							m_BestAverage;
        H_Stack<H_Line2D>				m_EvalStack;
        int								m_CheckDepth;
        float							m_CurrentFlatness;
        H_ArrayList<H_Line2D>			m_AllTangents;
        H_ArrayList<H_Line2D>			m_Tangents;
        H_ArrayList<H_Vector2f>			m_Intersections;
        H_ArrayList<H_Vector2f>			m_ControlPoints;
        H_ArrayList<H_QuadBezier>		m_Beziers;
        bool							m_FoundMatch;

        int m_MidPoint;
		H_ArrayList<int>               m_BezierIndeces;

		bool                           m_InflectionSet;
		H_Vector2f                     m_InflectionVector;
		int                            m_InflectionIndex;

		H_ArrayList<H_ContourPoint>    m_ResolvedPoints;

		static bool					   m_Verbose;
};

#endif
