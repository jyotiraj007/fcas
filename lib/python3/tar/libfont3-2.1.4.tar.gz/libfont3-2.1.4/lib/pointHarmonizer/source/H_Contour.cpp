// Copyright (C) 2016 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// H_Contour.cpp

#include "H_Contour.h"
#include "H_BoundingBox.h"

H_Contour::H_Contour()
    :   m_Id            (-1),
        m_NestingLevel  (0),
		m_FirstPoint	(-1)
{
    Clear();
}

H_Contour::H_Contour(const H_Contour& other)
    : m_Points(other.m_Points),
      m_Id			(other.m_Id),
	  m_NestingLevel	(other.m_NestingLevel),
	  m_FirstPoint	(other.m_FirstPoint)
{
}

void H_Contour::AddPoint(const H_ContourPoint& point)
{
    m_Points.Add(point);
}

void H_Contour::Clear()
{
    m_Points.Clear();
	m_Id			= -1;
	m_NestingLevel	= 0;
	m_FirstPoint	= -1;
} 

int H_Contour::NumPoints()
{
    return m_Points.NumElements();
}

H_ContourPoint& H_Contour::GetPoint(int index)
{
    return m_Points[index];
}

void H_Contour::Reverse()
{
    H_ArrayList<H_ContourPoint> reversedList;

    for (int i = m_Points.NumElements() - 1; i >=0; i--)
    {
        reversedList.Add(m_Points[i]);
    }

    m_Points = reversedList;
}

void H_Contour::Scale(float xScale, float yScale)
{
    for (int i = 0; i < m_Points.NumElements(); i++)
    {
        H_ContourPoint& currPoint = m_Points[i];

        currPoint.m_Point[0] *= xScale;
        currPoint.m_Point[1] *= yScale;
    }
}

void H_Contour::Offset(float x, float y)
{
    for (int i = 0; i < m_Points.NumElements(); i++)
    {
        H_ContourPoint& currPoint = m_Points[i];

        currPoint.m_Point[0] += x;
        currPoint.m_Point[1] += y;
    }
}

H_Handedness H_Contour::GetHandedness()
{
    float total = 0.0f;
    H_Handedness handedness = eH_CW;

    for (int i = 0; i < m_Points.NumElements() - 1; i++)
    {
        total += ((m_Points[i+1].m_Point[0] - m_Points[i].m_Point[0]) * (m_Points[i+1].m_Point[1] + m_Points[i].m_Point[1]));
    }

    if (total < 0.0)
    {
        handedness = eH_CCW;
    }

    return handedness;
}

int H_Contour::GetNestingLevel()
{
    return m_NestingLevel;
}

void H_Contour::IncNestingLevel()
{
    m_NestingLevel++;
}

void H_Contour::ClearNestingLevel()
{
    m_NestingLevel = 0;
}

void H_Contour::SetId(int id)
{
    m_Id = id;
}

int H_Contour::GetId()
{
    return m_Id;
}

// Bounds of just the control points.
void H_Contour::GetPointBounds(H_BoundingBox& boundsBox) 
{
    boundsBox.Reset();

     // Get the bounds.
    for (int i = 0; i < m_Points.NumElements(); i++)
    {
        H_ContourPoint& currPoint = m_Points[i];

        boundsBox.ExpandLeft   (currPoint.m_Point.X());
        boundsBox.ExpandRight  (currPoint.m_Point.X());
        boundsBox.ExpandTop    (currPoint.m_Point.Y());
        boundsBox.ExpandBottom (currPoint.m_Point.Y());
    }
}


int H_Contour::SizeBytes()
{
    int total = m_Points.NumElements() * sizeof(H_ContourPoint);

    return total;
}

void H_Contour::SetFirstPoint(int firstPoint)
{
	m_FirstPoint = firstPoint;
}

void H_Contour::ReOrder()
{
	//	TODO make this lazy.
	int firstPoint = FirstPointIndex();

	if (firstPoint > 0)
	{
		// Make a copy.
		H_Contour temp(*this);

		// 
		Clear();

		int index = firstPoint;

		int numPoints = temp.NumPoints();

		if (index == (numPoints - 1))
		{
			index = 0;
		}


		for (int i = 0; i < numPoints - 1; i++)
		{
			AddPoint(temp.GetPoint(index));

			index++;
			if (index >= numPoints - 1)
			{
				index = 0;
			}
		}

		// Explicitly close.
		AddPoint(temp.GetPoint(firstPoint));
	}
}


// Label the indeces...
void H_Contour::LabelIndices()
{
	int nPoints = m_Points.NumElements();

	for (int i = 0; i < nPoints; i++)
	{
		m_Points[i].m_Index = i;
		float nIndex = ((float)i / (float)nPoints) * 100.0f;
		m_Points[i].m_NormalizedIndex = nIndex;
	}
}

int H_Contour::FirstPointIndex()
{
	return m_FirstPoint;
}

// Lowest left extrema point.
int H_Contour::FindFirstPoint()
{
	int lowestIndex;

	// Initialize lowestIndex with the first extremum point.
	for (lowestIndex = 0; lowestIndex < m_Points.NumElements(); lowestIndex++)
	{
		if (m_Points[lowestIndex].m_IsExtremum)
		{
			break;
		}
	}

	// Now look for lower left corner.
    for (int i = lowestIndex; i < m_Points.NumElements(); i++)
    {
        H_ContourPoint& currentPoint = m_Points[i];

		if (currentPoint.m_IsExtremum)
		{
			// Favor lowest.
			if (currentPoint.m_Point.Y() < m_Points[lowestIndex].m_Point.Y())
			{
				lowestIndex = i;
			}
			else if (currentPoint.m_Point.Y() == m_Points[lowestIndex].m_Point.Y())
			{
				// Favor left at same Y.
				if (currentPoint.m_Point.X() < m_Points[lowestIndex].m_Point.X())
				{
					lowestIndex = i;
				}
			}
		}
    }

	m_FirstPoint = lowestIndex;

	return lowestIndex;
}


void H_Contour::FindAngles()
{
    int numPoints = m_Points.NumElements() - 1;

	for (int currIndex = 0; currIndex < numPoints; currIndex++)
	{
		int prevIndex = currIndex - 1;
		if (prevIndex < 0)
		{
			prevIndex = numPoints - 1;
		}

		int nextIndex = currIndex + 1;
		if (nextIndex >= numPoints)
		{
			nextIndex = 0;
		}

		H_ContourPoint& previousPoint = m_Points[prevIndex];
		H_ContourPoint& currentPoint = m_Points[currIndex];
		H_ContourPoint& nextPoint = m_Points[nextIndex];

		H_Vector2f inVector(currentPoint.m_Point - previousPoint.m_Point);
		H_Vector2f outVector(currentPoint.m_Point - nextPoint.m_Point);

		float angle = AngleBetween(inVector, outVector);

		currentPoint.m_Angle = angle;
	}

	H_ContourPoint& last = m_Points.Last();
	H_ContourPoint& first = m_Points.First();

	last = first;
	last.m_Index = m_Points.NumElements() - 1;

}


void H_Contour::FindDirections()
{
    int numPoints = m_Points.NumElements() - 1;

    for (int currIndex = 0; currIndex < numPoints; currIndex++)
    {
		int prevIndex = currIndex - 1;

		if (prevIndex < 0)
		{
			prevIndex = numPoints - 1;
		}

        int nextIndex = currIndex + 1;

        if (nextIndex >= numPoints)
        {
            nextIndex = 0;
        }

		H_ContourPoint& previousPoint = m_Points[prevIndex];
        H_ContourPoint& currentPoint  = m_Points[currIndex];
        H_ContourPoint& nextPoint     = m_Points[nextIndex];

		currentPoint.CalcDirection(previousPoint, nextPoint);
    }

	H_ContourPoint& last = m_Points.Last();
	H_ContourPoint& first = m_Points.First();

	last = first;
	last.m_Index = m_Points.NumElements() - 1;

}

// Some extrema have a line section instead of a point. 
// we need to identify these so we can match with others or match to a point extrema.
// Expects Extrema to have already been identified with FindExtrema.
void H_Contour::FindFlatExtrema()
{
	H_ArrayList<H_ContourPoint> temp = m_Points;

	m_Points.Clear();

	for (int i = 0; i < temp.NumElements(); i++)
	{
		temp[i].m_FlatExtrema = false;
	}

	int numPoints = temp.NumElements() - 1;

    for (int currIndex = 0; currIndex < numPoints; currIndex++)
    {
        int prevIndex = currIndex - 1;
        if (prevIndex < 0)
        {
            prevIndex = numPoints - 1;
        }

        int next1Index = currIndex + 1;
        if (next1Index >= numPoints)
        {
            next1Index = 0;
        }

		int next2Index = next1Index + 1;

		if (next1Index >= numPoints)
		{
			next2Index = 0;
		}

        H_ContourPoint& previousPoint = temp[prevIndex];
        H_ContourPoint& currentPoint  = temp[currIndex];
        H_ContourPoint& next1Point    = temp[next1Index];
        H_ContourPoint& next2Point    = temp[next2Index];

		m_Points.Add(currentPoint);

		if (currentPoint.m_ExtremaType != H_ContourPoint::E_NONE)
		{
			if (	(currentPoint.m_ExtremaType == next1Point.m_ExtremaType)	&&
					(currentPoint.m_Smooth)										&&
					(next1Point.m_Smooth)										&&
					(previousPoint.m_Type		== H_ContourPoint::OFF_CURVE)	&&
					(next2Point.m_Type			== H_ContourPoint::OFF_CURVE)	)
			{
				currentPoint.m_FlatExtrema = true;
			//	currentPoint.m_IsExtremum = false; // Set so we don't match, and flat extrema are always at the 'end' of a section.
				next1Point.m_FlatExtrema   = true;

				H_Vector2f midPoint = H_Interpolate(currentPoint.m_Point, next1Point.m_Point, 0.5f);
				H_ContourPoint newPoint(H_ContourPoint::ON_CURVE, midPoint);
				m_Points.Add(newPoint);
			}
		}

    }
	m_Points.Add(temp.Last());

	H_ContourPoint& last = m_Points.Last();
	H_ContourPoint& first = m_Points.First();

	last = first;
	last.m_Index = m_Points.NumElements() - 1;
}

void H_Contour::FindExtrema()
{
	int numPoints = m_Points.NumElements() - 1;

    for (int currIndex = 0; currIndex < numPoints; currIndex++)
    {
        int prevIndex = currIndex - 1;
        if (prevIndex < 0)
        {
            prevIndex = numPoints - 1;
        }

        int nextIndex = currIndex + 1;
        if (nextIndex >= numPoints)
        {
            nextIndex = 0;
        }

        H_ContourPoint& previousPoint = m_Points[prevIndex];
        H_ContourPoint& currentPoint  = m_Points[currIndex];
        H_ContourPoint& nextPoint     = m_Points[nextIndex];

		H_Vector2f inVector (currentPoint.m_Point - previousPoint.m_Point);
		H_Vector2f outVector(currentPoint.m_Point - nextPoint.m_Point);

		bool areLinear = AreLinear(inVector, outVector, H_COLINEAR);

		currentPoint.m_IsExtremum = false;
		currentPoint.m_Index = currIndex;

		if (currentPoint.m_Type == H_ContourPoint::ON_CURVE)
		{
			if (true == areLinear)
			{
				currentPoint.m_Smooth = true;
			}

			if (false == areLinear)
			{
				currentPoint.m_IsExtremum = true;
			}

			if ((currentPoint.m_Point[0] >= previousPoint.m_Point[0]) && (currentPoint.m_Point[0] >= nextPoint.m_Point[0]))
			{
				currentPoint.m_ExtremaType = H_ContourPoint::E_RIGHT;
				currentPoint.m_IsExtremum = true;
			}
			if ((currentPoint.m_Point[0] <= previousPoint.m_Point[0]) && (currentPoint.m_Point[0] <= nextPoint.m_Point[0]))
			{
				currentPoint.m_ExtremaType = H_ContourPoint::E_LEFT;
				currentPoint.m_IsExtremum = true;
			}
			if ((currentPoint.m_Point[1] >= previousPoint.m_Point[1]) && (currentPoint.m_Point[1] >= nextPoint.m_Point[1]))
			{
				currentPoint.m_ExtremaType = H_ContourPoint::E_TOP;
				currentPoint.m_IsExtremum = true;
			}
			if ((currentPoint.m_Point[1] <= previousPoint.m_Point[1]) && (currentPoint.m_Point[1] <= nextPoint.m_Point[1]))
			{
				currentPoint.m_ExtremaType = H_ContourPoint::E_BOTTOM;
				currentPoint.m_IsExtremum = true;
			}

			if (((m_Points[prevIndex].m_Type == H_ContourPoint::ON_CURVE) && (m_Points[currIndex].m_Type == H_ContourPoint::ON_CURVE)) ||
				((m_Points[nextIndex].m_Type == H_ContourPoint::ON_CURVE) && (m_Points[currIndex].m_Type == H_ContourPoint::ON_CURVE)))
			{
				currentPoint.m_IsExtremum = true;
			}
		}
    }

	H_ContourPoint& last = m_Points.Last();
	H_ContourPoint& first = m_Points.First();

	last = first;
	last.m_Index = m_Points.NumElements() - 1;

	//FindFlatExtrema();
}

/*

void H_Contour::FindPositions()
{
	H_BoundingBox bounds;

	GetPointBounds(bounds);

	float width = bounds.Width();
	float height = bounds.Height();

    int numPoints = m_Points.NumElements();

	for (int i = 0; i < numPoints; i++)
	{
		H_ContourPoint& currentPoint = m_Points[i];

		float x = currentPoint.m_Point.X();
		float y = currentPoint.m_Point.Y();

		x -= bounds.Left();
		y -= bounds.Bottom();

		currentPoint.m_NormalX = (x / width)  * 40.0f;
		currentPoint.m_NormalY = (y / height) * 40.0f;
	}
}
*/


