// Copyright (C) 2016 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// H_OffsetContour.cpp

#include "H_OffsetContour.h"

H_OffsetContour::H_OffsetContour()
{
    m_Points.Clear();
}

H_OffsetContour::H_OffsetContour(H_Contour& contour)
{
	m_Points.Clear();

	m_Points.Add(H_Offset(0.0f, 0.0f, true));

	H_ContourPoint currentPoint = contour.GetPoint(0);
	H_ContourPoint lastPoint;

    for (int i = 1; i < contour.NumPoints(); i++)
    {
		lastPoint = currentPoint;
		currentPoint = contour.GetPoint(i);

		float x = currentPoint.m_Point.X() - lastPoint.m_Point.X();
		float y = currentPoint.m_Point.Y() - lastPoint.m_Point.Y();

		m_Points.Add(H_Offset(x, y, true));
    }
}

H_ArrayList<H_Offset>& H_OffsetContour::GetOffsets()
{
	return m_Points;
}


