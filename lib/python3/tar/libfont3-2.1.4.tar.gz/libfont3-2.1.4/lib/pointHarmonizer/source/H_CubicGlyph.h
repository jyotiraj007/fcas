// Copyright (C) 2015 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
/// \file CubicGlyph.h

#ifndef H_CUBIC_GLYPH_H
#define H_CUBIC_GLYPH_H

#include "H_CubicContour.h"
#include "H_QuadGlyph.h"
#include <stdio.h>

class H_CubicGlyph 
{
    public:

        /* CTOR */ H_CubicGlyph   (int designUnits = DEFAULT_CUBIC_UNITS);

        void            Clear           ();
        void            AddContour      (H_CubicContour& contour);
        int             NumContours     ();
        H_CubicContour*   GetContour      (int index);

        H_CubicContour*	FirstContour     ();
        H_CubicContour*	NextContour      ();

        int             GetDesignUnits  ();

    protected:

        H_LinkedList<H_CubicContour>	m_Contours;
        int								m_DesignUnits;
};

#endif
