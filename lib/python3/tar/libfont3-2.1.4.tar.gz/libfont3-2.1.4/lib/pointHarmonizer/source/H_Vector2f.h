// Copyright (C) 2014 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
/// \file H_Vector2f.h

#ifndef H_VECTOR2_F_H
#define H_VECTOR2_F_H

class H_Vector2i;

//! Provides 2D vector (float) operations
/*!
    Defines vector addition, subtraction, and comparison. Permits indexed access to vector components. 
    See also Vector2.
*/
class H_Vector2f
{
   public:

       enum  Direction { eCO_LINEAR = 0, eCLOCK_WISE, eANTI_CLOCK_WISE };

        /* Ctor */      H_Vector2f        ();
        /* Ctor */      H_Vector2f        (float x, float y);
        /* Ctor */      H_Vector2f        (const H_Vector2f& other);
		/* Ctor */		H_Vector2f		  (const H_Vector2i& other);

		H_Vector2f		Rounded()		 const;

        const float&    operator[]          (int i) const;
        float&          operator[]          (int i);
        float           X                   () const;
        float           Y                   () const;
        H_Vector2f     operator-           (const H_Vector2f& other) const;
        H_Vector2f     operator+           (const H_Vector2f& other) const;
        H_Vector2f     operator+=          (const H_Vector2f& other);

        bool            operator==          (const H_Vector2f& other) const;
        bool            operator!=          (const H_Vector2f& other) const;

        float           LengthSquared       () const;
        float           Length				() const;
		void            Normalize			();

        friend
        H_Vector2f     operator*           (float scale, const H_Vector2f& other);

        void            FromFixed           (long x, long y);

        bool            IsValid             () const;
		bool            IsInteger			() const;
		bool            OnInteger			() const;

        friend
        float           PointDistance		(const H_Vector2f& one, const H_Vector2f& two);

        friend
        float           PointDistanceSquared(const H_Vector2f& one, const H_Vector2f& two);

        friend
        float           DotProduct			(const H_Vector2f& one, const H_Vector2f& two);

        friend
        float           AngleBetween		(const H_Vector2f& one, const H_Vector2f& two);

		friend
		bool            AreLinear			(const H_Vector2f& one, const H_Vector2f& two, float epsilon);

		friend
		bool            SameDirection		(const H_Vector2f& one, const H_Vector2f& two, float epsilon);

        friend
        Direction       Orientation			(const H_Vector2f& p, const H_Vector2f& q, const H_Vector2f& r);

		friend
        float           ManhattenDistance(const H_Vector2f& one, const H_Vector2f& two);

		static bool		SortOnY(H_Vector2f& a, H_Vector2f& b);

		void            Print	();

    protected:

        float           m_X;
        float           m_Y;
};


/**
    Access to coordinates.
    @param[in] i Coordinate index
    @return Coordinate value.
*/

inline const float& H_Vector2f::operator[](int i) const
{
    if (i == 0)
        return m_X;
    else
        return m_Y;
}


inline float& H_Vector2f::operator[](int i)
{
    if (i == 0)
        return m_X;
    else
        return m_Y;
}

inline float H_Vector2f::X() const
{
    return m_X;
}

inline float H_Vector2f::Y() const
{
    return m_Y;
}

#endif
