// Copyright (C) 2016 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// H_GlyphCompositor.h

#ifndef H_GLYPH_COMPOSITOR_H
#define H_GLYPH_COMPOSITOR_H


#include "H_Trie.h"
#include "H_QuadGlyph.h"
#include "H_CubicGlyph.h"
#include "H_NormalizedContour.h"
#include "H_IndexTable.h"
#include "H_Array.h"
#include "H_Stack.h"
#include "H_ComboArrayList.h"
#include "H_CompositQuadBezier.h"

//typedef H_IndexTable<H_QuadGlyph> H_GlyphTable;
typedef H_ArrayList<H_QuadGlyph> H_QuadGlyphTable;
typedef H_ArrayList<H_CubicGlyph> cubicGlyphTable;

struct H_ContourData
{
	H_ContourData()
		:	m_NestingLevel	(-1),
			m_AveragePoint	(),
			m_Selected		(false)
	{	};

	H_ContourData(int nestLevel, H_Vector2f averagePoint)
		:	m_NestingLevel	(nestLevel), 
			m_AveragePoint	(averagePoint),
			m_Selected		(false)
	{	};

	int			m_NestingLevel;
	H_Vector2f	m_AveragePoint;
	bool        m_Selected;
};

class H_GlyphHarmonizer
{
    public:
		enum H_Result { eFAILED = 0, eSUCCESS, eINVALID_INPUT };

        /* CTOR */	H_GlyphHarmonizer	();
		/* DTOR */ ~H_GlyphHarmonizer	();

        void        Clear               ();

		bool        HarmonizeGlyph		(H_ArrayList<H_QuadGlyph>& glyphs, int fontUnits, 
										 bool skipContourCheck, bool dontAddExtrema, bool skipStartPointCheck,
		 								 bool verbose = false);

		H_Result	HarmonizeGlyph		(H_ArrayList<H_CubicGlyph>& inputGlyphs, H_ArrayList<H_QuadGlyph>& outputGlyphs);

		void		SetDebugLevel		(int level);

    protected:

		void			SortContours	(H_ArrayList<H_QuadGlyph>& glyphs);
		void			SortContoursGenetic (H_ArrayList<H_QuadGlyph>& glyphs);

		void			MatchFirstPoints(H_ArrayList<H_QuadGlyph>& glyphs);
		void            MatchFirstPoints(H_ArrayList<H_QuadContour>& contours, H_ArrayList<int>& firstPoints);

		bool			MatchPoints		(H_ArrayList<H_QuadGlyph>& glyphs);
		bool			MatchPoints		(H_ArrayList<H_QuadContour*>& contours, int contourNumber);

		void			CheckBeziers		(H_ArrayList<H_QuadContour*>& contours);
		void			RemoveDegeneratePoints(H_ArrayList<H_QuadContour*>& contours);

		void			MatchContourExtrema	(H_ArrayList<H_QuadContour*>& contours);
		void			MatchSectionExtrema (H_ArrayList<H_QuadContour*>& contours);
		void			MatchSectionOnCurve (H_ArrayList<H_QuadContour*>& contours);
		void                    MatchFlatExtrema	(H_ArrayList<H_QuadContour*>& contours);

		void			CollapseStartLines	(H_ArrayList<H_QuadContour*>& contours);
		void			CollapseEndLines	(H_ArrayList<H_QuadContour*>& contours);
		void			MatchBezierToBezier	(H_ArrayList<H_QuadContour*>& contours);
		void			ReflowSmoothPoints	(H_ArrayList<H_QuadContour*>& contours);


		void			SplitAtKinks        (H_ArrayList<H_QuadContour*>& contours);
		void			SplitAtKinkPoints	(H_ArrayList<H_QuadContour*>& contours);
		void			MatchSingleBezier	(H_ArrayList<H_QuadContour*>& contours);
		void			MatchLineSegment    (H_ArrayList<H_QuadContour*>& contours);
		void			ReflowInflections   (H_ArrayList<H_QuadContour*>& contours);


		void			MakePoints			(H_ArrayList<H_QuadContour*>& contours);

		bool			ReflowBezier(H_OutlineSection* pSection, H_Comparision comparision, int numPoints = 0);
		int             LowestPoints(H_OutlineSection* pSection);

		void			LineToBezier(H_OutlineSection* pSection, int numPoints);

		bool			CheckMatch	(H_ArrayList<H_QuadContour*>& contours);
		bool			AreValid	(H_ArrayList<H_QuadContour*>& contours);

		H_QuadContour*	BestFit			(H_QuadContour& contour, H_LinkedList<H_QuadContour>& localList); 
		H_QuadContour*	Closest		(H_QuadContour* pContour, H_LinkedList<H_QuadContour>& localList);
		int				ClosestPoint(H_ContourData& point, H_ArrayList<H_ContourData>& list);



		bool			CheckPoints(H_ArrayList<H_ContourPoint>& points);

		bool            CheckPointers	(H_ArrayList<H_QuadContour*>& contours);
		bool			CountToEnd		(H_ArrayList<H_ListElem<H_OutlineSection>* >& elementPointers);

		H_ListElem<H_QuadContour>*	FindContour	(H_LinkedList<H_QuadContour>& list, int number);

		bool			CheckHarmoneous	(H_ArrayList<H_QuadGlyph>& glyphs);
		void			CreateHarmoneousSections(H_ArrayList<H_QuadContour*>& contours);

		bool            CheckEqualContours(H_ArrayList<H_QuadGlyph>& glyphs);

		void			LabelIndices	(H_ArrayList<H_QuadGlyph>& glyphs);


		int m_DebugLevel;
		bool m_Verbose;

		H_Result		ConvertContourSet(H_ArrayList<H_CubicContour*>& cubicContours, H_ArrayList<H_QuadContour>& quadContours);
		void            AddContour		 (H_ArrayList<H_QuadGlyph>& outputGlyphs, H_ArrayList<H_QuadContour>& quadContours);
};

#endif
