// Copyright (C) 2015 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// H_QuadContour.cpp

#include "H_QuadContour.h"
#include "H_QuadBezier.h"
#include "H_MathUtilities.h"
#include "H_BoundingBox.h"
#include "H_LinkedList.h"
#include "H_OutlineSection.h"
#include "H_CompositQuadBezier.h"
#include "H_OrientedMinimumBoundingBox.h"

bool H_QuadContour::m_Verbose = false;

H_QuadContour::H_QuadContour()
    :   H_Contour(),
        m_ScaledBounds(),
        m_GlyphBounds(),
        m_Tag(false),
        m_Number(-1)
{
}

H_QuadContour::H_QuadContour(const H_QuadContour& other)
	: H_Contour(other)
{
	m_ScaledBounds = other.m_ScaledBounds;

	m_Index = other.m_Index;
	m_CurrentPoint = other.m_CurrentPoint;
	m_LastPoint = other.m_LastPoint;
	m_Tag = other.m_Tag;

	m_Sections = other.m_Sections;

	m_OutlineSections = other.m_OutlineSections;

	m_MatchedExtrema   = other.m_MatchedExtrema;
	m_MatchingIndecesA = other.m_MatchingIndecesA;
	m_MatchingIndecesB = other.m_MatchingIndecesB;

	m_Bounds = other.m_Bounds;
	m_GlyphBounds = other.m_GlyphBounds;
	m_NestingLevel = other.m_NestingLevel;
}


H_QuadContour&  H_QuadContour::operator = (const H_QuadContour& other)
{
	m_ScaledBounds = other.m_ScaledBounds;

	m_Index = other.m_Index;
	m_CurrentPoint = other.m_CurrentPoint;
	m_LastPoint = other.m_LastPoint;
	m_Tag = other.m_Tag;

	m_Sections = other.m_Sections;

	m_OutlineSections = other.m_OutlineSections;

	m_MatchingIndecesA = other.m_MatchingIndecesA;
	m_MatchingIndecesB = other.m_MatchingIndecesB;

	m_Points = other.m_Points;

	m_Bounds = other.m_Bounds;
	m_GlyphBounds = other.m_GlyphBounds;
	m_NestingLevel = other.m_NestingLevel;

	return *this;
}

void H_QuadContour::SetGlyphBounds(H_BoundingBox& bounds)
{
	m_GlyphBounds = bounds;
}

H_BoundingBox& H_QuadContour::GetGlyphBounds()
{
	return m_GlyphBounds;
}

void H_QuadContour::SetNumber(int number)
{
	m_Number = number;
}

int H_QuadContour::GetNumber()
{
	return m_Number;
}

int H_QuadContour::LastIndex()
{
	return NumPoints() - 1;
}

bool H_QuadContour::GetFirstQuad(H_QuadPoints& points, int fromIdx, int toIdx)
{
    m_Index = 0;
    m_CurrentPoint = fromIdx;
	m_LastPoint	   = toIdx;
    
    return GetNextQuad(points);
 }


H_LinkedList<H_OutlineSection>*  H_QuadContour::GetOutlineSections()
{
	return &m_OutlineSections;
}

H_OutlineSection* H_QuadContour::FirstOutlineSection()
{
	return m_OutlineSections.First();
}

H_OutlineSection* H_QuadContour::NextOutlineSection()
{
	return m_OutlineSections.Next();
}

int H_QuadContour::FirstExtremaIdx()
{
	int index = -1;
	m_CurrentIndex = 0;

	while (m_CurrentIndex < m_Points.NumElements())
	{
		if (m_Points[m_CurrentIndex].m_IsExtremum)
		{
			index = m_CurrentIndex;
			break;
		}
		m_CurrentIndex++;
	}
	
	return index;
}

int H_QuadContour::NextExtremaIdx()
{
	int index = -1;

	m_CurrentIndex++;

	while (m_CurrentIndex < m_Points.NumElements())
	{
		if (m_Points[m_CurrentIndex].m_IsExtremum)
		{
			index = m_CurrentIndex;
			break;
		}
		m_CurrentIndex++;
	}
	
	return index;
}

int H_QuadContour::FirstOnCurveIdx()
{
	int index = -1;
	m_CurrentIndex = 0;

	while (m_CurrentIndex < m_Points.NumElements())
	{
		if (m_Points[m_CurrentIndex].m_Type == H_ContourPoint::ON_CURVE)
		{
			index = m_CurrentIndex;
			break;
		}
		m_CurrentIndex++;
	}
	
	return index;
}

int H_QuadContour::NextOnCurveIdx()
{
	int index = -1;

	m_CurrentIndex++;

	while (m_CurrentIndex < m_Points.NumElements())
	{
		if (m_Points[m_CurrentIndex].m_Type == H_ContourPoint::ON_CURVE)
		{
			index = m_CurrentIndex;
			break;
		}
		m_CurrentIndex++;
	}
	
	return index;
}


H_ContourPoint* H_QuadContour::GetFirstExtrema()
{
	H_ContourPoint* pPoint = NULL;

	int currentIndex = 0;

	while (pPoint == NULL && currentIndex < m_Points.NumElements())
	{
		if (m_Points[currentIndex].m_IsExtremum)
		{
			pPoint = &m_Points[currentIndex];
		}
		currentIndex++;
	}
	
	return pPoint;
}

H_ContourPoint* H_QuadContour::GetNextExtrema(H_ContourPoint* pCurrent)
{
	H_ContourPoint* pPoint = NULL;
	
	if (pCurrent != NULL)
	{
		int currentIndex = pCurrent->m_Index;

		currentIndex++;

		while (pPoint == NULL && currentIndex < m_Points.NumElements())
		{
			if (m_Points[currentIndex].m_IsExtremum)// see above.
			//if (m_Points[currentIndex].m_Type == H_ContourPoint::ON_CURVE)
			{
				pPoint = &m_Points[currentIndex];
			}
			currentIndex++;
		}
	}

	return pPoint;
}


bool H_QuadContour::GetNextQuad(H_QuadPoints& points)
{
    bool foundQuad = false;

    while (foundQuad == false && m_CurrentPoint <= m_LastPoint)
    {
        H_ContourPoint& currentPoint = m_Points[m_CurrentPoint];     

        switch (currentPoint.m_Type)
        {
            case H_ContourPoint::ON_CURVE:

                m_Point[m_Index] = currentPoint.m_Point;
                m_Index++;

                // If it's a line strip it out.
                if (m_Index == 2)
                {
                    m_Point[0] = m_Point[1];
                    m_Index = 1;
                }

                if (m_Index == 3)
                {
                    points.m_Start    = m_Point[0];
                    points.m_Control  = m_Point[1];
                    points.m_End      = m_Point[2];

                    m_Point[0] = m_Point[2];
                    m_Index = 1;
                    foundQuad = true;
                }

            break;

            case H_ContourPoint::OFF_CURVE:

                m_Point[m_Index] = currentPoint.m_Point;
                m_Index++;

                if (m_Index == 3)
                {
                    H_Vector2f midPoint = H_Interpolate(m_Point[1], m_Point[2], 0.5f);
                    
                    points.m_Start    =  m_Point[0];
                    points.m_Control  =  m_Point[1];
                    points.m_End      =  midPoint;

                    m_Point[0] = midPoint;
                    m_Point[1] = m_Point[2];
                    m_Index = 2;
                    foundQuad = true;
                }

            break;
        }

        m_CurrentPoint++;
    }

    return foundQuad;
}

bool H_QuadContour::GetFirstLine(H_Line2D& line, int fromIdx, int toIdx)
{
    m_Index = 0;
    m_CurrentPoint	= fromIdx;
	m_LastPoint		= toIdx;

    return GetNextLine(line);
}

bool H_QuadContour::GetNextLine(H_Line2D& line)
{
    bool foundLine = false;

    while (foundLine == false && m_CurrentPoint <= m_LastPoint)
    {
        H_ContourPoint& currentPoint = m_Points[m_CurrentPoint];     

        switch (currentPoint.m_Type)
        {
            case H_ContourPoint::ON_CURVE:

                m_Point[m_Index] = currentPoint.m_Point;
                m_Index++;

                if (m_Index == 2)
                {
                    line = H_Line2D(m_Point[0], m_Point[1]);
                    foundLine = true;
                    m_Point[0] = m_Point[1];
                    m_Index = 1;
                }

                // If it's a quad stip it out.
                if (m_Index == 3)
                {
                    m_Point[0] = m_Point[2];
                    m_Index = 1;
                }

            break;

            case H_ContourPoint::OFF_CURVE:
            
                m_Point[m_Index] = currentPoint.m_Point;
                m_Index++;

                if (m_Index == 3)
                {
                     m_Index = 2;
                }
            break;
        }

        m_CurrentPoint++;
    }

    return foundLine;
}


bool H_QuadContour::Contains(H_Vector2f& point)
{
    const float LARGE_FLOAT = 1e5f;

    bool containsPoint = false;
    float y = point.Y();

    H_Line2D line(H_Vector2f(-LARGE_FLOAT, y), H_Vector2f(LARGE_FLOAT, y));

    H_ArrayList<H_Vector2f> intersections;

    if (Intersects(line))
    {
        GetIntersections(line, intersections);

        int count = 0;
        for (int i = 0; i < intersections.NumElements(); i++)
        {
            if (intersections[i].X() < point.X())
            {
                count++;
            }
        }
        if (count % 2 == 1)
        {
            containsPoint = true;
        }
        else
        {
            containsPoint = false;
        }
    }

    return containsPoint;
}

bool H_QuadContour::Contains(H_QuadContour& other)
{
    const float EPSILON = 0.005f;

	int pointsContained = 0;

	int numPoints = other.NumPoints();

	for (int i = 0; i < other.NumPoints(); i++)
	{
		H_ContourPoint point = other.GetPoint(i);
        point.m_Point[1] += EPSILON;

        if (Contains(point.m_Point))
        {
			pointsContained++;
        }
    }

	float percent = (float) pointsContained / (float) numPoints;

	bool contains = false;

	// Leave some wiggle for overlapping contours.
	if (percent > 0.75f)
	{
		contains = true;
	}

    return contains;
}

/*
bool H_QuadContour::Contains(H_QuadContour& other)
{
    const float EPSILON = 0.005f;

    if (other.NumPoints() > 0)
    {
        H_ContourPoint point = other.GetPoint(0);
        point.m_Point[1] += EPSILON;

        if (Contains(point.m_Point))
        {
            if (false == Intersects(other))
            {
                return true;
            }
        }
    }
    return false;
}
*/

bool H_QuadContour::Intersects(H_QuadContour& otherContour)
{
    H_Line2D line;

    bool newLine = GetFirstLine(line, 0, LastIndex());

    while (newLine)
    {
        if (otherContour.Intersects(line))
        {
            return true;
        }
        newLine = GetNextLine(line);
    }

    H_QuadPoints quadPoints;
    
    bool newQuad = GetFirstQuad(quadPoints, 0, LastIndex());

    while (newQuad)
    {
        H_QuadBezier quad(quadPoints);

        if (otherContour.Intersects(quad))
        {
            return true;
        }
        newQuad = GetNextQuad(quadPoints);
    }

    return false;
}


bool H_QuadContour::Intersects(H_Line2D& line)
{
    H_Line2D contourLine;

    bool newLine = GetFirstLine(contourLine, 0, LastIndex());

    while (newLine)
    {
        if (contourLine.Intersects(line))
        {
            return true;
        }
        newLine = GetNextLine(contourLine);
    }

    H_QuadPoints quadPoints;
    
    bool newQuad = GetFirstQuad(quadPoints, 0, LastIndex());

    while (newQuad)
    {
        H_QuadBezier quad(quadPoints);

        if (quad.Intersects(line))
        {
            return true;
        }
        newQuad = GetNextQuad(quadPoints);
    }
    
    return false;
}


bool H_QuadContour::Intersects(H_QuadBezier& quad)
{
    H_Line2D contourLine;

    bool newLine = GetFirstLine(contourLine, 0, LastIndex());

    while (newLine)
    {
        if (quad.Intersects(contourLine))
        {
            return true;
        }
        newLine = GetNextLine(contourLine);
    }

    H_QuadPoints quadPoints;
    
    bool newQuad = GetFirstQuad(quadPoints, 0, LastIndex());

    while (newQuad)
    {
        H_QuadBezier contourQuad(quadPoints);

        if (quad.Intersects(contourQuad))
        {
            return true;
        }
        newQuad = GetNextQuad(quadPoints);
    }
    
    return false;
}


void H_QuadContour::GetIntersections(H_Line2D& line, H_ArrayList<H_Vector2f>& intersections)
{
    H_Line2D contourLine;

    bool newLine = GetFirstLine(contourLine, 0, LastIndex());

    while (newLine)
    {
        contourLine.GetIntersections(line, intersections);

        newLine = GetNextLine(contourLine);
    }

    H_QuadPoints quadPoints;

    bool newQuad = GetFirstQuad(quadPoints, 0, LastIndex());

    while (newQuad)
    {
        H_QuadBezier quad(quadPoints);

        quad.GetIntersections(line, intersections);

        newQuad = GetNextQuad(quadPoints);
    }
}


bool H_QuadContour::IsSinglePoint(H_BoundingBox& boundsBox)
{
    if (1 == NumPoints())
    {
        H_ContourPoint pt = GetPoint(0);
        boundsBox.ExpandLeft(pt.m_Point.X());
        boundsBox.ExpandRight(pt.m_Point.X());
        boundsBox.ExpandTop(pt.m_Point.Y());
        boundsBox.ExpandBottom(pt.m_Point.Y());

        return true;
    }

    return false;
}



void H_QuadContour::SetScaledBounds(H_ScaleOffset& scaleOffset)
{
	H_BoundingBox bounds;

	GetBounds(bounds);

	bounds.ApplyScaleOffset(scaleOffset);

	m_ScaledBounds = bounds;

}


H_BoundingBox& H_QuadContour::GetScaledBounds()
{
	return m_ScaledBounds;
}

// Bounds of the actual contour/outline. Might be larger than the point bounds.
bool H_QuadContour::GetBounds(H_BoundingBox& boundsBox)
{
    H_QuadPoints  quad;
    H_Line2D      line;

    if (IsSinglePoint(boundsBox))
    {
        return false;
    }

    bool newLine = GetFirstLine(line, 0, LastIndex());

    if (newLine)
    {
        boundsBox.Expand(line.Start());
    }

    while (newLine)
    {
        boundsBox.Expand(line.End());

        newLine = GetNextLine(line);
    }

    bool leftTangent    = false;
    bool rightTangent   = false;
    bool topTangent     = false;
    bool bottomTangent  = false;

    bool newQuad = GetFirstQuad(quad, 0, LastIndex());

    while (newQuad)
    {
        H_QuadBezier quadBezier(quad);

        if (boundsBox.ExpandLeft(quadBezier.LeftExtent()))
        {
            leftTangent = quadBezier.LeftIsTangent();
        }

        if (boundsBox.ExpandRight(quadBezier.RightExtent()))
        {
            rightTangent = quadBezier.RightIsTangent();
        }

        if (boundsBox.ExpandTop(quadBezier.TopExtent()))
        {
            topTangent = quadBezier.TopIsTangent();
        }

        if (boundsBox.ExpandBottom(quadBezier.BottomExtent()))
        {
            bottomTangent = quadBezier.BottomIsTangent();
        }

        newQuad = GetNextQuad(quad);
    }

    return (!leftTangent && !rightTangent && !topTangent && !bottomTangent);
}


void H_QuadContour::CheckWinding()
{
    bool windingOk = false;

    H_Handedness handedness = GetHandedness();

    if ((m_NestingLevel % 2) == 1)
    {
        if (handedness == eH_CCW)
        {
            windingOk = true;
        }
    }
    else
    {
        if (handedness == eH_CW)
        {
            windingOk = true;
        }
    }

	if (false == windingOk)
	{
		Reverse();
	}
}

void H_QuadContour::ClearMatchedExtrema()
{
	m_MatchedExtrema.Clear();
}

void H_QuadContour::AddMatchedExtrema(int index)
{
	m_MatchedExtrema.Add(index);
}

int H_QuadContour::FirstOnCurve()
{
	m_CurrentIndex = 0;

	return NextOnCurve();
}

int H_QuadContour::NextOnCurve()
{
	int index = -1;

	while (m_CurrentIndex < m_Points.NumElements())
	{
		if (m_Points[m_CurrentIndex].m_Type == H_ContourPoint::ON_CURVE)
		{
			index = m_CurrentIndex;
			m_CurrentIndex++;
			break;
		}
		m_CurrentIndex++;
	}

	return index;
}


void H_QuadContour::CreateHarmoneousSections()
{
	m_OutlineSections.RemoveAll();

	int startIndex	= FirstOnCurve();
	int endIndex	= NextOnCurve();

	while (endIndex != -1)
	{
		H_OutlineSection section;

		for (int i = startIndex; i <= endIndex; i++)
		{
			H_ContourPoint& point = GetPoint(i);
			section.AddPoint(point);
		}

		m_OutlineSections.Add(section);

		startIndex = endIndex;
		endIndex = NextOnCurve();
	}
}


// Create sections using all the extrema we found.
// We'll use this list to find and add any missing extrema points.
// before we try and match.
void H_QuadContour::CreateUnMatchedSections()
{
	m_OutlineSections.RemoveAll();

	// Find the first extrema.
	m_FirstPoint = FirstExtremaIdx();

	if (m_FirstPoint != -1)
	{
		// Make it at 0
		ReOrder();

		int startIndex = FirstOnCurveIdx();//FirstExtremaIdx();
		int endIndex = NextOnCurveIdx(); //  NextExtremaIdx();

		while (endIndex != -1)
		{
			H_OutlineSection section;

			for (int i = startIndex; i <= endIndex; i++)
			{
				H_ContourPoint& point = GetPoint(i);
				section.AddPoint(point);
			}

			m_OutlineSections.Add(section);

			startIndex = endIndex;
			endIndex = NextOnCurveIdx();// NextExtremaIdx();
		}
	}
	else // No extrema in this contour!
	{
		// Create a single section.
		H_OutlineSection section;

		for (int i = 0; i < m_Points.NumElements(); i++)
		{
			H_ContourPoint& point = GetPoint(i);
			section.AddPoint(point);
		}

		m_OutlineSections.Add(section);
	}
}



void H_QuadContour::CreateSections()
{
	m_OutlineSections.RemoveAll();

	int startIndex = m_MatchedExtrema[0];

	int endIndex;

	for (int i = 1; i < m_MatchedExtrema.NumElements(); i++)
	{
		endIndex = m_MatchedExtrema[i];

		H_OutlineSection section;

		section.SetContourHeight((int) m_Bounds.Height());

		for (int j = startIndex; j <= endIndex; j++)
		{
			H_ContourPoint& point = GetPoint(j);
			section.AddPoint(point);
		}
		m_OutlineSections.Add(section);

		startIndex = endIndex;
	}
}


// Check for contour extrema that don't have an on curve point on them.
// uses isextrema etc.
// recalc these when done.
// Maybe just do a quick calc extrema before createUnmatched extrema.
void H_QuadContour::AddMissingExtrema() 
{
	H_ListElem<H_OutlineSection>* pElement = m_OutlineSections.GetFirstElement();

	while (pElement)
	{
		H_OutlineSection& section = pElement->m_Data;

		if (false == section.OnCurveAtExtrema())
		{
			pElement = CreateExtrema(section);

		}

		pElement = m_OutlineSections.GetNext(pElement);
	}
}

void H_QuadContour::RemoveRedundantPoints()
{
	H_ArrayList<H_ContourPoint> newPoints;

	newPoints.Add(m_Points.First());

	for (int i = 1; i < m_Points.NumElements(); i++)
	{
		H_ContourPoint& currentPoint = m_Points[i];
		H_ContourPoint& lastPoint = newPoints.Last();

		if (currentPoint.m_Point != lastPoint.m_Point)
		{
			newPoints.Add(currentPoint);
		}
		else if (currentPoint.m_Type == H_ContourPoint::ON_CURVE)
		{
			newPoints.Last() = currentPoint;
		}
	}

	m_Points = newPoints;

	ReNumberPoints();
}

void H_QuadContour::ReNumberPoints()
{
	for (int i = 0; i < m_Points.NumElements(); i++)
	{
		m_Points[i].m_Index = i;
	}
}

void H_QuadContour::RemoveLinearBezier()
{
	H_ListElem<H_OutlineSection>* pElement = m_OutlineSections.GetFirstElement();

	while (pElement)
	{
		H_OutlineSection& section = pElement->m_Data;

		section.RemoveLinearSegments();

		pElement = m_OutlineSections.GetNext(pElement);
	}
}

void H_QuadContour::MakePoints()
{
	m_Points.Clear();

	int currentIndex = 0;

	H_OutlineSection* pSection = m_OutlineSections.First();

	if (pSection)
	{
		// Add the first point of the contour.
		H_ContourPoint& firstPoint = pSection->GetPoint(0);

		firstPoint.m_Index = currentIndex;

		m_Points.Add(firstPoint);

		// for each section add all the others.
		while (pSection)
		{
			for (int i = 1; i < pSection->NumPoints(); i++)
			{
				currentIndex++;
				H_ContourPoint& currentPoint = pSection->GetPoint(i);
				//int idx = currentPoint.m_Index;
				//if (idx < 0)
 				//	printf("%d", idx);
				currentPoint.m_Index = currentIndex;

				m_Points.Add(currentPoint);
			}

			pSection = m_OutlineSections.Next();
		}
	}
}

/*
void H_QuadContour::MakePoints()
{
	m_Points.Clear();

	int currentIndex = 0;

	H_ListElem<H_OutlineSection>* pElement = m_OutlineSections.GetFirstElement();

	if (pElement)
	{
		H_OutlineSection& firstSection = pElement->m_Data;

		//bb
		H_ContourPoint firstPoint = firstSection.GetPoint(0);

		firstPoint.m_Index = currentIndex;

		m_Points.Add(firstPoint);

		while (pElement)
		{
			H_OutlineSection section = pElement->m_Data;

			H_ContourPoint currentPoint = section.GetPoint(0);

			currentPoint.m_Index = currentIndex;

			for (int i = 1; i < section.NumPoints(); i++)
			{
				currentIndex++;
				currentPoint = section.GetPoint(i);
				currentPoint.m_Index = currentIndex;

				m_Points.Add(currentPoint);
			}

			pElement = m_OutlineSections.GetNext(pElement);
		}
	}
}
*/

float H_QuadContour::ShortestDistance(H_Vector2f& point)
{
	float shortestDistance = H_FLOAT_MAX;

	for (int i = 0; i < NumPoints(); i++)
	{
		H_ContourPoint& currentPoint = m_Points[i];

		if (currentPoint.m_Type == H_ContourPoint::ON_CURVE)
		{
			float distance = PointDistance(currentPoint.m_Point, point);

			if (distance < shortestDistance)
			{
				shortestDistance = distance;
			}
		}
	}

	return shortestDistance;
}

float H_QuadContour::Distance(H_QuadContour* pOther)
{
	float distance = 0.0f;

	for (int i = 0; i < NumPoints(); i++)
	{
		if (m_Points[i].m_Type == H_ContourPoint::ON_CURVE)
		{
			distance += pOther->ShortestDistance(m_Points[i].m_Point);
		}
	}

	return distance;
}


bool H_QuadContour::Matches(H_QuadContour* pOther)
{
	bool matches = true;

	bool sameNumber = (NumPoints() == pOther->NumPoints());

	for (int i = 0; i < NumPoints(); i++)
	{
		if (GetPoint(i).m_Type != pOther->GetPoint(i).m_Type)
		{
			matches = false;
			break;
		}
	}

	return sameNumber && matches;

}

int H_QuadContour::FindBestMatch(H_ContourPoint* pPoint, bool useIndex /* = true */)
{
	int index = -1;
	H_ContourPoint* pThisExtrema  = GetFirstExtrema();

	int bestScore = INT_MAX; // lowest score wins.
	int bestIndex = -1;

	while (pThisExtrema)
	{
		int currentScore = pPoint->ScoreMatch(*pThisExtrema, useIndex);

		if (currentScore < bestScore)
		{
			bestScore = currentScore;
			bestIndex = pThisExtrema->m_Index;
		}
		pThisExtrema = GetNextExtrema(pThisExtrema);
	}

	if (bestIndex >= 0 && bestScore < 200) // bb cut off for matching.
	{
		index = bestIndex;
	}

	return index;
}

H_ListElem<H_OutlineSection>* H_QuadContour::SplitAt(H_OutlineSection& section, int index)
{
	H_OutlineSection a;
	H_OutlineSection b;

	if (index == 0 || index == section.NumPoints() - 1)
	{
		if (m_Verbose)
			printf("Bad Split!\n");
	}

	for (int i = 0; i <= index; i++)
	{
		a.AddPoint(section.GetPoint(i));
	}

	for (int i = index; i < section.NumPoints(); i++)
	{
		b.AddPoint(section.GetPoint(i));
	}

	H_ListElem<H_OutlineSection>* pSectionA = (H_ListElem<H_OutlineSection>*) m_OutlineSections.AllocElem(a);
	H_ListElem<H_OutlineSection>* pSectionB = (H_ListElem<H_OutlineSection>*) m_OutlineSections.AllocElem(b);

	H_ListElem<H_OutlineSection>* pSectionElem = m_OutlineSections.Find(section);

	m_OutlineSections.InsertAfter(pSectionElem, pSectionA);
	m_OutlineSections.InsertAfter(pSectionA, pSectionB);

	m_OutlineSections.Remove(pSectionElem);

	return pSectionA;
}



H_ListElem<H_OutlineSection>* H_QuadContour::AddStartLine(H_OutlineSection& section)
{
	H_OutlineSection a;
	H_OutlineSection b;

	a.AddPoint(section.GetPoint(0));
	a.AddPoint(section.GetPoint(0));

	for (int i = 0; i < section.NumPoints(); i++)
	{
		b.AddPoint(section.GetPoint(i));
	}

	H_ListElem<H_OutlineSection>* pSectionA = (H_ListElem<H_OutlineSection>*) m_OutlineSections.AllocElem(a);
	H_ListElem<H_OutlineSection>* pSectionB = (H_ListElem<H_OutlineSection>*) m_OutlineSections.AllocElem(b);

	H_ListElem<H_OutlineSection>* pSectionElem = m_OutlineSections.Find(section);

	m_OutlineSections.InsertAfter(pSectionElem, pSectionA);
	m_OutlineSections.InsertAfter(pSectionA, pSectionB);

	m_OutlineSections.Remove(pSectionElem);

	return pSectionA;
}


H_ListElem<H_OutlineSection>* H_QuadContour::AddEndLine(H_OutlineSection& section)
{
	H_OutlineSection a;
	H_OutlineSection b;

	for (int i = 0; i < section.NumPoints(); i++)
	{
		a.AddPoint(section.GetPoint(i));
	}

	b.AddPoint(section.GetPoint(section.NumPoints() - 1));
	b.AddPoint(section.GetPoint(section.NumPoints() - 1));


	H_ListElem<H_OutlineSection>* pSectionA = (H_ListElem<H_OutlineSection>*) m_OutlineSections.AllocElem(a);
	H_ListElem<H_OutlineSection>* pSectionB = (H_ListElem<H_OutlineSection>*) m_OutlineSections.AllocElem(b);

	H_ListElem<H_OutlineSection>* pSectionElem = m_OutlineSections.Find(section);

	m_OutlineSections.InsertAfter(pSectionElem, pSectionA);
	m_OutlineSections.InsertAfter(pSectionA, pSectionB);

	m_OutlineSections.Remove(pSectionElem);

	return pSectionA;
}

H_ListElem<H_OutlineSection>* H_QuadContour::CreateExtrema(H_OutlineSection& section)
{
	H_ArrayList<H_ContourPoint> contourPoints;
	section.ResolvePoints(contourPoints);
	H_CompositQuadBezier compositBezier(contourPoints);

	H_ArrayList<H_ContourPoint> points;

	compositBezier.Evaluate(0.05f);

	H_ListElem<H_OutlineSection>* pSectionElem = m_OutlineSections.Find(section);
	H_ListElem<H_OutlineSection>* pLastSectionElem = pSectionElem;

	while (compositBezier.SplitAtFirstExtrema(points, 1, 1.0f))
	{
		H_OutlineSection newSection;

		for (int i = 0; i < points.NumElements(); i++)
		{
			newSection.AddPoint(points[i]);
		}

		H_ListElem<H_OutlineSection>* pSection = (H_ListElem<H_OutlineSection>*) m_OutlineSections.AllocElem(newSection);

		m_OutlineSections.InsertAfter(pLastSectionElem, pSection);

		pLastSectionElem = pSection;
	}

	m_OutlineSections.Remove(pSectionElem);

	return pLastSectionElem;

}

H_ListElem<H_OutlineSection>* H_QuadContour::SplitBezierSection(H_OutlineSection& section, float distance)
{
	H_ArrayList<H_ContourPoint> contourPoints;
	section.ResolvePoints(contourPoints);

	H_CompositQuadBezier compositBezier(contourPoints);

	H_ArrayList<H_ContourPoint> pointsA;
	H_ArrayList<H_ContourPoint> pointsB;

	if (distance < 0.0f || distance > 1.0f)
	{
		if (m_Verbose)
			printf("Bad distance. Split Bezier. \n");
	}

	compositBezier.Split(pointsA, pointsB, 1, 1, distance, 1.0f);

	if (pointsA.NumElements() == 0 || pointsB.NumElements() == 0)
	{
		if (m_Verbose)
			printf("Bad split. Bezier\n");
	}


	H_OutlineSection a;
	H_OutlineSection b;


	for (int i = 0; i < pointsA.NumElements(); i++)
	{
		a.AddPoint(pointsA[i]);
	}

	for (int i = 0; i < pointsB.NumElements(); i++)
	{
		b.AddPoint(pointsB[i]);
	}

	H_ListElem<H_OutlineSection>* pSectionA = (H_ListElem<H_OutlineSection>*) m_OutlineSections.AllocElem(a);
	H_ListElem<H_OutlineSection>* pSectionB = (H_ListElem<H_OutlineSection>*) m_OutlineSections.AllocElem(b);

	H_ListElem<H_OutlineSection>* pSectionElem = m_OutlineSections.Find(section);

	m_OutlineSections.InsertAfter(pSectionElem, pSectionA);
	m_OutlineSections.InsertAfter(pSectionA, pSectionB);

	m_OutlineSections.Remove(pSectionElem);

	return pSectionA;
}


H_ListElem<H_OutlineSection>* H_QuadContour::SplitSingleBezier(H_OutlineSection& section, float distance)
{
	H_OutlineSection a;
	H_OutlineSection b;

	H_QuadPoints pointsA;
	H_QuadPoints pointsB;

	H_QuadBezier bezier(section.GetPoint(0).m_Point, section.GetPoint(2).m_Point, section.GetPoint(1).m_Point);

	bezier.SplitAt(distance, pointsA, pointsB);

	H_ContourPoint startA;
	H_ContourPoint controlA;
	H_ContourPoint endA;

	startA.m_Point		= pointsA.m_Start;
	startA.m_Type		= H_ContourPoint::ON_CURVE;
	controlA.m_Point	= pointsA.m_Control;
	controlA.m_Type		= H_ContourPoint::OFF_CURVE;
	endA.m_Point		= pointsA.m_End;
	endA.m_Type			= H_ContourPoint::ON_CURVE;

	a.AddPoint(startA);
	a.AddPoint(controlA);
	a.AddPoint(endA);

	H_ContourPoint startB;
	H_ContourPoint controlB;
	H_ContourPoint endB;

	startB.m_Point		= pointsB.m_Start;
	startB.m_Type		= H_ContourPoint::ON_CURVE;
	controlB.m_Point	= pointsB.m_Control;
	controlB.m_Type		= H_ContourPoint::OFF_CURVE;
	endB.m_Point		= pointsB.m_End;
	endB.m_Type			= H_ContourPoint::ON_CURVE;

	b.AddPoint(startB);
	b.AddPoint(controlB);
	b.AddPoint(endB);


	H_ListElem<H_OutlineSection>* pSectionA = (H_ListElem<H_OutlineSection>*) m_OutlineSections.AllocElem(a);
	H_ListElem<H_OutlineSection>* pSectionB = (H_ListElem<H_OutlineSection>*) m_OutlineSections.AllocElem(b);

	H_ListElem<H_OutlineSection>* pSectionElem = m_OutlineSections.Find(section);

	m_OutlineSections.InsertAfter(pSectionElem, pSectionA);
	m_OutlineSections.InsertAfter(pSectionA, pSectionB);

	m_OutlineSections.Remove(pSectionElem);

	return pSectionA;
}


H_ListElem<H_OutlineSection>* H_QuadContour::SplitLineSegment(H_OutlineSection& section, float distance)
{
	H_OutlineSection a;
	H_OutlineSection b;

	if (distance < 0.0f || distance > 1.0f)
	{
		if (m_Verbose)
			printf("Bad line Split!\n");
	}

	if (section.NumPoints() != 2)
	{
		if (m_Verbose)
			printf("Not 2 point line!\n");
	}

	H_Vector2f start = section.GetPoint(0).m_Point;
	H_Vector2f end   = section.GetPoint(1).m_Point;

	H_Vector2f splitPoint = H_Interpolate(start, end, distance);

	H_ContourPoint startA;
	H_ContourPoint endA;

	startA.m_Point = start;
	startA.m_Type = H_ContourPoint::ON_CURVE;
	endA.m_Point = splitPoint;
	endA.m_Type = H_ContourPoint::ON_CURVE;

	a.AddPoint(startA);
	a.AddPoint(endA);

	H_ContourPoint startB;
	H_ContourPoint endB;

	startB.m_Point = splitPoint;
	startB.m_Type = H_ContourPoint::ON_CURVE;
	endB.m_Point = end;
	endB.m_Type = H_ContourPoint::ON_CURVE;

	b.AddPoint(startB);
	b.AddPoint(endB);


	H_ListElem<H_OutlineSection>* pSectionA = (H_ListElem<H_OutlineSection>*) m_OutlineSections.AllocElem(a);
	H_ListElem<H_OutlineSection>* pSectionB = (H_ListElem<H_OutlineSection>*) m_OutlineSections.AllocElem(b);

	H_ListElem<H_OutlineSection>* pSectionElem = m_OutlineSections.Find(section);

	m_OutlineSections.InsertAfter(pSectionElem, pSectionA);
	m_OutlineSections.InsertAfter(pSectionA, pSectionB);

	m_OutlineSections.Remove(pSectionElem);

	return pSectionA;
}

int H_QuadContour::NumOnCurve()
{
	int numPoints = m_Points.NumElements();

	int count = 0;

	for (int i = 0; i < numPoints; i++)
	{
		H_ContourPoint& currentPoint = m_Points[i];

		if (currentPoint.m_Type == H_ContourPoint::ON_CURVE)
		{
			count++;
		}
	}

	return count;
}


void H_QuadContour::FindPositions()
{
	GetPointBounds(m_Bounds);

	float width = m_Bounds.Width();
	float height = m_Bounds.Height();

    int numPoints = m_Points.NumElements();

	for (int i = 0; i < numPoints; i++)
	{
		H_ContourPoint& currentPoint = m_Points[i];

		float x = currentPoint.m_Point.X();
		float y = currentPoint.m_Point.Y();

		x -= m_Bounds.Left();
		y -= m_Bounds.Bottom();

		float normX = x / width;
		float normY = y / height;

		currentPoint.m_NormalX = normX;
		currentPoint.m_NormalY = normY;
	}
}


H_Vector2f H_QuadContour::GetAveragePoint()
{
	int numPoints = m_Points.NumElements();

	float xTotal = 0.0f;
	float yTotal = 0.0f;
	int count = 0;

	for (int i = 0; i < numPoints; i++)
	{
		H_ContourPoint& currentPoint = m_Points[i];

		//if (currentPoint.m_Type == H_ContourPoint::ON_CURVE)
		{
			xTotal += currentPoint.m_Point.X();
			yTotal += currentPoint.m_Point.Y();
			count++;
		}
	}

	return H_Vector2f(xTotal / (float) count, yTotal / (float) count);
}

bool H_QuadContour::IsValid()
{
	bool isValid = true;

	H_OutlineSection* pCurrentSection = m_OutlineSections.First();

	bool foundSections = (pCurrentSection != NULL);

	while (pCurrentSection)
	{
		isValid &= pCurrentSection->IsValid();
		pCurrentSection = m_OutlineSections.Next();
	}

	if (false == foundSections)
	{
		for (int i = 0; i < m_Points.NumElements(); i++)
		{
			isValid &= m_Points[i].IsValid();
		}
	}

	return isValid;
}