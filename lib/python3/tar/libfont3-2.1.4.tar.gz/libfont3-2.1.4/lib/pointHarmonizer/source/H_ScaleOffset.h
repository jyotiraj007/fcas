// Copyright (C) 2016 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// H_ScaleOffset.h

#ifndef H_SCALE_OFFSET_H
#define H_SCALE_OFFSET_H

#include <math.h>
#include <stdlib.h>

class H_ScaleOffset
{
    public:
        float   m_ScaleX;
        float   m_ScaleY;
        int     m_OffsetX;
        int     m_OffsetY;

        /* CTOR */ H_ScaleOffset   ();

        bool    operator == (const H_ScaleOffset& other);
        bool    operator != (const H_ScaleOffset& other);
};

inline H_ScaleOffset::H_ScaleOffset()
    :   m_ScaleX    (1.0f),
        m_ScaleY    (1.0f),
        m_OffsetX   (0),
        m_OffsetY   (0)
{
}

inline bool H_ScaleOffset::operator != (const H_ScaleOffset& other)
{
    float EPSILON = 0.1f;

    bool notEqual = false;

    if (fabs(m_ScaleX - other.m_ScaleX) > EPSILON ||
        fabs(m_ScaleY - other.m_ScaleY) > EPSILON ||
        abs(m_OffsetX - other.m_OffsetX) >= 2 ||
        abs(m_OffsetY - other.m_OffsetY) >= 2)
    {
        notEqual = true;
    }

    return notEqual;
}

inline bool H_ScaleOffset::operator == (const H_ScaleOffset& other)
{
    bool equal = false;

    if (    (m_ScaleX   == other.m_ScaleX ) &&
            (m_ScaleY   == other.m_ScaleY ) &&
            (m_OffsetX  == other.m_OffsetX) &&
            (m_OffsetY  == other.m_OffsetY) )
    {
        equal = true;
    }

    return equal;
}



#endif

