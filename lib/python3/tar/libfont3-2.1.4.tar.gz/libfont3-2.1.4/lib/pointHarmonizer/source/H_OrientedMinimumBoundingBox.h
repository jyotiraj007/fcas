#ifndef ORIENTED_MINIMUM_BOUNDING_BOX_H
#define ORIENTED_MINIMUM_BOUNDING_BOX_H

#include "H_Vector2f.h"
#include "H_MathUtilities.h"
#include <float.h>

class H_OrientedMinimumBoundingBox
{
    public:
        /* CTOR */  H_OrientedMinimumBoundingBox();

        float       Area();

        H_Vector2f    m_TopLeft;
        H_Vector2f    m_TopRight;
        H_Vector2f    m_BottomLeft;
        H_Vector2f    m_BottomRight;
};

// Implementation:
inline H_OrientedMinimumBoundingBox::H_OrientedMinimumBoundingBox() 
    :   m_TopLeft       (),
        m_TopRight      (),
        m_BottomLeft    (),
        m_BottomRight   ()
{
};


inline float H_OrientedMinimumBoundingBox::Area()
{
    H_Vector2f topSide = m_TopRight - m_TopLeft;
    float width    = topSide.Length();

    H_Vector2f leftSide = m_TopLeft - m_BottomLeft;
    float height     = leftSide.Length();

    float area = width * height;

    return area;
}

#endif

