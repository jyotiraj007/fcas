// Copyright (C) 2016 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// H_ContourSection.h

#ifndef H_CONTOUR_SECTION_H
#define H_CONTOUR_SECTION_H

#include <math.h>
#include <stdlib.h>
#include "H_ContourPoint.h"

class H_ContourSection
{
    public:
		/* CTOR */ H_ContourSection() {};
		/* CTOR */ H_ContourSection(const H_ContourSection& other) : m_StartPoint(other.m_StartPoint), m_EndPoint(other.m_EndPoint) { };

		bool       operator == (const H_ContourSection& other) 
		{
			bool same = false;

			if ((m_StartPoint == other.m_StartPoint) &&
				(m_EndPoint == other.m_EndPoint))
			{
				same = true;
			}
			return same;
		}

		H_ContourPoint m_StartPoint;
		H_ContourPoint m_EndPoint;
};



#endif

