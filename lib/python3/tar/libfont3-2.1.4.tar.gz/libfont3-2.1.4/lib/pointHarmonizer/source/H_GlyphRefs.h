// Copyright (C) 2016 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// H_GlyphRefs.h

#ifndef H_GLYPH_REFS_H
#define H_GLYPH_REFS_H

#include "H_ArrayList.h"


struct H_GlyphRefs
{
    int            m_GlyphId;            // This glyphId.

    H_ArrayList<int> m_SequenceIds;
    H_ArrayList<int> m_ContourIndex;      // Index of sequence id's int the source glyph.

    H_ArrayList<int> m_ComponentIds;       // GlyphId of component.

    void    Print()
    {
        printf("Glyph Ref: \n");
        printf("    glyphId: %d\n", m_GlyphId);

        printf("    Sequence ids: \n");
        for (int i = 0; i < m_SequenceIds.NumElements(); i++)
        {
            printf("        %d: \n", m_SequenceIds[i]);
        }

        printf("    Components: \n");
        for (int i = 0; i < m_ComponentIds.NumElements(); i++)
        {
            printf("        %d: \n", m_ComponentIds[i]);
        }
    }

};


#endif
