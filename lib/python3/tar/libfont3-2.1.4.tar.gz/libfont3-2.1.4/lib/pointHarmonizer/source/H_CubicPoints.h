#ifndef H_CUBIC_POINTS_H
#define H_CUBIC_POINTS_H

#include "H_Vector2f.h"

struct H_CubicPoints
{
    H_Vector2f    m_Start;
    H_Vector2f    m_End;
    H_Vector2f    m_Control1;
    H_Vector2f    m_Control2;

    H_CubicPoints() {};


    H_CubicPoints(const H_Vector2f& start, const H_Vector2f& end, const H_Vector2f& control1, const H_Vector2f& control2)
        :   m_Start     (start),
            m_End       (end),
            m_Control1  (control1),
            m_Control2  (control2)
    {
    }

    void Set(const H_Vector2f& start, const H_Vector2f& end, const H_Vector2f& control1, const H_Vector2f& control2)
    {
        m_Start         = start;
        m_End           = end;
        m_Control1      = control1;
        m_Control2      = control2;
    }

    bool IsLinear(float tolerance)
    {
        bool linear = false;
 
        H_Line2D line(m_Start, m_End);

        if ( (line.PointDistance(m_Control1) < tolerance) &&
             (line.PointDistance(m_Control2) < tolerance) )
        {
            linear = true;
        }

        return linear;
    }
};

#endif
