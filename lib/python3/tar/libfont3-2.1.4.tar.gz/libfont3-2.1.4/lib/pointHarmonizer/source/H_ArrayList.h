// Copyright (C) 2016 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// H_ArrayList.h

#ifndef H_ARRAY_LIST_H
#define H_ARRAY_LIST_H

#include <assert.h>
#include <stdio.h>
#include <limits.h>
#include "H_Stack.h"

template <class T> class H_ArrayList
{
		enum { DEFAULT_SLOTS = 4 };
		enum { MIN_SIZE = 4 };

	public:

		/* Ctor */      H_ArrayList();
		/* Ctor */		H_ArrayList(int numElements, const T& value = T());

		/* Ctor */      H_ArrayList(const H_ArrayList& other);
		/* Ctor */      H_ArrayList(H_ArrayList& other, int from, int to);
		/* Dtor */ virtual    ~H_ArrayList();
		H_ArrayList&   operator=       (const H_ArrayList& other);
		H_ArrayList&   operator+=      (H_ArrayList& other);

		void            AppendRange		(H_ArrayList& other, int from, int to);

		bool            Contains		(const T& element) const;
		bool            Contains		(const H_ArrayList<T>& other) const;

		bool            operator     == (const H_ArrayList<T>& other) const;
		void            Subtract		(const H_ArrayList<T>& other, H_ArrayList<T>& difference);

		int             NumElements		() const;
		int             Find			(T& value);
		int             Add				();
		int             Add				(const T& newElement);

		int             AddUnique		(const T& newElement);
		T&              operator[]      (int index);
		const T&        operator[]      (int index) const;

		T&              First	();
		T&              Last	();
		T&              New		();

		int             FirstIdx() const;
		int             LastIdx() const;

		void            Clear			();
		void            SetNumElements	(int numElements, const T& value = T());
		void            ResetIndex		();

		void            Reverse();

		void			Sort(bool(*Compare)(T& a, T& b));

		void            Sort        (bool ascending = true);
		void            SortedOrder	(H_ArrayList<int>& indexOrder, bool ascending = true);

		bool            AllSame();

		void            GetLongestIncreasingSubsequence(H_ArrayList<T>& subsequence);

		void            PrintMem();
		void            SetSentry(T x) { m_Sentry = x; };

	protected:

		void            FreeAll	();       // WARNING. For use by H_Linked list only, which creates a static pool using H_ArrayList.

		void            SetSize			(int newSize);
		void			SortDescendingInPlace(int left, int right);
		void			SortAscendingInPlace(int left, int right);

		void			SortDescendingIndeces(H_ArrayList<int>& indexOrder, int left, int right);
		void			SortAscendingIndeces (H_ArrayList<int>& indexOrder, int left, int right);

		int				GetSize() const;

		bool			IsValidIndex(int index) const;
		int				GetInitialSize(int desiredSize) const;

		void			Grow();
		void			GrowSlots();

		T**			m_pSlots;
		T			m_Sentry;

		int			m_Size;                  // How many T's do we currently have room for.
		int			m_NumElems;              // How many elements in our array.
		int			m_SmallestSlotSize;      // How many T's in the smallest slot.

		unsigned int m_UsedSlots;			// how many of the T* above have been malloc'd.
		unsigned int m_TotalSlots;			// m_pSlots is T**, how many T* do we have.


		friend class ls_coreTests;         // Let the unit tests have at it.

		template <class U>  
		friend class H_LinkedList;
};

template <class T>
void H_ArrayList<T>::PrintMem()
{
    printf("\n");
    printf("m_UsedSlots: %d\n", m_UsedSlots);
    printf("m_Size: %d\n", m_Size);
    printf("m_NumElems: %d\n", m_NumElems);
    printf("m_SmallestSlotSize: %d\n", m_SmallestSlotSize);
}

template <class T>
H_ArrayList<T>::H_ArrayList()
   :	m_Size              (0),
        m_NumElems          (0),
        m_SmallestSlotSize  (0),
        m_UsedSlots         (0),
        m_TotalSlots        (DEFAULT_SLOTS)
{
    m_pSlots = new T*[m_TotalSlots];
}

template <class T>
H_ArrayList<T>::H_ArrayList(int numElements, const T& value /* = T() */) 
   :	m_Size              (0),
        m_NumElems          (0),
        m_SmallestSlotSize  (0),
        m_UsedSlots         (0),
        m_TotalSlots        (DEFAULT_SLOTS)
{
    m_pSlots = new T*[m_TotalSlots];

    SetNumElements(numElements, value);
}

template <class T>
H_ArrayList<T>::H_ArrayList(const H_ArrayList& other)
   :	m_Size              (0),
        m_NumElems          (0),
        m_SmallestSlotSize  (0),
        m_UsedSlots         (0),
        m_TotalSlots        (DEFAULT_SLOTS)
{
    int numElems = other.NumElements();

    m_pSlots = new T*[m_TotalSlots];

    for (int i = 0; i < numElems; i++)
    {
        Add(other[i]);
    }
}

template <class T>
H_ArrayList<T>::H_ArrayList(H_ArrayList& other, int from, int to) 
   :	m_Size              (0),
        m_NumElems          (0),
        m_SmallestSlotSize  (0),
        m_UsedSlots         (0),
        m_TotalSlots        (DEFAULT_SLOTS)
{
    m_pSlots = new T*[m_TotalSlots];

    for (int i = from; i <= to; i++)
    {
        Add(other[i]);
    }
}

template <class T>
bool H_ArrayList<T>::Contains(const T& element) const
{
    for (int i = 0; i < NumElements(); i++)
    {
        if (operator[](i) == element)
        {
            return true;
        }
    }
    return false;
}

template <class T>
bool H_ArrayList<T>::Contains(const H_ArrayList<T>& other) const
{
    bool contains = true;

    if ((other.NumElements() == 0) ||
        (NumElements() <= other.NumElements()))
    {
        return false;
    }

    int i = 0;

    while (contains && i < other.NumElements())
    {
        contains = contains && Contains(other[i]);
        i++;
    }

    return contains;
}

template <class T>
void H_ArrayList<T>::Subtract(const H_ArrayList<T>& other, H_ArrayList<T>& difference)
{
    for (int i = 0; i < NumElements(); i++)
    {
        if (false == other.Contains(operator[](i)))
        {
            difference.Add(operator[](i));
        }
    }
}


template <class T>
int H_ArrayList<T>::Find(T& value)
{
    int index = -1;

    for (int i = 0; i < NumElements(); i++)
    {
        if (operator[](i) == value)
        {
            index = i;
            break;
        }
    }

    return index;
}

template <class T>
H_ArrayList<T>& H_ArrayList<T>::operator=(const H_ArrayList& other)
{
    if (this != &other)
    {
        Clear();
        int numElems = other.NumElements();
        for (int i = 0; i < numElems; i++)
        {
            Add(other[i]);
        }
    }
    return *this;
}

template <class T>
bool H_ArrayList<T>::operator==(const H_ArrayList& other) const
{
	bool sameNumber = (NumElements() == other.NumElements());

	bool sameElements = true;

	if (sameNumber)
	{
		for (int i = 0; i < NumElements(); i++)
		{
			if (operator[](i) != other[i])
			{
				sameElements = false;
				break;
			}
		}
	}

	return sameNumber && sameElements;
}



template <class T>
H_ArrayList<T>& H_ArrayList<T>::operator+=(H_ArrayList& other)
{
    if (this != &other)
    {
        int numElems = other.NumElements();
        for (int i = 0; i < numElems; i++)
        {
            Add(other[i]);
        }
    }
    return *this;
}


template <class T>
void H_ArrayList<T>::AppendRange(H_ArrayList& other, int from, int to)
{
    if (this != &other)
    {
        int numElems = other.NumElements();

        if ((from < 0) || (to < 0))
            return;
        if (from > to)
            return;
        if (from > numElems - 1)
            return;
        if (to > numElems - 1)
            return;

        for (int i = from; i <= to; i++)
        {
            Add(other[i]);
        }
    }
}

template <class T>
H_ArrayList<T>::~H_ArrayList()
{
    Clear();    //lint !e1551

	if (m_pSlots != NULL)
	{
		delete[] m_pSlots;
		m_pSlots = NULL;
	}
}


// WARNING. For use by H_Linked list only, which creates a static pool using H_ArrayList.
template <class T>
void H_ArrayList<T>::FreeAll()
{
	Clear();

	if (m_pSlots != NULL)
	{
		delete[] m_pSlots;
		m_pSlots = NULL;
	}
}

template <class T>
int H_ArrayList<T>::GetInitialSize(int size) const
{
    int power = 1;

    // Find next larger power of 2.
    while (power < size)
    {
        power <<= 1;                       //lint !e701
    }

    // Take the next smaller power of 2.
    power >>= 1;                            //lint !e702

    return power;
}

template <class T>
int H_ArrayList<T>::Add()
{
    int index = m_NumElems;
    m_NumElems++;

    if (m_Size == 0)
    {
        SetSize(MIN_SIZE);
    }

    while (index >= m_Size)
    {
        Grow();
    }

    return index;
}

template <class T>
int H_ArrayList<T>::Add(const T& newElement)
{
    int index = Add();

    operator[](index) = newElement;

    return index;
}

template <class T>
T& H_ArrayList<T>::New()
{
    int index = Add();

    return operator[](index);
}

template <class T>
int H_ArrayList<T>::AddUnique(const T& newElement)
{
    int index = -1;

    if (false == Contains(newElement))
    {
        index = Add(newElement);
    }

    return index;
}

template <class T>
T& H_ArrayList<T>::First()
{
    return operator[](FirstIdx());
}

template <class T>
T& H_ArrayList<T>::Last()
{
    return operator[](LastIdx());
}


template <class T>
int H_ArrayList<T>::FirstIdx() const
{
	return 0;
}

template <class T>
int H_ArrayList<T>::LastIdx() const
{
	return NumElements() - 1;
}

template <class T>
T& H_ArrayList<T>::operator[](int index)
{
    if (IsValidIndex(index))
    {
        int slot = 0;

        if (index >= m_SmallestSlotSize)
        {
            int slotSize = m_SmallestSlotSize;

            while (index >= slotSize)
            {
                slotSize <<= 1;     //lint !e701
                slot++;
            }
            slotSize >>= 1;         //lint !e702

            index -= slotSize;
        }

        return m_pSlots[slot][index];
    }

    return m_Sentry; //lint !e1536  The sentry value is that of the default ctor of the object. It it returned when an invalid index is requested.
}

template <class T>
const T& H_ArrayList<T>::operator[](int index) const
{
    if (IsValidIndex(index))
    {
        int slot = 0;

        if (index >= m_SmallestSlotSize)
        {
            int power = m_SmallestSlotSize;

            while (power <= index)
            {
                power <<= 1;    //lint !e701
                slot++;
            }
            power >>= 1;        //lint !e702

            index -= power;
        }

        return m_pSlots[slot][index];
    }

    return m_Sentry;
}


template <class T>
int H_ArrayList<T>::GetSize() const
{
    return m_Size;
}


template <class T>
int H_ArrayList<T>::NumElements() const
{
    return m_NumElems;
}

template <class T>
void H_ArrayList<T>::SetSize(int newSize)
{
    if (m_UsedSlots >= m_TotalSlots)
    {
        GrowSlots();
    }

    m_Size = GetInitialSize(newSize);
    m_SmallestSlotSize = m_Size;
    m_pSlots[m_UsedSlots] = new T[m_Size];

    m_UsedSlots++;
}

template <class T>
void H_ArrayList<T>::GrowSlots()
{
    T** temp = m_pSlots;
    m_pSlots = new T*[m_TotalSlots * 2];


    for (unsigned int i = 0; i < m_TotalSlots; i++)
    {
        m_pSlots[i] = temp[i];
    }

    m_TotalSlots *= 2;
    delete[] temp;
}

template <class T>
void H_ArrayList<T>::Grow()
{
    if (m_UsedSlots >= m_TotalSlots)
    {
        GrowSlots();
    }

    if (m_Size < 1)
    {
        assert(0);
        return;
    }

    m_pSlots[m_UsedSlots] = new T[m_Size];

    m_UsedSlots++;

    m_Size *= 2;
}

template <class T>
void H_ArrayList<T>::SetNumElements(int numElements, const T& value /* = T() */)
{
    Clear();

    // Allow for less than min size.
    // i.e. alloc min size but only add numElements.
    int required = numElements;

    if (required < MIN_SIZE)
    {
        required = MIN_SIZE;
    }

    SetSize(required);

    for (int i = 0; i < numElements; i++)
    {
        Add(value);
    }
}

template <class T>
void H_ArrayList<T>::Clear()
{
    for (unsigned int i = 0; i < m_UsedSlots; i++)
    {
        delete[](T*) m_pSlots[i];
        m_pSlots[i] = 0;
    }

    m_Size = 0;
    m_UsedSlots = 0;
    m_NumElems = 0;
    m_SmallestSlotSize = 0;
}

template <class T>
bool H_ArrayList<T>::IsValidIndex(int index) const
{
    bool valid = false;

    if ((index >= 0) &&
        (index < m_NumElems))
    {
        valid = true;
    }
    return valid;
}

template <class T>
void H_ArrayList<T>::ResetIndex()
{
    m_NumElems = 0;
}

template <class T>
void H_ArrayList<T>::Reverse()
{
	int numElements = NumElements();

	if (numElements > 1)
	{
		int lastIndex = numElements - 1;

		int halfIndex = (lastIndex / 2) + 1;

		for (int i = 0; i < halfIndex; i++)
		{
			int j = lastIndex - i;

			T temp = operator [] (i);
			operator [] (i) = operator [] (j);
			operator [] (j) = temp;
		}
	}
}


template <class T>
bool H_ArrayList<T>::AllSame()
{
	bool allSame = true;

	T& first = First();

	for (int i = 1; i < NumElements(); i++)
	{
		T& current = operator[](i);

		if (current != first)
		{
			allSame = false;
			break;
		}
	}

	return allSame;
}

template <class T>
void H_ArrayList<T>::Sort(bool (*Compare)(T& a, T& b))
{
    int minIndex;

    int numElements = NumElements();

    for (int j = 0; j < numElements - 1; j++)
    {
        minIndex = j;
        for (int i = j + 1; i < numElements; i++)
        {
            // If this element is less, then it is the new minimum.  
            if (Compare(operator[](i), operator[](minIndex)))
            {
                // Found new minimum; remember its index.
                minIndex = i;
            }
        }

        // iMin is the index of the minimum element.
        // Swap it with the current position.
        if (minIndex != j)
        {
            T temp               = operator[](j);
            operator[](j)        = operator[](minIndex);
            operator[](minIndex) = temp;
        }
    }
}

// Sort the elements.
// T must be or define (int), for comparisions.
template <class T>
void H_ArrayList<T>::Sort(bool ascending /* = true */)
{
    if (ascending)
    {
        SortAscendingInPlace(0, m_NumElems - 1);
    }
    else
    {
        SortDescendingInPlace(0, m_NumElems - 1);
    }
}


template <class T>
void H_ArrayList<T>::SortAscendingInPlace(int left, int right)
{
    int i = left;
    int j = right;

    int pivot = (int) operator[]((left + right) / 2);

    // Partition.
    while (i <= j)
    {
        while ((int) operator[](i) < pivot)
        {
            i++;
        }

        while ((int) operator[](j) > pivot)
        {
            j--;
        }

        if (i <= j)
        {
            T tmp = operator [](i);
            operator[](i) = operator[](j);
            operator[](j) = tmp;

            i++;
            j--;
        }
    };

    // Recursion.
    if (left < j)
    {
        SortAscendingInPlace(left, j);
    }

    if (i < right)
    {
        SortAscendingInPlace(i, right);
    }
}

template <class T>
void H_ArrayList<T>::SortDescendingInPlace(int left, int right)
{
    int i = left;
    int j = right;

    int pivot = (int) operator[]((left + right) / 2);

    // Partition.
    while (i <= j)
    {
        while ((int) operator[](i) > pivot)
        {
            i++;
        }

        while ((int) operator[](j) < pivot)
        {
            j--;
        }

        if (i <= j)
        {
            T tmp = operator [](i);
            operator[](i) = operator[](j);
            operator[](j) = tmp;

            i++;
            j--;
        }
    };

    // Recursion.
    if (left < j)
    {
        SortDescendingInPlace(left, j);
    }

    if (i < right)
    {
        SortDescendingInPlace(i, right);
    }
}


// Fill index order with the indeces of this array in order as defined by operator (int) 
// this avoids swapping the data if it happens to be large.
template <class T>
void H_ArrayList<T>::SortedOrder(H_ArrayList<int>& indexOrder, bool ascending /* = true */)
{
    // Populate our index array with default order.
    indexOrder.SetNumElements(m_NumElems);

    for (int i = 0; i < m_NumElems; i++)
    {
        indexOrder[i] = i;
    }

    // Now do a standard recursive quick sort.

    if (ascending)
    {
        SortAscendingIndeces(indexOrder, 0, m_NumElems - 1);
    }
    else
    {
        SortDescendingIndeces(indexOrder, 0, m_NumElems - 1);
    }
}



// Quick sort that produces array of indeces, rather than swapping T.
template <class T>
void H_ArrayList<T>::SortAscendingIndeces(H_ArrayList<int>& indexOrder, int left, int right)
{
    int i = left;
    int j = right;

    int pivot = (int) operator[](indexOrder[(left + right) / 2]);

    // Partition.
    while (i <= j)
    {
        while ((int) operator[](indexOrder[i]) < pivot)
        {
            i++;
        }

        while ((int) operator[](indexOrder[j]) > pivot)
            {
            j--;
            }

        if (i <= j)
        {
            int tmp = indexOrder[i];
            indexOrder[i] = indexOrder[j];
            indexOrder[j] = tmp;

            i++;
            j--;
        }
    };

    // Recursion.
    if (left < j)
    {
        SortAscendingIndeces(indexOrder, left, j);
    }

    if (i < right)
    {
        SortAscendingIndeces(indexOrder, i, right);
    }
}


// Quick sort that produces array of indeces, rather than swapping T.
template <class T>
void H_ArrayList<T>::SortDescendingIndeces(H_ArrayList<int>& indexOrder, int left, int right)
{
    int i = left;
    int j = right;

    int pivot = (int) operator[](indexOrder[(left + right) / 2]);

    // Partition.
    while (i <= j)
    {
        while ((int) operator[](indexOrder[i]) > pivot)
        {
            i++;
        }

        while ((int) operator[](indexOrder[j]) < pivot)
        {
            j--;
        }

        if (i <= j)
        {
            int tmp = indexOrder[i];
            indexOrder[i] = indexOrder[j];
            indexOrder[j] = tmp;

            i++;
            j--;
        }
    };

    // Recursion.
    if (left < j)
        {
        SortDescendingIndeces(indexOrder, left, j);
        }

    if (i < right)
    {
        SortDescendingIndeces(indexOrder, i, right);
    }
}

// returns indeces.
template <class T>
void H_ArrayList<T>::GetLongestIncreasingSubsequence(H_ArrayList<T>& subsequence)
{
	H_ArrayList<T>& self = *this;

    int bestEnd = 0;
	int numElements = NumElements();

	if (numElements == 0)
	{
		return;
	}

    H_ArrayList<int> previous(numElements,-1);
    H_ArrayList<int> memo	 (numElements, 0);

	int maxLen = INT_MIN;

    memo[0] = 1;

    for (int i = 1; i < numElements; ++i)
    {
        for (int j = 0; j < i; ++j)
        {
            if ( self[j] < self[i] && memo[i] < memo[j] + 1 )
            {
                memo[i]		=  memo[j] + 1;
                previous[i] =  j;
            }
        }

        if ( memo[i] > maxLen) 
        {
            bestEnd = i;
            maxLen = memo[i];
        }
    }

	subsequence.Clear();

    H_Stack<int> stack;

    int current = bestEnd;

    while (current != -1)
    {
        stack.Push(current);
        current = previous[current];
    }

    while (!stack.IsEmpty())
    {
        subsequence.Add(stack.Pop());
    }
}

#endif
