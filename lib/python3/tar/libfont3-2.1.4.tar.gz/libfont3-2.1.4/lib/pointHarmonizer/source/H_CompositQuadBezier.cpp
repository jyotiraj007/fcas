// Copyright (C) 2015 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// CompositQuadBezier.cpp

#include "H_CompositQuadBezier.h"
#include "H_QuadBezier.h"
#include "H_CubicBezier.h"
#include "H_MathUtilities.h"

bool H_CompositQuadBezier::m_Verbose = false;

H_CompositQuadBezier::H_CompositQuadBezier()
	: m_Comparision		(H_EQUALS),
      m_InflectionSet	(false)
{
}
 
H_CompositQuadBezier::H_CompositQuadBezier(H_ArrayList<H_ContourPoint>& points)
	: m_Comparision		(H_EQUALS),
      m_InflectionSet	(false)
{
	AddResolvedPoints(points);
}

void H_CompositQuadBezier::AddResolvedPoints(H_ArrayList<H_ContourPoint>& points)
{
	m_ResolvedPoints.Clear();

	m_ResolvedPoints = points;

	m_InflectionSet = false;
}

void H_CompositQuadBezier::Clear()
{
	m_ResolvedPoints.Clear();
    m_Points.Clear();
}


void H_CompositQuadBezier::Evaluate(float flatness)
{
    CreateSegments(flatness);
    CreateNormals();
    CreateTangents();
}

void H_CompositQuadBezier::CreateSegments(float flatness)
{
    m_CurrentFlatness = flatness;
 
    int numPoints = m_ResolvedPoints.NumElements();

    m_Points.Clear();

	m_Points.Add(m_ResolvedPoints.First().m_Point);

	H_ContourPoint points[4];
	points[0] = m_ResolvedPoints.First();

	int index = 1;

	for (int i = 1; i < numPoints; i++)
	{
		H_ContourPoint& currentPoint = m_ResolvedPoints[i];

		points[index++] = currentPoint;

		if (currentPoint.m_Type == H_ContourPoint::ON_CURVE)
		{
			if (index == 2)
			{
				m_Points.Add(currentPoint.m_Point);
				points[0] = points[1];
				index = 1;
			}
			else if (index == 3)
			{
				H_QuadBezier bezier(points[0].m_Point, points[2].m_Point, points[1].m_Point);
				bezier.Evaluate(m_CurrentFlatness);

				for (int j = 1; j < bezier.NumCurvePoints(); j++)
				{
					m_Points.Add(bezier.GetCurvePoint(j));
				}

				points[0] = points[2];
				index = 1;
			}
		}
		else
		{
			if (index == 3)
			{
				H_QuadBezier bezier(points[0].m_Point, points[2].m_Point, points[1].m_Point);
				bezier.Evaluate(m_CurrentFlatness);

				for (int j = 1; j < bezier.NumCurvePoints(); j++)
				{
					m_Points.Add(bezier.GetCurvePoint(j));
				}

				points[0] = points[2];
				index = 1;
			}
		}
	}
}

bool H_CompositQuadBezier::MatchPoints(H_ArrayList<H_ContourPoint>& points, int numPoints, float tolerance)
{
	bool success = false;

	if ((numPoints == 1) || (m_Comparision == H_LESS_THAN))
	{
		// Check if line segement. distance split may have got us here.
		if (m_Points.NumElements() == 2)
		{
			H_Vector2f midPoint = H_Interpolate(m_Control[eSTART], m_Control[eEND], 0.5f);
			midPoint = midPoint.Rounded();

			H_ContourPoint startPoint	(H_ContourPoint::ON_CURVE, m_Control[eSTART]);
			H_ContourPoint controlPoint	(H_ContourPoint::OFF_CURVE, midPoint);
			H_ContourPoint endPoint		(H_ContourPoint::ON_CURVE, m_Control[eEND]);

			points.Add(startPoint);
			points.Add(controlPoint);
			points.Add(endPoint);

			success = true;

			return success;
		}
		// Try for single quad: 
		float distance;

		m_Tolerance = tolerance;
		H_QuadBezier singleBezier;
		H_Vector2f midPoint = m_StartTangent.Intersection(m_EndTangent);
		midPoint = midPoint.Rounded();

		singleBezier.Init(m_Control[eSTART], m_Control[eEND], midPoint);

		singleBezier.Evaluate(0.05f);// m_CurrentFlatness * 0.2f);

		if (WithinTolerance(singleBezier, distance))
		{
			H_ContourPoint startPoint(H_ContourPoint::ON_CURVE, m_Control[eSTART]);
			H_ContourPoint controlPoint(H_ContourPoint::OFF_CURVE, midPoint);
			H_ContourPoint endPoint(H_ContourPoint::ON_CURVE, m_Control[eEND]);
			points.Add(startPoint);
			points.Add(controlPoint);
			points.Add(endPoint);

			success = true;
			return success;
		}
	}

	m_NumPoints = numPoints;
	m_Depth = 0;
	m_Tolerance = tolerance;

	success = Search(points);
	
	return success;
}


// Match but use the passed in start target.
bool H_CompositQuadBezier::MatchStartTarget(H_ArrayList<H_ContourPoint>& points, int numPoints, float tolerance, H_Comparision comparision, H_Line2D startTarget)
{
	m_Comparision = comparision;

	bool success = false;

	const int NUM_TRIES = 4;
	float flatness[NUM_TRIES] = { 0.05f, 0.001f, 0.0001f, 0.00001f };

	int tries = 0;

	// Keep trying with successively tighter evaluations.
	while (false == success && tries < NUM_TRIES)
	{
		Evaluate(flatness[tries]);

		m_Control[eSTART] = m_Points.First();
		m_Control[eEND]   = m_Points.Last();

		int numResolvedPoints = m_ResolvedPoints.NumElements();
		m_StartTangent = H_Line2D(m_ResolvedPoints[1].m_Point, m_ResolvedPoints[0].m_Point);
		m_EndTangent   = H_Line2D(m_ResolvedPoints[numResolvedPoints-1].m_Point, m_ResolvedPoints[numResolvedPoints-2].m_Point);

		m_StartTangent.Extend(10000.0f);
		m_EndTangent  .Extend(10000.0f);

		m_StartTarget = startTarget;

		success = MatchPoints(points, numPoints, tolerance);
		tries++;
	}

	return success;
}

bool H_CompositQuadBezier::Match(H_ArrayList<H_ContourPoint>& points, int numPoints, float tolerance, H_Comparision comparision)
{
	m_Comparision = comparision;

	bool success = false;

	const int NUM_TRIES = 4;
	float flatness[NUM_TRIES] = { 0.05f, 0.001f, 0.0001f, 0.00001f };

	int tries = 0;

	// Keep trying with successively tighter evaluations.
	while (false == success && tries < NUM_TRIES)
	{
		Evaluate(flatness[tries]);

		m_Control[eSTART] = m_Points.First();
		m_Control[eEND]   = m_Points.Last();

		int numResolvedPoints = m_ResolvedPoints.NumElements();
		m_StartTangent = H_Line2D(m_ResolvedPoints[1].m_Point, m_ResolvedPoints[0].m_Point);
		m_EndTangent   = H_Line2D(m_ResolvedPoints[numResolvedPoints-1].m_Point, m_ResolvedPoints[numResolvedPoints-2].m_Point);

		m_StartTangent.Extend(10000.0f);
		m_EndTangent  .Extend(10000.0f);

		m_StartTarget = m_StartTangent;

		success = MatchPoints(points, numPoints, tolerance);
		tries++;
	}

	return success;
}

bool H_CompositQuadBezier::Search(H_ArrayList<H_ContourPoint>& points)
{
    m_Depth++;
    bool success = false;

    m_BestBeziers.Clear();
    m_BestAverage = H_FLOAT_MAX;

    m_EvalStack.Reset();
    H_Line2D startTangent = m_StartTangent;
    H_Line2D startTarget  = m_StartTarget;

    m_CheckDepth = 0;

    CheckRight(startTangent, startTarget, 0, m_Points.NumElements() - 1);

    int numBeziers = m_BestBeziers.NumElements();

    if (numBeziers > 0)
    {
		success = true;
        int i;
		H_ContourPoint firstPoint(H_ContourPoint::ON_CURVE, m_BestBeziers[0].GetPoint(H_QuadBezier::eSTART));
		points.Add(firstPoint);

		// Emit the beziers to our contour.
        // All beziers have implicit on curve points, so just add controls.
        for (i = 0; i < numBeziers; i++)
        {
            H_QuadBezier& bezier = m_BestBeziers[i];
            H_ContourPoint point(H_ContourPoint::OFF_CURVE, bezier.GetPoint(H_QuadBezier::eCONTROL));
            points.Add(point);
        }

        // Add last on curve point of beziers.
        H_ContourPoint lastPoint(H_ContourPoint::ON_CURVE, m_BestBeziers[i-1].GetPoint(H_QuadBezier::eEND));
        points.Add(lastPoint);
    }

    return success;
}

bool H_CompositQuadBezier::CheckRight(H_Line2D& startTangent, H_Line2D& startTarget, int startIndex, int endIndex)
{
    m_CheckDepth++;

    bool foundSolution = false;

    if (m_CheckDepth < 15000)
    {
        int currentIndex = FindFirst(startTangent, startIndex, endIndex);

        bool intersectsStartTarget  = true;

        while ((false == foundSolution) && (currentIndex > startIndex) && (currentIndex < endIndex))// && intersectsStartTarget)
        {
            H_Line2D currentTangent(m_AllTangents[currentIndex]);

            intersectsStartTarget = currentTangent.Intersects(startTarget);

            if (intersectsStartTarget)
            {
                // Find intersection with current startTarget:
                H_Vector2f startIntersection(currentTangent.Intersection(startTarget));

                currentTangent.Set(startIntersection, m_Points[currentIndex + 1]);
                currentTangent.ExtendEnd(); // Double in length.

                H_Line2D currentTarget(startIntersection, m_Points[currentIndex]);
                currentTarget.ExtendEnd();   // Double the length.
                // CurrentTarget is the overlap 
                currentTarget.Set(currentTarget.End(), currentTangent.End());

                m_EvalStack.Push(currentTangent);

		foundSolution = Score();

                if (false == foundSolution)
                {
                    foundSolution = CheckRight(currentTangent, currentTarget, currentIndex + 1, endIndex);
                }
				/*
                if (currentTarget.Intersects(m_EndTangent))
                {
                    foundSolution = Score();
                }
                else
                {
                    foundSolution = CheckRight(currentTangent, currentTarget, currentIndex + 1, endIndex);
                }
				*/

                m_EvalStack.Pop();
            }

            --currentIndex;
        }
    }
    return foundSolution;
}

int H_CompositQuadBezier::FindFirst(H_Line2D& startTangent, int startIndex, int endIndex)
{
    int currentIndex = startIndex;
    bool intersects = false;

    // First remove any non intersecting segs, usually parallel with tangent.
    while (intersects == false && currentIndex < endIndex)
    {
        H_Line2D currentLine = m_AllTangents[currentIndex];
        intersects = currentLine.Intersects(startTangent);
        currentIndex++;
    }

    // Now find furthest intersecting tangent.
    while (intersects && currentIndex < endIndex)
    {
        H_Line2D currentLine = m_AllTangents[currentIndex];
        intersects = currentLine.Intersects(startTangent);
        currentIndex++;
    }

    currentIndex -= 2;

    if (currentIndex < startIndex)
    {
        currentIndex = startIndex + 1;
    }

    return currentIndex;
}

bool H_CompositQuadBezier::Score()
{
    int numTangents = m_EvalStack.NumElements();

	int numPoints = numTangents + 1;

	switch (m_Comparision)
	{
		case H_EQUALS:
			if (numPoints != m_NumPoints)
			{
				return false; 
			}
		break;

		case H_LESS_THAN:
			if (numPoints >= m_NumPoints)
			{
				return false; 
			}
		break;

		case H_ANY:
		break;
	}

    m_Tangents.ResetIndex();

    m_Tangents.Add(m_StartTangent);

    for (int i = 0; i < numTangents; i++)
    {
        H_Line2D currentTangent = m_EvalStack.ElementAt(i);
        currentTangent.Extend(10000.0f);
        m_Tangents.Add(currentTangent);
    }

    m_Tangents.Add(m_EndTangent);

    m_Intersections.ResetIndex();

    for (int i = 0; i < m_Tangents.NumElements()-1; i++)
    {
        H_Line2D& one = m_Tangents[i];
        H_Line2D& two = m_Tangents[i+1];

        if (false == one.Intersects(two))
        {
            return false;
        }

        H_Vector2f intersection = one.Intersection(two);
        m_Intersections.Add(intersection);
    }

    m_ControlPoints.ResetIndex();

    m_ControlPoints.Add(m_Control[eSTART]);

    for (int i = 0; i < m_Intersections.NumElements()-1; i++)
    {
        H_Vector2f rounded1 = m_Intersections[i].Rounded();
        H_Vector2f rounded2 = m_Intersections[i+1].Rounded();

        H_Vector2f midPoint = H_Interpolate(rounded1, rounded2, 0.5f);
        m_ControlPoints.Add(rounded1);
        m_ControlPoints.Add(midPoint);
    }

    m_ControlPoints.Add(m_Intersections[m_Intersections.NumElements()-1].Rounded());
    m_ControlPoints.Add(m_Control[eEND]);

    float averageDistance = 0.0f;
    m_Beziers.ResetIndex();

    for (int i = 0; i < m_ControlPoints.NumElements()-2; i+=2)
    {
        H_QuadBezier bezier;

        bezier.Init(m_ControlPoints[i], m_ControlPoints[i+2], m_ControlPoints[i+1]);

        m_Beziers.Add(bezier);
    }

    for (int i = 0; i < m_Beziers.NumElements(); i++)
    {
        H_QuadBezier& bezier = m_Beziers[i];
        bezier.Evaluate();

        float distance;

        if (WithinTolerance(bezier, distance))
        {
            averageDistance += distance;
        }
        else
        {
            return false;
        }
    }

    averageDistance /= (numTangents + 1);

    if (averageDistance < m_BestAverage)
    {
        m_BestAverage = averageDistance;

        m_BestBeziers = m_Beziers;

        m_FoundMatch = true;
    }

    return true;
}


bool H_CompositQuadBezier::WithinTolerance(H_QuadBezier& quad, float& distance)
{
    bool intersection;

    distance = (float)SplineDistance(quad, intersection, 0, m_Points.NumElements() - 1);

    if (distance < m_Tolerance)
    {
        return true;
    }
    else
    {
        return false;
    }
}

double H_CompositQuadBezier::SplineDistance(H_QuadBezier& quad, bool& anyIntersections, int startIndex, int stopIndex)
{
    int numSegments = quad.NumCurvePoints() - 1;

    double largestDistance = 0.0f;
    anyIntersections = false; 

    int numIntersections = 0;
    int largestIntesected = startIndex;


    for (int i = 0; i < numSegments; i++)
    {
        double distance = H_FLOAT_MAX;
        bool   foundIntersection = false;

        H_Line2D segment(quad.GetCurvePoint(i), quad.GetCurvePoint(i+1));

        // Look for intersection with segment.
        for (int j = largestIntesected; j < stopIndex; j++)
        {
            if (m_NormalLines[j].Intersects(segment))
            {
                numIntersections++;
                anyIntersections = true;
                foundIntersection = true;

                largestIntesected = j;

                double currentDistance = segment.PointDistance(m_MidPoints[j]);

                // Get the smallest intersection.
                if (currentDistance < distance)
                {
                    distance = currentDistance;
                    if (distance < m_Tolerance)
                    {
                        break;
                    }
                }
            }
        }

        if (foundIntersection) // Avoid adding FLOAT_MAX if no intersection.
        {
            if (distance > largestDistance)
            {
                largestDistance = distance;

                if (largestDistance > m_Tolerance)
                {
                    return largestDistance;
                }
            }
        }
    }

    // Reject degenerate quads with low hit rate.
    float percentMatch = (float)numIntersections / (float)numSegments;

    if (percentMatch < 0.02f)
    {
        largestDistance = H_FLOAT_MAX;
    }

    return largestDistance;
}
/*
double H_CompositQuadBezier::SplineDistance(H_QuadBezier& quad, bool& anyIntersections, int startIndex, int stopIndex)
{
	(void) startIndex;

    int numSegments = quad.NumCurvePoints() - 1;

	H_ArrayList<bool> intersected(numSegments, false);

    double largestDistance = 0.0f;
    anyIntersections = false; 

    int numIntersections = 0;

    for (int j = 0; j < stopIndex; j++)
    {
        double distance = H_FLOAT_MAX;
        bool   foundIntersection = false;

        // Look for intersection with segment.
        for (int i = 0; i < numSegments; i++)
        {
            H_Line2D segment(quad.GetCurvePoint(i), quad.GetCurvePoint(i+1));

            if (m_NormalLines[j].Intersects(segment))
            {
				intersected[i] = true;

                numIntersections++;
                anyIntersections = true;
                foundIntersection = true;

                double currentDistance = segment.PointDistance(m_MidPoints[j]);

                // Get the smallest intersection.
                if (currentDistance < distance)
                {
                    distance = currentDistance;
                    if (distance < m_Tolerance)
                    {
                        break;
                    }
                }
            }
        }

        if (foundIntersection) // Avoid adding FLOAT_MAX if no intersection.
        {
            if (distance > largestDistance)
            {
                largestDistance = distance;

                if (largestDistance > m_Tolerance)
                {
                    return largestDistance;
                }
            }
        }
    }

    // Reject degenerate quads with low hit rate.
	int intersections = 0;

	for (int i = 0; i < numSegments; i++)
	{
		if (intersected[i])
		{
			intersections++;
		}
	}

	float percentMatch = (float)intersections /  (float)numSegments;

    if (percentMatch < 0.3f)
    {
        largestDistance = H_FLOAT_MAX;
    }

    return largestDistance;
}

*/


void H_CompositQuadBezier::CreateNormals()
{
    m_NormalLines.Clear();
    m_MidPoints.Clear();

    int numSegments = m_Points.NumElements() - 1;

    for (int i = 0; i < numSegments; i++)
    {
        H_Line2D currentSegment(m_Points[i], m_Points[i+1]);
        // Create the normal to the segment:

        float xDelta = m_Points[i+1][0] - m_Points[i][0];
        float yDelta = m_Points[i+1][1] - m_Points[i][1];

        // Calc the unit normal vector.
        H_Vector2f normal(-yDelta, xDelta);
        normal.Normalize();
        normal = 4096.0 * normal;

        // Extend normal both ways.
        H_Vector2f midPoint = currentSegment.Interpolate(0.5f);
        H_Line2D normalLine(midPoint + normal, midPoint - normal);
        
        m_NormalLines.Add(normalLine);
        m_MidPoints.Add(midPoint);
    }
}

void H_CompositQuadBezier::CreateTangents()
{
    m_AllTangents.Clear();

    for (int i = 0; i < m_Points.NumElements()-1; i++)
    {
        H_Line2D line(m_Points[i], m_Points[i+1]);
        line.Extend(10000.0f);
        m_AllTangents.Add(line);
    }
}


// Must call evaluate first.
bool H_CompositQuadBezier::GetFirstExtremaIndex(int& index, bool& horizontal)
{

	index = -1;
	bool found = false;

	H_Vector2f prevPoint;
	H_Vector2f currPoint;
	H_Vector2f nextPoint;
	int i;

	for (i = 2; i < m_Points.NumElements() - 1; i++)
	{
		prevPoint = m_Points[i - 1];
		currPoint = m_Points[i];
		nextPoint = m_Points[i + 1];

		// Right.
		if ((currPoint[0] >= prevPoint[0]) && (currPoint[0] >= nextPoint[0]))
		{
			index = i;
			found = true;
			horizontal = true;
			break;
		}

		// Left.
		if ((currPoint[0] <= prevPoint[0]) && (currPoint[0] <= nextPoint[0]))
		{
			index = i;
			found = true;
			horizontal = true;
			break;
		}

		// Top.
		if ((currPoint[1] >= prevPoint[1]) && (currPoint[1] >= nextPoint[1]))
		{
			index = i;
			found = true;
			horizontal = false;
			break;
		}

		// Bottom.
		if ((currPoint[1] <= prevPoint[1]) && (currPoint[1] <= nextPoint[1]))
		{
			index = i;
			found = true;
			horizontal = false;
			break;
		}
	}

	return found;
}

// Must call evaluate first.
bool H_CompositQuadBezier::SplitAtFirstExtrema(H_ArrayList<H_ContourPoint>& points, int numPoints,  float tolerance)
{
	m_Comparision = H_ANY;

	bool success = false;

	points.Clear();

	int splitIndex;
	bool horizontal;
	H_ArrayList<H_Vector2f> firstPoints;
	H_ArrayList<H_Vector2f> lastPoints;

	if (GetFirstExtremaIndex(splitIndex, horizontal))
	{
		if (m_Points[splitIndex].OnInteger())
		{
			firstPoints = H_ArrayList<H_Vector2f>(m_Points, 0, splitIndex);
			lastPoints  = H_ArrayList<H_Vector2f>(m_Points, splitIndex, m_Points.NumElements() - 1);
		}
		else
		{
			H_Line2D segment(m_Points[splitIndex], m_Points[splitIndex + 1]);
			H_Vector2i nearest = segment.NearestPoint();

			firstPoints = H_ArrayList<H_Vector2f>(m_Points, 0, splitIndex - 1);
			firstPoints.Add(nearest);

			lastPoints.Add(nearest);

			for (int i = splitIndex + 2; i < m_Points.NumElements(); i++)
			{
				lastPoints.Add(m_Points[i]);
			}
		}

		m_Points = firstPoints;
		CreateNormals();
		CreateTangents();


		H_Vector2f splitPoint = m_Points.Last();
		//H_Vector2f splitPre = m_Points[splitIndex - 1];

		// First half.
		m_Control[eSTART] = m_Points[0];
		m_Control[eEND]   = splitPoint;

		m_StartTangent = H_Line2D(m_Points[0], m_Points[1]);

		if (horizontal)
		{
			m_EndTangent = H_Line2D(H_Vector2f(splitPoint[0], -5000.0f), H_Vector2f(splitPoint[0], 5000.0f));
		}
		else
		{
			m_EndTangent = H_Line2D(H_Vector2f(-5000.0f, splitPoint[1]), H_Vector2f(5000.0f, splitPoint[1]));
		}

		m_StartTangent	.Extend(10000.0f);
		m_EndTangent	.Extend(10000.0f);
		m_StartTarget   = m_StartTangent;

		if (IsLinear(tolerance))
		{
			H_ContourPoint startPoint(H_ContourPoint::ON_CURVE, m_Points.First());
			H_ContourPoint endPoint(H_ContourPoint::ON_CURVE, m_Points.Last());

			points.Add(startPoint);
			points.Add(endPoint);
		}
		else 
		{
			if (false == MatchPoints(points, numPoints, tolerance))
			{
				if (m_Verbose)
					printf("Failed to match\n");
			}
		}

		// Second half.
		m_Points.Clear();
		m_Points = lastPoints;
		CreateNormals();
		CreateTangents();

		success = true;
	}
	else if (m_Points.NumElements() >= 2) // Do any remaining section.
	{
		splitIndex = m_Points.NumElements() - 1;

		H_Vector2f splitPoint = m_Points[splitIndex];
		H_Vector2f splitPre = m_Points[splitIndex - 1];

		// First half.
		m_Control[eSTART] = m_Points[0];
		m_Control[eEND]   = splitPoint;

		m_StartTangent = H_Line2D(m_Points[0], m_Points[1]);
		m_EndTangent   = H_Line2D(splitPre, splitPoint);

		m_StartTangent.Extend(10000.0f);
		m_EndTangent  .Extend(10000.0f);

		m_StartTarget   = m_StartTangent;


		if (IsLinear(tolerance))
		{
			H_ContourPoint startPoint(H_ContourPoint::ON_CURVE, m_Points.First());
			H_ContourPoint endPoint(H_ContourPoint::ON_CURVE, m_Points.Last());

			points.Add(startPoint);
			points.Add(endPoint);
		}
		else
		{
			if (false == MatchPoints(points, numPoints, tolerance))
			{
				if (m_Verbose)
					printf("Failed to match\n");
			}
		}

		m_Points.Clear();
		success = true;
	}


	return success;
}
/*
bool H_CompositQuadBezier::IsLinear(float tolerance)
{
	bool linearBezier = true;

	H_Vector2f firstPoint = m_Points.First();
	H_Vector2f lastPoint = m_Points.Last();


	for (int i = 1; i < m_Points.NumElements() - 1; i++)
	{
		H_Vector2f current = m_Points[i];

		H_Vector2f inVector(current - firstPoint);
		H_Vector2f outVector(current - lastPoint);

		bool areLinear;

		if (inVector.LengthSquared() != 0.0f && outVector.LengthSquared() != 0.0f)
		{
			areLinear = AreLinear(inVector, outVector, tolerance);

			if (false == areLinear)
			{
				linearBezier = false;
				break;
			}
		}
	}

	return linearBezier;
}
*/

bool H_CompositQuadBezier::IsLinear(float tolerance)
{
    bool foundIntersection = false;

    H_Vector2f first(m_Points.First());
    H_Vector2f last (m_Points.Last());

    if (first == last)
    {
        return false;
    }

    H_Line2D line(first, last);

    // Look for intersection with segment.
    for (int j = 0; j < m_NormalLines.NumElements(); j++)
    {
        if (m_NormalLines[j].Intersects(line))
        {
            foundIntersection = true;
            double currentDistance = line.PointDistance(m_MidPoints[j]);

            if (currentDistance > tolerance)
            {
                return false;
            }
        }
    }

    // Only return true if we actually found an intersection to calc a distance from.
    return foundIntersection;
}


bool H_CompositQuadBezier::HasInflection()
{
	m_InflectionVector = H_Vector2f();
	m_InflectionIndex = -1;

	bool hasInflection = false;

	Evaluate(0.05f);

	int numSegments = m_Points.NumElements();

	bool foundLeft  = false;
	bool foundRight = false;

	bool first = false;
	bool foundInflection = false;

	for (int i = 1; i < numSegments - 1; i++)
	{
		H_Vector2f previousPoint = m_Points[i - 1];
		H_Vector2f currentPoint  = m_Points[i];
		H_Vector2f nextPoint	 = m_Points[i + 1];

		H_Line2D section(previousPoint, currentPoint);

		bool isLeft = section.IsLeft(nextPoint);

		if (i == 1)
		{
			first = isLeft;
		}
		else
		{
			if (isLeft != first)
			{
				if (false == foundInflection)
				{
					m_InflectionVector = nextPoint - currentPoint;
					m_InflectionIndex = i;
					foundInflection = true;
				}
			}
		}

		if (isLeft)
		{
			foundLeft = true;
		}
		else
		{
			foundRight = true;
		}
	}

	hasInflection = (foundLeft && foundRight);

	m_InflectionSet = true;

	return hasInflection;
}

H_Vector2f H_CompositQuadBezier::GetInfectionVector()
{
	return m_InflectionVector;
}

bool H_CompositQuadBezier::SplitAtIndex(H_ArrayList<H_ContourPoint>& pointsA, H_ArrayList<H_ContourPoint>& pointsB, int numPointsA, int numPointsB, int splitIndex, float tolerance)
{
	pointsA.Clear();
	pointsB.Clear();

	bool success = false;
	m_Comparision = H_ANY;

	H_ArrayList<H_Vector2f> firstPoints;
	H_ArrayList<H_Vector2f> lastPoints;

	if (m_Points[splitIndex].OnInteger())
	{
		firstPoints = H_ArrayList<H_Vector2f>(m_Points, 0, splitIndex);
		lastPoints  = H_ArrayList<H_Vector2f>(m_Points, splitIndex, m_Points.NumElements() - 1);
	}
	else
	{
		H_Line2D segment(m_Points[splitIndex], m_Points[splitIndex + 1]);
		H_Vector2i nearest = segment.NearestPoint();

		firstPoints = H_ArrayList<H_Vector2f>(m_Points, 0, splitIndex - 1);
		firstPoints.Add(nearest);

		lastPoints.Add(nearest);

		for (int i = splitIndex + 2; i < m_Points.NumElements(); i++)
		{
			lastPoints.Add(m_Points[i]);
		}
	}

	// First half.
	m_Points = firstPoints;
	CreateNormals();
	CreateTangents();

	m_Control[eSTART] = m_Points.First();
	m_Control[eEND]   = m_Points.Last();

	m_StartTangent = H_Line2D(m_Points[1], m_Points[0]);
	m_EndTangent = H_Line2D(m_Points[m_Points.NumElements() - 1], m_Points[m_Points.NumElements() - 2]);

	m_StartTangent.Extend(10000.0f);
	m_EndTangent  .Extend(10000.0f);

	m_StartTarget   = m_StartTangent;


	success = MatchPoints(pointsA, numPointsA, tolerance);

	if (false == success)
	{
		if (m_Verbose)
			printf("Failed to split.\n");

		return false;
	}

	// second half.
	m_Points = lastPoints;
	CreateNormals();
	CreateTangents();


	m_Control[eSTART] = m_Points.First();
	m_Control[eEND]   = m_Points.Last();

	m_StartTangent = H_Line2D(m_Points[1], m_Points[0]);
    m_EndTangent   = H_Line2D(m_Points[m_Points.NumElements() - 1], m_Points[m_Points.NumElements() - 2]);

	m_StartTangent.Extend(10000.0f);
	m_EndTangent  .Extend(10000.0f);

	m_StartTarget   = m_StartTangent;

	success = MatchPoints(pointsB, numPointsB, tolerance);
	if (false == success)
	{
		if (m_Verbose)
			printf("Failed to split.\n");
	}

	return success;
}



void H_CompositQuadBezier::Split(H_ArrayList<H_ContourPoint>& pointsA, H_ArrayList<H_ContourPoint>& pointsB, int numPointsA, int numPointsB, float distance, float tolerance)
{
	m_Comparision = H_ANY;

	// Evaluate(0.05f);

	bool success = false;

	const int NUM_TRIES = 4;
	float flatness[NUM_TRIES] = { 0.05f, 0.001f, 0.0001f, 0.00001f };
//	float flatness[NUM_TRIES] = { 0.1f, 0.01f, 0.001f, 0.0001f };

	int tries = 0;

	// Keep trying with successively tighter evaluations.
	while (false == success && tries < NUM_TRIES)
	{
		Evaluate(flatness[tries]);

	int splitIndex = IndexAt(distance);

		if (-1 != splitIndex)
	{
			success = SplitAtIndex(pointsA, pointsB, numPointsA, numPointsB, splitIndex, tolerance);
		}
		tries++;
	}
}


void H_CompositQuadBezier::CalcPathLengths()
{
	float totalLength = 0.0f;

	m_PathLengths.Clear();
	m_PathLengths.Add(0.0f);

	for (int i = 0; i < m_Points.NumElements() - 1; i++)
	{
		H_Vector2f curr = m_Points[i];
		H_Vector2f next = m_Points[i + 1];

		H_Vector2f segment = next - curr;

		float segLength = segment.Length();
		totalLength += segLength;

		m_PathLengths.Add(totalLength);

	}

	for (int i = 0; i < m_Points.NumElements(); i++)
	{
		float current = m_PathLengths[i];
		float normalized = current / totalLength;
		m_PathLengths[i] = normalized;
	}
}

int H_CompositQuadBezier::IndexAt(float position)
{
	CalcPathLengths();

    int i = -1;
	int numElements = m_Points.NumElements();

	for (i = 2; i < numElements - 2; i++)
	{
		float length = m_PathLengths[i];

        if (length >= position)
        {
            break;
        }
	}

	if (i == -1)
	{
		i = numElements / 2;
	}

    return i;
}

