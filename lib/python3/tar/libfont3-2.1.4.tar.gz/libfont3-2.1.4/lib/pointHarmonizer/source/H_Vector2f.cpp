// Copyright (C) 2014 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// H_Vector2f.cpp

//lint -sem(H_Vector2f::Set,initializer)

#include "H_Vector2f.h"
#include "H_MathUtilities.h"
#include <math.h>

/**
    Constructs H_Vector2f and initializes coordinates to (0.0f,0.0f).
*/
H_Vector2f::H_Vector2f() : m_X(0.0), m_Y(0.0)
{
}

/**
    Copy constructor.
*/
H_Vector2f::H_Vector2f(const H_Vector2f& other)
                : m_X(other.m_X),
                  m_Y(other.m_Y)
{
}


/**
    Copy constructor.
*/
H_Vector2f::H_Vector2f(const H_Vector2i& other)
                : m_X((float)(other[0])),
                  m_Y((float)(other[1]))
{
}

/**
    Constructs H_Vector2f using coordinates.
    @param[in]     x   First coordinate
    @param[in]     y   Second coordinate.
*/
H_Vector2f::H_Vector2f(float x, float y)
                : m_X(x),
                  m_Y(y)
{
}


/**
    Round data members to nearest integer.
    @return Vector2f x and y both rounded to nearest integer.
*/
H_Vector2f H_Vector2f::Rounded() const
{
    float x = (m_X + 0.5f);
    float y = (m_Y + 0.5f);

    return H_Vector2f((float)floor(x), (float)floor(y));
}


/**
    Subtracts one vector from the current vector.
    @param[in]     other Other vector
*/
H_Vector2f H_Vector2f::operator-(const H_Vector2f& other) const
{
    return H_Vector2f(m_X - other.m_X, m_Y - other.m_Y);
}

/**
    Adds one vector to the current vector.
    @param[in]     other Other vector
*/
H_Vector2f H_Vector2f::operator+=(const H_Vector2f& other)
{
    m_X += other.m_X;
    m_Y += other.m_Y;
    return *this;
}

/**
    Adds one vector to the current vector.
    @param[in] other Other vector
*/
H_Vector2f H_Vector2f::operator+(const H_Vector2f& other) const
{
    return H_Vector2f(m_X + other.m_X, m_Y + other.m_Y);
}

bool H_Vector2f::operator==(const H_Vector2f& other) const
{
    bool equal = false;

    if ( (m_X == other.m_X) &&  //lint !e777
         (m_Y == other.m_Y))    //lint !e777
    {
        equal = true;
    }
    return equal;
}

/**
    Compares whether current vector is not equal to another vector.
    Vectors are equal if their coordinates are equal.
    @param[in]     other Other vector
    @return @b true if coordinate values of two vectors are equal.
*/
bool H_Vector2f::operator!=(const H_Vector2f& other) const
{
    bool notEqual = false;

    if ( (m_X != other.m_X) ||  //lint !e777
         (m_Y != other.m_Y))    //lint !e777
    {
        notEqual = true;
    }
    return notEqual;
}

float H_Vector2f::Length() const
{
    float length = (float)sqrt(m_X * m_X + m_Y * m_Y );
    return length;
}

void H_Vector2f::Normalize()
{
    const float epsilon = 1e-8f;

    float divisor = Length();

    if (divisor > epsilon)
    {
        float oneOverLength = 1.0f / divisor;

        m_X *= oneOverLength;
        m_Y *= oneOverLength;
    }
}


/**
    Computes length of vector.
    @return square of the length of the vector.
*/
float H_Vector2f::LengthSquared() const
{
    return  m_X * m_X + m_Y * m_Y;
}

/**
    Multiples a scalar times a vector.
    @param[in]  scale Scalar value
    @param[in]  other Other vector
    @return scaled H_Vector2f.
*/
H_Vector2f operator*(float scale, const H_Vector2f& other)
{
    return H_Vector2f(scale * other.m_X, scale * other.m_Y );
}


void H_Vector2f::FromFixed(long x, long y)
{
    float fx = H_FixedToFloat((int)x);
    float fy = H_FixedToFloat((int)y);

    fx += 0.5f;
    fy += 0.5f;

    m_X = (float)floor(fx);
    m_Y = (float)floor(fy);
}


float PointDistance(const H_Vector2f& one, const H_Vector2f& two)
{
    H_Vector2f lineVec = two - one;
    float distance = lineVec.Length();
    return distance;
}

float PointDistanceSquared(const H_Vector2f& one, const H_Vector2f& two)
{
    H_Vector2f lineVec = two - one;
    float distance = lineVec.LengthSquared();
    return distance;
}

float DotProduct(const H_Vector2f& one, const H_Vector2f& two)
{
    return (one.m_X * two.m_X) + (one.m_Y * two.m_Y);
}


bool AreLinear(const H_Vector2f& one, const H_Vector2f& two, float epsilon /* = 7.0 */)
{
	float low	= 180.0f - epsilon;
	float high	= 180.0f + epsilon;

	bool linear = false;

	float angle = AngleBetween(one, two);

	if ((angle >= low) &&
		(angle <= high))
	{
		linear = true;
	}

	return linear;
}


bool SameDirection(const H_Vector2f& one, const H_Vector2f& two, float epsilon)
{
	bool sameDirection = false;

	float angle = AngleBetween(one, two);

	if (fabs(angle) < epsilon)
	{
		sameDirection = true;
	}

	return sameDirection;
}

float AngleBetween(const H_Vector2f& one, const H_Vector2f& two)
{
	float denom = one.Length() * two.Length();

	double cosAngle = 0.0f;

	if (denom != 0)
	{
		cosAngle = DotProduct(one, two) / denom;
	}

    H_Clamp(cosAngle, -1.0, 1.0);

    double angle = acos(cosAngle);

	angle = H_ToDegrees(angle);
    return (float) angle;
}


H_Vector2f::Direction  Orientation(const H_Vector2f& p, const H_Vector2f& q, const H_Vector2f& r)
{
    H_Vector2f::Direction orientation;
 
    float val = (q.Y() - p.Y()) * (r.X() - q.X()) - (q.X() - p.X()) * (r.Y() - q.Y());
 
    if (val == 0.0f)
    {
        orientation = H_Vector2f::eCO_LINEAR;  
    }
    else if (val > 0.0f)
    {
        orientation = H_Vector2f::eCLOCK_WISE;  
    }
    else 
    {
        orientation = H_Vector2f::eANTI_CLOCK_WISE; 
    }

    return orientation;
}

float ManhattenDistance(const H_Vector2f& one, const H_Vector2f& two)
{
    float xDistance = (float)fabs(two[0] - one[0]);
    float yDistance = (float)fabs(two[1] - one[1]);

    float distance = xDistance + yDistance;

    return distance;
}


bool H_Vector2f::SortOnY(H_Vector2f& a, H_Vector2f& b)
{
    return a.Y() < b.Y();
}

void H_Vector2f::Print()
{
	printf("(%.2f, %.2f)", m_X, m_Y);
}

/**
    Determines whether the vector is valid, i.e. the coordinates are
    valid floating point numbers.
    @return @b true if both coordinates are valid floating point numbers.
*/
bool H_Vector2f::IsValid() const
{
    bool valid = true;

    if (    H_IsNan(m_X) ||
            H_IsNan(m_Y) ||
            H_IsInf(m_X) ||
            H_IsInf(m_Y) )
    {
        valid = false;
    }
    return valid;
}

bool H_Vector2f::IsInteger() const
{
	bool isInteger = false;
	
	float x = m_X;
	float y = m_Y;

	int xi = (int)x;
	int yi = (int)y;

	float fracx = x - xi;
	float fracy = y - yi;

	if (fracx == 0.0f || fracx == 0.5f || fracy == 0.0f || fracy == 0.5f)
	{
		isInteger = true;
	}

	return isInteger;
}

bool H_Vector2f::OnInteger() const
{
	bool onInteger = false;

	int xi = (int) m_X;
	int yi = (int) m_Y;

	float fracx = m_X - xi;
	float fracy = m_Y - yi;

	if (fracx == 0.0f && fracy == 0.0f)
	{
		onInteger = true;
	}

	return onInteger;
}