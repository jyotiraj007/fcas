#include "H_OutlineSection.h"
#include "H_MathUtilities.h"
#include "H_QuadBezier.h"
#include "H_BoundingBox.h"
#include "H_CompositQuadBezier.h"

int H_OutlineSection::m_SmallLine = 10; // font units.

H_OutlineSection::H_OutlineSection()
	: m_ExtremaOnCurve(true),
    m_Matched(true),
    m_InflectionVector()
{
}

void H_OutlineSection::SetSmallLine(int length)
{
	m_SmallLine = length;
}

H_OutlineSection::H_OutlineSection(const H_OutlineSection& other)
    : m_ExtremaOnCurve	(other.m_ExtremaOnCurve),
      m_Matched			(other.m_Matched),
      m_ContourHeight	(other.m_ContourHeight),
      m_Points			(other.m_Points),
	  m_InflectionVector(other.m_InflectionVector)
{

}

H_OutlineSection& H_OutlineSection::operator =(const H_OutlineSection& other)
{
	m_Points			= other.m_Points;
	m_ExtremaOnCurve	= other.m_ExtremaOnCurve;

	m_ContourHeight		= other.m_ContourHeight;
	m_CurrentIndex		= other.m_CurrentIndex;
	m_ImplicitPoints	= other.m_ImplicitPoints;
	m_InflectionVector	= other.m_InflectionVector;
	m_Matched			= other.m_Matched;

	return *this;
}


void H_OutlineSection::AddPoint(H_ContourPoint& point)
{
	m_Points.Add(point);
}

void H_OutlineSection::ClearPoints()
{
	m_Points.Clear();
}

int H_OutlineSection::FirstIndex() const
{
	int index = m_Points.FirstIdx();
	return m_Points[index].m_Index;
}

int H_OutlineSection::LastIndex() const
{
	int index = m_Points.LastIdx();
	return m_Points[index].m_Index;
}


H_ContourPoint& H_OutlineSection::GetPoint(int index)
{
	return m_Points[index];
}

int H_OutlineSection::NumPoints()
{
	return m_Points.NumElements();
}

bool H_OutlineSection::LineSegment()
{
	bool lineSegment = false;

	if (NumPoints() == 2)
	{
		if (	(m_Points[0].m_Type == H_ContourPoint::ON_CURVE)  &&
				(m_Points[1].m_Type == H_ContourPoint::ON_CURVE)	)
		{
			lineSegment = true;
		}
	}
	return lineSegment;
}

bool H_OutlineSection::SingleBezier()
{
	bool singleBezier = false;

	if (NumPoints() == 3)
	{
		if (	(m_Points[0].m_Type == H_ContourPoint::ON_CURVE)  &&
				(m_Points[1].m_Type == H_ContourPoint::OFF_CURVE) &&
				(m_Points[2].m_Type == H_ContourPoint::ON_CURVE)	)
		{
			singleBezier = true;
		}
	}

	return singleBezier;
}

bool H_OutlineSection::DegenerateStartLine()
{
	bool lineAtStart = false;

	// Don't match with single line section.
	if (NumPoints() > 2)
	{
		if (	(m_Points[0].m_Type == H_ContourPoint::ON_CURVE) &&
				(m_Points[1].m_Type == H_ContourPoint::ON_CURVE)	)
		{
			float distance = PointDistance(m_Points[0].m_Point, m_Points[1].m_Point);

			// Less than one font unit away. Diagonal will be 1.414.
			if (distance < 1.5f) 
			{
				lineAtStart = true;
			}
		}
	}

	return lineAtStart;
}

bool H_OutlineSection::DegenerateEndLine()
{
	bool lineAtEnd = false;

	if (NumPoints() > 2)
	{
		int idx1 = NumPoints() - 1; // Last point index.
		int idx2 = NumPoints() - 2; // Last but one index.

		if (	(m_Points[idx1].m_Type == H_ContourPoint::ON_CURVE) &&
				(m_Points[idx2].m_Type == H_ContourPoint::ON_CURVE)	)
		{
			float distance = PointDistance(m_Points[idx1].m_Point, m_Points[idx2].m_Point);

			// Less than one font unit away. Diagonal will be 1.414.
			if (distance < 1.5f)
			{
				lineAtEnd = true;
			}
		}
	}
	return lineAtEnd;
}


void H_OutlineSection::RemoveStartLine()
{
	H_ArrayList<H_ContourPoint> temp(m_Points);

	m_Points.Clear();

	// Add first point.
	m_Points.Add(temp[0]);

	// Skip temp[1], and add the rest.
	for (int i = 2; i < temp.NumElements(); i++)
	{
		m_Points.Add(temp[i]);
	}
}

void H_OutlineSection::RemoveEndLine()
{
	H_ArrayList<H_ContourPoint> temp(m_Points);

	int idx1 = NumPoints() - 1; // Last point index.
	int idx2 = NumPoints() - 2; // Last but one index.

	m_Points.Clear();

	// Add the first points.
	for (int i = 0; i < idx2; i++)
	{
		m_Points.Add(temp[i]);
	}

	// Add Last point.
	m_Points.Add(temp[idx1]);
}


bool H_OutlineSection::LineAtStart()
{
	bool lineAtStart = false;

	// Don't match with single line section.
	if (NumPoints() > 2)
	{
		if (	(m_Points[0].m_Type == H_ContourPoint::ON_CURVE) &&
				(m_Points[1].m_Type == H_ContourPoint::ON_CURVE)	)
		{
			lineAtStart = true;
		}
	}

	return lineAtStart;
}

bool H_OutlineSection::LineAtEnd()
{
	bool lineAtEnd = false;

	if (NumPoints() > 2)
	{
		int idx1 = NumPoints() - 1; // Last point index.
		int idx2 = NumPoints() - 2; // Last but one index.

		if (	(m_Points[idx1].m_Type == H_ContourPoint::ON_CURVE) &&
				(m_Points[idx2].m_Type == H_ContourPoint::ON_CURVE)	)
		{
			lineAtEnd = true;
		}
	}
	return lineAtEnd;
}


bool H_OutlineSection::MiddleLine()
{
	bool middleLine = false;

	for (int i = 1; i < m_Points.NumElements() - 3; i++)
	{
		H_ContourPoint& currentPoint = m_Points[i];
		H_ContourPoint& nextPoint    = m_Points[i+1];

		if (	(currentPoint.m_Type == H_ContourPoint::ON_CURVE) &&
				(nextPoint.m_Type    == H_ContourPoint::ON_CURVE) )
		{
			middleLine = true;
			break;
		}
	}

	return middleLine;
}

void H_OutlineSection::SetLineInflection()
{
	int idx1 = MiddleLineIndex();
	int idx2 = idx1 + 1;

	H_ArrayList<H_ContourPoint> startPoints;
	H_ArrayList<H_ContourPoint> endPoints;

	for (int i = 0; i <=  idx1; i++)
	{
		startPoints.Add(m_Points[i]);
	}
	
	startPoints.Reverse();

	for (int i = idx2; i < m_Points.NumElements(); i++)
	{
		endPoints.Add(m_Points[i]);
	}

	// Resolve here because MiddleLineIndex uses unresolved points.
	ResolvePoints(startPoints, m_StartPoints);
	ResolvePoints(endPoints, m_EndPoints);
}


void H_OutlineSection::ReflowLineInflection()
{
	SetLineInflection();
	// Find center of middle line section, and double int length to find start targets for the two bezier sides.
	H_ContourPoint startPoint = m_StartPoints.First();
	H_ContourPoint endPoint   = m_EndPoints.First();

	H_Vector2f startPosition = startPoint.m_Point;
	H_Vector2f endPosition	 = endPoint.m_Point;

	H_Line2D midLine(startPosition, endPosition);

	midLine.Extend(10000.0f);

	H_CompositQuadBezier pointsA(m_StartPoints);
	H_CompositQuadBezier pointsB(m_EndPoints);

	H_ArrayList<H_ContourPoint> resultsA;
	H_ArrayList<H_ContourPoint> resultsB;

	pointsA.MatchStartTarget(resultsA, 1, 1.0f, H_ANY, midLine);
	pointsB.MatchStartTarget(resultsB, 1, 1.0f, H_ANY, midLine);

	resultsA.Reverse();

	m_Points.Clear();


	for (int i = 0; i < resultsA.NumElements() - 1; i++)
	{
		m_Points.Add(resultsA[i]);
	}

	for (int i = 1; i < resultsB.NumElements(); i++)
	{
		m_Points.Add(resultsB[i]);
	}
}




int H_OutlineSection::MiddleLineIndex()
{
	int index = -1;

	for (int i = 1; i < m_Points.NumElements() - 3; i++)
	{
		H_ContourPoint& currentPoint = m_Points[i];
		H_ContourPoint& nextPoint    = m_Points[i+1];

		if (	(currentPoint.m_Type == H_ContourPoint::ON_CURVE) &&
				(nextPoint.m_Type    == H_ContourPoint::ON_CURVE) )
		{
			index = i;
			break;
		}
	}

	return index;
}


bool H_OutlineSection::FlatExtremaAtStart()
{
	bool flatExtrema = false;

	if (LineAtStart())
	{
		H_ContourPoint& pointA = m_Points[0];
		H_ContourPoint& pointB = m_Points[1];

		if (pointA.m_FlatExtrema && pointB.m_FlatExtrema)
		{
			flatExtrema = true;
		}
	}

	return flatExtrema;
}

bool H_OutlineSection::FlatExtremaAtEnd()
{ 
	bool flatExtrema = false;

	if (LineAtEnd())
	{
		int idx1 = NumPoints() - 1; // Last point index.
		int idx2 = NumPoints() - 2; // Last but one index.

		H_ContourPoint& pointA = m_Points[idx1];
		H_ContourPoint& pointB = m_Points[idx2];
		
		if (pointA.m_FlatExtrema && pointB.m_FlatExtrema)
		{
			flatExtrema = true;
		}
	}

	return flatExtrema;
}


bool H_OutlineSection::SmallLineAtStart()
{
	bool lineAtStart = false;

	if (LineAtStart())
	{
		H_ContourPoint& pointA = m_Points[0];
		H_ContourPoint& pointB = m_Points[1];
		H_ContourPoint& pointC = m_Points[2];

		// Line must be 'extension' of the curve it's next to, and not a 'kink'.
		H_Vector2f inVector (pointA.m_Point - pointB.m_Point);
		H_Vector2f outVector(pointC.m_Point - pointB.m_Point );

		bool linear = AreLinear(inVector, outVector, 5.0f);

		// Short lines only.
		float distance = PointDistance(m_Points[0].m_Point, m_Points[1].m_Point);

		// If its its really small do it, linear or not. Catches small 'crotches'.
		if (distance < 4.0f)
		{
			lineAtStart = true;
		}
		else if (linear && distance < m_SmallLine) // Catch linear 'extensions'.
		{
			lineAtStart = true;
		}
	}

	return lineAtStart;
}

bool H_OutlineSection::SmallLineAtEnd()
{ 
	bool lineAtEnd = false;

	if (LineAtEnd())
	{
		int idx1 = NumPoints() - 1; // Last point index.
		int idx2 = NumPoints() - 2; // Last but one index.
		int idx3 = NumPoints() - 3; // Next last but one index.

		H_ContourPoint& pointA = m_Points[idx1];
		H_ContourPoint& pointB = m_Points[idx2];
		H_ContourPoint& pointC = m_Points[idx3];

		H_Vector2f inVector (pointB.m_Point - pointA.m_Point);
		H_Vector2f outVector(pointC.m_Point - pointB.m_Point);

		// Line must be 'extension' of the curve it's next to, and not a 'kink'.
		bool linear		= SameDirection(inVector, outVector, 5.0f);

		// Short lines only.
		float distance	= PointDistance(m_Points[idx1].m_Point, m_Points[idx2].m_Point);

		// If its its really small do it, linear or not. Catches small 'crotches'.
		if (distance < 4.0f)
		{
			lineAtEnd = true;
		}
		else if (distance < m_SmallLine && linear) // Catch linear 'extensions'. 
		{
			lineAtEnd = true;
		}
	}

	return lineAtEnd;
}


bool H_OutlineSection::IsLinear()
{
	return PointsLinear(m_Points);
}

// For each mid point, create one vector to first point and one vector to end.
// These two vectors must be co-linear. If they all are then section is 'linear' 
// within epsilon (in degrees).
bool H_OutlineSection::PointsLinear(H_ArrayList<H_ContourPoint>& points)
{
	const float EPSILON = 1.5f; // In degrees.
	bool linearBezier = true;

	H_ContourPoint& firstPoint = points.First();
	H_ContourPoint& lastPoint  = points.Last();

	H_Vector2f first = firstPoint.m_Point;
	H_Vector2f last  = lastPoint.m_Point;

	for (int i = 1; i < points.NumElements() - 1; i++)
	{
		H_ContourPoint& currentPoint = points[i];
		H_Vector2f& current = currentPoint.m_Point;

		H_Vector2f inVector (current - first);
		H_Vector2f outVector(current - last);

		bool areLinear = AreLinear(inVector, outVector, EPSILON);

		if (false == areLinear)
		{
			linearBezier = false;
		}
	}

	return linearBezier;
}

// Just keep the first and last on-curve points;
void H_OutlineSection::RemoveLinearBezier()
{
	H_ArrayList<H_ContourPoint> temp(m_Points);

	m_Points.Clear();

	m_Points.Add(temp.First());
	m_Points.Add(temp.Last());
}

// Look for lengths of off curve points between 
// on curve that are linear.
//  This first, so we can label them as 'extrema' and match.
void H_OutlineSection::RemoveLinearSegments()
{
	H_ArrayList<H_ContourPoint> newPoints;
	H_ArrayList<H_ContourPoint> temp;

	newPoints.Add(m_Points.First());
	temp.Add(m_Points.First());

	int currentIdx = 1;

	while (currentIdx < m_Points.NumElements())
	{
		H_ContourPoint& currentPoint = m_Points[currentIdx];

		temp.Add(currentPoint);

		if (currentPoint.m_Type == H_ContourPoint::ON_CURVE)
		{
			if (PointsLinear(temp))
			{
				newPoints.Add(temp.Last());
			}
			else
			{
				for (int i = 1; i < temp.NumElements(); i++)
				{
					newPoints.Add(temp[i]);
				}
			}

			temp.Clear();
			temp.Add(currentPoint);
		}
		currentIdx++;
	}
	m_Points = newPoints;
}

void H_OutlineSection::FixEndPoints()
{
	m_Points.First().m_IsExtremum = true;
	m_Points.Last().m_IsExtremum = true;
}

bool H_OutlineSection::SmoothPointsOnly()
{
	bool foundSmoothPoint	= false;
	bool foundUnSmoothPoint = false;

	for (int i = 1; i < m_Points.NumElements() - 1; i++)
	{
		if (m_Points[i].m_Type == H_ContourPoint::ON_CURVE)
		{
			if (m_Points[i].m_IsExtremum)
			{
				foundUnSmoothPoint = true;
			}
			else
			{
				foundSmoothPoint = true;
			}
		}
	}

	bool smoothPoints = (foundSmoothPoint && (false == foundUnSmoothPoint));

	return smoothPoints;
}

bool H_OutlineSection::IsEmpty()
{
	bool isEmpty = false;

	if (NumPoints() == 0)
	{
		isEmpty = true;
	}

	return isEmpty;
}

int H_OutlineSection::NumOnCurve()
{
	int count = 0;

	for (int i = 1; i < m_Points.NumElements() - 1; i++)
	{
		if (m_Points[i].m_Type == H_ContourPoint::ON_CURVE)
		{
			count++;
		}
	}
	return count;
}

int H_OutlineSection::NumExtrema()
{
	int count = 0;

	for (int i = 1; i < m_Points.NumElements() - 1; i++)
	{
		if (	(m_Points[i].m_Type == H_ContourPoint::ON_CURVE) &&
				(m_Points[i].m_IsExtremum == true) )
		{
			count++;
		}
	}
	return count;
}

int H_OutlineSection::NumExtremaAll()
{
	int count = 0;

	for (int i = 0; i < m_Points.NumElements(); i++)
	{
		if (	(m_Points[i].m_Type == H_ContourPoint::ON_CURVE) &&
				(m_Points[i].m_IsExtremum == true) )
		{
			count++;
		}
	}
	return count;
}

bool H_OutlineSection::OffCurveOnly()
{
	bool offCurveOnly = true;

	for (int i = 1; i < NumPoints() - 1; i++)
	{
		if (m_Points[i].m_Type == H_ContourPoint::ON_CURVE)
		{
			offCurveOnly = false;
			break;
		}
	}

	return offCurveOnly && (NumOffCurve() > 0); // Make sure we're not a line segment.
}

int H_OutlineSection::NumOffCurve()
{
	int count = 0;

	for (int i = 1; i < m_Points.NumElements() - 1; i++)
	{
		if (m_Points[i].m_Type == H_ContourPoint::OFF_CURVE)
		{
			count++;
		}
	}
	return count;
}

bool H_OutlineSection::operator==(H_OutlineSection& other)
{
	bool sameNumber = (NumPoints() == other.NumPoints());

	bool pointsMatch = true;

	for (int i = 0; i < m_Points.NumElements(); i++)
	{
		if (m_Points[i].m_Point != other.GetPoint(i).m_Point)
		{
			pointsMatch = false;
			break;
		}
	}

	return sameNumber && pointsMatch;
}


int H_OutlineSection::BestOnCurveMatch(H_OutlineSection* pSection)
{
	int bestScore = INT_MAX; // lowest score wins.
	int bestIndex = -1;

	int index = FirstOnCurve();

	if (index > -1)
	{
		H_ContourPoint& point = GetPoint(index);

		int otherIndex = pSection->FirstOnCurve();

		while (otherIndex != -1)
		{
			H_ContourPoint& otherPoint = pSection->GetPoint(otherIndex);

			int currentScore = otherPoint.ScoreOnCurve(point);

			if (currentScore < bestScore)
			{
				bestScore = currentScore;
				bestIndex = otherIndex;
			}

			otherIndex = pSection->NextOnCurve();
		}
	}

	int result = -1;

	// Must be high confidence. This allows to find coherent features accross the set,
	// but not finding 'smooth' points for an inflection.
	if (bestScore < 50)
	{
		result = bestIndex;
	}

	return result;
}

int H_OutlineSection::BestMatch(H_OutlineSection* pSection)
{
	int bestScore = INT_MAX; // lowest score wins.
	int bestIndex = -1;

	int index = FirstExtrema();

	if (index > -1)
	{
		H_ContourPoint& point = GetPoint(index);

		int otherIndex = pSection->FirstExtrema();

		while (otherIndex != -1)
		{
			H_ContourPoint& otherPoint = pSection->GetPoint(otherIndex);

			int currentScore = otherPoint.ScoreOnCurve(point);

			if (currentScore < bestScore)
			{
				bestScore = currentScore;
				bestIndex = otherIndex;
			}

			otherIndex = pSection->NextExtrema();
		}
	}

	return bestIndex;
}

float H_OutlineSection::PathLengthToFirstOnCurve()
{
	CalcPathLengths();

	int firstIndex = FirstOnCurve();

	H_ContourPoint& first = GetPoint(firstIndex);

	return first.m_PathLength;
}

int H_OutlineSection::FirstOnCurve()
{
	int index = -1;

	m_CurrentIndex = 1;

	while (m_CurrentIndex < m_Points.NumElements() - 1)
	{
		if (m_Points[m_CurrentIndex].m_Type == H_ContourPoint::ON_CURVE)
		{
			index = m_CurrentIndex;
			break;
		}
		m_CurrentIndex++;
	}
	
	return index;
}

int H_OutlineSection::NextOnCurve()
{
	int index = -1;

	m_CurrentIndex++;

	while (m_CurrentIndex < m_Points.NumElements() - 1)
	{
		if (m_Points[m_CurrentIndex].m_Type == H_ContourPoint::ON_CURVE)
		{
			index = m_CurrentIndex;
			break;
		}
		m_CurrentIndex++;
	}

	return index;
}



int H_OutlineSection::FirstExtrema()
{
	int index = -1;

	m_CurrentIndex = 1;

	while (m_CurrentIndex < m_Points.NumElements() - 1)
	{
		if (	(m_Points[m_CurrentIndex].m_Type == H_ContourPoint::ON_CURVE) &&
				(m_Points[m_CurrentIndex].m_IsExtremum == true)	)
		{
			index = m_CurrentIndex;
			break;
		}
		m_CurrentIndex++;
	}
	
	return index;
}

int H_OutlineSection::NextExtrema()
{
	int index = -1;

	m_CurrentIndex++;

	while (m_CurrentIndex < m_Points.NumElements() - 1)
	{
		if (	(m_Points[m_CurrentIndex].m_Type == H_ContourPoint::ON_CURVE) &&
				(m_Points[m_CurrentIndex].m_IsExtremum == true)	)
		{
			index = m_CurrentIndex;
			break;
		}
		m_CurrentIndex++;
	}

	return index;
}

void H_OutlineSection::CalcPathLengths()
{
	float totalPath = 0.0f;

	if (m_ImplicitPoints.NumElements() > 0) // Implicits only...
	{
		H_QuadPoints quadPoints;

		quadPoints.m_Start = m_Points[0].m_Point;

		for (int i = 1; i < NumPoints() - 2; i++)
		{
			H_ContourPoint& currentPoint = m_Points[i];

			quadPoints.m_Control = currentPoint.m_Point;

			quadPoints.m_End = m_ImplicitPoints[i - 1].m_Point;

			H_QuadBezier bezier(quadPoints);

			totalPath += bezier.PathLength();
			m_ImplicitPoints[i - 1].m_PathLength = totalPath;

			quadPoints.m_Start = quadPoints.m_End;
		}
		quadPoints.m_Control = m_Points[NumPoints() - 2].m_Point;
		quadPoints.m_End = m_Points[NumPoints() - 1].m_Point;
		H_QuadBezier bezier(quadPoints);
		totalPath += bezier.PathLength();

		// Now normalize the path lengths.
		for (int i = 0; i < m_ImplicitPoints.NumElements(); i++)
		{
			m_ImplicitPoints[i].m_PathLength /= totalPath;
		}
	}
	else
	{
		H_Vector2f points[4];
		int        index = 0;

		points[index++] = m_Points[0].m_Point;

		for (int i = 1; i < NumPoints(); i++)
		{
			H_ContourPoint& currentPoint = m_Points[i];
			points[index++] = currentPoint.m_Point;

			if (currentPoint.m_Type == H_ContourPoint::ON_CURVE)
			{
				// Check for line segment:
				if (index == 2)
				{
					H_Vector2f& currPosition = points[0];
					H_Vector2f& nextPosition = points[1];

					H_Vector2f vector = nextPosition - currPosition;

					totalPath += vector.Length();
					currentPoint.m_PathLength = totalPath;

					points[0] = points[1];
					index = 1;
				}
				// Check for single quad:
				else if (index == 3)
				{
					H_QuadPoints quadPoints;
					quadPoints.m_Start		= points[0];
					quadPoints.m_Control	= points[1];
					quadPoints.m_End		= points[2];
					
					H_QuadBezier quadBezier(quadPoints);

					totalPath += quadBezier.PathLength();
					currentPoint.m_PathLength = totalPath;

					points[0] = points[2];
					index = 1;
				}
			}
			else if (currentPoint.m_Type == H_ContourPoint::OFF_CURVE)
			{
				if (index > 2)
				{
					H_Vector2f midPoint = H_Interpolate(points[1], points[2], 0.5f);

					H_QuadPoints quadPoints;
					quadPoints.m_Start		= points[0];
					quadPoints.m_Control	= points[1];
					quadPoints.m_End		= midPoint;

					H_QuadBezier quadBezier(quadPoints);
					totalPath += quadBezier.PathLength();

					points[0] = midPoint;
					index = 1;
				}
			}
		}

		for (int i = 1; i < NumPoints(); i++)
		{
			H_ContourPoint& currentPoint = m_Points[i];
			if (currentPoint.m_Type == H_ContourPoint::ON_CURVE)
			{
				currentPoint.m_PathLength /= totalPath;
			}
		}
	}
}

void H_OutlineSection::ResolvePoints(H_ArrayList<H_ContourPoint>& input, H_ArrayList<H_ContourPoint>& output)
{
	output.Clear();

	int offCurveCount = 0;
	H_ContourPoint lastPoint = input[0];

	for (int i = 0; i < input.NumElements(); i++)
	{
		H_ContourPoint& currentPoint = input[i];

		if (currentPoint.m_Type == H_ContourPoint::ON_CURVE)
		{
			output.Add(currentPoint);
			offCurveCount = 0;
		}
		else if (currentPoint.m_Type == H_ContourPoint::OFF_CURVE)
		{
			offCurveCount++;

			if (offCurveCount == 2)
			{
				H_Vector2f midPoint = H_Interpolate(lastPoint.m_Point, currentPoint.m_Point, 0.5f);
				H_ContourPoint newPoint(H_ContourPoint::ON_CURVE, midPoint);
				output.Add(newPoint);

				output.Add(currentPoint);

				offCurveCount = 1;
			}
			else
			{
				output.Add(currentPoint);
			}
		}

		lastPoint = currentPoint;
	}
}

void H_OutlineSection::ResolvePoints(H_ArrayList<H_ContourPoint>& points)
{
	ResolvePoints(m_Points, points);
}


void H_OutlineSection::SetContourHeight(int contourHeight)
{
	m_ContourHeight = contourHeight;
}

// Check that all off curve points are the same side of their associated on curve points.
bool H_OutlineSection::HasInflection()
{
	bool hasInflection = false;

	m_InflectionVector = H_Vector2f();

//	if (SmoothCurve())
//	{
		H_ArrayList<H_ContourPoint> contourPoints;
		ResolvePoints(contourPoints);

		H_CompositQuadBezier composit(contourPoints);

		hasInflection = composit.HasInflection();

		if (hasInflection)
		{
			m_InflectionVector = composit.GetInfectionVector();
		}
//	}

	return hasInflection;
}

bool H_OutlineSection::SmoothCurve()
{
	bool isSmooth = true;

	for (int i = 1; i < m_Points.NumElements() - 1; i++)
	{
		H_ContourPoint& pointA = m_Points[i - 1];
		H_ContourPoint& pointB = m_Points[i];
		H_ContourPoint& pointC = m_Points[i + 1];

		H_Vector2f inVector(pointA.m_Point - pointB.m_Point);
		H_Vector2f outVector(pointB.m_Point - pointC.m_Point);

		// Allow for some slack.
		bool linear = SameDirection(inVector, outVector, 5.0f);

		if (false == linear)
		{
			isSmooth = false;
			break;
		}
	}

	return isSmooth;
}


bool H_OutlineSection::OnCurveAtExtrema()
{
	H_BoundingBox boundsBox;

	bool leftTangent = false;
	bool rightTangent = false;
	bool topTangent = false;
	bool bottomTangent = false;

	// Create bounds box with on curve points.
	for (int i = 0; i < m_Points.NumElements(); i++)
	{
		H_ContourPoint& point = m_Points[i];

		if (point.m_Type == H_ContourPoint::ON_CURVE)
		{
			if (boundsBox.ExpandLeft(point.m_Point[0]))
			{
				leftTangent = false;
			}

			if (boundsBox.ExpandRight(point.m_Point[0]))
			{
				rightTangent = false;
			}

			if (boundsBox.ExpandTop(point.m_Point[1]))
			{
				topTangent = false;
			}

			if (boundsBox.ExpandBottom(point.m_Point[1]))
			{
				bottomTangent = false;
			}
		}
	}

	// Now add to bounds with off curve points.
	// If any expand the bounds then we've got an off curve extrema.
	for (int i = 0; i < m_Points.NumElements(); i++)
	{
		H_ContourPoint& point = m_Points[i];

		if (point.m_Type == H_ContourPoint::OFF_CURVE)
		{
			if (boundsBox.ExpandLeft(point.m_Point[0]))
			{
				leftTangent = true;
			}

			if (boundsBox.ExpandRight(point.m_Point[0]))
			{
				rightTangent = true;
			}

			if (boundsBox.ExpandTop(point.m_Point[1]))
			{
				topTangent = true;
			}

			if (boundsBox.ExpandBottom(point.m_Point[1]))
			{
				bottomTangent = true;
			}
		}
	}


	return (!leftTangent && !rightTangent && !topTangent && !bottomTangent);
}


bool H_OutlineSection::Matches(H_OutlineSection* pOther)
{
	bool matches = true;

	if (NumPoints() != pOther->NumPoints())
	{
		matches = false;
	}
	else
	{
		for (int i = 0; i < NumPoints(); i++)
		{
			if (m_Points[i].m_Type != pOther->m_Points[i].m_Type)
			{
				matches = false;
				break;
			}
		}
	}

	m_Matched = matches;

	return matches;
}

bool H_OutlineSection::Matched()
{
	return m_Matched;
}

H_BoundingBox H_OutlineSection::GetBounds()
{
	H_BoundingBox bounds;

	for (int i = 0; i < NumPoints(); i++)
	{
		bounds.Expand(m_Points[i].m_Point);
	}

	return bounds;
}

bool H_OutlineSection::IsValid()
{
	bool isValid = true;

	for (int i = 0; i < m_Points.NumElements(); i++)
	{
		isValid &= m_Points[i].IsValid();
	}

	if (NumPoints() == 0)
	{
		isValid = false;
	}

	return isValid;
}

void H_OutlineSection::Print()
{
	for (int i = 0; i < m_Points.NumElements(); i++)
	{
		m_Points[i].Print();
	}
}