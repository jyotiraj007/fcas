// Copyright (C) 2016 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// H_OutlineSection.h

#ifndef H_OUTLINE_SECTION_H
#define H_OUTLINE_SECTION_H

#include "H_ContourPoint.h"
#include "H_ArrayList.h"
#include "H_QuadPoints.h"
#include "H_BoundingBox.h"
//#include "H_CompositQuadBezier.h"


struct Pair
{
	Pair() : m_Index1(0), m_Index2(0) {}
	Pair(int index1, int index2) : m_Index1(index1), m_Index2(index2) { };
	int m_Index1;
	int m_Index2;
};

struct PairScore
{
	PairScore() : m_Index1(0), m_Index2(0), m_Score(0) {}
	PairScore(int index1, int index2, int score) : m_Index1(index1), m_Index2(index2), m_Score(score) { };

	int		m_Index1;
	int		m_Index2;
	int     m_Score;

};

class H_OutlineSection 
{
    public:
		/* CTOR */	H_OutlineSection();
		/* CTOR */	H_OutlineSection(const H_OutlineSection& other);

		H_OutlineSection& operator =(const H_OutlineSection& other);

		bool        operator ==(H_OutlineSection& other);

		int         NumExtrema	();
        void		AddPoint	(H_ContourPoint& point);
		void        ClearPoints	();

		int         FirstIndex	() const;
		int         LastIndex	() const;

		void        FixEndPoints();
		bool        SmoothPointsOnly	(); // This is a misnomer.

		bool        SmoothCurve();

		bool        DegenerateStartLine	();
		bool        DegenerateEndLine	();

		void        RemoveStartLine	();
		void        RemoveEndLine	();

		bool        SmallLineAtStart();
		bool        SmallLineAtEnd	();

		bool        FlatExtremaAtStart();
		bool        FlatExtremaAtEnd();

		bool        LineAtStart	();
		bool		LineAtEnd	();

		bool        MiddleLine		();
		int         MiddleLineIndex	();

		void        ReflowLineInflection();
		
		int         NumOnCurve	();
		int         NumOffCurve	();
		int         NumImplicit	();
		bool        ImplicitOnly();
		bool        SingleBezier();
		bool        LineSegment	();
		bool        OffCurveOnly(); // diff from implicit only: includes single bezier.
		bool        IsEmpty();

		bool        IsLinear		();
		void        RemoveLinearBezier	();

		void        RemoveLinearSegments();

		bool		PointsLinear		(H_ArrayList<H_ContourPoint>& points);


		void        SetLineInflection();
		
		int         BestMatch(H_OutlineSection* pSection);
		int         BestOnCurveMatch(H_OutlineSection* pSection);

		int			FirstOnCurve	();
		int         NextOnCurve		();

		int         NumExtremaAll	();

		int			FirstExtrema	();
		int			NextExtrema		();

		int         NumPoints		();
		H_ContourPoint& GetPoint(int index);

		void        CalcPathLengths();

		float		PathLengthToFirstOnCurve();

		void		ResolvePoints(H_ArrayList<H_ContourPoint>& points); // Resolve any implicit points. 
		void		ResolvePoints(H_ArrayList<H_ContourPoint>& input, H_ArrayList<H_ContourPoint>& output); // Resolve any implicit points. 

		void        SetContourHeight(int contourHeight);

		bool		OnCurveAtExtrema();
		bool		m_ExtremaOnCurve;

		bool		HasInflection();

		bool		Matches(H_OutlineSection* pOther);

		static void SetSmallLine(int length);

		bool       Matched();

		void       Print();
		bool       IsValid();

		H_BoundingBox GetBounds();

	protected:

		static int					m_SmallLine;
		bool                        m_Matched;
		int							m_ContourHeight;
		H_ArrayList<H_ContourPoint> m_Points;
		int                         m_CurrentIndex;

		H_ArrayList<H_ContourPoint> m_ImplicitPoints;

		H_Vector2f                  m_InflectionVector;
		
		H_ArrayList<H_ContourPoint> m_StartPoints;
		H_ArrayList<H_ContourPoint> m_EndPoints;

};



#endif

