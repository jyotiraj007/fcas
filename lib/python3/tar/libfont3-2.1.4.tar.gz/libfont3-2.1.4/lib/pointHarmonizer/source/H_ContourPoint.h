// Copyright (C) 2015 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// ContourPoint.h

#ifndef H_CONTOUR_POINT
#define H_CONTOUR_POINT

#include "H_Vector2f.h"

class H_ContourPoint
{
    public:

        enum H_PointType	 { ON_CURVE = 0, OFF_CURVE = 1 };
		enum H_ExtremaType   { E_NONE = 0, E_TOP, E_BOTTOM, E_LEFT, E_RIGHT };

        /*  CTOR */ H_ContourPoint    ();
        /*  CTOR */ H_ContourPoint    (H_PointType type, H_Vector2f point);

		bool        operator == (const H_ContourPoint& other) const ;

		int         ScoreMatch	(H_ContourPoint& other, bool useIndex = true);
		int			ScoreOnCurve(H_ContourPoint& other, bool useIndex = true);

		void		CalcDirection(H_ContourPoint& previous, H_ContourPoint& next);

		static bool		SortOnY(H_ContourPoint& a, H_ContourPoint& b);

		void          Print();
		bool          IsValid();

		int           m_Index;
        H_PointType   m_Type;
        H_Vector2f    m_Point;
		bool          m_IsExtremum;
		bool          m_Smooth;

		H_ExtremaType m_ExtremaType;

		float		  m_Angle;
		H_Vector2f    m_InVector;
		H_Vector2f	  m_OutVector;

		float         m_NormalX;
		float		  m_NormalY;

		float         m_NormalizedIndex;
		float         m_PathLength;

		bool          m_FlatExtrema;
};

#endif



