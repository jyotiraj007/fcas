// Copyright (C) 2016 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
/// \file Compositor.cpp

#include <stdlib.h>
#include "Compositor.h"
#include "CF_GlyphCompositor.h"
#include "CF_BoundingBox.h"

//#define COMP_DUMP
#ifdef COMP_DUMP

static char* TypeToString(CF_ContourPoint::CF_PointType type)
{
    switch (type)
    {
    case CF_ContourPoint::CF_PointType::ON_CURVE: return "ON_CURVE";
    case CF_ContourPoint::CF_PointType::OFF_CURVE: return "OFF_CURVE";
    default: return "<UNKNOWN?>";
    }
}

static void dumpCFQuad(CF_QuadGlyph* quadGlyph)
{
    printf("\nQuadContour:\n");
    printf("num contours: %d\n", quadGlyph->NumContours());

    CF_QuadContour* pContour = quadGlyph->FirstContour();
    int contourIndex = 0;

    while (pContour)
    {
        printf("Contour %d:\n", contourIndex);

        int contourNpts = pContour->NumPoints();

        for (int j = 0; j < contourNpts; j++)
        {
            CF_ContourPoint point = pContour->GetPoint(j);
            printf("%f %f (%s)\n", (float)point.m_Point[0], (float)point.m_Point[1], TypeToString(point.m_Type));
        }

        pContour = quadGlyph->NextContour();
    }

    printf("\n");
}

//#define DumpCubic(c) dumpCubic(c);
#define DumpCFQuad(q) dumpCFQuad(q);

#else
//#define DumpCubic(c)
#define DumpCFQuad(q)
#endif


static Compositor_Error createCFQuadGlyph(Glyph& input, CF_QuadGlyph& output)
{
    if (input.glyphType != eGlyph_TTF)
        return COMPOSITOR_INVALID_PARAM;

    if (input.glyphOutline.numberOfComponents == 0)
        return COMPOSITOR_SUCCESS;

    if ((input.glyphOutline.numberOfComponents > 1) ||
        (input.glyphOutline.component.type == eIsComposite))
    {
        Glyph_Component* gc = &input.glyphOutline.component;

        for (int i = 0; i < input.glyphOutline.numberOfComponents; i++)
        {
            if (i > 0)
            {
                gc = gc->next;
            }

            CF_ScaleOffset scaleOffset;
            scaleOffset.m_OffsetX = (int)gc->xoffset;
            scaleOffset.m_OffsetY = (int)gc->yoffset;
            scaleOffset.m_ScaleX = gc->xscale;
            scaleOffset.m_ScaleY = gc->yscale;

            CF_Component comp = CF_Component(gc->glyphIndex, scaleOffset);

            output.AddComponent(comp);
        }
    }
    else
    {
        Simple_Outline* quadOutline = &input.glyphOutline.component.outline;

        int np = quadOutline->np;
        float* x = quadOutline->x;
        float* y = quadOutline->y;
        Point_Type* types = quadOutline->types;

        if (np == 0 || x == NULL || y == NULL || types == NULL)
            return COMPOSITOR_INVALID_PARAM;

        // First point must be a moveto
        if (types[0] != MOVE_TO)
            return COMPOSITOR_INVALID_PARAM;

        CF_QuadContour quadContour;

        for (int i = 0; i < np/*- 2 not expecting phantom pts*/; i++)
        {
            switch (types[i])
            {
            case MOVE_TO:
                if (i != 0)
                {
                    if (quadContour.NumPoints() > 0)
                        output.AddContour(quadContour);
                    quadContour.Clear();
                }
                quadContour.AddPoint(CF_ContourPoint(CF_ContourPoint::ON_CURVE, CF_Vector2f(x[i], y[i])));
                break;
            case LINE_TO:
                quadContour.AddPoint(CF_ContourPoint(CF_ContourPoint::ON_CURVE, CF_Vector2f(x[i], y[i])));
                break;
            case ON_CURVE:
                quadContour.AddPoint(CF_ContourPoint(CF_ContourPoint::ON_CURVE, CF_Vector2f(x[i], y[i])));
                break;
            case OFF_CURVE:
                quadContour.AddPoint(CF_ContourPoint(CF_ContourPoint::OFF_CURVE, CF_Vector2f(x[i], y[i])));
                break;
            }
        }

        // Add last contour
        if (quadContour.NumPoints() > 0)
            output.AddContour(quadContour);
    }

    DumpCFQuad(&output);

    return COMPOSITOR_SUCCESS;
}

static void preserveOriginalCompFlags(Glyph* origGlyphs, int numOrigGlyphs, Glyph* output)
{
    for (int i = 0; i < numOrigGlyphs; i++)
    {
        Glyph curGlyph = origGlyphs[i];

        if ((curGlyph.glyphOutline.numberOfComponents > 1) ||
            (curGlyph.glyphOutline.component.type == eIsComposite))
        {
            Glyph_Component* gcinput = &curGlyph.glyphOutline.component;
            Glyph_Component* gcoutput = &output[i].glyphOutline.component;

            for (int j = 0; j < curGlyph.glyphOutline.numberOfComponents; j++)
            {
                if (j > 0)
                {
                    gcinput = gcinput->next;
                    gcoutput = gcoutput->next;
                }

                if ((gcinput->flags & /*USE_MY_METRICS*/0x200) != 0)
                    gcoutput->flags |= 0x200;
                if ((gcinput->flags & /*ROUND_XY_TO_GRID*/0x004) != 0)
                    gcoutput->flags |= 0x004;
            }
        }
    }
}

static bool IsClosed(CF_QuadContour* contour)
{
    if (contour->NumPoints() == 1)
        return false;

    CF_ContourPoint first = contour->GetPoint(0);
    CF_ContourPoint last = contour->GetPoint(contour->NumPoints()-1);

    if ((first.m_Point == last.m_Point) &&
        (last.m_Type != CF_ContourPoint::OFF_CURVE))
    {
        return true;
    }

    return false;
}

static Compositor_Error createQuadGlyph(CF_QuadGlyph& input, Glyph& output)
{
    // Fill in the Simple_Outline of the output glyph from the CF_QuadGlyph

    Simple_Outline* quadOutline = &output.glyphOutline.component.outline;

    quadOutline->nc = (unsigned short)input.NumContours();

    int np = 0;

    CF_QuadContour* pContour = input.FirstContour();

    while (pContour)
    {
        int contourNpts = pContour->NumPoints();

        if (IsClosed(pContour))
            contourNpts -= 1;

        np += contourNpts;

        pContour = input.NextContour();
    }

    quadOutline->np = (unsigned short)np;

    quadOutline->endPtsOfContours = new unsigned short[quadOutline->nc];
    if (NULL == quadOutline->endPtsOfContours)
        return COMPOSITOR_MEMORY;
    memset(quadOutline->endPtsOfContours, 0, quadOutline->nc * sizeof(unsigned short));

    float* x = quadOutline->x = new float[np];
    if (NULL == x)
    {
        delete [] quadOutline->endPtsOfContours;
        return COMPOSITOR_MEMORY;
    }
    memset(x, 0, np * sizeof(float));

    float* y = quadOutline->y = new float[np];
    if (NULL == y)
    {
        delete [] x;
        delete [] quadOutline->endPtsOfContours;
        return COMPOSITOR_MEMORY;
    }
    memset(y, 0, np * sizeof(float));

    quadOutline->types = new Point_Type[np];
    if (NULL == quadOutline->types)
    {
        delete [] y;
        delete [] x;
        delete [] quadOutline->endPtsOfContours;
        return COMPOSITOR_MEMORY;
    }
    memset(quadOutline->types, 0, np * sizeof(Point_Type));

    unsigned short index = 0;
    int nContour = 0;

    pContour = input.FirstContour();

    while (pContour)
    {
        int nPts = pContour->NumPoints();

        if (IsClosed(pContour))
            nPts -= 1;

        for (int j = 0; j < nPts; j++)
        {
            CF_ContourPoint point = pContour->GetPoint(j);
            x[index] = point.m_Point[0];
            y[index] = point.m_Point[1];

            Point_Type type;

            if (j == 0)
                type = MOVE_TO;
            else if (point.m_Type == CF_ContourPoint::OFF_CURVE)
                type = OFF_CURVE;
            else
            {
                CF_ContourPoint prevPoint = pContour->GetPoint(j-1);
                if (prevPoint.m_Type == CF_ContourPoint::OFF_CURVE)
                    type = ON_CURVE;
                else
                    type = LINE_TO;
            }

            quadOutline->types[index++] = type;
        }
        quadOutline->endPtsOfContours[nContour++] = index - 1;

        pContour = input.NextContour();
    }

    //DumpQuad(&output); not implemented, see Conversion.cpp if needed.

    return COMPOSITOR_SUCCESS;
}

static void computeBoundingBox(Glyph& quad)
{
    Simple_Outline *quadOutline = &quad.glyphOutline.component.outline;

    quad.glyphOutline.xMax = quad.glyphOutline.xMin = quadOutline->x[0];
    quad.glyphOutline.yMax = quad.glyphOutline.yMin = quadOutline->y[0];

    for (int j = 1; j < quadOutline->np; j++)
    {
        if (quadOutline->x[j] > quad.glyphOutline.xMax)
            quad.glyphOutline.xMax = quadOutline->x[j];
        if (quadOutline->x[j] < quad.glyphOutline.xMin)
            quad.glyphOutline.xMin = quadOutline->x[j];
        if (quadOutline->y[j] > quad.glyphOutline.yMax)
            quad.glyphOutline.yMax = quadOutline->y[j];
        if (quadOutline->y[j] < quad.glyphOutline.yMin)
            quad.glyphOutline.yMin = quadOutline->y[j];
    }
}

static float checkScale(float val)
{
    float tolerance = 0.001f;

    if ((val != 1.0f) && (val != -1.0f))
    {
        if (fabs(val - 1.0) < tolerance)
            val = 1.0f;
        else if (fabs(val + 1.0) < tolerance)
            val = -1.0f;
    }

    return val;
}

static Compositor_Error createNewQuadGlyphs(CF_GlyphTable& glyphTable, Glyph** quadGlyphArray)
{
    Compositor_Error error;

    int first = glyphTable.FirstIndex();
    int last = glyphTable.LastIndex();

    if (last > 65535)
        return COMPOSITOR_FAIL;

    *quadGlyphArray = new Glyph[last+1];
    if (*quadGlyphArray == NULL)
        return COMPOSITOR_MEMORY;
    memset(*quadGlyphArray, 0, sizeof(Glyph) * (last + 1));

    for (int i = first; i <= last; i++)
    {
        CF_QuadGlyph& srcQuad = glyphTable[i];
        Glyph& dstQuad = (*quadGlyphArray)[i];

        dstQuad.glyphType = eGlyph_TTF;

        // There might be contours or components.
        if (srcQuad.HasContours())
        {
            error = createQuadGlyph(srcQuad, dstQuad);
            if (error != COMPOSITOR_SUCCESS)
                return error;

            computeBoundingBox(dstQuad);
        }

        if (srcQuad.HasComponents())
        {
            // Composite -- add the components.

            dstQuad.glyphOutline.xMin = 65536.f;
            dstQuad.glyphOutline.xMax = -65536.f;
            dstQuad.glyphOutline.yMin = 65536.f;
            dstQuad.glyphOutline.yMax = -65536.f;

            Glyph_Component* outComp = &dstQuad.glyphOutline.component;

            CF_Component* pComponent = srcQuad.FirstComponent();

            while (pComponent)
            {
                dstQuad.glyphOutline.numberOfComponents++;

                if (dstQuad.glyphOutline.numberOfComponents != 1)
                {
                    Glyph_Component* newComp = new Glyph_Component;
                    if (newComp == NULL)
                        return COMPOSITOR_MEMORY;
                    memset(newComp, 0, sizeof(Glyph_Component));

                    outComp->next = newComp;
                    outComp = newComp;
                }

                outComp->type = eIsComposite;
                outComp->glyphIndex = (unsigned short)pComponent->m_GlyphId;

                outComp->xoffset = (float)(pComponent->m_ScaleOffset.m_OffsetX);
                outComp->yoffset = (float)(pComponent->m_ScaleOffset.m_OffsetY);
                outComp->xscale = checkScale(pComponent->m_ScaleOffset.m_ScaleX);
                outComp->yscale = checkScale(pComponent->m_ScaleOffset.m_ScaleY);

                // Get bounding box of component.
                CF_QuadGlyph& compQuad = glyphTable[pComponent->m_GlyphId];

                CF_BoundingBox bb;

                compQuad.GetBounds(bb);

                // Apply scale and offset to bounding box.
                bb.Scale(outComp->xscale, outComp->yscale);

                float compXmin = bb.Left() + outComp->xoffset;
                float compXmax = bb.Right() + outComp->xoffset;
                float compYmin = bb.Bottom() + outComp->yoffset;
                float compYmax = bb.Top() + outComp->yoffset;

                if (compXmin < dstQuad.glyphOutline.xMin)
                    dstQuad.glyphOutline.xMin = compXmin;
                if (compXmax > dstQuad.glyphOutline.xMax)
                    dstQuad.glyphOutline.xMax = compXmax;
                if (compYmin < dstQuad.glyphOutline.yMin)
                    dstQuad.glyphOutline.yMin = compYmin;
                if (compYmax > dstQuad.glyphOutline.yMax)
                    dstQuad.glyphOutline.yMax = compYmax;

                pComponent = srcQuad.NextComponent();
            }

            dstQuad.glyphOutline.xMin = (float)floor(dstQuad.glyphOutline.xMin + 0.5f);
            dstQuad.glyphOutline.xMax = (float)floor(dstQuad.glyphOutline.xMax + 0.5f);
            dstQuad.glyphOutline.yMin = (float)floor(dstQuad.glyphOutline.yMin + 0.5f);
            dstQuad.glyphOutline.yMax = (float)floor(dstQuad.glyphOutline.yMax + 0.5f);
        }
    }

    return COMPOSITOR_SUCCESS;
}

static void freeGlyphOutline(Glyph *glyph)
{
    if (glyph)
    {
        if (glyph->glyphOutline.numberOfComponents > 1)
        {
            Glyph_Component* cur = glyph->glyphOutline.component.next;

            while (cur != NULL)
            {
                Glyph_Component* next = cur->next;
                delete cur;
                cur = next;
            };
        }

        Simple_Outline* so = &glyph->glyphOutline.component.outline;

        delete [] so->endPtsOfContours;
        delete [] so->x;
        delete [] so->y;
        delete [] so->types;
    }
}



///////////////////////////////////////////////////////////////////////////////
//
// public functions
//
///////////////////////////////////////////////////////////////////////////////


//
// Fills in newGlyphs with an array componentized glyphs.
// Fills in numNewGlyphs with the total number of glyphs (originaL + new components)
//
// Client must call compositor_freeQuadGlyphArray() to release the newGlyphs array.
//
extern "C" Compositor_Error compositor_findQuadComposites(Glyph* origGlyphs, int numOrigGlyphs,
              float tolerance, Glyph** newGlyphs, int* numNewGlyphs, Compositor_Progress* progress)
{
    if ((origGlyphs == NULL) || (numOrigGlyphs <= 0) || (newGlyphs == NULL) || (numNewGlyphs == NULL))
        return COMPOSITOR_INVALID_PARAM;

    if (tolerance < 0.0001f)
        tolerance = 0.0001f;
    if (tolerance > 1.0)
        tolerance = 1.0;

    *newGlyphs = NULL;

    if (progress != NULL)
        progress->progressCB(progress->userState, 0);

    Compositor_Error error;

    CF_GlyphTable  glyphTable;

    glyphTable.Clear();

    CF_QuadGlyph::ClearHeap();

    glyphTable.Init(0, numOrigGlyphs-1);

    // Convert the Glyphs to CF_QuadGlyphs, and add to table.
    for (int i = 0; i < numOrigGlyphs; i++)
    {
        CF_QuadGlyph quadGlyph(i);

        error = createCFQuadGlyph(origGlyphs[i], quadGlyph);
        if (error != COMPOSITOR_SUCCESS)
        {
            glyphTable.Clear();
            CF_QuadGlyph::ClearHeap();
            return error;
        }

        glyphTable[i] = quadGlyph;
    }

    // Mark any components
    for (int i = 0; i < numOrigGlyphs; i++)
    {
        if (glyphTable[i].HasComponents())
        {
            CF_Component* comp = glyphTable[i].FirstComponent();

            while (comp != NULL)
            {
                glyphTable[comp->m_GlyphId].SetIsComponent(true);
                comp = glyphTable[i].NextComponent();
            }
        }
    }

    CF_GlyphCompositor* compositor = new CF_GlyphCompositor;
    if (compositor == NULL)
    {
        glyphTable.Clear();
        CF_QuadGlyph::ClearHeap();
        return COMPOSITOR_MEMORY;
    }

    if (progress != NULL)
        progress->progressCB(progress->userState, 20);

    // Call the algorithm with your glyphTable.
    compositor->FindComponents(glyphTable, tolerance, (progress != NULL) ? true : false);

    if (progress != NULL)
        progress->progressCB(progress->userState, 70);

    *numNewGlyphs = glyphTable.LastIndex()+1;

    error = createNewQuadGlyphs(glyphTable, newGlyphs);
    if (error != COMPOSITOR_SUCCESS)
    {
        compositor_freeQuadGlyphArray(*newGlyphs, *numNewGlyphs);
        delete compositor;
        glyphTable.Clear();
        CF_QuadGlyph::ClearHeap();
        return error;
    }

    // Preserve flags of any original composites
    preserveOriginalCompFlags(origGlyphs, numOrigGlyphs, *newGlyphs);

    glyphTable.Clear();
    delete compositor;
    CF_QuadGlyph::ClearHeap();      // Frees all memory that glyphs alloc�d: it�s all in one ArrayList.

    if (progress != NULL)
        progress->progressCB(progress->userState, 100);

    return COMPOSITOR_SUCCESS;
}

extern "C" void compositor_freeQuadGlyphArray(Glyph* glyphArray, int count)
{
    if (NULL == glyphArray)
        return;

    for (int i = 0; i < count; i++)
        freeGlyphOutline(&glyphArray[i]);

    delete[] glyphArray;
}
