// Copyright (C) 2014 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
/// \file CF_Line2D.h

#ifndef CF_LINE_2D_H
#define CF_LINE_2D_H

#include "CF_Vector2f.h"
#include "CF_ArrayList.h"

class CF_Line2D
{
    public:
                    CF_Line2D       ();
                    CF_Line2D       (const CF_Vector2f& start, const CF_Vector2f& end);

        bool        Intersects      (const CF_Line2D& other) const;
        CF_Vector2f Intersection    (CF_Line2D& other);

        void        GetIntersections(CF_Line2D& other, CF_ArrayList<CF_Vector2f>& intersections);

        CF_Vector2f    Start           () const;
        CF_Vector2f    End             () const;

    protected:

        CF_Vector2f    m_Start;
        CF_Vector2f    m_End;
};


#endif
