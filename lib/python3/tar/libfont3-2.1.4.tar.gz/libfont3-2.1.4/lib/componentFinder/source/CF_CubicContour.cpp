// Copyright (C) 2015 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// CF_CubicContour.cpp

#include "CF_CubicContour.h"
#include "CF_CubicBezier.h"
#include "CF_ArrayList.h"
#include "CF_BoundingBox.h"

CF_CubicContour::CF_CubicContour()
    : CF_Contour()
{
}

bool CF_CubicContour::GetFirstCubic(CF_CubicPoints& points)
{
    m_Index = 0;
    m_CurrentPoint = 0;
    
    return GetNextCubic(points);
 }

bool CF_CubicContour::GetNextCubic(CF_CubicPoints& points)
{
    bool foundCubic = false;

    while (foundCubic == false && m_CurrentPoint < m_Points.NumElements())
    {
        CF_ContourPoint& currentPoint = m_Points[m_CurrentPoint];     

        switch (currentPoint.m_Type)
        {
            case CF_ContourPoint::ON_CURVE:

                m_Point[m_Index] = currentPoint.m_Point;
                m_Index++;

                // If it's a line strip it out.
                if (m_Index == 2)
                {
                    m_Point[0] = m_Point[1];
                    m_Index = 1;
                }

                if (m_Index == 4)
                {
                    points.m_Start    = m_Point[0];
                    points.m_Control1 = m_Point[1];
                    points.m_Control2 = m_Point[2];
                    points.m_End      = m_Point[3];

                    m_Point[0] = m_Point[3];
                    m_Index = 1;
                    foundCubic = true;
                }

            break;

            case CF_ContourPoint::OFF_CURVE:
                m_Point[m_Index] = currentPoint.m_Point;
                m_Index++;
            break;
        }

        m_CurrentPoint++;
    }

    return foundCubic;
}

bool CF_CubicContour::GetFirstLine(CF_Line2D& line)
{
    m_Index = 0;
    m_CurrentPoint = 0;

    return GetNextLine(line);
}

bool CF_CubicContour::GetNextLine(CF_Line2D& line)
{
    bool foundLine = false;

    while (foundLine == false && m_CurrentPoint < m_Points.NumElements())
    {
        CF_ContourPoint& currentPoint = m_Points[m_CurrentPoint];     

        switch (currentPoint.m_Type)
        {
            case CF_ContourPoint::ON_CURVE:

                m_Point[m_Index] = currentPoint.m_Point;
                m_Index++;

                if (m_Index == 2)
                {
                    line = CF_Line2D(m_Point[0], m_Point[1]);
                    foundLine = true;
                    m_Point[0] = m_Point[1];
                    m_Index = 1;
                }

                // If it's a cubic stip it out.
                if (m_Index == 4)
                {
                    m_Point[0] = m_Point[3];
                    m_Index = 1;
                }

            break;

            case CF_ContourPoint::OFF_CURVE:
                m_Point[m_Index] = currentPoint.m_Point;
                m_Index++;
            break;
        }

        m_CurrentPoint++;
    }

    return foundLine;
}

bool CF_CubicContour::Contains(CF_Vector2f& point)
{
    const float LARGE_FLOAT = 1e5f;

    bool containsPoint = false;
    float y = point.Y();

    CF_Line2D line(CF_Vector2f(-LARGE_FLOAT, y), CF_Vector2f(LARGE_FLOAT, y));

    CF_ArrayList<CF_Vector2f> intersections;

    if (Intersects(line))
    {
        GetIntersections(line, intersections);

        int count = 0;
        for (int i = 0; i < intersections.NumElements(); i++)
        {
            if (intersections[i].X() < point.X())
            {
                count++;
            }
        }
        if (count % 2 == 1)
        {
            containsPoint = true;
        }
        else
        {
            containsPoint = false;
        }
    }

    return containsPoint;
}

bool CF_CubicContour::Contains(CF_CubicContour& other)
{
    const float EPSILON = 0.005f;

    if (other.NumPoints() > 0)
    {
        CF_ContourPoint point = other.GetPoint(0);
        point.m_Point[1] += EPSILON;

        if (Contains(point.m_Point))
        {
            if (false == Intersects(other))
            {
                return true;
            }
        }
    }
    return false;
}

bool CF_CubicContour::Intersects(CF_CubicContour& otherContour)
{
    CF_Line2D line;

    bool newLine = GetFirstLine(line);

    while (newLine)
    {
        if (otherContour.Intersects(line))
        {
            return true;
        }
        newLine = GetNextLine(line);
    }

    CF_CubicPoints cubicPoints;

    bool newCubic = GetFirstCubic(cubicPoints);

    while (newCubic)
    {
        CF_CubicBezier cubic(cubicPoints);

        if (otherContour.Intersects(cubic))
        {
            return true;
        }
        newCubic = GetNextCubic(cubicPoints);
    }

    return false;
}

bool CF_CubicContour::Intersects(CF_Line2D& line)
{
    CF_Line2D contourLine;

    bool newLine = GetFirstLine(contourLine);

    while (newLine)
    {
        if (contourLine.Intersects(line))
        {
            return true;
        }
        newLine = GetNextLine(contourLine);
    }

    CF_CubicPoints cubicPoints;

    bool newCubic = GetFirstCubic(cubicPoints);

    while (newCubic)
    {
        CF_CubicBezier cubic(cubicPoints);

        if (cubic.Intersects(line))
        {
            return true;
        }
        newCubic = GetNextCubic(cubicPoints);
    }

    return false;
}

bool CF_CubicContour::Intersects(CF_CubicBezier& cubic)
{
    CF_Line2D contourLine;

    bool newLine = GetFirstLine(contourLine);

    while (newLine)
    {
        if (cubic.Intersects(contourLine))
        {
            return true;
        }
        newLine = GetNextLine(contourLine);
    }

    CF_CubicPoints cubicPoints;

    bool newCubic = GetFirstCubic(cubicPoints);

    while (newCubic)
    {
        CF_CubicBezier contourCubic(cubicPoints);

        if (cubic.Intersects(contourCubic))
        {
            return true;
        }
        newCubic = GetNextCubic(cubicPoints);
    }

    return false;
}

void CF_CubicContour::GetIntersections(CF_CubicContour& otherContour, CF_ArrayList<CF_Vector2f>& intersections)
{
    intersections.ResetIndex();

    CF_Line2D line;

    bool newLine = GetFirstLine(line);

    while (newLine)
    {
        otherContour.GetIntersections(line, intersections);

        newLine = GetNextLine(line);
    }

    CF_CubicPoints cubicPoints;

    bool newCubic = GetFirstCubic(cubicPoints);

    while (newCubic)
    {
        CF_CubicBezier cubic(cubicPoints);

        otherContour.GetIntersections(cubic, intersections);

        newCubic = GetNextCubic(cubicPoints);
    }
}

void CF_CubicContour::GetIntersections(CF_Line2D& line, CF_ArrayList<CF_Vector2f>& intersections)
{
    CF_Line2D contourLine;

    bool newLine = GetFirstLine(contourLine);

    while (newLine)
    {
        contourLine.GetIntersections(line, intersections);

        newLine = GetNextLine(contourLine);
    }

    CF_CubicPoints cubicPoints;

    bool newCubic = GetFirstCubic(cubicPoints);

    while (newCubic)
    {
        CF_CubicBezier cubic(cubicPoints);

        cubic.GetIntersections(line, intersections);

        newCubic = GetNextCubic(cubicPoints);
    }
}

void CF_CubicContour::GetIntersections(CF_CubicBezier& cubic, CF_ArrayList<CF_Vector2f>& intersections)
{
    CF_Line2D contourLine;

    bool newLine = GetFirstLine(contourLine);

    while (newLine)
    {
        cubic.GetIntersections(contourLine, intersections);

        newLine = GetNextLine(contourLine);
    }

    CF_CubicPoints cubicPoints;

    bool newCubic = GetFirstCubic(cubicPoints);

    while (newCubic)
    {
        CF_CubicBezier contourCubic(cubicPoints);

        cubic.GetIntersections(contourCubic, intersections);

        newCubic = GetNextCubic(cubicPoints);
    }
}


bool CF_CubicContour::CheckWinding()
{
    bool windingOk = false;

    CF_Handedness handedness = GetHandedness();

    if ((m_NestingLevel % 2) == 1)
    {
        if (handedness == eCF_CW)
        {
            windingOk = true;
        }
    }
    else
    {
        if (handedness == eCF_CCW)
        {
            windingOk = true;
        }
    }

    return windingOk;
}

bool CF_CubicContour::GetBounds(CF_BoundingBox& boundsBox)
{
    CF_CubicPoints cubic;
    CF_Line2D      line;

    bool newLine = GetFirstLine(line);

    if (newLine)
    {
        boundsBox.Expand(line.Start());
    }

    while (newLine)
    {
        boundsBox.Expand(line.End());

        newLine = GetNextLine(line);
    }

    bool newCubic = GetFirstCubic(cubic);

    bool leftTangent    = false;
    bool rightTangent   = false;
    bool topTangent     = false;
    bool bottomTangent  = false;

    while (newCubic)
    {
        CF_CubicBezier cubicBezier(cubic);

        if (boundsBox.ExpandLeft(cubicBezier.LeftExtent()))
        {
            leftTangent = cubicBezier.LeftIsTangent();
        }

        if (boundsBox.ExpandRight(cubicBezier.RightExtent()))
        {
            rightTangent = cubicBezier.RightIsTangent();
        }

        if (boundsBox.ExpandTop(cubicBezier.TopExtent()))
        {
            topTangent = cubicBezier.TopIsTangent();
        }

        if (boundsBox.ExpandBottom(cubicBezier.BottomExtent()))
        {
            bottomTangent = cubicBezier.BottomIsTangent();
        }

        newCubic = GetNextCubic(cubic);
    }

    return (!leftTangent && !rightTangent && !topTangent && !bottomTangent);
}
