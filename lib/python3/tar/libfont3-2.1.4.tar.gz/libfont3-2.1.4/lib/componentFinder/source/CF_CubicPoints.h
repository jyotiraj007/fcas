// Copyright (C) 2016 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// CF_CubicPoints.h

#ifndef CF_CUBIC_POINTS_H
#define CF_CUBIC_POINTS_H

#include "CF_Vector2f.h"

struct CF_CubicPoints
{
    CF_Vector2f    m_Start;
    CF_Vector2f    m_End;
    CF_Vector2f    m_Control1;
    CF_Vector2f    m_Control2;

    CF_CubicPoints() {};

    CF_CubicPoints(const CF_Vector2f& start, const CF_Vector2f& end, const CF_Vector2f& control1, const CF_Vector2f& control2)
        :   m_Start     (start),
            m_End       (end),
            m_Control1  (control1),
            m_Control2  (control2)
    {
    }
};

#endif
