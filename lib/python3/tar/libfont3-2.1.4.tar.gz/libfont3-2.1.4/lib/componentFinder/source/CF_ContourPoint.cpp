// Copyright (C) 2015 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// CF_ContourPoint.cpp

#include "CF_ContourPoint.h"

/* CTOR */ CF_ContourPoint::CF_ContourPoint() : m_Point()
{
}

/* CTOR */ CF_ContourPoint::CF_ContourPoint(CF_PointType type, CF_Vector2f point)
{
    m_Type       = type;
    m_Point      = point;
}
