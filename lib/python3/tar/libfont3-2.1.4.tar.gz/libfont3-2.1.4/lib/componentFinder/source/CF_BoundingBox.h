// Copyright (C) 2016 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// CF_BoundingBox.h

#ifndef CF_BOUNDING_BOX_H
#define CF_BOUNDING_BOX_H

#include "CF_Vector2f.h"
#include "CF_MathUtilities.h"
#include "CF_ScaleOffset.h"
#include <float.h>

class CF_BoundingBox
{
    public:
        /* CTOR */  CF_BoundingBox ();

        void        Reset       ();
        bool        Expand      (const CF_Vector2f& point);
        bool        ExpandLeft  (float x);
        bool        ExpandRight (float x);
        bool        ExpandTop   (float y);
        bool        ExpandBottom(float y);

        float       Left        ();
        float       Right       ();
        float       Bottom      ();
        float       Top         ();

        float       Width       ();
        float       Height      ();

        void        Scale       (float scale);
        void        Scale       (float xScale, float yScale);

        CF_ScaleOffset  GetScaleOffset(CF_BoundingBox& other);

    protected:

        float   m_Left;
        float   m_Right;
        float   m_Top;
        float   m_Bottom;
};

// Implementation:
inline CF_BoundingBox::CF_BoundingBox() 
    : m_Left    (+FLT_MAX),
      m_Right   (-FLT_MAX),
      m_Top     (-FLT_MAX),
      m_Bottom  (+FLT_MAX)
{
};

inline void CF_BoundingBox::Reset()
{
    m_Left   = +FLT_MAX;
    m_Right  = -FLT_MAX;
    m_Top    = -FLT_MAX;
    m_Bottom = +FLT_MAX;
};


inline bool CF_BoundingBox::ExpandLeft(float x)
{
    bool expanded = false;

    if (x < m_Left)
    {
        m_Left = x;
        expanded = true;
    }

    return expanded;
}

inline bool CF_BoundingBox::ExpandRight(float x)
{
    bool expanded = false;

    if (x > m_Right)
    {
        m_Right = x;
        expanded = true;
    }

    return expanded;
}

inline bool CF_BoundingBox::ExpandBottom(float y)
{
    bool expanded = false;

    if (y < m_Bottom)
    {
        m_Bottom = y;
        expanded = true;
    }

    return expanded;
}

inline bool CF_BoundingBox::ExpandTop(float y)
{
    bool expanded = false;

    if (y > m_Top)
    {
        m_Top = y;
        expanded = true;
    }

    return expanded;
}


inline bool CF_BoundingBox::Expand(const CF_Vector2f& point)
{
    bool expanded = false;

    expanded |= ExpandLeft  (point.X());
    expanded |= ExpandRight (point.X());
    expanded |= ExpandTop   (point.Y());
    expanded |= ExpandBottom(point.Y());

    return expanded;
}

inline float CF_BoundingBox::Left  () { return m_Left;   };
inline float CF_BoundingBox::Right () { return m_Right;  };
inline float CF_BoundingBox::Top   () { return m_Top;    };
inline float CF_BoundingBox::Bottom() { return m_Bottom; };

inline float CF_BoundingBox::Width () { return m_Right - m_Left;   };
inline float CF_BoundingBox::Height() { return m_Top   - m_Bottom; };


inline void CF_BoundingBox::Scale(float scale)
{
    m_Left   *= scale;
    m_Right  *= scale;
    m_Top    *= scale;
    m_Bottom *= scale;
}

inline void CF_BoundingBox::Scale(float xScale, float yScale)
{
    m_Left   *= xScale;
    m_Right  *= xScale;
    m_Top    *= yScale;
    m_Bottom *= yScale;
}


// Returns the scale offset to change other into this.
inline CF_ScaleOffset CF_BoundingBox::GetScaleOffset(CF_BoundingBox& other)
{
    CF_ScaleOffset scaleOffset;

    scaleOffset.m_ScaleX = 1.0f;
    scaleOffset.m_ScaleY = 1.0f;

    // Careful with single point contours:
    if (other.Width() != 0.0f)
    {
        scaleOffset.m_ScaleX = Width() / other.Width();
    }

    if (other.Height() != 0.0f)
    {
        scaleOffset.m_ScaleY = Height() / other.Height();
    }

    CF_BoundingBox scaled = other;
    scaled.Scale(scaleOffset.m_ScaleX, scaleOffset.m_ScaleY);

    scaleOffset.m_OffsetX = (int)((Left()   - scaled.Left())  + 0.5f);
    scaleOffset.m_OffsetY = (int)((Bottom() - scaled.Bottom()) + 0.5f);

    return scaleOffset;
}

#endif
