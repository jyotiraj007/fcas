// Copyright (C) 2016 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// CF_Component.h

#ifndef CF_COMPONENT_H
#define CF_COMPONENT_H

#include "CF_Vector2f.h"
#include "CF_ScaleOffset.h"

class CF_Component
{
    public:

        /* CTOR */  CF_Component   ();
        /* CTOR */  CF_Component   (int glyphId, CF_ScaleOffset scaleOffset);

        int         m_GlyphId;

        CF_ScaleOffset m_ScaleOffset;
};

#endif

