// Copyright (C) 2016 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// CF_GlyphCompositor.h

#ifndef CF_GLYPH_COMPOSITOR_H
#define CF_GLYPH_COMPOSITOR_H


#include "CF_Trie.h"
#include "CF_QuadGlyph.h"
#include "CF_CubicGlyph.h"
#include "CF_NormalizedContour.h"
#include "CF_IndexTable.h"
#include "CF_Array.h"
#include "CF_ContourGroup.h"
#include "CF_Stack.h"
#include "CF_ComboArrayList.h"


typedef CF_IndexTable<CF_QuadGlyph>     CF_GlyphTable;


class CF_GlyphCompositor
{
    public:

        /* CTOR */	CF_GlyphCompositor  ();
		/* DTOR */ ~CF_GlyphCompositor	();
        void        Clear               ();


        void        FindComponents      (CF_GlyphTable& glyphTable, float tolerance = 0.05f, bool verbose = true);


        // For use of the demo:
        int         CalcSize            (CF_GlyphTable& glyphTable);
        void        AddGlyphs           (CF_GlyphTable& glyphTable, float tolerance = 0.05f, bool verbose = true);
        void        Componentize        (CF_GlyphTable& glyphTable);

    protected:

        bool        GetGroup            (int glyphId, CF_GlyphTable& glyphTable, CF_ContourGroup& group, CF_ArrayList<int>& sequence);
        void        GetGroups           (CF_QuadGlyph& glyph, CF_ArrayList<CF_ArrayList<int> >& groups);

        void        MakeGroupTrie       (CF_GlyphTable& glyphTable);
        void        AddGlyph            (CF_QuadGlyph& quadGlyph);

        int         m_FirstGroup;

        int         FindGroup           (CF_QuadGlyph& group, CF_GlyphTable& glyphTable);

        int         CreateGroup         (CF_QuadGlyph& group, CF_GlyphTable& glyphTable);

        CF_Trie<CF_NormalizedPoint>     m_Trie; // Trie of contours.
        CF_Trie<int>                    m_GroupTrie;

        bool                            m_Verbose;
};

#endif
