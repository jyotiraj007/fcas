// Copyright (C) 2014 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// MathUtilities.h

#ifndef CF_MATH_UTILITIES_H
#define CF_MATH_UTILITIES_H

#include <math.h>
#include "CF_Vector2f.h"
#include "CF_Line2D.h"

static const double CF_PI     = 3.14159265;

static inline double CF_ToRadians(double degrees)
{
    return degrees * (CF_PI / 180);
}

static inline double CF_ToDegrees(double radians)
{
    return radians * (180.0 / CF_PI);
}

static inline bool CF_IsNan(double x)
{
    return x != x;  //lint !e777
}

static inline bool CF_IsInf(double x)
{
    return !CF_IsNan(x) && CF_IsNan(x - x);
}

static inline bool CF_IsNam(float x)
{
    return x != x;
}

static inline bool CF_IsInf(float x)
{
    return !CF_IsNan(x) && CF_IsNan(x - x);
}

static inline float CF_Clamp(float& value, float low, float high)
{
    if (value < low)
    {
        value = low;
    }
    if (value > high)
    {
        value = high;
    }
    return value;
}

static inline double CF_Clamp(double& value, double low, double high)
{
    if (value < low)
    {
        value = low;
    }
    if (value > high)
    {
        value = high;
    }
    return value;
}

static inline void CF_Clamp(int& value, int low, int high)
{
    if (value < low)
    {
        value = low;
    }
    if (value > high)
    {
        value = high;
    }
}

// Convert 16:16 Fixed Point to float.
static inline float CF_FixedToFloat(int fixed)
{
    return (float) fixed / 65536.0f;
}

static inline int CF_FloatToFixed(float val)
{
    float shifted = val * 65536.0f;
    return (int) shifted;
}


static inline CF_Vector2f CF_Interpolate(CF_Vector2f& a, CF_Vector2f& b, float t)
{
    CF_Vector2f result;

    result[0] = a[0] + (b[0] - a[0]) * t;
    result[1] = a[1] + (b[1] - a[1]) * t;

    return result;
}


/*
// Actually twice triangle area, but we're just looking for the sign.
static inline float TriangleArea(CF_Vector2f v1, CF_Vector2f v2, CF_Vector2f v3)
{
    return (v3[0] * v2[1] - v2[0] * v3[1]) - (v3[0] * v1[1] - v1[0] * v3[1]) + (v2[0] * v1[1] - v1[0] * v2[1]);
}
*/

static inline void CF_Swap(int& a, int& b)
{
    int temp = a;
    a = b;
    b = temp;
}

static inline void CF_Swap(float& a, float& b)
{
    float temp = a;
    a = b;
    b = temp;
}

static inline float CF_F_MIN(float a, float b)
{
    return (a < b ? a : b);
}

static inline float CF_F_MAX(float a, float b)
{
    return (a > b ? a : b);
}



#endif
