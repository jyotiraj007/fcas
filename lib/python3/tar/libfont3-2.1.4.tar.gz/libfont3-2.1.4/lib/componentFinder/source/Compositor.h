// Copyright (C) 2016 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
/// \file Compositor.h

#ifndef __COMPOSITOR_H__
#define __COMPOSITOR_H__

#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

#include "../../conversion/source/Conversion.h"

typedef enum
{
    COMPOSITOR_SUCCESS = 0,
    COMPOSITOR_FAIL,
    COMPOSITOR_INVALID_PARAM,
    COMPOSITOR_MEMORY
} Compositor_Error;


typedef Compositor_Error (*Compositor_Progress_CB)(void* userState, int progress);

typedef struct
{
    void* userState;
    Compositor_Progress_CB progressCB;
} Compositor_Progress;

Compositor_Error compositor_findQuadComposites(Glyph* origGlyphs, int numOrigGlyphs, float tolerance, Glyph** newGlyphs, int* numNewGlyphs, Compositor_Progress* progress);
void             compositor_freeQuadGlyphArray(Glyph* glyphArray, int count);

#ifdef __cplusplus
}
#endif

#endif // __COMPOSITOR_H__
