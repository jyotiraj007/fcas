// Copyright (C) 2016 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// CF_OffsetContour.h

#ifndef CF_OFFSET_CONTOUR_H
#define CF_OFFSET_CONTOUR_H

#include "CF_Contour.h"
#include "CF_ScaleOffset.h"
#include <stdlib.h>
#include <math.h>

class CF_Offset
{
    public:

		CF_Offset()
            :   m_Data(0)
        {};
        
		CF_Offset(float x, float y, bool onCurve)
        {
            m_Shorts.m_OnCurve = onCurve;
            m_Shorts.m_X = (signed int) floor(x);   //bb check we don't quantize fp precision error.
            m_Shorts.m_Y = (signed int) floor(y);
        }

        operator int() { return m_Data; };

        union
        {
            int   m_Data;

            struct
            {
                  signed int m_OnCurve : 2;
                  signed int m_X       : 15;
                  signed int m_Y       : 15;
            } m_Shorts;
        };
};


class CF_OffsetContour
{
    public:
        /* CTOR */      CF_OffsetContour        ();
        /* CTOR */      CF_OffsetContour        (CF_Contour& contour);

       CF_ArrayList<CF_Offset>&                GetOffsets();

    protected:

        CF_ArrayList<CF_Offset> m_Points;
};



#endif
