// Copyright (C) 2015 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// CF_QuadContour.cpp

#include "CF_QuadContour.h"
#include "CF_QuadBezier.h"
#include "CF_MathUtilities.h"
#include "CF_BoundingBox.h"

CF_QuadContour::CF_QuadContour()
    :   CF_Contour(),
        m_Tag(false)
{
}

bool CF_QuadContour::GetFirstQuad(CF_QuadPoints& points)
{
    m_Index = 0;
    m_CurrentPoint = 0;
    
    return GetNextQuad(points);
 }

bool CF_QuadContour::GetNextQuad(CF_QuadPoints& points)
{
    bool foundQuad = false;

    while (foundQuad == false && m_CurrentPoint < m_Points.NumElements())
    {
        CF_ContourPoint& currentPoint = m_Points[m_CurrentPoint];     

        switch (currentPoint.m_Type)
        {
            case CF_ContourPoint::ON_CURVE:

                m_Point[m_Index] = currentPoint.m_Point;
                m_Index++;

                // If it's a line strip it out.
                if (m_Index == 2)
                {
                    m_Point[0] = m_Point[1];
                    m_Index = 1;
                }

                if (m_Index == 3)
                {
                    points.m_Start    = m_Point[0];
                    points.m_Control  = m_Point[1];
                    points.m_End      = m_Point[2];

                    m_Point[0] = m_Point[2];
                    m_Index = 1;
                    foundQuad = true;
                }

            break;

            case CF_ContourPoint::OFF_CURVE:

                m_Point[m_Index] = currentPoint.m_Point;
                m_Index++;

                if (m_Index == 3)
                {
                    CF_Vector2f midPoint = CF_Interpolate(m_Point[1], m_Point[2], 0.5f);
                    
                    points.m_Start    =  m_Point[0];
                    points.m_Control  =  m_Point[1];
                    points.m_End      =  midPoint;

                    m_Point[0] = midPoint;
                    m_Point[1] = m_Point[2];
                    m_Index = 2;
                    foundQuad = true;
                }

            break;
        }

        m_CurrentPoint++;
    }

    return foundQuad;
}

bool CF_QuadContour::GetFirstLine(CF_Line2D& line)
{
    m_Index = 0;
    m_CurrentPoint = 0;

    return GetNextLine(line);
}

bool CF_QuadContour::GetNextLine(CF_Line2D& line)
{
    bool foundLine = false;

    while (foundLine == false && m_CurrentPoint < m_Points.NumElements())
    {
        CF_ContourPoint& currentPoint = m_Points[m_CurrentPoint];     

        switch (currentPoint.m_Type)
        {
            case CF_ContourPoint::ON_CURVE:

                m_Point[m_Index] = currentPoint.m_Point;
                m_Index++;

                if (m_Index == 2)
                {
                    line = CF_Line2D(m_Point[0], m_Point[1]);
                    foundLine = true;
                    m_Point[0] = m_Point[1];
                    m_Index = 1;
                }

                // If it's a quad stip it out.
                if (m_Index == 3)
                {
                    m_Point[0] = m_Point[2];
                    m_Index = 1;
                }

            break;

            case CF_ContourPoint::OFF_CURVE:
            
                m_Point[m_Index] = currentPoint.m_Point;
                m_Index++;

                if (m_Index == 3)
                {
                     m_Index = 2;
                }
            break;
        }

        m_CurrentPoint++;
    }

    return foundLine;
}


bool CF_QuadContour::Contains(CF_Vector2f& point)
{
    const float LARGE_FLOAT = 1e5f;

    bool containsPoint = false;
    float y = point.Y();

    CF_Line2D line(CF_Vector2f(-LARGE_FLOAT, y), CF_Vector2f(LARGE_FLOAT, y));

    CF_ArrayList<CF_Vector2f> intersections;

    if (Intersects(line))
    {
        GetIntersections(line, intersections);

        int count = 0;
        for (int i = 0; i < intersections.NumElements(); i++)
        {
            if (intersections[i].X() < point.X())
            {
                count++;
            }
        }
        if (count % 2 == 1)
        {
            containsPoint = true;
        }
        else
        {
            containsPoint = false;
        }
    }

    return containsPoint;
}

bool CF_QuadContour::Contains(CF_QuadContour& other)
{
    const float EPSILON = 0.005f;

    if (other.NumPoints() > 0)
    {
        CF_ContourPoint point = other.GetPoint(0);
        point.m_Point[1] += EPSILON;

        if (Contains(point.m_Point))
        {
            if (false == Intersects(other))
            {
                return true;
            }
        }
    }
    return false;
}


bool CF_QuadContour::Intersects(CF_QuadContour& otherContour)
{
    CF_Line2D line;

    bool newLine = GetFirstLine(line);

    while (newLine)
    {
        if (otherContour.Intersects(line))
        {
            return true;
        }
        newLine = GetNextLine(line);
    }

    CF_QuadPoints quadPoints;
    
    bool newQuad = GetFirstQuad(quadPoints);

    while (newQuad)
    {
        CF_QuadBezier quad(quadPoints);

        if (otherContour.Intersects(quad))
        {
            return true;
        }
        newQuad = GetNextQuad(quadPoints);
    }

    return false;
}


bool CF_QuadContour::Intersects(CF_Line2D& line)
{
    CF_Line2D contourLine;

    bool newLine = GetFirstLine(contourLine);

    while (newLine)
    {
        if (contourLine.Intersects(line))
        {
            return true;
        }
        newLine = GetNextLine(contourLine);
    }

    CF_QuadPoints quadPoints;
    
    bool newQuad = GetFirstQuad(quadPoints);

    while (newQuad)
    {
        CF_QuadBezier quad(quadPoints);

        if (quad.Intersects(line))
        {
            return true;
        }
        newQuad = GetNextQuad(quadPoints);
    }
    
    return false;
}


bool CF_QuadContour::Intersects(CF_QuadBezier& quad)
{
    CF_Line2D contourLine;

    bool newLine = GetFirstLine(contourLine);

    while (newLine)
    {
        if (quad.Intersects(contourLine))
        {
            return true;
        }
        newLine = GetNextLine(contourLine);
    }

    CF_QuadPoints quadPoints;
    
    bool newQuad = GetFirstQuad(quadPoints);

    while (newQuad)
    {
        CF_QuadBezier contourQuad(quadPoints);

        if (quad.Intersects(contourQuad))
        {
            return true;
        }
        newQuad = GetNextQuad(quadPoints);
    }
    
    return false;
}


void CF_QuadContour::GetIntersections(CF_QuadContour& otherContour, CF_ArrayList<CF_Vector2f>& intersections)
{
    intersections.ResetIndex();

    CF_Line2D line;

    bool newLine = GetFirstLine(line);

    while (newLine)
    {
        otherContour.GetIntersections(line, intersections);

        newLine = GetNextLine(line);
    }

    CF_QuadPoints quadPoints;

    bool newQuad = GetFirstQuad(quadPoints);

    while (newQuad)
    {
        CF_QuadBezier quad(quadPoints);

        otherContour.GetIntersections(quad, intersections);

        newQuad = GetNextQuad(quadPoints);
    }
}


void CF_QuadContour::GetIntersections(CF_Line2D& line, CF_ArrayList<CF_Vector2f>& intersections)
{
    CF_Line2D contourLine;

    bool newLine = GetFirstLine(contourLine);

    while (newLine)
    {
        contourLine.GetIntersections(line, intersections);

        newLine = GetNextLine(contourLine);
    }

    CF_QuadPoints quadPoints;

    bool newQuad = GetFirstQuad(quadPoints);

    while (newQuad)
    {
        CF_QuadBezier quad(quadPoints);

        quad.GetIntersections(line, intersections);

        newQuad = GetNextQuad(quadPoints);
    }
}

void CF_QuadContour::GetIntersections(CF_QuadBezier& quad, CF_ArrayList<CF_Vector2f>& intersections)
{
    CF_Line2D contourLine;

    bool newLine = GetFirstLine(contourLine);

    while (newLine)
    {
        quad.GetIntersections(contourLine, intersections);

        newLine = GetNextLine(contourLine);
    }

    CF_QuadPoints quadPoints;

    bool newQuad = GetFirstQuad(quadPoints);

    while (newQuad)
    {
        CF_QuadBezier contourQuad(quadPoints);

        quad.GetIntersections(contourQuad, intersections);

        newQuad = GetNextQuad(quadPoints);
    }
}

bool CF_QuadContour::CheckWinding()
{
    bool windingOk = false;

    CF_Handedness handedness = GetHandedness();

    if ((m_NestingLevel % 2) == 1)
    {
        if (handedness == eCF_CCW)
        {
            windingOk = true;
        }
    }
    else
    {
        if (handedness == eCF_CW)
        {
            windingOk = true;
        }
    }

    return windingOk;
}


bool CF_QuadContour::IsSinglePoint(CF_BoundingBox& boundsBox)
{
    if (1 == NumPoints())
    {
        CF_ContourPoint pt = GetPoint(0);
        boundsBox.ExpandLeft(pt.m_Point.X());
        boundsBox.ExpandRight(pt.m_Point.X());
        boundsBox.ExpandTop(pt.m_Point.Y());
        boundsBox.ExpandBottom(pt.m_Point.Y());

        return true;
    }

    return false;
}

// Bounds of the actual contour/outline. Might be larger than the point bounds.
bool CF_QuadContour::GetBounds(CF_BoundingBox& boundsBox)
{
    CF_QuadPoints  quad;
    CF_Line2D      line;

    if (IsSinglePoint(boundsBox))
    {
        return false;
    }

    bool newLine = GetFirstLine(line);

    if (newLine)
    {
        boundsBox.Expand(line.Start());
    }

    while (newLine)
    {
        boundsBox.Expand(line.End());

        newLine = GetNextLine(line);
    }

    bool leftTangent    = false;
    bool rightTangent   = false;
    bool topTangent     = false;
    bool bottomTangent  = false;

    bool newQuad = GetFirstQuad(quad);

    while (newQuad)
    {
        CF_QuadBezier quadBezier(quad);

        if (boundsBox.ExpandLeft(quadBezier.LeftExtent()))
        {
            leftTangent = quadBezier.LeftIsTangent();
        }

        if (boundsBox.ExpandRight(quadBezier.RightExtent()))
        {
            rightTangent = quadBezier.RightIsTangent();
        }

        if (boundsBox.ExpandTop(quadBezier.TopExtent()))
        {
            topTangent = quadBezier.TopIsTangent();
        }

        if (boundsBox.ExpandBottom(quadBezier.BottomExtent()))
        {
            bottomTangent = quadBezier.BottomIsTangent();
        }

        newQuad = GetNextQuad(quad);
    }

    return (!leftTangent && !rightTangent && !topTangent && !bottomTangent);
}
