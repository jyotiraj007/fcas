// Copyright (C) 2015 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
/// \file CF_ContourGroup.h

#ifndef CF_CONTOUR_GROUP_H
#define CF_CONTOUR_GROUP_H

// A list of quadcontours without all the overhead of a QuadGlyph:
// Most importantly the contours are not allocated on the static global pool of contours,
// so we can create and destroy these without blowing out memory.


#include "CF_QuadContour.h"
#include "CF_Component.h"
#include "CF_LinkedList.h"

class CF_ContourGroup
{
    public:

        /* CTOR */      CF_ContourGroup		();
        void            Clear               ();

        void            AddContour          (CF_QuadContour& contour);

        CF_QuadContour* FirstContour();
        CF_QuadContour* NextContour();

        CF_QuadContour& operator []         (int index);

        bool            operator==          (CF_ContourGroup& other);


//      bool            Contains            (CF_QuadGlyph& other);
        void            ClearTags           ();


        void            Scale               (float xScale, float yScale);

    protected:

        int             m_Iterator;
        CF_QuadContour* GetSequence         (int sequenceId);
        CF_QuadContour* RemoveContour       (int sequenceId);

        CF_ArrayList<CF_QuadContour>        m_Contours;

        friend class CF_GlyphCompositor;
        friend class CF_BezierView;
};

#endif
