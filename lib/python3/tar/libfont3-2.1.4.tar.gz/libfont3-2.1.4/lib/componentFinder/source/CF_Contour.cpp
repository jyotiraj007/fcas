// Copyright (C) 2016 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// CF_Contour.cpp

#include "CF_Contour.h"
#include "CF_BoundingBox.h"

CF_Contour::CF_Contour()
    :   m_Id            (-1),
        m_NestingLevel  (0)
{
    Clear();
}

void CF_Contour::AddPoint(const CF_ContourPoint& point)
{
    m_Points.Add(point);
}

void CF_Contour::Clear()
{
    m_Points.Clear();
} 

int CF_Contour::NumPoints()
{
    return m_Points.NumElements();
}

CF_ContourPoint& CF_Contour::GetPoint(int index)
{
    return m_Points[index];
}

void CF_Contour::Reverse()
{
    CF_ArrayList<CF_ContourPoint> reversedList;

    for (int i = m_Points.NumElements() - 1; i >=0; i--)
    {
        reversedList.Add(m_Points[i]);
    }

    m_Points = reversedList;
}

void CF_Contour::Scale(float xScale, float yScale)
{
    for (int i = 0; i < m_Points.NumElements(); i++)
    {
        CF_ContourPoint& currPoint = m_Points[i];

        currPoint.m_Point[0] *= xScale;
        currPoint.m_Point[1] *= yScale;
    }
}

void CF_Contour::Offset(float x, float y)
{
    for (int i = 0; i < m_Points.NumElements(); i++)
    {
        CF_ContourPoint& currPoint = m_Points[i];

        currPoint.m_Point[0] += x;
        currPoint.m_Point[1] += y;
    }
}

CF_Handedness CF_Contour::GetHandedness()
{
    float total = 0.0f;
    CF_Handedness handedness = eCF_CW;

    for (int i = 0; i < m_Points.NumElements() - 1; i++)
    {
        total += ((m_Points[i+1].m_Point[0] - m_Points[i].m_Point[0]) * (m_Points[i+1].m_Point[1] + m_Points[i].m_Point[1]));
    }

    if (total < 0.0)
    {
        handedness = eCF_CCW;
    }

    return handedness;
}

int CF_Contour::GetNestingLevel()
{
    return m_NestingLevel;
}

void CF_Contour::IncNestingLevel()
{
    m_NestingLevel++;
}

void CF_Contour::ClearNestingLevel()
{
    m_NestingLevel = 0;
}

void CF_Contour::SetId(int id)
{
    m_Id = id;
}

int CF_Contour::GetId()
{
    return m_Id;
}

// Bounds of just the control points.
void CF_Contour::GetPointBounds(CF_BoundingBox& boundsBox) 
{
    boundsBox.Reset();

     // Get the bounds.
    for (int i = 0; i < m_Points.NumElements(); i++)
    {
        CF_ContourPoint& currPoint = m_Points[i];

        boundsBox.ExpandLeft   (currPoint.m_Point.X());
        boundsBox.ExpandRight  (currPoint.m_Point.X());
        boundsBox.ExpandTop    (currPoint.m_Point.Y());
        boundsBox.ExpandBottom (currPoint.m_Point.Y());
    }
}

// What is scaleOffset required to change other into this.
CF_ScaleOffset CF_Contour::GetScaleOffset(CF_Contour& other)
{
    CF_BoundingBox bounds;
    CF_BoundingBox otherBounds;

    GetPointBounds(bounds);
    other.GetPointBounds(otherBounds);

    return bounds.GetScaleOffset(otherBounds);
}


void CF_Contour::ApplyScaleOffset(CF_ScaleOffset& scaleOffset)
{
    Scale(scaleOffset.m_ScaleX, scaleOffset.m_ScaleY);
    Offset((float)scaleOffset.m_OffsetX, (float)scaleOffset.m_OffsetY);
}

int CF_Contour::SizeBytes()
{
    int total = m_Points.NumElements() * sizeof(CF_ContourPoint);

    return total;
}
