// Copyright (C) 2016 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// CF_GlyphSubroutinizer.h

#ifndef CF_GLYPH_SUBROUTINIZER
#define CF_GLYPH_SUBROUTINIZER

#include "CF_Trie.h"
#include "CF_QuadGlyph.h"
#include "CF_CubicGlyph.h"
#include "CF_OffsetContour.h"
#include "CF_IndexTable.h"
#include "CF_Array.h"


typedef CF_IndexTable<CF_CubicGlyph>    CF_CubicTable;


class CF_GlyphSubroutinizer
{
    public:

		/* CTOR */  CF_GlyphSubroutinizer();
        void        Clear				();


        void        FindSubroutines(CF_CubicTable& glyphTable, float tolerance = 0.05f);


        int         CalcSize(CF_CubicTable& glyphTable);

    protected:

        void        AddGlyph        (CF_CubicGlyph&		cubicGlyph);
		void		AddContour		(CF_OffsetContour&	contour);

		CF_Trie<CF_Offset>        m_Trie;


		int                      Find(CF_Offset offset);

		CF_ArrayList<CF_Offset>  m_UniqueOffsets;
		
};

#endif
