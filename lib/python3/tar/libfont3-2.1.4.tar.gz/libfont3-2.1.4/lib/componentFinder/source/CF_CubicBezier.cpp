// Copyright (C) 2014 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// CF_CubicBezier.cpp

#include "CF_CubicBezier.h"
#include "CF_Line2D.h"
#include "CF_Stack.h"

CF_CubicBezier::CF_CubicBezier()
:   m_NumSegments(0)
{
}

CF_CubicBezier::CF_CubicBezier(const CF_Vector2f& startPoint, const CF_Vector2f& endPoint, const CF_Vector2f& controlPoint1, const CF_Vector2f& controlPoint2)
{
    Init(startPoint, endPoint, controlPoint1, controlPoint2);
}

 CF_CubicBezier::CF_CubicBezier(const CF_CubicPoints& points)
{
    Init(points.m_Start, points.m_End, points.m_Control1, points.m_Control2);
}

void CF_CubicBezier::Init(const CF_Vector2f& startPoint, const CF_Vector2f& endPoint, const CF_Vector2f& controlPoint1, const CF_Vector2f& controlPoint2)
{
    m_Control[eSTART]    = startPoint;
    m_Control[eEND]      = endPoint;
    m_Control[eCONTROL1] = controlPoint1;
    m_Control[eCONTROL2] = controlPoint2;
}

void CF_CubicBezier::Evaluate(float flatness)
{
    CF_Vector2f left;
    CF_Vector2f right;
    CF_Vector2f middle;

    CF_Vector2f middleLeft;
    CF_Vector2f middleRight;
    CF_Vector2f middleMiddle;

    float len;
    float len1;
    float len2;
    CF_Vector2f distance1;
    CF_Vector2f distance2;

    CF_Stack<CF_CubicPoints> stack;

    m_Points.ResetIndex();

    m_Points.Add(m_Control[eSTART]);
    m_NumSegments = 0;

    CF_CubicPoints points(m_Control[eSTART], m_Control[eEND], m_Control[eCONTROL1], m_Control[eCONTROL2]);

    stack.Push(points);

    while (!stack.IsEmpty())
    {
        points = stack.Pop();

        // Find the mid curve point of these controls:
        left   = 0.5f * (points.m_Start    + points.m_Control1);
        right  = 0.5f * (points.m_End      + points.m_Control2);
        middle = 0.5f * (points.m_Control1 + points.m_Control2);

        middleLeft   = 0.5f * (left + middle);
        middleRight  = 0.5f * (right + middle);
        middleMiddle = 0.5f * (middleLeft + middleRight);

        // Evaluate their flatness:
        distance1 = middleLeft  - points.m_Control1;
        distance2 = middleRight - points.m_Control2;

        len1 = distance1.LengthSquared();
        len2 = distance2.LengthSquared();

        len = len1 > len2 ? len1 : len2;

        if (len < flatness)
        {
            m_Points.Add(middleMiddle);
        }
        else
        {
            CF_CubicPoints cubicLeft(middleMiddle, points.m_End, middleRight, right);
            CF_CubicPoints cubicRight(points.m_Start, middleMiddle, left, middleLeft);

            // Split in two and keep going:
            stack.Push(cubicLeft);
            stack.Push(cubicRight);
        }
    }
    m_Points.Add(m_Control[eEND]);
    m_NumSegments = m_Points.NumElements() - 1;
}

void CF_CubicBezier::SetPoint(Control control, const CF_Vector2f& point)
{
    m_Control[control] = point;
}

CF_Vector2f CF_CubicBezier::GetPoint(Control control)
{
    return m_Control[control];
}


bool CF_CubicBezier::QuadrilateralsIntersect(CF_CubicBezier& other, CF_ArrayList<int>& list1, CF_ArrayList<int>& list2)
{
    bool foundIntersection = false;
    list1.ResetIndex();
    list2.ResetIndex();

    for (int i = 0; i < m_Quadrilaterals.NumElements(); i++)
    {
        for (int j = 0; j < other.m_Quadrilaterals.NumElements(); j++)
        {
            if (m_Quadrilaterals[i].Intersects(other.m_Quadrilaterals[j]))
            {
                list1.AddUnique(i);
                list2.AddUnique(j);
                foundIntersection = true;
            }
        }
    }
    return foundIntersection;
}


bool CF_CubicBezier::Intersects(CF_CubicBezier& other)
{
    // Initialize with single quad that is our control points.
    m_Quadrilaterals.Clear();
    m_Quadrilaterals.Add(CF_Quadrilateral(m_Control[eSTART], m_Control[eCONTROL1], m_Control[eCONTROL2], m_Control[eEND]));

    other.m_Quadrilaterals.Clear();
    other.m_Quadrilaterals.Add(CF_Quadrilateral(other.m_Control[eSTART], other.m_Control[eCONTROL1], other.m_Control[eCONTROL2], other.m_Control[eEND]));

    CF_ArrayList<int> indexList1;
    CF_ArrayList<int> indexList2;

    bool flatEnough = false;

    while (!flatEnough)
    {
        if (QuadrilateralsIntersect(other, indexList1, indexList2))
        {
            // Split the one's that intersected.
            bool thisFlatEnough  = Split(indexList1);
            bool otherFlatEnough = other.Split(indexList2);

            flatEnough = thisFlatEnough && otherFlatEnough; // Avoid && sort circuiting by using above temporaries.
        }
        else
        {   // If none intersected then the neither do the two quads.
            return false;
        }
    }

    return true;
}


void CF_CubicBezier::GetIntersections(CF_CubicBezier& other, CF_ArrayList<CF_Vector2f>& intersections)
{
    if (Intersects(other)) // This leaves m_Quadrilaterals populated with those that intersect.
    {
        // We still intersect at our flatness criteria.
        // Work out the intersections.
        for (int i = 0; i < m_Quadrilaterals.NumElements(); i++)
        {
            for (int j = 0; j < other.m_Quadrilaterals.NumElements(); j++)
            {
                CF_Line2D line1(m_Quadrilaterals[i][0], m_Quadrilaterals[i][3]);
                CF_Line2D line2(other.m_Quadrilaterals[j][0], other.m_Quadrilaterals[j][3]);

                if (line1.Intersects(line2))
                {
                    CF_Vector2f intersection = line1.Intersection(line2);
                    intersections.Add(intersection);
                }
            }
        }
    }
}

bool CF_CubicBezier::Split(CF_ArrayList<int>& indexList, float flatness /* = 0.05f */)
{
    bool flatEnough = true;

    CF_Vector2f left;
    CF_Vector2f right;
    CF_Vector2f middle;

    CF_Vector2f middleLeft;
    CF_Vector2f middleRight;
    CF_Vector2f middleMiddle;

    float len;
    float len1;
    float len2;

    CF_Vector2f distance1;
    CF_Vector2f distance2;

    CF_ArrayList<CF_Quadrilateral> source = m_Quadrilaterals;

    m_Quadrilaterals.Clear();

    for (int i = 0; i < indexList.NumElements(); i++)
    {
        int index = indexList[i];
        CF_Quadrilateral& quadrilateral = source[index];

        // Find the mid curve point of these controls:
        left   = 0.5f * (quadrilateral[0] + quadrilateral[1]);
        right  = 0.5f * (quadrilateral[3] + quadrilateral[2]);
        middle = 0.5f * (quadrilateral[1] + quadrilateral[2]);

        middleLeft   = 0.5f * (left + middle);
        middleRight  = 0.5f * (right + middle);
        middleMiddle = 0.5f * (middleLeft + middleRight);

        // Evaluate their flatness:
        distance1 = middleLeft  - quadrilateral[1];
        distance2 = middleRight - quadrilateral[2];

        len1 = distance1.LengthSquared();
        len2 = distance2.LengthSquared();

        len = len1 > len2 ? len1 : len2;

        if (len < flatness)
        {
            m_Quadrilaterals.Add(quadrilateral);
        }
        else
        {
            flatEnough = false;

            m_Quadrilaterals.Add(CF_Quadrilateral(middleMiddle, middleRight, right, quadrilateral[3]));
            m_Quadrilaterals.Add(CF_Quadrilateral(quadrilateral[0], left, middleLeft, middleMiddle));   
        }
    }

    return flatEnough;
}

bool CF_CubicBezier::Intersects(CF_Line2D& line)
{
    // Initialize with single quad that is our control points.
    m_Quadrilaterals.Clear();
    m_Quadrilaterals.Add(CF_Quadrilateral(m_Control[eSTART], m_Control[eCONTROL1], m_Control[eCONTROL2], m_Control[eEND]));

    CF_ArrayList<int> indexList;

    bool flatEnough = false;

    while (!flatEnough)
    {
        if (LineIntersects(line, indexList))
        {
            // Split the one's that intersected.
            flatEnough = Split(indexList);
        }
        else
        {   // If none intersected then the neither do the two quads.
            return false;
        }
    }

    return true;
}

void CF_CubicBezier::GetIntersections(CF_Line2D &line, CF_ArrayList<CF_Vector2f> &intersections)
{
    if (Intersects(line)) // Leaves m_Quadrilaterals populated with those that intersect line.
    {
        // We still intersect at our flatness criteria.
        // Work out the intersections.
        for (int i = 0; i < m_Quadrilaterals.NumElements(); i++)
        {
            CF_Line2D thisLine(m_Quadrilaterals[i][0], m_Quadrilaterals[i][3]);

            if (thisLine.Intersects(line))
            {
                CF_Vector2f intersection = thisLine.Intersection(line);
                intersections.Add(intersection);
            }
        }
    }
}

bool CF_CubicBezier::LineIntersects(CF_Line2D& line, CF_ArrayList<int>& indexList)
{
    bool foundIntersection = false;
    indexList.ResetIndex();

    for (int i = 0; i < m_Quadrilaterals.NumElements(); i++)
    {
        if (m_Quadrilaterals[i].Intersects(line))
        {
            foundIntersection = true;
            indexList.AddUnique(i);
        }
    }
    return foundIntersection;
}

float CF_CubicBezier::TopHorizontalTangent()
{
    const float EPSILON = 1e-2f;

    float start    = m_Control[eSTART]   .Y();
    float control1 = m_Control[eCONTROL1].Y();
    float control2 = m_Control[eCONTROL2].Y();
    float end      = m_Control[eEND]     .Y();

    float left;
    float right;
    float middle;

    float middleLeft;
    float middleRight;
    float middleMiddle;

    int count = 20; // Fail safe to avoid infinite loop. Don't expect to loop more than ~7 times.

    while (count)
    {
        // Find the mid curve point of these controls:
        left   = 0.5f * (start    + control1);
        right  = 0.5f * (end      + control2);
        middle = 0.5f * (control1 + control2);

        middleLeft   = 0.5f * (left + middle);
        middleRight  = 0.5f * (right + middle);
        middleMiddle = 0.5f * (middleLeft + middleRight);

        float difference = middleLeft - middleRight;

        if (fabs(difference) < EPSILON)
        {
            return middleMiddle;
        }
        else
        {
            if (difference < 0.0f)
            {
                start     = middleMiddle;
                control1  = middleRight;
                control2  = right;
            }
            else
            {
                end      = middleMiddle;
                control1 = left;
                control2 = middleLeft;
            }
        }
        count--;
    }
    return m_Control[eSTART].Y();
}

float CF_CubicBezier::BottomHorizontalTangent()
{
    const float EPSILON = 1e-2f;

    float start    = m_Control[eSTART]   .Y();
    float control1 = m_Control[eCONTROL1].Y();
    float control2 = m_Control[eCONTROL2].Y();
    float end      = m_Control[eEND]     .Y();

    float left;
    float right;
    float middle;

    float middleLeft;
    float middleRight;
    float middleMiddle;

    int count = 20; // Fail safe to avoid infinite loop. Don't expect to loop more than ~7 times.

    while (count)
    {
        // Find the mid curve point of these controls:
        left   = 0.5f * (start    + control1);
        right  = 0.5f * (end      + control2);
        middle = 0.5f * (control1 + control2);

        middleLeft   = 0.5f * (left + middle);
        middleRight  = 0.5f * (right + middle);
        middleMiddle = 0.5f * (middleLeft + middleRight);

        // Evaluate for horizontal.
        float difference = middleLeft - middleRight;

        if (fabs(difference) < EPSILON)
        {
            return middleMiddle;
        }
        else
        {
            if (difference > 0.0f)
            {
                start     = middleMiddle;
                control1  = middleRight;
                control2  = right;
            }
            else
            {
                end      = middleMiddle;
                control1 = left;
                control2 = middleLeft;
            }
        }
        count--;
    }
    return m_Control[eSTART].Y();
}


float CF_CubicBezier::RightVerticalTangent()
{
    const float EPSILON = 1e-2f;

    float start    = m_Control[eSTART]   .X();
    float control1 = m_Control[eCONTROL1].X();
    float control2 = m_Control[eCONTROL2].X();
    float end      = m_Control[eEND]     .X();

    float left;
    float right;
    float middle;

    float middleLeft;
    float middleRight;
    float middleMiddle;

    int count = 20; // Fail safe to avoid infinite loop. Don't expect to loop more than ~7 times.

    while (count)
    {
        // Find the mid curve point of these controls:
        left   = 0.5f * (start    + control1);
        right  = 0.5f * (end      + control2);
        middle = 0.5f * (control1 + control2);

        middleLeft   = 0.5f * (left + middle);
        middleRight  = 0.5f * (right + middle);
        middleMiddle = 0.5f * (middleLeft + middleRight);

        // Evaluate if vertical.
        float difference = left - right;

        if (fabs(difference) < EPSILON)
        {
            return middleMiddle;
        }
        else
        {
            if (difference < 0.0f)
            {
                start     = middleMiddle;
                control1  = middleRight;
                control2  = right;
            }
            else
            {
                end      = middleMiddle;
                control1 = left;
                control2 = middleLeft;
            }
        }
        count--;
    }

    return m_Control[eSTART].X();
}

float CF_CubicBezier::LeftVerticalTangent()
{
    const float EPSILON = 1e-2f;

    float start    = m_Control[eSTART]   .X();
    float control1 = m_Control[eCONTROL1].X();
    float control2 = m_Control[eCONTROL2].X();
    float end      = m_Control[eEND]     .X();

    float left;
    float right;
    float middle;

    float middleLeft;
    float middleRight;
    float middleMiddle;

    int count = 20; // Fail safe to avoid infinite loop. Don't expect to loop more than ~7 times.

    while (count)
    {
        // Find the mid curve point of these controls:
        left   = 0.5f * (start    + control1);
        right  = 0.5f * (end      + control2);
        middle = 0.5f * (control1 + control2);

        middleLeft   = 0.5f * (left + middle);
        middleRight  = 0.5f * (right + middle);
        middleMiddle = 0.5f * (middleLeft + middleRight);

        // Evaluate if vertical.
        float difference = left - right;

        if (fabs(difference) < EPSILON)
        {
            return middleMiddle;
        }
        else
        {
            if (difference > 0.0f)
            {
                start     = middleMiddle;
                control1  = middleRight;
                control2  = right;
            }
            else
            {
                end      = middleMiddle;
                control1 = left;
                control2 = middleLeft;
            }
        }
        count--;
    }

    return m_Control[eSTART].X();
}

float CF_CubicBezier::LeftExtent()
{
    m_LeftIsTangent = false;

    float left = m_Control[eSTART].X();

    if (m_Control[eEND].X() < left)
    {
        left = m_Control[eEND].X();
    }

    if (    (m_Control[eCONTROL1].X() < left) ||
            (m_Control[eCONTROL2].X() < left))
    {
        float tangent = LeftVerticalTangent();
        if (tangent < left)
        {
            left = tangent;
            m_LeftIsTangent = true;
        }
    }

    return left;
}

float CF_CubicBezier::RightExtent()
{
    m_RightIsTangent = false;

    float right = m_Control[eSTART].X();

    if (m_Control[eEND].X() > right)
    {
        right = m_Control[eEND].X();
    }

    if (    (m_Control[eCONTROL1].X() > right) ||
            (m_Control[eCONTROL2].X() > right))
    {
        float tangent = RightVerticalTangent();
        if (tangent > right)
        {
            right = tangent;
            m_RightIsTangent = true;
        }
    }

    return right;
}

float CF_CubicBezier::TopExtent()
{
    m_TopIsTangent = false;

    float top = m_Control[eSTART].Y();

    if (m_Control[eEND].Y() > top)
    {
        top = m_Control[eEND].Y();
    }

    if (    (m_Control[eCONTROL1].Y() > top) ||
            (m_Control[eCONTROL2].Y() > top))
    {
        float tangent = TopHorizontalTangent();

        if (tangent > top)
        {
            top = tangent;
            m_TopIsTangent = true;
        }
    }

    return top;
}

float CF_CubicBezier::BottomExtent()
{
    m_BottomIsTangent = false;

    float bottom = m_Control[eSTART].Y();

    if (m_Control[eEND].Y() < bottom)
    {
        bottom = m_Control[eEND].Y();
    }

    if (    (m_Control[eCONTROL1].Y() < bottom) ||
            (m_Control[eCONTROL2].Y() < bottom))
    {
        float tangent = BottomHorizontalTangent();
        if (tangent < bottom)
        {
            bottom = tangent;
            m_BottomIsTangent = true;
        }
    }

    return bottom;
}
