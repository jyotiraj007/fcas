// Copyright (C) 2014 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// CF_QuadBezier.h

#ifndef CF_QUAD_BEZIER_H
#define CF_QUAD_BEZIER_H

#include "CF_QuadPoints.h"
#include "CF_ArrayList.h"
#include "CF_Vector2f.h"
#include "CF_Stack.h"
#include "CF_Triangle.h"
#include "CF_Line2D.h"

class CF_CubicContour;


class  CF_QuadBezier
{
    public:

        enum Control { eSTART = 0, eEND, eCONTROL };

        /* Ctor */  CF_QuadBezier          ();
        /* Ctor */  CF_QuadBezier          (const CF_Vector2f& startPoint, const CF_Vector2f& endPoint, const CF_Vector2f& controlPoint);
        /* Ctor */  CF_QuadBezier          (CF_QuadPoints& quadPoints);
        void        Init                (const CF_Vector2f& startPoint, const CF_Vector2f& endPoint, const CF_Vector2f& controlPoint);

        void        SetPoint            (Control control, const CF_Vector2f& point);
        CF_Vector2f    GetPoint            (Control control);
        void        Evaluate            (float flatness = 0.01f);

        bool        Intersects          (CF_QuadBezier& other);
        void        GetIntersections    (CF_QuadBezier& other, CF_ArrayList<CF_Vector2f>& intersections);

        bool        Intersects          (CF_Line2D& line);
        void        GetIntersections    (CF_Line2D& line, CF_ArrayList<CF_Vector2f>& intersections);

        float       LeftExtent          ();
        float       RightExtent         ();
        float       TopExtent           ();
        float       BottomExtent        ();

        bool        LeftIsTangent       ();
        bool        RightIsTangent      ();
        bool        TopIsTangent        ();
        bool        BottomIsTangent     ();

    protected:

        float       HorizontalTangent   ();
        float       VerticalTangent     ();

        bool        TrianglesIntersect  (CF_QuadBezier& other, CF_ArrayList<int>& list1, CF_ArrayList<int>& list2);
        bool        LineIntersects      (CF_Line2D& line, CF_ArrayList<int>& indexList);
        bool        Split               (CF_ArrayList<int>& indexList, float flatness = 0.01f);

        CF_ArrayList<CF_Triangle>             m_Triangles;
        CF_ArrayList<CF_Vector2f>             m_Points;
        CF_Vector2f                        m_Control[3];

        bool                            m_LeftIsTangent;
        bool                            m_RightIsTangent;
        bool                            m_TopIsTangent;
        bool                            m_BottomIsTangent;
};


inline bool CF_QuadBezier::LeftIsTangent  () { return m_LeftIsTangent;    };
inline bool CF_QuadBezier::RightIsTangent () { return m_RightIsTangent;   };
inline bool CF_QuadBezier::TopIsTangent   () { return m_TopIsTangent;     };
inline bool CF_QuadBezier::BottomIsTangent() { return m_BottomIsTangent;  };



#endif
