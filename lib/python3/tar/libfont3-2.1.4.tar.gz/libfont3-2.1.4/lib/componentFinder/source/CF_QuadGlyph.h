// Copyright (C) 2015 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
/// \file CF_QuadGlyph.h

#ifndef CF_QUAD_GLYPH_H
#define CF_QUAD_GLYPH_H

#include "CF_QuadContour.h"
#include "CF_Component.h"
#include "CF_LinkedList.h"
#include "CF_ContourGroup.h"

class CF_QuadGlyph
{
    public:

        /* CTOR */      CF_QuadGlyph        ();
        /* CTOR */      CF_QuadGlyph        (unsigned int glyphId);
        /* CTOR */      CF_QuadGlyph		(CF_LinkedList<CF_QuadContour>& contours);
        /* CTOR */      CF_QuadGlyph		(CF_ContourGroup& group);

        void            Clear               ();

        void            SetGlyphId          (unsigned int glyphId);
        unsigned int    GetGlyphId          () const;

        void            SetIsComponent      (bool isComponent);
        bool            IsComponent         ();                         // Do other glyphs reference this one.

        bool            HasContours         ();
        bool            HasComponents       ();                         // Does this glyph contain references to other components.

        int             NumContours         ();
        void            AddContour          (CF_QuadContour& contour);
        void            AddComponent(CF_Component& component);

        CF_Component*   FirstComponent   ();
        CF_Component*   NextComponent    ();

        CF_QuadContour* FirstContour     ();
        CF_QuadContour* NextContour      ();

        void            AddComponent     (CF_QuadGlyph& glyph); // Use glyph as a component. remove the common contours.

        bool            operator==       (CF_QuadGlyph& other);

        bool            ContoursIntersect   ();
        //bool            CheckWinding        ();
        void            CalcNesting();

        bool            GetBounds           (CF_BoundingBox& bounds);

        bool            Contains            (CF_QuadGlyph& other);
        void            ClearTags           ();

        int             SizeBytes           ();

        void            Scale               (float xScale, float yScale);

        static void     ClearHeap           ();

        int             NumPoints(int sequenceId);

        void            GetNestedContours(CF_ArrayList<CF_ArrayList<int> >& contourGroups, CF_ArrayList<int>& counts);

    protected:

        CF_QuadContour* GetSequence         (int sequenceId);
        CF_QuadContour* RemoveContour       (int sequenceId);

        unsigned int             m_GlyphId;
        bool                     m_IsComponent;

        CF_LinkedList<CF_QuadContour>   m_Contours;
        CF_LinkedList<CF_Component>     m_Components;

        friend class CF_GlyphCompositor;
        friend class CF_BezierView;
};

#endif
