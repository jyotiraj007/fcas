// Copyright (C) 2016 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// CF_GlyphRefs.h

#ifndef CF_GLYPH_REFS_H
#define CF_GLYPH_REFS_H

#include "CF_ArrayList.h"


struct CF_GlyphRefs
{
    int            m_GlyphId;            // This glyphId.

    CF_ArrayList<int> m_SequenceIds;
    CF_ArrayList<int> m_ContourIndex;      // Index of sequence id's int the source glyph.

    CF_ArrayList<int> m_ComponentIds;       // GlyphId of component.

    void    Print()
    {
        printf("Glyph Ref: \n");
        printf("    glyphId: %d\n", m_GlyphId);

        printf("    Sequence ids: \n");
        for (int i = 0; i < m_SequenceIds.NumElements(); i++)
        {
            printf("        %d: \n", m_SequenceIds[i]);
        }

        printf("    Components: \n");
        for (int i = 0; i < m_ComponentIds.NumElements(); i++)
        {
            printf("        %d: \n", m_ComponentIds[i]);
        }
    }

};


#endif
