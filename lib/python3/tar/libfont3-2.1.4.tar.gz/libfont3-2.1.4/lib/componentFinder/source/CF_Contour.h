// Copyright (C) 2016 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// CF_Contour.h

#ifndef CF_CONTOUR_H
#define CF_CONTOUR_H

#include "CF_ContourPoint.h"
#include "CF_ArrayList.h"
#include "CF_ScaleOffset.h"

enum CF_Handedness { eCF_CW, eCF_CCW };
class CF_BoundingBox;

class CF_Contour
{
    public:

        /* CTOR */          CF_Contour          ();

        void                Clear               ();
        void                AddPoint            (const CF_ContourPoint& point);

        int                 NumPoints           ();
        CF_ContourPoint&    GetPoint            (int index);

        void                Reverse             ();

        CF_Handedness       GetHandedness       ();

        void                ClearNestingLevel   ();
        int                 GetNestingLevel     ();
        void                IncNestingLevel     ();

        void                SetId               (int id);
        int                 GetId               ();

        void                GetPointBounds      (CF_BoundingBox& boundsBox);

        void                Scale              (float xScale, float yScale);
        void                Offset             (float x, float y);

        CF_ScaleOffset      GetScaleOffset(CF_Contour& other);

        void                ApplyScaleOffset(CF_ScaleOffset& scaleOffset);

        int                 SizeBytes       ();

    protected:

        CF_ArrayList<CF_ContourPoint>   m_Points;

        int                             m_Id;
        int                             m_NestingLevel;
};

#endif
