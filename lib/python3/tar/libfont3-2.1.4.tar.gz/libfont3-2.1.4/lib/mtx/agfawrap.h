/* Copyright (C) 1989, 1990, 1991, 1992, 1993, 1994, 1995, 1996
 * all rights reserved, by Bayer Corp., Agfa Division, Wilmington, MA.
 *
 * This software is furnished under a license and may be used and
 * copied only in accordance with the terms of such license and with
 * the inclusion of the above copyright notice. This software or any
 * other copies thereof may not be provided or otherwise made
 * available to any other person except as allowed under license. No
 * title to and ownership of the software is hereby transferred.
 *
 * This information in this software is subject to change without notice
 */
/* $Header:   I:\bull\c_exprss\src\agfawrap.h_v   1.4   22 May 1997 11:16:18   MARTIN  $ */
/* $Log:   I:\bull\c_exprss\src\agfawrap.h_v  $
 * 
 *              04 Apr 2014            hadleyj
 *
 * Removed FAR declarations because we are not going to support Windows 16-bit.
 *
 *    Rev 1.4   22 May 1997 11:16:18   MARTIN
 * 
 * Added conditional compile for MTX_MEMPTRs.
 * 
 *    Rev 1.3   14 May 1997 17:17:38   MARTIN
 * 
 * Renamed MEMORY.H to MTXMEM.H.
 * 
 *    Rev 1.2   29 Apr 1997 14:38:44   MARTIN
 * 
 * Added FAR decalrations for Windows 16-bit support.
 * 
 *    Rev 1.1   16 Jan 1997 15:53:56   MARTIN
 * 
 * 
 * Made free_Packed_Data and free_Ttf_In shorts.
 * 
 *    Rev 1.0   17 Dec 1996 16:31:20   MARTIN
 * Initial revision.
   
      Rev 1.2   17 May 1996 09:12:42   MARTIN
   
   Made variable name changes.
   
      Rev 1.1   15 May 1996 17:39:58   MARTIN
   
   Added temporary file path name to arguments.
   
      Rev 1.0   13 May 1996 11:31:52   MARTIN
   Initial revision.
 */
#ifndef AGFAWRAP_H
#define AGFAWRAP_H 

#ifndef MTX_MEMPTR
#define MTX_MEMPTR
#ifdef BIT16  /* for 16-bit applications */
typedef void *(*MTX_MALLOCPTR)(unsigned long);
typedef void *(*MTX_REALLOCPTR)(void *, unsigned long, unsigned long);
typedef void (*MTX_FREEPTR)(void *);
#else         /* for 32-bit applications */
typedef void *(*MTX_MALLOCPTR)(size_t);
typedef void *(*MTX_REALLOCPTR)(void *, size_t);
typedef void (*MTX_FREEPTR)(void *);
#endif /* BIT16 */
#endif /* MTX_MEMPTR */

/*
 * File:                            AGFAWRAP.H
 * Author:                            Paul Linnerud of Microsoft
 * Revised by:                      Sara Martin
 * First Version:                    May 13, 1996
 * First pure ANSI C version:        October 28, 1996  (Sampo).
 * Added a memory based interface
 * directly in AGFAWRAP.c with
 * optional auto deletion of the
 * input data.                        Nov 18, 1996 (Sampo).
 */
#ifndef FALSE
#define FALSE               0
#endif

#ifndef TRUE
#define TRUE                1
#endif

#ifdef __cplusplus
extern "C" {
#endif

int Agfa_IS_MTX_Data( unsigned char *packed_Data, long packedDataSize );

int AgfaPack_TTF_File(
    char* szFontName,       /* Original TTF font file name */
    char* szComprName,      /* Name of output compressed file */
    long* plFontSize,       /* Size of TTF file */
    long* plComprSize,      /* Size of resultant compressed file */
    long  lcopyLimit,       /* If non-zero, maximum copy distance to use */
    MTX_MALLOCPTR mptr,        /* Pointer to a malloc function */
    MTX_REALLOCPTR rptr,    /* Pointer to a realloc function */
    MTX_FREEPTR fptr );        /* Pointer to a free function */
    
int AgfaPack_TTF_InMemory(
    unsigned char *ttf_In,    /* The pointer to the TTF data */
    long size_In,            /* Size of ttf_In */
    short free_Ttf_In,        /* If true we will always fptr( ttf_In ) */
    unsigned char **packed_DataHandle, /* *packed_DataHandle is set to point at the compressed data */
    long *plComprSize,        /* Size of resultant compressed file */
    long  lcopyLimit,          /* If non-zero, maximum copy distance to use */
    MTX_MALLOCPTR mptr,        /* Pointer to a malloc function */
    MTX_REALLOCPTR rptr,    /* Pointer to a realloc function */
    MTX_FREEPTR fptr );        /* Pointer to a free function */


int AgfaUnPack_TTF_File(
    char* szComprName,      /* Name of compressed file */
    char* szOutFile,        /* Name of output TTF font file */
    long* plOutSize,        /* Size of resultant TTF font file */
    MTX_MALLOCPTR mptr,        /* Pointer to a malloc function */
    MTX_REALLOCPTR rptr,    /* Pointer to a realloc function */
    MTX_FREEPTR fptr );        /* Pointer to a free function */
    
int AgfaUnPack_TTF_InMemory(
    unsigned char *packed_Data,        /* The pointer to the compressed data */
    long size_In,                    /* The size of the compressed data */
    short free_Packed_Data,            /* if true we will free up the packed_Data memory */
    unsigned char **ttfDataHandle,    /* *ttfDataHandle is set to point at the expanded TTF data */
    long* plOutSize,                /* Size of resultant TTF font file */
    MTX_MALLOCPTR mptr,                /* Pointer to a malloc function */
    MTX_REALLOCPTR rptr,            /* Pointer to a realloc function */
    MTX_FREEPTR fptr );                /* Pointer to a free function */

#ifdef __cplusplus
}
#endif
/* end AGFAWRAP.HPP */
#endif /* AGFAWRAP_H */
