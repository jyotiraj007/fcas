/* Copyright (C) 1989, 1990, 1991, 1992, 1993, 1994, 1995, 1996
 * all rights reserved, by Bayer Corp., Agfa Division, Wilmington, MA.
 *
 * This software is furnished under a license and may be used and
 * copied only in accordance with the terms of such license and with
 * the inclusion of the above copyright notice. This software or any
 * other copies thereof may not be provided or otherwise made
 * available to any other person except as allowed under license. No
 * title to and ownership of the software is hereby transferred.
 *
 * This information in this software is subject to change without notice
 */
/* $Header:   I:\bull\c_exprss\src\glyph.h_v   1.0   29 Apr 1997 15:51:48   MARTIN  $ */
/* $Log:   I:\bull\c_exprss\src\glyph.h_v  $
 * 
 *    Rev 1.0   29 Apr 1997 15:51:48   MARTIN
 * Initial revision.
 */

/* The Glyph class */
typedef struct {
    /* private */
    short xmax, xmin, ymax, ymin;
    short leftSideBearing, advanceWidth;

    short numberOfContours;
    short numberOfPoints;
    
    unsigned short *startPoint;
    unsigned short *endPoint;
    short *x;
    short *y;
    unsigned char *onCurve;
    short *componentData;
    short maxComponentSize;
    short componentSize;
    short componentVersionNumber;
    
    unsigned short numberOfInstructions;
    unsigned char *code;
    
    
    unsigned short    pushCount;
    short            *pushData;
    unsigned short    remainingCodeSize;
    unsigned char    *remainingCode;
    /* unsigned char    *remainingCodeType; */ 

    ctfDescriptor *ctfPtr;
    
    char *inDataStart;        /* The start of the glyph table (ctf or ttf) */
    char *inDataEnd;        /* Points at the first byte past of the glyph table (ctf or ttf) */

    MTX_MemHandler *mem;
} Glyph;

void InitCoordEncoding( void );

/* The Glyph Constructor */
Glyph *MTX_Glyph_Create( MTX_MemHandler *mem, char isTTFSpline, char *sp, long splineLength, short lsb, short aw,
                                long *bytesRead, ctfDescriptor *ctfData, char *inDataStart, char *inDataEnd );
/* Deconstructor */
void MTX_Glyph_Destroy( Glyph *t );
#ifdef COMPRESS_ON
/* Writes out the Glyph in ctf format at the location pointed to by <p>. */
/* Returns the number of bytes written. */
long MTX_Glyph_WriteCTFSpline( Glyph *t, char * *destSfnt, long pos, long *maxOutSize );
/* encode a short in 1 to 3 bytes */    
/* Writes a cvt value in the ctf format */
void WriteCVTShort( unsigned char * *pRef, short valueIn );
#endif
#ifdef DECOMPRESS_ON
/* Writes out a glyph in the TrueType format */
long MTX_Glyph_WriteTTFSpline( register Glyph *t, char * *destSfnt, long pos, long *maxOutSize );
/* Reads a cvt value in the ctf format */
short ReadCVTShort( register unsigned char * *p );
#endif
