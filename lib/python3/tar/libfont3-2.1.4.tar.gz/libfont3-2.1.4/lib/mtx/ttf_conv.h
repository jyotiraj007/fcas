/* Copyright (C) 1989, 1990, 1991, 1992, 1993, 1994, 1995, 1996
 * all rights reserved, by Bayer Corp., Agfa Division, Wilmington, MA.
 *
 * This software is furnished under a license and may be used and
 * copied only in accordance with the terms of such license and with
 * the inclusion of the above copyright notice. This software or any
 * other copies thereof may not be provided or otherwise made
 * available to any other person except as allowed under license. No
 * title to and ownership of the software is hereby transferred.
 *
 * This information in this software is subject to change without notice
 */
/* $Header:   I:\bull\c_exprss\src\ttf_conv.h_v   1.2   14 May 1997 17:19:36   MARTIN  $ */
/* $Log:   I:\bull\c_exprss\src\ttf_conv.h_v  $
 * 
 *    Rev 1.2   14 May 1997 17:19:36   MARTIN
 * 
 * Renamed MEMORY.H to MTXMEM.H.
 * 
 *    Rev 1.1   24 Mar 1997 14:24:38   MARTIN
 * 
 * Added function is_TTF_Test.
 * 
 *    Rev 1.0   17 Dec 1996 16:31:26   MARTIN
 * Initial revision.
   
      Rev 1.3   21 Oct 1996 16:08:32   MARTIN
   
   Modifications made by Sampo for memory based version.
   
      Rev 1.2   19 Aug 1996 15:11:42   MARTIN
   Added version identifier to TTF_Converter.
   
      Rev 1.1   24 Apr 1996 15:51:34   MARTIN
   
   Fixed header.
   
      Rev 1.0   24 Apr 1996 10:55:12   LISA
   Initial revision.
*/

/*
 * File:                                TTF_CONV.H
 * Author:                                Sampo Kaasila
 * First Version:                        February 6, 1996
 * First memory based version:            September 27, 1996 (Sampo)
 * Automatic memory reallocation:        October 2, 1996 (Sampo)
 * First pure ANSI C version:            October 28, 1996  (Sampo).
 * Bounds checking on all reads in the
 * TrueType data structure for increased
 * robustness. All C-structs defining
 * the TrueType fileformat were removed
 * for increased portability.
 * The subsetter code was also removed
 * since we now totally rely on the
 * Microsoft subsetting code:            November 18, 1996 (Sampo).
 * Remove the use of setjmp and longjmp. August 6, 2014 (Taylor)
 */
#include "mtxmem.h"

#ifdef __cplusplus
extern "C" {
#endif

typedef struct {
    unsigned char *ctf1; /* The ctf data minus data and code */
    long ctfSize1;
    unsigned char *ctf2; /* The ctf data */
    long ctfSize2;
    unsigned char *ctf3; /* The ctf code */
    long ctfSize3;
    long ctf2Index, ctf3Index;
} ctfDescriptor;


typedef struct {
    /* private */
    char *ttf;                /* The TrueType data */
    long ttfSize;            /* The TrueType size */

    char *tableStart;        /* The start of the input table */
    char *tableEnd;            /* Points at the first byte past the input table */
    
    ctfDescriptor ctfData;    /* ctf data descriptor */
    
    short convertFormat;
    short indexToLocFormat;
    
    MTX_MemHandler *mem;
    /* public */
    /* No public fields! */
} TTF_Converter;

/* public interface routines */
int is_TTF_Test( unsigned char *t, long dataSize  );
long MTX_TTC_GetTTFSize( TTF_Converter *t );
        
#ifdef COMPRESS_ON
int MTX_TTC_TTF_To_CTF(    TTF_Converter *t, unsigned char *ttfData, long ttfSize,
                             unsigned char * *ctf1, long *size1,
                             unsigned char * *ctf2, long *size2,
                             unsigned char * *ctf3, long *size3 );
    
    
#endif
#ifdef DECOMPRESS_ON
unsigned char *MTX_TTC_CTF_To_TTF(    TTF_Converter *t,
                                    unsigned char *ctf1, long size1,
                                      unsigned char *ctf2, long size2,
                                      unsigned char *ctf3, long size3, long *ttSize);
#endif
/* Constructor */
TTF_Converter *MTX_TTC_Create( MTX_MemHandler *mem, short version );
/* Destructor */
void MTX_TTC__Destroy( TTF_Converter *t );

#ifdef __cplusplus
}
#endif
