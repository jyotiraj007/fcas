/* Copyright (C) 1989, 1990, 1991, 1992, 1993, 1994, 1995, 1996
 * all rights reserved, by Bayer Corp., Agfa Division, Wilmington, MA.
 *
 * This software is furnished under a license and may be used and
 * copied only in accordance with the terms of such license and with
 * the inclusion of the above copyright notice. This software or any
 * other copies thereof may not be provided or otherwise made
 * available to any other person except as allowed under license. No
 * title to and ownership of the software is hereby transferred.
 *
 * This information in this software is subject to change without notice
 */
/* $Header:   I:\bull\c_exprss\src\sfnt.h_v   1.2   24 Mar 1997 14:22:38   MARTIN  $ */
/* $Log:   I:\bull\c_exprss\src\sfnt.h_v  $
 * 
 *    Rev 1.2   24 Mar 1997 14:22:38   MARTIN
 * Removed Rev 1.1 changes due to optimization issues.
 * 
 *    Rev 1.1   04 Feb 1997 10:56:44   MARTIN
 * 
 * Added calls to memmove to solve porting problems to Sun worksations.
 * Memmove will handle pointers that are not longword aligned.
 * 
 *    Rev 1.0   17 Dec 1996 16:31:30   MARTIN
 * Initial revision.
 * 
 *    Rev 1.1   24 Apr 1996 15:50:14   MARTIN
 * 
 * Fixed header.
 * 
 *    Rev 1.0   24 Apr 1996 10:54:16   LISA
 * Initial revision.
*/

/*
 * File SFNT.H
 * First pure ANSI C version:            October 28, 1996  (Sampo).
 * Bounds checking on all reads in the
 * TrueType data structure for increased
 * robustness. All C-structs defining
 * the TrueType fileformat were removed
 * for increased portability.
 * The subsetter code was also removed
 * since we now totally rely on the
 * Microsoft subsetting code:            November 18, 1996 (Sampo).
 */

#ifndef _MSC_VER
#include <inttypes.h>
#else
#include <stdint.h>
//typedef signed   char int8_t;
//typedef unsigned char uint8_t;
//typedef signed   short int16_t;
//typedef unsigned short uint16_t;
//typedef signed   int int32_t;
//typedef unsigned int uint32_t;
//typedef unsigned long long int uint64_t;
//typedef long long int int64_t;
#endif  /* _MSC_VER */

#define int32     int32_t
#define int16     int16_t
#define int8      int8_t
#define uint8     uint8_t
#define uint16    uint16_t
#define uint32    uint32_t
#define FWord     int16_t         /* a 16 bit quantity in FUnits */
#define uFWord    uint16_t        /* a 16 bit quantity in FUnits */


#ifndef Fixed

#define Fixed int32_t

#endif

#define tag_OpenTypeCFF         0x4f54544f        /* 'OTTO' */

#define tag_FontHeader          0x68656164        /* 'head' */
#define tag_HoriHeader          0x68686561        /* 'hhea' */
#define tag_IndexToLoc          0x6c6f6361        /* 'loca' */
#define tag_MaxProfile          0x6d617870        /* 'maxp' */
#define tag_ControlValue        0x63767420        /* 'cvt ' */
#define tag_MetricValue         0x6d767420        /* 'mvt ' */
#define tag_PreProgram          0x70726570        /* 'prep' */
#define tag_GlyphData           0x676c7966        /* 'glyf' */
#define tag_HorizontalMetrics   0x686d7478        /* 'hmtx' */
#define tag_CharToIndexMap      0x636d6170        /* 'cmap' */
#define tag_Kerning             0x6b65726e        /* 'kern' */
#define tag_HoriDeviceMetrics   0x68646d78        /* 'hdmx' */
#define tag_Encryption          0x63727970        /* 'cryp' */
#define tag_NamingTable         0x6e616d65        /* 'name' */
#define tag_FontProgram         0x6670676d        /* 'fpgm' */

#define tag_VertDeviceMetrics   0x56444d58        /* 'VDMX' */

#define tag_EBLC                0x45424C43          /* 'EBLC' */
#define tag_EBLC2                0x626c6f63          /* 'bloc' Apple's TT GX version */
#define tag_EBDT                0x45424454          /* 'EBDT' */
#define tag_EBDT2                0x62646174          /* 'bdat' Apple's TT GX version */

#define SHORT_INDEX_TO_LOC_FORMAT        0
#define LONG_INDEX_TO_LOC_FORMAT        1
#define GLYPH_DATA_FORMAT                0

typedef long sfnt_TableTag;

#ifdef OLD
    typedef struct {
        sfnt_TableTag    tag;
        uint32            checkSum;
        uint32            offset;
        uint32            length;
    } sfnt_DirectoryEntry;


    typedef struct {
        int32 version;                    /* 0x10000 (1.0) */
        uint16 numOffsets;                /* number of tables */
        uint16 searchRange;                /* (max2 <= numOffsets)*16 */
        uint16 entrySelector;            /* log2(max2 <= numOffsets) */
        uint16 rangeShift;                /* numOffsets*16-searchRange*/
        sfnt_DirectoryEntry table[1];    /* table[numOffsets] */
    } sfnt_OffsetTable;
#endif /* OLD */
/* const long OFFSETTABLESIZE = sizeof( sfnt_OffsetTable ) - sizeof( sfnt_DirectoryEntry ) */
#define OFFSETTABLESIZE 12L
#define DirectoryEntrySize 16L

#define GET_sfnt_fontVersion( sfnt )                ( *((sfnt_TableTag *)(sfnt)) ) /* VL */

#define GET_sfnt_numOffsets( sfnt )                 ( *((uint16 *)((char *)(sfnt) + 4)) )
#define GET_sfnt_table_tag( sfnt, i )                 ( *((sfnt_TableTag *)((char *)(sfnt) + OFFSETTABLESIZE + (i) * DirectoryEntrySize)) )
#define GET_sfnt_table_checkSum( sfnt, i )            ( *((uint32 *)((char *)(sfnt) + OFFSETTABLESIZE + (i) * DirectoryEntrySize + 4)) )
#define SET_sfnt_table_checkSum( sfnt, i, value )    ( *((uint32 *)((char *)(sfnt) + OFFSETTABLESIZE + (i) * DirectoryEntrySize + 4)) = value )
#define GET_sfnt_table_offset( sfnt, i )            ( *((uint32 *)((char *)(sfnt) + OFFSETTABLESIZE + (i) * DirectoryEntrySize + 8)) )
#define SET_sfnt_table_offset( sfnt, i, value )        ( *((uint32 *)((char *)(sfnt) + OFFSETTABLESIZE + (i) * DirectoryEntrySize + 8)) = (value) )
#define GET_sfnt_table_length( sfnt, i )            ( *((uint32 *)((char *)(sfnt) + OFFSETTABLESIZE + (i) * DirectoryEntrySize + 12)) )
#define SET_sfnt_table_length( sfnt, i, value )        ( *((uint32 *)((char *)(sfnt) + OFFSETTABLESIZE + (i) * DirectoryEntrySize + 12)) = (value) )


#ifdef OLD
    typedef struct {
        uint32 bc;
        uint32 ad;
    } BigDate;

    typedef struct {
        Fixed        version;            /* for this table, set to 1.0 */
        Fixed        fontRevision;        /* For Font Manufacturer */
        uint32        checkSumAdjustment;
        uint32        magicNumber;         /* signature, should always be 0x5F0F3CF5  == MAGIC */
        uint16        flags;
        uint16        unitsPerEm;            /* Specifies how many in Font Units we have per EM */

        BigDate        created;
        BigDate        modified;

        /** This is the font wide bounding box in ideal space
        (baselines and metrics are NOT worked into these numbers) **/
        FWord        xMin;
        FWord        yMin;
        FWord        xMax;
        FWord        yMax;

        uint16        macStyle;                /* macintosh style word */
        uint16        lowestRecPPEM;             /* lowest recommended pixels per Em */

        /* 0: fully mixed directional glyphs, 1: only strongly L->R or T->B glyphs, 
           -1: only strongly R->L or B->T glyphs, 2: like 1 but also contains neutrals,
           -2: like -1 but also contains neutrals */
        int16        fontDirectionHint;

        int16        indexToLocFormat;
        int16        glyphDataFormat;
    } sfnt_FontHeader;
#endif /* OLD */
#define GET_head_magicNumber( head ) ( *((uint32 *)((char *)(head) + 12)) )
#define GET_head_unitsPerEm( head ) ( *((uint16 *)((char *)(head) + 18)) )
#define GET_head_indexToLocFormat( head ) ( *((int16 *)((char *)(head) + 50)) )
#define GET_head_glyphDataFormat( head ) ( *((int16 *)((char *)(head) + 52)) )

#define SET_head_checkSumAdjustment( head, value ) ( *((uint32 *)((char *)(head) + 8)) = (value) )
#define SET_head_indexToLocFormat( head, value ) ( *((int16 *)((char *)(head) + 50)) = value )

#ifdef OLD
    typedef struct {
        Fixed        version;                /* for this table, set to 1.0 */
        uint16        numGlyphs;
        uint16        maxPoints;                /* in an individual glyph */
        uint16        maxContours;            /* in an individual glyph */
        uint16        maxCompositePoints;        /* in an composite glyph */
        uint16        maxCompositeContours;    /* in an composite glyph */
        uint16        maxElements;            /* set to 2, or 1 if no twilightzone points */
        uint16        maxTwilightPoints;        /* max points in element zero */
        uint16        maxStorage;                /* max number of storage locations */
        uint16        maxFunctionDefs;        /* max number of FDEFs in any preprogram */
        uint16        maxInstructionDefs;        /* max number of IDEFs in any preprogram */
        uint16        maxStackElements;        /* max number of stack elements for any individual glyph */
        uint16        maxSizeOfInstructions;    /* max size in bytes for any individual glyph */
        uint16        maxComponentElements;    /* number of glyphs referenced at top level */
        uint16        maxComponentDepth;        /* levels of recursion, 1 for simple components */
    } sfnt_maxProfileTable;
#endif /* OLD */
#define GET_maxp_numGlyphs( maxp ) ( *((uint16 *)((char *)(maxp) + 4)) )

/*
 * UNPACKING Constants
*/
#define ONCURVE              0x01
#define XSHORT               0x02
#define YSHORT               0x04
#define REPEAT_FLAGS        0x08 /* repeat flag n times */
/* IF XSHORT */
#define SHORT_X_IS_POS       0x10 /* the short vector is positive */
/* ELSE */
#define NEXT_X_IS_ZERO       0x10 /* the relative x coordinate is zero */
/* ENDIF */
/* IF YSHORT */
#define SHORT_Y_IS_POS       0x20 /* the short vector is positive */
/* ELSE */
#define NEXT_Y_IS_ZERO       0x20 /* the relative y coordinate is zero */
/* ENDIF */
/* 0x40 & 0x80                RESERVED
** Set to Zero
**
*/


/*
 * Composite glyph constants
 */
#define COMPONENTCTRCOUNT             -1        /* ctrCount == -1 for composite */
#define ARG_1_AND_2_ARE_WORDS        0x0001    /* if set args are words otherwise they are bytes */
#define ARGS_ARE_XY_VALUES            0x0002    /* if set args are xy values, otherwise they are points */
#define ROUND_XY_TO_GRID            0x0004    /* for the xy values if above is true */
#define WE_HAVE_A_SCALE                0x0008    /* Sx = Sy, otherwise scale == 1.0 */
#define NON_OVERLAPPING                0x0010    /* set to same value for all components */
#define MORE_COMPONENTS                0x0020    /* indicates at least one more glyph after this one */
#define WE_HAVE_AN_X_AND_Y_SCALE    0x0040    /* Sx, Sy */
#define WE_HAVE_A_TWO_BY_TWO        0x0080    /* t00, t01, t10, t11 */
#define WE_HAVE_INSTRUCTIONS        0x0100    /* instructions follow */
#define USE_MY_METRICS                0x0200    /* */


#ifdef OLD
    typedef struct {
        Fixed        version;                /* for this table, set to 1.0 */

        FWord        yAscender;
        FWord        yDescender;
        FWord        yLineGap;        /* Recommended linespacing = ascender - descender + linegap */
        uFWord        advanceWidthMax;    
        FWord        minLeftSideBearing;
        FWord        minRightSideBearing;
        FWord        xMaxExtent;        /* Max of ( LSBi + (XMAXi - XMINi) ), i loops through all glyphs */

        int16        horizontalCaretSlopeNumerator;
        int16        horizontalCaretSlopeDenominator;

        FWord        caretOffset;    
        uint16        reserved1;
        uint16        reserved2;
        uint16        reserved3;
        uint16        reserved4;

        int16        metricDataFormat;            /* set to 0 for current format */
        uint16        numberOf_LongHorMetrics;    /* if format == 0 */
    } sfnt_HorizontalHeader;
#endif /* OLD */
#define GET_hhea_numberOf_LongHorMetrics( hhea ) ( *((uint16 *)((hhea) + 34)) )

#ifdef OLD
    typedef struct {
        uint16        advanceWidth;
        int16         leftSideBearing;
    } sfnt_HorizontalMetrics;
#endif /* OLD */

#define HorizontalMetricsSize 4
#define GET_hmtx_advanceWidth_Ptr( hmtx, i )     ( (uint16 *)((char *)(hmtx) + (i)*HorizontalMetricsSize + 0))
#define GET_hmtx_leftSideBearing_Ptr( hmtx, i ) ( (int16 *)((char *)(hmtx) + (i)*HorizontalMetricsSize + 2))
#define GET_hmtx_FirstSoloLsb_Ptr( hmtx, numEntries ) ( (uint16 *)((char *)(hmtx) + (numEntries)*HorizontalMetricsSize))



/* Begin hdmx */
/*
 *    Each record is n+2 bytes, padded to long word alignment.
 *    First byte is ppem, second is maxWidth, rest are widths for each glyph
 */
#ifdef OLD
    typedef struct {
        int16                version;
        int16                numRecords;
        int32                recordSize;
        /* Byte widths[numGlyphs+2] * numRecords */
    } sfnt_DeviceMetrics;
#endif /* OLD */

#define sfnt_devMetricsSize 8
#define GET_hdmx_version_Ptr( hdmx )    ((int16 *)((char *)(hdmx) + 0))
#define GET_hdmx_numRecords_Ptr( hdmx )    ((int16 *)((char *)(hdmx) + 2))
#define GET_hdmx_recordSize_Ptr( hdmx )    ((int32 *)((char *)(hdmx) + 4))

#ifdef OLD
    typedef struct {
        uint8 ppem;
        uint8 maxWidth;
        uint8 widths[1];
    } sfnt_devMetricSubRecordType;
#endif /* OLD */

#define GET_hdmxSubRecord_ppem_Ptr( devSubRecord )        ((uint8 *)((uint8 *)(devSubRecord) + 0))
#define GET_hdmxSubRecord_maxWidth_Ptr( devSubRecord )    ((uint8 *)((uint8 *)(devSubRecord) + 1))
#define GET_hdmxSubRecord_width_Ptr( devSubRecord, i )    ((uint8 *)((uint8 *)(devSubRecord) + 2 + (i) ))

/* End hdmx */

/*** Begin VDMX ***/

#ifdef OLD
    typedef struct {
        uint16 yPelHeight;
        int16 yMax;
        int16 yMin;
    } sfnt_vdmxTable;

    typedef struct {
        uint16 recs;
        uint8 startSize;
        uint8 endSize;
        sfnt_vdmxTable entry[1]; /* really entry[recs] */
    } sfnt_vdmxGroup;
#endif /* OLD */
#define vdmxGroupSize 4
#define vdmxTableSize 6

#define GET_vdmxGroup_recs_Ptr( groups )        ((uint16 *)((char *)(groups) + 0))
#define GET_vdmxGroup_startSize_Ptr( groups )    ((uint8 *)( (char *)(groups) + 2))
#define GET_vdmxGroup_endSize_Ptr( groups )        ((uint8 *)( (char *)(groups) + 3))

#define GET_vdmxGroup_entry_yPelHeight_Ptr( groups, i ) ((uint16 *)( (char *)(groups) + 4 + (i) * vdmxTableSize + 0))
#define GET_vdmxGroup_entry_yMax_Ptr( groups, i ) ((uint16 *)( (char *)(groups) + 4 + (i) * vdmxTableSize + 2))
#define GET_vdmxGroup_entry_yMin_Ptr( groups, i ) ((uint16 *)( (char *)(groups) + 4 + (i) * vdmxTableSize + 4))

#ifdef OLD
    typedef struct {
        uint8 bCharSet;
        uint8 xRatio;
        uint8 yStartRatio;
        uint8 yEndRatio;
    } sfnt_vdmxRatio;


    typedef struct {
        uint16                version;
        uint16                numRecs;
        uint16                numRatios;
        sfnt_vdmxRatio        ratRange[1]; /* really ratRange[numRatios] */
    /*     uint16                offset[numRatios]; */
    /*    sfnt_vdmxGroup        groups[]; */
    } sfnt_vdmxFormat;
#endif /* OLD */

#define sfnt_vdmxRatio_Size 4
/* sfnt_vdmxFormatSize includes one sfnt_vdmxRatio_Size */
#define sfnt_vdmxFormatSize 10

/*** End VDMX ***/

