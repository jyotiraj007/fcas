/* Copyright (C) 1989, 1990, 1991, 1992, 1993, 1994, 1995, 1996
 * all rights reserved, by Bayer Corp., Agfa Division, Wilmington, MA.
 *
 * This software is furnished under a license and may be used and
 * copied only in accordance with the terms of such license and with
 * the inclusion of the above copyright notice. This software or any
 * other copies thereof may not be provided or otherwise made
 * available to any other person except as allowed under license. No
 * title to and ownership of the software is hereby transferred.
 *
 * This information in this software is subject to change without notice
 */
/* $Header:   I:\bull\c_exprss\src\lzcomp.h_v   1.2   14 May 1997 17:19:12   MARTIN  $ */
/* $Log:   I:\bull\c_exprss\src\lzcomp.h_v  $
 * 
 *    Rev 1.2   14 May 1997 17:19:12   MARTIN
 * 
 * Renamed MEMORY.H to MTXMEM.H.
 * 
 *    Rev 1.1   29 Apr 1997 14:39:12   MARTIN
 * 
 * Changed usingRunLength from int to short. Changed DUP#
 * from int to long.
 * 
 *    Rev 1.0   17 Dec 1996 16:31:54   MARTIN
 * Initial revision.
   
      Rev 1.3   09 Oct 1996 16:05:12   MARTIN
   
   Modifications for memory based version.
   
      Rev 1.2   05 Aug 1996 16:30:54   AL
   format 2 changes
   
      Rev 1.1   24 Apr 1996 15:49:02   MARTIN
   
   Fixed header.
   
      Rev 1.0   24 Apr 1996 10:53:18   LISA
   Initial revision.
*/

/*
 * File:                            LZCOMP.H
 * Author:                            Sampo Kaasila
 * First Version:                    February 6, 1996
 * Added the RUNLENGTHCOMP class:     July 31, 1996 (Sampo)
 *                                    Warning this is a format change !!!
 * First Memory Version :            September 30, 1996 (Sampo)    .
 * First pure ANSI C version:        October 28, 1996  (Sampo).
 * Remove the use of setjmp and longjmp. August 6, 2014 (Taylor)
 */
#include "mtxmem.h"

#ifdef __cplusplus
extern "C" {
#endif

/* This class was added to improve the compression performance */
/* for subsetted large fonts. ---Sampo July 31, 1996 */
/* Adding this increased the speed by about 50 times for the test-case */
/* font "MSMIN1.TTF". The compressed file also shrank to 91% of it's */
/* original size!!! */
typedef struct {
    /* private */
    /* State information for SaveBytes */
    unsigned char escape, count, state;
    MTX_MemHandler *mem;
    /* No public fields! */
} RUNLENGTHCOMP;

/* public RUNLENGTHCOMP interface */
#ifdef COMPRESS_ON
/* Invoke this method to run length compress a file in memory */
unsigned char *MTX_RUNLENGTHCOMP_PackData( RUNLENGTHCOMP *t, unsigned char *data, long lengthIn, long *lengthOut );
#endif
#ifdef DECOMPRESS_ON
/* Use this method to decompress the data transparently */
/* as it goes to the output memory. */
int MTX_RUNLENGTHCOMP_SaveBytes( RUNLENGTHCOMP *t, unsigned char value, unsigned char * *dataOut, long *dataOutSize, long *index );
#endif
RUNLENGTHCOMP *MTX_RUNLENGTHCOMP_Create( MTX_MemHandler *mem  );
void MTX_RUNLENGTHCOMP_Destroy( RUNLENGTHCOMP *t );


/* This structure is only for private use by LZCOMP */
typedef struct hn {
    long index;
    struct hn *next;
} hasnNode;

typedef struct {
    /* private */
    unsigned char *ptr1;
    char ptr1_IsSizeLimited;
    char filler1, filer2, filler3;
    /* New August 1, 1996 */
    RUNLENGTHCOMP *rlComp;
    short usingRunLength;
    
    long length1, out_len;
    long maxIndex;
    
    long num_DistRanges;
    long dist_max;
    long DUP2, DUP4, DUP6, NUM_SYMS;
    long maxCopyDistance;
    
    AHUFF *dist_ecoder;
    AHUFF *len_ecoder;
    AHUFF *sym_ecoder;
    BITIO *bitIn, *bitOut;
    
    
    #ifdef COMPRESS_ON
        hasnNode **hashTable;
        hasnNode *freeList;
        long nextFreeNodeIndex;
        hasnNode *nodeBlock;
    #endif /* COMPRESS_ON */
    MTX_MemHandler *mem;
    /* public */
    /* No public fields! */
} LZCOMP;

    /* public LZCOMP interface */

#ifdef COMPRESS_ON
    /* Call this method to compress a memory area */
    unsigned char *MTX_LZCOMP_PackMemory( LZCOMP *t, void *dataIn, long size_in, long *sizeOut);
#endif

#ifdef DECOMPRESS_ON
    /* Call this method to un-compress memory */
    unsigned char *MTX_LZCOMP_UnPackMemory( LZCOMP *t, void *dataIn, long dataInSize, long *sizeOut, unsigned char version );
#else
#ifdef DEBUG
    unsigned char *MTX_LZCOMP_UnPackMemory( LZCOMP *t, void *dataIn, long dataInSize, long *sizeOut, unsigned char version );
#endif
#endif

/* Constructors */
LZCOMP *MTX_LZCOMP_Create1( MTX_MemHandler *mem  );
LZCOMP *MTX_LZCOMP_Create2( MTX_MemHandler *mem, long maxCopyDistance );
/* Destructor */
void MTX_LZCOMP_Destroy( LZCOMP *t );

#ifdef __cplusplus
}
#endif
