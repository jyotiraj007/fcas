/* Copyright (C) 1989, 1990, 1991, 1992, 1993, 1994, 1995, 1996
 * all rights reserved, by Bayer Corp., Agfa Division, Wilmington, MA.
 *
 * This software is furnished under a license and may be used and
 * copied only in accordance with the terms of such license and with
 * the inclusion of the above copyright notice. This software or any
 * other copies thereof may not be provided or otherwise made
 * available to any other person except as allowed under license. No
 * title to and ownership of the software is hereby transferred.
 *
 * This information in this software is subject to change without notice
 */
/* $Header:   I:\bull\c_exprss\src\agfacomp.h_v   1.1   14 May 1997 17:16:46   MARTIN  $ */
/* $Log:   I:\bull\c_exprss\src\agfacomp.h_v  $
 * 
 *    Rev 1.1   14 May 1997 17:16:46   MARTIN
 * Renamed MEMORY.H to MTXMEM.H.
 * 
 *    Rev 1.0   17 Dec 1996 16:31:32   MARTIN
 * Initial revision.
   
      Rev 1.5   09 Oct 1996 16:06:42   MARTIN
   
   Modifications for memory based version.
   
      Rev 1.4   05 Aug 1996 16:30:46   AL
   format 2 changes
   
      Rev 1.3   15 May 1996 17:42:10   MARTIN
   
   Added temporary file path name to arguments.
   
      Rev 1.2   06 May 1996 10:43:48   MARTIN
   
   Added Remove_TTF_Work_Files and Remove_T1_Work_Files.
   
      Rev 1.1   24 Apr 1996 15:46:22   MARTIN
   
   Fixed header.
   
      Rev 1.0   24 Apr 1996 10:49:32   LISA
   Initial revision.
*/

/*
 * File:                        AGFACOMP.H
 * Author:                        Sampo Kaasila
 * First Version:                March 15, 1996
 * First Memory Version :        September 30, 1996 (Sampo)    .
 * First pure ANSI C version:    October 28, 1996  (Sampo).
 * Remove the use of setjmp and longjmp. August 6, 2014 (Taylor)
 */
#include "mtxmem.h"

#ifdef __cplusplus
extern "C" {
#endif

typedef struct {
    /* private */
    long copyLimit, ttfSize;
    /* protected: */
    void **d1;
    long *size_d1;
    void **d2;
    long *size_d2;
    void **d3;
    long *size_d3;
    unsigned char *version;
    MTX_MemHandler *mem;
    /* No public fields! */
} AGFACOMP;

/* public interface routines */
/* Returns true if it seems like we have Agfa microType Express compressed data */
int MTX_IS_MTX_Data( unsigned char *packed_Data, long packedDataSize );

/* Sets the max copy distance, for more speed, but lower compression */
void MTX_AGFACOMP_SetMaxCopyDistance( AGFACOMP *t, long d);
/* Returns the size of the ttf file */
long MTX_AGFACOMP_GetTTFSize( AGFACOMP *t );

/* Top level call to compress a TrueType file */
/* returns the packed size */
long MTX_AGFACOMP_Pack_TTF_File( AGFACOMP *t, const char *ttf_fileName, const char *packed_fileName );
/* Top level call to de-compress a TrueType file */
/* returns the output size */
long MTX_AGFACOMP_UnPack_TTF_File( AGFACOMP *t, const char *packed_fileName, const char *ttf_fileName);

#define USE_MTX_FREE 1            /* Caller can set to this */
#define USE_EXTERNAL_FREE 2        /* Caller can set to this */
#define FREE_HAS_BEEN_CALLED 0    /* Callee can set to this */
/* Returns pointer to the TTF in memory. It frees packed packed_Data automatically if *free_Packed_Data is true. */
unsigned char *MTX_AGFACOMP_UnPack_TTF_InMemory( AGFACOMP *t, unsigned char *packed_Data, long size_In, int *free_Packed_Data, long *size_out );

/* Returns pointer to the packed data in memory. It frees packed ttf_In automatically if *free_Ttf_In is true. */
unsigned char *MTX_AGFACOMP_Pack_TTF_InMemory( AGFACOMP *t, unsigned char *ttf_In, long size_In, int *free_Ttf_In, long *size_out );


/* Constructor */
AGFACOMP *MTX_AGFACOMP_Create( MTX_MemHandler *mem );
/* Destructor */
void MTX_AGFACOMP_Destroy( AGFACOMP *t );

#ifdef __cplusplus
}
#endif
