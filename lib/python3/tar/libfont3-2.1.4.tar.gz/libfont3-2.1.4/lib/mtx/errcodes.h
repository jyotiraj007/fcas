/* Copyright (C) 1989, 1990, 1991, 1992, 1993, 1994, 1995, 1996
 * all rights reserved, by Bayer Corp., Agfa Division, Wilmington, MA.
 *
 * This software is furnished under a license and may be used and
 * copied only in accordance with the terms of such license and with
 * the inclusion of the above copyright notice. This software or any
 * other copies thereof may not be provided or otherwise made
 * available to any other person except as allowed under license. No
 * title to and ownership of the software is hereby transferred.
 *
 * This information in this software is subject to change without notice
 */
/* $Header:   I:\bull\c_exprss\src\errcodes.h_v   1.2   29 Apr 1997 14:39:56   MARTIN  $ */
/* $Log:   I:\bull\c_exprss\src\errcodes.h_v  $
 * 
 *    Rev 1.2   29 Apr 1997 14:39:56   MARTIN
 * 
 * Fixed date.
 * 
 *    Rev 1.1   24 Mar 1997 11:25:04   MARTIN
 * 
 * Added NO_ERROR define.
 * 
 *    Rev 1.0   17 Dec 1996 16:31:34   MARTIN
 * Initial revision.
 * 
 *    Rev 1.4   21 Oct 1996 16:07:38   MARTIN
 * Added header.
 */
/*
 * File:            ERRCODES.H
 * Author:            Sara Martin
 * First Version:    May 20, 1996
 */
#define NO_ERROR   0
#define ERR_fopen  3300                             /*fopen failed*/
#define ERR_MergeFiles_file  3301                   /*MergeFiles:file error*/
#define ERR_bad_version  3302                       /*Bad Version*/
#define ERR_SplitFile_file  3303                    /*SplitFile:file error*/
#define ERR_BITIO_end_of_file  3304                 /*BITIO::input_bit:UNEXPECTED END OF FILE*/
#define ERR_BITIO_open_file  3305                   /*BITIO::BITIO Could not open file*/
#define ERR_BITIO_fseek  3306                       /*BITIO::~BITIO fseek error*/
#define ERR_BITIO_fclose 3307                       /*BITIO::~BITIO fclose error*/
#define ERR_LZCOMP_PackFile_fopen  3308             /*LZCOMP::PackFile fopen failed*/
#define ERR_LZCOMP_PackFile_fseek  3309             /*LZCOMP::PackFile fseek failed*/
#define ERR_LZCOMP_PackFile_fread  3310             /*LZCOMP::PackFile fread failed*/
#define ERR_LZCOMP_PackFile_fclose 3311             /*LZCOMP::PackFile fclose error*/
#define ERR_LZCOMP_UnPackFile_fopen  3312           /*LZCOMP::UnPackFile fopen failed*/    
#define ERR_LZCOMP_UnPackFile_fseek  3313           /*LZCOMP::UnPackFile fseek failed*/    
#define ERR_LZCOMP_UnPackFile_fclose  3314          /*LZCOMP::UnPackFile fclose failed*/    
#define ERR_LZCOMP_AssertFilesEqual_fopen 3315      /*LZCOMP::AssertFilesEqual fopen failed*/
#define ERR_LZCOMP_AssertFilesEqual_fseek 3316      /*LZCOMP::AssertFilesEqual fseek failed*/
#define ERR_LZCOMP_AssertFilesEqual_len   3317      /*LZCOMP::AssertFilesEqual len1 != len2!*/
#define ERR_LZCOMP_AssertFilesEqual_c1c2  3318      /*LZCOMP::AssertFilesEqual c1 != c2 !*/
#define ERR_LZCOMP_AssertFilesEqual_EOF   3319      /*LZCOMP::AssertFilesEqual c1 == EOF !*/
#define ERR_LZCOMP_AssertFilesEqual_fclose 3320     /*LZCOMP::AssertFilesEqual fclose failed*/
#define ERR_no_more_memory  3321                    /*No More Memory!*/
#define ERR_new_logical  3322                       /*new logical error*/
#define ERR_array_start_thrashed  3323              /*Array start thrashed*/
#define ERR_mem_dangling_pointers 3324              /*mem: Dangling pointers*/
#define ERR_wrong_new  3325                         /*Wrong new operator called*/
#define ERR_wrong_delete  3326                      /*Wrong delete operator called*/
#define ERR_global_new    3327                      /*Global new called*/
#define ERR_global_delete 3328                      /*Global delete called*/
#define ERR_WritePCSegment_fwrite  3329             /*WritePCSegment::fwrite failed*/
#define ERR_fopen_failed  3330                      /*... fopen failed*/
#define ERR_T1_CONV_TranslateFile_fopen  3331       /*T1_CONV::TranslateFile fopen failed*/
#define ERR_T1_CONV_WriteFile_fwrite  3332          /*T1_CONV::WriteFile fwrite failed*/
#define ERR_PC_Decode_fclose  3333                  /*PC_Decode fclose failed*/    
#define ERR_TTF_CONV_file_system  3334              /*TTF_CONV file system error*/
#define ERR_TTF_CONV_ftell  3335                    /*TTF_CONV ftell error*/
#define ERR_TTF_CONV_fread  3336                    /*TTF_CONV fread failed*/
#define ERR_TTF_CONV_fopen  3337                    /*TTF_CONV fopen error*/
#define ERR_TTF_CONV_fseek  3338                    /*TTF_CONV fseek error*/
#define ERR_Convert_FONT_too_many_tables  3339      /*Convert_FONT: unreasonably many tables*/
#define ERR_Convert_FONT_table_outside  3340        /*Convert_FONT: table outside file*/
#define ERR_Convert_FONT_table_end_outside  3341    /*Convert_FONT: table end outside file*/
#define ERR_Convert_FONT_bad_magic  3342            /*Convert_FONT: Bad Magic*/
#define ERR_Convert_FONT_unknown_glyphDataFormat 3343/*Convert_FONT: Unknown glyphDataFormat*/          
#define ERR_TTF_CONV_file_len_lessthan_0  3344      /*TTF_CONV file length <= 0*/                                 
#define ERR_TTF_CONV_fclose  3345                   /*TTF_CONV fclose error*/
#define ERR_TTF_Converter_WriteFile_fopen   3346    /*TTF_Converter::WriteFile fopen failed*/
#define ERR_TTF_Converter_WriteFile_fwrite  3347    /*TTF_Converter::WriteFile fwrite failed*/
#define ERR_TTF_Converter_WriteFile_fclose  3348    /*TTF_Converter::WriteFile fclose failed*/
#define ERR_TTF_Converter_fopen  3349               /*TTF_Converter fopen failed*/
#define ERR_TTF_Converter_file   3350               /*TTF_Converter: file error*/
#define ERR_TTF_Converter_fclose 3351               /*TTF_Converter: fclose error*/
#define ERR_SubSetBitMapTables_indexFormat  3352    /*SubSetBitMapTables: Bad indexFormat*/
#define ERR_LZCOMP_Encode_bounds            3353    /*LZCOMP:Encode out of bounds i*/
#define ERR_LZCOMP_Decode_bounds            3354    /*LZCOMP::Decode out of bounds pos*/
#define ERR_TTF_Converter_WriteHdmxValue_badvalue  3355    /*TTF_Converter::WriteHdmxValue bad value*/
#define ERR_realloc_bad_pointer  3356               /*realloc bad input pointer*/
#define ERR_realloc_failed       3357               /* realloc failed error */
#define ERR_delete_bad_pointer   3358               /* delete bad pointer */
#define ERR_array_end_thrashed   3359               /* Array end thrashed */
#define ERR_NOT_MTX_DATA         3360               /* Array end thrashed */
#define ERR_mem_Create_Failed    3361               /* Array end thrashed */
#define ERR_OutOfBoundsRead_In_InputFont 3362       /* Corrupted input data */
#define ERR_head_table_gone_or_to_short  3363       /* Corrupted input data */
#define ERR_hhea_table_gone_or_to_short  3364       /* Corrupted input data */
#define ERR_maxp_table_gone_or_to_short  3365       /* Corrupted input data */
#define ERR_loca_table_gone_or_to_short  3366       /* Corrupted input data */
#define ERR_hmtx_table_gone_or_to_short  3367       /* Corrupted input data */
#define ERR_TTF_CONV_Space 3368                     /*TTF_CONV insufficient space for compressed output */
