/* Copyright (C) 1989, 1990, 1991, 1992, 1993, 1994, 1995, 1996
 * all rights reserved, by Bayer Corp., Agfa Division, Wilmington, MA.
 *
 * This software is furnished under a license and may be used and
 * copied only in accordance with the terms of such license and with
 * the inclusion of the above copyright notice. This software or any
 * other copies thereof may not be provided or otherwise made
 * available to any other person except as allowed under license. No
 * title to and ownership of the software is hereby transferred.
 *
 * This information in this software is subject to change without notice
 */
/* $Header:   I:\bull\c_exprss\src\agfacomp.c_v   1.8   14 Oct 1998 12:12:46   MARTIN  $ */
/* $Log:   I:\bull\c_exprss\src\agfacomp.c_v  $
 *
 *              04 Apr 2014            hadleyj
 * switch 'DEBUG' to 'MTX_DEBUG' to avoid conflict.
 * 
 *    Rev 1.8   14 Oct 1998 12:12:46   MARTIN
 * 
 * Modifications by Microsoft for 64-bit port.
 * 
 *    Rev 1.7   16 May 1997 10:24:52   MARTIN
 * Removed SUN reference.
 * 
 *    Rev 1.6   14 May 1997 16:55:22   MARTIN
 * 
 * Removed compiler warnings.
 * 
 *    Rev 1.5   29 Apr 1997 14:14:10   MARTIN
 * Added _WINDOWS references. Modified ReadFileIntoMuse Windows file handling.
 * 
 *    Rev 1.4   24 Mar 1997 11:26:42   MARTIN
 * 
 * MTX_IS_MTX_Data now calls is_TTF_Test if size >= 0x800003.
 * 
 *    Rev 1.3   17 Jan 1997 12:20:20   MARTIN
 * 
 * Added HARD_DISK_ON conditional code, and new algorithm for setting of
 * copy limit.
 * 
 *    Rev 1.2   16 Jan 1997 15:52:22   MARTIN
 * 
 * Modifications to COMPRESS_ON and DECOMPRESS_ON conditional code.
 * 
 *    Rev 1.1   30 Dec 1996 11:46:34   MARTIN
 * 
 * Fix for dangling pointer error from MTX_mem_CloseMemory.
 * Using caller's memory routines at top level, instead of MTX's.
 * 
 *    Rev 1.0   17 Dec 1996 16:32:02   MARTIN
 * Initial revision.
   
      Rev 1.11   09 Oct 1996 16:06:20   MARTIN
   
   Modifications for memory based version.
   
      Rev 1.10   09 Oct 1996 14:02:48   MARTIN
   
   Modifications made by Sampo for the Mac platform.
   
      Rev 1.9   27 Aug 1996 09:34:38   AL
   Version 3 format: store hdmx and VDMX if they grow by 50%
   
      Rev 1.8   19 Aug 1996 15:26:16   MARTIN
   Added format2 define.
   
      Rev 1.7   05 Aug 1996 16:30:24   AL
   format 2 changes
   
      Rev 1.6   06 Jun 1996 11:47:08   MARTIN
   
   Added declarations for tmp0ctf and tmp0bin, for DEBUG option.
   
      Rev 1.5   22 May 1996 15:45:18   MARTIN
   Added _MAX_PATH to path name declarations. Handle NULL temp directory.
   
      Rev 1.4   20 May 1996 15:08:12   MARTIN
   
   Replaced error messages with error codes.
   
      Rev 1.3   15 May 1996 17:41:38   MARTIN
   
   Added temporary file path name to arguments.
   
      Rev 1.2   06 May 1996 10:43:04   MARTIN
   Added Remove_TTF_Work_Files and Remove_T1_Work_Files.
   
      Rev 1.1   24 Apr 1996 15:46:00   MARTIN
   
   Fixed header.
   
      Rev 1.0   24 Apr 1996 10:49:18   LISA
   Initial revision.
*/
/*
 * File:                        AGFACOMP.CPP
 * Author:                        Sampo Kaasila
 * First Version:                March 15, 1996
 * First Memory Version :        September 30, 1996 (Sampo)    .
 * First pure ANSI C version:    October 28, 1996  (Sampo).
 * Remove the use of setjmp and longjmp. August 6, 2014 (Taylor)
 */ 
#ifdef _WINDOWS
#include <windows.h>
#include <fcntl.h>
#include <io.h>
#endif
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <assert.h>
#include <string.h>


#include "agfaconfig.h"
#include "sfnt.h"
#include "ttf_conv.h"
#include "bitio.h"
#include "ahuff.h"
#include "lzcomp.h"
#include "mtxmem.h"
#include "agfacomp.h"
#include "agfautil.h"
#include "errcodes.h"


/* Writes out a 3-byte field */
static void Write3byteField( unsigned char *p, long value )
{
    *p++ = (unsigned char)(value >> 16);
    *p++ = (unsigned char)(value >> 8);
    *p++ = (unsigned char)(value >> 0);
}

/* Reads a 3-byte field */
static long Read3byteField( unsigned char *p )
{
    register long value = 0;
    
    value = *p++;
    value <<= 8;
    value |= *p++;
    value <<= 8;
    value |= *p;
    return value; /*******/    
}
#ifdef HARD_DISK_ON
/* Simple function, with error checking, to read a file into a memory area */
static unsigned char *ReadFileIntoMemory( AGFACOMP *t, const char *fname, long *size )
{
    int err;
    long size_In;
    size_t count;
    unsigned char *memArea;
    
#ifdef _WINDOWS
    HFILE fh;
    LPCSTR lpszFileName;
    UINT wFunction;
    signed int i,max_i;
    unsigned int read_count;
    unsigned long total_count;
#define  u64K           ( (unsigned int)0xFFFE )
#else
    FILE *fp;
#endif
    assert( fname != NULL );  

#ifdef _WINDOWS
    wFunction = OF_READ;
    lpszFileName = (LPCSTR)fname;
    fh = _lopen( lpszFileName, wFunction);  
    if ( fh == -1 ) SETLASTERROR( t->mem->env, ERR_TTF_CONV_fopen );
    size_In = _llseek( fh, 0L, 2 ); /* Go to the end */
    if ( size_In == -1L ) SETLASTERROR( t->mem->env, ERR_TTF_CONV_fseek );
    
    if ( size_In <= 0 ) SETLASTERROR( t->mem->env, ERR_TTF_CONV_file_len_lessthan_0 );

    err = (int)_llseek( fh, 0L, 0 ); /* Go to the beginning */
    if ( err != 0 ) SETLASTERROR( t->mem->env, ERR_TTF_CONV_fseek );
    
    /* Allocate Memory */
    memArea = (unsigned char __huge *)MTX_mem_malloc( t->mem, sizeof( char ) * size_In );
    CHECKLASTERROR(t->mem->env);

    /*  lread is dumb, will only read 64K at a time so have to force  */
    /*  multiple reads to get all of file in memory...                */
    max_i = (int)(size_In/ u64K) + 1;
    total_count = 0;
    for( i = 0; i < max_i; i++ )
    {
      /*  If have < 64K to read (max_i == 1) OR working on last 64K    */
      /*  "page", will probably read < 64K, so calculate the amount.   */
      /*  Otherwise, read a 64K chunk.                                 */
      read_count = ( max_i == 1  ||  i == (max_i-1) )
                          ? ( (unsigned int)(size_In-(i*u64K))) : u64K;

      if( read_count == 0  &&  (unsigned int)size_In == u64K )
         read_count = u64K;

      if( (count = _lread( fh, (unsigned char __huge *)memArea + ((unsigned long)i * u64K),(size_t)read_count)) != (size_t)read_count )
         SETLASTERROR( t->mem->env, ERR_TTF_CONV_fread ); 
      total_count += (unsigned long)read_count;

    }  /*  end - for  */
    if ( total_count != (unsigned long)size_In ) SETLASTERROR( t->mem->env, ERR_TTF_CONV_fread );
    
    err = _lclose( fh ); if ( err != 0 ) SETLASTERROR( t->mem->env, ERR_TTF_CONV_fclose );
    
    *size = size_In;
    return memArea; /******/
#else     
    fp = fopen(fname, "rb");
    if ( fp == NULL ) SETLASTERROR( t->mem->env, ERR_TTF_CONV_fopen );
    err = fseek( fp, 0L, SEEK_END ); /* Go to the end */
    if ( err != 0 ) SETLASTERROR( t->mem->env, ERR_TTF_CONV_fseek );
    size_In = ftell( fp );
    
    if ( size_In <= 0 ) SETLASTERROR( t->mem->env, ERR_TTF_CONV_file_len_lessthan_0 );
    if ( ferror(fp) != 0 ) SETLASTERROR( t->mem->env, ERR_TTF_CONV_ftell );

    err = fseek( fp, 0L, SEEK_SET ); /* Go to the beginning */
    if ( err != 0 ) SETLASTERROR( t->mem->env, ERR_TTF_CONV_fseek );
    
    /* Allocate Memory */
    memArea = (unsigned char *)MTX_mem_malloc( t->mem, sizeof( char ) * size_In );
    CHECKLASTERROR(t->mem->env);
    
    count = fread( memArea, sizeof( char ), size_In, fp );
    if ( count != (size_t)size_In || ferror(fp) != 0 ) SETLASTERROR( t->mem->env, ERR_TTF_CONV_fread );
    
    err = fclose( fp ); if ( err != 0 ) SETLASTERROR( t->mem->env, ERR_TTF_CONV_fclose );
    
    *size = size_In;
    return memArea; /******/
#endif
}

/* Simple function, with error checking, to write a memory area to a file */
static int WriteDataToFile( AGFACOMP *t, const char *fname, void *dataIn, long sizeIn)
{
    int err;
    size_t count;
#ifdef _WINDOWS
    HFILE fh;
    LPCSTR lpszFileName;
    UINT wFunction;
    signed int i,max_i;
    unsigned int write_count;
    unsigned long total_count;
#define  u64K           ( (unsigned int)0xFFFE )
        
    wFunction = OF_WRITE;
    lpszFileName = (LPCSTR)fname;
    fh = _lcreat( lpszFileName, 0);  
    if ( fh == -1 ) SETLASTERROR( t->mem->env, ERR_TTF_CONV_fopen );
 
    /*  lwrite is dumb, will only write 64K at a time so have to force  */
    /*  multiple writes...                */
    max_i = (int)(sizeIn/ u64K) + 1;
    total_count = 0;
    for( i = 0; i < max_i; i++ )
    {
      /*  If have < 64K to write (max_i == 1) OR working on last 64K    */
      /*  "page", will probably write < 64K, so calculate the amount.   */
      /*  Otherwise, write a 64K chunk.                                 */
      write_count = ( max_i == 1  ||  i == (max_i-1) )
                          ? ( (unsigned int)(sizeIn-(i*u64K))) : u64K;

      if( write_count == 0  &&  (unsigned int)sizeIn == u64K )
         write_count = u64K;

      if( (count = _lwrite( fh, (unsigned char __huge *)dataIn + ((unsigned long)i * u64K),(size_t)write_count)) != (size_t)write_count )
         SETLASTERROR( t->mem->env, ERR_TTF_Converter_WriteFile_fwrite ); 
      total_count += write_count;

    }  /*  end - for  */
    if ( total_count != (unsigned long)sizeIn ) SETLASTERROR( t->mem->env, ERR_TTF_Converter_WriteFile_fwrite );
    
    err = _lclose( fh ); if ( err != 0 ) SETLASTERROR( t->mem->env, ERR_TTF_CONV_fclose );
#else     
    FILE *fp;
    fp = fopen( fname, "wb" ); if ( fp == NULL ) SETLASTERROR( t->mem->env, ERR_TTF_CONV_fopen );
    count = fwrite( dataIn, sizeof( char ), sizeIn, fp );
    if ( ferror(fp) != 0 || count != (size_t)sizeIn) SETLASTERROR( t->mem->env, ERR_TTF_Converter_WriteFile_fwrite );
    err = fclose( fp ); if ( err != 0 ) SETLASTERROR( t->mem->env, ERR_TTF_Converter_WriteFile_fclose );
    return 0;
#endif
}
#endif /*HARD_DISK_ON */
#ifdef COMPRESS_ON
/*
 * This method merges the 3 compresseds ctf memory areas into a single memory area, with a 10 byte header
 * bin[0..2] contains bin1, 2, and 3. The lengths of the bin areas are in len[0..2]
 * It frees bin1, bin2, and bin3 automatically
 * returns the pointer to the merged memory
 */
static unsigned char *MergeMemory( AGFACOMP *t, unsigned char *bin[], long len[], long *lenOut )
{
    register long i, index = 0;
    long offset[3];        /* 3 bytes each */
    unsigned char *dataOut;

    *lenOut = 10 + len[0] + len[1] + len[2];
    dataOut = (unsigned char *)t->mem->malloc( *lenOut );   /* we are using the user's malloc, not MTX's memory management */

    index = 10;                                                /* skip 10 byte header */
    for ( i = 0; i < 3; i++ ) {
        memcpyHuge( &dataOut[index], bin[i], len[i] );            /* Merge bin1, bin2, and bin3 */
        index += len[i];    
        MTX_mem_free( t->mem, bin[i] );
        offset[i] = index;
    }
    index = 0;                                                 /* Go to the beginning */
    dataOut[index++] = currentformat;                        /* 1 byte header, currentformat 5-Aug-96 awr  */
    Write3byteField( &dataOut[index], t->copyLimit );        /* 3 byte copyLimit */
    index += 3;
    Write3byteField( &dataOut[index], offset[0] );            /* 3 byte offset to data set 2, from the beginning of the file */
    index += 3;
    Write3byteField( &dataOut[index], offset[1] );            /* 3 byte offset tp data set 3, from the beginning of the file */
    /*index += 3; */
                                                            /* data set 1 starts right here at the 11th byte in the file */
    assert( offset[2] == *lenOut );
    return dataOut; /******/
}

#endif /* COMPRESS_ON */


/* This method finds the 3 separate sets of data within the packed data */
/* Returns the maxDist used by the compressor */
static long SplitMemory( AGFACOMP *t, unsigned char *packed_Data, long packedDataSize, void **d1, long *size_d1, void **d2, long *size_d2, void **d3, long *size_d3, unsigned char *version )
{
    long maxDist, offset1, offset2; /* 3 bytes each; */
    unsigned char *dataIn = (unsigned char *)packed_Data;
    
    /* read the Header */
    *version = *dataIn++;
    if ( *version > currentformat ) SETLASTERROR( t->mem->env, ERR_bad_version );
    maxDist = Read3byteField( dataIn ); dataIn += 3;
    offset1 = Read3byteField( dataIn ); dataIn += 3;
    offset2 = Read3byteField( dataIn ); dataIn += 3;
    
    assert( (unsigned char __huge *)dataIn - (unsigned char __huge *)packed_Data == 10 );

    *d1 = (void *)dataIn;
    *d2 = (void *)((unsigned char __huge *)packed_Data + offset1);
    *d3 = (void *)((unsigned char __huge *)packed_Data + offset2);
    
    *size_d1 = (long)((unsigned char __huge *)*d2 - (unsigned char __huge *)*d1);
    *size_d2 = (long)((unsigned char __huge *)*d3 - (unsigned char __huge *)*d2);
    *size_d3 = (long)((unsigned char __huge *)packed_Data + packedDataSize - (unsigned char __huge *)*d3);
    
    assert( *size_d1 >= 0 && *size_d2 >= 0 && *size_d3 >= 0 );

    return maxDist; /******/
}


/* Returns true if it seems like we have Agfa microType Express compressed data */
int MTX_IS_MTX_Data( unsigned char *packed_Data, long packedDataSize )
{
    unsigned char version;
    void *d1, *d2, *d3; 
    long size_d1, size_d2, size_d3;
    long maxDist, offset1, offset2; /* 3 bytes each; */
    unsigned char *dataIn = (unsigned char *)packed_Data;
    long packedDataBytesLeft;
    
    /* If the file is greater than or equal to 8388611 bytes (0x800003L), test to make sure it is not a TT font. */
    /* This mysterious number comes from the fact that there are some TT fonts that may look like */
    /* a compressed MTX file because of the combination of data items in the first 10 bytes of the */
    /* file. In an MTX file the first 10 bytes comprise the version number (1 byte), the copy limit */
    /* value (3 bytes), the offset to the second chunk of data (3 bytes), and the offset to the third */
    /* chunk of data (3 bytes). The test for a valid MTX file is that the version number makes sense, */
    /* and that the two data offsets are in ascending order and the computed sizes for the three data chunks */
    /* seem reasonable. In a TT font file the first 10 bytes comprise the version number (4 bytes), */
    /* the number of tables (2 bytes), the searchRange (2 bytes), and the entrySelector (2 bytes). The */
    /* searchRange and entrySelector are computed values based on the number of tables. The version number */
    /* of a TT font automatically passes the version check for an MTX file, but the only combination of */
    /* numTables, searchRange, and entrySelector that might be mistaken for the two data offsets in an MTX */
    /* file, is if there are between 9 and 15 tables in the TT font, and that the font size is greater or equal */
    /* to 0x800003. Spelled out in detail, the possible byte combinations are:                             */
    /*                                                                                                     */
    /*         (TT)         numTables searchRange entrySelector                                            */
    /*                        00 09       00 80       00 03                                                */
    /*                        00 0A       00 80       00 03                                                */
    /*                        00 0B       00 80       00 03                                                */
    /*                        00 0C       00 80       00 03                                                */
    /*                        00 0D       00 80       00 03                                                */
    /*                        00 0E       00 80       00 03                                                */
    /*                        00 0F       00 80       00 03                                                */
    /*         (MTX)          |<--offset1-->|<--offset2-->|                                                */
    /*                                                                                                     */

    if ((packedDataSize >= 0x800003L) &&  is_TTF_Test(packed_Data, packedDataSize))
        return false;
    
    /* read the Header */
    version = *dataIn++;
    maxDist = Read3byteField( dataIn ); dataIn += 3;
    offset1 = Read3byteField( dataIn ); dataIn += 3;
    offset2 = Read3byteField( dataIn ); dataIn += 3;
    packedDataBytesLeft = packedDataSize - 10;

    d1 = (void *)dataIn;
    d2 = (void *)((unsigned char __huge *)packed_Data + offset1);
    d3 = (void *)((unsigned char __huge *)packed_Data + offset2);
    
    size_d1 = (long)((unsigned char __huge *)d2 - (unsigned char __huge *)d1);
    size_d2 = (long)((unsigned char __huge *)d3 - (unsigned char __huge *)d2);
    size_d3 = (long)((unsigned char __huge *)packed_Data + packedDataSize - (unsigned char __huge *)d3);
    
    return( packedDataBytesLeft >= 9 && version <= currentformat &&
            size_d1 >= 3 && size_d2 >= 3 && size_d3 >= 3 &&
            (size_d1+size_d2+size_d3) == packedDataBytesLeft ); /******/
}


#ifdef COMPRESS_ON
/*
 * Returns pointer to the packed data in memory.
 * It frees packed packed_Data automatically.
 */
unsigned char *MTX_AGFACOMP_Pack_TTF_InMemory( AGFACOMP *t, unsigned char *ttf_In, long size_In, int *free_Ttf_In, long *size_out )
{
    long i, packedLength, compressedSize = 0;
    unsigned char *ctf[3], *bin[3], *dataOut;
    long ctfSize[3], binSize[3];
const long LZpreLoadSize = 2*32*96 + 4*256 +64; /* const from LZCOMP */

    t->ttfSize = size_In;
    
    ctfSize[0] = 0;
    ctfSize[1] = 0;
    ctfSize[2] = 0;

    /* If a copy limit was not set by the user, determine an optimal value based on the font size */
    /* If the font size is less than 1MB, use the font_size + LZpreLoadSize as the value, otherwise use 9K */
    if (!t->copyLimit){
        if (t->ttfSize < 1000000L)
               MTX_AGFACOMP_SetMaxCopyDistance( t, t->ttfSize + LZpreLoadSize );
        else
               MTX_AGFACOMP_SetMaxCopyDistance( t, 9000L );
    }

    /* Do ttf to 3 ctf memory areas conversion */
    {
        TTF_Converter *ttf = MTX_TTC_Create( t->mem, (short)currentformat);
        MTX_TTC_TTF_To_CTF( ttf, ttf_In, size_In, &ctf[0], &ctfSize[0], &ctf[1], &ctfSize[1], &ctf[2], &ctfSize[2] );
        MTX_TTC__Destroy( ttf );

        if (ctfSize[0] > 0xffffff)  /* will not fit in 24 bits */
        {
            SETLASTERROR(t->mem->env, ERR_TTF_CONV_Space);
        }
    }
    if ( *free_Ttf_In != FREE_HAS_BEEN_CALLED ) {
        /* Now this can be freed */
        if ( *free_Ttf_In == USE_EXTERNAL_FREE ) {
            t->mem->free( ttf_In );
        } else {
            assert( *free_Ttf_In == USE_MTX_FREE );
            MTX_mem_free( t->mem, ttf_In );
        }
        *free_Ttf_In = FREE_HAS_BEEN_CALLED;
    }
    
    /* i = 0,1,2 is conceptually mapped to 1,2,3 */
    for ( i = 0; i < 3 ; i++ ) {
        /* Convert the 3 ctf files to compressed ctf file format */
        LZCOMP *crusher = MTX_LZCOMP_Create2( t->mem, t->copyLimit);
        if(crusher == NULL) return NULL;
        bin[i] = MTX_LZCOMP_PackMemory( crusher, ctf[i], ctfSize[i], &binSize[i]);
        compressedSize += binSize[i];
#ifdef MTX_DEBUG
        {
            long len0;
            unsigned char *ctf0 = MTX_LZCOMP_UnPackMemory( crusher, bin[i], binSize[i], &len0, currentformat );
            assert( len0 == ctfSize[i] && memcmp( (void *)ctf0, (void *)ctf[i], len0 ) == 0 );
            MTX_mem_free( t->mem, ctf0 );
        }
#endif        
        MTX_LZCOMP_Destroy( crusher );
        MTX_mem_free( t->mem, ctf[i] ); /* Now this can be freed */
    }
    dataOut = MergeMemory( t, bin, binSize, &packedLength );
    *size_out  = packedLength;
    return dataOut; /******/
}


#ifdef HARD_DISK_ON
/* Top level call to compress a TrueType file */
/* returns the packed size */
long MTX_AGFACOMP_Pack_TTF_File( AGFACOMP *t, const char *ttf_fileName, const char *packed_fileName )
{
    unsigned char *ttf_In, *packed_Data;
    long size_In, size_out;
    int freeCode = USE_MTX_FREE;

    ttf_In = ReadFileIntoMemory( t, ttf_fileName, &size_In );
    CHECKLASTERROR(t->mem->env);

    packed_Data = MTX_AGFACOMP_Pack_TTF_InMemory( t, ttf_In, size_In, &freeCode, &size_out );
    
    WriteDataToFile( t, packed_fileName, packed_Data, size_out );
    t->mem->free( packed_Data );   /* we are using the user's free, not MTX's memory management */
    CHECKLASTERROR(t->mem->env);
    return size_out; /******/
}
#endif /* HARD_DISK_ON */
#endif /* COMPRESS_ON */

#ifdef DECOMPRESS_ON
/*
 * Returns pointer to the TTF in memory.
 * It frees packed packed_Data automatically.
 */
unsigned char *MTX_AGFACOMP_UnPack_TTF_InMemory( AGFACOMP *t, unsigned char *packed_Data, long size_In, int *free_Packed_Data, long *size_out )
{
    void *d1, *d2, *d3;
    long maxCopyDistance;
    unsigned char version;
    unsigned char *ctf1, *ctf2, *ctf3;
    long size1, size2, size3;
    unsigned char *ttfData = NULL;
    long size_d1, size_d2, size_d3;
    
    if ( !MTX_IS_MTX_Data( packed_Data, size_In ) ) SETLASTERROR( t->mem->env, ERR_NOT_MTX_DATA );

    maxCopyDistance = SplitMemory( t, packed_Data, size_In, &d1, &size_d1, &d2, &size_d2, &d3, &size_d3, &version );
    CHECKLASTERROR(t->mem->env);
    assert( d1 > (void *)packed_Data && d1 <  (void *)((char __huge *)packed_Data + size_In) );
    assert( d2 > (void *)packed_Data && d2 <= (void *)((char __huge *)packed_Data + size_In) );
    assert( d3 > (void *)packed_Data && d3 <= (void *)((char __huge *)packed_Data + size_In) );
    {
        LZCOMP *crusher = MTX_LZCOMP_Create2( t->mem, maxCopyDistance);
        ctf1 = MTX_LZCOMP_UnPackMemory( crusher, d1, size_d1, &size1, version );
        MTX_LZCOMP_Destroy( crusher );
    }
    CHECKLASTERROR(t->mem->env);
    {
        LZCOMP *crusher = MTX_LZCOMP_Create2( t->mem, maxCopyDistance);
        ctf2 = MTX_LZCOMP_UnPackMemory( crusher, d2, size_d2, &size2, version );
        MTX_LZCOMP_Destroy( crusher );
    }
    {
        LZCOMP *crusher = MTX_LZCOMP_Create2( t->mem, maxCopyDistance);
        ctf3 = MTX_LZCOMP_UnPackMemory( crusher, d3, size_d3, &size3, version );
        MTX_LZCOMP_Destroy( crusher );
    }
    if ( *free_Packed_Data != FREE_HAS_BEEN_CALLED ) {
        /* Now this can be freed */
        if ( *free_Packed_Data == USE_EXTERNAL_FREE ) {
            t->mem->free( packed_Data );
        } else {
            assert( *free_Packed_Data == USE_MTX_FREE );
            MTX_mem_free( t->mem, packed_Data );
        }
        *free_Packed_Data = FREE_HAS_BEEN_CALLED;
    }
    
    {
        TTF_Converter *ttf = MTX_TTC_Create( t->mem, (short)version);
        ttfData = MTX_TTC_CTF_To_TTF( ttf, ctf1, size1, ctf2, size2, ctf3, size3, size_out );

        t->ttfSize = *size_out; /* GetTTFSize... */
        assert( t->ttfSize == *size_out );
        MTX_TTC__Destroy( ttf );
    }
#ifdef MTX_DEBUG
    {
        char fileName[_MAX_PATH];
        memset(fileName,'\0',_MAX_PATH);
        strcpy( fileName, "temp.ctf1" );
        WriteDataToFile( t, fileName, ctf1, size1 );
        CHECKLASTERROR(t->mem->env);
        memset(fileName,'\0',_MAX_PATH);
        strcpy( fileName, "temp.ctf2" );
        WriteDataToFile( t, fileName, ctf2, size2 );
        CHECKLASTERROR(t->mem->env);
        memset(fileName,'\0',_MAX_PATH);
        strcpy( fileName, "temp.ctf3" );
        WriteDataToFile( t, fileName, ctf3, size3 );
        CHECKLASTERROR(t->mem->env);
    }
#endif
    MTX_mem_free( t->mem, ctf1 ); /* Now this can be freed */
    MTX_mem_free( t->mem, ctf2 ); /* Now this can be freed */
    MTX_mem_free( t->mem, ctf3 ); /* Now this can be freed */

    return ttfData; /******/
}

#ifdef HARD_DISK_ON
/* Top level call to de-compress a TrueType file */
/* returns the output size */
long MTX_AGFACOMP_UnPack_TTF_File( AGFACOMP *t, const char *packed_fileName, const char *ttf_fileName )
{
    long size_In, ttfSizeOut;
    unsigned char *packed_Data;
    unsigned char *ttfData;
    int freeCode = USE_MTX_FREE;
    
    packed_Data = ReadFileIntoMemory( t, packed_fileName, &size_In );
    CHECKLASTERROR(t->mem->env);

    ttfData = MTX_AGFACOMP_UnPack_TTF_InMemory( t,  packed_Data, size_In, &freeCode, &ttfSizeOut );
    CHECKLASTERROR(t->mem->env);
    
    WriteDataToFile( t, ttf_fileName, ttfData, ttfSizeOut );
    t->mem->free( ttfData );  /* we are using the user's free, not MTX's memory management */
    CHECKLASTERROR(t->mem->env);
    return ttfSizeOut; /******/
}
#endif /* HARD_DISK_ON */
#endif /* DECOMPRESS_ON */

/* Sets the max copy distance, for more speed, but lower compression */
void MTX_AGFACOMP_SetMaxCopyDistance( AGFACOMP *t, long d)
{
    t->copyLimit = d;
}

/* Returns the size of the ttf file */
long MTX_AGFACOMP_GetTTFSize( AGFACOMP *t )
{
    return t->ttfSize; /******/
}



/* Constructor */
AGFACOMP *MTX_AGFACOMP_Create( MTX_MemHandler *mem )
{
    AGFACOMP *t        = (AGFACOMP *)MTX_mem_malloc( mem, sizeof( AGFACOMP ) );
    CHECKLASTERROR(mem->env);
    t->mem            = mem;
    
    t->copyLimit    = 0;
    t->ttfSize        = 0;
    return t; /*****/
}

/* Destructor */
void MTX_AGFACOMP_Destroy( AGFACOMP *t )
{
    MTX_mem_free( t->mem, t );
}

