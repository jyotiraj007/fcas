/* Copyright (C) 1989, 1990, 1991, 1992, 1993, 1994, 1995, 1996
 * all rights reserved, by Bayer Corp., Agfa Division, Wilmington, MA.
 *
 * This software is furnished under a license and may be used and
 * copied only in accordance with the terms of such license and with
 * the inclusion of the above copyright notice. This software or any
 * other copies thereof may not be provided or otherwise made
 * available to any other person except as allowed under license. No
 * title to and ownership of the software is hereby transferred.
 *
 * This information in this software is subject to change without notice
 */
/* $Header:   I:\bull\c_exprss\src\glyph.c_v   1.2   14 Oct 1998 12:13:14   MARTIN  $ */
/* $Log:   I:\bull\c_exprss\src\glyph.c_v  $
 *
 *              04 Apr 2014            hadleyj
 *
 * Only include <malloc.h> if non-Apple.
 * 
 *    Rev 1.2   14 Oct 1998 12:13:14   MARTIN
 * 
 * Modifications by Microsoft for 64-bit port.
 * 
 *    Rev 1.1   14 May 1997 16:54:34   MARTIN
 * 
 * Removed compiler warnings.
 * 
 *    Rev 1.0   29 Apr 1997 15:50:40   MARTIN
 * Initial revision.
 */
/*
 * File:                                glyph.c (originally taken from ttf_conv.cp)
 * Author:                                Sampo Kaasila
 * First Version:                        February 6, 1996
 * First memory based version:            September 27, 1996 (Sampo)
 * Automatic memory reallocation:        October 2, 1996 (Sampo)
 * First pure ANSI C version:            October 28, 1996  (Sampo).
 * Bounds checking on all reads in the
 * TrueType data structure for increased
 * robustness. All C-structs defining
 * the TrueType fileformat were removed
 * for increased portability.
 * The subsetter code was also removed
 * since we now totally rely on the
 * Microsoft subsetting code:            November 18, 1996 (Sampo).
 * Separated from ttf_conv.c due to 16-bit
 * code size limitation.            April 8, 1997 (Sara Martin).
 * Remove the use of setjmp and longjmp. August 6, 2014 (Taylor)
 */
#ifdef _WINDOWS
#include <windows.h>
#endif
 
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <assert.h>
#include <string.h>
#if !defined(__APPLE__)
#include <malloc.h>
#endif

#include "agfaconfig.h"
#include "sfnt.h"
#include "ttf_conv.h"
#include "glyph.h"
#include "mtxmem.h"
#include "agfautil.h"
#include "errcodes.h"

/* This data structure is read only, except when it is initialized once */
/* by InitCoordEncoding(), this means it can be shared in a preemptive */
/* multi-tasking environment. */
typedef struct {
    short            byteCount;
    short            xBits;
    short            yBits;
    short            dxPlus;
    short            dyPlus;
    char             xIsNegative; /* No meaning if xBits == 0 */
    char             yIsNegative; /* No meaning if yBits == 0 */
} coordEncodingType;

static coordEncodingType coordEncoding[128];
static int coordEncodingIsInited = false;

/* Here we have both big and little endian versions of SWAPENDS. */
/* These routines are needed since the TrueType format is Big-Endian native. */
#ifdef MTX_BIG_ENDIAN

#define SWAPENDS_16( w ) (w)
#define SWAPENDS_U16( w ) (w)
#define SWAPENDS_32( w ) (w)
#define SWAPENDS_U32( w ) (w)

#else
static short SWAPENDS_16( register short w )
{
    register unsigned char /* b0, */ b1;
    
    /* b0 = (char)w; */
    b1 = (char)(w >> 8);
    
    /* w = b0; */
    w <<= 8;
    w |= b1;
    
    return w; /*****/
}

static unsigned short SWAPENDS_U16( register unsigned short w )
{
    register unsigned char /* b0, */ b1;
    
    /* b0 = (char)w; */
    b1 = (char)(w >> 8);
    
    /* w = b0; */
    w <<= 8;
    w |= b1;
    
    return w; /*****/
}


static long SWAPENDS_32( register long ww )
{
    register unsigned short w0, w1;
    
    w0 = (short)ww;
    w1 = (short)(ww >> 16);
    w0 = SWAPENDS_U16( w0 );
    w1 = SWAPENDS_U16( w1 );
    
    ww = w0;
    ww <<= 16;
    ww |= w1;
    
    return ww; /*****/
}

static unsigned long SWAPENDS_U32( register unsigned long ww )
{
    register unsigned short w0, w1;
    
    w0 = (short)ww;
    w1 = (short)(ww >> 16);
    w0 = SWAPENDS_U16( w0 );
    w1 = SWAPENDS_U16( w1 );
    
    ww = w0;
    ww <<= 16;
    ww |= w1;
    
    return ww; /*****/
}
#endif

/* Reads a word and increments the pointer */
/* It works for both big and little endian machines */
static short READWORD_INC( char * *pRef )
{
    short x;
    register char *p = *pRef;
    
    x = (short)((((short)*p) << 8) | *(unsigned char *)(p+1));

    *pRef += 2;
    return x; /*****/
}

/* Writes a word and increments the pointer */
/* It works for both big and little endian machines */
static void WRITEWORD_INC( char * *pRef, short x )
{
    register char *p = *pRef;
    *p++ = (char)((unsigned short)x >> 8);
    *p++ = (char)x;
    *pRef = p;
}

#if 0
/* Writes a long and increments the pointer */
/* It works for both big and little endian machines */
static void WRITELONG_INC( char * *p, long x )
{
    short w0, w1;
    
    w0 = (short)x;
    w1 = (short)(x >> 16);

    WRITEWORD_INC( p, w1 );
    WRITEWORD_INC( p, w0 );
}
#endif
/*
const unsigned char flipSignCode        = 250;
const unsigned char Hop3Code            = 251; * A,X1,A,X2,A -> A,X1,Hop3Code,X2 - >A,X1,A,X2,A *
const unsigned char Hop4Code            = 252; * A,X1,A,X2,A,X3,A -> A,X1,Hop4Code,X2,X3 - >A,X1,A,X2,A,X3,A *
const unsigned char wordCode            = 253;
const unsigned char oneMoreByteCode2    = 254;
const unsigned char oneMoreByteCode1    = 255;

const short lowestUCode = 253; * wordCode *

const short lowestCode  = 250; * flipSignCode *
*/

#ifdef COMPRESS_ON
/* Writes a short in our 255UShort format */
static void Write255UShort( char * *pRef, short value )
{
    register char *p = *pRef;
//const unsigned char flipSignCode        = 250;
//const unsigned char Hop3Code            = 251; /* A,X1,A,X2,A -> A,X1,Hop3Code,X2 - >A,X1,A,X2,A */
//const unsigned char Hop4Code            = 252; /* A,X1,A,X2,A,X3,A -> A,X1,Hop4Code,X2,X3 - >A,X1,A,X2,A,X3,A */
const unsigned char wordCode            = 253;
const unsigned char oneMoreByteCode2    = 254;
const unsigned char oneMoreByteCode1    = 255;

const short lowestUCode = 253; /* wordCode */

//const short lowestCode  = 250; /* flipSignCode */

    assert( value >= 0 );
    if ( value >= lowestUCode*3 ) {
        *p++ = wordCode; /* Do a word */
        *p++ = (char)((unsigned short)value >> 8);
        *p++ = (char)(value & 0xff);
    } else {
        if ( value >= lowestUCode ) {
            value = (short)(value - lowestUCode);
            if ( value >= lowestUCode ) {
                value = (short)(value - lowestUCode);
                *p++ = oneMoreByteCode2; /* one more byte */
            } else {
                *p++ = oneMoreByteCode1; /* one more byte */
            }
        }
        assert( value >= 0 && value < lowestUCode );
        *p++ = (char)value;
    }
    *pRef = p;
}
#endif

#ifdef DECOMPRESS_ON
/* Reads a short in our 255UShort format */
static short Read255UShort( char * *pRef )
{
    unsigned char code;
    short value;
    register char *p = *pRef;
//const unsigned char flipSignCode        = 250;
//const unsigned char Hop3Code            = 251; /* A,X1,A,X2,A -> A,X1,Hop3Code,X2 - >A,X1,A,X2,A */
//const unsigned char Hop4Code            = 252; /* A,X1,A,X2,A,X3,A -> A,X1,Hop4Code,X2,X3 - >A,X1,A,X2,A,X3,A */
const unsigned char wordCode            = 253;
const unsigned char oneMoreByteCode2    = 254;
const unsigned char oneMoreByteCode1    = 255;

const short lowestUCode = 253; /* wordCode */

//const short lowestCode  = 250; /* flipSignCode */

    code = *((unsigned char *)p++);
    if ( code == wordCode ) {
        value = *p++;
        value <<= 8;
        value &= 0xff00;
        value |= *p++ & 0x00ff;
    } else if ( code == oneMoreByteCode1 ) {
        value = *((unsigned char *)p++);
        assert( value >= 0 && value < lowestUCode );
        value = (short)(value + lowestUCode);
    } else if ( code == oneMoreByteCode2 ) {
        value = *((unsigned char *)p++);
        assert( value >= 0 && value < lowestUCode );
        value = (short)(value + lowestUCode*2);
    } else {
        value = code;
    }
    assert( value >= 0 );
    *pRef = p;
    return value; /*****/
}
#endif /* DECOMPRESS_ON */


static int AllocateGlyphSpace( Glyph *t, char * *destSfnt, long pos, long byteCount, long *maxOutSize )
{
    byteCount += 4; /* Always keep a 4 byte margin to allow for the zero padding */
    if ( pos + byteCount > *maxOutSize ) {
        *maxOutSize = pos + byteCount + (*maxOutSize>>1) + 2; /* Allocate memory in exponentially increasing steps */
        *destSfnt = (char *)MTX_mem_realloc( t->mem, *destSfnt, *maxOutSize );
        CHECKLASTERROR(t->mem->env);
    }
    return 0;
}

/* just some variables for collecting statistics during development */
/* static long total_pushCount = 0;  */
/* static long total_pushBytes = 0;  */
/* static long total_otherCount = 0; */

/* Getter function for the bounding box */
static void MTX_Glyph_GetBBox( Glyph *t, short *xmax, short *xmin, short *ymax, short *ymin )
{
    *xmax = t->xmax;
    *xmin = t->xmin;
    *ymax = t->ymax;
    *ymin = t->ymin;
}
/* Computes the bounding box for this glyph, returns results in the arguments */
static void MTX_Glyph_ComputeBBox( Glyph *t, short *xmax, short *xmin, short *ymax, short *ymin )
{
    long i;
    
    *xmax = *xmin = t->x[0];
    *ymax = *ymin = t->y[0];
    
    for ( i = 1; i < t->numberOfPoints; i++ ) {
        if ( t->x[i] > *xmax ) {
            *xmax = t->x[i];
        } else if ( t->x[i] < *xmin ) {
            *xmin = t->x[i];
        }
        if ( t->y[i] > *ymax ) {
            *ymax = t->y[i];
        } else if ( t->y[i] < *ymin ) {
            *ymin = t->y[i];
        }
    }
}
#ifdef COMPRESS_ON
/* Parses a sequence of TrueType code. The most important */
/* Function of this code to split the data into initally pushed data */
/* everything else */
static int ParseCode( register Glyph *t )
{
    unsigned char uByte, argc_b, argc_w;
    short stmp;
    unsigned short i;
    unsigned char j;
    long pushBytes;
    
    MTX_mem_free( t->mem,t->pushData);             t->pushData = NULL;
    MTX_mem_free( t->mem,t->remainingCode);     t->remainingCode = NULL;
    /* MTX_mem_free( t->mem,t->remainingCodeType);    t->remainingCodeType = NULL; */

    t->pushData = (short *)MTX_mem_malloc( t->mem, sizeof(short) *  t->numberOfInstructions );
    t->remainingCode = (unsigned char *)MTX_mem_malloc( t->mem, sizeof( unsigned char ) * t->numberOfInstructions );
    CHECKLASTERROR(t->mem->env);
    /* t->remainingCodeType = (unsigned char *)MTX_mem_malloc( t->mem, sizeof( unsigned char ) * t->numberOfInstructions ); */
    
    pushBytes               = 0;
    t->pushCount            = 0;
    t->remainingCodeSize    = 0;
    
    for ( i = 0; i < t->numberOfInstructions;  ) {
        argc_b = argc_w = 0;
        uByte = t->code[i++];
        if ( uByte == 0x40 ) {
            /* NPUSHB */
            argc_b = t->code[i++];
        } else if ( uByte >= 0xB0 && uByte <= 0xB7 ) {
            /* PUSHB */
            argc_b = (unsigned char)(uByte - 0xB0 + 1);
        } else if ( uByte == 0x41 ) {
            /* NPUSHW */
            argc_w = t->code[i++];
        } else if ( uByte >= 0xB8 && uByte <= 0xBF ) {
            /* PUSHW */
            argc_w = (unsigned char)(uByte - 0xB8 + 1);
        } else {
            i--;
        }

        if ( argc_b > 0 ) {
            for ( j = 0; j < argc_b; j++ ) {
                t->pushData[t->pushCount++] = t->code[i++];
            }
        } else if ( argc_w > 0 ) {
            for ( j = 0; j < argc_w; j++ ) {
                stmp = t->code[i++];
                stmp <<= 8;
                stmp |= t->code[i++];
                t->pushData[t->pushCount++] = stmp;
            }
        } else {
            pushBytes = i;
            while ( i < t->numberOfInstructions ) {
                t->remainingCode[ t->remainingCodeSize++] = t->code[i++];
            }
            break; /****** not a push */
        }
    }
    assert( i == t->numberOfInstructions  );
    
#ifdef OLD
    /* Classify into code or data */
    for ( i = 0; i < t->remainingCodeSize;  ) {
        argc_b = argc_w = 0;
        t->remainingCodeType[i] = 'C'; /* Code */
        uByte = t->remainingCode[i++];
        if ( uByte == 0x40 ) {
            /* NPUSHB */
            t->remainingCodeType[i] = 'D'; /* Data */
            argc_b = t->remainingCode[i++];
            for ( j = 0; j < argc_b; j++ ) {
                t->remainingCodeType[i++] = 'D'; /* Data */
            }
        } else if ( uByte >= 0xB0 && uByte <= 0xB7 ) {
            /* PUSHB */
            argc_b = (unsigned char)(uByte - 0xB0 + 1);
            for ( j = 0; j < argc_b; j++ ) {
                t->remainingCodeType[i++] = 'D'; /* Data */
            }
        } else if ( uByte == 0x41 ) {
            /* NPUSHW */
            t->remainingCodeType[i] = 'D'; /* Data */
            argc_w = t->remainingCode[i++];
            for ( j = 0; j < argc_w; j++ ) {
                t->remainingCodeType[i++] = 'D'; /* Data */
                t->remainingCodeType[i++] = 'D'; /* Data */
            }
        } else if ( uByte >= 0xB8 && uByte <= 0xBF ) {
            /* PUSHW */
            argc_w = (unsigned char)(uByte - 0xB8 + 1);
            for ( j = 0; j < argc_w; j++ ) {
                t->remainingCodeType[i++] = 'D'; /* Data */
                t->remainingCodeType[i++] = 'D'; /* Data */
            }
        } else {
            ;
        }
    }
    assert( i == t->remainingCodeSize );
#endif /* OLD */
    

    /* total_pushCount += pushCount; */
    /* total_pushBytes += pushBytes; */
    /* total_otherCount += t->remainingCodeSize; */
    assert( pushBytes+t->remainingCodeSize == t->numberOfInstructions  );
    assert( t->pushCount+t->remainingCodeSize <= t->numberOfInstructions  );
    assert( t->pushCount >= 0 );
    assert( t->remainingCodeSize >= 0 );
    return 0;
}
#endif /* COMPRESS_ON */


/* Computes the bounding box for this glyph */
static void SetBBox( register Glyph *t )
{
    long i;
    register short coord;
    
    t->xmax = t->xmin = t->x[0];
    t->ymax = t->ymin = t->y[0];
    for ( i = 1; i < t->numberOfPoints; i++ ) {
        if ( (coord = t->x[i]) > t->xmax ) {
            t->xmax = coord;
        } else if ( coord < t->xmin ) {
            t->xmin = coord;
        }
        if ( (coord = t->y[i]) > t->ymax ) {
            t->ymax = coord;
        } else if ( coord < t->ymin ) {
            t->ymin = coord;
        }
    }
}


#ifdef OLD
    static long totBytes = 0;
    static long insBytes = 0;
#endif

static int CheckReadBoundsGlyph( Glyph *t, char *readStart, long byteCount )
{
    if ( ((char __huge *)readStart+byteCount) > t->inDataEnd || readStart < t->inDataStart ) {
        SETLASTERROR( t->mem->env, ERR_OutOfBoundsRead_In_InputFont )
    }
    return 0;
}

#ifdef COMPRESS_ON
/* Reads a glyph in the TrueType format */
static long ReadTTFSpline( Glyph *t, char *sp )
{
    unsigned short i;
    long j;
    short k;
    short stmp;
    unsigned char bitflags;
    char *spStart = sp;
    
    CheckReadBoundsGlyph( t, sp, 5 * 2 ); /* numberOfContours, + the bounding box */
    CHECKLASTERROR(t->mem->env);
    t->numberOfContours = READWORD_INC( &sp );
    t->xmin = READWORD_INC( &sp );
    t->ymin = READWORD_INC( &sp );
    t->xmax = READWORD_INC( &sp );
    t->ymax = READWORD_INC( &sp );
    
    MTX_mem_free( t->mem,t->code);          t->code = NULL;
    MTX_mem_free( t->mem,t->startPoint);    t->startPoint = NULL;
    MTX_mem_free( t->mem,t->endPoint);      t->endPoint = NULL;
    MTX_mem_free( t->mem,t->onCurve);       t->onCurve = NULL;
    MTX_mem_free( t->mem,t->x);             t->x = NULL;
    MTX_mem_free( t->mem,t->y);             t->y = NULL;
    
    
    t->numberOfPoints = 0; /* Initialize */
    if ( t->numberOfContours < 0  ) {
        unsigned short flags;
        int weHaveInstructions;
        short flagsWithInstructionsIndex = 0;

         t->componentVersionNumber = t->numberOfContours;
         assert( t->componentData != NULL );
         do {
             CheckReadBoundsGlyph( t, sp, 2*2 ); /* flags, glyphIndex */
            CHECKLASTERROR(t->mem->env);
             flags = READWORD_INC( &sp );
             weHaveInstructions = flags & WE_HAVE_INSTRUCTIONS;
             if ( weHaveInstructions )
                 flagsWithInstructionsIndex = t->componentSize;
             t->componentData[ t->componentSize++] = flags;
             
             t->componentData[ t->componentSize++] = READWORD_INC( &sp );
             if ( flags & ARG_1_AND_2_ARE_WORDS ) {
                 /* arg 1 and 2 as words */
                 CheckReadBoundsGlyph( t, sp, 2*2 );
                CHECKLASTERROR(t->mem->env);
                 t->componentData[ t->componentSize++] = READWORD_INC( &sp );
                 t->componentData[ t->componentSize++] = READWORD_INC( &sp );
             } else {
                 /* arg 1 and 2 as bytes */
                  CheckReadBoundsGlyph( t, sp, 2 );
                CHECKLASTERROR(t->mem->env);
                 t->componentData[ t->componentSize++] = READWORD_INC( &sp );
             }
             
             if ( flags & WE_HAVE_A_SCALE ) {
                 /* scale */
                  CheckReadBoundsGlyph( t, sp, 2 );
                CHECKLASTERROR(t->mem->env);
                   t->componentData[ t->componentSize++] = READWORD_INC( &sp );
             } else if ( flags & WE_HAVE_AN_X_AND_Y_SCALE ) {
                 /* xscale, yscale */
                  CheckReadBoundsGlyph( t, sp, 2*2 );
                CHECKLASTERROR(t->mem->env);
                    t->componentData[ t->componentSize++] = READWORD_INC( &sp );
                   t->componentData [ t->componentSize++] = READWORD_INC( &sp );
             } else if ( flags & WE_HAVE_A_TWO_BY_TWO ) {
                 /* xscale, scale01, scale10, yscale */
                  CheckReadBoundsGlyph( t, sp, 4*2 );
                CHECKLASTERROR(t->mem->env);
                    t->componentData[ t->componentSize++] = READWORD_INC( &sp );
                   t->componentData [ t->componentSize++] = READWORD_INC( &sp );
                    t->componentData[ t->componentSize++] = READWORD_INC( &sp );
                   t->componentData [ t->componentSize++] = READWORD_INC( &sp );
             }
             assert( t->componentSize < t->maxComponentSize );
         } while ( flags & MORE_COMPONENTS );
         t->numberOfInstructions  = 0;
         if ( weHaveInstructions ) {
             CheckReadBoundsGlyph( t, sp, 2 ); /* numberOfInstructions */
            CHECKLASTERROR(t->mem->env);
             t->numberOfInstructions  = READWORD_INC( &sp );

             if ( t->numberOfInstructions != 0 )
             {
                 /*code = new unsigned char [ t->numberOfInstructions  ];assert( code != NULL ); */
                 t->code = (unsigned char *)MTX_mem_malloc(t->mem, sizeof(unsigned char) * t->numberOfInstructions);
                 CHECKLASTERROR(t->mem->env);

                 CheckReadBoundsGlyph(t, sp, t->numberOfInstructions); /* the instructions */
                 CHECKLASTERROR(t->mem->env);
                 for (i = 0; i < t->numberOfInstructions; i++) {
                     t->code[i] = (unsigned char)*sp++;
                 }
             }
             else
                 t->componentData[flagsWithInstructionsIndex] = t->componentData[flagsWithInstructionsIndex] & (~WE_HAVE_INSTRUCTIONS);
         }
    } else if ( t->numberOfContours > 0 ) {
        t->startPoint = (unsigned short *)MTX_mem_malloc( t->mem, sizeof( unsigned short ) * t->numberOfContours );
        t->endPoint = (unsigned short *)MTX_mem_malloc( t->mem, sizeof( unsigned short ) * t->numberOfContours );
        CHECKLASTERROR(t->mem->env);
        
        /* Non Composite */
         CheckReadBoundsGlyph( t, sp, t->numberOfContours * 2 ); /* the end points */
        CHECKLASTERROR(t->mem->env);
        stmp = 0;
        for ( k = 0; k < t->numberOfContours; k++ ) {
            t->startPoint[k]  = stmp;
            t->endPoint[k]    = READWORD_INC( &sp );
             assert( t->endPoint[k] >= 0  );
             stmp = (short)(t->endPoint[k] + 1);
        }
        t->numberOfPoints = (short)(t->endPoint[t->numberOfContours - 1] + 1);
        assert( t->numberOfPoints > 0 );

         CheckReadBoundsGlyph( t, sp, 2 ); /* numberOfInstructions */
        CHECKLASTERROR(t->mem->env);
        t->numberOfInstructions  = READWORD_INC( &sp );
         CheckReadBoundsGlyph( t, sp, t->numberOfInstructions ); /* the instructions */
        CHECKLASTERROR(t->mem->env);
        if ( t->numberOfInstructions  > 0 ) {
            t->code = (unsigned char *)MTX_mem_malloc( t->mem, sizeof(unsigned char) * t->numberOfInstructions  );
            assert( t->code != NULL );
            CHECKLASTERROR(t->mem->env);
            for ( i = 0; i < t->numberOfInstructions ; i++ ) {
                t->code[i] = *sp++;
            }
        }
        t->onCurve = (unsigned char *)MTX_mem_malloc( t->mem, sizeof(unsigned char) * t->numberOfPoints );
        CHECKLASTERROR(t->mem->env);

        for ( k = 0; k < t->numberOfPoints; ) {
             CheckReadBoundsGlyph( t, sp, 1 );
            t->onCurve[k++] = bitflags = *sp++;
            if ( bitflags & REPEAT_FLAGS ) {
                for ( j = *sp++; j--; ) {
                    t->onCurve[k++] = bitflags;
                    if (k == t->numberOfPoints) break;
                }
            }
        }
        t->x = (short *)MTX_mem_malloc( t->mem, sizeof( short ) * t->numberOfPoints );
        t->y = (short *)MTX_mem_malloc( t->mem, sizeof( short ) * t->numberOfPoints );
        CHECKLASTERROR(t->mem->env);

        for ( stmp = 0, k = 0; k < t->numberOfPoints; k++ ) {
            bitflags = t->onCurve[k];
             if ( bitflags & XSHORT ) {
                 if ( bitflags & SHORT_X_IS_POS ) {
                     CheckReadBoundsGlyph( t, sp, 1 );
                    CHECKLASTERROR(t->mem->env);
                     stmp = (short)(stmp + (*(unsigned char *)sp++));
                 } else {
                     CheckReadBoundsGlyph( t, sp, 1 );
                    CHECKLASTERROR(t->mem->env);
                     stmp = (short)(stmp - (*(unsigned char *)sp++));
                 }
             } else if ( ! ( bitflags & NEXT_X_IS_ZERO) ) {
                 CheckReadBoundsGlyph( t, sp, 2 );
                CHECKLASTERROR(t->mem->env);
                 stmp = (short)(stmp + READWORD_INC( &sp ));
             }
            t->x[k] = stmp;
        }
    
        for ( stmp = 0, k = 0; k < t->numberOfPoints; k++ ) {
            bitflags = t->onCurve[k];
             if ( bitflags & YSHORT ) {
                 if ( bitflags & SHORT_Y_IS_POS ) {
                     CheckReadBoundsGlyph( t, sp, 1 );
                    CHECKLASTERROR(t->mem->env);
                     stmp = (short)(stmp + (*(unsigned char *)sp++));
                 } else {
                     CheckReadBoundsGlyph( t, sp, 1 );
                    CHECKLASTERROR(t->mem->env);
                     stmp = (short)(stmp - (*(unsigned char *)sp++));
                 }
             } else if ( ! ( bitflags & NEXT_Y_IS_ZERO) ) {
                 CheckReadBoundsGlyph( t, sp, 2 );
                CHECKLASTERROR(t->mem->env);
                 stmp = (short)(stmp + READWORD_INC( &sp ));
             }
            t->y[k] = stmp;
            t->onCurve[k] = (unsigned char)(bitflags & ONCURVE); /* Clear other bitflags */
        }
        /* totBytes += (char __huge *)sp-(char __huge *)spStart; */
        /* insBytes += t->numberOfInstructions ; */
    } /* t->numberOfContours >= 0 */
    return (long)((char __huge *)sp-(char __huge *)spStart); /*****/
}
#endif /* COMPRESS_ON */


#ifdef DECOMPRESS_ON
/* Writes out a glyph in the TrueType format */
long MTX_Glyph_WriteTTFSpline( register Glyph *t, char * *destSfnt, long pos, long *maxOutSize )
{
    register unsigned char *f;
    register unsigned short i;
    register short x, y;
    short delta, j, k;
    unsigned char bitFlags;
    long deltaFromStart;
    /* Pointers dependent on destSfnt */
    char *p, *pStart;
    
    
    if (t->numberOfContours == 0 ) {
        return 0; /******/
    }
    
    deltaFromStart = 0;
    AllocateGlyphSpace( t, destSfnt, pos, 10, maxOutSize );
    pStart = (char *)&(*destSfnt)[pos]; p = (char __huge *)pStart + deltaFromStart; /* Reset pointers */
    
    if ( t->componentSize > 0 ) {
        assert( t->componentVersionNumber < 0 );
        WRITEWORD_INC( &p, t->componentVersionNumber );
    } else {
        WRITEWORD_INC( &p, t->numberOfContours );
    }

    /* Bounding box */
    WRITEWORD_INC( &p, t->xmin );
    WRITEWORD_INC( &p, t->ymin );
    WRITEWORD_INC( &p, t->xmax );
    WRITEWORD_INC( &p, t->ymax );
    
    if ( t->componentSize > 0 ) {
        deltaFromStart = (long)((char __huge *)p - (char __huge *)pStart);
        AllocateGlyphSpace( t, destSfnt, pos, (long)((char __huge *)p-(char __huge *)pStart+t->componentSize*2), maxOutSize );
        pStart = (char *)&(*destSfnt)[pos]; p = (char __huge *)pStart + deltaFromStart; /* Reset pointers */
        for ( j = 0; j < t->componentSize; j++ ) {
            WRITEWORD_INC( &p, t->componentData[j] );
        }
        deltaFromStart = (long)((char __huge *)p - (char __huge *)pStart);
        AllocateGlyphSpace( t, destSfnt, pos, (long)((char __huge *)p-(char __huge *)pStart+2+t->numberOfInstructions) , maxOutSize );
        pStart = (char *)&(*destSfnt)[pos]; p = (char __huge *)pStart + deltaFromStart; /* Reset pointers */
        if ( t->numberOfInstructions  > 0 ) {
            WRITEWORD_INC( &p, t->numberOfInstructions  );
            for ( i = 0; i < t->numberOfInstructions ; i++ ) {
                *p++ = t->code[i];
            }
        }
        return ( (long)((char __huge *)p - (char __huge *)pStart) ); /******/
    }
    f = (unsigned char *)MTX_mem_malloc( t->mem, sizeof( unsigned char ) * t->numberOfPoints );
    CHECKLASTERROR(t->mem->env);

    deltaFromStart = (long)((char __huge *)p - (char __huge *)pStart);
    AllocateGlyphSpace( t, destSfnt, pos, (long)((char __huge *)p-(char __huge *)pStart+t->numberOfContours*2), maxOutSize );
    CHECKLASTERROR(t->mem->env);
    pStart = (char *)&(*destSfnt)[pos]; p = (char __huge *)pStart + deltaFromStart; /* Reset pointers */
    for ( j = 0; j < t->numberOfContours; j++ ) {
        WRITEWORD_INC( &p, t->endPoint[j] );
    }

    deltaFromStart = (long)((char __huge *)p - (char __huge *)pStart);
    AllocateGlyphSpace( t, destSfnt, pos, (long)((char __huge *)p-(char __huge *)pStart+2+t->numberOfInstructions) , maxOutSize );
    CHECKLASTERROR(t->mem->env);
    pStart = (char *)&(*destSfnt)[pos]; p = (char __huge *)pStart + deltaFromStart; /* Reset pointers */
    WRITEWORD_INC( &p, t->numberOfInstructions  );
    for ( i = 0; i < t->numberOfInstructions; i++ ) {
        *p++ = t->code[i];
    }
    
    /* Calculate flags */
    for ( x = y = j = 0; j < t->numberOfPoints; j++ ) {
        bitFlags = (unsigned char)(t->onCurve[j] & ONCURVE);
        delta = (short)(t->x[j] - x); x = t->x[j];
        if ( delta == 0 ) {
            bitFlags |= NEXT_X_IS_ZERO;
        } else if ( delta >= -255 && delta <= 255 ) {
            bitFlags |= XSHORT;
            if ( delta > 0 ) {
                bitFlags |= SHORT_X_IS_POS;
            }
        }
        delta = (short)(t->y[j] - y); y = t->y[j];
        if ( delta == 0 ) {
            bitFlags |= NEXT_Y_IS_ZERO;
        } else if ( delta >= -255 && delta <= 255 ) {
            bitFlags |= YSHORT;
            if ( delta > 0 ) {
                bitFlags |= SHORT_Y_IS_POS;
            }
        }
        f[j] = bitFlags;
    }

    deltaFromStart = (long)((char __huge *)p - (char __huge *)pStart);
    AllocateGlyphSpace( t, destSfnt, pos, (long)((char __huge *)p-(char __huge *)pStart+t->numberOfPoints), maxOutSize ); /* At least big enough */
    CHECKLASTERROR(t->mem->env);
    pStart = (char *)&(*destSfnt)[pos]; p = (char __huge *)pStart + deltaFromStart; /* Reset pointers */
    /* Write out bitFlags */
    for ( k = 0; k < t->numberOfPoints;) {
        unsigned char repeat = 0;
        for ( j = (short)(k+1); j < t->numberOfPoints && f[k] == f[j] && repeat < 255; j++ )
            repeat++;
        if ( repeat > 1 ) {
            *p++ = (char)(f[k] | REPEAT_FLAGS);
            *p++ = repeat;
            k = j;
        } else {
            *p++ = f[k++];
        }
    }

    deltaFromStart = (long)((char __huge *)p - (char __huge *)pStart);
    AllocateGlyphSpace( t, destSfnt, pos, (long)((char __huge *)p-(char __huge *)pStart+2*t->numberOfPoints), maxOutSize ); /* At least big enough */
    CHECKLASTERROR(t->mem->env);
    pStart = (char *)&(*destSfnt)[pos]; p = (char __huge *)pStart + deltaFromStart; /* Reset pointers */
    /* Write out X */
    for ( x = k = 0; k < t->numberOfPoints; k++ ) {
        delta = (short)(t->x[k] - x); x = t->x[k];
        if ( f[k] & XSHORT ) {
            if ( !(f[k] & SHORT_X_IS_POS) ) delta = (short)-delta;
            *p++ = (char)delta;
        } else if ( !(f[k] & NEXT_X_IS_ZERO ) ) {
            WRITEWORD_INC( &p, delta );
        }
    }

    /* Write out Y */
    deltaFromStart = (long)((char __huge *)p - (char __huge *)pStart);
    AllocateGlyphSpace( t, destSfnt, pos, (long)((char __huge *)p-(char __huge *)pStart+2*t->numberOfPoints), maxOutSize ); /* At least big enough */
    CHECKLASTERROR(t->mem->env);
    pStart = (char *)&(*destSfnt)[pos]; p = (char __huge *)pStart + deltaFromStart; /* Reset pointers */
    for ( y = k = 0; k < t->numberOfPoints; k++ ) {
        delta = (short)(t->y[k] - y); y = t->y[k];
        if ( f[k] & YSHORT ) {
            if ( !(f[k] & SHORT_Y_IS_POS) ) delta = (short)-delta;
            *p++ = (char)delta;
        } else if ( !(f[k] & NEXT_Y_IS_ZERO ) ) {
            WRITEWORD_INC( &p, delta );
        }
    }
    MTX_mem_free( t->mem,f);
    
    return ( (long)((char __huge *)p - (char __huge *)pStart) ); /*****/
}
#endif /*  DECOMPRESS_ON */

#ifdef OLD
    static long ByteCount1 = 0;
    static long ByteCount2 = 0;
    static long ByteCount3 = 0;
    static long ByteCount4 = 0;
    static long ByteCount5 = 0;
#endif

/* Initializes the relative coordinate encoding technique used */
/* to store the coordinates in the CTF format. Is is designed */
/* to be more compact than TrueType, but still allow compaction */
/* by traditional compression methods. */

void InitCoordEncoding( void )
{
    short i, index = 0;
    short dxPlus, dyPlus;
    
    if ( coordEncodingIsInited ) return; /******/ 
    for ( dyPlus = 0; dyPlus <= 1024; dyPlus += 256 ) {
        coordEncoding[index].byteCount = 2;
        coordEncoding[index].xBits     = 0;
        coordEncoding[index].yBits     = 8;
        coordEncoding[index].dxPlus    = 0;
        coordEncoding[index].dyPlus    = dyPlus;
        index++;
    }
    for ( dxPlus = 0; dxPlus <= 1024; dxPlus += 256 ) {
        coordEncoding[index].byteCount = 2;
        coordEncoding[index].xBits     = 8;
        coordEncoding[index].yBits     = 0;
        coordEncoding[index].dxPlus    = dxPlus;
        coordEncoding[index].dyPlus    = 0;
        index++;
    }
    
    /* No need to start at zero since the prior cases will have taken care of that case */
    for ( dxPlus = 1; dxPlus <= 49+1; dxPlus += 16 ) {
        for ( dyPlus = 1; dyPlus <= 49+1; dyPlus += 16 ) {
            coordEncoding[index].byteCount = 2;
            coordEncoding[index].xBits     = 4;
            coordEncoding[index].yBits     = 4;
            coordEncoding[index].dxPlus    = dxPlus;
            coordEncoding[index].dyPlus    = dyPlus;
            index++;
        }
    }

    /* No need to start at zero since the prior cases will have taken care of that case */
    for ( dxPlus = 1; dxPlus <= 513; dxPlus += 256 ) {
        for ( dyPlus = 1; dyPlus <= 513; dyPlus += 256 ) {
            coordEncoding[index].byteCount = 3;
            coordEncoding[index].xBits     = 8;
            coordEncoding[index].yBits     = 8;
            coordEncoding[index].dxPlus    = dxPlus;
            coordEncoding[index].dyPlus    = dyPlus;
            index++;
        }
    }

    
    coordEncoding[index].byteCount    = 4;
    coordEncoding[index].xBits        = 12;
    coordEncoding[index].yBits        = 12;
    coordEncoding[index].dxPlus       = 0;
    coordEncoding[index].dyPlus       = 0;
    index++;
    
    coordEncoding[index].byteCount    = 5;
    coordEncoding[index].xBits        = 16;
    coordEncoding[index].yBits        = 16;
    coordEncoding[index].dxPlus       = 0;
    coordEncoding[index].dyPlus       = 0;
    /*index++; */
    
    
    /*index--; */
    for ( i = index; i >= 0; i-- ) {
        coordEncoding[i].xIsNegative = false;
        coordEncoding[i].yIsNegative = false;
    }
    for ( i = 127; index >= 0;) {
        coordEncoding[i] = coordEncoding[index];
        i--;
        if ( coordEncoding[i+1].xBits == 0 ) {
            /* *2 */
            coordEncoding[i] = coordEncoding[index];
            coordEncoding[i].yIsNegative = true;
            i--;
        } else if ( coordEncoding[i+1].yBits == 0 ) {
            /* *2 */
            coordEncoding[i] = coordEncoding[index];
            coordEncoding[i].xIsNegative = true;
            i--;
        } else {
            /* *4 */
            coordEncoding[i] = coordEncoding[index];
            coordEncoding[i].xIsNegative = true;
            i--;
            coordEncoding[i] = coordEncoding[index];
            coordEncoding[i].yIsNegative = true;
            i--;
            coordEncoding[i] = coordEncoding[index];
            coordEncoding[i].xIsNegative = true;
            coordEncoding[i].yIsNegative = true;
            i--;
        }
        index--;
    }
    assert( i == -1 );
    assert( index == -1 );
    coordEncodingIsInited = true;
}

/*
const unsigned char cvt_pos8                = 255;
const unsigned char cvt_pos1                = 255 - 7;                    * == cvt_pos8 - 7 *
const unsigned char cvt_neg8                = 255 - 7 - 1;                * == cvt_pos1 - 1 *
const unsigned char cvt_neg1                = 255 - 7 - 1 - 7;            * == cvt_neg8 - 7 *
const unsigned char cvt_neg0                = 255 - 7 - 1 - 7 - 1;        * == cvt_neg1 - 1 *
const unsigned char cvt_wordCode            = 255 - 7 - 1 - 7 - 1 - 1;    * == cvt_neg0 - 1 *

const short cvt_lowestCode                     = 255 - 7 - 1 - 7 - 1 - 1;    * == cvt_wordCode *
*/
#ifdef COMPRESS_ON
/* encode a short in 1 to 3 bytes */    
/* Writes a cvt value in the ctf format */
void WriteCVTShort( unsigned char * *pRef, short valueIn )
{
    short index;
    short negative = false;
    short value = valueIn;
    unsigned char code;
#ifdef MTX_DEBUG
    const unsigned char cvt_pos8                = 255;
    const unsigned char cvt_neg8                = 255 - 7 - 1;                /* == cvt_pos1 - 1 */
#endif
    const unsigned char cvt_pos1                = 255 - 7;                    /* == cvt_pos8 - 7 */

//const unsigned char cvt_neg1                = 255 - 7 - 1 - 7;            /* == cvt_neg8 - 7 */
const unsigned char cvt_neg0                = 255 - 7 - 1 - 7 - 1;        /* == cvt_neg1 - 1 */
const unsigned char cvt_wordCode            = 255 - 7 - 1 - 7 - 1 - 1;    /* == cvt_neg0 - 1 */

const short cvt_lowestCode                     = 255 - 7 - 1 - 7 - 1 - 1;    /* == cvt_wordCode */
    
    if ( value < 0 ) {
        negative = true;
        value = (short)-value;
    }
    
    index = (short)(value / cvt_lowestCode);
    if ( index <= 8  && valueIn != -32768) {   /* write -32768 as a word below */
        register unsigned char *p = *pRef;
        if ( negative ) {
            assert( cvt_neg0 + 8 == cvt_neg8 );
            code = (unsigned char)(cvt_neg0 + index);
            assert( code >= cvt_neg0 && code <= cvt_neg8 );
            *p++ = code;
            value = (short)(value - index * cvt_lowestCode);
            assert( value >= 0 && value < cvt_lowestCode );
            *p++ = (unsigned char)value;
        } else {
            assert( cvt_pos1 + 7 == cvt_pos8 );
            if ( index > 0 ) {
                code = (unsigned char)(cvt_pos1 + index - 1);
                assert( code >= cvt_pos1 && code <= cvt_pos8 );
                *p++ = code;
                value = (short)(value - index * cvt_lowestCode);
            }
            assert( value >= 0 && value < cvt_lowestCode );
            *p++ = (unsigned char)value;
        }
        *pRef = p;
    } else {
        *(*pRef)++ = cvt_wordCode; /* Do a word */
        WRITEWORD_INC( ( char **)pRef, valueIn );
    }
}
#endif /* COMPRESS_ON */

#ifdef DECOMPRESS_ON
/* Reads a cvt value in the ctf format */
short ReadCVTShort( register unsigned char * *p )
{
    short index;
    unsigned char code;
    short value;
const unsigned char cvt_pos8                = 255;
const unsigned char cvt_pos1                = 255 - 7;                    /* == cvt_pos8 - 7 */
const unsigned char cvt_neg8                = 255 - 7 - 1;                /* == cvt_pos1 - 1 */
//const unsigned char cvt_neg1                = 255 - 7 - 1 - 7;            /* == cvt_neg8 - 7 */
const unsigned char cvt_neg0                = 255 - 7 - 1 - 7 - 1;        /* == cvt_neg1 - 1 */
#ifdef MTX_DEBUG
const unsigned char cvt_wordCode            = 255 - 7 - 1 - 7 - 1 - 1;    /* == cvt_neg0 - 1 */
#endif
const short cvt_lowestCode                     = 255 - 7 - 1 - 7 - 1 - 1;    /* == cvt_wordCode */
    
    code = *((*p)++);
    if ( code < (unsigned char)cvt_lowestCode ) {
        value = code;
    } else {
        if ( code >= cvt_pos1 && code <= cvt_pos8 ) {
            index = (short)(code - cvt_pos1 + 1);
            assert( index >= 1 && index <= 8 );
            value = *(*p)++;
            assert( value >= 0 && value < cvt_lowestCode );
            value = (short)(value + index * cvt_lowestCode);
        } else if ( code >= cvt_neg0 && code <= cvt_neg8 ) {
            index = (short)(code - cvt_neg0);
            assert( index >= 0 && index <= 8 );
            value = *(*p)++;
            assert( value >= 0 && value < cvt_lowestCode );
            value = (short)(value + index * cvt_lowestCode);
            value = (short)-value;
        } else {
            assert( code == cvt_wordCode );
            value = READWORD_INC( ( char **)p );
        }
    }
    return value; /*****/
}
#endif /* DECOMPRESS_ON */




#ifdef COMPRESS_ON
/* encode a short in 1 to 3 bytes (255 short format ); */
static void Write255Short( char * *pRef, short value )
{
    register char *p = *pRef;
const unsigned char flipSignCode        = 250;
//const unsigned char Hop3Code            = 251; /* A,X1,A,X2,A -> A,X1,Hop3Code,X2 - >A,X1,A,X2,A */
//const unsigned char Hop4Code            = 252; /* A,X1,A,X2,A,X3,A -> A,X1,Hop4Code,X2,X3 - >A,X1,A,X2,A,X3,A */
const unsigned char wordCode            = 253;
const unsigned char oneMoreByteCode2    = 254;
const unsigned char oneMoreByteCode1    = 255;
//const short lowestUCode = 253; /* wordCode */

const short lowestCode  = 250; /* flipSignCode */

    
    if ( value >= lowestCode*3 || value <= -lowestCode ) {
        *p++ = wordCode; /* Do a word */
        *(unsigned char *)p++ = (unsigned char)(value >> 8);
        *(unsigned char *)p++ = (unsigned char)(value & 0xff);
    } else {
        if ( value < 0 ) {
            *p++ = flipSignCode; /* flip the sign */
            value = (short)-value;
        } else if ( value >= lowestCode ) {
            value = (short)(value - lowestCode);
            if ( value >= lowestCode ) {
                value = (short)(value - lowestCode);
                *p++ = oneMoreByteCode2; /* one more byte */
            } else {
                *p++ = oneMoreByteCode1; /* one more byte */
            }
        }
        assert( value >= 0 && value < lowestCode );
        *p++ = (char)value;
    }
    *pRef = p;
}
#endif /* COMPRESS_ON */

#ifdef DECOMPRESS_ON
/* Reads a short in our 255 short format */
static short Read255Short( char * *pRef )
{
    unsigned char code;
    short value;
    register char *p = *pRef;
const unsigned char flipSignCode        = 250;
//const unsigned char Hop3Code            = 251; /* A,X1,A,X2,A -> A,X1,Hop3Code,X2 - >A,X1,A,X2,A */
//const unsigned char Hop4Code            = 252; /* A,X1,A,X2,A,X3,A -> A,X1,Hop4Code,X2,X3 - >A,X1,A,X2,A,X3,A */
const unsigned char wordCode            = 253;
const unsigned char oneMoreByteCode2    = 254;
const unsigned char oneMoreByteCode1    = 255;
const short lowestCode  = 250; /* flipSignCode */
    
    code = *((unsigned char *)p++);
    if ( code == wordCode ) {
        value = *(unsigned char *)p++;
        value <<= 8;
        value &= 0xff00;
        value |= *(unsigned char *)p++ & 0xff;
    } else {
        short sign = 1;
        if ( code == flipSignCode ) {
            sign = -1;
            code = *((unsigned char *)p++);
        }
        if ( code == oneMoreByteCode1 ) {
            value = *((unsigned char *)p++);
            assert( value >= 0 && value < lowestCode );
            value = (short)(value + lowestCode);
        } else if ( code == oneMoreByteCode2 ) {
            value = *((unsigned char *)p++);
            assert( value >= 0 && value < lowestCode );
            value = (short)(value + lowestCode*2);
        } else {
            value = code;
            assert( value >= 0 && value < lowestCode );
        }
        value = (short)(value * sign);
    }
    *pRef = p;
    return value; /*****/
}
#endif /* DECOMPRESS_ON */



#ifdef COMPRESS_ON
/* Stores the intial push sequence in CTF format */
static int PushInitialCTFStack( Glyph *t, char * *pExternal )
{
    register short i;
    char *p, *p0;
    long byteCount;
//const unsigned char flipSignCode        = 250;
const unsigned char Hop3Code            = 251; /* A,X1,A,X2,A -> A,X1,Hop3Code,X2 - >A,X1,A,X2,A */
const unsigned char Hop4Code            = 252; /* A,X1,A,X2,A,X3,A -> A,X1,Hop4Code,X2,X3 - >A,X1,A,X2,A,X3,A */
//const unsigned char wordCode            = 253;
//const unsigned char oneMoreByteCode2    = 254;
//const unsigned char oneMoreByteCode1    = 255;
    
    assert( t->pushCount >= 0 );
    Write255UShort( pExternal, t->pushCount );
    
    /* Assume worst case */
    byteCount = t->pushCount * 3;
    if ( t->ctfPtr->ctf2Index+byteCount > t->ctfPtr->ctfSize2 ) {
        t->ctfPtr->ctfSize2 = t->ctfPtr->ctf2Index + byteCount + (t->ctfPtr->ctfSize2>>1) + 2; /* Allocate memory in exponentially increasing steps */
        t->ctfPtr->ctf2     = (unsigned char *)MTX_mem_realloc( t->mem, t->ctfPtr->ctf2, sizeof( char ) * t->ctfPtr->ctfSize2 );
        CHECKLASTERROR(t->mem->env);
    }
    p0 = p = (char *)&t->ctfPtr->ctf2[ t->ctfPtr->ctf2Index ];
    
    for ( i = 0; i < (short)t->pushCount; ) {
        if ( i-2 >= 0 && t->pushData[i] == t->pushData[i-2] && i+2 < (short)t->pushCount && t->pushData[i] == t->pushData[i+2] ) {
            if ( i+4 < (short)t->pushCount && t->pushData[i] == t->pushData[i+4] ) {
                *p++ = Hop4Code; i++;
                Write255Short( &p, t->pushData[i++] );
                i++;
                Write255Short( &p, t->pushData[i++] );
                i++;
            } else {
                *p++ = Hop3Code; i++;
                Write255Short( &p, t->pushData[i++] );
                i++;
            }
        } else {
            Write255Short( &p, t->pushData[i++] );
        }
    }
    assert( i == t->pushCount );
    assert( (char __huge *)p-(char __huge *)p0 <= byteCount );
    byteCount = (long)((char __huge *)p-(char __huge *)p0);
    t->ctfPtr->ctf2Index += byteCount;
    assert( t->ctfPtr->ctf2Index <= t->ctfPtr->ctfSize2 );
    return 0;
}
#endif /* COMPRESS_ON */

#ifdef COMPRESS_ON
/* Writes out the remaining CTF code beyond the inital push sequence */
static int WriteRemainingCTFCode( Glyph *t, char * *pExternal )
{
    long byteCount;
    assert( t->remainingCodeSize >= 0 );
    
    Write255UShort( pExternal, t->remainingCodeSize );
    byteCount = t->remainingCodeSize;
    
    if ( t->ctfPtr->ctf3Index+byteCount > t->ctfPtr->ctfSize3 ) {
        t->ctfPtr->ctfSize3 = t->ctfPtr->ctf3Index + byteCount + (t->ctfPtr->ctfSize3>>1) + 2; /* Allocate memory in exponentially increasing steps */
        t->ctfPtr->ctf3     = (unsigned char *)MTX_mem_realloc( t->mem, t->ctfPtr->ctf3, sizeof( char ) * t->ctfPtr->ctfSize3 );
        CHECKLASTERROR(t->mem->env);
    }
    memcpyHuge( &t->ctfPtr->ctf3[ t->ctfPtr->ctf3Index ], &t->remainingCode[0], byteCount );
    t->ctfPtr->ctf3Index += byteCount;
    assert( t->ctfPtr->ctf3Index <= t->ctfPtr->ctfSize3 );
    return 0;
}
#endif /* COMPRESS_ON */

/* Emits a TrueType PUSHB[] or NPUSHB[] instruction */
static void BytePush( char * *pRef, short argStore[], long numberofArgs )
{
    register long i;
    register char *p = *pRef;

    assert( numberofArgs > 0 );
    if ( numberofArgs <= 8 ) {
        *p++ = (char)(0xB0 + numberofArgs -1);/* PUSHB */
    } else {
        *p++ = 0x40; /* NPUSHB */
        assert( numberofArgs <= 255 );
        *p++ = (char)numberofArgs;
    }
    for ( i = 0; i < numberofArgs; i++ ) {
        assert( argStore[i] >= 0 && argStore[i] <= 255 );
        *p++ = (char)argStore[i];
    }
    *pRef = p;
}

/* Emits a TrueType PUSHW[] or NPUSHW[] instruction */
static void WordPush( char * *pRef, short argStore[], long numberofArgs )
{
    register long i;
    register char *p = *pRef;

    assert( numberofArgs > 0 );
    if ( numberofArgs <= 8 ) {
        *p++ = (char)(0xB8 + numberofArgs -1);/* PUSHW */
    } else {
        *p++ = 0x41; /* NPUSHW */
        assert( numberofArgs <= 255 );
        *p++ = (char)numberofArgs;
    }
    for ( i = 0; i < numberofArgs; i++ ) {
        *p++ = (char)((argStore[i] >> 8) & 0x00ff);
        *p++ = (char)(argStore[i] & 0x00ff);
    }
    *pRef = p;
}

/* Returns the number of bytes that all fir within an unsigned byte */
static short ByteRunLength( short *argStore, short n )
{
    register short len;
    
    for ( len = 0; len < n && *argStore >= 0 && *argStore <= 255; argStore++ ) {
        len++;
    }
    return len; /*****/
}

/* Does an optimized sequence of TrueType push statements */
static void OptimizingPush( char * *p, short argStore[], long numberofArgs )
{
    register short i, argument;
    short argCount, n, byteRun, runLength;
    short doBytePush, limit;
    

    for ( n = 0; numberofArgs > 0;  ) {
        argCount = (short)(numberofArgs > 255 ? 255 : numberofArgs);
        doBytePush = true;
        
        for ( runLength = 0, i = n; i < (n + argCount); i++ ) {
            argument = argStore[i];
            byteRun = ByteRunLength( &argStore[i], (short)(n + argCount - i) );
            /* if we have a run of bytes of length 3 (2 if first or last) or more it is more
               optimal in terms of space to push them as bytes */
            limit = 3;
            if ( (runLength == 0) || ((byteRun + i) >= (n + argCount)) ) {
                limit = 2;
            }
            if ( byteRun >= limit ) {
                if ( runLength > 0 ) {
                    argCount = runLength;
                    doBytePush = false;
                    break; /*****/
                } else {
                    argCount = byteRun;
                    doBytePush = true;
                    break; /*****/
                }
            }
            if ( argument > 255 || argument < 0 ) doBytePush = false;
            runLength++;
        }
        if ( doBytePush ) {
            BytePush( p, &argStore[n], argCount );
        } else {
            WordPush( p, &argStore[n], argCount );
        }
        numberofArgs -= argCount;
        n = (short)(n+argCount);
    }
    assert( numberofArgs == 0 );
}


#ifdef DECOMPRESS_ON
/* Reads CTF instructions */
static int ReadAllCTFInstructions( Glyph *t, char * *p )
{
    register short i, limit;
    unsigned char *out, uc;
    char *old_p;
const unsigned char Hop3Code            = 251; /* A,X1,A,X2,A -> A,X1,Hop3Code,X2 - >A,X1,A,X2,A */
const unsigned char Hop4Code            = 252; /* A,X1,A,X2,A,X3,A -> A,X1,Hop4Code,X2,X3 - >A,X1,A,X2,A,X3,A */
    
    MTX_mem_free( t->mem,t->pushData);         t->pushData = NULL;
    MTX_mem_free( t->mem,t->remainingCode);    t->remainingCode = NULL;

    t->pushCount    = Read255UShort( p );
    t->pushData     = (short *)MTX_mem_malloc( t->mem, sizeof( short ) * t->pushCount);
    
    assert( t->ctfPtr != NULL );
    old_p = *p;
    *p    = (char *)&t->ctfPtr->ctf2[t->ctfPtr->ctf2Index];
    limit = t->pushCount;
    for ( i = 0; i < limit; ) {
        uc = **p;
        
        if ( uc == Hop3Code ) {
            short A;
            (*p)++;                                     /* Hop3Code */
            A = t->pushData[i-2];
            t->pushData[i++] = A;                       /* A */
            t->pushData[i++] = Read255Short( p );       /* X2 */
            t->pushData[i++] = A;                       /* A */
        } else if ( uc == Hop4Code ) {
            short A;
            (*p)++;                                     /* Hop4Code */
            A = t->pushData[i-2];
            t->pushData[i++] = A;                       /* A */
            t->pushData[i++] = Read255Short( p );       /* X2 */
            t->pushData[i++] = A;                       /* A */
            t->pushData[i++] = Read255Short( p );       /* X3 */
            t->pushData[i++] = A;                       /* A */
        } else {
            t->pushData[i++] = Read255Short( p );       /* Data */
        }
    }
    assert( i == t->pushCount );

    t->ctfPtr->ctf2Index += (long)((*p) - (char *)&t->ctfPtr->ctf2[t->ctfPtr->ctf2Index]); /* Go to oldpos + length of data */
    assert( t->ctfPtr->ctf2Index <= t->ctfPtr->ctfSize2 );
    (*p) = old_p;

    t->remainingCodeSize    = Read255UShort( p );

    limit = t->remainingCodeSize;
    assert( t->ctfPtr != NULL );
    
    MTX_mem_free( t->mem,t->code); t->code = NULL;
    t->code = (unsigned char *)MTX_mem_malloc( t->mem, sizeof( unsigned char ) * (t->pushCount*3 + t->remainingCodeSize + 16) );
    CHECKLASTERROR(t->mem->env);
    
    out = t->code;
    OptimizingPush( (char **)&out, t->pushData, t->pushCount ); /* Generate TrueType to set the intial stack */
    assert( (unsigned char __huge *)out - (unsigned char __huge *)t->code < t->pushCount*2 + 16  );
    if ( t->ctfPtr ) {
        if (t->ctfPtr->ctf3)
        {
            for ( i = 0; i < limit; i++ ) {
                *out++ = t->ctfPtr->ctf3[t->ctfPtr->ctf3Index++];
            }
        }
        assert( t->ctfPtr->ctf3Index <= t->ctfPtr->ctfSize3 );
    } else {
        for ( i = 0; i < limit; i++ ) {
            *out++ = t->remainingCode[i];
        }
    }
    t->numberOfInstructions = (unsigned short)(out - t->code);
    assert( t->numberOfInstructions < t->pushCount*3 + t->remainingCodeSize + 16  );
    return 0;
}
#endif /* DECOMPRESS_ON */

#ifdef DECOMPRESS_ON
/* Reads a glyph in the ctf format at the location pointed to by <p>. */
/* Returns the number of bytes read */
static long ReadCTFSpline( Glyph *t, char *sp )
{
    long i;
    short stmp, lastEndPoint;
    short x, y;
    unsigned char bitflags;
    char *spStart = sp;
    int setBBox = true; /* Initialize here to avoid compiler warnings, Sept 23, 1996 ---Sampo */
    
    MTX_mem_free( t->mem,t->startPoint);    t->startPoint   = NULL;
    MTX_mem_free( t->mem,t->endPoint);      t->endPoint     = NULL;
    MTX_mem_free( t->mem,t->onCurve);       t->onCurve      = NULL;
    MTX_mem_free( t->mem,t->x);             t->x            = NULL;
    MTX_mem_free( t->mem,t->y);             t->y            = NULL;
    
    t->numberOfContours = READWORD_INC( &sp );
    if ( t->numberOfContours < 0 ) {
        t->xmin = READWORD_INC( &sp );
        t->ymin = READWORD_INC( &sp );
        t->xmax = READWORD_INC( &sp );
        t->ymax = READWORD_INC( &sp );
    } else {
        if ( t->numberOfContours == 0x7fff) { /* flag to read bbox */
            t->numberOfContours = READWORD_INC( &sp );
            t->xmin = READWORD_INC( &sp );
            t->ymin = READWORD_INC( &sp );
            t->xmax = READWORD_INC( &sp );
            t->ymax = READWORD_INC( &sp );
            setBBox = false;
        }
    }
    if ( t->numberOfContours == 0 ) {
        return (long)((char __huge *)sp-(char __huge *)spStart); /******/
    }
    
    if ( t->numberOfContours < 0  ) {
         unsigned short flags;
         int weHaveInstructions;
         
         t->componentVersionNumber = t->numberOfContours;
         assert( t->componentData != NULL );
         do {
             flags = READWORD_INC( &sp );
             weHaveInstructions = flags & WE_HAVE_INSTRUCTIONS;
             t->componentData[ t->componentSize++] = flags;
             
             t->componentData[ t->componentSize++] = READWORD_INC( &sp );
             if ( flags & ARG_1_AND_2_ARE_WORDS ) {
                 /* arg 1 and 2 */
                 t->componentData[ t->componentSize++] = READWORD_INC( &sp );
                 t->componentData[ t->componentSize++] = READWORD_INC( &sp );
             } else {
                 /* arg 1 and 2 as bytes */
                  t->componentData[ t->componentSize++] = READWORD_INC( &sp );
             }
             
             if ( flags & WE_HAVE_A_SCALE ) {
                 /* scale */
                   t->componentData[ t->componentSize++] = READWORD_INC( &sp );
             } else if ( flags & WE_HAVE_AN_X_AND_Y_SCALE ) {
                 /* xscale, yscale */
                    t->componentData[ t->componentSize++] = READWORD_INC( &sp );
                   t->componentData[ t->componentSize++] = READWORD_INC( &sp );
             } else if ( flags & WE_HAVE_A_TWO_BY_TWO ) {
                 /* xscale, scale01, scale10, yscale */
                    t->componentData[ t->componentSize++] = READWORD_INC( &sp );
                   t->componentData[ t->componentSize++] = READWORD_INC( &sp );
                    t->componentData[ t->componentSize++] = READWORD_INC( &sp );
                   t->componentData[ t->componentSize++] = READWORD_INC( &sp );
             }
             assert( t->componentSize < t->maxComponentSize );
         } while ( flags & MORE_COMPONENTS );
         t->numberOfInstructions = 0;
         if ( weHaveInstructions ) {
             ReadAllCTFInstructions( t, &sp );
         }
    } else {
        /*startPoint = new unsigned short [ t->numberOfContours ]; assert( startPoint != NULL ); */
        /*endPoint = new unsigned short [ t->numberOfContours ]; assert( endPoint != NULL ); */
        t->startPoint = (unsigned short *)MTX_mem_malloc( t->mem, sizeof( unsigned short ) * t->numberOfContours );
        t->endPoint   = (unsigned short *)MTX_mem_malloc( t->mem, sizeof( unsigned short ) * t->numberOfContours );
        CHECKLASTERROR(t->mem->env);
    
        /* Non Composite */
        lastEndPoint = stmp = 0;
        for ( i = 0; i < t->numberOfContours; i++ ) {
            t->startPoint[i]    = stmp;
            t->endPoint[i]    = (unsigned short)(Read255UShort( &sp ) + lastEndPoint);
             assert( t->endPoint[i] >= 0  );

             lastEndPoint = t->endPoint[i];
             stmp = (short)(lastEndPoint + 1);
        }
        t->numberOfPoints = (short)(t->endPoint[t->numberOfContours - 1] + 1);
        assert( t->numberOfPoints > 0 );

        t->onCurve = (unsigned char *)MTX_mem_malloc( t->mem, sizeof( unsigned char ) * t->numberOfPoints );
        CHECKLASTERROR(t->mem->env);
        for ( i = 0; i < t->numberOfPoints; ) {
            t->onCurve[i++] = bitflags = *sp++;
        }
        t->x = (short *)MTX_mem_malloc( t->mem, sizeof( short ) * t->numberOfPoints );
        t->y = (short *)MTX_mem_malloc( t->mem, sizeof( short ) * t->numberOfPoints );
        CHECKLASTERROR(t->mem->env);

        x = y = 0;
        for ( stmp = 0, i = 0; i < t->numberOfPoints; i++ ) {
            char xIsNegative, yIsNegative, isOnCurvePoint;
            unsigned short index;
            long dx, dy;
            unsigned long data, ultmp;
            
            bitflags = t->onCurve[i];
            
            isOnCurvePoint = (char)!(bitflags & 0x80);
            
            index = (unsigned short)(bitflags & (128-1));
            assert( index < 128 );
            xIsNegative = coordEncoding[index].xIsNegative;
            yIsNegative = coordEncoding[index].yIsNegative;
            
            ultmp = *(unsigned char *)sp;
            ultmp <<= 24;
            data = ultmp;
            ultmp = *((unsigned char *)sp+1);
            ultmp <<= 16;
            data |= ultmp;
            ultmp = *((unsigned char *)sp+2);
            ultmp <<= 8;
            data |= ultmp;
            ultmp = *((unsigned char *)sp+3);
            /*ultmp <<= 0; */
            data |= ultmp;
            sp += coordEncoding[index].byteCount-1; /* Since 1 byte is for the flags */
            
            ultmp = data >> (32 - coordEncoding[index].xBits);
            ultmp &= ((1L << coordEncoding[index].xBits ) - 1);
            dx = ultmp; assert( dx >= 0 );
            ultmp = data >> (32 - coordEncoding[index].xBits - coordEncoding[index].yBits);
            ultmp &= ((1L << coordEncoding[index].yBits ) - 1);
            dy = ultmp; assert( dy >= 0 );
            dx += coordEncoding[index].dxPlus; assert( dx >= 0 );
            dy += coordEncoding[index].dyPlus; assert( dy >= 0 );
            if ( xIsNegative ) dx = -dx;
            if ( yIsNegative ) dy = -dy;
            x = (short)(x+dx);
            y = (short)(y+dy);

            t->onCurve[i] = (unsigned char)(isOnCurvePoint ? ONCURVE : 0);
            t->x[i] = x;
            t->y[i] = y;
        }
        if (setBBox) SetBBox(t); /* Set it, since it is not stored in the CTF format */
        ReadAllCTFInstructions( t, &sp );
    } /* t->numberOfContours >= 0 */
    return (long)((char __huge *)sp-(char __huge *)spStart); /******/
}
#endif /* DECOMPRESS_ON */

    

#ifdef COMPRESS_ON
/* Writes out the Glyph in ctf format at the location pointed to by <p>. */
/* Returns the number of bytes written. */
long MTX_Glyph_WriteCTFSpline( Glyph *t, char * *destSfnt, long pos, long *maxOutSize )
{
    register short i, j, k;
    register short x, y;
    unsigned char bitFlags;
    long bitFlagOffset;
    long deltaFromStart;
    /* Harmless pointer */
    register unsigned char *f;
    /* Pointers that depend on destSfnt */
    char *pStart, *p;

    deltaFromStart = 0;
    pStart = (char *)&(*destSfnt)[pos]; p = (char __huge *)pStart + deltaFromStart;
    
    if ( t->numberOfContours == 0 ) {
        deltaFromStart = (long)((char __huge *)p - (char __huge *)pStart);
        AllocateGlyphSpace( t, destSfnt, pos, (long)((char __huge *)p-(char __huge *)pStart+2), maxOutSize );
        pStart = (char *)&(*destSfnt)[pos]; p = (char __huge *)pStart + deltaFromStart; /* Reset pointers */
        *p++ = 0;
        *p++ = 0;
        return (long)((char __huge *)p - (char __huge *)pStart); /******/
    }
    
    if ( t->componentSize > 0 ) {
        assert( t->componentVersionNumber < 0 );
        deltaFromStart = (long)((char __huge *)p - (char __huge *)pStart);
        AllocateGlyphSpace( t, destSfnt, pos, (long)((char __huge *)p-(char __huge *)pStart+5*2), maxOutSize );
        pStart = (char *)&(*destSfnt)[pos]; p = (char __huge *)pStart + deltaFromStart; /* Reset pointers */
        WRITEWORD_INC( &p, t->componentVersionNumber );
        /* Bounding box */
        WRITEWORD_INC( &p, t->xmin );
        WRITEWORD_INC( &p, t->ymin );
        WRITEWORD_INC( &p, t->xmax );
        WRITEWORD_INC( &p, t->ymax );
    } else {
         short xmax, xmin, ymax, ymin;
          short xmax2, xmin2, ymax2, ymin2;

        MTX_Glyph_GetBBox( t, &xmax, &xmin, &ymax, &ymin);
        MTX_Glyph_ComputeBBox( t, &xmax2, &xmin2, &ymax2, &ymin2);
        if ((xmin != xmin2) | (ymin != ymin2) | (xmax != xmax2) | (ymax != ymax2)){
            deltaFromStart = (long)((char __huge *)p - (char __huge *)pStart);
            AllocateGlyphSpace( t, destSfnt, pos, (long)((char __huge *)p-(char __huge *)pStart+6*2), maxOutSize );
            pStart = (char *)&(*destSfnt)[pos]; p = (char __huge *)pStart + deltaFromStart; /* Reset pointers */
            WRITEWORD_INC( &p, 0x7fff );       /* flag indicating BBox follows */
            WRITEWORD_INC( &p, t->numberOfContours );
             /* Bounding box */
            WRITEWORD_INC( &p, xmin );
            WRITEWORD_INC( &p, ymin );
            WRITEWORD_INC( &p, xmax );
            WRITEWORD_INC( &p, ymax );
        } else {
            deltaFromStart = (long)((char __huge *)p - (char __huge *)pStart);
            AllocateGlyphSpace( t, destSfnt, pos, (long)((char __huge *)p-(char __huge *)pStart+2), maxOutSize );
            pStart = (char *)&(*destSfnt)[pos]; p = (char __huge *)pStart + deltaFromStart; /* Reset pointers */
            WRITEWORD_INC( &p, t->numberOfContours );
        }
    }
    
    if ( t->componentSize > 0 ) {
        deltaFromStart = (long)((char __huge *)p - (char __huge *)pStart);
        AllocateGlyphSpace( t, destSfnt, pos, (long)((char __huge *)p-(char __huge *)pStart+t->componentSize*2), maxOutSize );
        pStart = (char *)&(*destSfnt)[pos]; p = (char __huge *)pStart + deltaFromStart; /* Reset pointers */
        for ( i = 0; i < t->componentSize; i++ ) {
            WRITEWORD_INC( &p, t->componentData[i] );
        }
        if ( t->numberOfInstructions > 0 ) {
            /* The old scheme was to output t->numberOfInstructions, and then the code array */
            /* Now we are more efficient */
            deltaFromStart = (long)((char __huge *)p - (char __huge *)pStart);
            AllocateGlyphSpace( t, destSfnt, pos, (long)((char __huge *)p-(char __huge *)pStart+6), maxOutSize ); /* 6 bytes for number of contours & t->remainingCodeSize */
            pStart = (char *)&(*destSfnt)[pos]; p = (char __huge *)pStart + deltaFromStart; /* Reset pointers */
            PushInitialCTFStack( t, &p ); /* goes to ctf2 */
            WriteRemainingCTFCode(t,  &p ); /* goes to ctf3 */
        }
        return ( (long)((char __huge *)p - (char __huge *)pStart) ); /******/
    }
    f = (unsigned char *)MTX_mem_malloc( t->mem, sizeof( unsigned char ) * t->numberOfPoints );
    CHECKLASTERROR(t->mem->env);

    deltaFromStart = (long)((char __huge *)p - (char __huge *)pStart);
    AllocateGlyphSpace( t, destSfnt, pos, (long)((char __huge *)p-(char __huge *)pStart+t->numberOfContours*3), maxOutSize ); /* At least big enough */
    pStart = (char *)&(*destSfnt)[pos]; p = (char __huge *)pStart + deltaFromStart; /* Reset pointers */
    for ( i = j = 0; i < t->numberOfContours; i++ ) {
        k = (short)(t->endPoint[i] - j);
        Write255UShort( &p, k );
        j = t->endPoint[i];
    }
    
    /* The old scheme was to output t->numberOfInstructions, and then the code array */
    /* Now we are more efficient */

    bitFlagOffset = (long)((char __huge *)p - (char __huge *)pStart);
    p += t->numberOfPoints; /* skip the bitFlags */
    deltaFromStart = (long)((char __huge *)p - (char __huge *)pStart);
    AllocateGlyphSpace( t, destSfnt, pos, (long)((char __huge *)p-(char __huge *)pStart), maxOutSize );
    pStart = (char *)&(*destSfnt)[pos]; p = (char __huge *)pStart + deltaFromStart; /* Reset pointers */
    x = y = 0;
    /* Calculate flags */
    for ( x = y = i = 0; i < t->numberOfPoints; i++ ) {
        char xIsNegative, yIsNegative;
        long dx, dy;
        unsigned short index;
        short bCount;
        unsigned short x0, x1, y0, y1;
        unsigned long data, coord, shift;
        
        /*bitFlags = t->onCurve[i] & ONCURVE ? 0x80 : 0; */
        bitFlags = (unsigned char)(t->onCurve[i] & ONCURVE ?  0 : 0x80); /* This comresses better ! */
        dx = t->x[i] - x; x = t->x[i];
        dy = t->y[i] - y; y = t->y[i];

        xIsNegative = false;
        if ( dx < 0 ) {
            xIsNegative = true;
            dx = -dx;
        }
        yIsNegative = false;
        if ( dy < 0 ) {
            yIsNegative = true;
            dy = -dy;
        }
        
        /* Pick the lowest index that works */
        for ( index = 0; index < 128; index++ ) {
            if ( coordEncoding[index].xBits != 0 && coordEncoding[index].xIsNegative != xIsNegative ) continue; /******/
            if ( coordEncoding[index].yBits != 0 && coordEncoding[index].yIsNegative != yIsNegative ) continue; /******/
            x0 = coordEncoding[index].dxPlus;
            x1 = (unsigned short)(x0 + (1L << coordEncoding[index].xBits ) - 1);
            y0 = coordEncoding[index].dyPlus;
            y1 = (unsigned short)(y0 + (1L << coordEncoding[index].yBits ) - 1);
            if ( (unsigned short)dx >= x0 && (unsigned short)dx <= x1 && (unsigned short)dy >= y0 && (unsigned short)dy <= y1 ) break; /******/
        }
        assert( index < 128 );
        bitFlags |= index;
        f[i] = bitFlags;
        #ifdef OLD
            switch ( coordEncoding[index].byteCount ) {
                case 1: ByteCount1++; break;
                case 2: ByteCount2++; break;
                case 3: ByteCount3++; break;
                case 4: ByteCount4++; break;
                case 5: ByteCount5++; break;
            }
        #endif /* OLD */
        deltaFromStart = (long)((char __huge *)p - (char __huge *)pStart);
        AllocateGlyphSpace( t, destSfnt, pos, (long)((char __huge *)p-(char __huge *)pStart+coordEncoding[index].byteCount-1), maxOutSize );
        pStart = (char *)&(*destSfnt)[pos]; p = (char __huge *)pStart + deltaFromStart; /* Reset pointers */
        
        dx -= coordEncoding[index].dxPlus; assert( dx >= 0 );
        dy -= coordEncoding[index].dyPlus; assert( dy >= 0 );
        assert( dx < (1L << coordEncoding[index].xBits ) );
        assert( dy < (1L << coordEncoding[index].yBits ) );
        data = 0;
        if ( coordEncoding[index].xBits > 0 ) {
            coord = dx & ((1L << coordEncoding[index].xBits ) - 1);
            data |= coord << (32 - coordEncoding[index].xBits);
        }
        if ( coordEncoding[index].yBits > 0 ) {
            coord = dy & ((1L << coordEncoding[index].yBits ) - 1);
            data |= coord << (32 - coordEncoding[index].xBits - coordEncoding[index].yBits);
        }
        for ( shift = 24, bCount = 1; bCount < coordEncoding[index].byteCount; bCount++ ) {
            assert( shift >= 0 );
            *(unsigned char *)p++ = (char)((data >> shift) & 0xff);
            shift -= 8;
        }
    } /* for i */
    
    /* Write out bitFlags, at the old location upstream in the data */
    for ( i = 0; i < t->numberOfPoints; i++) {
        /**p++ = f[i]; */
        pStart[bitFlagOffset + i] = f[i];
    }

    deltaFromStart = (long)((char __huge *)p - (char __huge *)pStart);
    AllocateGlyphSpace( t, destSfnt, pos, (long)((char __huge *)p-(char __huge *)pStart+6), maxOutSize ); /* 6 bytes for number of contours & t->remainingCodeSize */
    pStart = (char *)&(*destSfnt)[pos]; p = (char __huge *)pStart + deltaFromStart; /* Reset pointers */
    PushInitialCTFStack( t, &p );  /* goes to ctf2 */
    WriteRemainingCTFCode( t, &p ); /* goes to ctf3 */

    MTX_mem_free( t->mem, f );
    return (long)((char __huge *)p - (char __huge *)pStart); /******/
}
#endif /* COMPRESS_ON */


/* The Glyph Constructor */
Glyph *MTX_Glyph_Create( MTX_MemHandler *mem, char isTTFSpline, char *sp, long splineLength, short lsb, short aw,
                                long *bytesRead, ctfDescriptor *ctfData, char *inDataStart, char *inDataEnd )
{
    Glyph *t    = (Glyph *)MTX_mem_malloc( mem, sizeof( Glyph ) );
    CHECKLASTERROR(mem->env);
    t->mem        = mem;
    
    t->advanceWidth          = aw;
    t->leftSideBearing       = lsb;
     t->componentSize        = 0;
    
    t->numberOfContours      = 0;
    t->numberOfPoints        = 0;
    t->numberOfInstructions  = 0;
    t->startPoint            = NULL;
    t->endPoint              = NULL;
    t->x                     = NULL;
    t->y                     = NULL;
    t->onCurve               = NULL;
    t->code                  = NULL;
    t->componentData         = NULL;
    t->pushData              = NULL;
    t->remainingCode         = NULL;
    /* t->remainingCodeType    = NULL; */
    
    t->inDataStart           = inDataStart;
    t->inDataEnd             = inDataEnd;
    
    t->ctfPtr                = ctfData;
    assert( ctfData != NULL );    
         
    t->maxComponentSize = 1024;
    /*t->componentData = new short [ t->maxComponentSize ]; assert( t->componentData != NULL ); */
    t->componentData = (short *)MTX_mem_malloc( t->mem, sizeof( short ) * t->maxComponentSize );
    CHECKLASTERROR(t->mem->env);
         
    if ( isTTFSpline ) {
        if ( splineLength ) {
            #ifdef COMPRESS_ON
                if ( sp ) {
                    *bytesRead = ReadTTFSpline( t, sp );
                    CHECKLASTERROR(t->mem->env);
                    ParseCode( t );
                } else {
                    *bytesRead = 0;
                    t->numberOfContours = 0;
                }
            #endif
        } else { 
            *bytesRead = 0;
        }
    } else {
        #ifdef DECOMPRESS_ON
        *bytesRead = ReadCTFSpline( t, sp );
        CHECKLASTERROR(t->mem->env);
        #endif
    }
    return t; /******/
}

/* Deconstructor */
void MTX_Glyph_Destroy( Glyph *t )
{
    if (t == NULL)
        return;
    /* It is always ok to do delete on NULL */
    MTX_mem_free( t->mem, t->startPoint);
    MTX_mem_free( t->mem, t->endPoint);
    MTX_mem_free( t->mem, t->x);
    MTX_mem_free( t->mem, t->y);
    MTX_mem_free( t->mem, t->onCurve);
    MTX_mem_free( t->mem, t->code);
    MTX_mem_free( t->mem, t->componentData);
    MTX_mem_free( t->mem, t->pushData);
    MTX_mem_free( t->mem, t->remainingCode);
    /* MTX_mem_free( t->mem, t->remainingCodeType); */
    MTX_mem_free( t->mem, t );
}
