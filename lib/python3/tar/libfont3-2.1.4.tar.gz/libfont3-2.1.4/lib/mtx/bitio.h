/* Copyright (C) 1989, 1990, 1991, 1992, 1993, 1994, 1995, 1996
 * all rights reserved, by Bayer Corp., Agfa Division, Wilmington, MA.
 *
 * This software is furnished under a license and may be used and
 * copied only in accordance with the terms of such license and with
 * the inclusion of the above copyright notice. This software or any
 * other copies thereof may not be provided or otherwise made
 * available to any other person except as allowed under license. No
 * title to and ownership of the software is hereby transferred.
 *
 * This information in this software is subject to change without notice
 */
/* $Header:   I:\bull\c_exprss\src\bitio.h_v   1.2   14 May 1997 17:18:50   MARTIN  $ */
/* $Log:   I:\bull\c_exprss\src\bitio.h_v  $
 * 
 *    Rev 1.2   14 May 1997 17:18:50   MARTIN
 * 
 * Renamed MEMORY.H to MTXMEM.H.
 * 
 *    Rev 1.1   29 Apr 1997 14:36:08   MARTIN
 * 
 * Modified input and output bit references from int to short.
 * Modified 2nd arg to MTX_BITIO_output_bit from int to long.
 * 
 *    Rev 1.0   17 Dec 1996 16:31:40   MARTIN
 * Initial revision.
   
      Rev 1.2   09 Oct 1996 16:05:58   MARTIN
   
   Modifications for memory based version.
   
      Rev 1.1   24 Apr 1996 15:47:36   MARTIN
   
   Fixed header.
   
      Rev 1.0   24 Apr 1996 10:50:32   LISA
   Initial revision.
*/

/*
 * File:                        bitio.hpp
 * Author:                        Sampo Kaasila
 * First Version:                February 6, 1996
 * First Memory Version:        September 27, 1996 (Sampo)
 * First pure ANSI C version:     October 28, 1996  (Sampo)
 * Remove the use of setjmp and longjmp. August 6, 2014 (Taylor)
 */
#include "mtxmem.h"

#ifdef __cplusplus
extern "C" {
#endif

typedef struct {
    /* private */
    unsigned char  *mem_bytes;    /* Memory data buffer */
    long            mem_index;    /* Memory area size */
    long            mem_size;    /* Memory area size */
    
    
    unsigned short input_bit_count;     /* Input bits buffered */
    unsigned short input_bit_buffer;    /* Input buffer */
    long bytes_in;            /* Input byte count */

    unsigned short output_bit_count;    /* Output bits buffered */
    unsigned short output_bit_buffer;    /* Output buffer */
    long bytes_out;            /* Output byte count */

    char ReadOrWrite;
    
    MTX_MemHandler *mem;  
    /* public */
    /* No public fields! */
} BITIO;

/* public interface routines */
/* Writes out <numberOfBits> to the output memory */
void MTX_BITIO_WriteValue( BITIO *t, unsigned long value, long numberOfBits );
/* Reads out <numberOfBits> from the input memory */
unsigned long MTX_BITIO_ReadValue( BITIO *t, long numberOfBits );

/* Read a bit from input memory */
short MTX_BITIO_input_bit(BITIO *t);

/* Write one bit to output memory */
int MTX_BITIO_output_bit(BITIO *t,unsigned long bit);
/* Flush any remaining bits to output memory before finnishing */
int MTX_BITIO_flush_bits(BITIO *t);

/* Returns the memory buffer pointer */
unsigned char *MTX_BITIO_GetMemoryPointer( BITIO *t );
long MTX_BITIO_GetBytesOut( BITIO *t ); /* Get method for the output byte count */
long MTX_BITIO_GetBytesIn( BITIO *t );  /* Get method for the input byte count */

/* Constructor for the new Memory based incarnation */
BITIO *MTX_BITIO_Create( MTX_MemHandler *mem, void *memPtr, long memSize, const char param ); /* mem Pointer, current size, 'r' or 'w' */
/* Destructor */
void MTX_BITIO_Destroy(BITIO *t);

#ifdef __cplusplus
}
#endif
