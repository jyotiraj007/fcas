// Copyright (C) 2014, 2015 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// Conversion.cpp

#include <string.h>
#include <stdlib.h>
#include "Conversion.h"
#include "ContourPoint.h"
#include "CubicGlyph.h"

//#define CONV_DUMP

#ifdef CONV_DUMP
static void dumpCubic(CubicGlyph cubicGlyph)
{
    printf("\nCubic Glyph:\n");

    if (cubicGlyph.NumContours() == 0)
    {
        printf("   ---No Contours---\n\n");
        return;
    }

    int totPts = 0;

    for (int i = 0; i < cubicGlyph.NumContours(); i++)
    {
        CubicContour contour = cubicGlyph.GetContour(i);
        int numPts = contour.NumPoints();

        totPts += numPts;

        printf("contour %d (%d pts)\n", i, numPts);
        for (int j = 0; j < numPts; j++)
        {
            Vector2f point = contour.GetPoint(j).m_Point;
            printf("%f %f\n", point[0], point[1]);
        }
    }

    printf("num points: %d\n\n", totPts);
}

static char* TypeToString(ContourPoint::PointType type)
{
    switch (type)
    {
    case ContourPoint::PointType::MOVE_TO: return "MOVE_TO";
    case ContourPoint::PointType::LINE_TO: return "LINE_TO";
    case ContourPoint::PointType::ON_CURVE: return "ON_CURVE";
    case ContourPoint::PointType::OFF_CURVE: return "OFF_CURVE";
    default: return "<UNKNOWN?>";
    }
}


static void dumpQuad(QuadGlyph* quadGlyph)
{
    printf("\nQuadContour:\n");
    printf("num contours: %d\n", quadGlyph->NumContours());
    for (int i = 0; i < quadGlyph->NumContours(); i++)
    {
        printf("Contour %d:\n", i);
        QuadContour quadContour = quadGlyph->GetContour(i);

        int numPts = quadContour.NumPoints();
        if (quadContour.IsClosed())
            numPts--;

        for (int j = 0; j < numPts; j++)
        {
            ContourPoint point = quadContour.GetPoint(j);
            printf("%f %f (%s)\n", (float)point.m_Point[0], (float)point.m_Point[1], TypeToString(point.m_Type));
        }
        if (quadContour.NumPoints() != numPts)
        {
            ContourPoint point = quadContour.GetPoint(numPts);
            printf("%f %f (%s) (unused closing point)\n", (float)point.m_Point[0], (float)point.m_Point[1], TypeToString(point.m_Type));
        }
    }
    printf("\n");
}

#define DumpCubic(c) dumpCubic(c);
#define DumpQuad(q) dumpQuad(q);
#define DumpFail() printf("*** Unable to convert to quads. ***\n");
#define DumpFailC() printf("*** Unable to convert to cubics. ***\n");
#else

#define DumpCubic(c)
#define DumpQuad(q)
#define DumpFail()
#define DumpFailC()

#endif

//
// Converts a cubic outline to a quad outline.
//
// @param[in]   cubicOutline        input cubic outline, must have closed contours, assumed to have two phantom points at end
// @param[in]   tolerance           fit tolerance, must be in [0.1, 10.0]
// @param[out]  quadOutline         output quadratic outline, the contours of which are NOT closed
//
// @notes
//  Client must free (with free()) memory allocated at quadOutline->x, ->y, ->endPtsOfContours, and ->types
//
//  Current implementation does not scale the created quad ouline. It is created with the same design units
//  as the input cubic outline.
//
extern "C" Conversion_Error convertCubic(Simple_Outline *cubicOutline, float tolerance, Simple_Outline *quadOutline)
{
    if ((cubicOutline == NULL) || (quadOutline == NULL))
        return CONVERSION_INVALID_PARAM;

    if ((tolerance < 0.10f) || (tolerance > 10.0f))
        return CONVERSION_INVALID_PARAM;

    int np = cubicOutline->np;
    float* x  = cubicOutline->x;
    float* y  = cubicOutline->y;
    Point_Type *types = cubicOutline->types;

    if (np == 0 || x == NULL || y == NULL || types == NULL)
        return CONVERSION_INVALID_PARAM;

    // First point must be a moveto
    if (types[0] != MOVE_TO)
        return CONVERSION_INVALID_PARAM;

    if (cubicOutline->designUnits == 0)
        return CONVERSION_INVALID_PARAM;

    CubicGlyph cubicGlyph(cubicOutline->designUnits);
    CubicContour cubicContour;

    for (int i = 0; i < np-2; i++)
    {
        switch (types[i])
        {
        case MOVE_TO:
            if (i != 0)
            {
                if (cubicContour.NumPoints() > 0)
                    cubicGlyph.AddContour(cubicContour);
                cubicContour.Clear();
            }
            cubicContour.AddPoint(ContourPoint(ContourPoint::MOVE_TO, Vector2f(x[i], y[i])));
            break;
        case LINE_TO:
            cubicContour.AddPoint(ContourPoint(ContourPoint::LINE_TO, Vector2f(x[i], y[i])));
            break;
        case ON_CURVE:
            cubicContour.AddPoint(ContourPoint(ContourPoint::ON_CURVE, Vector2f(x[i], y[i])));
            break;
        case OFF_CURVE:
            cubicContour.AddPoint(ContourPoint(ContourPoint::OFF_CURVE, Vector2f(x[i], y[i])));
            break;
        }
    }

    // Add last contour
    if (cubicContour.NumPoints() > 0)
        cubicGlyph.AddContour(cubicContour);

    DumpCubic(cubicGlyph);

    if (cubicGlyph.NumContours() == 0)
    {
        return CONVERSION_SUCCESS;
    }

    // For now the quad outline will be created at the same font units as the original cubic outline
#if 1
    QuadGlyph quadGlyph(cubicOutline->designUnits);
#else
    QuadGlyph quadGlyph(quadOutline->designUnits);
#endif

    // Do the conversion
    bool result = cubicGlyph.Match(quadGlyph, tolerance);

    if (!result)
    {
        DumpFail();
        return CONVERSION_FAIL;
    }

    quadOutline->nc = (unsigned short)quadGlyph.NumContours();
    np = 0;

    for (int i = 0; i < quadOutline->nc; i++)
    {
        QuadContour quadContour = quadGlyph.GetContour(i);

        int contourNpts = quadContour.NumPoints();

        if (quadContour.IsClosed())
            contourNpts -= 1;

        np += contourNpts;
    }

    if (np == 0)
        return CONVERSION_FAIL;

    quadOutline->np = (unsigned short)np;

    quadOutline->endPtsOfContours = (unsigned short *)calloc(quadOutline->nc, sizeof(unsigned short));
    if (NULL == quadOutline->endPtsOfContours)
        return CONVERSION_MEMORY;

    x = quadOutline->x = (float *)calloc(np, sizeof(float));
    if (NULL == x)
    {
        free(quadOutline->endPtsOfContours);
        return CONVERSION_MEMORY;
    }

    y = quadOutline->y = (float *)calloc(np, sizeof(float));
    if (NULL == y)
    {
        free(x);
        free(quadOutline->endPtsOfContours);
        return CONVERSION_MEMORY;
    }

    quadOutline->types = (Point_Type *)calloc(np, sizeof(Point_Type));
    if (NULL == quadOutline->types)
    {
        free(y);
        free(x);
        free(quadOutline->endPtsOfContours);
        return CONVERSION_MEMORY;
    }

    unsigned short index = 0;

    for (int i = 0; i < quadGlyph.NumContours(); i++)
    {
        QuadContour quadContour = quadGlyph.GetContour(i);
        int nPts = quadContour.NumPoints();

        if (quadContour.IsClosed())
            nPts -= 1;

        for (int j = 0; j < nPts; j++)
        {
            ContourPoint point = quadContour.GetPoint(j);
            x[index] = point.m_Point[0];
            y[index] = point.m_Point[1];
            quadOutline->types[index++] = (Point_Type)point.m_Type;
        }
        quadOutline->endPtsOfContours[i] = index-1;
    }

    DumpQuad(&quadGlyph);

    return CONVERSION_SUCCESS;
}


//
// Converts a quad outline to a cubic outline.
//
// @param[in]   quadOutline         input quadratic outline, must have closed contours
// @param[in]   tolerance           fit tolerance, must be in [0.001, 10.0]
// @param[out]  cubicOutline        output cubic outline, the contours of which ARE closed
//
// @notes
//  Client must free (with free()) memory allocated at cubicOutline->x, ->y, ->endPtsOfContours, and ->types
//
//  Current implementation does not scale the created cubic ouline. It is created with the same design units
//  as the input quadratic outline.
//

extern "C" Conversion_Error convertQuadratic(Simple_Outline *quadOutline, float tolerance, Simple_Outline *cubicOutline)
{
    if ((quadOutline == NULL) || (cubicOutline == NULL))
        return CONVERSION_INVALID_PARAM;

    if ((tolerance < 0.001f) || (tolerance > 10.0f))        // TODO check that range is correct
        return CONVERSION_INVALID_PARAM;

    int np = quadOutline->np;
    float* x = quadOutline->x;
    float* y = quadOutline->y;
    Point_Type* types = quadOutline->types;

    if (np == 0 || x == NULL || y == NULL || types == NULL)
        return CONVERSION_INVALID_PARAM;

    if (quadOutline->designUnits == 0)
        return CONVERSION_INVALID_PARAM;

    // First point must be a moveto
    if (types[0] != MOVE_TO)
        return CONVERSION_INVALID_PARAM;

    QuadGlyph quadGlyph(quadOutline->designUnits);
    QuadContour quadContour;

    for (int i = 0; i < np/*- 2 not expecting phantom pts*/; i++)
    {
        switch (types[i])
        {
        case MOVE_TO:
            if (i != 0)
            {
                if (quadContour.NumPoints() > 0)
                    quadGlyph.AddContour(quadContour);
                quadContour.Clear();
            }
            quadContour.AddPoint(ContourPoint(ContourPoint::MOVE_TO, Vector2f(x[i], y[i])));
            break;
        case LINE_TO:
            quadContour.AddPoint(ContourPoint(ContourPoint::LINE_TO, Vector2f(x[i], y[i])));
            break;
        case ON_CURVE:
            quadContour.AddPoint(ContourPoint(ContourPoint::ON_CURVE, Vector2f(x[i], y[i])));
            break;
        case OFF_CURVE:
            quadContour.AddPoint(ContourPoint(ContourPoint::OFF_CURVE, Vector2f(x[i], y[i])));
            break;
        }
    }

    // Add last contour
    if (quadContour.NumPoints() > 0)
        quadGlyph.AddContour(quadContour);

    DumpQuad(&quadGlyph);

    if (quadGlyph.NumContours() == 0)
    {
        return CONVERSION_SUCCESS;
    }

    // For now the cubic outline will be created at the same font units as the original quad outline
#if 1
    CubicGlyph cubicGlyph(quadOutline->designUnits);
#else
    CubicGlyph cubicGlyph(cubicOutline->designUnits);
#endif

    // Do the conversion
    bool result = quadGlyph.Match(cubicGlyph, tolerance);

    if (!result)
    {
        DumpFailC();
        return CONVERSION_FAIL;
    }

    cubicOutline->nc = (unsigned short)cubicGlyph.NumContours();
    np = 0;

    for (int i = 0; i < cubicOutline->nc; i++)
    {
        CubicContour cubicContour = cubicGlyph.GetContour(i);
        int countourNpts = cubicContour.NumPoints();

        np += countourNpts;
    }

    if (np == 0)
        return CONVERSION_FAIL;

    cubicOutline->np = (unsigned short)np;

    cubicOutline->endPtsOfContours = (unsigned short *)calloc(cubicOutline->nc, sizeof(unsigned short));
    if (NULL == cubicOutline->endPtsOfContours)
        return CONVERSION_MEMORY;

    x = cubicOutline->x = (float *)calloc(np, sizeof(float));
    if (NULL == x)
    {
        free(cubicOutline->endPtsOfContours);
        return CONVERSION_MEMORY;
    }

    y = cubicOutline->y = (float *)calloc(np, sizeof(float));
    if (NULL == y)
    {
        free(x);
        free(cubicOutline->endPtsOfContours);
        return CONVERSION_MEMORY;
    }

    types = cubicOutline->types = (Point_Type *)calloc(np, sizeof(Point_Type));
    if (NULL == types)
    {
        free(y);
        free(x);
        free(cubicOutline->endPtsOfContours);
        return CONVERSION_MEMORY;
    }

    unsigned short index = 0;

    for (int i = 0; i < cubicGlyph.NumContours(); i++)
    {
        CubicContour cubicContour = cubicGlyph.GetContour(i);
        int nPts = cubicContour.NumPoints();

        for (int j = 0; j < nPts; j++)
        {
            ContourPoint point = cubicContour.GetPoint(j);
            x[index] = point.m_Point[0];
            y[index] = point.m_Point[1];
            types[index++] = (Point_Type)point.m_Type;
        }
        cubicOutline->endPtsOfContours[i] = index - 1;
    }

    DumpCubic(cubicGlyph);

    return CONVERSION_SUCCESS;
}

Conversion_Error refitCubic(Simple_Outline *cubicOutline, float tolerance, Simple_Outline *refitOutline)
{
    if ((cubicOutline == NULL) || (refitOutline == NULL))
        return CONVERSION_INVALID_PARAM;

    if ((tolerance < 0.10f) || (tolerance > 10.0f))
        return CONVERSION_INVALID_PARAM;

    int np = cubicOutline->np;
    float* x = cubicOutline->x;
    float* y = cubicOutline->y;
    Point_Type *types = cubicOutline->types;

    if (np == 0 || x == NULL || y == NULL || types == NULL)
        return CONVERSION_INVALID_PARAM;

    // First point must be a moveto
    if (types[0] != MOVE_TO)
        return CONVERSION_INVALID_PARAM;

    if (cubicOutline->designUnits == 0)
        return CONVERSION_INVALID_PARAM;

    // Create a CubicGlyph from the passed in outline
    CubicGlyph cubicGlyph(cubicOutline->designUnits);
    CubicContour cubicContour;

    for (int i = 0; i < np - 2; i++)
    {
        switch (types[i])
        {
        case MOVE_TO:
            if (i != 0)
            {
                if (cubicContour.NumPoints() > 0)
                    cubicGlyph.AddContour(cubicContour);
                cubicContour.Clear();
            }
            cubicContour.AddPoint(ContourPoint(ContourPoint::MOVE_TO, Vector2f(x[i], y[i])));
            break;
        case LINE_TO:
            cubicContour.AddPoint(ContourPoint(ContourPoint::LINE_TO, Vector2f(x[i], y[i])));
            break;
        case ON_CURVE:
            cubicContour.AddPoint(ContourPoint(ContourPoint::ON_CURVE, Vector2f(x[i], y[i])));
            break;
        case OFF_CURVE:
            cubicContour.AddPoint(ContourPoint(ContourPoint::OFF_CURVE, Vector2f(x[i], y[i])));
            break;
        }
    }

    // Add last contour
    if (cubicContour.NumPoints() > 0)
        cubicGlyph.AddContour(cubicContour);

    DumpCubic(cubicGlyph);

    if (cubicGlyph.NumContours() == 0)
        return CONVERSION_SUCCESS;

    CubicGlyph refittedGlyph(cubicOutline->designUnits);

    // Do the match.
    bool result = cubicGlyph.Match(refittedGlyph, tolerance, /*true*/ false);

    if (!result)
    {
        DumpFail();
        return CONVERSION_FAIL;
    }


    // Fill in the output outline from the refitted glyph.
    refitOutline->nc = (unsigned short)refittedGlyph.NumContours();
    np = 0;

    for (int i = 0; i < refitOutline->nc; i++)
    {
        cubicContour = refittedGlyph.GetContour(i);
        int countourNpts = cubicContour.NumPoints();

        np += countourNpts;
    }

    if (np == 0)
        return CONVERSION_FAIL;

    refitOutline->np = (unsigned short)np;

    refitOutline->endPtsOfContours = (unsigned short *)calloc(refitOutline->nc, sizeof(unsigned short));
    if (NULL == refitOutline->endPtsOfContours)
        return CONVERSION_MEMORY;

    x = refitOutline->x = (float *)calloc(np, sizeof(float));
    if (NULL == x)
    {
        free(refitOutline->endPtsOfContours);
        return CONVERSION_MEMORY;
    }

    y = refitOutline->y = (float *)calloc(np, sizeof(float));
    if (NULL == y)
    {
        free(x);
        free(refitOutline->endPtsOfContours);
        return CONVERSION_MEMORY;
    }

    types = refitOutline->types = (Point_Type *)calloc(np, sizeof(Point_Type));
    if (NULL == types)
    {
        free(y);
        free(x);
        free(refitOutline->endPtsOfContours);
        return CONVERSION_MEMORY;
    }

    unsigned short index = 0;

    for (int i = 0; i < refittedGlyph.NumContours(); i++)
    {
        cubicContour = refittedGlyph.GetContour(i);
        int nPts = cubicContour.NumPoints();

        for (int j = 0; j < nPts; j++)
        {
            ContourPoint point = cubicContour.GetPoint(j);
            x[index] = point.m_Point[0];
            y[index] = point.m_Point[1];
            types[index++] = (Point_Type)point.m_Type;
        }
        refitOutline->endPtsOfContours[i] = index - 1;
    }

    DumpCubic(refittedGlyph);

    return CONVERSION_SUCCESS;
}

Conversion_Error refitQuadratic(Simple_Outline *quadOutline, float tolerance, Simple_Outline *refitOutline)
{
    if ((quadOutline == NULL) || (refitOutline == NULL))
        return CONVERSION_INVALID_PARAM;

    if ((tolerance < 0.001f) || (tolerance > 10.0f))
        return CONVERSION_INVALID_PARAM;

    int np = quadOutline->np;
    float* x = quadOutline->x;
    float* y = quadOutline->y;
    Point_Type* types = quadOutline->types;

    if (np == 0 || x == NULL || y == NULL || types == NULL)
        return CONVERSION_INVALID_PARAM;

    if (quadOutline->designUnits == 0)
        return CONVERSION_INVALID_PARAM;

    // First point must be a moveto
    if (types[0] != MOVE_TO)
        return CONVERSION_INVALID_PARAM;

    QuadGlyph quadGlyph(quadOutline->designUnits);
    QuadContour quadContour;

    for (int i = 0; i < np/*- 2 not expecting phantom pts*/; i++)
    {
        switch (types[i])
        {
        case MOVE_TO:
            if (i != 0)
            {
                if (quadContour.NumPoints() > 0)
                    quadGlyph.AddContour(quadContour);
                quadContour.Clear();
            }
            quadContour.AddPoint(ContourPoint(ContourPoint::MOVE_TO, Vector2f(x[i], y[i])));
            break;
        case LINE_TO:
            quadContour.AddPoint(ContourPoint(ContourPoint::LINE_TO, Vector2f(x[i], y[i])));
            break;
        case ON_CURVE:
            quadContour.AddPoint(ContourPoint(ContourPoint::ON_CURVE, Vector2f(x[i], y[i])));
            break;
        case OFF_CURVE:
            quadContour.AddPoint(ContourPoint(ContourPoint::OFF_CURVE, Vector2f(x[i], y[i])));
            break;
        }
    }

    // Add last contour
    if (quadContour.NumPoints() > 0)
        quadGlyph.AddContour(quadContour);

    DumpQuad(&quadGlyph);

    if (quadGlyph.NumContours() == 0)
        return CONVERSION_SUCCESS;

    // Do the match
    QuadGlyph refittedGlyph(quadOutline->designUnits);

    bool result = quadGlyph.Match(refittedGlyph, tolerance);

    if (!result)
    {
        DumpFail();
        return CONVERSION_FAIL;
    }

    // Fill in the refitted outline from the refitted glyph

    refitOutline->nc = (unsigned short)refittedGlyph.NumContours();
    np = 0;

    for (int i = 0; i < refitOutline->nc; i++)
    {
        quadContour = refittedGlyph.GetContour(i);

        int contourNpts = quadContour.NumPoints();

        if (quadContour.IsClosed())
            contourNpts -= 1;

        np += contourNpts;
    }

    if (np == 0)
        return CONVERSION_FAIL;

    refitOutline->np = (unsigned short)np;

    refitOutline->endPtsOfContours = (unsigned short *)calloc(refitOutline->nc, sizeof(unsigned short));
    if (NULL == refitOutline->endPtsOfContours)
        return CONVERSION_MEMORY;

    x = refitOutline->x = (float *)calloc(np, sizeof(float));
    if (NULL == x)
    {
        free(refitOutline->endPtsOfContours);
        return CONVERSION_MEMORY;
    }

    y = refitOutline->y = (float *)calloc(np, sizeof(float));
    if (NULL == y)
    {
        free(x);
        free(refitOutline->endPtsOfContours);
        return CONVERSION_MEMORY;
    }

    refitOutline->types = (Point_Type *)calloc(np, sizeof(Point_Type));
    if (NULL == refitOutline->types)
    {
        free(y);
        free(x);
        free(refitOutline->endPtsOfContours);
        return CONVERSION_MEMORY;
    }

    unsigned short index = 0;

    for (int i = 0; i < refittedGlyph.NumContours(); i++)
    {
        quadContour = refittedGlyph.GetContour(i);
        int nPts = quadContour.NumPoints();

        if (quadContour.IsClosed())
            nPts -= 1;

        for (int j = 0; j < nPts; j++)
        {
            ContourPoint point = quadContour.GetPoint(j);
            x[index] = point.m_Point[0];
            y[index] = point.m_Point[1];
            refitOutline->types[index++] = (Point_Type)point.m_Type;
        }
        refitOutline->endPtsOfContours[i] = index - 1;
    }

    DumpQuad(&refittedGlyph);

    return CONVERSION_SUCCESS;
}
