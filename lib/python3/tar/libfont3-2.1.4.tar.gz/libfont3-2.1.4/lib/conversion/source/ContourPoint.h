// Copyright (C) 2015 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
/// \file ContourPoint.h

#ifndef CONTOUR_POINT
#define CONTOUR_POINT

#include "Vector2f.h"
#include <stdio.h>

class ContourPoint
{
    public:

        enum PointType {  MOVE_TO = 0, LINE_TO,   ON_CURVE,   OFF_CURVE  };

        /*  CTOR */ ContourPoint    ();
        /*  CTOR */ ContourPoint    (PointType type, const Vector2f& point);

        void        PrintToFile     (FILE* pFile);
        void        Print           ();

        PointType   m_Type;
        Vector2f    m_Point;
        bool        m_IsExtremum;
        bool        m_IsImplicit;
};

#endif



