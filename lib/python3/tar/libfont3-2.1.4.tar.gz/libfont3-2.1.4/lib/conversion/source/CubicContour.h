// Copyright (C) 2015 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
/// \file CubicContour.h

#ifndef CUBIC_CONTOUR_H
#define CUBIC_CONTOUR_H

#include "Contour.h"
class QuadContour;

class CubicContour : public Contour
{
    public:
        /*  CTOR */     CubicContour(int designUnits = DEFAULT_CUBIC_UNITS);

        bool            Match       (QuadContour& quadContour, float tolerance);
        bool            Match       (CubicContour& cubicContour, float tolerance, bool preserveExtrema = false);

    protected:
};

#endif

