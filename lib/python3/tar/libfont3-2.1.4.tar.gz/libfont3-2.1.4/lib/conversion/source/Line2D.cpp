// Copyright (C) 2014 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// Line2D.cpp

#include "Line2D.h"
#include <math.h>
#include "ArrayList.h"
#include "Vector2f.h"

/**
    Constructs a degenerate line segment with start and end at the origin.
*/
Line2D::Line2D()
{
}

Line2D::Line2D(const Line2D& other)
    : m_Start(other.m_Start),
      m_End  (other.m_End)
{
}

/**
    Constructs a line segment using start and end coordinates.
    @param[in]  start  Coordinate of start of line
    @param[in]  end    Coordinate of end of line
*/
Line2D::Line2D(const Vector2& start, const Vector2& end)
    : m_Start(start),
      m_End  (end)
{
}

/**
    Sets the start and end coordinates of the line segment.
    @param[in]  start  Coordinate of start of line
    @param[in]  end    Coordinate of end of line
    */
void Line2D::Set(const Vector2& start, const Vector2& end)
{
    m_Start = start;
    m_End   = end;
}


/**
    Returns the length of the line segment.
    @return Length of the line
*/
double Line2D::Length() const
{
    double length;
    Vector2 lineVec = m_End - m_Start;
    length = lineVec.Length();
    return length;
}

double Line2D::LengthSquared() const
{
    double length;
    Vector2 lineVec = m_End - m_Start;
    length = lineVec.LengthSquared();
    return length;
}

void Line2D::SetStart(const Vector2& start)
{
    m_Start = start;
}

void Line2D::SetEnd(const Vector2& end)
{
    m_End = end;
}

/**
    Extends the line segment by moving the end point a distance equal to the 
    given length.
*/
void Line2D::Extend(double length)
{
    double xDelta = m_End.X() - m_Start.X();
    double yDelta = m_End.Y() - m_Start.Y();

    Vector2 delta(xDelta, yDelta);
    delta.Normalize();
    delta = length * delta;

    m_End   = Vector2(m_End  .X() + delta.X(), m_End  .Y() + delta.Y());
    m_Start = Vector2(m_Start.X() - delta.X(), m_Start.Y() - delta.Y());
}

void Line2D::ExtendStart(double length)
{
    double xDelta = m_End.X() - m_Start.X();
    double yDelta = m_End.Y() - m_Start.Y();

    Vector2 delta(xDelta, yDelta);
    delta.Normalize();
    delta = length * delta;

    m_Start = Vector2(m_Start.X() - delta.X(), m_Start.Y() - delta.Y());
}

/**
    Extends the line segment by moving the end point a distance equal to the 
    length along the line direction. The line segment is twice as long following
    this operation.
*/
void Line2D::ExtendEnd()
{
    double xDelta = m_End.X() - m_Start.X();
    double yDelta = m_End.Y() - m_Start.Y();

    double newX = m_End.X() + xDelta;
    double newY = m_End.Y() + yDelta;

    m_End = Vector2(newX, newY);
}

/**
    Extends the line segment by moving the start point a distance equal to the 
    length along the line direction. The line segment is twice as long following
    this operation.
*/
void Line2D::ExtendStart()
{
    double xDelta = m_End.X() - m_Start.X();
    double yDelta = m_End.Y() - m_Start.Y();

    double newX = m_Start.X() - xDelta;
    double newY = m_Start.Y() - yDelta;

    m_Start = Vector2(newX, newY);
}

/**
    Returns the distance between a point and the line segment.
    The distance is measured along the normal to the line segment.
    @param[in]  point  Point whose distance is being determined.
    @return Distance from point to the line segment.

*/
double Line2D::PointDistance(const Vector2& point)
{
    // Distance is projection of the vector from
    // the point to start onto the normal vector.

    // Get normal vector.
    double xDelta = m_End.X() - m_Start.X();
    double yDelta = m_End.Y() - m_Start.Y();

    Vector2 normal(yDelta, -xDelta);
    normal.Normalize();

    // Calculate vector from point to m_Start.
    double x = m_Start.X() - point.X();
    double y = m_Start.Y() - point.Y();

    Vector2 toStart(x, y);

    // Now project toStart onto normal.
    double distance = DotProduct(normal, toStart);

    return fabs(distance);
}

Vector2f Line2D::ReflectPoint(const Vector2f& point) const
{
    Vector2f reflectedPoint;

    Vector2f lineVector = m_End - m_Start;

    lineVector.Normalize();

    Vector2f startToPoint = point - m_Start;

    float scalarProjection = DotProduct(startToPoint, lineVector);

    Vector2f startToIntersection = scalarProjection * lineVector;

    Vector2f pointToIntersection = startToIntersection - startToPoint;

    reflectedPoint = point + 2 * pointToIntersection;

    return reflectedPoint;
}

Line2D Line2D::Normal()
{
    double xDelta = m_End[0] - m_Start[0];
    double yDelta = m_End[1] - m_Start[1];

    // Calc the unit normal vector.
    Vector2 normal(-yDelta, xDelta);

    // Extend normal both ways.
    Vector2 midPoint = Interpolate(0.5f);

    return Line2D(midPoint + normal, midPoint - normal);
}

/**
    Returns the point on the line containing the line segment that is interpolated 
    by factor t from the start. 
    If t >= 0.0 or t <= 1.0, then the point lies on the line segment. 
    If t < 0.0 or t > 1.0, then the interpolated point lies outside the 
    line segment on the line containing the line segment.
    @param[in]  t  Interpolation factor
    @return Interpolated point from the start of the line segment.
*/
Vector2 Line2D::Interpolate(float t)
{
    double x = m_Start.X() + (m_End.X() - m_Start.X()) * t;
    double y = m_Start.Y() + (m_End.Y() - m_Start.Y()) * t;

    return Vector2(x, y);
}

/**
    Returns the parameter Tau computed for the current line segment and
    another line segment. Tau is defined as the ratio of the length of path
    formed by the two line segments to the length of the chord (distance between the ends).
    Tau is a measure of how curved the path containing the two line segments is.
    The two line segments should share a vertex for this measure to be meaningfull.
    @param[in]  other  Second line segment.
    @return Tau parameter.
*/
double  Line2D::Tau(const Line2D& other) const
{
    // Define Tau to be ratio of length of curve to the chord (distance between the ends).
    // First check that the two lines share a vertex.
    double tau = 1.0;
    Line2D chordLine(m_Start, other.m_End);
    double chord = chordLine.Length();
    double curveLength = Length() + other.Length();

    if (chord != 0.0)
    {
        tau = curveLength / chord;
    }
    return tau;
}

/**
    Returns the intersection point between two line segments. The intersection point
    may lie outside one or both line segments but will lie on the lines containing the 
    two line segments.
    @param[in]  other  Second line segment.
    @return Intersection point.
*/
Vector2 Line2D::Intersects(Line2D& other)
{
    double m1;
    double m2;
    double c1;
    double c2;

    double startX = m_Start.X();
    double startY = m_Start.Y();
    double endX   = m_End.X();
    double endY   = m_End.Y();
    double otherStartX = other.m_Start.X();
    double otherStartY = other.m_Start.Y();
    double otherEndX   = other.m_End.X();
    double otherEndY   = other.m_End.Y();

    double deltaX = endX - startX;
    double deltaY = endY - startY;
    double otherDeltaX = otherEndX - otherStartX;
    double otherDeltaY = otherEndY - otherStartY;
    double x;
    double y;


    // If both are horizontal or both vertical.
    // Check for colinear and pick joining end.
    if (    ((deltaX == 0.0) && (otherDeltaX == 0.0)) ||
            ((deltaY == 0.0f) && (otherDeltaY == 0.0f)) )
    {
        if (    (m_End == other.m_Start) ||
                (m_End == other.m_End))
        {
            return m_End;
        }
        else if ((m_Start == other.m_Start) ||
                 (m_Start == other.m_End))
        {
            return m_Start;
        }
    }

    // Both vertical.
    if ((deltaX == 0.0) && (otherDeltaX == 0.0))
    {
        ArrayList<double> list;
        list.Add(otherEndY);
        list.Add(startY);
        list.Add(endY);
        list.Add(otherStartY);
        list.Sort();
        
        return Vector2(startX, list[1] + ((list[2] - list[1]) / 2.0));
    }

    // Both horizontal.
    if ((deltaY == 0.0f) && (otherDeltaY == 0.0f))
    {
        ArrayList<double> list;
        list.Add(otherEndX);
        list.Add(startX);
        list.Add(endX);
        list.Add(otherStartX);
        list.Sort();
        
        return Vector2(list[1] + ((list[2] - list[1]) / 2.0), startY);
    }


    if (deltaX == 0.0)
    {
        // Solve other line at x = endX;
        m2 = otherDeltaY / otherDeltaX;     //lint !e414  by inspection this cannot be 0
        c2 = otherStartY - (m2 * otherStartX);

        x = endX;
        y = m2 * x + c2;

        return Vector2(x, y);
    }

    if (deltaY == 0.0)
    {
        // This is horizontal other is vertical.
        if (otherDeltaX == 0.0)
        {
            x = otherEndX;
            y = endY;

            return Vector2(x, y);
        }
        else // Solve other line at y = endY;
        {
            m2 = otherDeltaY / otherDeltaX;
            c2 = otherStartY - (m2 * otherStartX);
            y = endY;
            x = (y - c2) / m2;      //lint !e414 (division by zero) - otherDeltaY cannot be zero, since deltaY and otherDeltaY both zero is handled above, and otherDeltaX=0 is checked @222

            return Vector2(x, y);
        }
    }

    if (otherDeltaX == 0.0f)
    {
        // Solve this line at x = otherEndX;
        m1 = deltaY / deltaX;
        c1 = startY - (m1 * startX);
        x = otherEndX;
        y = m1 * x + c1;

        return Vector2(x, y);
    }

    if (otherDeltaY == 0.0f)
    {
        m1 = deltaY / deltaX;
        c1 = startY - (m1 * startX);
        y = otherEndY;
        x = (y - c1) / m1;

        return Vector2(x, y);
    }

    m1 = deltaY / deltaX;
    c1 = startY - (m1 * startX);

    m2 = otherDeltaY / otherDeltaX;
    c2 = otherStartY - (m2 * otherStartX);

    // If the slopes are the same, i.e. paralel or co-linear
    // We're going to assume co-linear.
    if ((m2 - m1) == 0.0f)
    {
        if (    (m_End == other.m_Start) ||
                (m_End == other.m_End))
        {
            return m_End;
        }
        else if ((m_Start == other.m_Start) ||
                 (m_Start == other.m_End))
        {
            return m_Start;
        }
    }

    // Finaly the general case:
    x = -(c2 - c1) / (m2 - m1);
    y = ((c1 * m2) - (c2 * m1)) / (m2 - m1);

    return Vector2(x, y);
}

/**
    Determines if two line segments intersect.
    @return @b true if segments intersect.
*/
bool Line2D::SegsIntersect(const Line2D& other) const
{
    double deltaX = m_End.X() - m_Start.X();
    double deltaY = m_End.Y() - m_Start.Y();
    double otherDeltaX = other.m_End.X() - other.m_Start.X();
    double otherDeltaY = other.m_End.Y() - other.m_Start.Y();

    double divisor = (-otherDeltaX * deltaY + deltaX * otherDeltaY);

    if (divisor != 0.0)
    {
        double oneOverDivisor = 1.0 / divisor;

        double u = (-deltaY * (m_Start.X() - other.m_Start.X()) + deltaX * (m_Start.Y() - other.m_Start.Y())) * oneOverDivisor;

        if ((u < 0) || (u > 1)) return false;

        double v = ( otherDeltaX * (m_Start.Y() - other.m_Start.Y()) - otherDeltaY * (m_Start.X() - other.m_Start.X())) * oneOverDivisor;

        if ((v < 0) || (v > 1)) return false;

        return true;
    }
    else
    {
        // could be overlapping horizontal lines
        if ((deltaY == 0.0) && (otherDeltaY == 0.0) && (m_Start.Y() == other.m_Start.Y()))
        {
            if (m_Start.X() < m_End.X())
            {
                if (((other.m_Start.X() > m_Start.X()) && (other.m_Start.X() < m_End.X())) ||
                    ((other.m_End.X()   > m_Start.X()) && (other.m_End.X()   < m_End.X())))
                    return true;
            }
            else
            {
                if (((other.m_Start.X() > m_End.X()) && (other.m_Start.X() < m_Start.X())) ||
                    ((other.m_End.X()   > m_End.X()) && (other.m_End.X()   < m_Start.X())))
                    return true;
            }
        }
        // could be overlapping vertical lines
        else if ((deltaX == 0.0) && (otherDeltaX == 0.0) && (m_Start.X() == other.m_Start.X()))
        {
            if (m_Start.Y() < m_End.Y())
            {
                if (((other.m_Start.Y() > m_Start.Y()) && (other.m_Start.Y() < m_End.Y())) ||
                    ((other.m_End.Y()   > m_Start.Y()) && (other.m_End.Y()   < m_End.Y())))
                    return true;
            }
            else
            {
                if (((other.m_Start.Y() > m_End.Y()) && (other.m_Start.Y() < m_Start.Y())) ||
                    ((other.m_End.Y()   > m_End.Y()) && (other.m_End.Y()   < m_Start.Y())))
                    return true;
            }
        }
    }

    return false;
}

/**
    Returns the start of the line segment.
    @return Start point.
*/
Vector2 Line2D::Start()const 
{
    return m_Start;
}

/**
    Returns the end of the line segment.
    @return End point.
*/
Vector2 Line2D::End()const
{
    return m_End;
}

/**
    Returns the intersection point between a Circle and the line segment. The intersection point
    may not exist. The return value indicates whether the intersection exists. The return point
    is only modified if the intersection exists.
    @param[in]  circle  Circle.
    @param[out] out     Intersection point.
    @return @b true if intersection point exists.
*/
bool Line2D::Intersects(Circle circle, Vector2 &out)
{
    bool intersects = false;

    Vector2 center = circle.Center();
    double  radius2 = circle.RadiusSquared();
    
    if (circle.Intersects(*this))
    {
        double x;
        double y;

        intersects = true;

        double deltaX = m_End.X() - m_Start.X();
        // Test for delta x of zero.
        if (deltaX == 0.0) 
        {
            // We know x so solve circle at x.
            x = m_End.X();
            double root = sqrt(radius2 - (x - center.X()) * (x - center.X()));  //lint !e864
            y = center.Y() + root;

            // Check we got the correct root.
            if ((y < m_Start.Y()) || (y > m_End.Y()))
            {
                y = center.Y() - root;
            }
            out = Vector2(x, y);
            return intersects;
        }
       
        // Plug equation of line into equation of circle.
        // Solve resultant quadratic.
        double M = (m_End.Y() - m_Start.Y()) / deltaX;
        double B = m_Start.Y() - M * m_Start.X();
        double a = 1.0 + M * M;
        double b = 2.0 * (M * B - M * center.Y() - center.X());   //lint !e864
        double c = center.X() * center.X() + B * B + center.Y() * center.Y() - radius2 - 2.0 * B * center.Y();       //lint !e864

        double root = sqrt(b * b - 4 * a * c);

        x = ((-b) + root) / (2.0 * a);

        // Check we got the correct root.
        if ((x < m_Start.X()) || (x > m_End.X()))
        {
            x = ((-b) - root) / (2.0 * a);
        }

        y = M * x + B;

        out = Vector2(x, y);
    }

    return intersects && out.IsValid();
}

/**
    Indicates whether the start and end points are valid points.
    See Vector2::IsValid().
    @return @b true start and end points are valid.
*/
bool Line2D::IsValid() const
{
    bool valid = false;

    if (    m_Start.IsValid() &&
            m_End.IsValid() )
    {
        valid = true;
    }
    return valid;
}

