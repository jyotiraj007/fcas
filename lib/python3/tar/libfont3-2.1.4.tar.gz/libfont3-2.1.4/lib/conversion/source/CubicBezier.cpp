// Copyright (C) 2014 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// CubicBezier.cpp

#include "CubicBezier.h"
#include "Line2D.h"
#include "MathUtilities.h"
#include "Stack.h"


CubicBezier::CubicBezier()
:   m_NumSegments(0)
{
}

CubicBezier::CubicBezier(const Vector2f& startPoint, const Vector2f& endPoint, const Vector2f& controlPoint1, const Vector2f& controlPoint2, int numSegments /* = 10 */)
{
    Init(startPoint, endPoint, controlPoint1, controlPoint2, numSegments);
}

CubicBezier::CubicBezier(const CubicPoints& cubicPoints)
{
    Init(cubicPoints.m_Start, cubicPoints.m_End, cubicPoints.m_Control1, cubicPoints.m_Control2);
}

void CubicBezier::GetPoints(CubicPoints& points)
{
    points.m_Start    = m_Control[eSTART];
    points.m_End      = m_Control[eEND];
    points.m_Control1 = m_Control[eCONTROL1];
    points.m_Control2 = m_Control[eCONTROL2];
}

void CubicBezier::SetPoints(const CubicPoints& points)
{
    Init(points.m_Start, points.m_End, points.m_Control1, points.m_Control2);
}

void CubicBezier::Init(const Vector2f& startPoint, const Vector2f& endPoint, const Vector2f& controlPoint1, const Vector2f& controlPoint2, int numSegments /* = 10 */)
{
    m_Control[eSTART]    = startPoint;
    m_Control[eEND]      = endPoint;
    m_Control[eCONTROL1] = controlPoint1;
    m_Control[eCONTROL2] = controlPoint2;

    m_NumSegments = numSegments;

    Evaluate();
}

void CubicBezier::CreateSegments(float flatness)
{
    m_CurrentFlatness = flatness;
    Vector2f left;
    Vector2f right;
    Vector2f middle;

    Vector2f middleLeft;
    Vector2f middleRight;
    Vector2f middleMiddle;

    float len1;
    float len2;
    Vector2f distance1;
    Vector2f distance2;

    Stack<CubicPoints> stack;

    //m_Points.Clear();
    m_Points.ResetIndex();

    m_Points.Add(m_Control[eSTART]);
    m_NumSegments = 0;

    CubicPoints points;

    points.Set(m_Control[eSTART], m_Control[eEND], m_Control[eCONTROL1], m_Control[eCONTROL2]);

    stack.Push(points);

    while (false == stack.IsEmpty())
    {
        points = stack.Pop();

        // Find the mid curve point of these controls:
        left   = 0.5f * (points.m_Start    + points.m_Control1);
        right  = 0.5f * (points.m_End      + points.m_Control2);
        middle = 0.5f * (points.m_Control1 + points.m_Control2);

        middleLeft   = 0.5f * (left + middle);
        middleRight  = 0.5f * (right + middle);
        middleMiddle = 0.5f * (middleLeft + middleRight);

        // Evaluate their flatness:
        distance1 = middleLeft  - points.m_Control1;
        distance2 = middleRight - points.m_Control2;

        len1 = distance1.LengthSquared();
        len2 = distance2.LengthSquared();

        if (len1 < flatness && len2 < flatness)
        {
            m_Points.Add(middleMiddle);
        }
        else
        {
            CubicPoints cubicLeft(middleMiddle, points.m_End, middleRight, right);
            CubicPoints cubicRight(points.m_Start, middleMiddle, left, middleLeft);

            // Split in two and keep going:
            stack.Push(cubicLeft);
            stack.Push(cubicRight);
        }
    }
    m_Points.Add(m_Control[eEND]);
    m_NumSegments = m_Points.NumElements() - 1;
}

void CubicBezier::Evaluate(float flatness)
{
    if (ManhattenDistance(m_Control[eCONTROL1], m_Control[eSTART]) <= 2.0f)
    {
        m_Control[eCONTROL1] =  m_Control[eSTART];
    }

    if (ManhattenDistance(m_Control[eCONTROL2], m_Control[eEND]) <= 2.0f)
    {
        m_Control[eCONTROL2] =  m_Control[eEND];
    }

    CreateSegments(flatness);
    CreateNormals();
}


Vector2f CubicBezier::CalculatePoint(float t)
{
    Vector2f a = Interpolate(m_Control[eSTART],    m_Control[eCONTROL1], t);
    Vector2f b = Interpolate(m_Control[eCONTROL1], m_Control[eCONTROL2], t);
    Vector2f c = Interpolate(m_Control[eCONTROL2], m_Control[eEND],      t);

    Vector2f d = Interpolate(a, b, t);
    Vector2f e = Interpolate(b, c, t);

    Vector2f f = Interpolate(d, e, t);

    return f;
}



void CubicBezier::GetCenterSegment(Line2D& segment, float flatness)
{
    m_CurrentFlatness = flatness;

    Vector2f start      = m_Control[eSTART];
    Vector2f control1   = m_Control[eCONTROL1];
    Vector2f control2   = m_Control[eCONTROL2];
    Vector2f end        = m_Control[eEND];

    Vector2f left;
    Vector2f right;
    Vector2f middle;

    Vector2f middleLeft;
    Vector2f middleRight;
    Vector2f middleMiddle;

    left   = 0.5f * (start    + control1);
    right  = 0.5f * (end      + control2);
    middle = 0.5f * (control1 + control2);

    middleLeft   = 0.5f * (left + middle);
    middleRight  = 0.5f * (right + middle);
    middleMiddle = 0.5f * (middleLeft + middleRight);

    CubicPoints leftPoints  (start, middleMiddle, left, middleLeft);
    CubicPoints rightPoints (middleMiddle, end, middleRight, right);

    float len1;
    float len2;
    Vector2f distance1;
    Vector2f distance2;

    m_Points.Add(m_Control[eSTART]);
    m_NumSegments = 0;

    // Do left first.
    Vector2f segmentLeft;

    start    = leftPoints.m_Start;
    control1 = leftPoints.m_Control1;
    control2 = leftPoints.m_Control2;
    end      = leftPoints.m_End;

    int count = 20; // Avoid infinite loop.

    while (count--)
    {
        // Find the mid curve point of these controls:
        left   = 0.5f * (start    + control1);
        right  = 0.5f * (end      + control2);
        middle = 0.5f * (control1 + control2);

        middleLeft   = 0.5f * (left + middle);
        middleRight  = 0.5f * (right + middle);
        middleMiddle = 0.5f * (middleLeft + middleRight);

        // Evaluate their flatness:
        distance1 = middleLeft  - control1;
        distance2 = middleRight - control2;

        len1 = distance1.LengthSquared();
        len2 = distance2.LengthSquared();

        if (len1 < flatness && len2 < flatness)
        {
            segmentLeft = middleMiddle;
            break;
        }
        else
        {
            start    = middleMiddle;
            control1 = middleRight;
            control2 = right;
        }
    }

    // Now do right.
    Vector2f segmentRight;
    start    = rightPoints.m_Start;
    control1 = rightPoints.m_Control1;
    control2 = rightPoints.m_Control2;
    end      = rightPoints.m_End;

    count = 20; // Avoid infinite loop.

    while (count--)
    {
        // Find the mid curve point of these controls:
        left   = 0.5f * (start    + control1);
        right  = 0.5f * (end      + control2);
        middle = 0.5f * (control1 + control2);

        middleLeft   = 0.5f * (left + middle);
        middleRight  = 0.5f * (right + middle);
        middleMiddle = 0.5f * (middleLeft + middleRight);

        // Evaluate their flatness:
        distance1 = middleLeft  - control1;
        distance2 = middleRight - control2;

        len1 = distance1.LengthSquared();
        len2 = distance2.LengthSquared();

        if (len1 < flatness && len2 < flatness)
        {
            segmentRight = middleMiddle;
            break;
        }
        else
        {
            control1 = left;
            control2 = middleLeft;
            end      = middleMiddle;
        }
    }
    
    segment.SetStart(segmentLeft);
    segment.SetEnd(segmentRight);
}


bool CubicBezier::Search(QuadContour& quadContour)
{
    m_Depth++;
    bool success = true;

    m_BestBeziers.Clear();
    m_BestAverage = FLOAT_MAX;

    m_EvalStack.Reset();
    Line2D startTangent = m_StartTangent;
    Line2D startTarget = startTangent;

    m_CheckDepth = 0;

    CheckRight(startTangent, startTarget, 0, m_Points.NumElements() - 1);

    int numBeziers = m_BestBeziers.NumElements();

    if (numBeziers > 0)
    {
        int i;
        // Emit the beziers to our contour.
        // All beziers have implicit on curve points, so just add controls.
        for (i = 0; i < numBeziers; i++)
        {
            QuadBezier& bezier = m_BestBeziers[i];
            ContourPoint point(ContourPoint::OFF_CURVE, bezier.GetPoint(QuadBezier::eCONTROL));
            quadContour.AddPoint(point, true);
        }

        // Add last on curve point of beziers.
        ContourPoint lastPoint(ContourPoint::ON_CURVE, m_BestBeziers[i-1].GetPoint(QuadBezier::eEND));
        quadContour.AddPoint(lastPoint, true);
    }

    if (numBeziers == 0)
    {
        // If we didn't find a solution, recurse after a tighter evaluation of this cubic.
        Evaluate(m_CurrentFlatness / 10);

        // Limit by both recursion depth and number of elements so we don't take too long.
        // If we return false, Match will split the cubic which usually has better results.
        if ((m_Points.NumElements() < 60) && (m_Depth < 5))
        {
            success = Search(quadContour);
        }
        else
        {
            success = false;
        }
    }

    return success;
}

bool CubicBezier::CheckRight(Line2D& startTangent, Line2D& startTarget, int startIndex, int endIndex)
{
    m_CheckDepth++;

    bool foundSolution = false;

    if (m_CheckDepth < 15000)
    {

        int currentIndex = FindFirst(startTangent, startIndex, endIndex);

        bool intersectsStartTarget  = true;

        while ((false == foundSolution) && (currentIndex > startIndex) && (currentIndex < endIndex) && intersectsStartTarget)
        {
            Line2D currentTangent(m_AllTangents[currentIndex]);

            intersectsStartTarget = currentTangent.SegsIntersect(startTarget);

            // Find intersection with current startTarget:
            Vector2f startIntersection(currentTangent.Intersects(startTarget));

            currentTangent.Set(startIntersection, m_Points[currentIndex + 1]);
            currentTangent.ExtendEnd(); // Double in length.

            Line2D currentTarget(startIntersection, m_Points[currentIndex]);
            currentTarget.ExtendEnd();   // Double the length.
            // CurrentTarget is the overlap 
            currentTarget.Set(currentTarget.End(), currentTangent.End());

            m_EvalStack.Push(currentTangent);

            if (currentTarget.SegsIntersect(m_EndTangent))
            {
                foundSolution = Score();
            }
            else
            {
                foundSolution = CheckRight(currentTangent, currentTarget, currentIndex+2, endIndex);
            }

            m_EvalStack.Pop();

            --currentIndex;
        }
    }
    return foundSolution;
}




bool CubicBezier::Score()
{
    int numTangents = m_EvalStack.NumElements();

    m_Tangents.ResetIndex();

    m_Tangents.Add(m_StartTangent);

    for (int i = 0; i < numTangents; i++)
    {
        Line2D currentTangent = m_EvalStack.ElementAt(i);
        currentTangent.Extend(10000.0f);
        m_Tangents.Add(currentTangent);
    }

    m_Tangents.Add(m_EndTangent);

    m_Intersections.ResetIndex();

    for (int i = 0; i < m_Tangents.NumElements()-1; i++)
    {
        Line2D& one = m_Tangents[i];
        Line2D& two = m_Tangents[i+1];

        if (false == one.SegsIntersect(two))
        {
            return false;
        }

        Vector2f intersection = one.Intersects(two);
        m_Intersections.Add(intersection);
    }

    m_ControlPoints.ResetIndex();

    m_ControlPoints.Add(m_Control[eSTART]);

    for (int i = 0; i < m_Intersections.NumElements()-1; i++)
    {
        Vector2f rounded1 = m_Intersections[i].Rounded();
        Vector2f rounded2 = m_Intersections[i+1].Rounded();

        Vector2f midPoint = Interpolate(rounded1, rounded2, 0.5f);
        m_ControlPoints.Add(rounded1);
        m_ControlPoints.Add(midPoint);
    }

    m_ControlPoints.Add(m_Intersections[m_Intersections.NumElements()-1].Rounded());
    m_ControlPoints.Add(m_Control[eEND]);

    float averageDistance = 0.0f;
    m_Beziers.ResetIndex();

    for (int i = 0; i < m_ControlPoints.NumElements()-2; i+=2)
    {
        QuadBezier bezier;

        bezier.SetPoints(m_ControlPoints[i], m_ControlPoints[i+2], m_ControlPoints[i+1]);

        m_Beziers.Add(bezier);
    }

    for (int i = 0; i < m_Beziers.NumElements(); i++)
    {
        QuadBezier& bezier = m_Beziers[i];
        bezier.Evaluate();

        float distance;

        if (WithinTolerance(bezier, distance))
        {
            averageDistance += distance;
        }
        else
        {
            return false;
        }
    }

    averageDistance /= (numTangents + 1);

    if (averageDistance < m_BestAverage)
    {
        m_BestAverage = averageDistance;

        m_BestBeziers = m_Beziers;

        m_FoundMatch = true;
    }

    return true;
}

// returns index of allTangent.
int CubicBezier::FindFirst(Line2D& startTangent, int startIndex, int endIndex)
{
    int currentIndex = startIndex;
    bool intersects = false;

    // First remove any non intersecting segs, usually parallel with tangent.
    while (intersects == false && currentIndex < endIndex)
    {
        Line2D currentLine = m_AllTangents[currentIndex];
        intersects = currentLine.SegsIntersect(startTangent);
        currentIndex++;
    }

    // Now find furthest intersecting tangent.
    while (intersects && currentIndex < endIndex)
    {
        Line2D currentLine = m_AllTangents[currentIndex];
        intersects = currentLine.SegsIntersect(startTangent);
        currentIndex++;
    }

    currentIndex -= 2;

    if (currentIndex < startIndex)
    {
        currentIndex = startIndex + 1;
    }

    return currentIndex;
}




bool CubicBezier::Match(QuadContour& quadContour, float tolerance)
{
    m_Depth = 0;
    m_Tolerance = tolerance;

    // Check if all points are the same. 
    if ((m_Control[eCONTROL1] == m_Control[eSTART]) &&
        (m_Control[eCONTROL2] == m_Control[eSTART]) &&
        (m_Control[eEND]      == m_Control[eSTART]))
    {
        // Nothing to do. Strip out the redundant points.
        return true;
    }

    m_StartTangent = Line2D(m_Control[eCONTROL1], m_Control[eSTART]);
    m_EndTangent   = Line2D(m_Control[eCONTROL2], m_Control[eEND]);

    // Check if start tangent has zero length.
    if (m_Control[eCONTROL1] == m_Control[eSTART])
    {
        m_StartTangent = Line2D(m_Points[1], m_Control[eSTART]);
    }
    // Check if end tangent has zero length.
    if (m_Control[eCONTROL2] ==  m_Control[eEND])
    {
        m_EndTangent = Line2D(m_Points[m_Points.NumElements() - 2], m_Control[eEND]);
    }

    // Check for linear cubic by comparing to line from start to end.
    if (IsLinear(m_Tolerance))
    {
        ContourPoint lineEnd(ContourPoint::LINE_TO, m_Control[eEND]);
        quadContour.AddPoint(lineEnd, true);
        return true;
    }

    m_StartTangent.ExtendStart(10000.0);
    m_EndTangent.ExtendStart(10000.0);


    if (m_Control[eSTART] != m_Control[eEND])
    {
        // Try for single quad: got lucky or very small.
        if (m_StartTangent.SegsIntersect(m_EndTangent))
        {
            float distance;
            QuadBezier startBezier;
            Vector2f midPoint = m_StartTangent.Intersects(m_EndTangent);
            midPoint = midPoint.Rounded();

            startBezier.SetPoints(m_Control[eSTART], m_Control[eEND], midPoint);

            startBezier.Evaluate();

            if (WithinTolerance(startBezier, distance))
            {
                ContourPoint controlPoint(ContourPoint::OFF_CURVE, midPoint);
                ContourPoint endPoint(ContourPoint::ON_CURVE, m_Control[eEND]);
                quadContour.AddPoint(controlPoint, true);
                quadContour.AddPoint(endPoint, true);
                return true;
            }
        }
    }

    bool success = Search(quadContour);

    if (false == success)
    {
        CubicPoints points1;
        CubicPoints points2;
        SplitAt(0.5f, points1, points2);

        CubicBezier one(points1);
        CubicBezier two(points2);

        one.Evaluate();
        two.Evaluate();

        success = one.Match(quadContour, tolerance);
        success &= two.Match(quadContour, tolerance);

        if (false == success)
        {
            PrintControlPoints();
        }
    }

    return success;
}


void CubicBezier::PrintControlPoints()
{
#ifdef _DEBUG

    m_Control[eSTART]   .Print();
    m_Control[eEND]     .Print();
    m_Control[eCONTROL1].Print();
    m_Control[eCONTROL2].Print();
    printf("\n");

#endif
}

void CubicBezier::SplitAt(float t, CubicPoints& one, CubicPoints& two)
{
    Vector2f a = Interpolate(m_Control[eSTART],    m_Control[eCONTROL1], t);
    Vector2f b = Interpolate(m_Control[eCONTROL1], m_Control[eCONTROL2], t);
    Vector2f c = Interpolate(m_Control[eCONTROL2], m_Control[eEND],      t);

    Vector2f d = Interpolate(a, b, t);
    Vector2f e = Interpolate(b, c, t);

    Vector2f f = Interpolate(d, e, t);

    one.m_Start    = m_Control[eSTART];
    one.m_Control1 = a.Rounded();
    one.m_Control2 = d.Rounded();
    one.m_End      = f.Rounded();

    two.m_Start    = f.Rounded();
    two.m_Control1 = e.Rounded();
    two.m_Control2 = c.Rounded();
    two.m_End      = m_Control[eEND];
}


void CubicBezier::CreateNormals()
{
    m_NormalLines.Clear();
    m_MidPoints.Clear();

    int numSegments = m_Points.NumElements() - 1;

    for (int i = 0; i < numSegments; i++)
    {
        Line2D currentSegment(m_Points[i], m_Points[i+1]);
        // Create the normal to the segment:

        double xDelta = m_Points[i+1][0] - m_Points[i][0];
        double yDelta = m_Points[i+1][1] - m_Points[i][1];

        // Calc the unit normal vector.
        Vector2 normal(-yDelta, xDelta);
        normal.Normalize();
        normal = 4096.0 * normal;

        // Extend normal both ways.
        Vector2 midPoint = currentSegment.Interpolate(0.5f);
        Line2D normalLine(midPoint + normal, midPoint - normal);
        
        m_NormalLines.Add(normalLine);
        m_MidPoints.Add(midPoint);
    }

    m_AllTangents.Clear();

    for (int i = 0; i < m_Points.NumElements()-1; i++)
    {
        Line2D line(m_Points[i], m_Points[i+1]);
        line.Extend(10000.0f);
        m_AllTangents.Add(line);
    }
}


bool CubicBezier::WithinTolerance(QuadBezier& quad, float& distance)
{
    bool intersection;

    distance = (float)SplineDistance(quad, intersection, 0, m_Points.NumElements() - 1);

    if (distance < m_Tolerance)
    {
        return true;
    }
    else
    {
        return false;
    }
}

double CubicBezier::SplineDistance(QuadBezier& quad, bool& anyIntersections, int startIndex, int stopIndex)
{
    int numSegments = quad.m_Points.NumElements() - 1;

    double largestDistance = 0.0f;
    anyIntersections = false;

    int numIntersections = 0;
    int largestIntesected = startIndex;


    for (int i = 0; i < numSegments; i++)
    {
        double distance = FLOAT_MAX;
        bool   foundIntersection = false;

        Line2D segment(quad.m_Points[i], quad.m_Points[i+1]);

        // Look for intersection with segment.
        for (int j = largestIntesected; j < stopIndex; j++)
        {
            if (m_NormalLines[j].SegsIntersect(segment))
            {
                numIntersections++;
                anyIntersections = true;
                foundIntersection = true;

                largestIntesected = j;

                double currentDistance = segment.PointDistance(m_MidPoints[j]);

                // Get the smallest intersection.
                if (currentDistance < distance)
                {
                    distance = currentDistance;
                    if (distance < m_Tolerance)
                    {
                        break;
                    }
                }
            }
        }

        if (foundIntersection) // Avoid adding FLOAT_MAX if no intersection.
        {
            if (distance > largestDistance)
            {
                largestDistance = distance;

                if (largestDistance > m_Tolerance)
                {
                    return largestDistance;
                }
            }
        }
    }

    // Reject degenerate quads with low hit rate.
    float percentMatch = (float)numIntersections / (float)numSegments;

    if (percentMatch < 0.02f)
    {
        largestDistance = FLOAT_MAX;
    }

    return largestDistance;
}

bool CubicBezier::IsLinear(float tolerance)
{
    if (m_Control[eSTART] == m_Control[eEND])
    {
        return false;
    }

    Line2D line(m_Control[eSTART], m_Control[eEND]);

    // Look for intersection with segment.
    for (int j = 0; j < m_NormalLines.NumElements(); j++)
    {
        if (m_NormalLines[j].SegsIntersect(line))
        {
            double currentDistance = line.PointDistance(m_MidPoints[j]);

            if (currentDistance > tolerance)
            {
                return false;
            }
        }
    }

    return true;
}

 
int CubicBezier::NumSegments()
{
    return m_NumSegments;
}

void CubicBezier::SetPoint(Control control, const Vector2f& point)
{
    m_Control[control] = point;
}

Vector2f CubicBezier::GetPoint(Control control)
{
    return m_Control[control];
}


