// Copyright (C) 2015 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
/// \file CompositQuadBezier.h

#ifndef COMPOSIT_QUAD_BEZIER_H
#define COMPOSIT_QUAD_BEZIER_H

#include "Vector2f.h"
#include "CubicContour.h"
#include "QuadBezier.h"
#include "QuadPoints.h"
#include "Line2D.h"
#include "Stack.h"

class CubicBezier;

class CompositQuadBezier : public QuadBezier
{
    public:
        /* CTOR */  CompositQuadBezier   ();
        void        AddQuad              (QuadPoints& points);

        void        Evaluate             (float flatness = 0.5f);

        void        Clear                ();
        int         NumComponents        ();

        bool        Match               (CubicContour& contour, float tolerance);
        bool        Match               (QuadContour& quadContour, float tolerance);

    protected:

        void        CreateNormals       ();
        void        CreateTangents      ();
        void        CreateSegments      (float flatness = 0.5f);
        bool        WithinTolerance     (QuadBezier& quad, float& distance);
        double      SplineDistance      (QuadBezier& quad, bool& anyIntersections, int startIndex, int stopIndex);
        bool        Search              (QuadContour& quadContour);
        bool        CheckRight          (Line2D& startTangent, Line2D& startTarget, int startIndex, int endIndex);
        int         FindFirst           (Line2D& startTangent, int startIndex, int endIndex);
        bool        Score               ();



        double      SplineDistance      (CubicBezier& cubic);

        double      CheckIndex          (CubicBezier& cubic, int index);
        double      MiddleDistance      (CubicBezier& cubic);

        bool        IsLinear            (float tolerance);


        ArrayList<QuadPoints>   m_QuadPoints;

        ArrayList<Line2D>       m_NormalLines; // Normals to the segments;
        ArrayList<Vector2f>     m_MidPoints;

        Line2D                  m_StartTangent;
        Line2D                  m_EndTangent;

        float                   m_Tolerance;
        int                     m_Depth;
        ArrayList<QuadBezier>   m_BestBeziers;
        float                   m_BestAverage;
        Stack<Line2D>           m_EvalStack;
        int                     m_CheckDepth;
        float                   m_CurrentFlatness;
        ArrayList<Line2D>       m_AllTangents;
        ArrayList<Line2D>       m_Tangents;
        ArrayList<Vector2f>     m_Intersections;
        ArrayList<Vector2f>     m_ControlPoints;
        ArrayList<QuadBezier>   m_Beziers;
        bool                    m_FoundMatch;

        int m_MidPoint;
};

#endif
