// Copyright (C) 2014 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// Vector2.cpp

//lint -sem(Vector2::Set,initializer)

#include "Vector2.h"
#include "Vector2f.h"
#include "MathUtilities.h"
#include <math.h>


/**
    Constructs Vector2 and initializes coordinates to (0.0,0.0).
*/
Vector2::Vector2()
{
   Set(0.0, 0.0);
}

/**
    Copy constructor.
*/
Vector2::Vector2(const Vector2& other)
{
    m_Vector[0]  = other.m_Vector[0];
    m_Vector[1]  = other.m_Vector[1];
}

/**
    Copy constructor.
*/
Vector2::Vector2(const Vector2f& other)
{
    m_Vector[0]  = (double)other[0];
    m_Vector[1]  = (double)other[1];
}

/**
    Constructs Vector2 using coordinates.
    @param[in]     x   First coordinate
    @param[in]     y   Second coordinate.
*/
Vector2::Vector2(double x, double y)
{
    Set(x, y);
}

/**
    Sets vector coordinates.
    @param[in]     x   First coordinate
    @param[in]     y   Second coordinate.
*/
void Vector2::Set(double x, double y)
{
    m_Vector[0]  = x;
    m_Vector[1]  = y;
}

/**
    Subtracts one vector from the current vector.
    @param[in]     other Other vector
*/
Vector2 Vector2::operator-=(const Vector2& other)
{
    m_Vector[0] -= other.m_Vector[0];
    m_Vector[1] -= other.m_Vector[1];
    return *this;
}

/**
    Subtracts one vector from the current vector.
    @param[in]     other Other vector
*/
Vector2 Vector2::operator-(const Vector2& other) const
{
    return Vector2(m_Vector[0] - other.m_Vector[0], m_Vector[1] - other.m_Vector[1]);
}

/**
    Adds one vector to the current vector.
    @param[in]     other Other vector
*/
Vector2 Vector2::operator+=(const Vector2& other)
{
    m_Vector[0] += other.m_Vector[0];
    m_Vector[1] += other.m_Vector[1];
    return *this;
}

/**
    Adds one vector to the current vector.
    @param[in]     other Other vector
*/
Vector2 Vector2::operator+(const Vector2& other) const
{
    return Vector2(m_Vector[0] + other.m_Vector[0], m_Vector[1] + other.m_Vector[1]);
}

/**
    Compares whether current vector is equal to another vector.
    Vectors are equal if their coordinates are equal.
    @param[in]     other Other vector
    @return @b true if coordinate values of two vectors are equal.
*/
bool Vector2::operator==(const Vector2& other) const
{
    bool equal = false;

    if ( (m_Vector[0] == other.m_Vector[0]) &&  //lint !e777
         (m_Vector[1] == other.m_Vector[1]))    //lint !e777
    {
        equal = true;
    }
    return equal;
}

/**
    Compares whether current vector is not equal to another vector. 
    Vectors are not equal if either of their coordinates are not equal.
    @param[in]     other Other vector
    @return @b true if coordinate values of two vectors are NOT equal.
*/
bool Vector2::operator!=(const Vector2& other) const
{
    bool notEqual = false;

    if ( (m_Vector[0] != other.m_Vector[0]) ||  //lint !e777
         (m_Vector[1] != other.m_Vector[1]))    //lint !e777
    {
        notEqual = true;
    }
    return notEqual;

}

/**
    Computes length of vector.
    @return length of vector.
*/
double Vector2::Length() const
{
    return sqrt(m_Vector[0] * m_Vector[0] + m_Vector[1] * m_Vector[1]);
}

/**
    Computes length of vector.
    @return square of the length of the vector.
*/
double Vector2::LengthSquared() const
{
    return  m_Vector[0] * m_Vector[0] + m_Vector[1] * m_Vector[1];
}

/**
    Converts vector to a unit vector.
*/
void Vector2::Normalize()
{
    const double epsilon = 1e-8;

    double divisor = Length();

    if (divisor > epsilon)
    {
        double oneOverLength = 1.0 / divisor;

        m_Vector[0] *= oneOverLength;
        m_Vector[1] *= oneOverLength;
    }
}

/**
    Multiples a scalar times a vector.
    @param[in]  scale Scalar value
    @param[in]  vector Other vector
    @return scaled Vector2.
*/
Vector2 operator*(double scale, const Vector2& vector)
{
    return Vector2(scale * vector.m_Vector[0],
                   scale * vector.m_Vector[1] );
}

/**
    Computes the dot product of two vectors. This operation commutes.
    @param[in]  one    First vector
    @param[in]  two    Second vector
    @return dot product.
*/
double DotProduct(const Vector2& one, const Vector2& two)
{
    return (one.m_Vector[0] * two.m_Vector[0]) + (one.m_Vector[1] * two.m_Vector[1]);
}

/**
    Computes the angle between two vectors. The included angle is in radians.
    @param[in]  one    First vector
    @param[in]  two    Second vector
    @return angle in radians.
*/
double AngleBetween(const Vector2& one, const Vector2& two)
{
    double cosAngle = DotProduct(one, two) / (one.Length() * two.Length());

    Clamp(cosAngle, -1.0, 1.0);

    double angle = acos(cosAngle);

    return angle;
}

/**
    Computes the Tau factor of two vectors. 
    Tau is defined to be ratio of length of curve to the chord (distance between the ends).
    This gives an idea of the angle between the two vectors.
    @note The vectors must be of the same length.
    @param[in]  one    First vector
    @param[in]  two    Second vector
    @return tau.
*/
double Tau(const Vector2& one, const Vector2& two)
{
    // Since the vectors are the same length then we can compare the length squared using
    // the fact that (x/2)^2 + (x/2)^2 = x^2/2.
    double  pathLength  = one.LengthSquared() + two.LengthSquared();
    Vector2 chord = one + two;
    double  chordLength = chord.LengthSquared();

    double  tau = (pathLength * 2.0) / chordLength;
    return tau;
}

/**
    Determines whether the vector is valid, i.e. the coordinates are
    valid floating point numbers.
    @return @b true if both coordinates are valid floating point numbers.
*/
bool Vector2::IsValid() const
{
    bool valid = true;

    if (    IsNan(m_Vector[0]) ||
            IsNan(m_Vector[1]) ||
            IsInf(m_Vector[0]) ||
            IsInf(m_Vector[1]) )
    {
        valid = false;
    }
    return valid;
}
