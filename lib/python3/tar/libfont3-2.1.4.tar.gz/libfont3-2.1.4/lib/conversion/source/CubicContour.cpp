// Copyright (C) 2015 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// CubicContour.cpp

#include "CubicContour.h"
#include "CubicBezier.h"
#include "CompositCubicBezier.h"


CubicContour::CubicContour(int designUnits /* = DEFAULT_CUBIC_UNITS */)
    : Contour(designUnits)
{
}



bool CubicContour::Match(QuadContour& quadContour, float tolerance)
{
    bool success = true;
    int numPoints = m_Points.NumElements();

    // If output contour has different design units adjust size 
    // before converting.
    ScaleTo(quadContour.GetDesignUnits());

    // tolerance may need fixing up due to scaling.
    tolerance *= m_Scale;

    // Make sure we write out single points.
    if (numPoints == 1)
    {
        quadContour.AddPoint(m_Points[0]);
        return true;
    }

    CubicBezier cubic;

    Vector2f points[4];

    int index = 0;

    for (int i = 0; i < numPoints; i++)
    {
        ContourPoint& currentPoint = m_Points[i];

        switch (currentPoint.m_Type)
        {
            case ContourPoint::MOVE_TO:
                points[0] = currentPoint.m_Point;
                quadContour.AddPoint(currentPoint);
                index = 1;
            break;

            case ContourPoint::LINE_TO:
                quadContour.AddPoint(currentPoint, true);

                points[index] = currentPoint.m_Point;
                points[0] = points[1];
                index = 1;
            break;

            case ContourPoint::OFF_CURVE:
                points[index++] = currentPoint.m_Point;
            break;

            case ContourPoint::ON_CURVE:
                points[index++] = currentPoint.m_Point;
                if (index >= 4)
                {
                    cubic.SetPoint(CubicBezier::eSTART,     points[0]);
                    cubic.SetPoint(CubicBezier::eCONTROL1,  points[1]);
                    cubic.SetPoint(CubicBezier::eCONTROL2,  points[2]);
                    cubic.SetPoint(CubicBezier::eEND,       points[3]);
                    cubic.Evaluate();

                    success &= cubic.Match(quadContour, tolerance);
                    points[0] = points[3];
                    index = 1;
                }
            break;
        }
    }

    quadContour.Reverse();

    return success;
}


bool CubicContour::Match(CubicContour& cubicContour, float tolerance, bool preserveExtrema /* = false */)
{
    bool success = true;

    FindExtrema(preserveExtrema);

    int numPoints = m_Points.NumElements();

    // If output contour has different design units adjust size 
    // before converting.
    ScaleTo(cubicContour.GetDesignUnits());

    // tolerance may need fixing up due to scaling.
    tolerance *= m_Scale;

    // Make sure we write out single points.
    if (numPoints == 1)
    {
        cubicContour.AddPoint(m_Points[0]);
        return true;
    }

    CompositCubicBezier cubic;
    cubic.Clear();

    Vector2f points[4];

    int index = 0;

    for (int i = 0; i < numPoints; i++)
    {
        ContourPoint& currentPoint = m_Points[i];

        switch (currentPoint.m_Type)
        {
            case ContourPoint::MOVE_TO:
                if (cubic.NumComponents() > 0)
                {
                    cubic.Match(cubicContour, tolerance);
                    cubic.Clear();
                }

                points[0] = currentPoint.m_Point;
                cubicContour.AddPoint(currentPoint);
                index = 1;
            break;

            case ContourPoint::LINE_TO:
                if (cubic.NumComponents() > 0)
                {
                    cubic.Match(cubicContour, tolerance);
                    cubic.Clear();
                }

                points[1] = currentPoint.m_Point;
                points[0] = points[1];
                cubicContour.AddPoint(currentPoint);
                index = 1;
            break;

            case ContourPoint::OFF_CURVE:
                points[index++] = currentPoint.m_Point;
            break;

            case ContourPoint::ON_CURVE:

                points[index] = currentPoint.m_Point;

                cubic.AddCubic(points[0], points[3], points[1], points[2]);

                if (currentPoint.m_IsExtremum) 
                {
                    success &= cubic.Match(cubicContour, tolerance);
                    cubic.Clear();
                }
                points[0] = points[3];
                index = 1;
            break;
        }
    }

    if (cubic.NumComponents() > 0)
    {
        success &= cubic.Match(cubicContour, tolerance);
        cubic.Clear();
    }
    return success;
}


