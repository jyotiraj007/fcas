// Copyright (C) 2015 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
/// \file Contour.h

#ifndef CONTOUR_H
#define CONTOUR_H

#include "Defines.h"
#include "ContourPoint.h"
#include "ArrayList.h"
#include <stdio.h>

class Contour
{
    public:

        /* CTOR */      Contour         ();
        /* CTOR */      Contour         (int designUnits);

        void            Clear           ();
        void            AddPoint        (const ContourPoint& point, bool stipDuplicates = false);

        int             NumPoints       ();
        ContourPoint&   GetPoint        (int index);

        void            ScaleTo         (int newUnits);
        void            FindExtrema     (bool findAll = true);

        void            SetDesignUnits  (int designUnits);
        int             GetDesignUnits  ();

        bool            IsClosed        ();

        bool            DuplicatePoints ();
        bool            InvalidPoints   ();
        bool            OffIntegerPoints();
        void            PrintToFile     (FILE* pFile);

        void            Reverse         ();

    protected:

        ArrayList<ContourPoint> m_Points;
        Vector2f m_LastPoint;

        int                     m_DesignUnits;
        float                   m_Scale;
        bool                    m_Changed;

};

#endif
