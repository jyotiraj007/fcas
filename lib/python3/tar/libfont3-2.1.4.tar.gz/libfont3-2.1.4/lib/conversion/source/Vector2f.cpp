// Copyright (C) 2014 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// Vector2f.cpp

//lint -sem(Vector2f::Set,initializer)

#include "Vector2f.h"
#include "Vector2i.h"
#include "MathUtilities.h"
#include "ConversionLibPort.h"
#include <math.h>


/**
    Constructs Vector2f and initializes coordinates to (0.0f,0.0f).
*/
Vector2f::Vector2f()
{
}

/**
    Copy constructor.
*/
Vector2f::Vector2f(const Vector2f& other)
                : m_X(other.m_X),
                  m_Y(other.m_Y)
        
{
}

Vector2f::Vector2f(const Vector2i& other)
                : m_X((float) other[0]),
                  m_Y((float) other[1])
{
}

/**
    Copy constructor.
*/
Vector2f::Vector2f(const Vector2& otherDouble)
                : m_X((float) otherDouble[0]),
                  m_Y((float) otherDouble[1])
{
}

/**
    Constructs Vector2f using coordinates.
    @param[in]     x   First coordinate
    @param[in]     y   Second coordinate.
*/
Vector2f::Vector2f(float x, float y)
                : m_X(x),
                  m_Y(y)
{
}

/**
    Constructs Vector2f using Fixed Point 16:16 coordinates.
    @param[in]     x   First coordinate
    @param[in]     y   Second coordinate.
*/
void Vector2f::FromFixed(int x, int y)
{
    float fx = FixedToFloat(x);
    float fy = FixedToFloat(y);

    fx += 0.5f;
    fy += 0.5f;

    Set((float)floor(fx), (float)floor(fy));
}



/**
    Sets vector coordinates.
    @param[in]     x   First coordinate.
    @param[in]     y   Second coordinate.
*/
void Vector2f::Set(float x, float y)
{
    m_X  = x;
    m_Y  = y;
}

/**
    Subtracts one vector from the current vector.
    @param[in]     other Other vector
*/
Vector2f Vector2f::operator-=(const Vector2f& other)
{
    m_X -= other.m_X;
    m_Y -= other.m_Y;
    return *this;
}

/**
    Subtracts one vector from the current vector.
    @param[in]     other Other vector
*/
Vector2f Vector2f::operator-(const Vector2f& other) const
{
    return Vector2f(m_X - other.m_X, m_Y - other.m_Y);
}

/**
    Adds one vector to the current vector.
    @param[in]     other Other vector
*/
Vector2f Vector2f::operator+=(const Vector2f& other)
{
    m_X += other.m_X;
    m_Y += other.m_Y;
    return *this;
}

/**
    Scales this vector by a float.
    @param[in]  scale factor.
*/
Vector2f Vector2f::operator*=(float scale)
{
    m_X *= scale;
    m_Y *= scale;
    return *this;
}

/**
    Adds one vector to the current vector.
    @param[in] other Other vector
*/
Vector2f Vector2f::operator+(const Vector2f& other) const
{
    return Vector2f(m_X + other.m_X, m_Y + other.m_Y);
}

/**
    Compares whether current vector is equal to another vector.
    Vectors are equal if their coordinates are equal.
    @param[in]     other Other vector
    @return @b true if coordinate values of two vectors are equal.
*/
bool Vector2f::operator==(const Vector2f& other) const
{
    bool equal = false;

    if ( (m_X == other.m_X) &&  //lint !e777
         (m_Y == other.m_Y))    //lint !e777
    {
        equal = true;
    }
    return equal;
}

/**
    Compares whether current vector is not equal to another vector.
    Vectors are equal if their coordinates are equal.
    @param[in]     other Other vector
    @return @b true if coordinate values of two vectors are equal.
*/
bool Vector2f::operator!=(const Vector2f& other) const
{
    bool notEqual = false;

    if ( (m_X != other.m_X) ||  //lint !e777
         (m_Y != other.m_Y))    //lint !e777
    {
        notEqual = true;
    }
    return notEqual;
}

/**
    Round data members to nearest integer.
    @return Vector2f x and y both rounded to nearest integer.
*/
Vector2f Vector2f::Rounded() const
{
    float x = (m_X + 0.5f);
    float y = (m_Y + 0.5f);

    return Vector2f((float)floor(x), (float)floor(y));
}

/**
    Computes length of vector.
    @return length of vector.
*/
float Vector2f::Length() const
{
    float length = (float)sqrt(m_X * m_X +
                               m_Y * m_Y );
    return length;
}



/**
    Converts vector to a unit vector.
*/
void Vector2f::Normalize()
{
    float divisor = Length();

    if (divisor > 1e-8f)
    {
        m_X /= divisor;
        m_Y /= divisor;
    }
}

/**
    Multiples a scalar times a vector.
    @param[in]  scale Scalar value
    @param[in]  other Other vector
    @return scaled Vector2f.
*/
Vector2f operator*(float scale, const Vector2f& other)
{
    return Vector2f(scale * other.m_X,
                    scale * other.m_Y );
}

/**
    Computes the dot product of two vectors. This operation commutes.
    @param[in]  one    First vector
    @param[in]  two    Second vector
    @return dot product.
*/
float DotProduct(const Vector2f& one, const Vector2f& two)
{
    return (one.m_X * two.m_X) + (one.m_Y * two.m_Y);
}

/**
    Computes the cross product of two vectors. 
    @param[in]  one    First vector
    @param[in]  two    Second vector
    @return cross product.
*/
float CrossProduct(const Vector2f& one, const Vector2f& two)
{
    return one[0] * two[1] - one[1] * two[0];
                       
}


/**
    Determines whether the vector is valid, i.e. the coordinates are
    valid floating point numbers.
    @return @b true if both coordinates are valid floating point numbers.
*/
bool Vector2f::IsValid() const
{
    bool valid = true;

    if (    IsNan(m_X) ||
            IsNan(m_Y) ||
            IsInf(m_X) ||
            IsInf(m_Y) )
    {
        valid = false;
    }
    return valid;
}

float Distance(const Vector2f& one, const Vector2f& two)
{
    Vector2f lineVec = two - one;
    float distance = lineVec.Length();
    return distance;
}

float ManhattenDistance(const Vector2f& one, const Vector2f& two)
{
    float xDistance = (float)fabs(two[0] - one[0]);
    float yDistance = (float)fabs(two[1] - one[1]);

    float distance = xDistance + yDistance;

    return distance;
}

void Vector2f::Print()
{
    printf("(%.1f, %.1f)", m_X, m_Y);
}