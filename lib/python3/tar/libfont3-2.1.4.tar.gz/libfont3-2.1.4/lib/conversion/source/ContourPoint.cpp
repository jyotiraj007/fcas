// Copyright (C) 2015 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// ContourPoint.cpp

#include "ContourPoint.h"

static const char* TypeNames [] = { "MOVE_TO",   "LINE_TO", "ON_CURVE", "OFF_CURVE" };

/* CTOR */ ContourPoint::ContourPoint() 
    : m_Type        (MOVE_TO),
      m_Point       (),
      m_IsExtremum  (false),
      m_IsImplicit  (false)
{
}

/* CTOR */ ContourPoint::ContourPoint(PointType type, const Vector2f& point)
    : m_Type        (type),
      m_Point       (point),
      m_IsExtremum  (false),
      m_IsImplicit  (false)
{
}

void ContourPoint::PrintToFile(FILE* pFile)
{
    fprintf(pFile, "%s %.1f %.1f\n", TypeNames[m_Type], m_Point[0], m_Point[1]);
}

void ContourPoint::Print()
{
    printf("%s %.1f %.1f\n", TypeNames[m_Type], m_Point[0], m_Point[1]);
}