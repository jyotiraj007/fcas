// Copyright (C) 2014 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
/// \file ArrayList.h

#ifndef ARRAY_LIST_H
#define ARRAY_LIST_H

#include <assert.h>

template <class T> class ArrayList
{
   enum { MAX_SLOTS = 64 };
   enum { MIN_SIZE  = 128};

    public:

        /* Ctor */  ArrayList   ();
        /* Ctor */  ArrayList   (int numElements);
        /* Ctor */  ArrayList   (const ArrayList& other);
        /* Ctor */  ArrayList   (ArrayList& other, int from, int to);
        /* Dtor */ ~ArrayList   ();
        ArrayList&  operator=   (const ArrayList& other);
        ArrayList&  operator+=  (ArrayList& other);
        void        AppendRange (ArrayList& other, int from, int to);


        int         NumElements () const;

        int         Add         (const T& newElement);
        T&          operator[]  (int index);
        const T&    operator[]  (int index) const;

        T&          First       ();
        T&          Last        ();

        void        Clear       ();
        void        SetNumElements(int numElements);
        void        ResetIndex  ();
        void        Sort        ();

    protected:

        void        SetSize     (int newSize);
        int         GetSize     () const;

        bool        IsValidIndex    (int index) const;
        int         GetInitialSize  (int desiredSize) const;
        void        Grow            ();

        T*          m_Slots[MAX_SLOTS];
        T           m_Sentry;

        int         m_NumSlots;
        int         m_Size;
        int         m_NumElems;
        int         m_SmallestSlotSize;
};


template <class T>
ArrayList<T>::ArrayList() : m_NumSlots(0), m_Size(0), m_NumElems(0),  m_SmallestSlotSize(0)
{
}

template <class T>
ArrayList<T>::ArrayList(int numElements) : m_NumSlots(0),  m_Size(0), m_NumElems(0), m_SmallestSlotSize(0)
{
    SetNumElements(numElements);
}

template <class T>
ArrayList<T>::ArrayList(const ArrayList& other) : m_NumSlots(0), m_Size(0), m_NumElems(0), m_SmallestSlotSize(0)
{
    int numElems = other.NumElements();

    for (int i = 0; i < numElems; i++)
    {
       Add(other[i]);
    }
}

template <class T>
ArrayList<T>::ArrayList(ArrayList& other, int from, int to) : m_NumSlots(0), m_Size(0), m_NumElems(0), m_SmallestSlotSize(0)
{
    for (int i = from; i <= to; i++)
    {
        Add(other[i]);
    }
}


template <class T>
ArrayList<T>& ArrayList<T>::operator=(const ArrayList& other)
{
    if (this != &other)
    {
        Clear();
        int numElems = other.NumElements();
        for (int i = 0; i < numElems; i++)
        {
            Add(other[i]);
        }
    }
    return *this;
}

template <class T>
ArrayList<T>& ArrayList<T>::operator+=(ArrayList& other)
{
    if (this != &other)
    {
        int numElems = other.NumElements();
        for (int i = 0; i < numElems; i++)
        {
            Add(other[i]);
        }
    }
    return *this;
}

template <class T>
void ArrayList<T>::AppendRange(ArrayList& other, int from, int to)
{
    if (this != &other)
    {
        int numElems = other.NumElements();

        if ((from < 0) || (to < 0))
            return;
        if (from > to)
            return;
        if (from > numElems-1)
            return;
        if (to > numElems-1)
            return;

        for (int i = from; i <= to; i++)
        {
            Add(other[i]);
        }
    }
}

template <class T>
ArrayList<T>::~ArrayList()
{
    Clear();    //lint !e1551
}

template <class T>
int ArrayList<T>::GetInitialSize(int size) const
{
    int power = 1;

    // Find next larger power of 2.
    while (power < size)
    {
        power  <<= 1;                       //lint !e701
    }

    // Take the next smaller power of 2.
    power >>= 1;                            //lint !e702

    return power;
}

template <class T>
int ArrayList<T>::Add(const T& newElement)
{
   int index = m_NumElems;
   m_NumElems++;

   if (m_Size == 0)
   {
       SetSize(MIN_SIZE);
   }

   while (index >= m_Size)
   {
      Grow();
   }

   operator[](index) = newElement;
   return index;
}

template <class T>
T& ArrayList<T>::First()
{
    return operator[](0);
}

template <class T>
T& ArrayList<T>::Last()
{
    int lastIndex = NumElements() - 1;

    return operator[](lastIndex);
}


template <class T>
T& ArrayList<T>::operator[](int index)
{
    if (IsValidIndex(index))
    {
        int slot = 0;

        if (index >= m_SmallestSlotSize)
        {
            int slotSize = m_SmallestSlotSize;

            while (index >= slotSize)
            {
                slotSize <<= 1;     //lint !e701
                slot++;
            }
            slotSize >>= 1;         //lint !e702

            index -= slotSize;
        }

       return m_Slots[slot][index];
    }

    return m_Sentry; //lint !e1536  The sentry value is that of the default ctor of the object. It it returned when an invalid index is requested.
}

template <class T>
const T& ArrayList<T>::operator[](int index) const
{
    if (IsValidIndex(index))
    {
        int slot = 0;

        if (index >= m_SmallestSlotSize)
        {
            int power = m_SmallestSlotSize;

            while (power <= index)
            {
                power <<= 1;    //lint !e710
                slot++;
            }
            power >>= 1;        //lint !e702

            index -= power;
        }

       return m_Slots[slot][index];
    }

    return m_Sentry;
}


template <class T>
int ArrayList<T>::GetSize() const
{
   return m_Size;
}


template <class T>
int ArrayList<T>::NumElements() const
{
   return m_NumElems;
}

template <class T>
void ArrayList<T>::SetSize(int newSize)
{
    if (m_NumSlots > MAX_SLOTS-1)
    {
        assert(0);
        return;
    }

    m_Size              = GetInitialSize(newSize);
    m_SmallestSlotSize  = m_Size;
    m_Slots[m_NumSlots] = new T[m_Size];

    m_NumSlots++;
}

template <class T>
void ArrayList<T>::Grow()
{
    if (m_NumSlots > MAX_SLOTS-1)
    {
        assert(0);
        return;
    }

    if (m_Size < 1)
    {
        assert(0);
        return;
    }

    m_Slots[m_NumSlots] = new T[m_Size];

    m_NumSlots++;

    m_Size *= 2;
}

template <class T> 
void ArrayList<T>::SetNumElements(int numElements)
{
    Clear();
    if (numElements < MIN_SIZE)
    {
        numElements = MIN_SIZE;
    }

    SetSize(numElements);

    T object;

    for (int i = 0; i < numElements; i++)
    {
        Add(object);
    }
}

template <class T>
void ArrayList<T>::Clear()
{
   for (int i = 0; i < m_NumSlots; i++)
   {
      delete[] (T*) m_Slots[i];
      m_Slots[i] = 0;
   }

   m_Size     = 0;
   m_NumSlots = 0;
   m_NumElems = 0;
}

template <class T>
bool ArrayList<T>::IsValidIndex(int index) const
{
    bool valid = false;

    if ((index >= 0) &&
        (index < m_NumElems))
    {
        valid = true;
    }
    return valid;
}

template <class T>
void ArrayList<T>::ResetIndex()
{
    m_NumElems = 0;
}

template <class T>
void ArrayList<T>::Sort()
{
    int minIndex;

    int numElements = NumElements();

    for (int j = 0; j < numElements - 1; j++)
    {
        minIndex = j;
        for (int i = j + 1; i < numElements; i++)
        {
            // If this element is less, then it is the new minimum.  
            if (operator[](i) < operator[](minIndex))
            {
                // Found new minimum; remember its index.
                minIndex = i;
            }
        }

        // iMin is the index of the minimum element.
        // Swap it with the current position.
        if (minIndex != j)
        {
            T temp               = operator[](j);
            operator[](j)        = operator[](minIndex);
            operator[](minIndex) = temp;
        }
    }
}


#endif
