#ifndef CUBIC_POINTS_H
#define CUBIC_POINTS_H

#include "Vector2f.h"

struct CubicPoints
{
    Vector2f    m_Start;
    Vector2f    m_End;
    Vector2f    m_Control1;
    Vector2f    m_Control2;

    CubicPoints() {};


    CubicPoints(const Vector2f& start, const Vector2f& end, const Vector2f& control1, const Vector2f& control2)
        :   m_Start     (start),
            m_End       (end),
            m_Control1  (control1),
            m_Control2  (control2)
    {
    }

    void Set(const Vector2f& start, const Vector2f& end, const Vector2f& control1, const Vector2f& control2)
    {
        m_Start         = start;
        m_End           = end;
        m_Control1      = control1;
        m_Control2      = control2;
    }

    CubicPoints Reflect(const Line2D& line)
    {
        CubicPoints reflectedPoints;

        reflectedPoints.m_Start     = line.ReflectPoint(m_Start);
        reflectedPoints.m_End       = line.ReflectPoint(m_End);
        reflectedPoints.m_Control1  = line.ReflectPoint(m_Control1);
        reflectedPoints.m_Control2  = line.ReflectPoint(m_Control2);

        return reflectedPoints;
    }

    bool IsLinear(float tolerance)
    {
        bool linear = false;
 
        Line2D line(m_Start, m_End);

        if ( (line.PointDistance(m_Control1) < tolerance) &&
             (line.PointDistance(m_Control2) < tolerance) )
        {
            linear = true;
        }

        return linear;
    }
};

#endif
