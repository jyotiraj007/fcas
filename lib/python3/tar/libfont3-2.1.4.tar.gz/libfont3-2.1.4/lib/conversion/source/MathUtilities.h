// Copyright (C) 2014 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
/// \file MathUtilities.h

#ifndef MATH_UTILITIES_H
#define MATH_UTILITIES_H

#include <math.h>
#include "Vector2f.h"
#include "Line2D.h"

static const double PI         = 3.14159265;
static const double DOUBLE_MAX = 1.7976931348623158e+308;
static const float  FLOAT_MAX  = 3.4e+038f;

static inline double ToRadians(double degrees)
{
    return degrees * (PI / 180);
}

static inline double ToDegrees(double radians)
{
    return radians * (180.0 / PI);
}

static inline bool IsNan(double x)
{
    return x != x;  //lint !e777
}

static inline bool IsInf(double x)
{
    return !IsNan(x) && IsNan(x - x);
}

static inline bool IsNan(float x)
{
    return x != x;
}

static inline bool IsInf(float x)
{
    return !IsNan(x) && IsNan(x - x);
}

static inline float Clamp(float& value, float low, float high)
{
    if (value < low)
    {
        value = low;
    }
    if (value > high)
    {
        value = high;
    }
    return value;
}

static inline double Clamp(double& value, double low, double high)
{
    if (value < low)
    {
        value = low;
    }
    if (value > high)
    {
        value = high;
    }
    return value;
}

static inline void Clamp(int& value, int low, int high)
{
    if (value < low)
    {
        value = low;
    }
    if (value > high)
    {
        value = high;
    }
}

// Convert 16:16 Fixed Point to float.
static inline float FixedToFloat(int fixed)
{
    return (float) fixed / 65536.0f;
}

static inline int FloatToFixed(float val)
{
    float shifted = val * 65536.0f;
    return (int) shifted;
}

static inline Vector2f Interpolate(Vector2f& a, Vector2f& b, float t)
{
    float x = a[0] + (b[0] - a[0]) * t;
    float y = a[1] + (b[1] - a[1]) * t;

    return Vector2f(x, y);
}

// Actually twice triangle area, but we're just looking for the sign.
static inline float TriangleArea(Vector2f v1, Vector2f v2, Vector2f v3)
{
    return (v3[0] * v2[1] - v2[0] * v3[1]) - (v3[0] * v1[1] - v1[0] * v3[1]) + (v2[0] * v1[1] - v1[0] * v2[1]);
}

static inline bool Linear(Vector2f p1, Vector2f p2, Vector2f p3)
{
    bool linear = false;

    Line2D line(p1, p3);

    double distance = line.PointDistance(p2);

    if (distance < 1.0) //bb
    {
        linear = true;
    }

    return linear;
}

static inline void Swap(int& a, int& b)
{
    int temp = a;
    a = b;
    b = temp;
}

static inline float F_MIN(float a, float b)
{
    return (a < b ? a : b);
}

static inline float F_MAX(float a, float b)
{
    return (a > b ? a : b);
}

#endif
