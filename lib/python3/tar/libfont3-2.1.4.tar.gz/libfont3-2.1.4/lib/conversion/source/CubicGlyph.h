// Copyright (C) 2015 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
/// \file CubicGlyph.h

#ifndef CUBIC_GLYPH_H
#define CUBIC_GLYPH_H

#include "CubicContour.h"
#include "QuadGlyph.h"
#include <stdio.h>

class CubicGlyph 
{
    public:

        /* CTOR */ CubicGlyph   (int designUnits = DEFAULT_CUBIC_UNITS);

        void            Clear           ();
        void            AddContour      (CubicContour& contour);
        int             NumContours     ();
        CubicContour&   GetContour      (int index);

        bool            Match           (QuadGlyph& quadGlyph, float tolerance);
        bool            Match           (CubicGlyph& cubicGlyph, float tolerance, bool preserveExtrema = false);

        int             GetDesignUnits  ();
        bool            InvalidPoints   ();
        bool            NonIntegerPoints();
        bool            DuplicatePoints ();
        void            PrintToFile     (FILE* pFile);

    protected:

        ArrayList<CubicContour>      m_Contours;
        int                          m_DesignUnits;
};

#endif
