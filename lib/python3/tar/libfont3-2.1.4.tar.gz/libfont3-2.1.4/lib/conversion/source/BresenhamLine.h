// Copyright (C) 2015 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
/// \file BresenhamLine.h

#ifndef BRESENHAM_LINE_H
#define BRESENHAM_LINE_H

#include "Vector2i.h"

class BresenhamLine
{
    public:
        /* CTOR */ BresenhamLine    ();
        /* CTOR */ BresenhamLine    (const Vector2i& start, const Vector2i& end);

        bool       FirstPoint       (Vector2i& point);
        bool       NextPoint        (Vector2i& point);

        float      Length           () const;

    protected:

        Vector2i    m_Start;
        Vector2i    m_End;

        bool        m_yMajor;
        int         m_yStep;
        int         m_LastX;

        float       m_Error;
        float       m_DeltaX;
        float       m_DeltaY;

        int         m_CurrentX;
        int         m_CurrentY;
};

#endif
