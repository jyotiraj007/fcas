// Copyright (C) 2014 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
/// \file Line2D.h

#ifndef LINE_2D_H
#define LINE_2D_H

#include "Vector2.h"
#include "Vector2f.h"
#include "Circle.h"

//! Describes a line segment in 2D space
/*!
    Provides methods to determine if the line segment intersects other line segments or circles. 
    See also Vector2 and Circle.
*/
class Line2D
{
    public:
                Line2D          ();
                Line2D          (const Vector2& start, const Vector2& end);
                Line2D          (const Line2D& other);
        void    Set             (const Vector2& start, const Vector2& end);

        void    SetStart        (const Vector2& start);
        void    SetEnd          (const Vector2& end);

        Vector2f ReflectPoint   (const Vector2f& point) const;

        Line2D  Normal          ();

        double  Length          () const;
        double  LengthSquared   () const;
        double  PointDistance   (const Vector2& point);
        Vector2 Intersects      (Line2D& other);
        bool    SegsIntersect   (const Line2D& other) const;
        double  Tau             (const Line2D& other) const;
        Vector2 Interpolate     (float t);
        void    ExtendEnd       ();
        void    ExtendStart     ();

        void    Extend          (double length);
        void    ExtendStart     (double length);

        bool    Intersects      (Circle circle, Vector2& out);
        Vector2 Start           () const;
        Vector2 End             () const;

        bool    IsValid         () const;

    protected:

        Vector2     m_Start;
        Vector2     m_End;
};


#endif
