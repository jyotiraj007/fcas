// Copyright (C) 2014 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
/// \file Stack.h

#ifndef STACK_H
#define STACK_H

#include "ArrayList.h"

template <class T> class Stack
{
    public:
        enum { MAX_STACK = 32 };
        /* Ctor */ Stack    ();
        /* Dtor */~Stack    ();

        void       Push     (T& element);
        T&         Pop      ();
        bool       IsEmpty  ();
        void       Reset    ();

        int        NumElements();
        T&         ElementAt(int index);

    protected:

        T           m_Elements[MAX_STACK];
        int         m_StackIndex;
};

template <class T>
Stack<T>::Stack()
{
    m_StackIndex = 0;
}

template <class T>
Stack<T>::~Stack()
{
}

template <class T>
void Stack<T>::Reset()
{
    m_StackIndex = 0;
}

template <class T>
void Stack<T>::Push(T& element)
{
    // Does the array need to grow?
    if (m_StackIndex < MAX_STACK)
    {
       m_Elements[m_StackIndex] = element;
    }

    m_StackIndex++;
}

template <class T>
T& Stack<T>::Pop()
{
    if (m_StackIndex > 0)
    {
        m_StackIndex--;
        return m_Elements[m_StackIndex];
    }

    return m_Elements[0];
}

template <class T>
int Stack<T>::NumElements()
{
    return m_StackIndex;
}

template <class T>
T& Stack<T>::ElementAt(int index)
{
    return m_Elements[index];
}

template <class T>
bool Stack<T>::IsEmpty()
{
    bool isEmpty = false;

    isEmpty = (m_StackIndex == 0);

    return isEmpty;
}

#endif
