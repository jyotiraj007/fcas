// Copyright (C) 2014 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
/// \file CubicBezier.h

#ifndef CUBIC_BEZIER_H
#define CUBIC_BEZIER_H

#include "ArrayList.h"
#include "Vector2f.h"
#include "QuadBezier.h"
#include "Line2D.h"
#include "QuadContour.h"
#include "Stack.h"
#include "CubicPoints.h"

class  CubicBezier
{
    public:

    enum Control { eCONTROL1 = 0, eCONTROL2, eSTART, eEND, eNONE };       // Must start with control: indexes m_Bars.

        /* Ctor */  CubicBezier ();
        /* Ctor */  CubicBezier (const Vector2f& startPoint, const Vector2f& endPoint, const Vector2f& controlPoint1, const Vector2f& controlPoint2, int numSegments = 10);
        /* Ctor */  CubicBezier (const CubicPoints& cubicPoints);
        void        Init        (const Vector2f& startPoint, const Vector2f& endPoint, const Vector2f& controlPoint1, const Vector2f& controlPoint2, int numSegments = 10);

        void        SetPoint    (Control control, const Vector2f& point);
        Vector2f    GetPoint    (Control control);

        void        GetPoints  (CubicPoints& points);
        void        SetPoints  (const CubicPoints& points);

        bool        Match       (QuadContour& quadContour, float tolerance);

        int         NumSegments ();
        void        CreateSegments  (float flatness = 0.05f);
        void        GetCenterSegment(Line2D& segment, float flatness = 0.05f);
        void        Evaluate        (float flatness = 0.05f);

        void        SplitAt(float t, CubicPoints& one, CubicPoints& two);
        void        PrintControlPoints();

    protected:

        bool            Search          (QuadContour& quadContour);
        bool            Score           ();
        bool            CheckRight      (Line2D& startTangent, Line2D& startTarget, int startIndex, int endIndex);
        int             FindFirst       (Line2D& startTangent, int startIndex, int endIndex);


        bool            WithinTolerance (QuadBezier& quad, float& distance);
        double          SplineDistance  (QuadBezier& quad, bool& anyIntersections, int startIndex, int stopIndex);
        bool            IsLinear        (float tolerance);

        Vector2f        CalculatePoint  (float t);

        ArrayList<QuadBezier>   m_Beziers;
        ArrayList<Line2D>       m_Tangents;
        ArrayList<Vector2f>     m_Intersections;
        ArrayList<Vector2f>     m_ControlPoints;

        float                   m_BestAverage;
        ArrayList<QuadBezier>   m_BestBeziers;
        bool                    m_FoundMatch;
        Line2D                  m_StartTangent;
        Line2D                  m_EndTangent;
        ArrayList<Line2D>       m_AllTangents;
        
        float                   m_CurrentFlatness;
        void                    CreateNormals();
        ArrayList<Line2D>       m_NormalLines; // Normals to this cubics segments;
        ArrayList<Vector2f>     m_MidPoints;

        Stack<Line2D>       m_EvalStack;
        Vector2f            m_Control[4];

        int                 m_NumSegments;
        ArrayList<Vector2f> m_Points;

        float               m_Tolerance;
        int                 m_Depth;
        int                 m_CheckDepth;

        friend class CompositCubicBezier;
        friend class CompositQuadBezier;
};

#endif
