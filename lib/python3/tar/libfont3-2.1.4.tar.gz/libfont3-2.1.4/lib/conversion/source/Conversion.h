// Copyright (C) 2014 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
/// \file Conversion.h

#ifndef __CONVERSION_H__
#define __CONVERSION_H__

#include <stdlib.h>
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

    typedef enum _conv_error
    {
        CONVERSION_SUCCESS,             ///< Outline converted
        CONVERSION_FAIL,                ///< Algorithm was not able to find a solution for a contour in the outline
        CONVERSION_INVALID_PARAM,       ///< Bad parameter passed to function
        CONVERSION_MEMORY               ///< Failed to allocate memory
    } Conversion_Error;

    typedef enum _component_type
    {
        eSimple,       ///< component is part of a simple glyph
        eIsComposite,  ///< component is part of a composite glyph
        eUndefined     ///< component type is not defined yet

    } Component_Type;

    typedef enum _pointType
    {
        MOVE_TO = 0,
        LINE_TO,
        ON_CURVE,
        OFF_CURVE
    } Point_Type;

    typedef struct _simple_outline
    {
        unsigned short   np;                // Number of points in x,y,flags arrays
        unsigned short   nc;                // Number of contours in the outline
        unsigned short  *endPtsOfContours;  // Array of last points of each contour; nc is the number of contours.
        Point_Type      *types;             // Array of type for each coordinate in outline; np is the number of flags.
        float           *x;                 // First coordinates relative to (0,0); others are relative to previous point.
        float           *y;                 // First coordinates relative to (0,0); others are relative to previous point.
        unsigned short  designUnits;        // Design units of original or requested design units of result
    } Simple_Outline;


    typedef struct _glyph_component
    {
        Component_Type   type;          // Type of component
        unsigned short   glyphIndex;    // Glyph index of component

        unsigned short   flags;         // Component flag (see TT spec)
        float            xoffset;       // x-offset for component or point number; type depends on bits 0 and 1 in component flags
        float            yoffset;       // y-offset for component or point number; type depends on bits 0 and 1 in component flags

        float            xscale;        // Transformation matrix, may be identity matrix if component is simple
        float            scale01;
        float            scale10;
        float            yscale;

        Simple_Outline outline;         // May be empty if glyph is part of a composite glyph

        struct _glyph_component* next;  // Linked list pointer to next component

    } Glyph_Component;


    typedef struct _Glyph_Outline
    {
        float    xMin;                // Minimum x for coordinate data.
        float    yMin;                // Minimum y for coordinate data.
        float    xMax;                // Maximum x for coordinate data.
        float    yMax;                // Maximum y for coordinate data.
        int      sid;                 // charset string id / cid for CID font
        int      FDid;                // FD index for CID font

        unsigned char*    glyfBlock;    // Raw data treated as a block.
        size_t   glyfSize;              // Size of glyfBlock

        short    numberOfComponents;    // If the number of components is zero, this is a simple glyph;
                                        // If greater than one, this is a composite glyph.
        Glyph_Component  component;     // Linked list of component glyphs

    } Glyph_Outline;


    typedef struct _glyph_hints
    {
        unsigned short    hintsLength;  // Total number of bytes for hint data.
        unsigned char*    hintsData;    // Hints data.

    } Glyph_Hints;

    typedef enum _glyph_type
    {
        eGlyph_UNKNOWN,   // Unknown font type
        eGlyph_TTF,       // TypeType outlines
        eGlyph_CFF        // CFF outlines

    } Glyph_Type;

    typedef struct _glyph_metrics
    {
        float aw;   // Horizontal advance width.
        float lsb;  // Horizontal left side bearing.
        float ah;   // Vertical advance
        float tsb;  // Vertical top side bearing

    } Glyph_Metrics;


    typedef struct _Glyph
    {
        Glyph_Type     glyphType;             // specifies glyph type {TTF,CFF}
        Glyph_Metrics  glyphMetrics;          // both horizontal and vertical metrics
        Glyph_Outline  glyphOutline;          // x, y, flags
        Glyph_Hints    glyphHints;            // block of either TT instructions or PS hints

    } Glyph;

    Conversion_Error convertCubic(Simple_Outline *cubicOutline, float tolerance, Simple_Outline *quadOutline);
    Conversion_Error convertQuadratic(Simple_Outline *quadOutline, float tolerance, Simple_Outline *cubicOutline);

    Conversion_Error refitCubic(Simple_Outline *cubicOutline, float tolerance, Simple_Outline *refitOutline);
    Conversion_Error refitQuadratic(Simple_Outline *quadOutline, float tolerance, Simple_Outline *refitOutline);

#ifdef __cplusplus
}
#endif

#endif //__CONVERSION_H__
