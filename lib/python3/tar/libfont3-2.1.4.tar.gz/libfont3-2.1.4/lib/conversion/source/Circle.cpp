// Copyright (C) 2014 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// Circle.cpp

#include "Circle.h"
#include "Line2D.h"
#include <assert.h>     /* Diagnostics: assert macro */

/**
    Constructs a degenerate circle with zero radius centered at the origin.
*/
Circle::Circle()
{
    m_Radius = m_RadiusSquared = 0.0f;
    m_Center = Vector2(0.0, 0.0);
}

/**
    Constructs a center using center position and radius.
    @param[in]  center  Center point.
    @param[in]  radius  Radius of circle.
*/
Circle::Circle(const Vector2& center, double radius)
{
    assert(radius >= 0.0);

    m_Radius = radius;
    m_Center = center;
    m_RadiusSquared = radius * radius;
}

/**
    Determines if a point is inside the circle. Points on the circle are not inside.
    @param[in]  point  Test point.
    @return @b true if point is inside the circle.
*/
bool Circle::IsInside(const Vector2& point)
{
    bool isInside = false;

    double deltaX = m_Center[0] - point[0];
    double deltaY = m_Center[1] - point[1];

    // Avoid sqrt by comparing the squares.
    double deltaXSquared = deltaX * deltaX;
    double deltaYSquared = deltaY * deltaY;
    double distance      = deltaXSquared + deltaYSquared;

    if (distance < m_RadiusSquared)
    {
        isInside = true;
    }

    return isInside;
}

/**
    Determines whether the circle and a line segment intersect.
    @param[in]  line  Line segment.
    @return @b true if intersection point exists.
*/
bool Circle::Intersects(const Line2D& line)
{
    bool intersects = false;

    // Intersects if one end inside and the other out.
    if (IsInside(line.Start())!= IsInside(line.End()))
    {
        intersects = true;
    }

    return intersects;
}

/**
    Returns center of circle.
    @return Center of circle.
*/
Vector2 Circle::Center() const
{
    return m_Center;
}

/**
    Returns radius of circle.
    @return Radius of circle.
*/
double Circle::Radius() const
{
    return m_Radius;
}

/**
    Returns the square of the radius of the circle.
    @return Radius squared of circle.
*/
double Circle::RadiusSquared() const
{
    return m_RadiusSquared;
}
