// Copyright (C) 2014 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// context_rule.h

#ifndef __CONTEXT_RULE_H__
#define __CONTEXT_RULE_H__

#include "data_types.h"
#include "stream.h"
#include "lf_error.h"
#include "lf_vector.h"
#include "coverage_table.h"

#ifdef __cplusplus
extern "C" {
#endif

/* ----------------------------------------------------------------------------
    A Rule table consists of a count of the glyphs to be matched in the 
    input context sequence (GlyphCount), including the first glyph in the 
    sequence, and an array of glyph indices that describe the context (Input). 
    The Coverage table specifies the index of the first glyph in the context, 
    and the Input array begins with the second glyph (array index = 1) in the 
    context sequence.

    Note: The Input array lists the indices in the order the corresponding 
    glyphs appear in the text. For text written from right to left, the 
    right-most glyph will be first; conversely, for text written from left 
    to right, the left-most glyph will be first.
    
    A SubRule table also contains a count of the substitutions to be 
    performed on the input glyph sequence (SubstCount) and an array of 
    LookupRecords (LookupRecord). Each record specifies a position in the 
    input glyph sequence and a LookupListIndex to the substitution lookup 
    that is applied at that position. The array should list records in 
    design order, or the order the lookups should be applied to the entire 
    glyph sequence.

---------------------------------------------------------------------------- */
typedef struct __context_rule__
{
    USHORT           GlyphCount;        // Total number of glyphs in input glyph
                                        // sequence-includes the first glyph.

    USHORT           LookupCount;       // Lookup Records count in SubstLookupRecords

//    GlyphID*        Input;            // Array of input GlyphIDs-start with second
                                        // glyph.

    LF_VECTOR        Input;
    LF_VECTOR        LookupRecords;     // Array of gsub_SubstLookupRecord structures.

} context_rule;

LF_ERROR    ContextRule_readRule(context_rule* sr, LF_STREAM* stream);
void        ContextRule_freeRule(context_rule* sr);
size_t      ContextRule_buildRule(context_rule* sr, LF_STREAM* stream);
size_t      ContextRule_sizeRule(context_rule* sr);
#ifdef LF_OT_DUMP
void        ContextRule_dumpRule(context_rule* cr);
#endif
LF_ERROR    ContextRule_searchRule(context_rule* cr, GlyphID glyphid, USHORT* index);
LF_ERROR    ContextRule_searchSequence(LF_VECTOR* sequence, GlyphID glyphid, USHORT* index);
LF_ERROR    ContextRule_readInputSequence(LF_VECTOR* input, USHORT count, LF_STREAM* stream);
LF_ERROR    ContextRule_remapRule(context_rule* cr, LF_MAP *remap);
void        ContextRule_cleanupLookups(context_rule* cr, TABLE_HANDLE hLookups);
LF_ERROR    ContextRule_existsInKeepTable(GlyphList* keepList, LF_VECTOR* glyphs);
LF_ERROR    ContextRule_collectGlyphs(context_rule* cr, GlyphList* keepList, TABLE_HANDLE hTable);

#ifdef __cplusplus
}
#endif

#endif //__CONTEXT_RULE_H__
