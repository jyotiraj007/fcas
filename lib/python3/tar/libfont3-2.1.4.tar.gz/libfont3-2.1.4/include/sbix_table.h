// Copyright (C) 2016 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// sbix_table.h

#include <stdio.h>
#include "data_types.h"
#include "offset_table_sfnt.h"
#include "lf_core.h"

#ifndef __SBIX_TABLE_H__
#define __SBIX_TABLE_H__

typedef struct _sbix_mask_info
{
    ULONG maskOffset;           // Offset(from the beginning of the 'sbix' table) to the mask data
    ULONG graphicType;          // (FourCharCode)Type of the masked graphic data(not of the mask).Currently, only 'jpg ', 'pdf ', 'png ', and 'tiff' are defined.
    BYTE* data;                 // The actual masked graphic data.The total length is inferred from sequential glyphDataOffsets.
} sbix_mask_info;

typedef struct _sbix_mask_data_
{
    ULONG maskLength;           // Length of the mask data(including this header)
    USHORT reserved;            // Currently unused; set to 0.
    USHORT blendingMode;        // Indicates how the mask is to be applied.
    SHORT originOffsetX;        // The x - value of the point in the glyph relative to its lower - left corner which corresponds to the origin of the glyph on the screen, that is the point on the baseline at the left edge of the glyph.
    SHORT originOffsetY;        // The y - value of the point in the glyph relative to its lower - left corner which corresponds to the origin of the glyph on the screen, that is the point on the baseline at the left edge of the glyph.
    ULONG graphicType;          // (FourCharCode) Indicates the graphic type of the mask and relieves clients of the need to parse the graphic data in order to determine the data type.Currently, only 'jpg ', 'png ', and 'tiff' are defined.
    BYTE* data;                 // The actual embedded mask data.
} sbix_mask_data;

typedef struct _sbix_glyph_
{
    SHORT originOffsetX;            // The x - value of the point in the glyph relative to its lower - left corner which corresponds to the origin of the glyph on the screen, that is the point on the baseline at the left edge of the glyph.
    SHORT originOffsetY;            // The y - value of the point in the glyph relative to its lower - left corner which corresponds to the origin of the glyph on the screen, that is the point on the baseline at the left edge of the glyph.
    ULONG graphicType;              // (FourCharCode) Indicates the type of graphic and relieves clients of the need to parse the graphic data in order to determine the data type.Currently, only 'jpg ', 'pdf ', 'png ', and 'tiff' are defined.

    ULONG dataSize;                 // Size of raw data (or mask info/data)
    union
    {
        BYTE* raw;                  // The actual embedded graphic data.The total length is inferred from sequential glyphDataOffsets.
        sbix_mask_info* mask;
    } data;

} sbix_glyph;

typedef struct _sbix_strike_
{
    USHORT ppem;                    // The PPEM for which this strike was designed(e.g., 9, 12, 24)
    USHORT resolution;              // The screen resolution(in dpi) for which this strike was designed(e.g., 72)


    boolean hasDupes;               // TRUE if the strike has glyphs which reference other glyphs

    LF_MAP glyphs;                  // Key = glyphID, data = sbix_glyph*; map contains entries for only the glyphs which are present in the strike
} sbix_strike;

typedef struct _sbix_table_
{
    USHORT version;                 // Version number(set to 1)
    USHORT flags;                   // The only two bits used in the flags field are bits 0 and 1. For historical reasons, bit 0 must always be 1. 
                                    // Bit 1 is a sbixDrawOutlines flag and is interpreted as follows: 0 Draw only 'sbix' bitmaps : 1 Draw both 'sbix' bitmaps and outlines, in that order.
                                    // The other bits in the flags field should be set to zero.
    ULONG numStrikes;               // Number of bitmap strikes to follow

    LF_VECTOR strikes;              // vector of [numStrikes] sbix_strike*

    LF_MAP  masks;                  // map of key = original offset, data = sbix_mask_data*. Use map so only one copy is written.

} sbix_table;


#ifdef __cplusplus
extern "C" {
#endif

LF_ERROR    SBIX_readTable(LF_FONT* lfFont, const sfnt_table_record* record, LF_STREAM* stream);
LF_ERROR    SBIX_removeGlyph(LF_FONT* lfFont, ULONG index);
LF_ERROR    SBIX_remapTable(LF_FONT* lfFont, LF_MAP *glyphIndexMap);
LF_ERROR    SBIX_isTableEmpty(LF_FONT* lfFont);
LF_ERROR    SBIX_getTableSize(LF_FONT* lfFont, size_t* tableSize);
LF_ERROR    SBIX_writeTable(LF_FONT* lfFont, sfnt_table_record* record, LF_STREAM* stream);
LF_ERROR    SBIX_freeTable(LF_FONT* lfFont);

#ifdef __cplusplus
}
#endif

#endif //__SBIX_TABLE_H__
