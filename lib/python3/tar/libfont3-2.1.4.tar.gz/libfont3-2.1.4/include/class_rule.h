// Copyright (C) 2014 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// class_rule.h

#ifndef __CLASS_RULE_H__
#define __CLASS_RULE_H__

#include "data_types.h"
#include "stream.h"
#include "lf_error.h"
#include "lf_vector.h"
#include "coverage_table.h"
#include "classdef.h"

#ifdef __cplusplus
extern "C" {
#endif


/* ----------------------------------------------------------------------------

    Class rule contains a count for substitutions to be performed on
    the context (LookupCount) and an array of lookup records (LookupRecords)
    that supply the lookup record script data.  For each position in the
    context that requires a substitution or position, a LookupRecord specifies
    a LookupList index and a position in the input glyph sequence where the
    lookup is applied.  The LookupRecord array lists LookupRecords in design
    order-that is, the order in which lookups should be applied to the
    entire glyph sequence.

---------------------------------------------------------------------------- */
typedef struct __class_rule__
{
    USHORT           InputClass;            // Starting class.  Represents the GlyphCount - 1 value.

    USHORT           GlyphCount;            // Total number of classes specified for
                                            // the context in the rule-includes the 
                                            // first class

    USHORT           LookupCount;           // Number of LookupRecords

    LF_VECTOR        Class;                 // Array of classes-beginning with the 
                                            // second class-to be matched to the 
                                            // input glyph class sequence
                                            // Class[GlyphCount - 1]

    LF_VECTOR        LookupRecords;         // vector array of LookupRecord
                                            // structures.
                                            // LookupRecords[SubstCount]
} class_rule;


// Class Rules
void        ClassRule_freeRule(class_rule* cr);
LF_ERROR    ClassRule_readRule(class_def* cd, class_rule* cr, LF_STREAM* stream);
size_t      ClassRule_sizeRule(class_rule* cr);
LF_ERROR    ClassRule_buildRule(class_rule* scr, LF_STREAM* stream);
LF_ERROR    ClassRule_isClassReferenced(class_rule* rule, USHORT classref, USHORT classstart);
LF_ERROR    ClassRule_isClassSequenceReferenced(LF_VECTOR* sequence, USHORT classref, USHORT classstart);
LF_ERROR    ClassRule_validateClassSequence(LF_VECTOR* sequence, class_def* cd, USHORT classstart);
LF_ERROR    ClassRule_cleanupLookups(class_rule* cr, TABLE_HANDLE hLookup);
LF_ERROR    ClassRule_collectGlyphs(class_rule* cr, GlyphList* keepList, TABLE_HANDLE hTable, class_def* classdef);

#ifdef LF_OT_DUMP
void        ClassRule_dumpRule(class_rule* cr);
#endif

#ifdef __cplusplus
}
#endif

#endif //__CLASS_RULE_H__
