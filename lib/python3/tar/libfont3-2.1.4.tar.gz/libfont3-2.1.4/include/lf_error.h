// Copyright (C) 2014, 2016 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
/// \file lf_error.h

#ifndef __LF_ERROR_H__
#define __LF_ERROR_H__

#include <stdio.h>

#ifdef __cplusplus
extern "C" {
#endif

/**
   Enumerated list of error codes
 */
typedef enum
{
    LF_ERROR_OK           =    0x0000,  ///< 0x0000

    LF_ADDED_GLYPH        =    0x0001,  ///< 0x0001

    LF_BAD_FORMAT         =    0x0100,  ///< 0x0100
    LF_NOT_COVERED        =    0x0101,  ///< 0x0101
    LF_EMPTY_TABLE        =    0x0102,  ///< 0x0102
    LF_OUT_OF_MEMORY      =    0x0104,  ///< 0x0104
    LF_INVALID_SUBTABLE   =    0x0108,  ///< 0x0108
    LF_INVALID_OFFSET     =    0x0109,  ///< 0x0109
    LF_INVALID_LENGTH     =    0x0110,  ///< 0x0110
    LF_INVALID_INDEX      =    0x0111,  ///< 0x0111
    LF_INVALID_TYPE       =    0x0112,  ///< 0x0112
    LF_FILE_OPEN_FAIL     =    0x0113,  ///< 0x0113
    LF_FILE_OPEN_WRITE    =    0x0114,  ///< 0x0114
    LF_TABLE_MISSING      =    0x0115,  ///< 0x0115
    LF_MAXP_CFF_MISMATCH  =    0x0116,  ///< 0x0116

    LF_UNSUPPORTED        =    0x0200,  ///< 0x0200
    LF_INVALID_PARAM      =    0x0201,  ///< 0x0201
    LF_STREAM_OVERRUN     =    0x0202,  ///< 0x0202
    LF_COMPRESSION        =    0x0203,  ///< 0x0203
    LF_CONVERSION         =    0x0204,  ///< 0x0204

    LF_REFIT              =    0x0210,  ///< 0x0210
    LF_COMPONENTIZE       =    0x0211,  ///< 0x0211

    LF_UNIMPLEMENTED      =    0x0300,   ///< 0x0300

    LF_HARMONIZE_PATHS      =   0x0400,     ///< 0x0400     The output path must be different from the input path.
    LF_HARMONIZE_NUM_GLYPHS =   0x0401,     ///< 0x0401     All the input fonts must have the same number of glyphs.
    LF_HARMONIZE_CMAP       =   0x0402,     ///< 0x0402     The fonts do not have the glyphs in the same order.
    LF_HARMONIZE_COMPOSITES =   0x0403,     ///< 0x0403     The fonts do not have composites at the same indexes, or components are different
    LF_HARMONIZE_POST_NAMES =   0x0404,     ///< 0x0404     The post table names of glyphs are not the same in all the fonts
    LF_HARMONIZE_POST_VERS  =   0x0405,     ///< 0x0405     The fonts do not all have the same post table version, or have an unsupported version
    LF_HARMONIZE_CONTOURS   =   0x0406,     ///< 0x0406     The fonts do not all have the same number of contours in the glyphs
    LF_HARMONIZE_UPM        =   0x0407,     ///< 0x0407     The fonts do not all have the same unitsPerEm
    LF_HARMONIZE_ALGORITHM  =   0x0408,     ///< 0x0408     An error occurred in the harmonzer algorithm
    LF_HARMONIZE_FONT_TYPES =   0x0409      ///< 0x0409     The input fonts do not all have the same type
} LF_ERROR;

#ifdef __cplusplus
}
#endif

#endif //__LF_ERROR_H__
