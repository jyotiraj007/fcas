// Copyright (C) 2014 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// ltsh_table.h

#include <stdio.h>
#include "lf_core.h"
#include "stream.h"
#include "offset_table_sfnt.h"

#ifndef __LTSH_TABLE_H__
#define __LTSH_TABLE_H__

#ifdef __cplusplus
extern "C" {
#endif

#define LTSH_MARK_REMOVED 0

typedef struct _ltsh_table
{
    USHORT    version;        //Table version number (0)
    USHORT    numGlyphs;      //Number of glyphs (from “numGlyphs” in 'maxp' table).
    LF_VECTOR yPels;          //The vertical pel height at which the glyph can be assumed to scale linearly. On a per glyph basis.
} ltsh_table;


LF_API LF_ERROR    LTSH_readTable(LF_FONT* lfFont, const sfnt_table_record* record, LF_STREAM* stream);
LF_API LF_ERROR    LTSH_getTableSize(LF_FONT* lfFont, size_t* tableSize);
LF_API LF_ERROR    LTSH_writeTable(LF_FONT* lfFont, sfnt_table_record* record, LF_STREAM* stream);
LF_API LF_ERROR    LTSH_freeTable(LF_FONT* lfFont);
LF_API LF_ERROR    LTSH_removeGlyph(LF_FONT* lfFont, ULONG index);

#ifdef __cplusplus
}
#endif

#endif //__LTSH_TABLE_H__
