// Copyright (C) 2014 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// attachement_list.h

#include "data_types.h"
#include "stream.h"
#include "lf_error.h"
#include "coverage_table.h"
#include "lf_vector.h"
#include "stream.h"

#ifndef __ATTACHMENT_LIST_H__
#define __ATTACHMENT_LIST_H__

#ifdef __cplusplus
extern "C" {
#endif

typedef struct _attachment_list
{
    coverage_table    Coverage;    //Offset to Coverage table - from beginning of AttachList table
    LF_VECTOR        AttachPoints;
} attachment_list;

LF_ERROR AttachmentList_readTable(attachment_list* list, LF_STREAM* stream);
LF_ERROR AttachmentList_getTableSize(attachment_list* list, size_t* tableSize);
LF_ERROR AttachmentList_buildTable(attachment_list* list, LF_STREAM* stream);
LF_ERROR AttachmentList_freeTable(attachment_list* list);

#ifdef __cplusplus
}
#endif

#endif //__ATTACHMENT_LIST_H__
