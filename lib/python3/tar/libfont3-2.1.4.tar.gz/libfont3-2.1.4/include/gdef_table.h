// Copyright (C) 2014, 2015 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// gdef_table.h

#ifndef __GDEF_TABLE_H__
#define __GDEF_TABLE_H__

#include "offset_table_sfnt.h"
#include "attachment_list.h"
#include "lig_caret_list.h"
#include "classdef.h"

#ifdef __cplusplus
extern "C" {
#endif

typedef struct _gdef_header
{
    ULONG            Version;               //Version of the GDEF table-currently 0x00010000
    class_def        GlyphClassDef;         //Offset to class definition table for glyph type-from beginning of GDEF header (may be NULL)
    attachment_list  AttachList;            //Offset to list of glyphs with attachment points-from beginning of GDEF header (may be NULL)
    lig_caret_list   LigCaretList;          //Offset to list of positioning points for ligature carets-from beginning of GDEF header (may be NULL)
    class_def        MarkAttachClassDef;    //Offset to class definition table for mark attachment type-from beginning of GDEF header (may be NULL)
    OFFSET           MarkGlyphSetsDef;      //Offset to the table of mark set definitions - from beginning of GDEF header (may be NULL)

    boolean         isValid;                // Whether the table is valid (no validation is done yet)
    size_t          calculatedTableSize;    // size in bytes of table if written, 0 if table is dirty
} gdef_header;

LF_ERROR    GDEF_readTable(LF_FONT* lfFont, const sfnt_table_record* record, LF_STREAM* stream);
boolean     GDEF_isValid(LF_FONT* lfFont);
LF_ERROR    GDEF_isTableEmpty(LF_FONT* lfFont);
LF_ERROR    GDEF_getTableSize(LF_FONT* lfFont, size_t* tableSize);
LF_ERROR    GDEF_writeTable(LF_FONT* lfFont, sfnt_table_record* record, LF_STREAM* stream);
LF_ERROR    GDEF_freeTable(LF_FONT* lfFont);
void        GDEF_removeGlyph(LF_FONT* lfFont, GlyphID index);
LF_ERROR    GDEF_remapAll(LF_FONT* lfFont, LF_MAP* remap);

#ifdef __cplusplus
}
#endif

#endif //__GDEF_TABLE_H__
