// Copyright (C) 2014 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// dsig_table.h

#ifndef __DSIG_TABLE_H__
#define __DSIG_TABLE_H__

#include "offset_table_sfnt.h"

#ifdef __cplusplus
extern "C" {
#endif


#if 0 // The functions below are not yet implemented.
struct dsig_header
{
    ULONG    ulVersion;    //Version number of the DSIG table (0x00000001)
    USHORT   usNumSigs;    //Number of signatures in the table
    USHORT   usFlag;       //permission flags
                           //Bit 0: cannot be resigned
                           //Bits 1-7: Reserved (Set to 0)
};

struct dsig_sig_header
{
    ULONG    ulFormat;    //format of the signature
    ULONG    ulLength;    //Length of signature in bytes
    ULONG    ulOffset;    //Offset to the signature block from the beginning of the table
};

struct dsig_signature
{
    USHORT   usReserved1;      //Reserved for later use; 0 for now
    USHORT   usReserved2;      //Reserved for later use; 0 for now
    ULONG    cbSignature;      //Length (in bytes) of the PKCS#7 packet in pbSignature
    BYTE     bSignature[1];    //PKCS#7 packet
};

LF_ERROR    DSIG_readTable(LF_FONT* lfFont, const sfnt_table_record* record, LF_STREAM* stream);
LF_ERROR    DSIG_getTableSize(LF_FONT* lfFont, size_t* tableSize);
LF_ERROR    DSIG_writeTable(LF_FONT* lfFont, sfnt_table_record* record, LF_STREAM* stream);
LF_ERROR    DSIG_freeTable(LF_FONT* lfFont, const sfnt_table_record* record);

//sfnt_table_record*    DSIG_updateRecord(sfnt_table_record *record);
#endif

#ifdef __cplusplus
}
#endif

#endif //__DSIG_TABLE_H__
