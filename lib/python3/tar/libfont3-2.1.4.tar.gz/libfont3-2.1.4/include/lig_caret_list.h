// Copyright (C) 2014 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// lig_caret_list.h

#include "data_types.h"
#include "stream.h"
#include "lf_error.h"
#include "coverage_table.h"
#include "lf_vector.h"
#include "device_table.h"

#ifndef __LIG_CARET_LIST_H__
#define __LIG_CARET_LIST_H__

#ifdef __cplusplus
extern "C" {
#endif

typedef struct _caret_value
{
    USHORT        CaretValueFormat;   //Format identifier

    SHORT         Coordinate;         //X or Y value, in design units
    USHORT        CaretValuePoint;    //Contour point index on glyph
    device_table  DeviceTable;        //Offset to Device table for X or Y value-from beginning of CaretValue table
} caret_value;

typedef struct _lig_caret_list
{
    coverage_table   Coverage;    //Offset to Coverage table - from beginning of LigCaretList table
    LF_VECTOR        LigGlyph;
} lig_caret_list;

LF_ERROR LigCaretList_readTable(lig_caret_list* list, LF_STREAM* stream);
LF_ERROR LigCaretList_getTableSize(lig_caret_list* list, size_t* tableSize);
LF_ERROR LigCaretList_buildTable(lig_caret_list* list, LF_STREAM* stream);
LF_ERROR LigCaretList_freeTable(lig_caret_list* list);

#ifdef __cplusplus
}
#endif

#endif //__LIG_CARET_LIST_H__
