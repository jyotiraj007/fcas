// Copyright (C) 2014 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// norm_nfc.h

#ifndef __NORM_NFC_H__
#define __NORM_NFC_H__

#include "data_types.h"
#include "lf_error.h"
#include "norm_nrmtxt.h"

#ifdef __cplusplus
extern "C" {
#endif

/*****************************************************************************
 *
 *  Composes a string to Normalization Form C (NFC).
 *
 *  Parameters:
 *      inputTextObj    - [in] the input text object
 *      inputStartIndex - [in] the start index for the input text
 *      inputEndIndex   - [in] the end index for the input text
 *
 *      outputTextObj    - [out] the output text object
 *      outputStartIndex - [in]  the start index for the output text
 *      outputEndIndex   - [out] the actual end index of the NFC composed text (this is an "out" only, not an "in" -- the "in" end index is (size-1) and can grow)
 *
 *      bufferForNFDObj        - [out] the buffer text object for temporary NFD storage
 *      (start index is 0, end index is (size-1) and can grow)
 *
 *  Return value:
 *      Result code -- TS_OK if all went well, error code otherwise.
 *
 *  <GROUP normalization>
 */

LF_API LF_ERROR TsNorm_composeStringToNFC(
    const TsNormTextObj *inputTextObj,
    LONG       inputStartIndex,
    LONG       inputEndIndex,

    TsNormTextObj *outputTextObj,
    LONG       outputStartIndex,
    LONG       *outputEndIndex,

    TsNormTextObj *bufferForNFDObj
);

#ifdef __cplusplus
}
#endif


#endif /* __NORM_NFC_H__ */

