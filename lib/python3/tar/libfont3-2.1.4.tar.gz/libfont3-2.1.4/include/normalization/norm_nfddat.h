// Copyright (C) 2014 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// norm_nfddat.h


#ifndef __NORM_NFDDAT_H__
#define __NORM_NFDDAT_H__

#include "data_types.h"


#ifdef __cplusplus
extern "C" {
#endif


#define TS_NUM_DECOMPOSITION_GROUPS 204


typedef struct DecompositionIndexType_ {
    ULONG start;
    USHORT length;
    USHORT tableNumAndIndex;
} DecompositionIndexType;


typedef struct DecompositionDataType0_ {
    USHORT decompChar1;
    USHORT decompChar2;
} DecompositionDataType0;


typedef struct DecompositionDataType1_ {
    USHORT decompChar1;
} DecompositionDataType1;


typedef struct DecompositionDataType2_ {
    ULONG decompChar1;
    ULONG decompChar2;
} DecompositionDataType2;


typedef struct DecompositionDataType3_ {
    ULONG decompChar1;
} DecompositionDataType3;


extern const DecompositionIndexType     decompositionIndex[];

extern const DecompositionDataType0     decompositionData0[];
extern const DecompositionDataType1     decompositionData1[];
extern const DecompositionDataType2     decompositionData2[];
extern const DecompositionDataType3     decompositionData3[];


#ifdef __cplusplus
}
#endif


#endif /* __NORM_NFDDAT_H__ */
