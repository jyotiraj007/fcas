// Copyright (C) 2014 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// norm_nfcdat.h

#ifndef __NORM_NFCDAT_H__
#define __NORM_NFCDAT_H__

#include "data_types.h"

#ifdef __cplusplus
extern "C" {
#endif

typedef BYTE CompositionMetaIndexType;


typedef struct CompositionIndexType_
{
    ULONG decompChar1Min;
    ULONG decompChar1Max;
    ULONG decompChar2Min;
    ULONG decompChar2Max;
    USHORT index;
    USHORT length;
} CompositionIndexType;


typedef struct CompositionDataType_
{
    BYTE  decompChar1;
    BYTE  decompChar2;
    ULONG compositeChar;
} CompositionDataType;


extern const CompositionDataType       compositionData[];
extern const CompositionIndexType      compositionIndex[];
extern const CompositionMetaIndexType  compositionMetaIndex[];

extern const USHORT                  jamoTable[];

#define SENTINEL_VALUE   0xFF
#define BLOCK_FULL_VALUE 0xFE
#define NUM_COMPATIBILITY_JAMO_SUPPORTED 94


#ifdef __cplusplus
}
#endif


#endif /* __NORM_NFCDAT_H__ */
