// Copyright (C) 2014 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// norm_uniprp.h

/****************************************************************************
 *
 *  This is a private file used for accessing general Unicode character properties.
 *  It was generated using the Python script GeneralPropertiesTrie.py.
 *  and properties data available at http://www.unicode.org/Public/UNIDATA/
 *  Unicode Version = Unicode 6.2.0
 *  Repertoire = All Unicode characters
 *  Generated on Tue 05 Feb 2013 @ 14:30:21
 *
 *  Index array  = 4032 entries,  8064 bytes
 *  LUT array    = 5210 entries,  5210 bytes
 *  Props array  =  239 entries,   956 bytes
 *
 *  Total Bytes = 14230
 *
 ****************************************************************************/

#ifndef __NORM_UNIPRP_H__
#define __NORM_UNIPRP_H__

#ifdef __cplusplus
extern "C" {
#endif

#include "data_types.h"

#define TS_GENERAL_PROPS_TRIPLE_INDEX

#define TS_GENERAL_PROPS_INDEX_MASK_A   0x001ff000
#define TS_GENERAL_PROPS_INDEX_MASK_B   0x00000f80
#define TS_GENERAL_PROPS_INDEX_MASK_C   0x00000078
#define TS_GENERAL_PROPS_INDEX_MASK_D   0x00000007

#define TS_GENERAL_PROPS_INDEX_SHIFT_A      12
#define TS_GENERAL_PROPS_INDEX_SHIFT_B      7
#define TS_GENERAL_PROPS_INDEX_SHIFT_C      3
#define TS_GENERAL_PROPS_INDEX_SHIFT_D      0

#define TS_GENERAL_CATEGORY_MASK        0x0000001f
#define TS_LINE_BREAK_MASK              0x000007e0
#define TS_WORD_BREAK_MASK              0x00007800
#define TS_GRAPHEME_BREAK_MASK          0x00078000
#define TS_COMBINING_CLASS_MASK         0x01f80000
#define TS_COMBINING_LETTERS_MASK       0x02000000
#define TS_COMPOSITION_EXCLUSION_MASK   0x04000000

#define TS_GENERAL_CATEGORY_SHIFT       0x00000000
#define TS_LINE_BREAK_SHIFT             0x00000005
#define TS_WORD_BREAK_SHIFT             0x0000000b
#define TS_GRAPHEME_BREAK_SHIFT         0x0000000f
#define TS_COMBINING_CLASS_SHIFT        0x00000013

extern const USHORT tsGeneralPropsIndex[];
extern const USHORT tsGeneralPropsLut[];
extern const ULONG tsGeneralPropsArray[];

#ifdef __cplusplus
}
#endif

#endif /* __NORM_UNIPRP_H__ */
