// Copyright (C) 2014 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
/// \file lf_valign.h

#ifndef __LF_VALIGN_H__
#define __LF_VALIGN_H__

#include "lf_core.h"
#include "lf_error.h"

#ifdef __cplusplus
extern "C" {
#endif

LF_API LF_ERROR LF_applyVerticalAlignment(LF_FONT* lfFont);

#ifdef __cplusplus
}
#endif

#endif // end of __LF_VALIGN_H__
