// Copyright (C) 2016 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// fvar_table.h

#include <stdio.h>
#include "data_types.h"
#include "offset_table_sfnt.h"
#include "lf_core.h"

#ifndef __FVAR_TABLE_H__
#define __FVAR_TABLE_H__

#ifdef __cplusplus
extern "C" {
#endif

typedef struct _sfnt_variation_axis_
{
    ULONG axisTag;                  // Axis name.
    FIXED minValue;                 // The minimum style coordinate for the axis.
    FIXED defaultValue;             // The default style coordinate for the axis.
    FIXED maxValue;                 // The maximum style coordinate for the axis.
    USHORT flags;                   // Set to zero.
    USHORT nameID;                  // The designation in the 'name' table.
} sfnt_variation_axis;

typedef struct _sfnt_instance_
{
    USHORT nameID;                  // nameID 	The name of the defined instance coordinate.Similar to the nameID in the variation axis record, this identifies a name in the font's 'name' table.
    USHORT flags;                   // Set to zero.
    LF_VECTOR coords;               // This is the coordinate of the defined instance. (vector of FIXEDs)
} sfnt_instance;

typedef struct _fvar_table
{
    FIXED  version;                 // Set to 1.0 (0x10000).
    USHORT offsetToData;            // Offset in bytes from the beginning of the table to the beginning of the first axis data.
    USHORT countSizePairs;          // Axis + instance = 2.
    USHORT axisCount;               // The number of style axes in this font.
    USHORT axisSize;                // The number of bytes in each gxFontVariationAxis record.Set to 20 bytes.
    USHORT instanceCount;           // The number of named instances for the font found in the sfntInstance array.
    USHORT instanceSize;            // The number of bytes in each gxFontInstance array.InstanceSize = axisCount * sizeof(gxShortFrac).

    LF_VECTOR axisArray;            // The font variation axis array. (vector of sfnt_variation_axis*)
    LF_VECTOR instanceArray;        // The instance array. (vector of sfnt_instance*)

    // old way
    BYTE* data;
    ULONG length;
} fvar_table;

LF_ERROR FVAR_readTable(LF_FONT* lfFont, const sfnt_table_record* record, LF_STREAM* stream);
LF_ERROR FVAR_getAxisCount(LF_FONT* lfFont, USHORT* count);
LF_ERROR FVAR_getAxisTag(LF_FONT* lfFont, USHORT axis, ULONG* tag);
LF_ERROR FVAR_getAxisCoordinates(LF_FONT* lfFont, USHORT axis, FIXED* min, FIXED* dflt, FIXED* max);
LF_ERROR FVAR_getAxisNameID(LF_FONT* lfFont, USHORT axis, USHORT* id);
LF_ERROR FVAR_getInstanceCount(LF_FONT* lfFont, USHORT* count);
LF_ERROR FVAR_getInstanceNameID(LF_FONT* lfFont, USHORT instance, USHORT* id);
LF_ERROR FVAR_getInstanceCoords(LF_FONT* lfFont, USHORT instance, FIXED* coordArray, USHORT avail);
LF_ERROR FVAR_getTableSize(LF_FONT* lfFont, size_t* tableSize);
LF_ERROR FVAR_writeTable(LF_FONT* lfFont, sfnt_table_record* record, LF_STREAM* stream);
LF_ERROR FVAR_freeTable(LF_FONT* lfFont);

#ifdef __cplusplus
}
#endif

#endif //__FVAR_TABLE_H__
