// Copyright (C) 2014, 2015 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// glyf_table.h

#ifndef __GLYF_TABLE_H__
#define __GLYF_TABLE_H__

#include "lf_core.h"
#include "offset_table_sfnt.h"
#include "table_tags.h"
#include "maxp_table.h"
#include "keep_table.h"

#ifdef __cplusplus
extern "C" {
#endif

#define FLAG_ON_CURVE                  0x00000001    //If set, the point is on the curve; otherwise, it is off the curve.
#define FLAG_X_SHORT_VECTOR            0x00000002    //If set, the corresponding x-coordinate is 1 byte long. If not set, 2 bytes.
#define FLAG_Y_SHORT_VECTOR            0x00000004    //If set, the corresponding y-coordinate is 1 byte long. If not set, 2 bytes.
#define FLAG_REPEAT                    0x00000008    //If set, the next byte specifies the number of additional times this set of 
                                                     //flags is to be repeated. In this way, the number of flags listed can be smaller 
                                                     //than the number of points in a character.
#define FLAG_X_SAME                    0x00000010    //This flag has two meanings, depending on how the x-Short Vector flag is set. If 
                                                     //x-Short Vector is set, this bit describes the sign of the value, with 1 equalling 
                                                     //positive and 0 negative. If the x-Short Vector bit is not set and this bit is set, 
                                                     //then the current x-coordinate is the same as the previous x-coordinate. If the 
                                                     //x-Short Vector bit is not set and this bit is also not set, the current x-coordinate 
                                                     //is a signed 16-bit delta vector.
#define FLAG_Y_SAME                    0x00000020    //This flag has two meanings, depending on how the y-Short Vector flag is set. If 
                                                     //y-Short Vector is set, this bit describes the sign of the value, with 1 equalling 
                                                     //positive and 0 negative. If the y-Short Vector bit is not set and this bit is set, 
                                                     //then the current y-coordinate is the same as the previous y-coordinate. If the 
                                                     //y-Short Vector bit is not set and this bit is also not set, the current y-coordinate 
                                                     //is a signed 16-bit delta vector.

#define ARG_1_AND_2_ARE_WORDS          0x00000001    //If this is set, the arguments are words; otherwise, they are bytes.
#define ARGS_ARE_XY_VALUES             0x00000002    //If this is set, the arguments are xy values; otherwise, they are points.
#define ROUND_XY_TO_GRID               0x00000004    //For the xy values if the preceding is true.
#define WE_HAVE_A_SCALE                0x00000008    //This indicates that there is a simple scale for the component. Otherwise, scale = 1.0.
#define GLYF_RESERVED                  0x00000010    //This bit is reserved. Set it to 0.
#define MORE_COMPONENTS                0x00000020    //Indicates at least one more glyph after this one.
#define WE_HAVE_AN_X_AND_Y_SCALE       0x00000040    //The x direction will use a different scale from the y direction.
#define WE_HAVE_A_TWO_BY_TWO           0x00000080    //There is a 2 by 2 transformation that will be used to scale the component.
#define WE_HAVE_INSTRUCTIONS           0x00000100    //Following the last component are instructions for the composite character.
#define USE_MY_METRICS                 0x00000200    //If set, this forces the aw and lsb (and rsb) for the composite to be equal to those from this original glyph. This works for hinted and unhinted characters.
#define OVERLAP_COMPOUND               0x00000400    //Used by Apple in GX fonts.
#define SCALED_COMPONENT_OFFSET        0x00000800    //Composite designed to have the component offset scaled (designed for Apple rasterizer).
#define UNSCALED_COMPONENT_OFFSET      0x00001000    //Composite designed not to have the component offset scaled (designed for the Microsoft TrueType rasterizer).

typedef struct _glyph_point
{
    BYTE    flag;
    SHORT   xCoordinate;
    SHORT   yCoordinate;
    boolean endpoint;
} glyph_point;

typedef struct _simple_glyf
{
    USHORT*  endPtsOfContours;     //Array of last points of each contour; n is the number of contours.
    USHORT   instructionLength;    //Total number of bytes for instructions.
    BYTE*    instructions;         //Array of instructions for each glyph; n is the number of instructions.
    BYTE*    flags;                //Array of flags for each coordinate in outline; n is the number of flags.
    SHORT*   xCoordinates;         //First coordinates relative to (0,0); others are relative to previous point.
    SHORT*   yCoordinates;         //First coordinates relative to (0,0); others are relative to previous point.

    glyph_point*    points;
} simple_glyf;

typedef struct _composite_glyf
{
    USHORT   flags;         //component flag
    USHORT   glyphIndex;    //glyph index of component

    SHORT    argument1;     //x-offset for component or point number; type depends on bits 0 and 1 in component flags
    SHORT    argument2;     //y-offset for component or point number; type depends on bits 0 and 1 in component flags

    F2DOT14  xscale;
    F2DOT14  scale01;
    F2DOT14  scale10;
    F2DOT14  yscale;
} composite_glyf;

typedef struct _glyf
{
    SHORT    numberOfContours;    //If the number of contours is greater than or equal to zero, this is a single glyph; if negative, this is a composite glyph.
    SHORT    xMin;                //Minimum x for coordinate data.
    SHORT    yMin;                //Minimum y for coordinate data.
    SHORT    xMax;                //Maximum x for coordinate data.
    SHORT    yMax;                //Maximum y for coordinate data.

    BYTE*    glyfBlock;
    size_t   glyfSize;

    boolean parsed;

    union _glyf_data
    {
        simple_glyf  simple;
        LF_VECTOR    composite;
    } glyf_data;
} glyf;

typedef struct _glyf_table
{
    glyf*   glyphDataBlock;         // contiguous block which is an array of glyf's
    LF_MAP* glyfMap;                // map containing key = glyph id, value = glyf* (pointers into above block)

    boolean remapped;               // TRUE if the glfMap has been remapped to renumber the glyphs
    boolean maxpInfoUpdated;        // TRUE if the calculated maxp info is up to date
    maxp_table derivedMaxp;         // maxp info transferred to the font's maxp table when font is built
    size_t  calculatedTableSize;    // size in bytes of table if written, 0 if table is dirty
    LF_MAP* remap;                  // map of the original gid vs. the new gid, created when table is reindexed.

} glyf_table;

#define GLYF_HEADER_SIZE    (sizeof(SHORT) * 5)

LF_API LF_ERROR    GLYF_readTable(LF_FONT* lfFont, const sfnt_table_record* record, LF_STREAM* stream);
LF_ERROR           GLYF_createTable(LF_FONT* lfFont, USHORT numGlyphs, boolean populateMap);
LF_API ULONG       GLYF_getCount(LF_FONT* lfFont);
LF_API LF_ERROR    GLYF_getNumContours(LF_FONT* lfFont, ULONG index, SHORT *numContours);
LF_API LF_ERROR    GLYF_getGlyph(LF_FONT* lfFont, glyf* glyf_object, ULONG index);
LF_API LF_ERROR    GLYF_getFullGlyph(LF_FONT* lfFont, glyf* glyf_object, ULONG index);
LF_API void        GLYF_destroyGlyf(glyf* glyf_object);
LF_API LF_ERROR    GLYF_getMAXPInfo(LF_FONT* lfFont, maxp_table* maxpTable, boolean calculate);
LF_API LF_ERROR    GLYF_getBoundingBox(LF_FONT* lfFont, SHORT* xMin, SHORT* yMin, SHORT* xMax, SHORT* yMax);
LF_API LF_ERROR    GLYF_getTableSize(LF_FONT* lfFont, size_t* tableSize);
LF_API LF_ERROR    GLYF_writeTable(LF_FONT* lfFont, sfnt_table_record* record, LF_STREAM* stream);
LF_API LF_ERROR    GLYF_keepGlyphs(LF_FONT* lfFont, GlyphList* keepList);
LF_API void        GLYF_removeGlyph(LF_FONT* lfFont, ULONG index);
LF_API LF_ERROR    GLYF_removeInstructions(LF_FONT* lfFont);
LF_API LF_ERROR    GLYF_remapCompositeGlyfs(LF_FONT* lfFont, LF_MAP *remap);
LF_API LF_ERROR    GLYF_remapTable(LF_FONT* lfFont);
LF_API LF_ERROR    GLYF_replaceGlyph(LF_FONT* lfFont, GlyphID index, glyf* newGlyf);
LF_API LF_ERROR    GLYF_freeTable(LF_FONT* lfFont);

// This is used by SVG routines
LF_ERROR            GLYF_getGlyfPoints(LF_FONT* lfFont, glyf* glyfObject, LF_VECTOR* points);

// These are used by CFF conversion routines
LF_ERROR           GLYF_getGlyf(const glyf_table* table, ULONG index, glyf* glyf_object);
LF_ERROR           GLYF_getGlyfPointsInternal(glyf_table* table, glyf* glyfObject, LF_VECTOR* points);
LF_ERROR           GLYF_getCompositeGlyfPoints(glyf_table* table, glyf* glyfObject, LF_VECTOR* points);

#ifdef __cplusplus
}
#endif

#endif //__GLYF_TABLE_H__
