// Copyright (C) 2014 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// name_table.h

#ifndef __NAME_TABLE_H__
#define __NAME_TABLE_H__

#include "lf_core.h"
#include "offset_table_sfnt.h"
#include "table_tags.h"

#ifdef __cplusplus
extern "C" {
#endif

#define NAME_COPYRIGHT_NOTICE                   0
#define NAME_FONT_FAMILY_NAME                   1
#define NAME_FONT_SUBFAMILY_NAME                2
#define NAME_UNIQUE_SUBFAMILY_IDENTIFICATION    3
#define NAME_FONT_FULL_NAME                     4
#define NAME_VERSION_NAME_TABLE                 5
#define NAME_POSTSCRIPT_FONT_NAME               6
#define NAME_TRADEMARK_NOTICE                   7

typedef struct _lang_tag_record_
{
    USHORT  length;         //Language-tag string length (in bytes)
    USHORT  offset;         //Language-tag string offset from start of storage area (in bytes).

    // INTERNAL
    BYTE* raw;
} lang_tag_record;

typedef struct _name_record_
{
    USHORT  platformID;         //Platform ID.
    USHORT  encodingID;         //Platform-specific encoding ID.
    USHORT  languageID;         //Language ID.
    USHORT  nameID;             //Name ID.
    USHORT  length;             //String length (in bytes).
    USHORT  offset;             //String offset from start of storage area (in bytes).

    // INTERNAL
    BYTE* raw;
} name_record;

typedef struct _name_table_
{
    USHORT  format;             //Format selector (= 0 or 1).
    USHORT  count;              //Number of name records.
    USHORT  stringOffset;       //Offset to start of string storage (from start of table).
    LF_VECTOR nameRecords;      //The name records where count is the number of records.

    USHORT  langTagCount;       //(version 1 only) Number of language-tag records.
    LF_VECTOR langTagRecords;   //(version 1 only) The language-tag records where langTagCount is the number of records.

    BYTE*   storage;            //Storage for the actual string data.

    //INTERNAL
    boolean isParsed;
    boolean modified;           // True if a name string has been changed
    BYTE *data;
    ULONG length;

} name_table;


LF_API LF_ERROR NAME_readTable(LF_FONT* lfFont, const sfnt_table_record* record, LF_STREAM* stream);
LF_API LF_ERROR NAME_parseTable(LF_FONT* lfFont);
LF_API LF_ERROR NAME_getTableSize(LF_FONT* lfFont, size_t* tableSize);
LF_API LF_ERROR NAME_writeTable(LF_FONT* lfFont, sfnt_table_record* record, LF_STREAM* stream);
LF_API LF_ERROR NAME_freeTable(LF_FONT* lfFont);
LF_API LF_ERROR NAME_getNameStringLength(LF_FONT* lfFont, USHORT nameID, USHORT* length);
LF_API LF_ERROR NAME_getNameString(LF_FONT* lfFont, USHORT nameID, BYTE *buffer, USHORT maxLength);
LF_API LF_ERROR NAME_obfuscate(LF_FONT* lfFont);
LF_API LF_ERROR NAME_setNameString(LF_FONT* lfFont, USHORT nameID, const BYTE *buffer, USHORT length);
LF_API LF_ERROR NAME_obfuscateRaw(const BYTE* nameBuf, ULONG length, BYTE** obfuscatedBuf);
LF_API LF_ERROR NAME_getMacNameStringLength(LF_FONT* lfFont, USHORT nameID, USHORT* length);
LF_API LF_ERROR NAME_getMacNameString(LF_FONT* lfFont, USHORT nameID, BYTE *buffer, USHORT maxLength);
LF_API LF_ERROR NAME_setMacNameString(LF_FONT* lfFont, USHORT nameID, const BYTE *buffer, USHORT length);

#ifdef __cplusplus
}
#endif

#endif //__NAME_TABLE_H__
