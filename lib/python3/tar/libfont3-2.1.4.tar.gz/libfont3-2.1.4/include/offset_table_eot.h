// Copyright (C) 2014 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// offset_table_eot.h

#ifndef __OFFSET_EOT_H__
#define __OFFSET_EOT_H__

#include <stdio.h>
#include "data_types.h"
#include "lf_vector.h"
#include "stream.h"
#include "lf_core.h"

#ifdef __cplusplus
extern "C" {
#endif

typedef struct _eot_header      // version 2.1
{
    ULONG   eotSize;            // Total structure length in bytes
    ULONG   fontDataSize;       // Length of FontData in bytes.
    ULONG   version;            // Format version number.
    ULONG   flags;              // Processing flags.
    BYTE    fontPanose[10];     // PANOSE value for this font.
    BYTE    charset;            // Character set fo the font. 
    BYTE    italic;             // Indicates if italic.
    ULONG   weight;             // Weight falue of this font.
    USHORT  fsType;             // Type flags that provide information about embedding permissions.
    USHORT  magicNumber;        // Magic number for EOT file - 0x504C. Used to check for data corruption.
    ULONG   unicodeRange1;      // Unicode range 1   (bits 00-31)
    ULONG   unicodeRange2;      // Unicode range 2   (bits 32-63)
    ULONG   unicodeRange3;      // Unicode range 3   (bits 64-95)
    ULONG   unicodeRange4;      // Unicode range 4   (bits 96-127)
    ULONG   codePageRange1;     // Code page range 1 (bits 00-31)
    ULONG   codePageRange2;     // Code page range 2 (bits 32-63)
    ULONG   checkSumAdjustment; // Head checksum adjustment
    USHORT  familyNameSize;     // Number of bytes used by the FamilyName array
    BYTE   *familyName;         // Array of UTF-16 characters of familyNameSize.
    USHORT  styleNameSize;      // Number of bytes used by the StyleName.
    BYTE   *styleName;          // Array of UTF-16 characters of styleNameSize.
    USHORT  versionNameSize;    // Number of bytes used by the versionName.
    BYTE   *versionName;        // Array of UTF-16 characters of versionNameSize.
    USHORT  fullNameSize;       // Number of bytes used by the fullName.
    BYTE   *fullName;           // Array of UTF-16 characters of fullNameSize.
    USHORT  rootStringSize;     // Number of bytes used by the rootString array.
    BYTE   *rootString;         // Array of UTF-16 characters of rootStringSize.
    BYTE   *fontData;           // The font data for this EOT file. May be compressed or XOR encrypted.

} LF_EOT_HEADER;

typedef struct _eot_offset_table
{
    LF_EOT_HEADER eotHeader;

    //INTERNAL
    boolean srcWasCompressed;
    LF_VECTOR record_list;
} eot_offset_table;


LF_ERROR offset_eot_readTable(LF_STREAM* stream, eot_offset_table** table);
LF_ERROR offset_eot_writeEmbeddedFont(const eot_offset_table* eotTable, LF_STREAM* stream);
LF_ERROR offset_eot_freeTable(LF_FONT* lfFont);

#ifdef __cplusplus
}
#endif

#endif //__OFFSET_EOT_H__
