// Copyright (C) 2016 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// cpal_table.h

#include "data_types.h"
#include "offset_table_sfnt.h"
#include "lf_core.h"

#ifndef __CPAL_TABLE_H__
#define __CPAL_TABLE_H__

#ifdef __cplusplus
extern "C" {
#endif

typedef struct _cpal_table
{
    // The CPAL table is not subsetted, so these are not needed. The table is read/written as a single block.
#if 0
    // V0
    USHORT version;                         // Table version number(= 0) or 1.
    USHORT numPalettesEntries;              // Number of palette entries in each palette.
    USHORT numPalette;                      // Number of palettes in the table.
    USHORT numColorRecords;                 // Total number of color records, combined for all palettes.
    ULONG  offsetFirstColorRecord;          // Offset from the beginning of CPAL table to the first ColorRecord.
    USHORT colorRecordIndices;              // [numPalettes] Index of each palette�s first color record in the combined color record array.

    // V1
    ULONG offsetPaletteTypeArray;           // Offset from the beginning of CPAL table to the Palette Type Array.Set to 0 if no array is provided.
    ULONG offsetPaletteLabelArray;          // Offset from the beginning of CPAL table to the Palette Labels Array.Set to 0 if no array is provided.
    ULONG offsetPaletteEntryLabelArray;     // Offset from the beginning of CPAL table to the Palette Entry Label Array.Set to 0 if no array is provided.
#endif
    ///
    BYTE* data;
    ULONG length;
} cpal_table;

#if 0
typedef struct _color_record_
{
    BYTE blue;      // Blue value(B0).
    BYTE green;     // Green value(B1).
    BYTE red;       // Red value(B2).
    BYTE alpha;     // Alpha value(B3).
} color_record;
#endif


LF_ERROR CPAL_readTable(LF_FONT* lfFont, const sfnt_table_record* record, LF_STREAM* stream);
LF_ERROR CPAL_getTableSize(LF_FONT* lfFont, size_t* tableSize);
LF_ERROR CPAL_writeTable(LF_FONT* lfFont, sfnt_table_record* record, LF_STREAM* stream);
LF_ERROR CPAL_freeTable(LF_FONT* lfFont);

#ifdef __cplusplus
}
#endif

#endif //__CPAL_TABLE_H__
