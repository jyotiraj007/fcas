// Copyright (C) 2014 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// value_record.h

#ifndef __VALUERECORD_TABLE_H__
#define __VALUERECORD_TABLE_H__

#include "data_types.h"
#include "stream.h"


#ifdef __cplusplus
extern "C" {
#endif

#define XPLACEMENT  0x0001      //Includes horizontal adjustment for placement
#define YPLACEMENT  0x0002      //Includes vertical adjustment for placement
#define XADVANCE    0x0004      //Includes horizontal adjustment for advance
#define YADVANCE    0x0008      //Includes vertical adjustment for advance
#define XPLADEVICE  0x0010      //Includes horizontal Device table for placement
#define YPLADEVICE  0x0020      //Includes vertical Device table for placement
#define XADVDEVICE  0x0040      //Includes horizontal Device table for advance
#define YADVDEVICE  0x0080      //Includes vertical Device table for advance

typedef struct _ValueRecord
{
    SHORT    XPlacement;    //Horizontal adjustment for placement-in design units
    SHORT    YPlacement;    //Vertical adjustment for placement-in design units
    SHORT    XAdvance;      //Horizontal adjustment for advance-in design units (only used for horizontal writing)
    SHORT    YAdvance;      //Vertical adjustment for advance-in design units (only used for vertical writing)
    OFFSET   XPlaDevice;    //Offset to Device table for horizontal placement-measured from beginning of PosTable (may be NULL)
    OFFSET   YPlaDevice;    //Offset to Device table for vertical placement-measured from beginning of PosTable (may be NULL)
    OFFSET   XAdvDevice;    //Offset to Device table for horizontal advance-measured from beginning of PosTable (may be NULL)
    OFFSET   YAdvDevice;    //Offset to Device table for vertical advance-measured from beginning of PosTable (may be NULL)
} ValueRecord;

ULONG    getValueRecordSize(USHORT format);
void     readValueRecord(USHORT format, ValueRecord* record, LF_STREAM* stream);
ULONG    writeValueRecord(USHORT format, ValueRecord* record, LF_STREAM* stream);
void     dumpValueRecord(USHORT format, const ValueRecord* record);

#ifdef __cplusplus
}
#endif

#endif //__VALUERECORD_TABLE_H__
