// Copyright (C) 2014 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// cmap_table.h

#ifndef __CMAP_TABLE_H__
#define __CMAP_TABLE_H__

#include "lf_core.h"
#include "stream.h"
#include "offset_table_sfnt.h"
#include "lf_vector.h"


#ifdef __cplusplus
extern "C" {
#endif

typedef struct _cmap_header
{
    USHORT      version;            //Table version number (0).

    USHORT      gidMappingLength;   // Length of below array.
    LONG*       gidMappingArray;    // Array of numGlyphs (from maxp table) LONGs. Initially set all 1 to
                                    // to indicate that the glyph should be kept. Toggled to 0 if the glyph is to
                                    // be removed. Upon remapping, the non-zero entries are renumbered in sequence, and
                                    // the entries that are 0 are set to -1. So the array then contains a mapping from old
                                    // glyph id to new glyph id, and where a -1 entry means that glyph has been removed.
    boolean     remapped;           // TRUE if the gidMappingArray has been remapped.
    ULONG       calculatedSize;     // calculated size of table, 0 indicates that size has not been calculated or the table has changed (glyph removed)
    ULONG       newMinUnicode;      // minimum Unicode after subsetting
    ULONG       newMaxUnicode;      // maximum Unicode after subsetting
    LF_VECTOR   encodings;          // list of the subtables/encodings (pointers to cmap_encoding's)
    LF_VECTOR*  sharedEncodings;    // List of shared_encoding pointers if font has encodings that share the same data NULL otherwise.
} cmap_header;

typedef struct _shared_encoding
{
    USHORT          platformID1;     // Platform ID.
    USHORT          encodingID1;     // Platform-specific encoding ID.
    USHORT          platformID2;     // Platform ID.
    USHORT          encodingID2;     // Platform-specific encoding ID.
    ULONG           newOffset;       // Shared offset
} shared_encoding;

typedef struct _cmap_encoding
{
    USHORT          platformID;     //Platform ID.
    USHORT          encodingID;     //Platform-specific encoding ID.
    ULONG           offset;         //Byte offset from beginning of table to the subtable for this encoding.

    // private
    boolean         srcForMapping;  // TRUE if this subtable should be used to create the gidMappingArray in the header object
    TABLE_HANDLE    subtable;       // pointer to either a cmap_format_4 or a cmap_format_12 if the encoding is supported/parsed, NULL otherwise
} cmap_encoding;

typedef struct _cmap_format_4_segments
{
    LF_VECTOR*    endCount;        //End characterCode for each segment, last=0xFFFF.
    LF_VECTOR*    startCount;      //Start character code for each segment.
    LF_VECTOR*    idDelta;         //Delta for all character codes in segment.
    LF_VECTOR*    idRangeOffset;   //Offsets into glyphIdArray or 0
    LF_VECTOR*    glyphIdArray;    //Glyph index array (arbitrary length)
} cmap_format_4_segments;

typedef struct _cmap_format_4
{
    USHORT        format;           //Format number is set to 4.
    USHORT        length;           //This is the length in bytes of the subtable.
    USHORT        language;         //Please see �Note on the language field in 'cmap' subtables� in this document.
    USHORT        segCountX2;       //2 x segCount.
    USHORT        searchRange;      //2 x (2**floor(log2(segCount)))
    USHORT        entrySelector;    //log2(searchRange/2)
    USHORT        rangeShift;       //2 x segCount - searchRange
    USHORT        reservedPad;      //Set to 0.

    cmap_format_4_segments segs;    // contains the vectors for the segment info
    // private
    USHORT*       forwardMap;       // a 64K array which is a lut made from the table. Input is unicode, output is GID (0 if not mapped).
                                    // Used to avoid doing map_char_4.
    ULONG           firstIndex;
    ULONG           lastIndex;
} cmap_format_4;

typedef struct _cmap_format_12_group
{
    ULONG     startCharCode;     //First character code in this group
    ULONG     endCharCode;       //Last character code in this group
    ULONG     startGlyphID;      //Glyph index corresponding to the starting character code
} cmap_format_12_group;

typedef struct _cmap_format_12
{
    USHORT      format;     //Subtable format; set to 12.
    USHORT      reserved;   //Reserved; set to 0
    ULONG       length;     //Byte length of this subtable (including the header)
    ULONG       language;   //Please see �Note on the language field in 'cmap' subtables� in this document.
    ULONG       nGroups;    //Number of groups

    LF_VECTOR*  groups;     // array of cmap_format_12_group objects
    BYTE*       rawTable;   // buffer containing the raw bytes of the subtable. Currently only used for format12 tables to do map_char_12.
} cmap_format_12;


LF_API LF_ERROR     CMAP_readTable(LF_FONT* lfFont, const sfnt_table_record* record, LF_STREAM* stream);
LF_API LF_ERROR     CMAP_getGlyphID(const LF_FONT* lfFont, ULONG unicode, GlyphID* gid);
LF_API LF_ERROR     CMAP_getRemappedGlyphID(const LF_FONT* lfFont, GlyphID gid, GlyphID *newID);
LF_API LF_ERROR     CMAP_getTableSize(const LF_FONT* lfFont, size_t* tableSize);
LF_API LF_ERROR     CMAP_writeTable(const LF_FONT* lfFont, sfnt_table_record* record, LF_STREAM* stream);
LF_API LF_ERROR     CMAP_removeGlyph(const LF_FONT* lfFont, ULONG index);
LF_API LF_ERROR     CMAP_freeTable(const LF_FONT* lfFont);
LF_API LF_ERROR     CMAP_hasEncoding(const LF_FONT* lfFont, USHORT platformID, USHORT encodingID);
LF_API LF_ERROR     CMAP_getMinMaxRemappedUnicodes(const LF_FONT* lfFont, USHORT *minUni, USHORT *maxUni);
LF_API const cmap_encoding* CMAP_getEncodingRecord(const LF_FONT* lfFont, USHORT platformID, USHORT encodingID);
LF_API GlyphID      CMAP_getIndexFromUnicode(const LF_FONT* lfFont, const cmap_encoding* encodingRecord, ULONG unicode, boolean useRemap);
LF_API LF_ERROR     CMAP_getCount(const LF_FONT* lfFont, USHORT* count);

#ifdef __cplusplus
}
#endif

#endif //__CMAP_TABLE_H__
