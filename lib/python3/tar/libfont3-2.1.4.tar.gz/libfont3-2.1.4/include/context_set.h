// Copyright (C) 2014 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// context_set.h

#include "data_types.h"
#include "stream.h"
#include "lf_error.h"
#include "lf_vector.h"
#include "coverage_table.h"
#include "context_rule.h"

#ifndef __CONTEXT_SET_H__
#define __CONTEXT_SET_H__

#ifdef __cplusplus
extern "C" {
#endif

typedef struct __context_rule_set__
{
    LF_VECTOR    RuleSet;           // Array collection of context_rule tables-from
                                    // beginning of RuleSet table-ordered
                                    // by preference.
} context_rule_set;

LF_ERROR    ContextSet_readRuleSets(LF_VECTOR* rss, USHORT numSets, LF_STREAM* stream, ULONG baseOffset);
LF_ERROR    ContextSet_readRuleSet(context_rule_set* rs, LF_STREAM* stream);
void        ContextSet_freeRuleSets(LF_VECTOR* rss);
void        ContextSet_freeRuleSet(context_rule_set* crs);
size_t      ContextSet_sizeRuleSet(context_rule_set* rs);
size_t      ContextSet_sizeRuleSets(LF_VECTOR* rs);
size_t      ContextSet_buildRuleSet(context_rule_set* rs, LF_STREAM* stream);
#ifdef LF_OT_DUMP
void        ContextSet_dumpSet(context_rule_set* pcs);
#endif
LF_ERROR    ContextSet_pruneRuleSets(LF_VECTOR* RuleSets, coverage_table* table, GlyphID glyphid);
LF_ERROR    ContextSet_remapRuleSets(LF_VECTOR* RuleSets, LF_MAP *remap);
LF_ERROR    ContextSet_cleanupLookups(LF_VECTOR* RuleSets, TABLE_HANDLE hLookups);
LF_ERROR    ContextSet_collectGlyphs(GlyphList* keepList, LF_VECTOR* RuleSets, TABLE_HANDLE hTable, TABLE_HANDLE coverageTable);

#ifdef __cplusplus
}
#endif

#endif //__CONTEXT_SET_H__
