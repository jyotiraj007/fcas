// Copyright (C) 2014 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// vhea_table.h

#include <stdio.h>
#include "data_types.h"
#include "offset_table_sfnt.h"
#include "lf_core.h"
#include "table_tags.h"

#ifndef __VHEA_TABLE_H__
#define __VHEA_TABLE_H__

#ifdef __cplusplus
extern "C" {
#endif


// vhea table spec: http://www.microsoft.com/typography/otspec/vhea.htm


typedef struct _vhea_v10_metrics
{
    SHORT    ascent;                 //Distance in FUnits from the centerline to the previous line�s descent.
    SHORT    descent;                //Distance in FUnits from the centerline to the next line�s ascent.
    SHORT    LineGap;                //Reserved; set to 0
} vhea_v1_metrics;

typedef struct _vhea_v11_metrics
{
    SHORT    vertTypoAscender;       //The vertical typographic ascender for this font.
    SHORT    vertTypoDescender;      //The vertical typographic descender for this font.
    SHORT    vertTypoLineGap;        //The vertical typographic gap for this font.
} vhea_v11_metrics;


typedef struct _vhea_table
{
    FIXED    version;                //0x00010000 for version 1.0.

    union {
        vhea_v1_metrics v10;
        vhea_v11_metrics v11;
    } m;

    SHORT    advanceHeightMax;       //The maximum advance height measurement -in FUnits found in the font.
    SHORT    minTopSideBearing;      //The minimum top sidebearing measurement found in the font, in FUnits.
    SHORT    minBottonSideBearing;   //The minimum bottom sidebearing measurement found in the font, in FUnits.
    SHORT    yMaxExtent;             //Defined as yMaxExtent=minTopSideBearing+(yMax-yMin)
    SHORT    caretSlopeRise;         //The value of the caretSlopeRise field divided by the value of the caretSlopeRun Field determines the slope of the caret.
    SHORT    caretSlopeRun;          //Value=1 for nonslanted vertical fonts.
    SHORT    caretOffset;            //The amount by which a slanted highlight on a glyph needs to be shifted to produce the best appearance. Set to 0 for non-slanted fonts.
    SHORT    reserved1;              //set to 0
    SHORT    reserved2;              //set to 0
    SHORT    reserved3;              //set to 0
    SHORT    reserved4;              //set to 0
    SHORT    metricDataFormat;       //0 for current format.
    USHORT   numberOfVMetrics;       //Number of vMetric entries in 'vmtx' table
} vhea_table;


#define VHEA_TABLE_SIZE (sizeof(FIXED) + (sizeof(SHORT) * 15) + sizeof(USHORT))

LF_API LF_ERROR    VHEA_readTable(LF_FONT* lfFont, const sfnt_table_record* record, LF_STREAM* stream);
LF_API LF_ERROR    VHEA_getTableSize(LF_FONT* lfFont, size_t* tableSize);
LF_API LF_ERROR    VHEA_writeTable(LF_FONT* lfFont, sfnt_table_record* record, LF_STREAM* stream);
LF_API LF_ERROR    VHEA_freeTable(LF_FONT* lfFont);
LF_API USHORT      VHEA_getNumVMetrics(LF_FONT* lfFont);
LF_API void        VHEA_setNumVMetrics(LF_FONT* lfFont, USHORT numVMetrics);
LF_API void        VHEA_setVertTypoLineGap(LF_FONT* lfFont, UFWORD lineGap);
LF_API void        VHEA_setTopSidebearingMin(LF_FONT* lfFont, UFWORD topSidebearingMin);
LF_API void        VHEA_setBottomSidebearingMin(LF_FONT* lfFont, UFWORD bottomSidebearingMin);
LF_API void        VHEA_setAdvanceHeightMax(LF_FONT* lfFont, UFWORD advanceHeightMax);
LF_API void        VHEA_setYMaxExtent(LF_FONT* lfFont, SHORT yMaxExtent);


#ifdef __cplusplus
}
#endif

#endif //__VHEA_TABLE_H__
