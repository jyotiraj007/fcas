// Copyright (C) 2014 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// eot_core.h

#ifndef __EOT_CORE_H__
#define __EOT_CORE_H__

#include "data_types.h"
#include "lf_error.h"
#include "stream.h"


#ifdef __cplusplus
extern "C" {
#endif

LF_ERROR EOT_readOffsetTable(LF_FONT* lfFont, LF_STREAM* stream, int keepFlags);
LF_ERROR EOT_to_SFNT(LF_FONT* lfFont, int keepFlags);
LF_ERROR EOT_getMaxSize(LF_FONT* lfFont, const LF_WRITE_PARAMS *params, size_t* size);
LF_ERROR EOT_writeToStream(LF_FONT* lfFont, const LF_WRITE_PARAMS *params, LF_STREAM* stream);

#ifdef __cplusplus
}
#endif

#endif //__EOT_CORE_H__
