// Copyright (C) 2014 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// mark_array.h

#ifndef __MARK_ARRAY_H__
#define __MARK_ARRAY_H__

#include "data_types.h"
#include "stream.h"
#include "lf_error.h"
#include "anchor.h"
#include "lf_vector.h"

#ifdef __cplusplus
extern "C" {
#endif

typedef struct _mark_record
{
    USHORT          Class;
    anchor_table    MarkAnchor;
} mark_record;

LF_ERROR    Mark_readArray(LF_VECTOR* markArray, LF_STREAM* stream);
LF_ERROR    Mark_getArraySize(LF_VECTOR* markArray, size_t* tableSize);
LF_ERROR    Mark_buildArray(LF_VECTOR* markArray, LF_STREAM* stream);
LF_ERROR    Mark_removeAtIndex(LF_VECTOR* markArray, ULONG index);
LF_ERROR    Mark_setAnchorFormat1(LF_VECTOR* markArray);
void        Mark_freeArray(LF_VECTOR* markArray);

#ifdef LF_OT_DUMP
LF_ERROR    Mark_dumpArray(LF_VECTOR* markArray);
#endif

#ifdef __cplusplus
}
#endif

#endif //__MARK_ARRAY_H__
