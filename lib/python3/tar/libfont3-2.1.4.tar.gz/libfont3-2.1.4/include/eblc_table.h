// Copyright (C) 2016 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// eblc_table.h

#include <stdio.h>
#include "data_types.h"
#include "offset_table_sfnt.h"
#include "lf_core.h"
#include "ebitmap_types.h"

#ifndef __EBLC_TABLE_H__
#define __EBLC_TABLE_H__

#ifdef __cplusplus
extern "C" {
#endif

typedef embedded_loc_table eblc_table;

LF_ERROR EBLC_readTable(LF_FONT* lfFont, const sfnt_table_record* record, LF_STREAM* stream);
LF_ERROR EBLC_removeGlyph(const LF_FONT* lfFont, ULONG index);
LF_ERROR EBLC_remapTable(LF_FONT* lfFont, LF_MAP *remap);
LF_ERROR EBLC_updateMetrics(LF_FONT* lfFont);
LF_ERROR EBLC_getTableSize(LF_FONT* lfFont, size_t* tableSize);
LF_ERROR EBLC_writeTable(LF_FONT* lfFont, sfnt_table_record* record, LF_STREAM* stream);
LF_ERROR EBLC_freeTable(LF_FONT* lfFont);


//private used by CBLC code
LF_ERROR EBLC_parseTable(embedded_loc_table* table, const sfnt_table_record* record, LF_STREAM* stream);
LF_ERROR EBLC_internalRemoveGlyph(embedded_loc_table* table, ULONG index);
LF_ERROR EBLC_internalRemap(LF_FONT* lfFont, embedded_loc_table* table, LF_MAP *remap);
LF_ERROR EBLC_internalUpdate(embedded_loc_table* table, embedded_data_table* dataTable);
LF_ERROR EBLC_internalGetSize(embedded_loc_table* table, size_t* tableSize);
LF_ERROR EBLC_buildTable(embedded_loc_table*table, embedded_data_table* dataTable, ULONG version, BYTE** tableData, size_t* tableSize);
void     EBLC_freeStrikes(embedded_loc_table* table);

#ifdef __cplusplus
}
#endif

#endif //__EBLC_TABLE_H__
