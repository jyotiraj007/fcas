// Copyright (C) 2014, 2015 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// gpos_table.h

#ifndef __GPOS_TABLE_H__
#define __GPOS_TABLE_H__

#include <stdio.h>
#include "data_types.h"
#include "offset_table_sfnt.h"
#include "base_table.h"

#ifdef __cplusplus
extern "C" {
#endif

typedef enum {
    GPOS_SINGLE_ADJUSTMENT           = 1, //Adjust position of a single glyph
    GPOS_PAIR_ADJUSTMENT             = 2, //Adjust position of a pair of glyphs
    GPOS_CURSIVE_ATTACHMENT          = 3, //Attach cursive glyphs
    GPOS_MARKTOBASE_ATTACHMENT       = 4, //Attach a combining mark to a base glyph
    GPOS_MARKTOLIGATURE_ATTACHMENT   = 5, //Attach a combining mark to a ligature
    GPOS_MARKTOMARK_ATTACHMENT       = 6, //Attach a combining mark to another mark
    GPOS_CONTEXT_POSITIONING         = 7, //Position one or more glyphs in context
    GPOS_CHAINED_CONTEXT_POSITIONING = 8, //Position one or more glyphs in chained context
    GPOS_EXTENSION_POSITIONING       = 9  //Extension mechanism for other positionings
} GPOS_LookupType;

/*
 * The GPOS table begins with a header that contains a version (Version) initially
 * set to 1.0 (0x000100000) and offsets to three tables: ScriptList, FeatureList,
 * and LookupList.  For descriptions of these tables, see OpenType Common Table
 * Formats.
*/
typedef struct _gpos_header
{
    base_table      Base;
    FIXED           Version;                // Version of the GPOS table-initially set to 0x00010000
    TABLE_HANDLE    ScriptList;             // ScriptList (LF_VECTOR) of scripts in the GPOS table
    TABLE_HANDLE    FeatureList;            // FeatureList (feature_list) of features in the GPOS table
    TABLE_HANDLE    LookupList;             // LookupList  (LF_VECTOR) of Lookups in the GPOS table

    boolean         isValid;                // Whether the table is valid (only feature offset and lookup offset are checked so far)
    size_t          calculatedTableSize;    // size in bytes of table if written, 0 if table is dirty
} gpos_header;



LF_ERROR        GPOS_readTable(LF_FONT* lfFont, const sfnt_table_record* record, LF_STREAM* stream);
LF_API LF_ERROR GPOS_getTableSize(LF_FONT* lfFont, size_t* tableSize);
LF_ERROR        GPOS_writeTable(LF_FONT* lfFont, sfnt_table_record* record, LF_STREAM* stream);
boolean         GPOS_isValid(LF_FONT* lfFont);
LF_ERROR        GPOS_isTableEmpty(LF_FONT* lfFont);
LF_ERROR        GPOS_freeTable(LF_FONT* lfFont);

LF_API LF_ERROR GPOS_removeGlyph(LF_FONT* lfFont, ULONG index);
LF_API LF_ERROR GPOS_remapTable(LF_FONT* lfFont, LF_MAP *remap);
LF_ERROR        GPOS_removeAllTables(LF_FONT* lfFont);
LF_ERROR        GPOS_pruneLookups(LF_FONT* lfFont);
LF_ERROR        GPOS_cleanupLookups(LF_FONT* lfFont);
LF_ERROR        GPOS_removeUnReferencedLookups(LF_FONT* lfFont);
LF_ERROR        GPOS_updateLookupFlags(LF_FONT* lfFont);
LF_ERROR        GPOS_removeAnchorPoints(LF_FONT* lfFont);


TABLE_HANDLE    GPOS_readSubtable(USHORT lookupType, LF_STREAM* stream);
size_t          GPOS_buildSubTable(USHORT lookupType, TABLE_HANDLE hTable, LF_STREAM* stream);
size_t          GPOS_getSubtableSize(USHORT lookupType, TABLE_HANDLE hTable);
LF_ERROR        GPOS_subtableRemoveGlyph(USHORT lookupType, TABLE_HANDLE hTable, ULONG index);
LF_ERROR        GPOS_subtableRemapGlyph(USHORT lookupType, TABLE_HANDLE hTable, LF_MAP *remap);

void            GPOS_freeSubtable(USHORT lookupType, TABLE_HANDLE hTable);
LF_ERROR        GPOS_removeLookupIndexSubtable(USHORT lookupType, TABLE_HANDLE hTable, USHORT refIndex, SHORT deltaIndex);
LF_ERROR        GPOS_pruneLookupRecords(USHORT lookupType, TABLE_HANDLE table);
LF_ERROR        GPOS_cleanupLookupSubtables(USHORT lookupType, TABLE_HANDLE subtable, TABLE_HANDLE hLookup);

#ifdef LF_OT_DUMP
LF_ERROR        GPOS_dumpTable(LF_FONT* lfFont);
LF_ERROR        GPOS_dumpSubtable(USHORT lookupType, TABLE_HANDLE table);
#endif

#ifdef __cplusplus
}
#endif

#endif //__GPOS_TABLE_H__
