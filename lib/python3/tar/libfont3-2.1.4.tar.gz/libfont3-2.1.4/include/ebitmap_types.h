// Copyright (C) 2016 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// ebitmap_types.h

#ifndef __EBITMAP_TYPES_H__
#define __EBITMAP_TYPES_H__

#include <stdio.h>
#include "data_types.h"
#include "lf_core.h"

#ifdef __cplusplus
extern "C" {
#endif

typedef struct _big_glyph_metrics_
{
    BYTE height;
    BYTE width;
    CHAR horiBearingX;
    CHAR horiBearingY;
    BYTE horiAdvance;
    CHAR vertBearingX;
    CHAR vertBearingY;
    BYTE vertAdvance;
} big_glyph_metrics;

#define sizeofBigGMs (4 * sizeof(BYTE) + 4 * sizeof(CHAR))


typedef struct _small_glyph_metrics_
{
    BYTE height;
    BYTE width;
    CHAR BearingX;
    CHAR BearingY;
    BYTE Advance;
} small_glyph_metrics;

#define sizeofSmallGMs  (3 * sizeof(BYTE) + 2 * sizeof(CHAR))


typedef struct _index_subtable_header_
{
    USHORT  indexFormat;                        // format of this indexSubTable
    USHORT  imageFormat;                        // format of 'EBDT' image data
    ULONG   imageDataOffset;                    // offset to image data in 'EBDT' table

    USHORT  bestWriteFormat;                    // calculated format to minimize size.
} index_subtable_header;


// The below structures exclude the header info so the header can be read first prior to knowning the format.

typedef struct _index_subtable_format_1_        // variable metrics glyphs with 4 byte offsets
{
    int dummy;
    //index_subtable_header header;             // header info
    //LF_VECTOR             offsetArray;        // vector of ULONGs (not needed since glyphs are put into the strike's glyphMap)
                                                // ULONG offsetArray[] offsetArray[glyphIndex] +imageDataOffset = glyphData
                                                // sizeOfArray = (lastGlyph - firstGlyph + 1) + 1 + 1    pad if needed
} index_subtable_format_1;

typedef struct _index_subtable_format_2_        // all glyphs have identical metrics
{
    //index_subtable_header header;             // header info
    ULONG                 imageSize;            // all the glyphs are of the same size
    big_glyph_metrics     bigMetrics;           // all glyphs have the same metrics; glyph data may be compressed, byte - aligned, or bit - aligned
} index_subtable_format_2;

typedef struct _index_subtable_format_3_        // variable metrics glyphs with 2 byte offsets
{
    int dummy;
    //index_subtable_header header;             // header info
    //LF_VECTOR             offsetArray;        // vector of USHORTs (not needed since glyphs are put into the strike's glyphMap)
                                                // USHORT offsetArray[] offsetArray[glyphIndex] +imageDataOffset = glyphData
                                                // sizeOfArray = (lastGlyph - firstGlyph + 1) + 1 + 1    pad if needed
} index_subtable_format_3;

typedef struct _code_offset_pair_
{
    USHORT glyphCode;                           // code of glyph present
    USHORT offset;                              // location in EBDT
} code_offset_pair;

typedef struct _index_subtable_format_4_        // variable metrics glyphs with sparse glyph codes
{
    //index_subtable_header header;             // header info
    ULONG                   numGlyphs;          // array length
    //LF_VECTOR             codeOffsetPairs;    // vector of code_offset_pair*s (not needed since glyphs are put into the strike's glyphMap)
                                                // codeOffsetPair glyphArray[] one per glyph; sizeOfArray = numGlyphs + 1
} index_subtable_format_4;

typedef struct _index_subtable_format_5_        // constant metrics glyphs with sparse glyph codes
{
    //index_subtable_header header;             // header info
    ULONG                 imageSize;            // all glyphs have the same data size
    big_glyph_metrics     bigMetrics;           // all glyphs have the same metrics
    ULONG                 numGlyphs;            // array length
    //LF_VECTOR           glyphCodeArray;       // array of GlyphIDs (not needed since glyphs are put into the strike's glyphMap)
                                                // USHORT glyphCodeArray[] one per glyph, sorted by glyph code; sizeOfArray = numGlyphs
} index_subtable_format_5;


// structure to hold the offset and length of the raw data, we need the length in case the glyph is the last
// in a subTable, so we can set the n+1 element in the *BLC table array.
typedef struct _index_glyph_info_
{
    ULONG offset;
    ULONG len;

} index_glyph_info;

typedef struct _index_subtable_
{
    USHORT  firstGlyphIndex;                    // first glyph code of this range
    USHORT  lastGlyphIndex;                     // last glyph code of this range(inclusive)
    ULONG   additionalOffsetToIndexSubtable;    // add to indexSubTableArrayOffset to get offset from beginning of 'EBLC'

    LF_MAP  glyphMap;                           // map with key = glyphID, data = index_glyph_info*

    index_subtable_header header;               // header info

    union
    {
        index_subtable_format_1 fmt1;
        index_subtable_format_2 fmt2;
        index_subtable_format_3 fmt3;
        index_subtable_format_4 fmt4;
        index_subtable_format_5 fmt5;
    } subtable;

} index_subtable;

typedef struct _sbit_line_metrics_
{
    CHAR ascender;
    CHAR descender;
    BYTE widthMax;
    CHAR caretSlopeNumerator;
    CHAR caretSlopeDenominator;
    CHAR caretOffset;
    CHAR minOriginSB;
    CHAR minAdvanceSB;
    CHAR maxBeforeBL;
    CHAR minAfterBL;
    CHAR pad1;
    CHAR pad2;
} sbit_line_metrics;

#define sizeofSbitLineMetrics  (11 * sizeof(CHAR) + sizeof(BYTE))

#define sbitFlagHorizontal  0x01
#define sbitFlagVertical    0x02


typedef struct _bitmap_size_table_
{
    ULONG   indexSubTableArrayOffset;           // offset to index subtable from beginning of EBLC.
    ULONG   indexTablesSize;                    // number of bytes in corresponding index subtables and array
    ULONG   numberOfIndexSubTables;             // an index subtable for each range or format change
    ULONG   colorRef;                           // not used; set to 0.
    sbit_line_metrics   hori;                   // line metrics for text rendered horizontally
    sbit_line_metrics   vert;                   // line metrics for text rendered vertically
    USHORT  startGlyphIndex;                    // lowest glyph index for this size
    USHORT  endGlyphIndex;                      // highest glyph index for this size
    BYTE    ppemX;                              // horizontal pixels per Em
    BYTE    ppemY;                              // vertical pixels per Em
    BYTE    bitDepth;                           // the Microsoft rasterizer v.1.7 or greater supports the following bitDepth values, as described below : 1, 2, 4, and 8.
    CHAR    flags;                              // vertical or horizontal(see bitmapFlags)

    LF_VECTOR indexSubTableArray;               // vector of index_subtable*s

} bitmap_size_table;

#define sizeofBitmapSizeTable  (4 * sizeof(ULONG) + 2 * sizeofSbitLineMetrics + 2 * sizeof(USHORT) + 3 * sizeof(BYTE) + 1 * sizeof(CHAR))

typedef struct _bitmap_fmt_1_                   // small metrics, byte-aligned data
{
    small_glyph_metrics smallMetrics;           // Metrics information for the glyph
    size_t              dataSize;               // Size of below buffer
    BYTE*               data;                   // image data Byte - aligned bitmap data
} bitmap_fmt_1;


typedef struct _bitmap_fmt_2_                   // small metrics, bit-aligned data
{
    small_glyph_metrics smallMetrics;           // Metrics information for the glyph
    size_t              dataSize;               // Size of below buffer
    BYTE*               data;                   // image data Bit - aligned bitmap data
} bitmap_fmt_2;

// Format 3 is not supported
// Format 4 is not supported

typedef struct _bitmap_fmt_5_                   // metrics in EBLC, bit-aligned image data only
{
    size_t              dataSize;               // Size of below buffer
    BYTE*               data;                   // image data Bit - aligned bitmap data
} bitmap_fmt_5;

typedef struct _bitmap_fmt_6_                   // big metrics, byte-aligned data
{
    big_glyph_metrics   bigMetrics;             // Metrics information for the glyph
    size_t              dataSize;               // Size of below buffer
    BYTE*               data;                   // image data  Byte - aligned bitmap data
} bitmap_fmt_6;

typedef struct _bitmap_fmt_7_                   // big metrics, bit-aligned data
{
    big_glyph_metrics   bigMetrics;             // Metrics information for the glyph
    size_t              dataSize;               // Size of below buffer
    BYTE*               data;                   // image data Bit - aligned bitmap data
} bitmap_fmt_7;

typedef struct _ebdt_component_                 // array used by Formats 8 and 9
{
    USHORT  glyphCode;                          // Component glyph code
    CHAR    xOffset;                            // Position of component left
    CHAR    yOffset;                            // Position of component top
} ebdt_component;

#define sizeofEbdtComponent (sizeof(USHORT) + 2 * sizeof(CHAR))


typedef struct _bitmap_fmt_8_                   // small metrics, component data
{
    small_glyph_metrics smallMetrics;           // Metrics information for the glyph
    BYTE                pad;                    // Pad to short boundary
    USHORT              numComponents;          // Number of components
    LF_VECTOR           compArray;              // vector of ebdt_component*
                                                // ebdtComponent componentArray[n] Glyph code, offset array
} bitmap_fmt_8;

typedef struct _bitmap_fmt_9_                   // big metrics, component data
{
    big_glyph_metrics   bigMetrics;             // Metrics information for the glyph
    USHORT              numComponents;          // Number of components
    LF_VECTOR           compArray;              // vector of ebdt_component*
                                                // ebdtComponent componentArray[n] Glyph code, offset array
} bitmap_fmt_9;

typedef struct _bitmap_fmt_17_                  // small metrics, PNG image data
{
    small_glyph_metrics glyphMetrics;           // Metrics information for the glyph
    ULONG               dataLen;                // Length of data in bytes
    BYTE*               data;                   // Variable data Raw PNG data
} bitmap_fmt_17;

typedef struct _bitmap_fmt_18_                  // big metrics, PNG image data
{
    big_glyph_metrics   glyphMetrics;           // Metrics information for the glyph
    ULONG               dataLen;                // Length of data in bytes
    BYTE*               data;                   // Variable data Raw PNG data
} bitmap_fmt_18;

typedef struct _bitmap_fmt_19_                  // metrics in CBLC, PNG image data
{
    ULONG   dataLen;                            // Length of data in bytes
    BYTE*   data;                               // Variable data Raw PNG data
} bitmap_fmt_19;

// Structure to represent an EBLC or CBLC
typedef struct _embedded_loc_table_
{
    FIXED version;                  // Initially defined as 0x0002000 for EBLC and 0x00030000 for CBLC
    ULONG numSizes;                 // Number of bitmapSizeTables

    LF_VECTOR bitmapSizeTables;     // vector of bitmap_size_table*

    ULONG calculatedTableSize;      // non-zero if table values and size calculated
} embedded_loc_table;

// Structure to represent an EBDT or CBDT
typedef struct _embedded_data_table_
{
    FIXED   version;            // Initially defined as 0x00020000 for EBDT and 0x00030000 for CBDT

    boolean hasComponents;      // TRUE if any glyph are made of components (image formats 8 and 9)

    LF_VECTOR strikeGlyphMaps;  // a vector of LF_MAPs, one for each strike; the maps have key = glyphID, data = bitmap_glyph*
} embedded_data_table;

// Structure to represent a glyph in a EBDT or CBDT
typedef struct _bitmap_glyph_
{
    USHORT format;

    union
    {
        bitmap_fmt_1 fmt1;
        bitmap_fmt_2 fmt2;
        bitmap_fmt_5 fmt5;
        bitmap_fmt_6 fmt6;
        bitmap_fmt_7 fmt7;
        bitmap_fmt_8 fmt8;
        bitmap_fmt_9 fmt9;
        bitmap_fmt_17 fmt17;
        bitmap_fmt_18 fmt18;
        bitmap_fmt_19 fmt19;
    } glyph;

} bitmap_glyph;

#ifdef __cplusplus
}
#endif

#endif //__EBITMAP_TYPES_H__
