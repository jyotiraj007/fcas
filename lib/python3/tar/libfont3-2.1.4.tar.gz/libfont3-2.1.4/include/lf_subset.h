// Copyright (C) 2014 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
/// \file lf_subset.h

#ifndef __LF_SUBSET_H__
#define __LF_SUBSET_H__

#include "lf_core.h"
#include "lf_error.h"

#ifdef __cplusplus
extern "C" {
#endif

//! Enumeration for optimization of OpenType tables during subsetting.
typedef enum _subset_opt_
{
    SUBSET_OPT_NONE = 0,                    // No optimization.
    SUBSET_OPT_REMOVE_EMPTY_FEATURES,       // Remove empty features.
    SUBSET_OPT_REMOVE_EMPTY_LOOKUPS         // Remove empty features and empty and unreferenced lookups. Recommended default.

} LF_SUBSET_OPT_LEVEL;

//! Parameters for subsetting fonts.
typedef struct _subsetParams_
{
    boolean             normalize;      ///< Set to TRUE to run NFC algorithm on the array of Unicode values. Recommended default is FALSE.
    char**              listLang;       ///< List of codepages and/or languages. Can be NULL. Supported values are: codpages:001 002 010 015 026 029; languages: Cyrillic and Devanagari
    ULONG               numLang;        ///< Number of items in listLang.
    LF_SUBSET_OPT_LEVEL optimize;       ///< Optimization level. Recommended default is SUBSET_OPT_REMOVE_EMPTY_LOOKUPS.

} LF_SUBSET_PARAMS;


// Public interface to the libfont library font subsetting function
LF_API LF_ERROR LF_subsetFont(LF_FONT* lfFont, ULONG* unicodes, ULONG  numUnicodes, const LF_SUBSET_PARAMS* params);

#ifdef __cplusplus
}
#endif

#endif // end of __LF_SUBSET_H__
