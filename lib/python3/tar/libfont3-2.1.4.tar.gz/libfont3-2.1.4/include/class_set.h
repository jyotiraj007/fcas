// Copyright (C) 2014 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// class_set.h

#ifndef __CLASS_SET_H__
#define __CLASS_SET_H__

#include "data_types.h"
#include "stream.h"
#include "lf_error.h"
#include "lf_vector.h"
#include "coverage_table.h"

#ifdef __cplusplus
extern "C" {
#endif

/* ----------------------------------------------------------------------------

    Each ClassSet table consists of a count of the ClassRule tables defined
    in the ClassSet (SubClassRuleCnt) and an array of offsets to ClassRule
    tables (ClassRule). The ClassRule tables are ordered by preference
    in the ClassRule array of the ClassSet.

---------------------------------------------------------------------------- */
typedef struct __class_set__
{
    USHORT            ClassRuleCount;       // number of ClassRule tables

    LF_VECTOR*        ClassRules;           // array of offsets to SubClassRule tables-
                                            // from the beginning of SubClassSet-
                                            // ordered by preference.

    USHORT            InputClass;
} class_set;

// ClassSets
LF_ERROR    ClassSets_readClassSets(LF_VECTOR* css, class_def* cd, USHORT count, LF_STREAM* stream, ULONG baseOffset);
LF_ERROR    ClassSets_validClassRules(LF_VECTOR* css);

// ClassSet
LF_ERROR    ClassSet_readClassSet(class_def* csf2, class_set* scs, LF_STREAM* stream);
void        ClassSet_freeClassSet(class_set* scs);
size_t      ClassSet_sizeClassSet(class_set* scs);
LF_ERROR    ClassSet_buildClassSet(class_set* scs, LF_STREAM* stream);
LF_ERROR    ClassSet_buildClassSets(LF_VECTOR* sets, LONG baseOffset, LONG classSetArrayOffset, LF_STREAM* stream);
LF_ERROR    ClassSet_validClassRules(class_set* css);

LF_ERROR    ClassSet_removeGlyphFromClass(class_def* cd, LF_VECTOR* ClassSet, GlyphID glyphid);
LF_ERROR    ClassSet_pruneEmptyClasses(class_def* classes, LF_VECTOR* classSets);
LF_ERROR    ClassSet_cleanupCoverageClasses(class_def* classes, LF_VECTOR* classSets, coverage_table* coverage);
LF_ERROR    ClassSet_cleanupLookups(class_set* cs, TABLE_HANDLE hLookup);
LF_ERROR    ClassSet_collectGlyphs(class_set* cs, GlyphList* keepList, TABLE_HANDLE hTable, class_def* classdef);

#ifdef LF_OT_DUMP
void        ClassSets_dumpClassSets(LF_VECTOR* css);
void        ClassSet_dumpClassSet(class_set* cs);
#endif

#ifdef __cplusplus
}
#endif

#endif //__CLASS_SET_H__
