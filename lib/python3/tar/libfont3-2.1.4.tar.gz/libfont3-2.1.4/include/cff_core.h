// Copyright (C) 2014, 2015 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// cff_core.h

#ifndef __CFF_CORE_H__
#define __CFF_CORE_H__

#include "data_types.h"
#include "stream.h"
#include "cff_types.h"

#ifdef __cplusplus
extern "C" {
#endif

typedef enum _cff_err
{
    CFF_ERR_OK = 0,
    CFF_ERR_MEMORY,
    CFF_ERR_BAD_PARAM,
    CFF_ERR_BAD_OPCODE,
    CFF_ERR_BAD_SUBRSPTR,
    CFF_ERR_BAD_FORMAT,
    CFF_ERR_UNSUPPORTED_FORMAT,
    CFF_ERR_BAD_FD_FORMAT,
    CFF_ERR_BAD_TOP_FORMAT,
    CFF_ERR_BAD_PRIV_FORMAT,
    CFF_ERR_CREATE_TABLE,
    CFF_ERR_BAD_OFFSET_SIZE,
    CFF_ERR_INTERNAL,
    CFF_ERR_CS_BUF_EXCEEDED,
    CFF_ERR_SUBR_BUF_EXCEEDED
} CFF_ERROR;

typedef enum
{
    ANALYSIS = 0,
    FULL_ANALYSIS,
    GENERATION,
    DUMPING

} parseReason;



CFF_ERROR       cff_load(BYTE* tableBuf, LONG tableBufLength, CFF_TAB **cffTab);
void            cff_unload(CFF_TAB *cffTab);

CFF_ERROR       cff_indexInitializeFromBuffer(const BYTE* startOfIndex, cffIndex** index);
CFF_ERROR       cff_indexInitializeWithSize(ULONG size, cffIndex** index);
CFF_ERROR       cff_indexCopy(cffIndex* index, cffIndex** createdIndex);
ULONG           cff_indexGetLength(cffIndex* index);
ULONG           cff_indexGetLengthForSingleItemIndex(ULONG itemSize);
ULONG           cff_indexGetLengthForIndexWithSizes(const ULONG* itemSizes, ULONG numItems);
ULONG           cff_indexGetCount(const cffIndex* index);
cffIndexItem*   cff_indexGetItem(cffIndex* index, ULONG which);
void            cff_indexDestroy(cffIndex* index);
LF_ERROR        cff_indexAppendToStream(cffIndex* index, LF_STREAM* stream);
CFF_ERROR       cff_indexAppendCopy(cffIndex* index, const cffIndexItem* item);
CFF_ERROR       cff_indexRemoveItem(cffIndex* index, ULONG which);
CFF_ERROR       cff_indexReplaceCopy(cffIndex* index, ULONG which, cffIndexItem* newItem);

CFF_ERROR       cff_analyzeCharstrings(CFF_TAB* cffTable, LF_MAP* acsMap);
CFF_ERROR       cff_analyzeCharstringsFully(CFF_TAB* cffTable, LF_MAP* acsMap);
void            cff_analyzedCharStringDestroy(cffAnalyzedCharstring* acs);

CFF_ERROR       cff_buildCFF_TAB(CFF_TAB* cff, LF_MAP* sidMap, LF_MAP* charstringMap, CFF_TAB_BUILD** builtCff);
CFF_ERROR       cff_encodeCharset(const cffSID* charset, ULONG count, BYTE** encodedCharset, LONG* encodedCharsetSize);
CFF_ERROR       cff_createPrivateDict(boolean isAsian, LONG defaultWidth, LONG nominalWidth, BYTE** encodedPrivDict, LONG* encodedPrivDictSize);
CFF_ERROR       cff_encodeTopDict(const CFFTOPDICT* td, BYTE** encodedBuf, ULONG* encodedBufLen);
void            cff_destroyCFF_TAB(CFF_TAB_BUILD* builtCff);

CFF_ERROR       cff_dumpCharString(CFF_TAB* table, BYTE* charString, size_t len, LONG index, boolean isSubroutine);

LF_ERROR        cff_mapCffErrorToLfError(CFF_ERROR e);

#ifdef __cplusplus
}
#endif

#endif //__CFF_CORE_H__
