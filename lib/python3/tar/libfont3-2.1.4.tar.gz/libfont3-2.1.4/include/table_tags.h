// Copyright (C) 2014, 2017 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// table_tags.h

#ifndef __TABLE_TAGS_H__
#define __TABLE_TAGS_H__

#define TAG_BASE    0x42415345  // BASE
#define TAG_CBDT    0x43424454  // CBDT
#define TAG_CBLC    0x43424C43  // CBLC
#define TAG_CFF     0x43464620  // CFF 
#define TAG_CFF2    0x43464632  // CFF2
#define TAG_COLR    0x434F4C52  // COLR
#define TAG_CPAL    0x4350414C  // CPAL
#define TAG_DSIG    0x44534947  // DSIG
#define TAG_EBDT    0x45424454  // EBDT
#define TAG_EBLC    0x45424C43  // EBLC
#define TAG_EBSC    0x45425343  // EBSC
#define TAG_FEAT    0x46656174  // Feat
#define TAG_FFTM    0x4646544D  // FFTM
#define TAG_GDEF    0x47444546  // GDEF
#define TAG_GLAT    0x476C6174  // Glat
#define TAG_GLOC    0x476C6F63  // Gloc
#define TAG_GPOS    0x47504F53  // GPOS
#define TAG_GSUB    0x47535542  // GSUB
#define TAG_HVAR    0x48654152  // HVAR
#define TAG_JSTF    0x4A535446  // JSTF
#define TAG_LTSH    0x4C545348  // LTSH
#define TAG_MATH    0x4D415448  // MATH
#define TAG_MVAR    0x4D654152  // MVAR
#define TAG_OS2     0x4F532F32  // OS/2
#define TAG_PCLT    0x50434C54  // PCLT
#define TAG_SILF    0x53696C66  // Silf
#define TAG_SILL    0x53696C6C  // Sill
#define TAG_STAT    0x53544154  // STAT
#define TAG_SVG     0x53564720  // SVG 
#define TAG_VDMX    0x56444D58  // VDMX
#define TAG_VORG    0x564F5247  // VORG
#define TAG_VVAR    0x56654152  // VVAR
#define TAG_ZAPF    0x5A617066  // Zapf

#define TAG_ACNT    0x61636E74  // acnt
#define TAG_AVAR    0x61766172  // avar
#define TAG_BDAT    0x62646174  // bdat
#define TAG_BLOC    0x626C6F63  // bloc
#define TAG_BSLN    0x62736C6E  // bsln
#define TAG_CMAP    0x636D6170  // cmap
#define TAG_CVAR    0x63766172  // cvar
#define TAG_CVT     0x63767420  // cvt 
#define TAG_FDSC    0x66647363  // fdsc
#define TAG_feat    0x66656174  // feat
#define TAG_FMTX    0x666D7478  // fmtx
#define TAG_FPGM    0x6670676d  // fpgm
#define TAG_FVAR    0x66766172  // fvar
#define TAG_GASP    0x67617370  // gasp
#define TAG_GLYF    0x676C7966  // glyf
#define TAG_GVAR    0x67766172  // gvar
#define TAG_HDMX    0x68646D78  // hdmx
#define TAG_HEAD    0x68656164  // head
#define TAG_HHEA    0x68686561  // hhea
#define TAG_HMTX    0x686D7478  // hmtx
#define TAG_HSTY    0x68737479  // hsty
#define TAG_JUST    0x6A757374  // just
#define TAG_KERN    0x6B65726E  // kern
#define TAG_LCAR    0x6C636172  // lcar
#define TAG_LOCA    0x6C6F6361  // loca
#define TAG_MAXP    0x6D617870  // maxp
#define TAG_MORT    0x6D6E7274  // mort
#define TAG_MORX    0x6D6F7278  // morx
#define TAG_NAME    0x6E616D65  // name
#define TAG_OPBD    0x6F706264  // opbd
#define TAG_POST    0x706F7374  // post
#define TAG_PREP    0x70726570  // prep
#define TAG_PROP    0x70726F70  // prop
#define TAG_SBIX    0x73626978  // sbix
#define TAG_TRAK    0x7472616B  // trak
#define TAG_VHEA    0x76686561  // vhea
#define TAG_VMTX    0x766D7478  // vmtx


#endif //__TABLE_TAGS_H__
