// Copyright (C) 2014 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// vmtx_table.h


#ifndef __VMTX_TABLE_H__
#define __VMTX_TABLE_H__

#include "lf_core.h"
#include "offset_table_sfnt.h"


#ifdef __cplusplus
extern "C" {
#endif

#define VMTX_MARK_REMOVED 0x00000000FFFFFFFF

typedef struct _longVerMetric {
    USHORT   advanceHeight;
    SHORT    topSideBearing;
} longVerMetric;

#define LONGVERMETRIC_SIZE (sizeof(USHORT) + sizeof(SHORT))

typedef struct _vmtx_table
{
    USHORT      numVMetrics;
    LF_VECTOR   metricsVector;

    boolean     numMetricsCalculated;
    size_t      calculatedTableSize;
} vmtx_table;

LF_API LF_ERROR    VMTX_readTable(LF_FONT* lfFont, const sfnt_table_record* record, LF_STREAM* stream);
LF_API LF_ERROR    VMTX_getTableSize(LF_FONT* lfFont, size_t* tableSize);
LF_API LF_ERROR    VMTX_writeTable(LF_FONT* lfFont, sfnt_table_record* record, LF_STREAM* stream);
LF_API LF_ERROR    VMTX_removeGlyph(LF_FONT* lfFont, ULONG index);
LF_API LF_ERROR    VMTX_updateSidebearings(LF_FONT* lfFont, LF_FONT_TYPE type, FWORD *mintsb, FWORD *minbsb, FWORD *maxadvance, FWORD* yMaxExtent);
LF_API UFWORD      VMTX_getMinTopSidebearing(LF_FONT* lfFont); 
LF_API UFWORD      VMTX_getAdvanceHeightMax(LF_FONT* lfFont);
LF_API USHORT      VMTX_getNumVMetrics(LF_FONT* lfFont);
LF_API LF_ERROR    VMTX_freeTable(LF_FONT* lfFont);
LF_API LF_ERROR    VMTX_expandTable(LF_FONT* lfFont, USHORT numGlyphs);
LF_API LF_ERROR    VMTX_setMetric(LF_FONT* lfFont, size_t index, USHORT advanceHeight, SHORT tsb);

#ifdef __cplusplus
}
#endif

#endif //__VMTX_TABLE_H__
