// Copyright (C) 2014 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// script_list.h

#ifndef __SCRIPTLIST_TABLE_H__
#define __SCRIPTLIST_TABLE_H__

#include "data_types.h"
#include "stream.h"
#include "lf_vector.h"
#include "base_table.h"

#ifdef __cplusplus
extern "C" {
#endif

typedef struct _langsys_table
{
    TAG          LangSysTag;         // 4-byte LangSysTag identifier
    OFFSET       LookupOrder;        // = NULL (reserved for an offset to a reordering table)
    USHORT       ReqFeatureIndex;    // Index of a feature required for this language system- if no required features = 0xFFFF
    USHORT       FeatureCount;       // Number of FeatureIndex values for this language system-excludes the required feature
    LF_VECTOR    FeatureIndex;
} langsys_table;

typedef struct _script_table
{
    base_table        Base;
    TAG               ScriptTag;         // 4-byte ScriptTag identifier
    langsys_table*    DefaultLangSys;    // pointer to DefaultLangSys table-from beginning of Script table-may be NULL
    LF_VECTOR         LangList;          // Array of LangSysRecords-listed alphabetically by LangSysTag
} script_table;



#define SCRIPT_RECORD_SIZE     (sizeof(TAG) + sizeof(OFFSET))
#define LANGSYS_RECORD_SIZE    (sizeof(TAG) + sizeof(OFFSET))

size_t       Script_getDataSize(TABLE_HANDLE hTable);
size_t       Script_getScriptTableSize(const script_table* table);
size_t       Script_getListTableSize(TABLE_HANDLE hTable);
TABLE_HANDLE Script_readListTable(LF_STREAM* stream, boolean isGPOS);
BYTE*        Script_buildTable(TABLE_HANDLE hTable, size_t* tableSize);
void         Script_deleteTable(TABLE_HANDLE list);
LF_ERROR     Script_removeLookupIndex(TABLE_HANDLE hScript, USHORT index, SHORT delta);
LF_ERROR     Script_collectGlyphs(GlyphList* keepList, TABLE_HANDLE hTable);


#ifdef __cplusplus
}
#endif

#endif //__SCRIPTLIST_TABLE_H__
