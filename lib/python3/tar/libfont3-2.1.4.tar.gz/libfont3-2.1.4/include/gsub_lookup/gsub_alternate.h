// Copyright (C) 2014 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// gsub_alternate.h


/* ============================================================================
    @summary

        LookupType 3: Alternate Substitution Subtable

    @description
        An Alternate Substitution (AlternateSubst) subtable identifies any
        number of aesthetic alternatives from which a user can choose a glyph
        variant to replace the input glyph. For example, if a font contains
        four variants of the ampersand symbol, the cmap table will specify the
        index of one of the four glyphs as the default glyph index, and an
        AlternateSubst subtable will list the indices of the other three
        glyphs as alternatives. A text-processing client would then have the
        option of replacing the default glyph with any of the three
        alternatives.

============================================================================ */
#ifndef __GSUB_LOOKUP_ALTERNATE_H__
#define __GSUB_LOOKUP_ALTERNATE_H__

#include "data_types.h"
#include "offset_table_sfnt.h"
#include "utils.h"
#include "coverage_table.h"
#include "base_table.h"
#include "link_list.h"

#ifdef __cplusplus
extern "C" {
#endif


/* ----------------------------------------------------------------------------
    @summary
        For each glyph, an AlternateSet subtable contains a count of the 
        alternative glyphs (GlyphCount) and an array of their glyph 
        indices (Alternate). Because all the glyphs are functionally 
        equivalent, they can be in any order in the array.

---------------------------------------------------------------------------- */
typedef struct gsub_alternate_set_table_
{

    USHORT       GlyphCount;       // Number of GlyphIDs in the Alternate array
    LF_VECTOR    Alternate;        // Array of alternate GlyphID-in arbitrary order

} gsub_alternate_set;


/* ----------------------------------------------------------------------------

    The subtable has one format: AlternateSubstFormat1. The subtable 
    contains a format identifier (SubstFormat), an offset to a Coverage 
    table containing the indices of glyphs with alternative forms (Coverage), 
    a count of offsets to AlternateSet tables (AlternateSetCount), and an 
    array of offsets to AlternateSet tables (AlternateSet).

---------------------------------------------------------------------------- */
typedef struct gsub_alternate_
{
    base_table           Base;                           // Base class for the Substitution Table.

    USHORT               SubstFormat;                    // Format identifier
    coverage_table       Coverage;                       // Offset to Coverage table-from beginning of Substitution table
    link_list            AlternateSetList;               // linked list of gsub_alternate_set*

} gsub_alternate_substitution;


TABLE_HANDLE    GSUB_readAlternateSubst(LF_STREAM* stream);
size_t          GSUB_buildAlternateSubst(gsub_alternate_substitution* table, LF_STREAM* stream);
size_t          GSUB_getAlternateSubstSize(gsub_alternate_substitution* table);
void            GSUB_freeAlternateSubst(gsub_alternate_substitution* table);
LF_ERROR        GSUB_removeAlternateGlyphIndex(gsub_alternate_substitution* as, GlyphID glyphid);

LF_ERROR        GSUB_remapAlternateGlyphs(gsub_alternate_substitution* as, LF_MAP* remap);
LF_ERROR        GSUB_keepAlternateSubstGlyphs(gsub_alternate_substitution* as, GlyphList* keepList);

#ifdef LF_OT_DUMP
void            GSUB_dumpAlternateSubst(gsub_alternate_substitution* as);
#endif

#ifdef __cplusplus
}
#endif

#endif    // end of __GSUB_LOOKUP_ALTERNATE_H__
