// Copyright (C) 2014 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// gsub_multiple.h

/* ============================================================================
    @summary
        A multiple substitution subtable replaces a single glyph with
        more than one glyph, as when multiple glyphs replace a single
        ligature.  The subtable has a single format.

    @see also
        http://partners.adobe.com/public/developer/opentype/index_table_formats1.html#MSF1


============================================================================ */
#ifndef __GSUB_LOOKUP_MULTIPLE_H__
#define __GSUB_LOOKUP_MULTIPLE_H__

#include "data_types.h"
#include "offset_table_sfnt.h"
#include "utils.h"
#include "coverage_table.h"
#include "base_table.h"
#include "link_list.h"

#ifdef __cplusplus
extern "C" {
#endif

typedef struct _gsub_subst_sequence_
{
    uint16       GlyphCount;            // Number of GlyphIDs in the Substitute
                                        // array.  This should always be greater
                                        // than 0.

    LF_VECTOR    Substitute;            // String of GlyphIDs to Substitute
} gsub_subst_sequence;


/* ----------------------------------------------------------------------------
    @brief
        the final stream output structure for the multiple substitution
        file.  this structure follows the font file specification and
        needs to be used when building out the stream and writing out
        the font.
---------------------------------------------------------------------------- */
typedef struct _gsub_multipleSubst1_
{
    USHORT        SubstFormat;            // format identifier-format = 1
    OFFSET        CoverageOffset;         // Offset to the coverage table
    USHORT        SequenceCount;          // Number of Sequence table offsets in
                                          // the sequence array

    OFFSET        Sequence;               // Offset to the array of offsets to Sequence tables
                                          // tables from beginning of Substitution table
                                          // ordered by Coverage Index
} gsub_multiple_substitution_stream;


/* ----------------------------------------------------------------------------
    @brief
        the working substitution structure which is used to allocate
        resources and store them.  this structure is passed around
        the interface when parsing the rules, or lookups.
---------------------------------------------------------------------------- */
typedef struct _gsub_multiple_substitution_
{
    base_table               Base;               // the parent class for GSUB rules

    USHORT                   SubstFormat;        // format identifier - format is always 1
    coverage_table           Coverage;           // The Coverage Table
    link_list                SequenceList;       // array of sequence tables from table ordered by
                                                 // coverage index.
} gsub_multiple_substitution;


TABLE_HANDLE    GSUB_readMultipleSubst(LF_STREAM* stream);
size_t          GSUB_buildMultipleSubst(gsub_multiple_substitution* table, LF_STREAM* stream);
size_t          GSUB_getMultipleSubstSize(gsub_multiple_substitution* table);
void            GSUB_freeMultipleSubst(gsub_multiple_substitution* table);
LF_ERROR        GSUB_removeMultipleGlyphIndex(gsub_multiple_substitution* ms, GlyphID glyphid);
LF_ERROR        GSUB_remapMultipleSubstGlyphs(gsub_multiple_substitution* ms, LF_MAP* remap);
LF_ERROR        GSUB_keepMultipleSubstGlyphs(gsub_multiple_substitution* ms, GlyphList* keepList);

#ifdef LF_OT_DUMP
void            GSUB_dumpMultipleSubst(gsub_multiple_substitution* ms);
#endif

#ifdef __cplusplus
}
#endif

#endif    // end of __GSUB_LOOKUP_MULTIPLE_H__
