// Copyright (C) 2014 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// gsub_common.h



#ifndef __GSUB_COMMON_H__
#define __GSUB_COMMON_H__


#ifdef __cplusplus
extern "C" {
#endif


/* Lookup types for glyph substitution */
#define GSUB_LOOKUP_SINGLE        1                // Replace one glyph with one glyph
#define GSUB_LOOKUP_MULTIPLE      2                // Replace one glyph with more than one glyph
#define GSUB_LOOKUP_ALTERNATE     3                // Replace one glyph with one of many glyphs
#define GSUB_LOOKUP_LIGATURE      4                // Replace multiple glyphs with one glyph
#define GSUB_LOOKUP_CONTEXT       5                // Replace one or more glyphs in context
#define GSUB_LOOKUP_CHAIN         6                // Replace one or more glyphs in chained context
#define GSUB_LOOKUP_EXTENSION     7                // Extension mechanism for other substitutions (i.e. this excludes the Extension type substitution itself)
#define GSUB_LOOKUP_REVERSE_CHAIN 8                // Applied in reverse order, replace single glyph in chaining context






#ifdef __cplusplus
}
#endif


#endif //__GSUB_COMMON_H__






