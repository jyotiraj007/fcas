// Copyright (C) 2014, 2015 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// cff_table.h

#ifndef __CFF_TABLE_H__
#define __CFF_TABLE_H__

#include "lf_core.h"
#include "offset_table_sfnt.h"
#include "cff_types.h"
#include "keep_table.h"

#ifdef __cplusplus
extern "C" {
#endif

typedef struct _cff_table
{
    BYTE*           rawTableBlock;      // raw data of the CFF table
    CFF_TAB*        cffTable;           // a parsed representation of the original table
    LF_MAP*         charStringMap;      // map containing key = gid, data = cffAnalyzedCharstring*
    LF_MAP*         SIDMap;             // map containing key = oldSID, data = newSID
                                        // for subbsetting the string INDEX and applying change to charset and top dict,
                                        // contains only non-standard SIDs
    CFF_TAB_BUILD*  builtTable;         // representation of the table after subsetting, or construction from glyf table

} cff_table;


// Flags for use with CFF__Dump
#define CFF_DUMP_DEFAULT                0x00
#define CFF_DUMP_BRIEF                  0x01    // do not fully expand the charstrings in the charstring INDEX and the subroutine indexes
#define CFF_DUMP_PARSED_CHARSTRINGS     0x02    // (not implemented) list the opcodes and arguments of the charstrings
#define CFF_DUMP_SUBROUTINE_HISTOGRAM   0x04    // (not implemented) list the usage of the subroutines (to find unused ones)


LF_ERROR    CFF__readTable(LF_FONT* lfFont, const sfnt_table_record* record, LF_STREAM* stream);
LF_ERROR    CFF__createTable(LF_FONT* lfFont);
LF_ERROR    CFF__removeGlyph(const LF_FONT* lfFont, ULONG index);
LF_ERROR    CFF__keepGlyphs(const LF_FONT* lfFont, GlyphList* keepList);
LF_ERROR    CFF__remapTable(const LF_FONT* lfFont, LF_MAP *remap);
LF_ERROR    CFF__getGlyphBoundingBox(const LF_FONT* lfFont, GlyphID id, SHORT* xMin, SHORT* yMin, SHORT* xMax, SHORT* yMax);
LF_ERROR    CFF__getBoundingBox(const LF_FONT* lfFont, SHORT* xMin, SHORT* yMin, SHORT* xMax, SHORT* yMax);
LF_ERROR    CFF__getCount(const LF_FONT* lfFont, USHORT* numGlyphs);
LF_ERROR    CFF__getNumContours(const LF_FONT* lfFont, USHORT index, SHORT* numContours);
LF_ERROR    CFF__replaceCharstring(const LF_FONT* lfFont, USHORT index, cffAnalyzedCharstring* cs);
LF_ERROR    CFF__getTableSize(const LF_FONT* lfFont, size_t* tableSize);
LF_ERROR    CFF__writeTable(const LF_FONT* lfFont, sfnt_table_record* record, LF_STREAM* stream);
LF_ERROR    CFF__Dump(LF_FONT* lfFont, ULONG flags);
LF_ERROR    CFF__freeTable(const LF_FONT* lfFont);

// private
void        cleanupCharStringMap(const cff_table* table);

#ifdef __cplusplus
}
#endif

#endif // __CFF_TABLE_H__
