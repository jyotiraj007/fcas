// Copyright (C) 2014 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// offset_table_woff.h

#ifndef __OFFSET_WOFF_H__
#define __OFFSET_WOFF_H__

#include <stdio.h>
#include "data_types.h"
#include "lf_vector.h"
#include "stream.h"
#include "lf_core.h"

#ifdef __cplusplus
extern "C" {
#endif

typedef struct _woff_header 
{
    ULONG   signature;        // 0x774F4646 'wOFF'
    ULONG   flavor;           // sfnt version of the input font.
    ULONG   length;           // Total size of the WOFF file.
    USHORT  numTables;        // Number of tables.
    USHORT  reserved;         // Reserverd, set to zero.
    ULONG   totalSfntSize;    // Total size needed for the uncompressed fontdata, including sfnt header, directory, and tables (including padding)
    USHORT  majorVersion;     // Major version of the WOFF file.
    USHORT  minorVersion;     // Minor version of the WOFF file.
    ULONG   metaOffset;       // Offset to metadata block, from beginning of WOFF file.
    ULONG   metaLength;       // Length of compressed metadata block.
    ULONG   metaOrigLength;   // Uncompressed size of metadata block.
    ULONG   privOffset;       // Offset to private data block, from beginning of WOFF file.
    ULONG   privLength;       // Length of private data block.
} LF_WOFF_HEADER;

typedef struct _woff_offset_table
{
    LF_WOFF_HEADER woffHeader;

    //INTERNAL
    LF_VECTOR record_list;
} woff_offset_table;

typedef struct _woff_table_record
{
    ULONG   tag;            // 4-byte sfnt table identifier.
    ULONG   offset;         // Offset to the data, from beginning of WOFF file.
    ULONG   compLength;     // Length of the compressed data, excluding padding.
    ULONG   origLength;     // Length of the uncompressed table, excluding padding.
    ULONG   origChecksum;   // Checksum of the uncompressed table.
} woff_table_record;

woff_offset_table*  offset_woff_readTable(LF_STREAM* stream, int keeFlags);
size_t              offset_woff_writeTable(woff_offset_table* table, LF_STREAM* stream);
LF_ERROR            offset_woff_freeTable(woff_offset_table* table);

#ifdef __cplusplus
}
#endif

#endif //__OFFSET_WOFF_H__
