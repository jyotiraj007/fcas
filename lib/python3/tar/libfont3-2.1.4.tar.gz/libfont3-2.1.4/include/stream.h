// Copyright (C) 2014 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// stream.h

#ifndef __STREAM_H__
#define __STREAM_H__

#include <stdio.h>
#include "data_types.h"
#include "lf_error.h"

#ifdef __cplusplus
extern "C" {
#endif

// defines for the streaming of data
#define LF_FILE FILE

#ifdef _DEBUG
#define STREAM_OFFSET_VALIDATE (1)
#else
#define STREAM_OFFSET_VALIDATE (0)
#endif


typedef enum
{
    eSTREAM_TYPE_UNKNOWN = -1,
    eSTREAM_TYPE_FILE,
    eSTREAM_TYPE_MEM,
    eSTREAM_TYPE_TOTAL
} eSTREAM_TYPE;


/* ----------------------------------------------------------------------------
    @brief
        This structure represents how to stream data from the font
        file.  This can be determined by multiple ways either through
        file or memory.

---------------------------------------------------------------------------- */
typedef struct StreamRecord
{
    eSTREAM_TYPE    Type;
    LF_FILE*        FileRef;            // file reference
    BYTE*           Base;               // starting base of memory
    BYTE*           Current;            // current position in memory
    size_t          Length;             // length of the stream
    boolean         isInvalid;          // set to TRUE if stream is overwritten
} LF_STREAM;

// streaming constructors
void        STREAM_openStream(LF_STREAM* stream, eSTREAM_TYPE type);
void        STREAM_closeStream(LF_STREAM* stream);

void        STREAM_initFileStream(LF_STREAM* stream, FILE* file);
void        STREAM_closeFileStream(LF_STREAM* stream);

void        STREAM_initMemStream(LF_STREAM* stream, BYTE* mem, size_t length);
void        STREAM_createMemStream(LF_STREAM* stream, size_t length);
LF_ERROR    STREAM_growStream(LF_STREAM* stream, size_t grow);

// adjust stream position
size_t      STREAM_streamPos(const LF_STREAM* stream);
LONG        STREAM_streamSeek(LF_STREAM* stream, size_t pos);

// access stream
BYTE        STREAM_readByte(LF_STREAM* stream);
USHORT      STREAM_readUShort(LF_STREAM* stream);
ULONG       STREAM_readULong(LF_STREAM* stream);
LONGDATETIME STREAM_readLongDateTime(LF_STREAM* stream);
BYTE*       STREAM_readChunk(LF_STREAM* stream, size_t size);
LF_ERROR    STREAM_getChunk(LF_STREAM* stream, BYTE* buf, size_t size);
CHAR*       STREAM_readString(LF_STREAM* stream, ULONG len);
boolean     STREAM_readUIntBase128(LF_STREAM* stream, ULONG* value);
USHORT      STREAM_read255UShort(LF_STREAM* stream);

#define STREAM_readFixed(stream)    STREAM_readULong(stream)
#define STREAM_readTag(stream)      STREAM_readULong(stream)
#define STREAM_readOffset(stream)   STREAM_readUShort(stream)
#define STREAM_readShort(stream)    STREAM_readUShort(stream)
#define STREAM_readFWord(stream)    STREAM_readShort(stream)
#define STREAM_readUFWord(stream)   STREAM_readUShort(stream)

size_t  STREAM_writeByte(LF_STREAM* stream, BYTE value);
void    STREAM_writeUShort(LF_STREAM* stream, USHORT value);
void    STREAM_writeULong(LF_STREAM* stream, ULONG value);
void    STREAM_writeLongDateTime(LF_STREAM* stream, LONGDATETIME value);
size_t  STREAM_writeChunk(LF_STREAM* stream, const BYTE* data, size_t len);
void    STREAM_writeUIntBase128(LF_STREAM* stream, ULONG value);
USHORT  STREAM_255UShortBytesNeeded(USHORT value);
void    STREAM_write255UShort(LF_STREAM* stream, USHORT value);
//void  STREAM_writeShort(LF_STREAM* stream, SHORT value);

#define STREAM_writeFixed(stream, val)  STREAM_writeULong(stream, val)
#define STREAM_writeTag(stream, val)    STREAM_writeULong(stream, val)
#define STREAM_writeShort(stream, val)  STREAM_writeUShort(stream, val)
#define STREAM_writeFWord(stream, val)  STREAM_writeShort(stream, val)
#define STREAM_writeUFWord(stream, val) STREAM_writeShort(stream, val)
#define STREAM_writeCard16(stream, val)  STREAM_writeUShort(stream, val)
#define STREAM_writeOffSize(stream, val)  STREAM_writeByte(stream, val)

LF_ERROR STREAM_writeCffOffset(LF_STREAM* stream, size_t offset, BYTE offSize);
LF_ERROR STREAM_writeCffEncodedOffset(LF_STREAM* stream, LONG offset);
size_t STREAM_getBytesToEncodeCffInteger(LONG number);
LF_ERROR STREAM_writeCffIntegerOperand(LF_STREAM* stream, LONG n);
LF_ERROR STREAM_writeCffRealOperand(LF_STREAM* stream, float val);

boolean     STREAM_ValidateOffset(size_t offset);

#if STREAM_OFFSET_VALIDATE
LF_ERROR    Stream_writeOffset(LF_STREAM* stream, size_t offset, char* strFile, unsigned uline);
#define STREAM_writeOffset(_stream, _offset)            \
            Stream_writeOffset(_stream, _offset, __FILE__, __LINE__)
#else
LF_ERROR Stream_writeOffset(LF_STREAM* stream, size_t offset);

#define STREAM_writeOffset(stream, val)    Stream_writeOffset(stream, val)
#endif


#define STREAM_ptrIsValid(s) ((s!=NULL) ? (!((s)->isInvalid)) : FALSE)
#define STREAM_isValid(s)    (!((s).isInvalid))

#ifdef __cplusplus
}
#endif

#endif //__STREAM_H__
