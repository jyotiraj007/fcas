// Copyright (C) 2014, 2015 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// keep_table.h

/* ===================================================================================
    common glyph list structures that are used to manage files as they
    are parsed in.

=================================================================================== */
#ifndef __KEEP_TABLE_H__
#define __KEEP_TABLE_H__

#ifdef __cplusplus
extern "C" {
#endif

#include <stdio.h>
#include "data_types.h"
#include "lf_error.h"
#include "lf_map.h"
#include "stream.h"


/* ===================================================================================
@summary
GlyphList structure holds all of the keep glyph id that may be part
of composites or substitution rules that are relevant to the rules
of the font.
=================================================================================== */
typedef struct __glyph_list__
{
    LF_MAP          Glyphs;                    // map collection of the glyphs (coverage in key, data holds count)
} GlyphList;

/* ==================================================================
    @desc
        glyph list functions that maintain the Keep glyph list.
================================================================== */

GlyphList*      Keep_createGlyphList(void);
LF_ERROR        Keep_destroyGlyphList(GlyphList* keepList);
LF_ERROR        Keep_populateGlyphList(GlyphList* keepList, const GlyphID* gids, ULONG numGids);
LF_ERROR        Keep_addGlyph(GlyphList* keepList, GlyphID id);
LF_ERROR        Keep_coverageExists(GlyphList* keepList, GlyphID glyphID);
LF_ERROR        Keep_setExists(GlyphList* keepList, LF_VECTOR* glyphs);
GlyphID*        Keep_getSortedGlyphIDList(GlyphList* list, ULONG* length);
LF_ERROR        Keep_dumpKeepList(GlyphList* keepList);

#ifdef __cplusplus
}
#endif

#endif // end of __KEEP_TABLE_H__
