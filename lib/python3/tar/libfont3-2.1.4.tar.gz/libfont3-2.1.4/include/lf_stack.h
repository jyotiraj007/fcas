// Copyright (C) 2014 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// lf_stack.h

#ifndef __LF_STACK_H__
#define __LF_STACK_H__

#include <stdio.h>
#include "data_types.h"
#include "lf_error.h"
#include "lf_vector.h"

#ifdef __cplusplus
extern "C" {
#endif

typedef LF_VECTOR    LF_STACK;

#define stack_create()   vector_create(4,4)
#define stack_init(s)    vector_init(s, 4, 4)
#define stack_empty(s)   vector_empty(s)
#define stack_push(s,d)  vector_push_back(s,d)
#define stack_pop(s)     vector_pop_back(s)

#ifdef __cplusplus
}
#endif

#endif //__LF_STACK_H__
