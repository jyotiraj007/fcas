// Copyright (C) 2015 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// cff_types.h

#ifndef __CFF_TYPES_H__
#define __CFF_TYPES_H__

#include "lf_core.h"

#ifdef __cplusplus
extern "C" {
#endif

// basic cff data types
typedef BYTE cffCard8;          // 1-byte unsigned number
typedef USHORT cffCard16;       // 2-byte unsigned number
typedef ULONG cffOffset;        // 1, 2, 3, or 4 byte offset (specified by OffSize field)
typedef BYTE cffOffSize;        // 1-byte unsigned number specifies the size of an Offset field or fields
typedef USHORT cffSID;          // 2-byte string identifier


// structure to represent a cff header
typedef struct _cff_header_
{
    cffCard8    major;      // Format major version(starting at 1)
    cffCard8    minor;      // Format minor version (starting at 0)
    cffCard8    hdrSize;    // Header size (bytes)
    cffOffSize  offSize;    // Absolute offset (0) size

} cffHeader;

// structure to represent a variable sized object in a cff INDEX
typedef struct _cff_index_item_
{
    ULONG length;      // length of below data
    BYTE* data;        // blob of data

} cffIndexItem;

// structure to represent a cff INDEX
typedef struct _cff_index_
{
    cffCard16   count;          // Number of objects stored in INDEX
    cffOffSize  offSize;        // Offset array element size (in original table, used for dumping)
    LF_VECTOR   content;        // a vector of cffIndexItem's
    ULONG       size;           // calculated size of the index if it were written, 0 if not calculated yet (i.e. something was removed)

} cffIndex;

// structure to represent info about a seac (standard encoding accented character)
typedef struct _cff_seac_info_
{
    GlyphID base;               // glyph id (adobe std number) of the base glyph
    GlyphID accent;             // glyph id (adobe std number) of the accent glyph
    FIXED accentX;              // x offset of accent
    FIXED accentY;              // y offset of accent
    boolean hasAdw;             // TRUE if the glyph has an advance width offset
    FIXED adwOffset;            // advance width delta

} cffSeacInfo;

typedef struct _cff_bb_
{
    FIXED xMin;
    FIXED xMax;
    FIXED yMin;
    FIXED yMax;

} cffBoundingBox;


// structure to represent a hint pair
typedef struct
{
    int first;
    int second;

} cffHint;

// structure for an individual instruction in a charstring or subroutine
typedef struct
{
    LF_VECTOR   args;               // array of arguments
    BYTE        opcode;             // opcode of the instruction
    BYTE        opcode2;            // 2nd byte of two byte opcode

} cffCSIntruction;

// structure to represent a charstring
typedef struct _cff_analyzed_charstring_
{
    ULONG rawLen;               // len of rawData
    BYTE*  rawData;             // raw data for charstring

    LF_VECTOR* gsubrArray;      // list of the global subroutines that this charstring references (or NULL if none)
    LF_VECTOR* subrArray;       // list of local subroutines that this charstring references (or NULL if none)
    cffSeacInfo* seacInfo;      // non-NULL if this charstring is built from a base and an accent

    cffSID sid;                 // SID for this charstring
    cffCard8 fdi;               // fd index for this glyph if CID font, 0xff otherwise

    boolean isEmpty;            // TRUE if bounding box is empty (to detect space char)
    cffBoundingBox bb;          // bounding box for the charstring

    boolean hasAdwAdj;          // TRUE if this charstring has a non-default advance
    int advanceWidthAdj;        // adjustment to nominal width if above is TRUE

    int numPointsMax;           // maximum number of points this glyph could have
    int numContours;            // number of contours in the glyph

    // Below are used when fully analyzing

    boolean hasNonInitialHints; // TRUE if the charstring has hints which not at the beginning of the charstring
    int numHintmasks;           // number of hintmask operations this charstring has
    LF_VECTOR* hstems;          // vector of cffHint *s
    LF_VECTOR* vstems;          // vector of cffHint *s

    boolean canRefit;           // TRUE if this charstring meets criteria to be refit

} cffAnalyzedCharstring;



// Structure to represent the content of a private DICT (either the main one or those for each Font DICT in a CID font)
// the items which are ints, are read in as generic cff 'numbers' (via int_args()), but are really unsigned values.
typedef struct
{
    int* BlueValues;
    int numBlueValues;
    int* OtherBlues;
    int numOtherBlues;
    int* FamilyBlues;
    int numFamilyBlues;
    int* FamilyOtherBlues;
    int numFamilyOtherBlues;
    double BlueScale;
    double BlueShift;
    double BlueFuzz;
    double StdHW;
    double StdVW;
    int* StemSnapH;
    int numStemSnapH;
    int* StemSnapV;
    int numStemSnapV;
    boolean  ForceBold;
    int LanguageGroup;
    double ExpansionFactor;
    double initialRandomSeed;
    int subrsoff;
    double defaultwidthX;
    double nominalwidthX;

} PRIVATEDICT;

// structure to represent a FD select
typedef struct _cff_fd_select_
{
    cffCard8    origFormat;                  // the original format (used for dumping info only)
    cffCard8*   fdIndexArray;                // an array of numGlyphs, containing the fd index for each glyph

} cffFDSelect;


// structure to represent info about a built Font Dict
typedef struct _cff_builtfdinfo_
{
    cffIndex*   localSubr;                  // local subroutine index for this range
    BYTE*       encodedPrivateDict;
    LONG        encodedPrivateDictSize;

} cffBuiltFDInfo;

// structure to represent the ROS (Registry-Ordering-Supplement) in the topdict
typedef struct _cff_ros_
{
    cffSID  Registry;
    cffSID  Ordering;
    LONG    Supplement;

} cffROS;

// enums for which encoding is used in the font
typedef enum
{
    CFF_STANDARD = 0,
    CFF_EXPERT,
    CFF_CUSTOM

} cffEncodingID;

// structure to hold a supplemental encoding
typedef struct
{
    cffCard8        code;           // character code
    cffSID          sid;            // corresponding sid

} cffSupplement;

// structure for the font's Encoding
typedef struct
{
    cffEncodingID   id;                 // encoding used in font
    cffCard8        origFormat;         // format (of custom) encoding
    cffCard8        nCodes;             // number of codes
    cffCard8*       codes;              // array of nCodes codes
    cffCard8        nSups;              // number of supplements
    cffSupplement*  sups;               // array of nSups cffSupplement's (or NULL)

} cffEncoding;

// structure to represent the parsed content of a cff top DICT
typedef struct
{
    cffSID version;
    cffSID Notice;
    cffSID copyright;
    cffSID FullName;
    cffSID FamilyName;
    cffSID Weight;
    boolean isFixedPitch;
    double italicAngle;
    LONG underlinePosition;
    LONG underlineThickness;
    LONG PaintType;
    LONG charstringType;
    boolean nonDefaultMatrix;
    double fontmatrix[6];
    double normalizedMatrix[6];
    LONG UniqueID;
    LONG fontbbox[4];
    double StrokeWidth;
    int* XUID;
    int numXUID;
    LONG charsetOffset;
    LONG encodingOffset;
    LONG charStringsOffset;
    LONG privateDictOffset;
    LONG privateDictSize;
    LONG SyntheticBase;
    cffSID PostScript;
    cffSID BaseFontName;
    int* BaseFontBlend;
    int numBaseFontBlendVals;

    // CID related fields
    cffROS ros;
    double CIDFontVersion;
    LONG CIDFontRevision;
    LONG CIDFontType;
    LONG CIDcount;
    LONG UIDBase;
    LONG FDArrayOffset;
    LONG FDSelectOffset;
    cffSID FDFontName;

} CFFTOPDICT;

// structure to represent info about a Font Dict
typedef struct _cff_fdinfo_
{
    CFFTOPDICT* topdict;            // parsed font dict for this range
    PRIVATEDICT* privateDict;       // parsed private dict for this range
    cffIndex*   localSubr;          // parsed local subroutine index for this range

} cffFDInfo;


// structure to represent the parsed cff table
typedef struct {
    cffHeader       header;
    cffIndex*       nameIndex;
    cffIndex*       topDictIndex;
    cffIndex*       stringIndex;
    cffIndex*       globalSubrIndex;
    cffEncoding     encoding;
    cffSID*         charset;
    cffFDSelect     fdSelect;
    cffIndex*       charStringsIndex;
    cffIndex*       FDIndex;
    PRIVATEDICT*    privateDict;
    cffIndex*       localSubrIndex;

    boolean         isCID;
    CFFTOPDICT*     mainTopDict;
    cffCard8        activeFDIndex;
    CFFTOPDICT*     activeTopDict;
    cffFDInfo*      fdInfo;
    USHORT          numGlyphs;

} CFF_TAB;

// structure to represent data which will be written to a cff table
typedef struct {
    cffHeader       header;
    cffIndex*       nameIndex;
    cffIndex*       topDictIndex;
    cffIndex*       stringIndex;
    cffIndex*       globalSubrIndex;
    cffIndex*       charStringsIndex;
    cffIndex*       FDIndex;
    cffIndex*       localSubrIndex;

    boolean         isCID;
    USHORT          numGlyphs;

    BYTE*           encodedCharset;
    LONG            encodedCharsetSize;

    BYTE*           encodedPrivateDict;
    LONG            encodedPrivateDictSize;

    BYTE*           encodedFDSelect;
    LONG            encodedFDSelectSize;

    cffBuiltFDInfo* FDinfoArray;                // CID only, array of built data for the dicts
    LONG            FDcount;                    // number of font dictionaries

    cffBoundingBox  bb;                         // bounding box for the font

} CFF_TAB_BUILD;

#ifdef __cplusplus
}
#endif

#endif //__CFF_TYPES_H__
