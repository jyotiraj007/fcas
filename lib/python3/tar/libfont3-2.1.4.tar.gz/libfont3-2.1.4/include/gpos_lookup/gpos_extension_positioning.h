// Copyright (C) 2014 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// gpos_extension_positioning.h


/* ============================================================================
    @summary

============================================================================ */
#ifndef __GPOS_LOOKUP_EXTENSION_POSITIONING_H__
#define __GPOS_LOOKUP_EXTENSION_POSITIONING_H__

#include "data_types.h"
#include "offset_table_sfnt.h"


#ifdef __cplusplus
extern "C" {
#endif


TABLE_HANDLE GPOS_readExtensionPositioning(LF_STREAM* stream);



#ifdef __cplusplus
}
#endif

#endif    // end of __GPOS_LOOKUP_EXTENSION_POSITIONING_H__
