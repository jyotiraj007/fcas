// Copyright (C) 2014 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// gpos_marktomark.h



/* ============================================================================
    @summary

============================================================================ */
#ifndef __GPOS_LOOKUP_MARKTOMARK_ATTACHMENT_H__
#define __GPOS_LOOKUP_MARKTOMARK_ATTACHMENT_H__

#include "data_types.h"
#include "offset_table_sfnt.h"
#include "lf_vector.h"
#include "base_table.h"

#ifdef __cplusplus
extern "C" {
#endif

typedef struct _gpos_marktomark
{
    base_table        Base;
    USHORT            PosFormat;
    coverage_table    Mark1Coverage;
    coverage_table    Mark2Coverage;
    USHORT            ClassCount;
    LF_VECTOR         Mark1Array;           // array of mark_record*
    LF_VECTOR         Mark2Array;           // array of LF_VECTOR* of array of anchor_table*
} gpos_marktomark;

TABLE_HANDLE GPOS_readMarkToMark(LF_STREAM* stream);
size_t       GPOS_getMarkToMarkSize(gpos_marktomark* table);
size_t       GPOS_buildMarkToMark(gpos_marktomark* table, LF_STREAM* stream);
LF_ERROR     GPOS_markToMarkRemoveGlyph(gpos_marktomark* table, GlyphID glyphID);
LF_ERROR     GPOS_markToMarkRemapTable(gpos_marktomark* table, LF_MAP *remap);
LF_ERROR     GPOS_markToMarkSetAnchorFmt1(gpos_marktomark* table);
void         GPOS_freeMarkToMark(gpos_marktomark* mm);
#ifdef LF_OT_DUMP
LF_ERROR     GPOS_dumpMarkToMark(gpos_marktomark* table);
#endif
#ifdef __cplusplus
}
#endif

#endif    // end of __GPOS_LOOKUP_MARKTOMARK_ATTACHMENT_H__
