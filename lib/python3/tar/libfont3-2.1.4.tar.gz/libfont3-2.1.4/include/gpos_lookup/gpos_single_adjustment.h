// Copyright (C) 2014 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// gpos_single_adjustment.h


/* ============================================================================
    @summary

============================================================================ */

#include "data_types.h"
#include "value_record.h"
#include "coverage_table.h"
#include "base_table.h"


#ifndef __GPOS_LOOKUP_SINGLE_ADJUSTMENT_H__
#define __GPOS_LOOKUP_SINGLE_ADJUSTMENT_H__

#ifdef __cplusplus
extern "C" {
#endif

typedef struct _gpos_single_adjustment_1
{
    ValueRecord    Value;            //Defines positioning value(s)-applied to all glyphs in the Coverage table
} gpos_single_adjustment_1;

typedef struct _gpos_single_adjustment_2
{
    LF_VECTOR    Values;
} gpos_single_adjustment_2;


typedef struct _gpos_single_adjustment
{
    base_table        Base;
    USHORT            PosFormat;
    coverage_table    Coverage;
    USHORT            ValueFormat;    // Defines the types of data in the ValueRecord

    union _format
    {
        gpos_single_adjustment_1 format1;
        gpos_single_adjustment_2 format2;
    } format;

} gpos_single_adjustment;



TABLE_HANDLE    GPOS_readSingleAdjustment(LF_STREAM* stream);
size_t          GPOS_getSingleAdjustmentSize(gpos_single_adjustment* table);
size_t          GPOS_buildSingleAdjustment(gpos_single_adjustment* table, LF_STREAM* stream);
LF_ERROR        GPOS_singleAdjustRemoveGlyph(gpos_single_adjustment* table, GlyphID index);
LF_ERROR        GPOS_singleAdjustRemapTable(gpos_single_adjustment* table, LF_MAP *remap);
#ifdef LF_OT_DUMP
LF_ERROR        GPOS_dumpSingleAdjust(gpos_single_adjustment* sa);
#endif
void            GPOS_freeSingleAdjust(gpos_single_adjustment* sa);


#ifdef __cplusplus
}
#endif

#endif    // end of __GPOS_LOOKUP_SINGLE_ADJUSTMENT_H__
