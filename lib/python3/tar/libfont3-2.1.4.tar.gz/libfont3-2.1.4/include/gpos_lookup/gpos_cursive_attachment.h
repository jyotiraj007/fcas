// Copyright (C) 2014 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// gpos_cursive_attachment.h



/* ============================================================================
    @summary

============================================================================ */

#include "data_types.h"
#include "anchor.h"
#include "coverage_table.h"
#include "lf_vector.h"
#include "base_table.h"


#ifndef __GPOS_LOOKUP_CURSIVE_ATTACHMENT_H__
#define __GPOS_LOOKUP_CURSIVE_ATTACHMENT_H__

#ifdef __cplusplus
extern "C" {
#endif

typedef struct _entry_exit_record
{
    anchor_table    EntryAnchor;
    anchor_table    ExitAnchor;
} entry_exit_record;

typedef struct _gpos_cursive_attachment
{
    base_table        Base;

    USHORT            PosFormat;
    coverage_table    Coverage;
    LF_VECTOR         EntryExitRecords;
} gpos_cursive_attachment;

TABLE_HANDLE GPOS_readCursiveAttachment(LF_STREAM* stream);
size_t       GPOS_getCursiveAttachmentSize(gpos_cursive_attachment* table);
size_t       GPOS_buildCursiveAttachment(gpos_cursive_attachment* table, LF_STREAM* stream);
LF_ERROR     GPOS_cursiveAttachRemoveGlyph(gpos_cursive_attachment* table, GlyphID glyphID);
LF_ERROR     GPOS_cursiveAttachRemapTable(gpos_cursive_attachment* table, LF_MAP *remap);
LF_ERROR     GPOS_cursiveAttachmentSetAnchorFmt1(gpos_cursive_attachment* table);
#ifdef LF_OT_DUMP
LF_ERROR     GPOS_dumpCursiveAttach(gpos_cursive_attachment* table);
#endif
void         GPOS_freeCursiveAttach(gpos_cursive_attachment* table);

#ifdef __cplusplus
}
#endif

#endif    // end of __GPOS_LOOKUP_CURSIVE_ATTACHMENT_H__
