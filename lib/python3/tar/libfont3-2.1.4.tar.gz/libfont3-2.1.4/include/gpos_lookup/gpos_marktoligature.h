// Copyright (C) 2014 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// gpos_marktoligature.h


/* ============================================================================
    @summary

============================================================================ */
#ifndef __GPOS_LOOKUP_MARKTOLIGATURE_ATTACHMENT_H__
#define __GPOS_LOOKUP_MARKTOLIGATURE_ATTACHMENT_H__

#include "data_types.h"
#include "offset_table_sfnt.h"
#include "lf_vector.h"
#include "base_table.h"

#ifdef __cplusplus
extern "C" {
#endif


typedef struct _gpos_marktoligature
{
    base_table        Base;
    USHORT            PosFormat;
    coverage_table    MarkCoverage;
    coverage_table    LigatureCoverage;
    USHORT            ClassCount;
    LF_VECTOR         MarkArray;
    LF_VECTOR         LigatureArray;
} gpos_marktoligature;



TABLE_HANDLE GPOS_readMarkToLigature(LF_STREAM* stream);
size_t       GPOS_getMarkToLigatureSize(gpos_marktoligature* table);
size_t       GPOS_buildMarkToLigature(gpos_marktoligature* table, LF_STREAM* stream);
LF_ERROR     GPOS_markToLigatureRemoveGlyph(gpos_marktoligature* table, GlyphID glyphID);
LF_ERROR     GPOS_markToLigatureRemapTable(gpos_marktoligature* table, LF_MAP *remap);
LF_ERROR     GPOS_markToLigatureSetAnchorFmt1(gpos_marktoligature* table);
#ifdef LF_OT_DUMP
LF_ERROR     GPOS_dumpMarkToLigature(gpos_marktoligature* table);
#endif
void         GPOS_freeMarkToLigature(gpos_marktoligature* table);



#ifdef __cplusplus
}
#endif

#endif    // end of __GPOS_LOOKUP_MARKTOLIGATURE_ATTACHMENT_H__
