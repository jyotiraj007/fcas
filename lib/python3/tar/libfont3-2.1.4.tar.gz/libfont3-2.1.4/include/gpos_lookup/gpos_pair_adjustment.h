// Copyright (C) 2014 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// gpos_pair_adjustment.h


/* ============================================================================
    @summary

============================================================================ */

#include "data_types.h"
#include "value_record.h"
#include "lf_vector.h"
#include "coverage_table.h"
#include "classdef.h"
#include "base_table.h"


#ifndef __GPOS_LOOKUP_PAIR_ADJUSTMENT_H__
#define __GPOS_LOOKUP_PAIR_ADJUSTMENT_H__

#ifdef __cplusplus
extern "C" {
#endif

typedef struct _pair_value_record
{
    GlyphID        SecondGlyph;    //GlyphID of second glyph in the pair-first glyph is listed in the Coverage table
    ValueRecord    Value1;         //Positioning data for the first glyph in the pair
    ValueRecord    Value2;         //Positioning data for the second glyph in the pair    
} pair_value_record;

typedef struct _gpos_pair_adjustment_1
{
    LF_VECTOR    PairOffsets;
    LF_MAP       PairSetMap;
} gpos_pair_adjustment_1;

typedef struct _gpos_class2_record
{
    ValueRecord Value1;            //Positioning for first glyph-empty if ValueFormat1 = 0
    ValueRecord Value2;            //Positioning for second glyph-empty if ValueFormat2 = 0
} gpos_class2_record;

typedef struct _gpos_pair_adjustment_2
{
    class_def    ClassDef1;        //left side ClassDef table
    class_def    ClassDef2;        //right side ClassDef table
    USHORT       Class1Count;      //Number of classes in ClassDef1 table-includes Class0
    USHORT       Class2Count;      //Number of classes in ClassDef2 table-includes Class0
    LF_VECTOR    Class1Records;    // A vector of vectors of gpos_class2_record*
} gpos_pair_adjustment_2;

typedef struct _gpos_pair_adjustment
{
    base_table        Base;
    USHORT            PosFormat;       //Format identifier-format = 1
    coverage_table    Coverage;        //Offset to Coverage table-from beginning of PairPos subtable-only the first glyph in each pair
    USHORT            ValueFormat1;    //Defines the types of data in ValueRecord1-for the first glyph in the pair -may be zero (0)
    USHORT            ValueFormat2;    //Defines the types of data in ValueRecord2-for the second glyph in the pair -may be zero (0)

    union _pair_format
    {
        gpos_pair_adjustment_1    format1;
        gpos_pair_adjustment_2    format2;
    } pair_format;
} gpos_pair_adjustment;

TABLE_HANDLE    GPOS_readPairAdjustment(LF_STREAM* stream);
size_t          GPOS_buildPairAdjustment(gpos_pair_adjustment* table, LF_STREAM* stream);
size_t          GPOS_getPairAdjustmentSize(gpos_pair_adjustment* table);
LF_ERROR        GPOS_pairAdjustRemoveGlyph(gpos_pair_adjustment* table, GlyphID glyphID);
LF_ERROR        GPOS_pairAdjustRemapTable(gpos_pair_adjustment* table, LF_MAP *remap);
void            GPOS_freePairAdjust(gpos_pair_adjustment* table);
LF_ERROR        GPOS_prunePairAdjustmentLookupRecords(gpos_pair_adjustment* table);
#ifdef LF_OT_DUMP
LF_ERROR        GPOS_dumpPairAdjustment(gpos_pair_adjustment* table);
#endif
#ifdef __cplusplus
}
#endif

#endif    // end of __GPOS_LOOKUP_PAIR_ADJUSTMENT_H__
