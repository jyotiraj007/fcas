﻿// Copyright (C) 2014 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// svg_core.h

#ifndef __SVG_CORE_H__
#define __SVG_CORE_H__

#include "lf_core.h"
#include "stream.h"

#ifdef __cplusplus
extern "C" {
#endif

LF_ERROR SVG_writeToStream(LF_FONT* lfFont, LF_WRITE_PARAMS *params, LF_STREAM* stream, size_t* size);
LF_ERROR SVG_getMaxSize(LF_FONT* lfFont, LF_WRITE_PARAMS *params, size_t* size);

#ifdef __cplusplus
}
#endif

#endif //__SVG_CORE_H__
