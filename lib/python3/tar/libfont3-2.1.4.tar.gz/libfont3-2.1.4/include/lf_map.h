// Copyright (C) 2014 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// lf_map.h

#ifndef __LF_MAP_H__
#define __LF_MAP_H__

#include <stdio.h>
#include "data_types.h"
#include "lf_error.h"
#include "lf_stack.h"

#ifdef __cplusplus
extern "C" {
#endif

typedef int (*LF_COMPARE_FUNC)(void*, void*);

typedef enum _rb_node_color    
{ 
    RED, BLACK 
} rb_node_color;

typedef struct _rb_tree_node
{
    void*    key;
    void*    data;

    struct _rb_tree_node*    left;
    struct _rb_tree_node*    right;
    struct _rb_tree_node*    parent;

    rb_node_color    color;
} rb_tree_node;

typedef struct _rb_tree
{
    rb_tree_node*    root;
    LF_COMPARE_FUNC    compare;
    ULONG            count;
} rb_tree;

typedef rb_tree        LF_MAP;

typedef struct _LF_MAP_ITER
{
    rb_tree_node*    node;
    LF_STACK        stack;
} LF_MAP_ITER;

int        integer_compare(void* left, void* right);

LF_API void             map_init(LF_MAP* map, LF_COMPARE_FUNC func);
LF_API LF_MAP*          map_create(LF_COMPARE_FUNC func);
LF_API ULONG            map_size(const LF_MAP* map);
LF_API rb_tree_node*    map_insert(LF_MAP* map, void* key, void* data);
LF_API void*            map_at(const LF_MAP* map, void* key);
LF_API LF_MAP_ITER*     map_begin(LF_MAP* map);
LF_API rb_tree_node*    map_next(LF_MAP_ITER* iter);
LF_API void             map_erase(LF_MAP* map, void* key);
LF_API boolean          map_empty(LF_MAP* map);
LF_API void             map_clear(LF_MAP* map);
LF_API void             map_free_iter(LF_MAP_ITER* iter);
LF_API boolean          map_key_exists(LF_MAP* map, void* key);
LF_API void             map_free(LF_MAP* map);

#ifdef __cplusplus
}
#endif

#endif //__LF_MAP_H__
