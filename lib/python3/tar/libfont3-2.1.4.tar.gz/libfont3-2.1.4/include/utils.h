// Copyright (C) 2014, 2015 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// utils.h

#ifndef __UTILS_H__
#define __UTILS_H__

#include <stdio.h>
#include <string.h>
#include "data_types.h"
#include "lf_vector.h"

#ifdef __cplusplus
extern "C" {
#endif

#ifndef ROUNDING_EPSILON
#define ROUNDING_EPSILON 0.0000001
#endif
#define UTILS_round(x)   ((int)UTILS_roundhalfeven(x, ROUNDING_EPSILON))
double UTILS_roundhalfeven(double number, double epsilon);


ULONG UTILS_CalcTableChecksum(BYTE* table, size_t length);
ULONG UTILS_CalcTableRecordChecksum(BYTE* table, size_t Length);
ULONG UTILS_CalcHeaderChecksum(BYTE* header);
BYTE* UTILS_AllocTable(size_t* length);
BYTE* UTILS_PadTable(BYTE **table, size_t length, ULONG* padLen);
LF_API USHORT UTILS_getCount(LF_VECTOR* v);


char* UTILS_getErrorMessage(LF_ERROR e);


int UTILS_snprintf(char *str, size_t size, const char *format, ...);


LF_API void UTILS_quicksortGlyphID(GlyphID list[], LONG m, LONG n);


#ifdef _DEBUG
void    UTILS_Assert(char*, unsigned);
#define    ASSERT(f)         \
        if (!(f))                \
            UTILS_Assert(__FILE__, __LINE__)

void UTILS_AssertMsg(char* msg, char* strFile, unsigned uline);
#define    ASSERT_MSG(f, _msg)    \
        if (!(f))                     \
            UTILS_AssertMsg(_msg, __FILE__, __LINE__)
#else
#define ASSERT(f)
#define ASSERT_MSG(f, _msg)
#endif


// Verbosity levels for logging and dumping.
typedef enum
{
    LIBFONT_VERBOSE_NONE,
    LIBFONT_VERBOSE_ERRORS,
    LIBFONT_VERBOSE_INFO,
    LIBFONT_VERBOSE_WARNINGS,
    LIBFONT_VERBOSE_ALL
} eVERBOSE;

#ifdef LF_LOGGING

LF_API void    UTILS_openLog(const char* file);
LF_API void    UTILS_closeLog(void);

// BASE filename removes the path of the file ... keeps logging a little more clean looking
#define BASE_FILENAME /*lint -e{613}*/ (char*)( (strrchr(__FILE__, '\\') != NULL) ? (strrchr(__FILE__, '\\') + 1) : __FILE__)

void    UTILS_LogMsg(char*, char*, unsigned);
#define DEBUG_LOG(_msg)                \
            UTILS_LogMsg(_msg, BASE_FILENAME, __LINE__)

void UTILS_LogMsgValue(char* msg, char* file, unsigned uline, int param);
#define DEBUG_LOG_VALUE(_msg, _param)                \
            UTILS_LogMsgValue(_msg, BASE_FILENAME, __LINE__, _param)

void    UTILS_LogError(char*, char*, unsigned);
#define DEBUG_LOG_ERROR(_err)        \
            UTILS_LogError(_err, BASE_FILENAME, __LINE__)

void    UTILS_LogWarning(char*, char*, unsigned);
#define DEBUG_LOG_WARNING(_warn)    \
            UTILS_LogWarning(_warn, BASE_FILENAME, __LINE__)

void    UTILS_LogErrorStatus(char* error, char* file, unsigned uline, LF_ERROR status);
#define DEBUG_LOG_STATUS(_msg, _status)    \
            UTILS_LogErrorStatus(_msg, BASE_FILENAME, __LINE__, _status)

#define LOG_ASSERT(file, line, msg) \
            UTILS_LogError(msg, file, line); \
            if (hLogfile) fflush(hLogfile);
#else
#define DEBUG_LOG(_msg)
#define DEBUG_LOG_VALUE(_msg, _param)
#define DEBUG_LOG_ERROR(_err)
#define DEBUG_LOG_WARNING(_warn)
#define DEBUG_LOG_ALLOCMEMORY(_allocmem)
#define DEBUG_LOG_STATUS(_msg, _status)
#define LOG_ASSERT(file, line, msg)
#endif


#ifdef LF_OT_DUMP
LF_API void    UTILS_openXML(const char* xmlfilename);
LF_API void    UTILS_closeXML(void);

void UTILS_xmlOpenNode(char* node);
#define    XML_START(_msg) \
        UTILS_xmlOpenNode(_msg);

void UTILS_xmlCloseNode(char* node);
#define    XML_END(_msg) \
        UTILS_xmlCloseNode(_msg);

void UTILS_xmlNode(char* node, char* msg);
#define    XML_NODE(_node, _msg) \
        UTILS_xmlNode(_node, _msg);

void UTILS_xmlDataNode(char* node, int data);
#define    XML_DATA_NODE(_node, _data) \
        UTILS_xmlDataNode(_node, _data);

void UTILS_xmlComment(char* comment, int data);
#define    XML_COMMENT(_comment, _data) \
        UTILS_xmlComment(_comment, _data);

void UTILS_xmlCommentIndex(char* comment, int index, int total);
#define    XML_COMMENT_INDEX(_comment, _index, _total) \
        UTILS_xmlCommentIndex(_comment, _index, _total);

void UTILS_xmlStartCommentIndex(char* node, int index, int total);
#define    XML_START_COMMENT(_node, _index, _total) \
        UTILS_xmlStartCommentIndex(_node,  _index, _total);

void UTILS_xmlEndCommentIndex(char* node, int index, int total);
#define    XML_END_COMMENT(_node, _index, _total) \
        UTILS_xmlEndCommentIndex(_node,  _index, _total);

void UTILS_xmlStartCommentMsgIndex(char* node, char* msg, int index, int total);
#define XML_START_COMMENT_INDEX(_node, _msg, _index, _total) \
        UTILS_xmlStartCommentMsgIndex(_node, _msg, _index, _total);
#else
#define XML_START(_msg)
#define XML_END(_msg)
#define XML_DATA_NODE(_node, _data) (void)_data
#define XML_NODE(_node, _msg)
#define XML_COMMENT(_comment, _data)
#define XML_COMMENT_INDEX(_comment, _index, _total)
#define XML_START_COMMENT(_node, _index, _total)
#define XML_START_COMMENT(_node, _index, _total)
#define XML_START_COMMENT_INDEX(_node, _msg, _index, _total)
#endif


#define FREE(_ptr)                          \
    if ((_ptr))                             \
        {                                   \
        free(_ptr);                         \
        _ptr = NULL;                        \
        }

#ifdef __cplusplus
}
#endif

#endif //__UTILS_H__
