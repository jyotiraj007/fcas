﻿// Copyright (C) 2016 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// svg_defs.h

#ifndef __SVG_DEFS_H__
#define __SVG_DEFS_H__

#ifdef __cplusplus
extern "C" {
#endif


// The spec allows for 64 bytes (32 characters) for the the Postscript name.
//  Our Webfonter process may create fonts that exceed that, so we allow for that.
#define MAX_POSTSCRIPT_NAME_LEN 36

#define SVG_MID_VALUE(a,b)  (a + (b - a) / 2)

#define SVG_SVG_TAG_BEGIN   "<svg"
#define SVG_SVG_TAG_END     "</svg>\n"
#define SVG_METADATA_TAG    "metadata"
#define SVG_DEFS_TAG        "defs"
#define SVG_FONT_TAG        "font"
#define SVG_FONTFACE_TAG    "font-face"
#define SVG_MISSING_TAG     "missing-glyph"
#define SVG_GLYPH_TAG       "glyph"
#define SV_TEXT_TAG         "text"
#define SV_HKERN_TAG         "hkern"

#define SVG_NAMESPACE_URI   "http://www.w3.org/2000/svg"
#define SVG_PUBLIC_ID       "\"-//W3C//DTD SVG 1.0//EN\"" // not required for SVG 1.2. 
#define SVG_SYSTEM_ID       "\"http://www.w3.org/TR/2001/REC-SVG-20010904/DTD/svg10.dtd\""

#define SVG_METADATA_VERSION_TAG    "version"
#define SVG_METADATA_ID_TAG         "id"
#define SVG_METADATA_VENDOR_TAG     "vendor"
#define SVG_METADATA_CREDITS_TAG    "credits"
#define SVG_METADATA_NAME_TAG       "name"
#define SVG_METADATA_URL_TAG        "URL"
#define SVG_MATADATA_ROLE_TAG       "role"
#define SVG_METADATA_LICENSE_TAG    "license"
#define SVG_METADATA_COPYRIGHT_TAG  "copyright"
#define SVG_METADATA_TRADEMARK_TAG  "trademark"
#define SVG_METADATA_LICENSEE_TAG   "licensee"

#define SVG_METADATA_VERSION_VALUE      "1.0"
#define SVG_METADATA_VENDOR_VALUE       "Monotype Imaging Inc."
#define SVG_METADATA_CREDITS_NAME_VALUE "Fonts.com WebFonts"
#define SVG_METADATA_CREDITS_URL_VALUE  "http://www.fonts.com"
#define SVG_METADATA_CREDITS_ROLE_VALUE "Home of the Web fonts"
#define SVG_METADATA_LICENSE_URL_VALUE  "http://www.fonts.com/info/legal"
#define SVG_METADATA_LICENSEE_NAME_VALUE ""

#define SVG_HORIZ_ADV_X_ATTRIBUTE   "horiz-adv-x"
#define SVG_FONT_FAMILY_ATTRIBUTE   "font-family"
#define SVG_PANOSE_ATTRIBUTE        "panose-1"
#define SVG_ASCENT_ATTRIBUTE        "ascent"
#define SVG_DESCENT_ATTRIBUTE       "descent"
#define SVG_UNITS_ATTRIBUTE         "units-per-em"
#define SVG_ALPHABETIC_ATTRIBUTE    "alphabetic"
#define SVG_UNICODE_ATTRIBUTE       "unicode"
#define SVG_GLYPH_NAME_ATTRIBUTE    "glyph-name"
#define SVG_X_ATTRIBUTE             "x"
#define SVG_Y_ATTRIBUTE             "y"
#define SVG_FONT_SIZE_ATTRIBUTE     "font-size"
#define SVG_FILL_ATTRIBUTE          "fill"
#define SVG_U1_ATTRIBUTE            "u1="
#define SVG_U2_ATTRIBUTE            "u2="

#define SVG_PATH_ARC                'A'
#define SVG_PATH_CLOSE              'Z'
#define SVG_PATH_CUBIC_TO           'C'
#define SVG_PATH_MOVE_TO            'M'
#define SVG_PATH_LINE_TO            'L'
#define SVG_PATH_VERTICAL_LINE_TO   'V'
#define SVG_PATH_HORIZONTAL_LINE_TO 'H'
#define SVG_PATH_QUAD_TO            'Q'
#define SVG_PATH_SMOOTH_QUAD_TO     'T'

#define CHARACTER_CODE_NEWLINE          10 //0xA
#define CHARACTER_CODE_CARRIAGE_RETURN  13 //0xD
#define CHARACTER_CODE_SPACE            32 // 0x20

#if defined(WIN32) || defined(WIN64)
#undef _T
#define _T(x)      L ## x
#else
#undef _T
#define _T(x)      (x)
#endif

#if defined(WIN32) || defined(WIN64) || defined(OS_MACOSX)
#define SVG_SAMPLE_TEXT_1           _T("ABCDEFGHIJKLMNOPQRSTUVWXYZ abcdefghijklmnopqrstuvwxyz AÁÀÂÄÅÃÆ CÇ DÐ EÉÈÊË I Í Ì Î Ï NÑ")
#define SVG_SAMPLE_TEXT_2           _T("OÓÒÔÖÕØŒ SŠ UÚÙÛÜ YÝŸ ZŽ Þ aáàâäåãæ cç dð eéèêë i ı í ì î ï nñ oóòôöõøœ sšß uúùûü yýÿ zž")
#define SVG_SAMPLE_TEXT_3           _T("þ 1234567890 ½ ¼ ¾ % ‰ $¢£¥ƒ€¤ † ‡ § ¶ # ^~µ +×± &lt; = &gt; ÷¬ !¡?¿ &quot; &amp; &apos; * ° . , : ; () [ \\ ] {} / |")
#define SVG_SAMPLE_TEXT_4           _T("¦ _ ‚ „ … ‹› «» ‘ ’ “ ” • ­ - – — @ © ® ™ ªº ¹²³ ´ ` ˆ ˜ ¨ ¯ · ¸")
#else
#define SVG_SAMPLE_TEXT_1           _T(u"ABCDEFGHIJKLMNOPQRSTUVWXYZ abcdefghijklmnopqrstuvwxyz AÁÀÂÄÅÃÆ CÇ DÐ EÉÈÊË I Í Ì Î Ï NÑ")
#define SVG_SAMPLE_TEXT_2           _T(u"OÓÒÔÖÕØŒ SŠ UÚÙÛÜ YÝŸ ZŽ Þ aáàâäåãæ cç dð eéèêë i ı í ì î ï nñ oóòôöõøœ sšß uúùûü yýÿ zž")
#define SVG_SAMPLE_TEXT_3           _T(u"þ 1234567890 ½ ¼ ¾ % ‰ $¢£¥ƒ€¤ † ‡ § ¶ # ^~µ +×± &lt; = &gt; ÷¬ !¡?¿ &quot; &amp; &apos; * ° . , : ; () [ \\ ] {} / |")
#define SVG_SAMPLE_TEXT_4           _T(u"¦ _ ‚ „ … ‹› «» ‘ ’ “ ” • ­ - – — @ © ® ™ ªº ¹²³ ´ ` ˆ ˜ ¨ ¯ · ¸")
#endif

#define SVG_X_ATTRIBUTE_VALUE           "40"
#define SVG_Y_ATTRIBUTE_VALUE           40
#define SVG_FONT_SIZE_ATTRIBUTE_VALUE   "30"
#define SVG_FILL_ATTRIBUTE_VALUE        "#933"

#define SVG_ARABIC_FORM_ATTRIBUTE           "arabic-form"
#define SVG_INITIAL_VALUE                   "initial"
#define SVG_ISOLATED_VALUE                  "isolated"
#define SVG_MEDIAL_VALUE                    "medial"
#define SVG_FINAL_VALUE                     "terminal"
#define GSUB_SCRIPT_TAG_ARAB                (('a' << 24) | ('r' << 16) | ('a' << 8) | 'b')
#define GSUB_FEATURE_SCRIPT_TAG_INITIAL     (('i' << 24) | ('n' << 16) | ('i' << 8) | 't')
#define GSUB_FEATURE_SCRIPT_TAG_MEDIAL      (('m' << 24) | ('e' << 16) | ('d' << 8) | 'i')
#define GSUB_FEATURE_SCRIPT_TAG_FINAL       (('f' << 24) | ('i' << 16) | ('n' << 8) | 'a')

#ifdef __cplusplus
}
#endif

#endif //__SVG_DEFS_H__

