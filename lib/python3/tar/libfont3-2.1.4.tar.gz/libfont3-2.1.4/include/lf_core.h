// Copyright (C) 2014-2017 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
/// \file lf_core.h

#ifndef __LF_CORE_H__
#define __LF_CORE_H__

#include "data_types.h"
#include "lf_error.h"
#include "lf_map.h"
#include "lf_vector.h"
#include "lf_version.h"

#ifdef __cplusplus
extern "C" {
#endif

//! Types of fonts supported.
typedef enum __font_type__
{
    eLF_UNDETERMINED,   ///< Unknown font type
    eLF_SFNT_FONT,      ///< Regular OpenType font
    eLF_EOT_FONT,       ///< EOT font
    eLF_WOFF_FONT,      ///< WOFF font
    eLF_WOFF2_FONT,     ///< WOFF2 font
    eLF_SVG_FONT,       ///< SVG font (write only)
    eLF_CFF_FONT        ///< CFF font

} LF_FONT_TYPE;

//! Signatures for various font types
#define SIG_VERSION1    0x00010000
#define SIG_VERSION2    0x00020000
#define SIG_VERSION2_1  0x00020001
#define SIG_VERSION2_2  0x00020002
#define SIG_TRUETYPE    0x74727565
#define SIG_CFF         0x4F54544F
#define SIG_WOFF        0x774F4646
#define SIG_WOFF2       0x774F4632
#define SIG_UNKONWN     0xFFFFFFFF

//! Flags defining which tables to retain.
#define LF_KEEP_MINIMUN_SET             0x00    ///< keep only required tables [OS/2, cmap, gasp, glyf, head, hhea, hmtx, loca, maxp, name, post, vhea, vmtx, cvt, fpgm, prep]
#define LF_KEEP_DEVICE_METRICS_TABLES   0x02    ///< keep device metrics tables [hdmx, vdmx]
#define LF_KEEP_KERN_TABLE              0x04    ///< keep kern table [kern]
#define LF_KEEP_OPENTYPE_TABLES         0x08    ///< keep OpenType tables [GSUB, GPOS, GDEF]
#define LF_KEEP_VARIATIONS_TABLES       0x10    ///< keep variable font tables [avar, cvar, fmtx, fvar, gvar, HVAR, MVAR, STAT, VVAR]
#define LF_KEEP_DEFAULT_TABLES          0x1f    ///< recommended set of tables to retain when subsetting [all of above]
#define LF_KEEP_EMBEDDED_BITMAP_TABLES  0x20    ///< keep embedded bitmap tables [EBLC, EBDT]
#define LF_KEEP_LTSH_TABLE              0x40    ///< keep LTSH table
#define LF_KEEP_COLOR_BITMAP_TABLES     0x80    ///< keep color bitmap tables [CBLC, CBDT, COLR, CPAL, sbix]
#define LF_KEEP_ALL_EXCEPT_DSIG         0xf0    ///< keep all tables except DSIG.
#define LF_KEEP_ALL_TABLES              0xfff   ///< keep all tables. Note that using this while subsetting may result in the subset font having invalid tables. For example, AAT tables are not currently subsetted.

//! Macros for converting between CFF and other formats.
#define USE_DEFAULT_DESIGN_UNITS (0)
#define DEFAUT_CFF_UPM 1000
#define DEFAUT_TTF_UPM 2048

//! Parameters for writing fonts.
typedef struct _writeParams_
{
    boolean sfnt_ttf;                           ///< If true, output woff, woff2, and eot fonts will be written with glyf and loca tables. Default is that output will have same glyph table as input.
    boolean sfnt_cff;                           ///< If true, output woff, woff2, and eot fonts will be written with a cff table. Default is that output will have same glyph table as input.
    ULONG woffCompressionLevel;                 ///< Controls the compression level when writing to woff (0 - 9). 0 results in uncompressed tables. 1 gives maximum speed; 9 will give maximum compression.
    ULONG woffMinTableSize;                     ///< Minimum size that a table must be for it to be compressed when writing to woff. 0 means no minimum.
    ULONG woff2CompressionLevel;                ///< Controls the compression density vs. speed tradeoff when writing to woff2 (0 - 11). The higher the value, the slower the compression. Default is 6.
    float conversionTolerance;                  ///< Controls how tightly created contours will match original contours when converting between TTF and CFF.
                                                ///< A value of 0.5 will produce a maximum deviation of 1/2 Font Unit at 1000 UPM. Value will be scaled according to the font's UnitsPerEm.
                                                ///< A lower value produces a more accurate fit but takes longer and the curves will have more points.
                                                ///< Allowed range is [0.1 - 10]. Suggested default is 0.5.
    ULONG postTableVersion;                     ///< Version of POST table to write to non-CFF font. Must be 0x00020000 (2.0) , 0x00030000 (3.0) or 0x00000000 to specify to
                                                ///< write the version that was in the original font. Recommended default is 3.0.
                                                ///< When writing CFF font, this value is ignored and a version 3.0 POST table is written.
    char    svgID[64];                          ///< Optional SVG font-id
    USHORT unitsPerEm;                          ///< [future use] Design units of output font, for use with converting to/from CFF; set to 0 for defaults: 1000 for CFF, 2048 for other formats.
} LF_WRITE_PARAMS;



//! Enumeration for types of glyphs
typedef enum _glyph_type_
{
    LF_TYPE_UNKNOWN = 0,
    LF_TYPE_SIMPLE,
    LF_TYPE_COMPOSITE
} LF_GLYPH_TYPE;

//! Enumeration for types of point in an outline.
typedef enum _point_type_
{
    LF_MOVETO = 0,
    LF_LINETO,
    LF_ON_CURVE,
    LF_OFF_CURVE
} LF_POINT_TYPE;

//! Structure to represent a point in an outline.
typedef struct _contour_point_
{
    FIXED x;
    FIXED y;
    LF_POINT_TYPE type;
} LF_CONTOUR_POINT;


//! Structure to represent a (simple) glyph outline.
typedef struct _glyph_outline_
{
    USHORT      numPoints;          ///< Number of points in outline
    USHORT      numContours;        ///< Number of contours in the outline
    USHORT      *endPtsOfContours;  ///< Array of last points of each contour
    LF_VECTOR   points;             ///< array of LF_CONTOUR_POINT*
} LF_GLYPH_OUTLINE;

//! Structure to represent a glyph component
typedef struct _glyph_comp_
{
    USHORT              flags;      ///< Component flag (see TT spec)
    F2DOT14             xoffset;    ///< x-offset for component or point number; type depends on bits 0 and 1 in component flags
    F2DOT14             yoffset;    ///< y-offset for component or point number; type depends on bits 0 and 1 in component flags

    F2DOT14             xscale;     ///< Transformation matrix, may be identity matrix if component is simple
    F2DOT14             scale01;
    F2DOT14             scale10;
    F2DOT14             yscale;
    LF_GLYPH_OUTLINE    outline;    ///< May be empty if glyph is part of a composite glyph
    struct _glyph_comp_ *next;      ///< Next component if this is a composite

} LF_GLYPH_COMPONENT;

//! Structure to represent a glyph. (WARNING: composite glyphs not supported yet)
typedef struct _lf_glyph_
{
    boolean isComposite;            ///< TRUE if the glyph is a composite glyph
#if 0
    SHORT    xMin;                //Minimum x for coordinate data.
    SHORT    yMin;                //Minimum y for coordinate data.
    SHORT    xMax;                //Maximum x for coordinate data.
    SHORT    yMax;                //Maximum y for coordinate data.
#endif

    LF_GLYPH_COMPONENT component;   ///< Glyph component
} LF_GLYPH;



typedef enum _woff_meta_type_
{
    eUNSET = 0,
    eUNCOMPRESSED,
    eWOFF,
    eWOFF2

} woff_meta_type;

typedef struct _woff_info_
{
    USHORT          majorVersion;
    USHORT          minorVersion;
    BYTE*           metaData;
    ULONG           metaDataLen;
    ULONG           metaDataOrigLen;
    BYTE*           privateData;
    ULONG           privateDataLen;
    woff_meta_type  metatDataCompression;

} woff_info;



//! Private data structure that describes a font
/*!
    This data structure must be created and passed to all LibFont API functions.
*/
typedef struct _lf_font
{
    LF_FONT_TYPE  fontType;             // specifies active font type
    LF_FONT_TYPE  origType;             // specifies original font type
    ULONG         origFlavor;           // flavor of original font, one of the SIG* values

    LF_MAP        table_map;

    BYTE*         fontData;
    ULONG         fontSize;
    boolean       ownFontData;

    woff_info     woffInfo;

    union
    {
        TABLE_HANDLE  sfnt;

        TABLE_HANDLE  eot;

        TABLE_HANDLE  woff;

        TABLE_HANDLE  woff2;

    } offset_table;


    TABLE_HANDLE    builtSFNT;
    ULONG           builtSFNTSize;
    TABLE_HANDLE    builtSFNTOffsetTable;
    LF_WRITE_PARAMS builtParams;

    boolean         isSubsetted;
    boolean         isRefitted;
    boolean         obfuscateOnWrite;

} LF_FONT;

// Public interface to the libfont core library functions
LF_API void     LF_getVersion(VERSION_STRING version);
LF_API char*    LF_getErrorMessage(LF_ERROR error);
LF_API LF_FONT* LF_createFont(void);
LF_API LF_ERROR LF_initFont(LF_FONT* lfFont);
LF_API LF_ERROR LF_readFontFromFile(LF_FONT* lfFont, const char* filePath, int tableFlags);
LF_API LF_ERROR LF_getFontInfo(LF_FONT* lfFont, LF_FONT_TYPE* type, ULONG* flavor);
LF_API LF_ERROR LF_readFontFromMemory(LF_FONT* lfFont, BYTE* fontData, ULONG fontSize, int keepFlags, LF_FONT_TYPE* origType);
LF_API LF_ERROR LF_hasTable(LF_FONT* lfFont, ULONG tag, boolean* hasTable);
LF_API LF_ERROR LF_removeTable(LF_FONT* lfFont, ULONG tag);
LF_API LF_ERROR LF_removeHints(LF_FONT* lfFont);
LF_API LF_ERROR LF_setMetaData(LF_FONT* lfFont, const char* metaDataPath);
LF_API LF_ERROR LF_setPrivateData(LF_FONT* lfFont, const char* privateDataPath);
LF_API LF_ERROR LF_clearMetaData(LF_FONT* lfFont);
LF_API LF_ERROR LF_clearPrivateData(LF_FONT* lfFont);
LF_API LF_ERROR LF_writeMetaDataFile(LF_FONT* lfFont, const char* dataPath);
LF_API LF_ERROR LF_writePrivateDataFile(LF_FONT* lfFont, const char* dataPath);
LF_API LF_ERROR LF_defaultWriteParams(LF_WRITE_PARAMS *params);
LF_API LF_ERROR LF_writeFontToFile(LF_FONT* lfFont, const char* filePath, LF_FONT_TYPE type, LF_WRITE_PARAMS *params);
LF_API LF_ERROR LF_getMaxFontSize(LF_FONT* lfFont, LF_FONT_TYPE type, LF_WRITE_PARAMS *params, size_t* size);
LF_API LF_ERROR LF_getNumberGlyphs(LF_FONT* lfFont, USHORT* numGlyphs);
LF_API LF_ERROR LF_writeFontToMemory(LF_FONT* lfFont, LF_FONT_TYPE type, LF_WRITE_PARAMS *params, BYTE* buf, size_t* size);
LF_API LF_ERROR LF_freeFont(LF_FONT* lfFont);
LF_API LF_ERROR LF_destroyFont(LF_FONT* lfFont);
LF_API LF_ERROR LF_obfuscateFont(LF_FONT* lfFont);
LF_API LF_ERROR LF_getNameString(LF_FONT* lfFont, USHORT nameID, BYTE** name, USHORT* length);
LF_API LF_ERROR LF_setNameString(LF_FONT* lfFont, USHORT nameID, const BYTE *buffer, USHORT length);
LF_API LF_ERROR LF_getMacNameString(LF_FONT* lfFont, USHORT nameID, BYTE** name, USHORT* length);
LF_API LF_ERROR LF_setMacNameString(LF_FONT* lfFont, USHORT nameID, const BYTE *buffer, USHORT length);
LF_API LF_ERROR LF_getGlyphID(LF_FONT* lfFont, ULONG unicode, GlyphID* glyphID);
LF_API LF_ERROR LF_getVendorID(LF_FONT* lfFont, CHAR vendorId[4]);
LF_API LF_ERROR LF_getEmbedding(LF_FONT* lfFont, USHORT* embedding);
LF_API LF_ERROR LF_setEmbedding(LF_FONT* lfFont, USHORT embedding);
LF_API LF_ERROR LF_getFontSelection(LF_FONT* lfFont, USHORT* selection);
LF_API LF_ERROR LF_setFontSelection(LF_FONT* lfFont, USHORT selection);
LF_API LF_ERROR LF_getWeightClass(LF_FONT* lfFont, USHORT* usWeightClass);
LF_API LF_ERROR LF_setWeightClass(LF_FONT* lfFont, USHORT usWeightClass);
LF_API LF_ERROR LF_getMacStyle(LF_FONT* lfFont, USHORT* macStyle);
LF_API LF_ERROR LF_setMacStyle(LF_FONT* lfFont, USHORT macStyle);
LF_API LF_ERROR LF_writeCSSFile(LF_FONT* lfFont, const char* baseName, LF_FONT_TYPE fontTypes[6], const char*svgID, const char* filePath);
LF_API LF_ERROR LF_getGlyph(LF_FONT* lfFont, GlyphID index, LF_GLYPH** glyphData);
LF_API LF_ERROR LF_freeGlyph(LF_GLYPH* glyphData);
LF_API LF_ERROR LF_setGlyph(LF_FONT* lfFont, GlyphID index, LF_GLYPH* glyphData);
LF_API LF_ERROR LF_updateFont(LF_FONT* lfFont);

LF_API LF_ERROR LF_getMaxBase64SizeForFile(const char* filePath, size_t* size);
LF_API size_t   LF_getMaxBase64Size(size_t srcSize);
LF_API LF_ERROR LF_convertFileToBase64(const char* filePath, const char* outputPath);
LF_API LF_ERROR LF_convertToBase64(const BYTE* inputBuf, size_t srcSize, BYTE* outputBuf, size_t* size);



//internal (private) functions
boolean LF_retainTable(ULONG tag, int flags);
#define LF_getTable(_cast, _lffont, _tag) (_cast*)map_at(&_lffont->table_map, (void*)_tag)
boolean LF_isUnpacked(LF_FONT* lfFont);

#ifdef __cplusplus
}
#endif

#endif //__LF_CORE_H__
