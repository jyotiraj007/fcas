// Copyright (C) 2014 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// chain_rule.h

#ifndef __CHAIN_RULE_H__
#define __CHAIN_RULE_H__

#include "data_types.h"
#include "stream.h"
#include "lf_error.h"
#include "lf_vector.h"
#include "coverage_table.h"
#include "context_rule.h"

#ifdef __cplusplus
extern "C" {
#endif


/* ----------------------------------------------------------------------------

---------------------------------------------------------------------------- */
typedef struct __chain_rule__
{
    context_rule    Input;                  // Array of input GlyphIDs (start with second Glyph)
                                            // uses context rule structure and holds the LookupRecord
                                            // as well.

    LF_VECTOR       Backtrack;              // Array of backtracking GlyphID's (to be matched
                                            // before the input sequence

    LF_VECTOR       LookAhead;              // Array of lookahead GlyphID's (to be matched after
                                            // the input sequence
} chain_rule;



LF_ERROR    ChainRule_readRule(chain_rule* cr, LF_STREAM* stream);
size_t      ChainRule_buildRule(chain_rule* cr, LF_STREAM* stream);
size_t      ChainRule_sizeRule(chain_rule* cr);
void        ChainRule_freeRule(chain_rule* cr);
#ifdef LF_OT_DUMP
void        ChainRule_dumpRule(chain_rule* cr);
#endif
LF_ERROR    ChainRule_searchRule(chain_rule* cr, GlyphID glyphid, USHORT* index);
LF_ERROR    ChainRule_remapRule(chain_rule* cr, LF_MAP *remap);
LF_ERROR    ChainRule_collectGlyphs(chain_rule* cr, GlyphList* keepList, TABLE_HANDLE hTable);

#ifdef __cplusplus
}
#endif

#endif //__CHAIN_RULE_H__
