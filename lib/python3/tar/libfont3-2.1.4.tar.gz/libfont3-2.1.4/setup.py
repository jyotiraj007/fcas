# Copyright (C) 2016, 2017 Monotype Imaging Inc. All rights reserved.
# Confidential information of Monotype Imaging Inc.
#
# setup.py -- setup for libfont3 extension
#

"""
Setup for libfont package.
"""

import sys
import os
import re
from distutils.core import setup, Extension
from distutils.cmd import Command


def get_version():
    """ Return LIB_VERSION string as defined in 'lf_version.h' file. """

    try:
        verpath = os.path.join('include', 'lf_version.h')
        with open(verpath, 'r') as f:
            for line in f:
                m = re.match(r'#define\sLIBFONT_VERSION\s"(.*)"', line)
                if m:
                    return m.group(1)
            m = "\n\n    Problem parsing lf_version.h!!\n\n"
            raise Exception(m)
    except FileNotFoundError:
        m = "\n\n    Could not find lf_version.h.\n\n"
        raise Exception(m)



class TestCommand(Command):
    """ Run all *_test.py scripts in 'tests' folder with the same Python
    interpreter used to run setup.py.
    """

    user_options = []

    def initialize_options(self):
        pass

    def finalize_options(self):
        pass

    def run(self):
        import sys
        import subprocess
        import glob
        CURR_DIR = os.path.abspath(os.path.dirname(os.path.realpath(__file__)))
        test_dir = os.path.join(CURR_DIR, 'tests')
        os.chdir(test_dir)

        for test in glob.glob("*_test.py"):
            try:
                subprocess.check_call([sys.executable, test])
            except subprocess.CalledProcessError:
                raise SystemExit(1)

# -----------------------------------------------------------------------------

extensionInc = ['include',
                'include/gpos_lookup',
                'include/gsub_lookup',
                'include/normalization',
                'lib/conversion/port',
                'lib/conversion/source',
                'lib/pointHarmonizer/source',
                'lib/componentFinder/source',
                'lib/libb64/include/b64',
                'lib/libb64/include',
                'lib/mtx',
                'lib/brotli/enc',
                'lib/brotli/dec',
                'lib/zlib',
                'src/resources'
                ]

compileArgs = []
linkArgs = []
localMacros = []


if sys.platform == "darwin":
    localMacros.append(('OS_MACOSX', 1))  # this is for svg_core.h
    compileArgs.append('-Wno-deprecated-writable-strings')
    compileArgs.append('-stdlib=libc++')
    compileArgs.append('-mmacosx-version-min=10.7')
elif sys.platform == "win32":
    extensionInc.append('lib/zlib')
    compileArgs.append('/wd4018')
    compileArgs.append('/D_CRT_SECURE_NO_WARNINGS')
elif sys.platform == 'linux':
    # note both of these are needed since there c and C++ files
    # in libfont, having both causes a lot of warnings.
    # the first is needed for the Brotli library.
    compileArgs.append('-std=gnu++0x')
    compileArgs.append('-std=c11')

extensionSrcs = [
    'libfont3/backend/PythonWrapper.cpp',

    # Brotli
    'lib/brotli/dec/bit_reader.c',
    'lib/brotli/dec/decode.c',
    'lib/brotli/dec/huffman.c',
    'lib/brotli/dec/safe_malloc.c',
    'lib/brotli/dec/state.c',
    'lib/brotli/dec/streams.c',
    'lib/brotli/enc/backward_references.cc',
    'lib/brotli/enc/block_splitter.cc',
    'lib/brotli/enc/brotli_bit_stream.cc',
    'lib/brotli/enc/encode.cc',
    'lib/brotli/enc/encode_parallel.cc',
    'lib/brotli/enc/enc_streams.cc',
    'lib/brotli/enc/entropy_encode.cc',
    'lib/brotli/enc/histogram.cc',
    'lib/brotli/enc/literal_cost.cc',
    'lib/brotli/enc/metablock.cc',
    'lib/brotli/enc/static_dict.cc',

    # Conversion
    'lib/conversion/source/BresenhamLine.cpp',
    'lib/conversion/source/Circle.cpp',
    'lib/conversion/source/CompositCubicBezier.cpp',
    'lib/conversion/source/CompositQuadBezier.cpp',
    'lib/conversion/source/Contour.cpp',
    'lib/conversion/source/ContourPoint.cpp',
    'lib/conversion/source/Conversion.cpp',
    'lib/conversion/source/CubicBezier.cpp',
    'lib/conversion/source/CubicContour.cpp',
    'lib/conversion/source/CubicGlyph.cpp',
    'lib/conversion/source/Line2D.cpp',
    'lib/conversion/source/QuadBezier.cpp',
    'lib/conversion/source/QuadContour.cpp',
    'lib/conversion/source/QuadGlyph.cpp',
    'lib/conversion/source/Vector2.cpp',
    'lib/conversion/source/Vector2f.cpp',
    'lib/conversion/source/Vector2i.cpp',

    # Component Finder
    'lib/componentFinder/source/CF_Component.cpp',
    'lib/componentFinder/source/CF_Contour.cpp',
    'lib/componentFinder/source/CF_ContourGroup.cpp',
    'lib/componentFinder/source/CF_ContourPoint.cpp',
    'lib/componentFinder/source/CF_CubicBezier.cpp',
    'lib/componentFinder/source/CF_CubicContour.cpp',
    'lib/componentFinder/source/CF_CubicGlyph.cpp',
    'lib/componentFinder/source/CF_GlyphCompositor.cpp',
    'lib/componentFinder/source/CF_Line2D.cpp',
    'lib/componentFinder/source/CF_NormalizedContour.cpp',
    'lib/componentFinder/source/CF_QuadBezier.cpp',
    'lib/componentFinder/source/CF_QuadContour.cpp',
    'lib/componentFinder/source/CF_QuadGlyph.cpp',
    'lib/componentFinder/source/CF_Quadrilateral.cpp',
    'lib/componentFinder/source/CF_Triangle.cpp',
    'lib/componentFinder/source/CF_Vector2f.cpp',
    'lib/componentFinder/source/Compositor.cpp',

    # point harmonizer
    'lib/pointHarmonizer/source/Harmonizer.cpp',
    'lib/pointHarmonizer/source/H_BresenhamLine.cpp',
    'lib/pointHarmonizer/source/H_Component.cpp',
    'lib/pointHarmonizer/source/H_CompositQuadBezier.cpp',
    'lib/pointHarmonizer/source/H_Contour.cpp',
    'lib/pointHarmonizer/source/H_ContourPoint.cpp',
    'lib/pointHarmonizer/source/H_CubicBezier.cpp',
    'lib/pointHarmonizer/source/H_CubicContour.cpp',
    'lib/pointHarmonizer/source/H_CubicGlyph.cpp',
    'lib/pointHarmonizer/source/H_GlyphHarmonizer.cpp',
    'lib/pointHarmonizer/source/H_GlyphSubroutinizer.cpp',
    'lib/pointHarmonizer/source/H_Line2D.cpp',
    'lib/pointHarmonizer/source/H_NormalizedContour.cpp',
    'lib/pointHarmonizer/source/H_OffsetContour.cpp',
    'lib/pointHarmonizer/source/H_OutlineSecton.cpp',
    'lib/pointHarmonizer/source/H_QuadBezier.cpp',
    'lib/pointHarmonizer/source/H_QuadContour.cpp',
    'lib/pointHarmonizer/source/H_QuadGlyph.cpp',
    'lib/pointHarmonizer/source/H_Quadrilateral.cpp',
    'lib/pointHarmonizer/source/H_Triangle.cpp',
    'lib/pointHarmonizer/source/H_Vector2f.cpp',
    'lib/pointHarmonizer/source/H_Vector2i.cpp',

    # b64
    'lib/libb64/src/cdecode.c',
    'lib/libb64/src/cencode.c',

    # mtx
    'lib/mtx/agfacomp.c',
    'lib/mtx/agfautil.c',
    'lib/mtx/agfawrap.c',
    'lib/mtx/ahuff.c',
    'lib/mtx/bitio.c',
    'lib/mtx/glyph.c',
    'lib/mtx/lzcomp.c',
    'lib/mtx/mtxmem.c',
    'lib/mtx/ttf_conv.c',

    # zlib
    'lib/zlib/adler32.c',
    'lib/zlib/compress.c',
    'lib/zlib/crc32.c',
    'lib/zlib/deflate.c',
    'lib/zlib/gzclose.c',
    'lib/zlib/gzlib.c',
    'lib/zlib/gzread.c',
    'lib/zlib/gzwrite.c',
    'lib/zlib/infback.c',
    'lib/zlib/inffast.c',
    'lib/zlib/inflate.c',
    'lib/zlib/inftrees.c',
    'lib/zlib/trees.c',
    'lib/zlib/uncompr.c',
    'lib/zlib/zutil.c',

    # libfont
    'src/anchor.c',
    'src/attachment_list.c',
    'src/base_table.c',
    'src/cbdt_table.c',
    'src/cblc_table.c',
    'src/cff_conversion.c',
    'src/cff_core.c',
    'src/cff_dump.c',
    'src/cff_refit.c',
    'src/cff_table.c',
    'src/chain_class_rule.c',
    'src/chain_class_set.c',
    'src/chain_rule.c',
    'src/chain_set.c',
    'src/classdef.c',
    'src/class_rule.c',
    'src/class_set.c',
    'src/cmap_table.c',
    'src/colr_table.c',
    'src/common_table.c',
    'src/context_rule.c',
    'src/context_set.c',
    'src/coverage_table.c',
    'src/cpal_table.c',
    'src/cvt_table.c',
    'src/device_table.c',
    'src/dsig_table.c',
    'src/ebdt_table.c',
    'src/eblc_table.c',
    'src/eot_core.c',
    'src/feature_table.c',
    'src/fmtx_table.c',
    'src/fpgm_table.c',
    'src/fvar_table.c',
    'src/gasp_table.c',
    'src/gdef_table.c',
    'src/glyf_table.c',
    'src/gpos_table.c',
    'src/gsub_table.c',
    'src/gvar_table.c',
    'src/hdmx_table.c',
    'src/head_table.c',
    'src/hhea_table.c',
    'src/hmtx_table.c',
    'src/keep_table.c',
    'src/kern_table.c',
    'src/lf_componentize.c',
    'src/lf_core.c',
    'src/lf_harmonize.c',
    'src/lf_map.c',
    'src/lf_refit.c',
    'src/lf_subset.c',
    'src/lf_valign.c',
    'src/lf_vector.c',
    'src/lf_xml.c',
    'src/lig_caret_list.c',
    'src/link_list.c',
    'src/loca_table.c',
    'src/lookup_table.c',
    'src/ltsh_table.c',
    'src/mark_array.c',
    'src/maxp_table.c',
    'src/name_table.c',
    'src/offset_table_eot.c',
    'src/offset_table_sfnt.c',
    'src/offset_table_woff.c',
    'src/offset_table_woff2.c',
    'src/os2_table.c',
    'src/post_table.c',
    'src/prep_table.c',
    'src/sbix_table.c',
    'src/script_list.c',
    'src/sfnt_core.c',
    'src/stream.c',
    'src/svg_core.c',
    'src/unknown_table.c',
    'src/utils.c',
    'src/value_record.c',
    'src/vdmx_table.c',
    'src/vhea_table.c',
    'src/vmtx_table.c',
    'src/woff2_core.c',
    'src/woff_core.c',
    'src/gpos_lookup/gpos_chained_context_positioning.c',
    'src/gpos_lookup/gpos_context_positioning.c',
    'src/gpos_lookup/gpos_cursive_attachment.c',
    'src/gpos_lookup/gpos_extension_positioning.c',
    'src/gpos_lookup/gpos_marktobase.c',
    'src/gpos_lookup/gpos_marktoligature.c',
    'src/gpos_lookup/gpos_marktomark.c',
    'src/gpos_lookup/gpos_pair_adjustment.c',
    'src/gpos_lookup/gpos_single_adjustment.c',
    'src/gsub_lookup/gsub_alternate.c',
    'src/gsub_lookup/gsub_chaining_context.c',
    'src/gsub_lookup/gsub_context.c',
    'src/gsub_lookup/gsub_ligature.c',
    'src/gsub_lookup/gsub_multiple.c',
    'src/gsub_lookup/gsub_reverse_chaining_single.c',
    'src/gsub_lookup/gsub_single.c',
    'src/normalization/norm_cmb.c',
    'src/normalization/norm_nfc.c',
    'src/normalization/norm_nfcdat.c',
    'src/normalization/norm_nfd.c',
    'src/normalization/norm_nfddat.c',
    'src/normalization/norm_uniprp.c',
    'src/resources/buildlang.c']


libfontbackend = Extension('libfont3backend',
                           include_dirs=extensionInc,
                           sources=extensionSrcs,
                           define_macros=localMacros,
                           extra_compile_args=compileArgs,
                           extra_link_args=linkArgs)

setup(name='libfont3',
      version=get_version(),
      description='Python interface for LibFont',
      packages=['libfont3'],
      ext_modules=[libfontbackend],
      cmdclass={'test': TestCommand})
