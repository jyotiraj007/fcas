// Copyright (C) 2014 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// chain_class_rule.c

#include "utils.h"
#include "chain_class_rule.h"

static LF_ERROR chainClassRule_readRule(class_def* cd, LF_VECTOR* sequence, USHORT count, LF_STREAM* stream)
{
    if (count)
    {
        USHORT n;

        vector_init(sequence, count, sizeof(USHORT));
        for (n = 0; n < count; n++)
        {
            USHORT       classValue = STREAM_readUShort(stream);          // read in class value from the sequence.
#if _DEBUG
            LF_ERROR     status;

            status = ClassDef_isClassReferenced(cd, classValue);          // is the sequence referenced in the class definition
            if (status != LF_ERROR_OK)
            {
                DEBUG_LOG_WARNING("class value in sequence isn't referenced in the class definition structure");
//              classValue = 0;                                           // no ... so clear the class
            }
#else
            UNUSED(cd);
#endif
            vector_push_back(sequence, (void*)(intptr_t)classValue);
        }
    }
    return LF_ERROR_OK;
}


LF_ERROR ChainClassRule_readRule(class_def* input, class_def* backtrack, class_def* lookahead,
                                 chain_class_rule* ccr, LF_STREAM* stream)
{
    USHORT          count;
    LF_ERROR        error;

    count = STREAM_readUShort(stream);                    // Backtrack Count
    error = chainClassRule_readRule(backtrack, &ccr->Backtrack, count, stream);
    if(error != LF_ERROR_OK)
        return error;

    count = STREAM_readUShort(stream);                    // Input Count
    ccr->Input.GlyphCount = count;
    error = chainClassRule_readRule(input, &ccr->Input.Class, count - 1, stream);
    if(error != LF_ERROR_OK)
        return error;

    ccr->Input.InputClass = ccr->InputClass;

    count = STREAM_readUShort(stream);                    // Lookahead Count
    error = chainClassRule_readRule(lookahead, &ccr->LookAhead, count, stream);
    if(error != LF_ERROR_OK)
        return error;

    count = STREAM_readUShort(stream);                    // LookupRecord Count
    ccr->Input.LookupCount = count;
    error = Common_readSubstLookupRecords(&ccr->Input.LookupRecords, count, stream);

    return error;
}


void ChainClassRule_freeRule(chain_class_rule* ccr)
{
    vector_delete(&ccr->Backtrack);
    vector_delete(&ccr->LookAhead);
    vector_delete(&ccr->Input.Class);
    Common_freeSubstLookupRecords(&ccr->Input.LookupRecords);
}


size_t ChainClassRule_sizeRule(chain_class_rule* ccr)
{
    size_t    size = 0;

    size += sizeof(USHORT);                                             // BacktrackGlyphCount
    size += ccr->Backtrack.count * sizeof(USHORT);                      // Backtrack[BacktrackGlyphCount]

    size += sizeof(USHORT);                                             // InputGlyphCount
    size += ccr->Input.Class.count * sizeof(USHORT);                    // Input[InputGlyphCount]

    size += sizeof(USHORT);                                             // LookaheadGlyphCount
    size += ccr->LookAhead.count * sizeof(USHORT);                      // LookAhead[LookaheadGlyphCount]

    size += sizeof(USHORT);                                             // RecordCount
    size += Common_sizeSubstLookupRecords(&ccr->Input.LookupRecords);   // LookupRecord[RecordCount]

    return size;
}


size_t ChainClassRule_buildRule(chain_class_rule* ccr, LF_STREAM* stream)
{
    Common_buildClassCountArray(&ccr->Backtrack, stream, 0);
    Common_buildClassCountArray(&ccr->Input.Class, stream, 1);
    Common_buildClassCountArray(&ccr->LookAhead, stream, 0);

    STREAM_writeUShort(stream, UTILS_getCount(&ccr->Input.LookupRecords));
    Common_buildSubstLookupRecords(&ccr->Input.LookupRecords, stream);

    return STREAM_streamPos(stream);
}



/* ============================================================================
    @summary
        validates class sequences against an associated class structure
        and returns EMPTY if the a class is no longer valid in the 
        context of the sequence.

        since this is a chain class rule, we need to compare against 
        all of the sequences for lookahead, backtrack, and input.


    @param
        ccr        :    pointer to the chain class rule structure
        context    :    pointer to the context structures associated with
                        with the rule.  it would contain the class definition
                        structures, and coverages.

    @return
        LF_ERROR_OK     :    the sequence is valid.
        LF_EMPTY_TABLE  :    the sequence isn't valid and can be removed.

============================================================================ */
LF_ERROR ChainClassRule_pruneLookupRecords(chain_class_rule* ccr, context_classes* context)
{
    if (ClassRule_validateClassSequence(&ccr->Input.Class, context->Input, ccr->InputClass) != LF_ERROR_OK)
        return LF_EMPTY_TABLE;

    if (ClassRule_validateClassSequence(&ccr->Backtrack, context->Backtrack, 0) != LF_ERROR_OK)
        return LF_EMPTY_TABLE;

    if (ClassRule_validateClassSequence(&ccr->LookAhead, context->LookAhead, 0) != LF_ERROR_OK)
        return LF_EMPTY_TABLE;

    return LF_ERROR_OK;
}


LF_ERROR ChainClassRule_validClassRules(chain_class_rule* ccr)
{
    if (ccr->Input.LookupRecords.count == 0)
        return LF_EMPTY_TABLE;

    return LF_ERROR_OK;
}

#ifdef LF_OT_DUMP
static void chainClassRule_dumpClassSequence(LF_VECTOR* sequence)
{
    USHORT    n, count = UTILS_getCount(sequence);

    for (n = 0; n < count; n++)
    {
//        char msg[2048];
        USHORT classid = (USHORT)(long)vector_at(sequence, n);

//        sprintf(msg, "ClassContext[%d] = %d", n, classid);
//        DEBUG_LOG(msg);

        XML_DATA_NODE("context", classid);
    }
}

void ChainClassRule_dumpRule(chain_class_rule* ccr)
{
    XML_START("Backtrack");
    chainClassRule_dumpClassSequence(&ccr->Backtrack);
    XML_END("Backtrack");

    XML_START("Input");
    ClassRule_dumpRule(&ccr->Input);
    XML_END("Input");

    XML_START("LookAhead");
    chainClassRule_dumpClassSequence(&ccr->LookAhead);
    XML_END("LookAhead");
}
#endif

/* ============================================================================
    @summary
        given a chain class rule structure
    @param
        context     :   pointer to the context_classes structure, which
                        holds the validClasses vector collection.

============================================================================ */
LF_ERROR ChainClassRule_findValidClasses(chain_class_rule* ccr, context_classes* context)
{
    USHORT            n, count;
    context_define*   def;

    // first do the starting class id for input sequence.
    def = (context_define*)vector_at(context->validClasses, ccr->InputClass);
    def->Input = 1;

    count = UTILS_getCount(&ccr->Input.Class);
    for ( n = 0; n < count; n++)
    {
        USHORT classid = (USHORT)(intptr_t)vector_at(&ccr->Input.Class, n);

        def = (context_define*)vector_at(context->validClasses, classid);
        def->Input = 1;
    }

    count = UTILS_getCount(&ccr->Backtrack);
    for ( n = 0; n < count; n++)
    {
        USHORT classid = (USHORT)(intptr_t)vector_at(&ccr->Backtrack, n);

        def = (context_define*)vector_at(context->validClasses, classid);
        def->Backtrack = 1;
    }


    count = UTILS_getCount(&ccr->LookAhead);
    for ( n = 0; n < count; n++)
    {
        USHORT classid = (USHORT)(intptr_t)vector_at(&ccr->LookAhead, n);

        def = (context_define*)vector_at(context->validClasses, classid);
        def->LookAhead = 1;
    }

    return LF_ERROR_OK;
}

/* ============================================================================
    @summary
        collect any relevant glyphs that may be present in the chained
        set.


    @param
        context        :    pointer to the context_classes structure, which
                            holds the validClasses vector collection.

============================================================================ */
LF_ERROR ChainClassRule_collectGlyphs(chain_class_rule* ccr, context_classes* context, GlyphList* keepList, TABLE_HANDLE hTable)
{
    LF_ERROR error = ClassDef_classesExists(context->Input, keepList, ccr->InputClass, &ccr->Input.Class);
    if (error == LF_NOT_COVERED)
        return error;

    if (ClassDef_getCount(context->Backtrack) != 0)
    {
        error = ClassDef_classesExists(context->Backtrack, keepList, IGNORE_STARTCLASS, &ccr->Backtrack);
        if (error == LF_NOT_COVERED)
            return error;
    }

    if (ClassDef_getCount(context->LookAhead) != 0)
    {
        error = ClassDef_classesExists(context->LookAhead, keepList, IGNORE_STARTCLASS, &ccr->LookAhead);
        if (error == LF_NOT_COVERED)
            return error;
    }

    if (error == LF_ERROR_OK)
    {
        error = Common_collectLookupRecordGlyphs(&ccr->Input.LookupRecords, keepList, hTable);
    }

    return error;
}
