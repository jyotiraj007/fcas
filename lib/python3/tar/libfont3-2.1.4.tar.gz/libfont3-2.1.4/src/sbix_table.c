// Copyright (C) 2016 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// sbix_table.c

#include "sbix_table.h"
#include "table_tags.h"
#include "maxp_table.h"
#include "utils.h"

static void SBIX_freeStrike(sbix_strike* strike);
static void SBIX_freeStrikes(sbix_table* table);

LF_ERROR SBIX_readTable(LF_FONT* lfFont, const sfnt_table_record* record, LF_STREAM* stream)
{
    if (STREAM_streamSeek(stream, record->offset) == 0)
    {
        sbix_table* table = (sbix_table*)calloc(1, sizeof(sbix_table));

        if (table == NULL)
            return LF_OUT_OF_MEMORY;

        table->version = STREAM_readUShort(stream);

        if (table->version != 1)
        {
            free(table);
            return LF_UNSUPPORTED;
        }

        table->flags = STREAM_readUShort(stream);
        table->numStrikes = STREAM_readULong(stream);

        if (table->numStrikes == 0)
        {
            free(table);
            return LF_UNSUPPORTED;
        }

        // Read strike offsets to temp array
        LF_VECTOR strikeOffsets;

        LF_ERROR error = vector_init(&strikeOffsets, table->numStrikes, 4);

        if (error != LF_ERROR_OK)
        {
            free(table);
            return error;
        }

        for (ULONG i = 0; i < table->numStrikes; i++)
        {
            ULONG strikeOffset = STREAM_readULong(stream);

            vector_push_back(&strikeOffsets, (void*)(intptr_t)strikeOffset);
        }

        // Read the strikes

        USHORT numGlyphs = MAXP_getNumGlyphs(lfFont);

        error = vector_init(&table->strikes, table->numStrikes, 4);
        if (error != LF_ERROR_OK)
        {
            free(table);
            return error;
        }

        for (ULONG i = 0; i < table->numStrikes; i++)
        {
            ULONG startOfStrike = record->offset + (ULONG)(intptr_t)vector_at(&strikeOffsets, i);

            if (STREAM_streamSeek(stream, startOfStrike) != 0)
            {
                SBIX_freeStrikes(table);
                vector_free(&strikeOffsets);
                vector_free(&table->strikes);
                free(table);
                return LF_INVALID_OFFSET;
            }

            sbix_strike* strike = (sbix_strike*)calloc(1, sizeof(sbix_strike));

            if (strike == NULL)
            {
                SBIX_freeStrikes(table);
                vector_free(&strikeOffsets);
                vector_free(&table->strikes);
                free(table);
                return LF_OUT_OF_MEMORY;
            }

            strike->ppem = STREAM_readUShort(stream);
            strike->resolution = STREAM_readUShort(stream);

            map_init(&strike->glyphs, integer_compare);

            // Read glyph offsets into a temp array
            LF_VECTOR glyphOffsets;

            error = vector_init(&glyphOffsets, numGlyphs + 1, 4);

            if (error != LF_ERROR_OK)
            {
                free(strike);
                SBIX_freeStrikes(table);
                vector_free(&strikeOffsets);
                vector_free(&table->strikes);
                free(table);
                return error;
            }

            for (USHORT j = 0; j < numGlyphs+1; j++)
            {
                ULONG glyphOffset = STREAM_readULong(stream);

                vector_push_back(&glyphOffsets, (void*)(intptr_t)glyphOffset);
            }

            // Read in the glyph Data

            for (ULONG k = 0; k < (ULONG)numGlyphs; k++)
            {
                ULONG nextOffset = (ULONG)(intptr_t)vector_at(&glyphOffsets, k + 1);
                ULONG currOffset = (ULONG)(intptr_t)vector_at(&glyphOffsets, k);

                ULONG glyphDataSize = nextOffset - currOffset;

                if (glyphDataSize != 0)
                {
                    if (STREAM_streamSeek(stream, startOfStrike + currOffset) != 0)
                    {
                        SBIX_freeStrike(strike);
                        SBIX_freeStrikes(table);
                        vector_free(&strikeOffsets);
                        vector_free(&table->strikes);
                        free(table);
                        return LF_INVALID_OFFSET;
                    }

                    sbix_glyph* glyph = (sbix_glyph*)calloc(1, sizeof(sbix_glyph));

                    if (glyph == NULL)
                    {
                        SBIX_freeStrike(strike);
                        vector_free(&glyphOffsets);
                        vector_free(&strikeOffsets);
                        SBIX_freeStrikes(table);
                        vector_free(&table->strikes);
                        free(table);
                        return LF_OUT_OF_MEMORY;
                    }

                    glyph->originOffsetX = STREAM_readShort(stream);
                    glyph->originOffsetY = STREAM_readShort(stream);
                    glyph->graphicType = STREAM_readULong(stream);

                    glyph->dataSize = glyphDataSize - (2 * sizeof(SHORT) + sizeof(ULONG));

                    if (glyph->graphicType == 0x64757065 /*dupe*/)
                        strike->hasDupes = TRUE;

                    if (glyph->graphicType == 0x6d61736B /*mask*/)
                    {
                        // Sbix tables with masks are not handled yet.
                        free(glyph);
                        SBIX_freeStrike(strike);
                        vector_free(&glyphOffsets);
                        vector_free(&strikeOffsets);
                        SBIX_freeStrikes(table);
                        vector_free(&table->strikes);
                        free(table);
                        return LF_UNSUPPORTED;
                    }
                    else
                    {
                        glyph->data.raw = STREAM_readChunk(stream, glyph->dataSize);

                        if (glyph->data.raw == NULL)
                        {
                            free(glyph);
                            SBIX_freeStrike(strike);
                            vector_free(&glyphOffsets);
                            vector_free(&strikeOffsets);
                            SBIX_freeStrikes(table);
                            vector_free(&table->strikes);
                            free(table);
                            return LF_OUT_OF_MEMORY;
                        }
                    }

                    // Insert into map
                    map_insert(&strike->glyphs, (void*)(intptr_t)k, (void*)glyph);
                }
            }

            // Strikes with dupes are not handled yet
            if (strike->hasDupes == TRUE)
            {
                SBIX_freeStrike(strike);
                vector_free(&glyphOffsets);
                vector_free(&strikeOffsets);
                SBIX_freeStrikes(table);
                vector_free(&table->strikes);
                free(table);
                return LF_UNSUPPORTED;
            }

            vector_free(&glyphOffsets);

            vector_push_back(&table->strikes, strike);
        }

        vector_free(&strikeOffsets);

        map_insert(&lfFont->table_map, (void*)(intptr_t)record->tag, table);

        return LF_ERROR_OK;
    }

    return LF_INVALID_OFFSET;
}

// note this does not work if the strike has dupes
LF_ERROR SBIX_removeGlyph(LF_FONT* lfFont, ULONG index)
{
    sbix_table* table = (sbix_table*)map_at(&lfFont->table_map, (void*)TAG_SBIX);
    if (table == NULL)
        return LF_EMPTY_TABLE;

    size_t numStrikes = vector_size(&table->strikes);

    for (size_t i = 0; i < numStrikes; i++)
    {
        sbix_strike* strike = (sbix_strike*)vector_at(&table->strikes, i);

        sbix_glyph* glyph = (sbix_glyph*)map_at(&strike->glyphs, (void*)(intptr_t)index);

        if (glyph != NULL)
        {
            if (glyph->graphicType == 0x6d61736B /*mask*/)
            {
                ; // Not supported yet
            }
            else
            {
                free(glyph->data.raw);
            }

            free(glyph);

            map_erase(&strike->glyphs, (void*)(intptr_t)index);
        }
    }

    return LF_ERROR_OK;
}

LF_ERROR SBIX_remapTable(LF_FONT* lfFont, LF_MAP *remap)
{
    if ((lfFont == NULL) || (remap == NULL))
        return LF_INVALID_PARAM;

    sbix_table* table = (sbix_table*)map_at(&lfFont->table_map, (void*)TAG_SBIX);
    if (table == NULL)
        return LF_TABLE_MISSING;

    size_t numStrikes = vector_size(&table->strikes);

    for (size_t i = 0; i < numStrikes; i++)
    {
        sbix_strike* strike = (sbix_strike*)vector_at(&table->strikes, i);

        LF_MAP_ITER* mapIter = map_begin(&strike->glyphs);
        if (mapIter != NULL)
        {
            rb_tree_node* node = map_next(mapIter);

            while (node)
            {
                node->key = map_at(remap, node->key);
                node = map_next(mapIter);
            }
        }
        else
        {
            return LF_OUT_OF_MEMORY;
        }

        map_free_iter(mapIter);
    }

    return LF_ERROR_OK;
}

LF_ERROR SBIX_isTableEmpty(LF_FONT* lfFont)
{
    sbix_table* table = (sbix_table*)map_at(&lfFont->table_map, (void*)TAG_SBIX);
    if (table == NULL)
        return LF_EMPTY_TABLE;

    size_t numStrikes = vector_size(&table->strikes);

    for (size_t i = 0; i < numStrikes; i++)
    {
        sbix_strike* strike = (sbix_strike*)vector_at(&table->strikes, i);

        if (0 != map_size(&strike->glyphs))
            return LF_ERROR_OK;
    }

    return LF_EMPTY_TABLE;
}

LF_ERROR SBIX_getTableSize(LF_FONT* lfFont, size_t* tableSize)
{
    *tableSize = 0;

    sbix_table* table = (sbix_table*)map_at(&lfFont->table_map, (void*)TAG_SBIX);
    if (table == NULL)
        return LF_EMPTY_TABLE;

    *tableSize = 2 * sizeof(USHORT) + sizeof(ULONG); // version, flags, and numStrikes

    size_t numStrikes = vector_size(&table->strikes);

    *tableSize += numStrikes * sizeof(ULONG);

    USHORT numGlyphs = MAXP_getNumGlyphs(lfFont);       // Warning - assuming the maxp has been updated prior to calling this function.

    // Add in the strike records
    *tableSize += ((2 * sizeof(USHORT) /* ppem, and resolution*/ + (numGlyphs + 1) * sizeof(ULONG)) * numStrikes);

    // figure out the size of the strike data
    for (size_t i = 0; i < numStrikes; i++)
    {
        sbix_strike* strike = (sbix_strike*)vector_at(&table->strikes, i);

        size_t numberOfGlyphs = map_size(&strike->glyphs);

        ULONG sizeofStrike;

        // account for the origOffsetX, origOffsetY, and graphicType for all the glyphs.
        sizeofStrike = (ULONG)((2 * sizeof(USHORT) + 1 * sizeof(ULONG)) * numberOfGlyphs);

        LF_MAP_ITER* mapIter = map_begin(&strike->glyphs);
        if (mapIter != NULL)
        {
            rb_tree_node* node = map_next(mapIter);

            while (node)
            {
                sbix_glyph* glyph = (sbix_glyph*)node->data;

                // TODO check for mask graphicType

                sizeofStrike += glyph->dataSize;

                node = map_next(mapIter);
            }
        }
        else
        {
            return LF_OUT_OF_MEMORY;
        }

        map_free_iter(mapIter);

        *tableSize += sizeofStrike;
    }

    return LF_ERROR_OK;
}

static LF_ERROR SBIX_buildTable(LF_FONT* lfFont, BYTE** tableData, size_t* tableSize)
{
    *tableData = NULL;
    *tableSize = 0;

    sbix_table* table = (sbix_table*)map_at(&lfFont->table_map, (void*)TAG_SBIX);
    if (table == NULL)
        return LF_TABLE_MISSING;

    LF_ERROR error = SBIX_getTableSize(lfFont, tableSize);
    if (error != LF_ERROR_OK)
        return error;

    size_t paddedSize = *tableSize;
    *tableData = UTILS_AllocTable(&paddedSize);

    if (*tableData == NULL)
    {
        DEBUG_LOG_ERROR("allocation failure in SBIX_buildTable");
        return LF_OUT_OF_MEMORY;
    }

    LF_STREAM stream;
    STREAM_initMemStream(&stream, *tableData, *tableSize);

    STREAM_writeUShort(&stream, table->version); // Version
    STREAM_writeUShort(&stream, table->flags); // Flags

    ULONG numStrikes = (ULONG)vector_size(&table->strikes);

    STREAM_writeULong(&stream, numStrikes); // Number of Strikes

    size_t offsetToFirstStrikeOffset = STREAM_streamPos(&stream);

    // Write zeros for the strike offsets for now

    for (USHORT i = 0; i < numStrikes; i++)
        STREAM_writeULong(&stream, 0);

    // a local vector to hold the offsets to the strikes
    LF_VECTOR newStrikeOffsets;

    error = vector_init(&newStrikeOffsets, numStrikes, 4);
    if (error != LF_ERROR_OK)
    {
        free(*tableData);
        return error;
    }

    USHORT numGlyphs = MAXP_getNumGlyphs(lfFont);   // Warning - assuming maxp has been updated

    for (size_t i = 0; i < numStrikes; i++)
    {
        size_t offsetToStartOfStrike = STREAM_streamPos(&stream);

        vector_push_back(&newStrikeOffsets, (void*)offsetToStartOfStrike);

        sbix_strike* strike = (sbix_strike*)vector_at(&table->strikes, i);

        STREAM_writeUShort(&stream, strike->ppem); // ppem
        STREAM_writeUShort(&stream, strike->resolution); // resolution

        size_t offsetToGlyphOffset = STREAM_streamPos(&stream);
        size_t offsetToStartOfGlyphData = offsetToGlyphOffset + (numGlyphs + 1)*sizeof(ULONG);

        STREAM_streamSeek(&stream, offsetToStartOfGlyphData);

        for (size_t j = 0; j < (size_t)(numGlyphs + 1); j++)
        {
            size_t currOffset = STREAM_streamPos(&stream);

            STREAM_streamSeek(&stream, offsetToGlyphOffset);
            STREAM_writeULong(&stream, (ULONG)(currOffset - offsetToStartOfStrike));
            STREAM_streamSeek(&stream, currOffset);

            offsetToGlyphOffset += sizeof(ULONG);

            sbix_glyph* glyph = (sbix_glyph*)map_at(&strike->glyphs, (void*)j);

            if (glyph != NULL)
            {
                STREAM_writeShort(&stream, glyph->originOffsetX);
                STREAM_writeShort(&stream, glyph->originOffsetY);
                STREAM_writeULong(&stream, glyph->graphicType);

                if (glyph->graphicType == 0x6d61736B /*mask*/)
                {
                    ; // Not supported yet
                }
                else
                {
                    STREAM_writeChunk(&stream, glyph->data.raw, glyph->dataSize);
                }
            }
        }
    }

    // update the strike offsets
    STREAM_streamSeek(&stream, offsetToFirstStrikeOffset);

    for (USHORT i = 0; i < numStrikes; i++)
        STREAM_writeULong(&stream, (ULONG)(intptr_t)vector_at(&newStrikeOffsets, i));

    vector_free(&newStrikeOffsets);

    return LF_ERROR_OK;
}

LF_ERROR SBIX_writeTable(LF_FONT* lfFont, sfnt_table_record* record, LF_STREAM* stream)
{
    size_t tableSize;
    BYTE* tableData;

    LF_ERROR error = SBIX_buildTable(lfFont, &tableData, &tableSize);
    if (error != LF_ERROR_OK)
        return error;

    record->checkSum = UTILS_CalcTableChecksum(tableData, tableSize);
    record->length = (ULONG)tableSize;
    record->offset = (ULONG)STREAM_streamPos(stream);

    STREAM_writeChunk(stream, tableData, (tableSize + 3) & ~3);
    free(tableData);

    return LF_ERROR_OK;
}

static void SBIX_freeStrike(sbix_strike* strike)
{
    LF_MAP_ITER* mapIter = map_begin(&strike->glyphs);
    if (mapIter != NULL)
    {
        rb_tree_node* node = map_next(mapIter);

        while (node)
        {
            sbix_glyph* glyph = (sbix_glyph*)node->data;

            if (glyph->graphicType == 0x6d61736B /*mask*/)
            {
                ; // not handled yet.
            }
            else
            {
                free(glyph->data.raw);
            }

            free(glyph);

            node = map_next(mapIter);
        }
    }
    else
    {
        DEBUG_LOG_ERROR("Allocation failure in SBIX_freeStrikes - will cause memory leaks");
    }

    map_free_iter(mapIter);

    map_clear(&strike->glyphs);

    free(strike);
}

static void SBIX_freeStrikes(sbix_table* table)
{
    size_t numStrikes = vector_size(&table->strikes);

    for (size_t i = 0; i < numStrikes; i++)
    {
        sbix_strike* strike = (sbix_strike*)vector_at(&table->strikes, i);

        SBIX_freeStrike(strike);
    }
} /*lint !e429  The table itself is freed by whatever calls this function. */

LF_ERROR SBIX_freeTable(LF_FONT* lfFont)
{
    sbix_table* table = (sbix_table*)map_at(&lfFont->table_map, (void*)TAG_SBIX);

    if (table != NULL)
    {
        SBIX_freeStrikes(table);

        vector_free(&table->strikes);
        free(table);
    }

    return LF_ERROR_OK;
}
