// Copyright (C) 2014, 2015 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// gpos_table.c

#include <string.h>
#include <stdlib.h>
#include "utils.h"
#include "gpos_table.h"
#include "lookup_table.h"
#include "feature_table.h"
#include "coverage_table.h"
#include "script_list.h"
#include "gpos_lookup/gpos_single_adjustment.h"
#include "gpos_lookup/gpos_pair_adjustment.h"
#include "gpos_lookup/gpos_cursive_attachment.h"
#include "gpos_lookup/gpos_marktobase.h"
#include "gpos_lookup/gpos_marktoligature.h"
#include "gpos_lookup/gpos_marktomark.h"
#include "data_types.h"
#include <stdint.h>
#include "offset_table_sfnt.h"
#include "lf_vector.h"
#include "lf_error.h"
#include "stream.h"
#include "lf_core.h"
#include "lf_map.h"
#include "gpos_lookup/gpos_context_positioning.h"
#include "gpos_lookup/gpos_chained_context_positioning.h"
#include "table_tags.h"

LF_ERROR GPOS_readTable(LF_FONT* lfFont, const sfnt_table_record* record, LF_STREAM* stream)
{
    if(STREAM_streamSeek(stream, record->offset) == 0)
    {
        gpos_header* header = (gpos_header*)calloc(1, sizeof(gpos_header));

        if (header == NULL)
            return LF_OUT_OF_MEMORY;

        header->isValid = TRUE;

        FIXED version = STREAM_readFixed(stream);
        OFFSET scriptOffset = STREAM_readOffset(stream);
        OFFSET featureOffset = STREAM_readOffset(stream);
        OFFSET lookupOffset = STREAM_readOffset(stream);

        if ((featureOffset == 0) || (lookupOffset == 0))
        {
            header->isValid = FALSE;
        }
        else
        {
            BaseTable_init(header, NULL);
            BaseTable_setType(header, TABLETYPE_GPOS, SUBTABLE_TYPE_NONE);

            header->Version = version;

            STREAM_streamSeek(stream, record->offset + scriptOffset);

            header->ScriptList = Script_readListTable(stream, TRUE);
            if (header->ScriptList == NULL)
            {
                free(header);
                return LF_OUT_OF_MEMORY;
            }

            STREAM_streamSeek(stream, record->offset + featureOffset);

            LF_ERROR error = Feature_readListTable(stream, TRUE, &header->FeatureList);
            if (error != LF_ERROR_OK)
            {
                Script_deleteTable(header->ScriptList);
                free(header);
                return error;
            }

            STREAM_streamSeek(stream, record->offset + lookupOffset);
            header->LookupList = Lookup_readListTable(stream, TRUE);
            if (header->LookupList == NULL)
            {
                Feature_deleteTable(header->FeatureList);
                Script_deleteTable(header->ScriptList);
                free(header);
                return LF_OUT_OF_MEMORY;
            }
        }

        map_insert(&lfFont->table_map, (void*)(intptr_t)record->tag, header);
        return LF_ERROR_OK;
    }

    return LF_INVALID_OFFSET;
}

TABLE_HANDLE GPOS_readSubtable(USHORT lookupType, LF_STREAM* stream)
{
    TABLE_HANDLE    table = NULL;

    switch(lookupType)
    {
        case GPOS_SINGLE_ADJUSTMENT:            table = GPOS_readSingleAdjustment(stream);              break;
        case GPOS_PAIR_ADJUSTMENT:              table = GPOS_readPairAdjustment(stream);                break;
        case GPOS_CURSIVE_ATTACHMENT:           table = GPOS_readCursiveAttachment(stream);             break;
        case GPOS_MARKTOBASE_ATTACHMENT:        table = GPOS_readMarkToBase(stream);                    break;
        case GPOS_MARKTOLIGATURE_ATTACHMENT:    table = GPOS_readMarkToLigature(stream);                break;
        case GPOS_MARKTOMARK_ATTACHMENT:        table = GPOS_readMarkToMark(stream);                    break;
        case GPOS_CONTEXT_POSITIONING:          table = GPOS_readContextPositioning(stream);            break;
        case GPOS_CHAINED_CONTEXT_POSITIONING:  table = GPOS_readChainContextPositioning(stream);       break;
//      case GPOS_EXTENSION_POSITIONING:        table = GPOS_readExtensionPositioning(stream);          break;
        case GPOS_EXTENSION_POSITIONING:                                                                break;
        default:
            DEBUG_LOG_VALUE("[BAD LOOKUP FORMAT] unexpected format found", lookupType);
            break;
    }

    return table;
}

size_t GPOS_getSubtableSize(USHORT lookupType, TABLE_HANDLE hTable)
{
    switch(lookupType)
    {
        case GPOS_SINGLE_ADJUSTMENT:            return GPOS_getSingleAdjustmentSize((gpos_single_adjustment*)hTable);
        case GPOS_PAIR_ADJUSTMENT:              return GPOS_getPairAdjustmentSize((gpos_pair_adjustment*)hTable);
        case GPOS_CURSIVE_ATTACHMENT:           return GPOS_getCursiveAttachmentSize((gpos_cursive_attachment*)hTable);
        case GPOS_MARKTOBASE_ATTACHMENT:        return GPOS_getMarkToBaseSize((gpos_marktobase*)hTable);
        case GPOS_MARKTOLIGATURE_ATTACHMENT:    return GPOS_getMarkToLigatureSize((gpos_marktoligature*)hTable);
        case GPOS_MARKTOMARK_ATTACHMENT:        return GPOS_getMarkToMarkSize((gpos_marktomark*)hTable);
        case GPOS_CONTEXT_POSITIONING:          return GPOS_sizeContextPositioning((gpos_context_positioning*)hTable);
        case GPOS_CHAINED_CONTEXT_POSITIONING:  return GPOS_sizeChainContextPositioning((gpos_chain_context_positioning*)hTable);
        default:    break;
    }

    return 0;
}

size_t GPOS_buildSubTable(USHORT lookupType, TABLE_HANDLE hTable, LF_STREAM* stream)
{
    size_t    tableStart = STREAM_streamPos(stream);

    switch(lookupType)
    {
        case GPOS_SINGLE_ADJUSTMENT:            GPOS_buildSingleAdjustment((gpos_single_adjustment*)hTable, stream);                break;
        case GPOS_PAIR_ADJUSTMENT:              GPOS_buildPairAdjustment((gpos_pair_adjustment*)hTable, stream);                    break;
        case GPOS_CURSIVE_ATTACHMENT:           GPOS_buildCursiveAttachment((gpos_cursive_attachment*)hTable, stream);              break;
        case GPOS_MARKTOBASE_ATTACHMENT:        GPOS_buildMarkToBase((gpos_marktobase*)hTable, stream);                             break;
        case GPOS_MARKTOLIGATURE_ATTACHMENT:    GPOS_buildMarkToLigature((gpos_marktoligature*)hTable, stream);                     break;
        case GPOS_MARKTOMARK_ATTACHMENT:        GPOS_buildMarkToMark((gpos_marktomark*)hTable, stream);                             break;
        case GPOS_CONTEXT_POSITIONING:          GPOS_buildContextPositioning((gpos_context_positioning*)hTable, stream);            break;
        case GPOS_CHAINED_CONTEXT_POSITIONING:  GPOS_buildChainContextPositioning((gpos_chain_context_positioning*)hTable, stream); break;

        default:    break;
    }

    return STREAM_streamPos(stream) - tableStart;
}

static LF_ERROR GPOS_buildTable(TABLE_HANDLE hTable, size_t* tableSize, BYTE** tableData)
{
    gpos_header* table = (gpos_header*)hTable;
    size_t scriptSize = 0, featureSize = 0, lookupSize = 0;

    BYTE* scriptData = Script_buildTable(table->ScriptList, &scriptSize);

    BYTE* featureData = Feature_buildTable(table->FeatureList, TRUE, &featureSize);
    if (featureData == NULL)
        return LF_OUT_OF_MEMORY;

    BYTE* lookupData = NULL;

    LF_ERROR error = Lookup_buildTable(table->LookupList, TRUE, &lookupSize, &lookupData);
    if (error == LF_ERROR_OK)
    {
        USHORT headerSize = sizeof(FIXED) + sizeof(OFFSET) * 3;
        *tableSize = headerSize + scriptSize + featureSize + lookupSize;

        size_t paddedSize = *tableSize;
        *tableData = UTILS_AllocTable(&paddedSize);
        if (*tableData == NULL)
        {
            error = LF_OUT_OF_MEMORY;
        }
        else
        {
            LF_STREAM stream;
            STREAM_initMemStream(&stream, *tableData, *tableSize);
            STREAM_writeFixed(&stream, table->Version);
            STREAM_writeOffset(&stream, headerSize);
            STREAM_writeOffset(&stream, (USHORT)(headerSize + scriptSize));
            STREAM_writeOffset(&stream, (USHORT)(headerSize + scriptSize + featureSize));

            STREAM_writeChunk(&stream, scriptData, scriptSize);
            STREAM_writeChunk(&stream, featureData, featureSize);
            STREAM_writeChunk(&stream, lookupData, lookupSize);
        }
    }

    free(scriptData);
    free(featureData);
    free(lookupData);

    return error;
}

LF_ERROR GPOS_getTableSize(LF_FONT* lfFont, size_t* tableSize)
{
    USHORT headerSize;
    size_t scriptSize, featureSize, lookupSize;
    gpos_header* header;

    *tableSize = 0;

    header = (gpos_header*)map_at(&lfFont->table_map, (void*)TAG_GPOS);

    if(header == NULL)
        return LF_EMPTY_TABLE;

    if (header->calculatedTableSize != 0)
    {
        *tableSize = header->calculatedTableSize;
        return LF_ERROR_OK;
    }

    headerSize = sizeof(FIXED) + sizeof(OFFSET) * 3;

    scriptSize = Script_getDataSize(header->ScriptList);
    featureSize = Feature_getDataSize(header->FeatureList);
    lookupSize = Lookup_getDataSize(header->LookupList, TRUE);

    *tableSize = headerSize + scriptSize + featureSize + lookupSize;

    header->calculatedTableSize = *tableSize;

    return LF_ERROR_OK;
}

LF_ERROR GPOS_writeTable(LF_FONT* lfFont, sfnt_table_record* record, LF_STREAM* stream)
{
    size_t table_size = 0;
    //ULONG padLen = 0;
    gpos_header* header = (gpos_header*)map_at(&lfFont->table_map, (void*)(intptr_t)record->tag);
    LF_ERROR error = LF_ERROR_OK;

    if (header)
    {
        BYTE* tableData;

        error = GPOS_buildTable(header, &table_size, &tableData);

        if (error == LF_ERROR_OK)
        {
            //UTILS_PadTable(&tableData, table_size, &padLen);

            record->checkSum = UTILS_CalcTableChecksum(tableData, table_size);
            record->length = (ULONG)table_size;
            record->offset = (ULONG)STREAM_streamPos(stream);

            STREAM_writeChunk(stream, tableData, (table_size + 3) & ~3);
            free(tableData);
        }
    }

    return error;
}

LF_ERROR GPOS_subtableRemoveGlyph(USHORT lookupType, TABLE_HANDLE hTable, ULONG index)
{
    switch(lookupType)
    {
        case GPOS_SINGLE_ADJUSTMENT:
            return GPOS_singleAdjustRemoveGlyph((gpos_single_adjustment*)hTable, (GlyphID)index);

        case GPOS_PAIR_ADJUSTMENT:
            return GPOS_pairAdjustRemoveGlyph((gpos_pair_adjustment*)hTable, (GlyphID)index);

        case GPOS_CURSIVE_ATTACHMENT:
            return GPOS_cursiveAttachRemoveGlyph((gpos_cursive_attachment*)hTable, (GlyphID)index);

        case GPOS_MARKTOBASE_ATTACHMENT:
            return GPOS_markToBaseRemoveGlyph((gpos_marktobase*)hTable, (GlyphID)index);

        case GPOS_MARKTOLIGATURE_ATTACHMENT:
            return GPOS_markToLigatureRemoveGlyph((gpos_marktoligature*)hTable, (GlyphID)index);

        case GPOS_MARKTOMARK_ATTACHMENT:
            return GPOS_markToMarkRemoveGlyph((gpos_marktomark*)hTable, (GlyphID)index);

        case GPOS_CONTEXT_POSITIONING:
            return GPOS_removeContextPositioningGlyphIndex((gpos_context_positioning*)hTable, (GlyphID)index);

        case GPOS_CHAINED_CONTEXT_POSITIONING:
            return GPOS_removeChainContextPositioning((gpos_chain_context_positioning*)hTable, (GlyphID)index);

        default:    break;
    }

    return LF_BAD_FORMAT;
}

LF_ERROR GPOS_removeGlyph(LF_FONT* lfFont, ULONG index)
{
    LF_ERROR error = LF_ERROR_OK;
    gpos_header* header = (gpos_header*)map_at(&lfFont->table_map, (void*)TAG_GPOS);

    if(header != NULL)
    {
        header->calculatedTableSize = 0;

        error = Lookup_removeGlyph(header->LookupList, header, index, TRUE);
    }

    return error;
}

LF_ERROR GPOS_subtableRemapGlyph(USHORT lookupType, TABLE_HANDLE hTable, LF_MAP *remap)
{
    LF_ERROR error = LF_NOT_COVERED;

    switch (lookupType)
    {
    case GPOS_SINGLE_ADJUSTMENT:            error = GPOS_singleAdjustRemapTable((gpos_single_adjustment*)hTable, remap);                    break;
    case GPOS_PAIR_ADJUSTMENT:              error = GPOS_pairAdjustRemapTable((gpos_pair_adjustment*)hTable, remap);                        break;
    case GPOS_CURSIVE_ATTACHMENT:           error = GPOS_cursiveAttachRemapTable((gpos_cursive_attachment*)hTable, remap);                  break;
    case GPOS_MARKTOBASE_ATTACHMENT:        error = GPOS_markToBaseRemapTable((gpos_marktobase*)hTable, remap);                             break;
    case GPOS_MARKTOLIGATURE_ATTACHMENT:    error = GPOS_markToLigatureRemapTable((gpos_marktoligature*)hTable, remap);                     break;
    case GPOS_MARKTOMARK_ATTACHMENT:        error = GPOS_markToMarkRemapTable((gpos_marktomark*)hTable, remap);                             break;
    case GPOS_CONTEXT_POSITIONING:          error = GPOS_contextPositioningRemapTable((gpos_context_positioning*)hTable, remap);            break;
    case GPOS_CHAINED_CONTEXT_POSITIONING:  error = GPOS_ChainContextPositioningRemapTable((gpos_chain_context_positioning*)hTable, remap); break;
    default:                                                                                                                                break;
    }

    return error;
}

LF_ERROR GPOS_remapTable(LF_FONT* lfFont, LF_MAP *remap)
{
    LF_ERROR error = LF_ERROR_OK;
    gpos_header* header = (gpos_header*)map_at(&lfFont->table_map, (void*)TAG_GPOS);

    if((header != NULL) && (header->LookupList != NULL))
    {
        error = Lookup_remapTables(header->LookupList, remap, TRUE);
    }

    return error;
}

/* ============================================================================
    @summary
        free up the subtable resources from the system.

    @param
        lookupType  = lookup type for casting table pointer.
        hTable      = pointer to the gpos table

============================================================================ */
void GPOS_freeSubtable(USHORT lookupType, TABLE_HANDLE hTable)
{
    switch(lookupType)
    {
        case GPOS_SINGLE_ADJUSTMENT:            GPOS_freeSingleAdjust((gpos_single_adjustment*)hTable);                      break;
        case GPOS_PAIR_ADJUSTMENT:              GPOS_freePairAdjust((gpos_pair_adjustment*)hTable);                          break;
        case GPOS_CURSIVE_ATTACHMENT:           GPOS_freeCursiveAttach((gpos_cursive_attachment*)hTable);                    break;
        case GPOS_MARKTOBASE_ATTACHMENT:        GPOS_freeMarkToBase((gpos_marktobase*)hTable);                               break;
        case GPOS_MARKTOLIGATURE_ATTACHMENT:    GPOS_freeMarkToLigature((gpos_marktoligature*)hTable);                       break;
        case GPOS_MARKTOMARK_ATTACHMENT:        GPOS_freeMarkToMark((gpos_marktomark*)hTable);                               break;
        case GPOS_CONTEXT_POSITIONING:          GPOS_freeContextPositioning((gpos_context_positioning*)hTable);              break;
        case GPOS_CHAINED_CONTEXT_POSITIONING:  GPOS_freeChainContextPositioning((gpos_chain_context_positioning*)hTable);   break;
        case GPOS_EXTENSION_POSITIONING:        DEBUG_LOG_WARNING("GPOS_EXTENSION_POSITIONING detected while freeing");      break;
        default:                                DEBUG_LOG_WARNING("Unknown format detected while freeing memory");           break;
    }
}

LF_ERROR GPOS_freeTable(LF_FONT* lfFont)
{
    gpos_header* table = (gpos_header*)map_at(&lfFont->table_map, (void*)TAG_GPOS);
    if (table)
    {
        Feature_deleteTable(table->FeatureList);
        Script_deleteTable(table->ScriptList);
        Lookup_freeTableList(table->LookupList, TRUE);

        free(table);
    }
    return LF_ERROR_OK;
}

LF_ERROR GPOS_removeLookupIndexSubtable(USHORT lookupType, TABLE_HANDLE hTable, USHORT refIndex, SHORT deltaIndex)
{
    LF_ERROR error = LF_ERROR_OK;

    switch(lookupType)
    {
        case GPOS_CONTEXT_POSITIONING:
            error = GPOS_removeContextPositioningLookupIndex((gpos_context_positioning*)hTable, refIndex, deltaIndex);
            break;

        case GPOS_CHAINED_CONTEXT_POSITIONING:
            error = GPOS_removeChainContextPositioningLookupIndex((gpos_chain_context_positioning*)hTable, refIndex, deltaIndex);
            break;

        case GPOS_SINGLE_ADJUSTMENT:
        case GPOS_PAIR_ADJUSTMENT:
        case GPOS_CURSIVE_ATTACHMENT:
        case GPOS_MARKTOBASE_ATTACHMENT:
        case GPOS_MARKTOLIGATURE_ATTACHMENT:
        case GPOS_MARKTOMARK_ATTACHMENT:
        default:
            break;

    }
    return error;
}

/* ============================================================================
    @summary
        lookup records contain references to context and classes.  This
        function will go through those relevent rules and remove any
        of the lookup records that reference a empty class and remove
        them.

        primarily this is being done to help with the validator from
        detecting errors in the font files referencing an empty class

    @param
        lookupType = lookup type for casting table pointer.
        table = pointer to the gsub rule

============================================================================ */
LF_ERROR GPOS_pruneLookupRecords(USHORT lookupType, TABLE_HANDLE table)
{
    LF_ERROR error = LF_NOT_COVERED;

    switch (lookupType)
    {
    case GPOS_CONTEXT_POSITIONING:
        error = GPOS_pruneContextPositioningLookupRecords((gpos_context_positioning*)table);
        break;

    case GPOS_CHAINED_CONTEXT_POSITIONING:
        error = GPOS_pruneChainContextPosLookupRecords((gpos_chain_context_positioning*)table);
        break;

    case GPOS_PAIR_ADJUSTMENT:
        error = GPOS_prunePairAdjustmentLookupRecords((gpos_pair_adjustment*)table);
        break;

    case GPOS_SINGLE_ADJUSTMENT:
    case GPOS_CURSIVE_ATTACHMENT:
    case GPOS_MARKTOBASE_ATTACHMENT:
    case GPOS_MARKTOLIGATURE_ATTACHMENT:
    case GPOS_MARKTOMARK_ATTACHMENT:
    default:
        break;
    }

    return error;
}

/* ============================================================================
    @summary
        prune lookups goes through and cleans up any classes that have
        been emptied, but need to be cleaned up.  since there is no
        particular order to how the glyphs are removed we cannot guarantee
        that all empty classes, coverages and lookup records have been
        properly pruned.

        This pass will do this and should only be called after all
        subsetting has been completed.

    @param
        lfFont      :    pointer to the LF_FONT structure.

    @return
        LF_ERROR    :    pruning completed

============================================================================ */
LF_ERROR GPOS_pruneLookups(LF_FONT* lfFont)
{
    LF_ERROR error = LF_ERROR_OK;
    gpos_header* table = (gpos_header*)map_at(&lfFont->table_map, (void*)TAG_GPOS);

    if (table)
    {
        table->calculatedTableSize = 0;
        error = Lookup_pruneLookups(table->LookupList, table, TRUE);
    }
    return error;
}

#ifdef LF_OT_DUMP
LF_ERROR GPOS_dumpSubtable(USHORT lookupType, TABLE_HANDLE table)
{
    LF_ERROR error = LF_NOT_COVERED;

    switch (lookupType)
    {
    case GPOS_CONTEXT_POSITIONING:              break;
    case GPOS_CHAINED_CONTEXT_POSITIONING:      break;
    case GPOS_SINGLE_ADJUSTMENT:                GPOS_dumpSingleAdjust((gpos_single_adjustment*)table);       break;
    case GPOS_PAIR_ADJUSTMENT:                  GPOS_dumpPairAdjustment((gpos_pair_adjustment*)table);       break;
    case GPOS_CURSIVE_ATTACHMENT:               GPOS_dumpCursiveAttach((gpos_cursive_attachment*)table);     break;
    case GPOS_MARKTOBASE_ATTACHMENT:            GPOS_dumpMarkToBase((gpos_marktobase*)table);                break;
    case GPOS_MARKTOLIGATURE_ATTACHMENT:        GPOS_dumpMarkToLigature((gpos_marktoligature*)table);        break;
    case GPOS_MARKTOMARK_ATTACHMENT:            GPOS_dumpMarkToMark((gpos_marktomark*)table);                break;
    default:
        break;
    }
    return error;
}

LF_ERROR GPOS_dumpTable(LF_FONT* lfFont)
{
    LF_ERROR error = LF_ERROR_OK;
    gpos_header* header = (gpos_header*)map_at(&lfFont->table_map, (void*)TAG_GPOS);

    if((header != NULL) && (header->LookupList != NULL))
    {
        error = Lookup_dumpTables(header->LookupList, TRUE);
    }
    return error;
}
#endif

LF_ERROR GPOS_removeAllTables(LF_FONT* lfFont)
{
    gpos_header* table = (gpos_header*)map_at(&lfFont->table_map, (void*)TAG_GPOS);
    if (table)
    {
        table->calculatedTableSize = 0;
        Lookup_freeTableList(table->LookupList, TRUE);
        table->LookupList = NULL;
    }

    return LF_ERROR_OK;
}

boolean GPOS_isValid(LF_FONT* lfFont)
{
    gpos_header* table = (gpos_header*)map_at(&lfFont->table_map, (void*)TAG_GPOS);
    if (table == NULL)
        return FALSE;

    // NOTE: the only validation done so far is to check that the feature offset and lookup offset are not 0.

    return table->isValid;
}

LF_ERROR GPOS_isTableEmpty(LF_FONT* lfFont)
{
    gpos_header* table = (gpos_header*)map_at(&lfFont->table_map, (void*)TAG_GPOS);
    if (table)
    {
        LF_VECTOR* hLookup = (LF_VECTOR*)table->LookupList;

        return (hLookup && hLookup->count) ? LF_ERROR_OK : LF_EMPTY_TABLE;
    }

    return LF_EMPTY_TABLE;
}

/* ----------------------------------------------------------------------------
    @summary
        this method goes through the feature table and removes any of
        the hanging lookups that may be left over from pruning and
        subsetting.

    @param
        lfFont        :    pointer to the main font structure.

---------------------------------------------------------------------------- */
LF_ERROR GPOS_cleanupLookups(LF_FONT* lfFont)
{
    gpos_header* table = (gpos_header*)map_at(&lfFont->table_map, (void*)TAG_GPOS);
    if (table)
    {
        table->calculatedTableSize = 0;

        TABLE_HANDLE hLookup = (TABLE_HANDLE)table->LookupList;
        TABLE_HANDLE hFeature = (TABLE_HANDLE)table->FeatureList;

        Feature_cleanupLookups(hFeature, hLookup, TRUE);
    }
    return LF_ERROR_OK;
}

LF_ERROR GPOS_cleanupLookupSubtables(USHORT lookupType, TABLE_HANDLE subtable, TABLE_HANDLE hLookup)
{
    LF_ERROR error = LF_NOT_COVERED;
    base_table* base = (base_table*)subtable;

    // flag the reference count, that we need this subtable
    base->refCount = 1;

    switch (lookupType)
    {
    case GPOS_CONTEXT_POSITIONING:
        error = GPOS_cleanupContextLookups((gpos_context_positioning*)subtable, hLookup);
        break;
    case GPOS_CHAINED_CONTEXT_POSITIONING:
        error = GPOS_cleanupChainContextLookups((gpos_chain_context_positioning*)subtable, hLookup);
        break;
    default:
        break;
    }

    return error;
}

LF_ERROR GPOS_removeUnReferencedLookups(LF_FONT* lfFont)
{
    gpos_header* table = (gpos_header*)map_at(&lfFont->table_map, (void*)TAG_GPOS);
    if (table)
    {
        table->calculatedTableSize = 0;

        TABLE_HANDLE hLookup = (TABLE_HANDLE)table->LookupList;
        Lookup_removeUnReferencedLookups(hLookup, table, TRUE);
    }
    return LF_ERROR_OK;
}

LF_ERROR GPOS_updateLookupFlags(LF_FONT* lfFont)
{
    // This updates lookup flags based on presence/absence of the GDEF table.
    // TODO update based on content of GDEF if it is there

    gpos_header* table = (gpos_header*)map_at(&lfFont->table_map, (void*)TAG_GPOS);
    if (table == NULL)
        return LF_TABLE_MISSING;

    if (FALSE == map_key_exists(&lfFont->table_map, (void*)TAG_GDEF))
    {
        // there is no GDEF table, so we need to update flags in the lookup tables to
        // clear out any that require GDEF
        if (table->LookupList != NULL)
            return Lookup_clearGDEFFlags(table->LookupList);
    }
    return LF_ERROR_OK;
}

LF_ERROR GPOS_removeAnchorPoints(LF_FONT* lfFont)
{
    gpos_header* table = (gpos_header*)map_at(&lfFont->table_map, (void*)TAG_GPOS);
    if (table == NULL)
        return LF_ERROR_OK;

    LF_VECTOR* lookup_list_table = (LF_VECTOR*)table->LookupList;

    LF_ERROR error = LF_ERROR_OK;

    for (size_t i = 0; i < lookup_list_table->count; i++)
    {
        lookup_table* lookupTable = (lookup_table*)vector_at(lookup_list_table, i);

        for (size_t j = 0; j < lookupTable->SubTables.count; j++)
        {
            TABLE_HANDLE subtable = (TABLE_HANDLE)vector_at(&lookupTable->SubTables, j);

            switch (lookupTable->LookupType)
            {
            case GPOS_CURSIVE_ATTACHMENT:
                error = GPOS_cursiveAttachmentSetAnchorFmt1((gpos_cursive_attachment*)subtable);
                break;
            case GPOS_MARKTOBASE_ATTACHMENT:
                error = GPOS_markToBaseSetAnchorFmt1((gpos_marktobase*)subtable);
                break;
            case GPOS_MARKTOLIGATURE_ATTACHMENT:
                error = GPOS_markToLigatureSetAnchorFmt1((gpos_marktoligature*)subtable);
                break;
            case GPOS_MARKTOMARK_ATTACHMENT:
                error = GPOS_markToMarkSetAnchorFmt1((gpos_marktomark*)subtable);
                break;
            default:
                break;
            }

            if (error != LF_ERROR_OK)
                break;
        }
    }

    return error;
}
