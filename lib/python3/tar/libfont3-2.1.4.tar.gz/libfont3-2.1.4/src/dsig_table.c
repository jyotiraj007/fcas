// Copyright (C) 2014 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// dsig_table.c


#include "dsig_table.h"
#include "table_tags.h"
#include "unknown_table.h"


#if 0 // The below functions are not yet implemented.
LF_ERROR DSIG_readTable(LF_FONT* lfFont, const sfnt_table_record* record, LF_STREAM* stream)
{
    return UNKNOWN_readTable(lfFont, record, stream);
}

LF_ERROR DSIG_getTableSize(LF_FONT* lfFont, size_t* tableSize)
{
    return UNKNOWN_getTableSize(lfFont, TAG_DSIG, tableSize);
}

LF_ERROR DSIG_writeTable(LF_FONT* lfFont, sfnt_table_record* record, LF_STREAM* stream)
{
    return UNKNOWN_writeTable(lfFont, record, stream);
}

LF_ERROR DSIG_freeTable(LF_FONT* lfFont, const sfnt_table_record* record)
{
    return UNKNOWN_freeTable(lfFont, record);
}

sfnt_table_record* DSIG_updateRecord(sfnt_table_record *record)
{
    record->tag = TAG_DSIG;
    record->checkSum = UTILS_CalcTableChecksum(g_data, g_length);
    record->checkSum = SWAP_LONG(record->checkSum);
    record->length = SWAP_LONG(g_length);
    record->offset = 0;

    return record;
}
#endif
