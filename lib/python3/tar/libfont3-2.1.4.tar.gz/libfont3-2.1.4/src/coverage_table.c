// Copyright (C) 2014, 2017 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// coverage_table.c

#include "coverage_table.h"
#include "utils.h"
#include "common_table.h"

#define COVERAGE_FORMAT1        1
#define COVERAGE_FORMAT2        2

// Coverage Format 1
static LF_ERROR coverage_readCoverageFormat1(coverage_table* ct, LF_STREAM* stream);
static void     coverage_buildTableFormat1(const coverage_table_1* cf1, LF_STREAM* stream);
static void     coverage_freeCoverageFormat1(coverage_table_1* cf1);
static LF_ERROR buildFormat1(coverage_table* ct);


// Coverage Format 2
static void     coverage_buildTableFormat2(coverage_table_2* cf2, LF_STREAM* stream);
static void     coverage_freeCoverageFormat2(coverage_table_2* cf2);
static LF_ERROR coverage_readCoverageFormat2to1(coverage_table* ct, LF_STREAM* stream);
static LF_ERROR buildFormat2(coverage_table* ct);

static LF_ERROR coverage_findGlyphIndex(coverage_table* table, GlyphID glyphID, ULONG* index);


/* ============================================================================
    @brief
        read in a new coverage

============================================================================ */
LF_ERROR Coverage_readTable(coverage_table* table, LF_STREAM* stream)
{
    LF_ERROR error;
    size_t size = STREAM_streamPos(stream);

    ASSERT(table);

    memset(table, 0, sizeof(coverage_table));

    table->CoverageFormat = STREAM_readUShort(stream);
    table->ReadFormat = table->CoverageFormat;
    table->minGlyph = 0xFFFF;
    table->maxGlyph = 0;
    table->isAscending = TRUE;

    switch (table->CoverageFormat)
    {
    case COVERAGE_FORMAT1:
        error = coverage_readCoverageFormat1(table, stream);
        // If we encounter an error, then set CoverageFormat to 0 since that is the value that is
        // always checked to determine if a table exists
        if((error != LF_ERROR_OK) || (table->coverage_format.format_1.GlyphCount == 0))
            table->CoverageFormat = 0;
        if (table->coverage_format.format_1.GlyphCount == 0)
            error = LF_EMPTY_TABLE;
        break;

    case COVERAGE_FORMAT2:
        error = coverage_readCoverageFormat2to1(table, stream);
        if ((error != LF_ERROR_OK) || (table->CoverageMap.count == 0))
            table->CoverageFormat = 0;
        else
            table->CoverageFormat = 1;

        if (table->CoverageMap.count == 0)
            error = LF_EMPTY_TABLE;

        break;

    default:
        DEBUG_LOG_ERROR("Coverage found a bad format");
        error = LF_BAD_FORMAT;
        break;
    }

    table->ReadSize = (ULONG)(STREAM_streamPos(stream) - size);

    return error;
}

LF_ERROR Coverage_buildTable(coverage_table* table, LF_STREAM* stream)
{
    LF_ERROR error;

    if (NULL == table)
        return LF_BAD_FORMAT;

    if (table->isAscending == TRUE)
    {
        // build both formats and use the smaller
        error = buildFormat1(table);
        if (error != LF_ERROR_OK)
            return error;
        error = buildFormat2(table);
        if (error != LF_ERROR_OK)
            return error;

        if (table->size_build_1 <= table->size_build_2)
        {
            table->build_format = 1;

            STREAM_writeUShort(stream, table->build_format);
            coverage_buildTableFormat1(&table->build_1, stream);

            //DEBUG_LOG_VALUE("[CoverageFormat1] glyph array size: ", table->build_1.GlyphCount);
            //DEBUG_LOG_VALUE("[CoverageFormat1] memory size: ", table->size_build_1);
        }
        else
        {
            table->build_format = 2;

            STREAM_writeUShort(stream, table->build_format);
            coverage_buildTableFormat2(&table->build_2, stream);

            //DEBUG_LOG_VALUE("[CoverageFormat2] RangeRecords required: ", table->build_2.RangeRecords.count);
            //DEBUG_LOG_VALUE("[CoverageFormat2] Memory size: ", table->size_build_2);
        }
    }
    else
    {
        // Always use format one for messed up original tables
        error = buildFormat1(table);
        if (error != LF_ERROR_OK)
            return error;
        table->build_format = 1;

        STREAM_writeUShort(stream, table->build_format);
        coverage_buildTableFormat1(&table->build_1, stream);

        //DEBUG_LOG_VALUE("[CoverageFormat1] glyph array size: ", table->build_1.GlyphCount);
        //DEBUG_LOG_VALUE("[CoverageFormat1] memory size: ", table->size_build_1);
    }

#if 0 // CoverageFormat logging.
    size = STREAM_streamPos(stream) - size;
    DEBUG_LOG("[CoverageFormat] Stats: ");
    DEBUG_LOG_VALUE("[CoverageFormat] Read Memory size: ", table->ReadSize);
    DEBUG_LOG_VALUE("[CoverageFormat] Read Coverage format: ", table->ReadFormat);
    DEBUG_LOG_VALUE("[CoverageFormat] Build Memory size: ", size);
    DEBUG_LOG_VALUE("[CoverageFormat] Build Format: ", table->build_format);
    DEBUG_LOG("");
#endif

    return error;
}



/* ============================================================================
    @brief
        get the coverage table size and return back to the caller.  The
        coverage is calculated for both formats and the one that
        takes less memory in the stream is chosen.  if the formats are
        the same memory requirements, format 1 is chosen.

    @param
        table = pointer to the coverage table
        *tableSize = pointer to where the table size is to be stored

    @return
        return status.

============================================================================ */
LF_ERROR Coverage_getTableSize(coverage_table* table, size_t* tableSize)
{
    LF_ERROR error;

    *tableSize = sizeof(USHORT) * 2;                    // CoverageFormat

    if (table->isAscending == TRUE)
    {
        // build both of the formats
        error = buildFormat1(table);
        if (error != LF_ERROR_OK)
            return error;
        error = buildFormat2(table);
        if (error != LF_ERROR_OK)
            return error;

        if (table->size_build_1 <= table->size_build_2)
        {
            *tableSize += sizeof(GlyphID) * table->build_1.GlyphCount;
        }
        else
        {
            *tableSize += RANGE_RECORD_SIZE * table->build_2.RangeRecords.count;
        }
    }
    else
    {
        // Always build format 1 for messed up tables
        error = buildFormat1(table);
        if (error != LF_ERROR_OK)
            return error;
        *tableSize += sizeof(GlyphID) * table->build_1.GlyphCount;
    }

    return error;
}





/* ============================================================================
    @brief
        delete the coverage table and free the memory resources used
        for the coverage table.

    @param
        table = pointer to the coverage table

    @return
        return status.

============================================================================ */
void Coverage_deleteTable(coverage_table* table)
{
    switch (table->CoverageFormat)
    {
    case COVERAGE_FORMAT1:
        coverage_freeCoverageFormat1(&table->coverage_format.format_1);
        break;

    case COVERAGE_FORMAT2:
        coverage_freeCoverageFormat2(&table->coverage_format.format_2);
        break;
    default:
        break;
    }

    coverage_freeCoverageFormat1(&table->build_1);
    coverage_freeCoverageFormat2(&table->build_2);

    vector_delete(&table->CoverageMap);

    memset(table, 0, sizeof(coverage_table));
}



/* ============================================================================
    @brief
        remove a glyphID from coverage table.  the function will return
        back the index which the glyphID was stored in the coverage table
        array.  This is useful if you need to sync coverage tables with
        other tables and maintain a 1 : 1 connection in both tables.

        the index pointer will be set to a value of 0xFFFFFFFF first, so
        if EMPTY_TABLE is returned and the index value is 0xFFFFFFFF you
        will know the coverage table was empty from before the call.

        if the index value is set to another value, and EMPTY is returned
        the caller will know the glyph id was found and removed from the
        coverage table.


    @param
        table        :    pointer to the coverage table
        glyphID      :    the glyph id value that you want to remove
        index        :    pointer to a ULONG which will hold the index.

    @return
        LF_ERROR_OK       :    the glyph id was removed from the coverage table

        LF_NOT_COVERED    :    the glyph id doesn't exist in the coverage table

        LF_EMPTY_TABLE    :    the coverage table is empty.  this can be caused
                               by the glyph was found and removed, which emptied
                               the table, or the table was already empty.

============================================================================ */
LF_ERROR Coverage_removeGlyphIndex(coverage_table* table, GlyphID glyphID, ULONG* index)
{
    if (glyphID >= table->minGlyph && glyphID <= table->maxGlyph)
    {
        LF_ERROR error;

        error = coverage_findGlyphIndex(table, glyphID, index);
        if(error == LF_ERROR_OK)
        {
            vector_erase(&table->CoverageMap, *index); // ignore ret val
            return ((Coverage_getCoverageCount(table) == 0) ? LF_EMPTY_TABLE : LF_ERROR_OK);
        }

        return error;
    }
    else
    {
        *index = 0xFFFFFFFF;
        return LF_NOT_COVERED;
    }
}

/* ============================================================================
    @brief
        remove a coverage value at a specific index inside the coverage
        table.

    @param
        table    : pointer to the coverage table structure
        index    : index into the coverage array

    @return
        OK               : index was erased
        INVALID_INDEX    : the index value exceeds the coverage array
        EMPTY            : the coverage table is empty

============================================================================ */
LF_ERROR Coverage_eraseIndex(coverage_table* table, USHORT index)
{
    LF_ERROR error = vector_erase(&table->CoverageMap, index);

    if (error == LF_ERROR_OK)
    {
        if (Coverage_getCoverageCount(table) == 0)
            error = LF_EMPTY_TABLE;
    }
    return error;
}

static LF_ERROR coverage_findGlyphIndexLinear(coverage_table* table, GlyphID glyphID, ULONG* index)
{
    size_t maxIdx = Coverage_getCoverageCount(table);

    // check for empty table ...
    if (maxIdx == 0)
    {
        *index = 0xFFFFFFFF;
        return LF_EMPTY_TABLE;
    }

    for (size_t i = 0; i < maxIdx; i++)
    {
        GlyphID glyph = (GlyphID)(intptr_t)vector_at(&table->CoverageMap, i);

        if (glyph == glyphID)
        {
            *index = (ULONG)i;
            return LF_ERROR_OK;
        }
    }

    *index = 0xFFFFFFFF;
    return LF_NOT_COVERED;
}

#define MID_POINT(min, max)        (min + ((max - min) >> 1))

/* ----------------------------------------------------------------------------
    @summary
        find glyph in the coverage map.

        This function searches the coverage array to return the index of the
        specified glyph.  The glyph is passed and a binary search is used
        to find the glyph index.  Once found the index is stored in the passed
        index pointer and returned.

        The function will return an error of not covered if the glyph is not
        found in the coverage array.


    @param
        table = pointer to the coverage table
        glyphID = glyph id that we want to find
        *index = pointer to ULONG that will return the index value.

    @return
        LF_ERROR_OK - the glyph id was found
        LF_NOT_COVERED - the glyph id doesn't exist in coverage
        LF_EMPTY_TABLE - the table is currently empty

    @notes
    This function uses a binary search, or a half-interval search algorithm,
    which finds the position of a specified glyphID value (aka key) within
    the sorted array list.  The array list is sorted by the key value.  In
    each step, the algorithm compares the search key value with the key
    value of the middle element of the array.  Once the key matches, the
    index value is stored and returns.  Otherwise, if the search key is less
    than the middle element's key, then the algorithm repeats its action on
    the sub-array to the left of the middle element or, if the key is greater,
    on the sub-array to the right.  If the remaining array to be searched is
    empty, then the key cannot be found in the array the "Err_Not_Covered" is
    returned.

---------------------------------------------------------------------------- */
static LF_ERROR coverage_findGlyphIndex(coverage_table* table, GlyphID glyphID, ULONG* index)
{
    if (table->isAscending == FALSE)
    {
        return coverage_findGlyphIndexLinear(table, glyphID, index);
    }

    LONG minIdx = 0;
    LONG maxIdx = (LONG)Coverage_getCoverageCount(table);

    // check for empty table ...
    if (maxIdx == 0)
    {
        *index = 0xFFFFFFFF;
        return LF_EMPTY_TABLE;
    }

    maxIdx--;

    while (maxIdx >= minIdx)
    {
        LONG midIdx = MID_POINT(minIdx, maxIdx);

        GlyphID glyph = (GlyphID)(intptr_t)vector_at(&table->CoverageMap, midIdx);

        if(glyph > glyphID)
        {
            maxIdx = midIdx - 1;
        }
        else if (glyph < glyphID)
        {
            minIdx = midIdx + 1;
        }
        else // (glyph == glyphID)
        {
            *index = midIdx;
            return LF_ERROR_OK;
        }
    }

    *index = 0xFFFFFFFF;
    return LF_NOT_COVERED;
}

/* ----------------------------------------------------------------------------
    @brief
        given a coverage format 1 structure, save out the data in the
        structure to the stream

    @param
        cf1 = pointer to the defined coverage format 1 structure
        stream = pointer to the stream we want to use.

---------------------------------------------------------------------------- */
static void coverage_buildTableFormat1(const coverage_table_1* cf1, LF_STREAM* stream)
{
    int i;

    if (cf1)
    {
        if (cf1->GlyphCount == 0)
        {
            DEBUG_LOG_WARNING("coverage format 1 glyph count is 0");
        }

        if (cf1->GlyphArray == NULL)
        {
            DEBUG_LOG_ERROR("coverage format 1 glyph array is empty or NULL");
            return;
        }

        STREAM_writeUShort(stream, cf1->GlyphCount);
        for(i = 0; i < cf1->GlyphCount; i++)
        {
            STREAM_writeUShort(stream, cf1->GlyphArray[i]);
        }
    }
}



/* ----------------------------------------------------------------------------
    @brief
        given a coverage format 2 structure, save out the data in the
        structure to the stream

    @param
        cf2 = pointer to the defined coverage format 1 structure
        stream = pointer to the stream we want to use.

---------------------------------------------------------------------------- */
static void coverage_buildTableFormat2(coverage_table_2* cf2, LF_STREAM* stream)
{
    ULONG i = 0;

    STREAM_writeUShort(stream, (USHORT)cf2->RangeRecords.count);

    for(; i < cf2->RangeRecords.count; i++)
    {
        range_record* record = (range_record*)vector_at(&cf2->RangeRecords, i);

        // check for errors in the ranges, since we are limited to 16bit offsets
        if ( record->Start > record->End )
        {
            DEBUG_LOG_WARNING("Coverage format 2 start range is higher than end range");
        }

        if ((record->End - record->Start + (long)record->StartCoverageIndex ) >= 0x10000L )
        {
            DEBUG_LOG_WARNING("Coverage format 2 exceeds 16bit start coverage index.");
        }

        STREAM_writeUShort(stream, record->Start);
        STREAM_writeUShort(stream, record->End);
        STREAM_writeUShort(stream, record->StartCoverageIndex);
    }
}



/* ----------------------------------------------------------------------------
    @brief
        read in coverage format 1 from the stream.

    @param
        cf1     = pointer to the coverage structure to initialize with the
                  stream.
        stream  = pointer to the stream that starts where the coverage table
                  is at.

    @return
        status of the stream.
---------------------------------------------------------------------------- */
static LF_ERROR coverage_readCoverageFormat1(coverage_table* ct, LF_STREAM* stream)
{
    USHORT              glyphCount    = STREAM_readUShort(stream);
    USHORT              i;

    coverage_table_1* cf1 = &ct->coverage_format.format_1;

    cf1->GlyphCount = glyphCount;

    if (glyphCount == 0)
    {
        DEBUG_LOG_WARNING("Original coverage table (format 1) has no glyphs.");
        return LF_ERROR_OK;
    }

    cf1->GlyphArray = (GlyphID*)malloc(glyphCount * sizeof(GlyphID));
    if (!cf1->GlyphArray)
    {
        DEBUG_LOG_ERROR("Coverage unable to allocate memory");
        return LF_OUT_OF_MEMORY;
    }

    // create a working coverage table in a common format
    LF_ERROR error = vector_init(&ct->CoverageMap, glyphCount, sizeof(ULONG));
    if (error != LF_ERROR_OK)
    {
        free(cf1->GlyphArray);
        cf1->GlyphArray = NULL;
        return LF_OUT_OF_MEMORY;
    }

    USHORT lastGID = 0;

    for(i = 0; i < glyphCount; i++)
    {
        USHORT glyphid = STREAM_readUShort(stream);

        if (glyphid > ct->maxGlyph)
            ct->maxGlyph = glyphid;

        if (glyphid < ct->minGlyph)
            ct->minGlyph = glyphid;

        cf1->GlyphArray[i] = glyphid;
        vector_push_back(&ct->CoverageMap, (void*)(intptr_t)glyphid);                // store the new coverage glyph

        if ((lastGID != 0) && (lastGID >= glyphid))
            ct->isAscending = FALSE;

        lastGID = glyphid;
    }

    if (ct->isAscending == FALSE)
    {
        DEBUG_LOG_WARNING("a format 1 coverage table has non-ascending values");
    }

    return LF_ERROR_OK;
}

/* ----------------------------------------------------------------------------
    @brief
        read in coverage format 2 and convert it to common format.

    @param
        ct = pointer to coverage table
        stream = pointer to stream holding the coverage.

    @return
        error = status of read.
---------------------------------------------------------------------------- */
static LF_ERROR coverage_readCoverageFormat2to1(coverage_table* ct, LF_STREAM* stream)
{
    USHORT count = STREAM_readUShort(stream);
    USHORT n;
    coverage_table_1* cf1 = &ct->coverage_format.format_1;

    if (count == 0)
    {
        DEBUG_LOG_WARNING("Original coverage table (format 2) has no glyphs.");
        return LF_ERROR_OK;    // Don't build a coverage table if no glyphs
    }

    cf1->GlyphCount = 0;
    cf1->GlyphArray = NULL;

    LF_ERROR error = vector_init(&ct->CoverageMap, 1, sizeof(ULONG));
    if (error != LF_ERROR_OK)
    {
        return LF_OUT_OF_MEMORY;
    }

    ULONG lastEnd = 0;

    for(n = 0; n < count; n++)
    {
        USHORT Start = STREAM_readUShort(stream);
        USHORT End = STREAM_readUShort(stream);
        USHORT StartCoverageIndex = STREAM_readUShort(stream);
        ULONG i;

        (void)StartCoverageIndex;

        if (End > ct->maxGlyph)
        {
            ct->maxGlyph = End;
        }

        if (Start < ct->minGlyph)
        {
            ct->minGlyph = Start;
        }

        if ((lastEnd != 0) && (Start <= lastEnd))
        {
            ct->isAscending = FALSE;

            if (Start == lastEnd)
            {
                if (Start == End)
                {
                    DEBUG_LOG_WARNING("removing a duplicate single entry coverage range");
                    continue;
                }
                else
                {
                    if (End > lastEnd)
                    {
                        Start = (USHORT)(lastEnd + 1);
                        DEBUG_LOG_WARNING("truncating an overlapping coverage range");
                    }
                    else
                    {
                        DEBUG_LOG_WARNING("skipping a non-ascending coverage range");
                        continue;
                    }
                }
            }
        }
        lastEnd = End;

        for(i = Start; i <= End; i++)
        {
            vector_push_back(&ct->CoverageMap, (void*)(intptr_t)i);
            if (i == 65535)
                break;
        }
    }

    if (ct->isAscending == FALSE)
    {
        DEBUG_LOG_WARNING("a format 2 coverage table has non-ascending values");
    }

    return LF_ERROR_OK;
}

/* ----------------------------------------------------------------------------
    @brief
        free the coverage format 1 table which consists of a USHORT
        array, reset the count to be 0

    @param
        cf1 = pointer to the coverage format 1 structure

---------------------------------------------------------------------------- */
static void coverage_freeCoverageFormat1(coverage_table_1* cf1)
{
    FREE(cf1->GlyphArray);
    cf1->GlyphCount = 0;
    cf1->GlyphArray = NULL;
}

/* ----------------------------------------------------------------------------
    @brief
        delete the coverage format 2 table

    @param
        pointer to the coverage format 2 table

---------------------------------------------------------------------------- */
static void coverage_freeCoverageFormat2(coverage_table_2* cf2)
{
    size_t count, i;

    count = vector_size(&cf2->RangeRecords);

    for(i = 0; i < count; i++)
    {
        free((void*)vector_at(&cf2->RangeRecords, i));
    }
    vector_delete(&cf2->RangeRecords);
}

/* ============================================================================
    @brief
        get the glyph id at the given offset within the coverage table


============================================================================ */
LF_ERROR Coverage_getCoverageAt(coverage_table* ct, USHORT offset, USHORT* glyph)
{
    *glyph = (USHORT)(intptr_t)vector_at(&ct->CoverageMap, offset);

    return LF_ERROR_OK;
}

/* ============================================================================
    @summary
        given a list of coverage tables, and an offset array position
        within a stream, this method will calculate the offsets and
        store out the coverage tables into the stream.

    @param
        coverages = pointer to the collection of coverage tables
        stream = pointer to the stream which will hold coverages
        baseOffset = stream position to base offset values from
        arrayOffset = stream position that holds the offsets for
                      each of the coverages.

    @return
        status of stream
============================================================================ */
LF_ERROR Coverage_buildTables(LF_VECTOR* coverages, LF_STREAM* stream, ULONG baseOffset, ULONG arrayOffset)
{
    USHORT n, count;
    ULONG  curOffset;

    ASSERT(coverages);
    ASSERT(stream);

    if (NULL == coverages)
        return LF_BAD_FORMAT;

    curOffset = arrayOffset;
    count = (USHORT)coverages->count;

    for (n = 0; n < count; n++)
    {
        coverage_table* ct = (coverage_table*)vector_at(coverages, n);

        Coverage_buildCoverage(ct, stream, curOffset, baseOffset);
        curOffset += sizeof(OFFSET);
    }

    return LF_ERROR_OK;
}

/* ============================================================================
    @summary
        build a coverage table and update the arrayOffset value.

    @param
        coverage = pointer to the coverage table
        stream = pointer to the stream which will hold coverages
        baseOffset = stream position to base offset which the Coverage
                     offset is calculated from.  (i.e. start of Substitution
                     table)

        arrayOffset = stream position that holds the offsets for
                      each of the coverages.  The Offset array holds USHORT
                      offset values.

    @return
        status of stream
============================================================================ */
LF_ERROR Coverage_buildCoverage(coverage_table* ct, LF_STREAM* stream, ULONG arrayOffset, ULONG baseOffset)
{
    size_t    curOffset, offset;

    ASSERT(ct);
    ASSERT(stream);

    curOffset = STREAM_streamPos(stream);
    offset = curOffset - baseOffset;
    STREAM_streamSeek(stream, arrayOffset);
    STREAM_writeOffset(stream, (OFFSET)offset);
    STREAM_streamSeek(stream, curOffset);

    Coverage_buildTable(ct, stream);

    return LF_ERROR_OK;
}

/* ============================================================================
    @summary
        return back the size of a list of coverage tables to the caller

    @param
        coverage = pointer to the coverage table

    @return
        the size of all of the coverages

============================================================================ */
size_t Coverage_sizeCoverages(LF_VECTOR* coverages)
{
    USHORT n;
    size_t coverageSize, size;

    size = 0;

    for ( n = 0; n < coverages->count; n++)
    {
        coverage_table* table = (coverage_table*)vector_at(coverages, n);
        Coverage_getTableSize(table, &coverageSize);
        size += coverageSize;
    }
    return size;
}

/* ============================================================================
    @summary
        free up the coverages collection.

    @param
        coverage = pointer to the coverage table

============================================================================ */
void Coverage_deleteCoverageTables(LF_VECTOR* coverages)
{
    USHORT n;

    ASSERT(coverages);

    if (coverages)
    {
        for (n = 0; n < coverages->count; n++)
        {
            coverage_table* table = (coverage_table*)vector_at(coverages, n);
            Coverage_deleteTable(table);
            free(table);
        }
        vector_delete(coverages);
    }
}

/* ============================================================================
    @summary
        remove a glyph from a collection of coverages.  return empty if
        all of the coverages have been emptied out.

        if just one of the tables is emptied in the collection, it will
        return EMPTY_TABLE as this breaks the context.

    @param
        coverages    :    pointer to the coverage tables
        glyphid      :    the glyph id to remove from the coverage tables.


    @return
        LF_EMPTY_TABLE    :   one of the coverages was emptied, so we have
                              broken the context and we can declare the
                              collection as empty.

        LF_ERROR_OK       :   the glyph id was removed and the context has
                              remained.

        LF_NOT_COVERED    :   the glyph id wasn't found in the collection
                              of coverage tables.
============================================================================ */
LF_ERROR Coverage_removeCoveragesGlyphIndex(LF_VECTOR* coverages, GlyphID glyphid)
{
    ULONG        n;
    LF_ERROR     error = LF_NOT_COVERED;
    ULONG        index;

    for (n = 0; n < coverages->count; n++)
    {
        coverage_table* ct = (coverage_table*)vector_at(coverages, n);
        if (ct)
        {
            if (Coverage_getCoverageCount(ct) != 0)
            {
                // if we return back with an empty table, then the glyph was
                // found and the we need to return an empty...
                error = Coverage_removeGlyphIndex(ct, glyphid, &index);

                if (error == LF_EMPTY_TABLE)
                    return LF_EMPTY_TABLE;

                if (error == LF_ERROR_OK)
                    error = LF_ERROR_OK;
            }
        }
    }

    return error;
}

/* ============================================================================
    @summary
        A common function is to read in an array of coverage tables from the
        stream.  The array is defined by an array of offsets. using the array
        of offsets, we seek to the coverage table in the stream, load it into
        a new structure, store it on the vector    array, and then continue reading
        the array of offset.

============================================================================ */
LF_ERROR Coverage_readArray(LF_VECTOR* array, USHORT count, LF_STREAM* stream, ULONG baseOffset)
{
    USHORT        nb;
    size_t        curOffset, newOffset;
    LF_ERROR      error;

    if (count)
    {
        error = vector_init(array, count, sizeof(ULONG));
        if (error != LF_ERROR_OK)
            return error;

        for (nb = 0; nb < count; nb++)
        {
            coverage_table* ct = (coverage_table*)malloc(sizeof(coverage_table));
            if (!ct)
            {
                DEBUG_LOG_ERROR("Failed to allocate a coverage table structure");
                return LF_OUT_OF_MEMORY;
            }

            newOffset = STREAM_readOffset(stream) + baseOffset;
            curOffset = STREAM_streamPos(stream);
            STREAM_streamSeek(stream, newOffset);

            error = Coverage_readTable(ct, stream);

            if ((error == LF_ERROR_OK) || (error == LF_EMPTY_TABLE))
            {
                vector_push_back(array, ct);
                STREAM_streamSeek(stream, curOffset);
            }
            else
            {
                free(ct);
                return error;
            }
        }
    }
    return LF_ERROR_OK;
}

/* ----------------------------------------------------------------------------
    @brief
        build a mock-up of coverage format 1

---------------------------------------------------------------------------- */
static LF_ERROR buildFormat1(coverage_table* ct)
{
    USHORT n, count;
    coverage_table_1* cf1 = &ct->build_1;

    // free old coverage calculations
    coverage_freeCoverageFormat1(&ct->build_1);

    count = UTILS_getCount(&ct->CoverageMap);

    cf1->GlyphCount = count;
    cf1->GlyphArray = (GlyphID*)malloc(count * sizeof(GlyphID));
    if (cf1->GlyphArray == NULL)
    {
        return LF_OUT_OF_MEMORY;
    }

    GlyphID lastAdded = 0;
    USHORT skipped = 0;
    USHORT used = 0;

    for(n = 0; n < count; n++)
    {
        GlyphID gid = (GlyphID)(intptr_t)vector_at(&ct->CoverageMap, n);

        if ((n!=0) && (gid <= lastAdded))
        {
            skipped++;
            DEBUG_LOG_WARNING("removing non-ascending value from coverage in buildFormat1");
            continue;
        }

        cf1->GlyphArray[used++] = lastAdded = gid;
    }

    count -= skipped;
    cf1->GlyphCount -= skipped;

    ct->size_build_1 = sizeof(USHORT);                          // CoverageFormat
    ct->size_build_1 += sizeof(USHORT);                         // GlyphCount
    ct->size_build_1 += (USHORT)(count * sizeof(GlyphID));      // Glyph[GlyphCount]

    return LF_ERROR_OK;
}

/* ----------------------------------------------------------------------------
    @brief
        given a LF_VECTOR, create a range record using the passed parameters
        and push the record onto the vector array.

    @param
        records = vector array to receive new record
        startRange = starting glyph of the range record
        endRange = ending glyph of the range record
        coverageindex = starting coverage index.

    @returns
        if will return OK, if successful in pushing the new range_record,
        otherwise OUT_OF_MEMORY.

---------------------------------------------------------------------------- */
static LF_ERROR pushRangeRecord(LF_VECTOR* records, GlyphID startRange, GlyphID endRange, USHORT coverageindex)
{
    LF_ERROR error;
    range_record* record = (range_record*)malloc(sizeof(range_record));
    if (record)
    {
        record->Start = startRange;
        record->End = endRange;
        record->StartCoverageIndex = coverageindex;

        vector_push_back(records, record);

        error = LF_ERROR_OK;
    }
    else
    {
        DEBUG_LOG_ERROR("failed to allocate range_record structure");
        error = LF_OUT_OF_MEMORY;
    }

    return error;
}

/* ----------------------------------------------------------------------------
    @desc
        build out format 2 using the coverage map format.  By going through
        the coverage map glyphs, build out a format 2 coverage output.
---------------------------------------------------------------------------- */
static LF_ERROR buildFormat2(coverage_table* ct)
{
    USHORT                n, count, glyphID;
    USHORT                coverageIndex = 0;
    USHORT                curCoverageIndex = 0;
    USHORT                startRange, endRange;
    USHORT                sizeFormat2;
    coverage_table_2*     cf2 = &ct->build_2;

    coverage_freeCoverageFormat2(cf2);

    // first check how many range records we have ...
    count = UTILS_getCount(&ct->CoverageMap);

    LF_ERROR error = vector_init(&cf2->RangeRecords, 1, sizeof(ULONG));
    if (error != LF_ERROR_OK)
        return error;

    if (count == 0)
    {
        ct->size_build_2 = 2*sizeof(USHORT); // CoverageFormat + RangeCount
        return LF_ERROR_OK;
    }

    startRange = endRange = (GlyphID)(intptr_t)vector_at(&ct->CoverageMap, 0);
    endRange++;

    for (n = 1; n < count; n++)
    {
        glyphID = (GlyphID)(intptr_t)vector_at(&ct->CoverageMap, n);

        coverageIndex++;

        if (endRange != glyphID)
        {
            error = pushRangeRecord(&cf2->RangeRecords, startRange, endRange - 1, curCoverageIndex);
            if (error != LF_ERROR_OK)
                return error;

            curCoverageIndex = coverageIndex;

            endRange = startRange = glyphID;
            endRange++;
        }
        else
        {
            endRange++;            // next element in range
        }
    }

    // we need to push the last range that was in the loop
    error = pushRangeRecord(&cf2->RangeRecords, startRange, endRange - 1, curCoverageIndex);
    if (error == LF_ERROR_OK)
    {
        sizeFormat2 = sizeof(USHORT);                                                       // CoverageFormat
        sizeFormat2 += sizeof(USHORT);                                                      // RangeCount
        sizeFormat2 += (USHORT)(RANGE_RECORD_SIZE * UTILS_getCount(&cf2->RangeRecords));    // RangeRecords

        ct->size_build_2 = sizeFormat2;
    }

    return error;
}

#ifdef LF_OT_DUMP
/* ----------------------------------------------------------------------------
    @brief
        Dump out the coverage table to the xml file

---------------------------------------------------------------------------- */
void Coverage_dumpTable(coverage_table* ct)
{
    size_t i, size;

    size = vector_size(&ct->CoverageMap);

    XML_START("Coverage");
    for (i = 0; i < size; i++)
    {
        //lint -size(a, 2049)
        char string[2048];
        //lint -size(a, 0)
        GlyphID glyph = (GlyphID)(long)vector_at(&ct->CoverageMap, i);
        sprintf(string, "%d        <!-- Index[%lu / %lu] -->", glyph, (unsigned long)i, (unsigned long)(size - 1));
        XML_NODE("gid", string);
    }
    XML_END("Coverage");
}
#endif

/* ----------------------------------------------------------------------------
    @summary
        given a coverage table and a remap dictionary, remap all of the
        glyphs inside the coverage table.

    @param
        table        :    pointer to the coverage table
        remap        :    pointer to the LF_MAP containing all of the
                          glyph id re-mappings.

    @return 
        LF_ERROR_OK       :    everything went well
        LF_EMPTY_TABLE    :    the coverage table is empty, nothing done
        LF_INVALID_INDEX  :    something is seriously wrong with vector count
                               and data.
    @notes
        Since the LF_MAP deals with everything being a void* pointer, NULL
        is returned if the key isn't found with the map_at function.  This
        means that a replacement glyphID value of 0 will be ignored.  I
        have put in a warning message if this is the case.

---------------------------------------------------------------------------- */
LF_ERROR Coverage_remapAll(coverage_table* table, LF_MAP* remap)
{
    ULONG        n;
    LF_ERROR    error = LF_ERROR_OK;

    for ( n = 0; n < table->CoverageMap.count; n++)
    {
        GlyphID coverage    = (GlyphID)(intptr_t)vector_at(&table->CoverageMap, n);
        GlyphID newGlyph;

        error = Common_remapGlyph(remap, coverage, &newGlyph);

        if (error != LF_ERROR_OK)
        {
            DEBUG_LOG_WARNING("Common_remapGlyph returned a zero for replacement glyph");
        }

        error = vector_set_data(&table->CoverageMap, n, (void*)(intptr_t)newGlyph);
    }

    return error;
}

/* ----------------------------------------------------------------------------
    @summary
        given a vector collection of coverage tables and a remap dictionary,
        remap all of the glyphs inside the coverage table within the
        collection.

    @param
        coverages    :    pointer to the LF_VECTOR collection that holds all
                          of the coverages.

        remap        :    pointer to the LF_MAP containing all of the
                          glyph id re-mappings.

    @return 
        LF_ERROR_OK       :    everything went well
        LF_EMPTY_TABLE    :    the coverage table is empty, nothing done
        LF_INVALID_INDEX  :    something is seriously wrong with vector count
                               and data.
    @notes
        Since the LF_MAP deals with everything being a void* pointer, NULL
        is returned if the key isn't found with the map_at function.  This
        means that a replacement glyphID value of 0 will be ignored.  I
        have put in a warning message if this is the case.

---------------------------------------------------------------------------- */
LF_ERROR Coverage_remapTables(LF_VECTOR* coverages, LF_MAP* remap)
{
    USHORT n, count;
    LF_ERROR error = LF_EMPTY_TABLE;
    LF_ERROR status;

    ASSERT(coverages);

    if (coverages)
    {
        count = (USHORT)coverages->count;
        for (n = 0; n < count; n++)
        {
            coverage_table* ct = (coverage_table*)vector_at(coverages, n);
            status = Coverage_remapAll(ct, remap);
            if (status != LF_ERROR_OK)
            {
                DEBUG_LOG_ERROR("remapping problem");
                error = status;
            }
        }
    }
    return error;
}

#ifdef LF_OT_DUMP
void Coverage_dumpTables(LF_VECTOR* coverages)
{
    USHORT n, count;

    ASSERT(coverages);

    count = (USHORT)coverages->count;
    for (n = 0; n < count; n++)
    {
        coverage_table* ct = (coverage_table*)vector_at(coverages, n);
        XML_COMMENT_INDEX("Coverages", n, (count - 1));
        Coverage_dumpTable(ct);
    }
}
#endif

LF_ERROR Coverage_existsInKeepList(coverage_table* coverage, GlyphList* keepTable)
{
    USHORT n, count;
    LF_ERROR error = LF_NOT_COVERED;

    count = (USHORT)Coverage_getCoverageCount(coverage);
    for (n = 0; n < count; n++)
    {
        GlyphID glyph;
        Coverage_getCoverageAt(coverage, n, &glyph);

        LF_ERROR keepStatus = Keep_coverageExists(keepTable, glyph);
        if (keepStatus == LF_ERROR_OK)
        {
            // one of the glyphs in the coverage table exists in the keepTable
            error = keepStatus;
        }
    }
    return error;
}

LF_ERROR Coverages_existsInKeepList(LF_VECTOR* coverages, GlyphList* keepTable)
{
    USHORT i, n, count;
    LF_ERROR error = LF_NOT_COVERED;
    USHORT bEmpty = TRUE;

    if (coverages->count == 0)
        return LF_EMPTY_TABLE;

    for (i = 0; i < coverages->count; i++)
    {
        coverage_table* coverage = (coverage_table*)vector_at(coverages, i);

        count = (USHORT)Coverage_getCoverageCount(coverage);

        for (n = 0; n < count; n++)
        {
            GlyphID glyph;
            Coverage_getCoverageAt(coverage, n, &glyph);

            bEmpty = FALSE;

            LF_ERROR keepStatus = Keep_coverageExists(keepTable, glyph);
            if (keepStatus == LF_ERROR_OK)
            {
                // one of the glyphs in the coverage table exists in the keepTable
                error = keepStatus;
            }
        }
    }

    // There are circumstances where a lookAhead, or Backtrack can be empty and
    // it is this value that will return EMPTY if there is nothing there.  we need
    // to check otherwise we may get a incorrect return of NOT_COVERED.  NOT_COVERED
    // would reflect that there was a context to check, but it wasn't found in the
    // keep list.
    if (bEmpty == TRUE)
        error = LF_EMPTY_TABLE;

    return error;
}

LF_ERROR Coverage_findGlyphIndex(coverage_table* table, GlyphID glyphID, ULONG* index)
{
    return coverage_findGlyphIndex(table, glyphID, index);
}

LF_ERROR Coverage_create(coverage_table* table, USHORT glyphCount)
{
    coverage_table_1* cf1 = &table->coverage_format.format_1;

    table->CoverageFormat = 1;              // default to format 1
    table->curIndex = 0;                    // current index
    table->minGlyph = 65535;                // minimum glyph id value
    table->maxGlyph = 0;                    // maximum glyph id value
    table->isAscending = TRUE;

    cf1->GlyphCount = glyphCount;           // store the number of glyphs
    cf1->GlyphArray = (GlyphID*)calloc(1, (glyphCount * sizeof(GlyphID)));
    if (!cf1->GlyphArray)
    {
        DEBUG_LOG_ERROR("Coverage unable to allocate memory");
        return LF_OUT_OF_MEMORY;
    }

    // create a working coverage table in a common format
    vector_init(&table->CoverageMap, glyphCount, sizeof(ULONG));
    map_init(&table->sortedMap, integer_compare);

    return LF_ERROR_OK;
}

LF_ERROR Coverage_addGlyph(coverage_table* table, GlyphID glyph)
{
    if (glyph > table->maxGlyph)
        table->maxGlyph = glyph;

    if (glyph < table->minGlyph)
        table->minGlyph = glyph;

    map_insert(&table->sortedMap, (void*)(intptr_t)glyph, (void*)(intptr_t)glyph);

    return LF_ERROR_OK;
}

LF_ERROR Coverage_done(coverage_table* table)
{
    LF_MAP_ITER* mapIter;
    rb_tree_node* node;

    mapIter = map_begin(&table->sortedMap);
    if (mapIter == NULL)
        return LF_OUT_OF_MEMORY;

    node = map_next(mapIter);

    while (node)
    {
        GlyphID glyph = (GlyphID)(intptr_t)node->key;

        vector_push_back(&table->CoverageMap, (void*)(intptr_t)glyph);  // store the new coverage glyph

        node = map_next(mapIter);
    }

    map_free_iter(mapIter);
    map_clear(&table->sortedMap);

    return LF_ERROR_OK;
}
