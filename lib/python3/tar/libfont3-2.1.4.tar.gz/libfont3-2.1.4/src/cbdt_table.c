// Copyright (C) 2016 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// cbdt_table.c

#include "cbdt_table.h"
#include "table_tags.h"
#include "cblc_table.h"
#include "ebdt_table.h"
#include "keep_table.h"
#include "utils.h"

LF_ERROR CBDT_readTable(LF_FONT* lfFont, const sfnt_table_record* record, LF_STREAM* stream)
{
    if (record->length == 0)
        return LF_BAD_FORMAT;

    if (STREAM_streamSeek(stream, record->offset) != 0)
        return LF_INVALID_OFFSET;

    // CBLC must have been read in
    cblc_table* cblc = (cblc_table*)map_at(&lfFont->table_map, (void*)TAG_CBLC);
    if (cblc == NULL)
        return LF_BAD_FORMAT;

    cbdt_table* table = (cbdt_table*)calloc(1, sizeof(cbdt_table));
    if (table == NULL)
        return LF_OUT_OF_MEMORY;

    LF_ERROR error = EBDT_parseTable(table, cblc, record, stream);

    if (error != LF_ERROR_OK)
    {
        return error;
    }

    map_insert(&lfFont->table_map, (void*)(intptr_t)record->tag, table);

    return LF_ERROR_OK;
}

LF_ERROR CBDT_keepGlyphs(const LF_FONT* lfFont, GlyphList* keepList)
{
    // We currently do not support CBDT tables with binary images, so there is nothing to do here.
    (void)lfFont; (void)keepList;
    return LF_ERROR_OK;
}

LF_ERROR CBDT_removeGlyph(LF_FONT* lfFont, ULONG index)
{
    cbdt_table* table = (cbdt_table*)map_at(&lfFont->table_map, (void*)TAG_CBDT);

    return EBDT_internalRemoveGlyph(table, index);
}

LF_ERROR CBDT_isTableEmpty(LF_FONT* lfFont)
{
    cbdt_table* table = (cbdt_table*)map_at(&lfFont->table_map, (void*)TAG_CBDT);

    return EBDT_internalIsTableEmpty(table);
}

LF_ERROR CBDT_remapTable(LF_FONT* lfFont, LF_MAP *remap)
{
    cbdt_table* table = (cbdt_table*)map_at(&lfFont->table_map, (void*)TAG_CBDT);

    return EBDT_internalRemap(lfFont, table, remap);
}

LF_ERROR CBDT_getCount(LF_FONT* lfFont, USHORT* numGlyphs)
{
    cbdt_table* table = (cbdt_table*)map_at(&lfFont->table_map, (void*)TAG_CBDT);
    if (table == NULL)
        return LF_EMPTY_TABLE;

    return EBDT_internalCount(table, numGlyphs);
}

LF_ERROR CBDT_getTableSize(LF_FONT* lfFont, size_t* tableSize)
{
    cbdt_table* table = (cbdt_table*)map_at(&lfFont->table_map, (void*)TAG_CBDT);

    return EBDT_internalGetSize(table, tableSize);
}

LF_ERROR CBDT_writeTable(LF_FONT* lfFont, sfnt_table_record* record, LF_STREAM* stream)
{
    size_t tableSize;
    BYTE* tableData;

    cbdt_table* table = (cbdt_table*)map_at(&lfFont->table_map, (void*)TAG_CBDT);
    if (table == NULL)
        return LF_TABLE_MISSING;

    LF_ERROR error = EBDT_buildTable(table, table->version, &tableData, &tableSize);
    if (error != LF_ERROR_OK)
        return error;

    record->checkSum = UTILS_CalcTableChecksum(tableData, tableSize);
    record->length = (ULONG)tableSize;
    record->offset = (ULONG)STREAM_streamPos(stream);

    STREAM_writeChunk(stream, tableData, (tableSize + 3) & ~3);
    free(tableData);

    return LF_ERROR_OK;
}

LF_ERROR CBDT_freeTable(LF_FONT* lfFont)
{
    cbdt_table* table = (cbdt_table*)map_at(&lfFont->table_map, (void*)TAG_CBDT);

    return EBDT_internalFree(table);
}
