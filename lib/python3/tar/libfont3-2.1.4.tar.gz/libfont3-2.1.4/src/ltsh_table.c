// Copyright (C) 2014 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// ltsh_table.c

#include <stdlib.h>
#include "ltsh_table.h"
#include "utils.h"
#include "maxp_table.h"
#include "table_tags.h"

#define LTSH_INVALID_GLYPH      0x8000

#define LTSH_isValid(w) (((w) & LTSH_INVALID_GLYPH) ? LF_INVALID_TYPE : LF_ERROR_OK)


LF_ERROR LTSH_readTable(LF_FONT* lfFont, const sfnt_table_record* record, LF_STREAM* stream)
{
    if(STREAM_streamSeek(stream, record->offset) == 0)
    {
        USHORT numGlyphs;
        LF_ERROR err;
        LONG i;
        ltsh_table* table;

        table = (ltsh_table *)malloc(sizeof(ltsh_table));
        if(table == NULL)
            return LF_OUT_OF_MEMORY;

        // read the header
        table->version            = STREAM_readUShort(stream);
        table->numGlyphs          = STREAM_readUShort(stream);
        numGlyphs = table->numGlyphs;

        err = vector_init(&table->yPels, table->numGlyphs, 1);
        if(err != LF_ERROR_OK)
        {
            free(table);
            return err;
        }

        for (i = 0; i < numGlyphs; i++)
        {
            BYTE yPel = STREAM_readByte(stream);

            vector_push_back(&table->yPels, (void*)(intptr_t)yPel);
        }

        map_insert(&lfFont->table_map, (void*)(intptr_t)record->tag, table);

        return LF_ERROR_OK;
    }

    return LF_INVALID_OFFSET;
}

static USHORT LTSH_GetNumGlyphs(ltsh_table* table)
{
    return table->numGlyphs;
}

static void LTSH_calcTableSize(ltsh_table* table, size_t* tableSize)
{
    *tableSize = 0;
    *tableSize += 4; /* 2 + 2 (version, numGlyphs) */
    *tableSize += table->numGlyphs;
}

LF_ERROR LTSH_getTableSize(LF_FONT* lfFont, size_t* tableSize)
{
    *tableSize = 0;

    ltsh_table* table = (ltsh_table*)map_at(&lfFont->table_map, (void*)TAG_LTSH);
    if (table == NULL)
        return LF_BAD_FORMAT;

    LTSH_calcTableSize(table, tableSize);

    return LF_ERROR_OK;
}

static BYTE* LTSH_buildTable(ltsh_table* table, size_t* tableSize)
{
    BYTE* tableData;
    LF_STREAM stream;

    // calculate table size
    LTSH_calcTableSize(table, tableSize);

    size_t paddedSize = *tableSize;
    tableData = UTILS_AllocTable(&paddedSize);
    if(tableData == NULL)
    {
        DEBUG_LOG_ERROR("allocation failure in LTSH_buildTable");
        return NULL;
    }

    STREAM_initMemStream(&stream, tableData, paddedSize);

    // write header
    STREAM_writeUShort(&stream, table->version);
    STREAM_writeShort(&stream, table->numGlyphs);

    // write yPels
    for (size_t i = 0; i < table->yPels.count; i++)
    {
        ULONG value = (ULONG)(intptr_t)vector_at(&table->yPels, i);

        BYTE yPel = (BYTE)value;

        if (yPel != LTSH_MARK_REMOVED)
        {
            STREAM_writeByte(&stream, yPel);
        }
    }

    return tableData;
}

LF_ERROR LTSH_writeTable(LF_FONT* lfFont, sfnt_table_record* record, LF_STREAM* stream)
{
    USHORT numGlyphs, numMAXPGlyphs;
    ltsh_table* table = (ltsh_table*)map_at(&lfFont->table_map, (void*)TAG_LTSH);
    size_t tableSize;
    BYTE* tableData;

    numGlyphs = LTSH_GetNumGlyphs(table);
    numMAXPGlyphs = MAXP_getNumGlyphs(lfFont);

    if(numGlyphs != numMAXPGlyphs)
    {
        DEBUG_LOG_ERROR("in LTSH_writeTable - mismatch between MAXP and LTSH info");
    }

    tableData = LTSH_buildTable(table, &tableSize);
    if(tableData == NULL)
        return LF_OUT_OF_MEMORY;

    record->checkSum = UTILS_CalcTableChecksum(tableData, tableSize);
    record->length = (ULONG)tableSize;
    record->offset = (ULONG)STREAM_streamPos(stream);

    STREAM_writeChunk(stream, tableData, (tableSize + 3) & ~3);
    free(tableData);

    return LF_ERROR_OK;
}

LF_ERROR LTSH_removeGlyph(LF_FONT* lfFont, ULONG index)
{
    ltsh_table* table = (ltsh_table*)map_at(&lfFont->table_map, (void*)TAG_LTSH);

    if(table == NULL)
        return LF_EMPTY_TABLE;

    ULONG yPel = (ULONG)(intptr_t)vector_at(&table->yPels, index);
    if (yPel == 0)
        return LF_INVALID_INDEX;

    if (yPel != LTSH_MARK_REMOVED)
    {
        vector_set_data(&table->yPels, index, (void*)LTSH_MARK_REMOVED);
        table->numGlyphs--;
    }

    return LF_ERROR_OK;
}

LF_ERROR LTSH_freeTable(LF_FONT* lfFont)
{
    ltsh_table* table = (ltsh_table*)map_at(&lfFont->table_map, (void*)TAG_LTSH);

    if(table != NULL)
    {
        vector_delete(&table->yPels);
        free(table);
    }

    return LF_ERROR_OK;
}
