// Copyright (C) 2014, 2015 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// hhea_table.c

#include "hhea_table.h"
#include "utils.h"

FWORD HHEA_getAscender(LF_FONT* lfFont)
{
    hhea_table* table = (hhea_table*)map_at(&lfFont->table_map, (void*)TAG_HHEA);
    return (table != NULL) ? table->Ascender : 0;
}

void HHEA_setAscender(LF_FONT* lfFont, FWORD ascender)
{
    hhea_table* table = (hhea_table*)map_at(&lfFont->table_map, (void*)TAG_HHEA);
    if (table)
        table->Ascender = ascender;
}

FWORD HHEA_getDescender(LF_FONT* lfFont)
{
    hhea_table* table = (hhea_table*)map_at(&lfFont->table_map, (void*)TAG_HHEA);
    return (table != NULL) ? table->Descender : 0;
}

void HHEA_setDescender(LF_FONT* lfFont, FWORD descender)
{
    hhea_table* table = (hhea_table*)map_at(&lfFont->table_map, (void*)TAG_HHEA);
    if (table)
        table->Descender = descender;
}

FWORD HHEA_getLineGap(LF_FONT* lfFont)
{
    hhea_table* table = (hhea_table*)map_at(&lfFont->table_map, (void*)TAG_HHEA);
    return (table != NULL) ? table->LineGap : 0;
}

void HHEA_setLineGap(LF_FONT* lfFont, FWORD linegap)
{
    hhea_table* table = (hhea_table*)map_at(&lfFont->table_map, (void*)TAG_HHEA);
    if (table)
        table->LineGap = linegap;
}

USHORT HHEA_getNumHMetrics(LF_FONT* lfFont)
{
    hhea_table* table = (hhea_table*)map_at(&lfFont->table_map, (void*)TAG_HHEA);
    return (table != NULL) ? table->numberOfHMetrics : 0;
}

void HHEA_setNumHMetrics(LF_FONT* lfFont, USHORT numHMetrics)
{
    hhea_table* table = (hhea_table*)map_at(&lfFont->table_map, (void*)TAG_HHEA);
    if (table)
        table->numberOfHMetrics = numHMetrics;
}

void HHEA_setAdvanceWidthMax(LF_FONT* lfFont, UFWORD advanceWidthMax)
{
    hhea_table* table = (hhea_table*)map_at(&lfFont->table_map, (void*)TAG_HHEA);
    if (table)
        table->advanceWidthMax = advanceWidthMax;
}

void HHEA_setLeftSidebearingMin(LF_FONT* lfFont, UFWORD leftSidebearingMin)
{
    hhea_table* table = (hhea_table*)map_at(&lfFont->table_map, (void*)TAG_HHEA);
    if (table)
        table->minLeftSideBearing = leftSidebearingMin;
}

void HHEA_setRightSidebearingMin(LF_FONT* lfFont, UFWORD rightSidebearingMin)
{
    hhea_table* table = (hhea_table*)map_at(&lfFont->table_map, (void*)TAG_HHEA);
    if (table)
        table->minRightSideBearing = rightSidebearingMin;
}

void HHEA_setXMaxExtent(LF_FONT* lfFont, SHORT xMaxExtent)
{
    hhea_table* table = (hhea_table*)map_at(&lfFont->table_map, (void*)TAG_HHEA);
    if (table)
        table->xMaxExtent = xMaxExtent;
}

LF_ERROR HHEA_readTable(LF_FONT* lfFont, const sfnt_table_record* record, LF_STREAM* stream)
{
    if(STREAM_streamSeek(stream, record->offset) == 0)
    {
        hhea_table* table = (hhea_table*)malloc(sizeof(hhea_table));

        if(table == NULL)
            return LF_OUT_OF_MEMORY;

        table->version = STREAM_readFixed(stream);
        table->Ascender = STREAM_readFWord(stream);
        table->Descender = STREAM_readFWord(stream);
        table->LineGap = STREAM_readFWord(stream);
        table->advanceWidthMax = STREAM_readUFWord(stream);
        table->minLeftSideBearing = STREAM_readFWord(stream);
        table->minRightSideBearing = STREAM_readFWord(stream);
        table->xMaxExtent = STREAM_readFWord(stream);
        table->caretSlopeRise = STREAM_readShort(stream);
        table->caretSlopeRun = STREAM_readShort(stream);
        table->caretOffset = STREAM_readShort(stream);
        table->reserved1 = STREAM_readShort(stream);
        table->reserved2 = STREAM_readShort(stream);
        table->reserved3 = STREAM_readShort(stream);
        table->reserved4 = STREAM_readShort(stream);
        table->metricDataFormat = STREAM_readShort(stream);
        table->numberOfHMetrics = STREAM_readUShort(stream);

        map_insert(&lfFont->table_map, (void*)(intptr_t)record->tag, table);

        return LF_ERROR_OK;
    }

    return LF_INVALID_OFFSET;
}

LF_ERROR HHEA_getTableSize(LF_FONT* lfFont, size_t *tableSize)
{
    (void)lfFont;
    *tableSize = HHEA_TABLE_SIZE;
    return LF_ERROR_OK;
}

/*
@desc:
write the table to the stream.

@param:
stream      :   pointer to the stream
table       :   pointer to the HHEA table.
*/
static void hhea_writeTable(LF_STREAM* stream, const hhea_table* table)
{
    STREAM_writeFixed(stream, table->version);
    STREAM_writeFWord(stream, table->Ascender);
    STREAM_writeFWord(stream, table->Descender);
    STREAM_writeFWord(stream, table->LineGap);
    STREAM_writeUFWord(stream, table->advanceWidthMax);
    STREAM_writeFWord(stream, table->minLeftSideBearing);
    STREAM_writeFWord(stream, table->minRightSideBearing);
    STREAM_writeFWord(stream, table->xMaxExtent);
    STREAM_writeShort(stream, table->caretSlopeRise);
    STREAM_writeShort(stream, table->caretSlopeRun);
    STREAM_writeShort(stream, table->caretOffset);
    STREAM_writeShort(stream, 0);
    STREAM_writeShort(stream, 0);
    STREAM_writeShort(stream, 0);
    STREAM_writeShort(stream, 0);
    STREAM_writeShort(stream, table->metricDataFormat);
    STREAM_writeUShort(stream, table->numberOfHMetrics);
}

LF_ERROR HHEA_writeTable(LF_FONT* lfFont, sfnt_table_record* record, LF_STREAM* stream)
{
    hhea_table* table = (hhea_table*)map_at(&lfFont->table_map, (void*)TAG_HHEA);
    if (table == NULL)
        return LF_BAD_FORMAT;

    size_t padLen = HHEA_TABLE_SIZE;
    BYTE* padTable = UTILS_AllocTable(&padLen);
    if (padTable == NULL)
        return LF_OUT_OF_MEMORY;

    LF_STREAM localStream;
    STREAM_initMemStream(&localStream, padTable, padLen);
    hhea_writeTable(&localStream, table);

    record->checkSum = UTILS_CalcTableChecksum(padTable, HHEA_TABLE_SIZE);
    record->length = HHEA_TABLE_SIZE;
    record->offset = (ULONG)STREAM_streamPos(stream);

    STREAM_streamSeek(stream, record->offset);
    STREAM_writeChunk(stream, padTable, padLen);
    free(padTable);

    return LF_ERROR_OK;
}


/* ----------------------------------------------------------------------------
@desc:
overwrite the original stream data with the new table.

@param:
stream      :   pointer to the stream
table       :   pointer to the HHEA table.
---------------------------------------------------------------------------- */
LF_ERROR HHEA_overwriteTable(LF_FONT* lfFont, sfnt_table_record* record, LF_STREAM* stream)
{
    hhea_table* table = (hhea_table*)map_at(&lfFont->table_map, (void*)TAG_HHEA);
    if (table == NULL)
        return LF_BAD_FORMAT;

    STREAM_streamSeek(stream, record->offset);
    hhea_writeTable(stream, table);

    STREAM_streamSeek(stream, record->offset);

    record->checkSum = UTILS_CalcTableChecksum(stream->Current, HHEA_TABLE_SIZE);

    return LF_ERROR_OK;
}

LF_ERROR HHEA_freeTable(LF_FONT* lfFont)
{
    hhea_table* table = (hhea_table*)map_at(&lfFont->table_map, (void*)TAG_HHEA);
    free(table);
    return LF_ERROR_OK;
}
