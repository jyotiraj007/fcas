// Copyright (C) 2014, 2016 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// gpos_marktobase.c

#include <stdlib.h>
#include "gpos_lookup/gpos_marktobase.h"
#include "anchor.h"
#include "mark_array.h"

#ifdef LF_OT_DUMP
#include "utils.h"
static LF_ERROR dumpBaseArray(gpos_marktobase* table);
static LF_ERROR dumpMarkArray(gpos_marktobase* table);
#endif

static LF_ERROR GPOS_readBaseArray(gpos_marktobase* table, LF_STREAM* stream)
{
    size_t tableStart = STREAM_streamPos(stream);
    size_t currPos;
    USHORT baseCount = STREAM_readUShort(stream);
    USHORT i, j = 0;

    LF_ERROR error = vector_init(&table->BaseArray, baseCount, 4);
    if (error != LF_ERROR_OK)
        return error;

    for(i = 0; i < baseCount; i ++)
    {
        LF_VECTOR* baseRecord = vector_create(table->ClassCount, 4);
        if (baseRecord == NULL)
        {
            return LF_OUT_OF_MEMORY;
        }

        for(j = 0; j < table->ClassCount; j++)
        {
            OFFSET anchorOffset = STREAM_readOffset(stream);

            // Only want to read in the anchor table if there is a valid offset
            // otherwise insert an empty (NULL) table into our list
            if (anchorOffset)
            {
                anchor_table* anchorTable = (anchor_table*)malloc(sizeof(anchor_table));

                if (anchorTable == NULL)
                {
                    vector_free(baseRecord);
                    free(baseRecord);
                    return LF_OUT_OF_MEMORY;
                }

                currPos = STREAM_streamPos(stream);
                STREAM_streamSeek(stream, tableStart + anchorOffset);
                error = Anchor_readTable(anchorTable, stream);
                if (error != LF_ERROR_OK)
                {
                    free(anchorTable);
                    for (USHORT k = 0; k < baseRecord->count; k++)
                    {
                        anchorTable = (anchor_table*)vector_at(baseRecord, k);
                        if (anchorTable != NULL)
                        {
                            Anchor_freeTable(anchorTable);
                            free(anchorTable);
                        }
                    }
                    vector_free(baseRecord);
                    free(baseRecord);

                    return error;
                }

                vector_push_back(baseRecord, anchorTable);
                STREAM_streamSeek(stream, currPos);
            }
            else
            {
                vector_push_back(baseRecord, NULL);
            }
        }

        vector_push_back(&table->BaseArray, baseRecord);
    }

    return LF_ERROR_OK;
}

TABLE_HANDLE GPOS_readMarkToBase(LF_STREAM* stream)
{
    gpos_marktobase* table = (gpos_marktobase*)calloc(1, sizeof(gpos_marktobase));
    size_t tableStart = STREAM_streamPos(stream);
    size_t oldOffset;
    size_t coverageOffset;
    size_t markOffset;
    size_t baseOffset;
    LF_ERROR error;

    if(table == NULL)
        return NULL;

    table->PosFormat = STREAM_readUShort(stream);

    //read mark coverage
    coverageOffset = STREAM_readOffset(stream);
    oldOffset = STREAM_streamPos(stream);
    STREAM_streamSeek(stream, tableStart + coverageOffset);
    Coverage_readTable(&table->MarkCoverage, stream);
    STREAM_streamSeek(stream, oldOffset);

    //read base coverage
    coverageOffset = STREAM_readOffset(stream);
    oldOffset = STREAM_streamPos(stream);
    STREAM_streamSeek(stream, tableStart + coverageOffset);
    Coverage_readTable(&table->BaseCoverage, stream);
    STREAM_streamSeek(stream, oldOffset);

    table->ClassCount = STREAM_readUShort(stream);
    markOffset = STREAM_readOffset(stream);
    baseOffset = STREAM_readOffset(stream);

    STREAM_streamSeek(stream, tableStart + markOffset);
    Mark_readArray(&table->MarkArray, stream);

    //read BaseArray table
    STREAM_streamSeek(stream, tableStart + baseOffset);
    error = GPOS_readBaseArray(table, stream);
    if (error != LF_ERROR_OK)
    {
        GPOS_freeMarkToBase(table);
        table = NULL;
    }

    return table;
}

size_t GPOS_getMarkToBaseSize(gpos_marktobase* table)
{
    size_t tableSize = sizeof(USHORT) * 2 + sizeof(OFFSET) * 4;
    size_t markSize = 0;
    size_t baseSize = 0;
    ULONG i, j = 0;

    Coverage_getTableSize(&table->MarkCoverage, &markSize);
    Coverage_getTableSize(&table->BaseCoverage, &baseSize);
    tableSize += markSize + baseSize;

    Mark_getArraySize(&table->MarkArray, &markSize);
    baseSize = sizeof(USHORT);

    for(i = 0; i < table->BaseArray.count; i++)
    {
        LF_VECTOR* baseRecord = (LF_VECTOR*)vector_at(&table->BaseArray, i);

        for(j = 0; j < baseRecord->count; j++)
        {
            size_t anchorSize = 0;
            anchor_table* at = (anchor_table*)vector_at(baseRecord, j);
            if (at)
                Anchor_getTableSize(at, &anchorSize);
            baseSize += anchorSize + sizeof(OFFSET);
        }
    }

    tableSize += markSize + baseSize;

    //tableSize = (tableSize + 3) & ~3;
    return tableSize;
}

static LF_ERROR GPOS_buildBaseArray(gpos_marktobase* table, LF_STREAM* stream)
{
    size_t baseStart = STREAM_streamPos(stream);
    size_t currPos;
    size_t baseEnd = baseStart + sizeof(USHORT) + sizeof(OFFSET) * table->BaseArray.count * table->ClassCount;
    ULONG i, j = 0;

    STREAM_writeUShort(stream, (USHORT)table->BaseArray.count);

    for(i = 0; i < table->BaseArray.count; i++)
    {
        LF_VECTOR* baseRecord = (LF_VECTOR*)vector_at(&table->BaseArray, i);

        for(j = 0; j < baseRecord->count; j++)
        {
            anchor_table* anchor = (anchor_table*)vector_at(baseRecord, j);

            if (anchor != NULL)
                STREAM_writeOffset(stream, (ULONG)(baseEnd - baseStart));
            else
                STREAM_writeOffset(stream, 0);

            currPos = STREAM_streamPos(stream);
            STREAM_streamSeek(stream, baseEnd);

            if (anchor != NULL)
                Anchor_buildTable(anchor, stream);

            baseEnd = STREAM_streamPos(stream);                        // Save off table write position
            STREAM_streamSeek(stream, currPos);
        }
    }
    STREAM_streamSeek(stream, baseEnd);                // Restore end of table position for calling routine
    return LF_ERROR_OK;
}

size_t GPOS_buildMarkToBase(gpos_marktobase* table, LF_STREAM* stream)
{
    size_t tableStart = STREAM_streamPos(stream);
    size_t currPos;
    size_t endPos = sizeof(USHORT) * 2 + sizeof(OFFSET) * 4;

    STREAM_writeUShort(stream, table->PosFormat);

    //write mark coverage table
    STREAM_writeOffset(stream, (OFFSET)endPos);
    currPos = STREAM_streamPos(stream);
    STREAM_streamSeek(stream, tableStart + endPos);
    Coverage_buildTable(&table->MarkCoverage, stream);
    endPos = STREAM_streamPos(stream) - tableStart;

    //write base coverage table
    STREAM_streamSeek(stream, currPos);
    STREAM_writeOffset(stream, (OFFSET)endPos);
    currPos = STREAM_streamPos(stream);
    STREAM_streamSeek(stream, tableStart + endPos);
    Coverage_buildTable(&table->BaseCoverage, stream);
    endPos = STREAM_streamPos(stream) - tableStart;

    STREAM_streamSeek(stream, currPos);
    STREAM_writeUShort(stream, table->ClassCount);

    //write mark array
    STREAM_writeOffset(stream, (OFFSET)endPos);
    currPos = STREAM_streamPos(stream);
    STREAM_streamSeek(stream, tableStart + endPos);
    Mark_buildArray(&table->MarkArray, stream);
    endPos = STREAM_streamPos(stream) - tableStart;

    //write base array table
    STREAM_streamSeek(stream, currPos);
    STREAM_writeOffset(stream, (OFFSET)endPos);
    STREAM_streamSeek(stream, tableStart + endPos);
    GPOS_buildBaseArray(table, stream);

    return STREAM_streamPos(stream) - tableStart;
}

LF_ERROR GPOS_markToBaseRemoveGlyph(gpos_marktobase* table, GlyphID glyphID)
{
    ULONG index,i;
    LF_ERROR error = Coverage_removeGlyphIndex(&table->MarkCoverage, glyphID, &index);


    // if MarkCoverage is empty, we are done ...
    if (error == LF_EMPTY_TABLE)
        return error;

    if(error == LF_ERROR_OK)
    {
        error = Mark_removeAtIndex(&table->MarkArray, index);
    }

    error = Coverage_removeGlyphIndex(&table->BaseCoverage, glyphID, &index);

    if(error == LF_ERROR_OK)
    {
        // Retrieve the base record and free up all of its anchor tables.  One per class
        LF_VECTOR* baseRecord = (LF_VECTOR*)vector_at(&table->BaseArray, index);
        i = 0;

        while (i < baseRecord->count)
        {
            anchor_table* anchorTable = (anchor_table*)(baseRecord->vector_array[i++]);

            if (anchorTable != NULL)
            {
                Anchor_freeTable(anchorTable);
                free(anchorTable);
            }
        }

        vector_delete(baseRecord);
        free(baseRecord);

        error = vector_erase(&table->BaseArray, index);
    }

    return error;
}

LF_ERROR GPOS_markToBaseRemapTable(gpos_marktobase* table, LF_MAP *remap)
{
    LF_ERROR error = Coverage_remapAll(&table->MarkCoverage, remap);

    if((error == LF_ERROR_OK) || (error == LF_EMPTY_TABLE))
    {
        error = Coverage_remapAll(&table->BaseCoverage, remap);
    }

    return error;
}

LF_ERROR GPOS_markToBaseSetAnchorFmt1(gpos_marktobase* table)
{
    for (size_t i = 0; i < table->BaseArray.count; i++)
    {
        LF_VECTOR* baseRecord = (LF_VECTOR*)vector_at(&table->BaseArray, i);

        for (size_t j = 0; j < baseRecord->count; j++)
        {
            anchor_table* anchor = (anchor_table*)vector_at(baseRecord, j);

            if (anchor != NULL && anchor->AnchorFormat == 2)
                anchor->AnchorFormat = 1;
        }
    }

    return Mark_setAnchorFormat1(&table->MarkArray);
}

/* ============================================================================
    @desc
        free up the mark to base memory resources from the system

    @param
        table = pointer to the table.

============================================================================ */
void GPOS_freeMarkToBase(gpos_marktobase* table)
{
    ULONG i = 0;
    Coverage_deleteTable(&table->BaseCoverage);
    Coverage_deleteTable(&table->MarkCoverage);

    Mark_freeArray(&table->MarkArray);

    while(i < table->BaseArray.count)
    {
        LF_VECTOR* anchorTables = (LF_VECTOR*)vector_at(&table->BaseArray, i++);
        ULONG j = 0;

        while (j < anchorTables->count)
        {
            anchor_table* anchorTable = (anchor_table*)vector_at(anchorTables, j++);
            if (anchorTable != NULL)
            {
                Anchor_freeTable(anchorTable);
                free(anchorTable);
            }
        }
        vector_delete(anchorTables);
        free(anchorTables);
    }

    vector_delete(&table->BaseArray);
    free(table);
}

#ifdef LF_OT_DUMP
LF_ERROR GPOS_dumpMarkToBase(gpos_marktobase* table)
{
    XML_START("GPOSMarkToBase");
    XML_DATA_NODE("PosFormat", table->PosFormat);
    XML_DATA_NODE("ClassCount", table->ClassCount);

    XML_START("BaseCoverage");
    Coverage_dumpTable(&table->BaseCoverage);
    XML_END("BaseCoverage");

    XML_START("MarkCoverage");
    Coverage_dumpTable(&table->MarkCoverage);
    XML_END("MarkCoverage");

    dumpMarkArray(table);
    dumpBaseArray(table);

    XML_END("GPOSMarkToBase");
    return LF_ERROR_OK;
}

static LF_ERROR dumpMarkArray(gpos_marktobase* table)
{
    return Mark_dumpArray(&table->MarkArray);
}

static LF_ERROR dumpBaseArray(gpos_marktobase* table)
{
    ULONG i = 0, j = 0;
    XML_START("GPOSBaseArray");

    XML_DATA_NODE("BaseCount", (int)table->BaseArray.count);

    XML_START("BaseArray");
    for (i = 0; i < table->BaseArray.count; i++)
    {
        LF_VECTOR* baseRecord = (LF_VECTOR*)vector_at(&table->BaseArray, i);

        for (j = 0; j < baseRecord->count; j++)
        {
            Anchor_dumpTable((anchor_table*)vector_at(baseRecord, j));
        }
    }
    XML_END("BaseArray");
    XML_END("GPOSBaseArray");

    return LF_ERROR_OK;
}
#endif
