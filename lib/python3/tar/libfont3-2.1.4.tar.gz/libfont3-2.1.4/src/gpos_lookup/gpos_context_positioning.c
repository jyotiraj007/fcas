// Copyright (C) 2014 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// gpos_context_positioning.c

#include "utils.h"
#include "gpos_lookup/gpos_context_positioning.h"
#include "common_table.h"


static LF_ERROR    contextPos_readFormat1(gpos_context_position_f1* cpf1, LF_STREAM* stream);
static size_t      contextPos_buildFormat1(gpos_context_position_f1* cpf1, LF_STREAM* stream);
static size_t      contextPos_sizeFormat1(gpos_context_position_f1* cpf1);
static void        contextPos_freeFormat1(gpos_context_position_f1* cpf1);
static LF_ERROR    contextPos_removeFormat1(gpos_context_position_f1* cpf1, GlyphID glyphid);
static LF_ERROR    contextPos_pruneLookupRecordsFormat1(gpos_context_position_f1* cpf1);
#ifdef LF_OT_DUMP
static void        contextPos_dumpFormat1(gpos_context_position_f1* cpf1);
#endif
static LF_ERROR    contextSubst_cleanupLookupsFormat1(gpos_context_position_f1* cpf1, TABLE_HANDLE hLookup);


static LF_ERROR    contextPos_readFormat2(gpos_context_position_f2* cpf2, LF_STREAM* stream);
static size_t      contextPos_buildFormat2(gpos_context_position_f2* cpf2, LF_STREAM* stream);
static size_t      contextPos_sizeFormat2(gpos_context_position_f2* cpf2);
static void        contextPos_freeFormat2(gpos_context_position_f2* cpf2);
static LF_ERROR    contextPos_removeFormat2(gpos_context_position_f2* cpf2, GlyphID glyphid);
static LF_ERROR    contextPos_pruneLookupRecordsFormat2(gpos_context_position_f2* cpf2);
static LF_ERROR    contextPos_removeLookupIndexFormat2(gpos_context_position_f2* f2, USHORT lookupIndex, SHORT deltaIndex);
//static void        contextPos_dumpFormat2(gpos_context_position_f2* cpf2);
static LF_ERROR    contextSubst_cleanupLookupsFormat2(gpos_context_position_f2* cpf2, TABLE_HANDLE hLookup);

static LF_ERROR    contextPos_readFormat3(gpos_context_position_f3* cpf3, LF_STREAM* stream);
static size_t      contextPos_buildFormat3(gpos_context_position_f3* cpf3, LF_STREAM* stream);
static size_t      contextPos_sizeFormat3(gpos_context_position_f3* cpf3);
static void        contextPos_freeFormat3(gpos_context_position_f3* cpf3);
static LF_ERROR    contextPos_removeFormat3(gpos_context_position_f3* cpf3, GlyphID glyphid);
static LF_ERROR    contextPos_pruneLookupRecordsFormat3(gpos_context_position_f3* cpf3);
static LF_ERROR    contextSubst_cleanupLookupsFormat3(gpos_context_position_f3* cpf3, TABLE_HANDLE hLookup);



TABLE_HANDLE GPOS_readContextPositioning(LF_STREAM* stream)
{
    gpos_context_positioning*    cp;
    LF_ERROR                     error;

    ASSERT(stream);

    cp = (gpos_context_positioning*)calloc(1, sizeof(gpos_context_positioning));
    if (!cp)
    {
        DEBUG_LOG_ERROR("unable to allocate GPOS Context Positioning structure");
        return NULL;
    }

    cp->PosFormat = STREAM_readUShort(stream);                            // stream format ...

    switch (cp->PosFormat)
    {
    case 1:        error = contextPos_readFormat1(&cp->csf.cpf1, stream);        break;
    case 2:        error = contextPos_readFormat2(&cp->csf.cpf2, stream);        break;
    case 3:        error = contextPos_readFormat3(&cp->csf.cpf3, stream);        break;
    default:       error = LF_BAD_FORMAT;                                        break;
    }

    if (error != LF_ERROR_OK)
    {
        DEBUG_LOG_VALUE("GPOS context failed to read format ", cp->PosFormat);
        FREE(cp);
    }

    return (TABLE_HANDLE)cp;
}

LF_ERROR GPOS_removeContextPositioningGlyphIndex(gpos_context_positioning* cp, GlyphID glyphid)
{
    LF_ERROR error = LF_ERROR_OK;

    switch (cp->PosFormat)
    {
    case 1:    error = contextPos_removeFormat1(&cp->csf.cpf1, glyphid);    break;
    case 2:    error = contextPos_removeFormat2(&cp->csf.cpf2, glyphid);    break;
    case 3:    error = contextPos_removeFormat3(&cp->csf.cpf3, glyphid);    break;
    default:   error = LF_BAD_FORMAT;                                       break;
    }

    return error;
}

size_t GPOS_buildContextPositioning(gpos_context_positioning* cp, LF_STREAM* stream)
{
    size_t ret;

    ASSERT(cp);
    ASSERT(stream);

    STREAM_writeUShort(stream, cp->PosFormat);                    // PosFormat

    switch (cp->PosFormat)
    {
    case 1:        ret = contextPos_buildFormat1(&cp->csf.cpf1, stream);    break;
    case 2:        ret = contextPos_buildFormat2(&cp->csf.cpf2, stream);    break;
    case 3:        ret = contextPos_buildFormat3(&cp->csf.cpf3, stream);    break;
    default:       ret = (size_t)-1;                                        break;
    }

    return ret;
}

size_t GPOS_sizeContextPositioning(gpos_context_positioning* cp)
{
    size_t size;
    ASSERT(cp);

    size = sizeof(USHORT);                            // PosFormat

    switch (cp->PosFormat)
    {
    case 1:        size += contextPos_sizeFormat1(&cp->csf.cpf1);        break;
    case 2:        size += contextPos_sizeFormat2(&cp->csf.cpf2);        break;
    case 3:        size += contextPos_sizeFormat3(&cp->csf.cpf3);        break;
    default:       size = 0;                                             break;
    }
    return size;
}

void GPOS_freeContextPositioning(gpos_context_positioning* cp)
{
    ASSERT(cp);

    switch (cp->PosFormat)
    {
    case 1:        contextPos_freeFormat1(&cp->csf.cpf1);        break;
    case 2:        contextPos_freeFormat2(&cp->csf.cpf2);        break;
    case 3:        contextPos_freeFormat3(&cp->csf.cpf3);        break;
    default:                                                     break;
    }

    FREE(cp);
}


/* ****************************************************************************

    FORMAT 1

**************************************************************************** */
static LF_ERROR contextPos_readFormat1(gpos_context_position_f1* cpf1, LF_STREAM* stream)
{
    LF_ERROR    error;
    size_t      curOffset, newOffset, baseOffset;

    ASSERT(cpf1);

    baseOffset    = STREAM_streamPos(stream) - 2L;
    newOffset = STREAM_readUShort(stream) + baseOffset;              // Coverage Offset
    curOffset = STREAM_streamPos(stream);                            // current stream position

    STREAM_streamSeek(stream, newOffset);                            // Seek Coverage in Stream
    error = Coverage_readTable(&cpf1->Coverage, stream);             // read coverage
    if (error != LF_ERROR_OK)
    {
        if (error != LF_EMPTY_TABLE)
        {
            contextPos_freeFormat1(cpf1);
            return error;
        }
    }

    STREAM_streamSeek(stream, curOffset);

    // create the PosRuleSet[] array
    cpf1->PosRuleSetCount = STREAM_readUShort(stream);                // How many sub rule sets are there?
    vector_init(&cpf1->PosRuleSet, cpf1->PosRuleSetCount, sizeof(ULONG));
    error = ContextSet_readRuleSets(&cpf1->PosRuleSet, cpf1->PosRuleSetCount, stream, (ULONG)baseOffset);

    if (error != LF_ERROR_OK)
        contextPos_freeFormat1(cpf1);

    return error;
}

static size_t contextPos_buildFormat1(gpos_context_position_f1* cpf1, LF_STREAM* stream)
{
    size_t baseOffset = STREAM_streamPos(stream) - 2L;  /* Minus 2 since we've already grabbed the format earlier */
    size_t coverageOffset;
    size_t setOffset;
    size_t curOffset = 0;
    size_t offset = 0;
    USHORT n, count, subruleSetCount;
    size_t coverageCount;
    size_t SubRuleSetOffset;

    ASSERT(cpf1);

    coverageOffset = STREAM_streamPos(stream);
    STREAM_writeOffset(stream, 0);

    subruleSetCount = UTILS_getCount(&cpf1->PosRuleSet);
    STREAM_writeUShort(stream, subruleSetCount);
    SubRuleSetOffset = STREAM_streamPos(stream);
    (void)SubRuleSetOffset; //not used

    /*
     *    Lets do some sanity checks!
     *
     *    Number of SubRuleSet tables-must equal GlyphCount
     *    in Coverage Table.
     */
    coverageCount = Coverage_getCoverageCount(&cpf1->Coverage);
    ASSERT(coverageCount == subruleSetCount);
    if (coverageCount != subruleSetCount)
    {
        // TODO: LOG an error in the file ...
        DEBUG_LOG_ERROR("coverage glyph count mismatch with PosRuleSet count");
        DEBUG_LOG_VALUE("coverage table count ", (int)coverageCount);
        DEBUG_LOG_VALUE("PosRuleSet count ", subruleSetCount);
        STREAM_streamSeek(stream, baseOffset);            // reset the stream
        return 0;
    }

    count = subruleSetCount;

    // write all of the Offsets into the sub-rule set offset array
    setOffset = STREAM_streamPos(stream);                    // save set OFFSET in the stream, so we get back to it.
    for ( n = 0; n < count; n++)
    {
        STREAM_writeOffset(stream, 0);
    }

    // write all of the Offsets into the sub-rule set offset array
    for ( n = 0; n < count; n++)
    {
        context_rule_set* prs = (context_rule_set*)vector_at(&cpf1->PosRuleSet, n);
        curOffset = STREAM_streamPos(stream);                // get our current stream position
        offset = curOffset - baseOffset;                     // calculate the offset
        STREAM_streamSeek(stream, setOffset);                // seek out the set offset table

        STREAM_writeOffset(stream, (USHORT)offset);          // write the offset into the set offset
        setOffset += sizeof(OFFSET);                         // increment to the next offset in the array.

        STREAM_streamSeek(stream, curOffset);                // go back to stream current position
        ContextSet_buildRuleSet(prs, stream);
    }

    curOffset = STREAM_streamPos(stream);
    offset = curOffset - baseOffset;
    STREAM_streamSeek(stream, coverageOffset);
    STREAM_writeUShort(stream, (USHORT)offset);
    STREAM_streamSeek(stream, curOffset);

    Coverage_buildTable(&cpf1->Coverage, stream);

    return STREAM_streamPos(stream);
}

static size_t contextPos_sizeFormat1(gpos_context_position_f1* cpf1)
{
    size_t size = 0;

    ASSERT(cpf1);

    Coverage_getTableSize(&cpf1->Coverage, &size);             // Coverage size

    //size += sizeof(USHORT);                                    // PosFormat - already counted earlier
    size += sizeof(OFFSET);                                    // Coverage OFFSET value
    size += sizeof(USHORT);                                    // PosRuleSetCount;

    size += ContextSet_sizeRuleSets(&cpf1->PosRuleSet);        // RuleSets
    size += sizeof(OFFSET) * cpf1->PosRuleSet.count;           // OFFSET array for PosRuleSet[PosRuleSetCount] 

    return size;
}

static void contextPos_freeFormat1(gpos_context_position_f1* cpf1)
{
    ASSERT(cpf1);

    Coverage_deleteTable(&cpf1->Coverage);
    ContextSet_freeRuleSets(&cpf1->PosRuleSet);
    vector_delete(&cpf1->PosRuleSet);
    memset(cpf1, 0, sizeof(gpos_context_position_f1));
}

/* ----------------------------------------------------------------------------
    @description
        remove a glyph from format 1.  This is a glyph based format, so we
        do all of the cleanup here rather than in the last stage of pruning
        because the glyph id reference will be lost once we complete this
        function.

        the optimization is to initially clear the coverage table, and the
        associated PosRuleSet that is associated with the coverage.

        if the coverage isn't affected, we need to go into the each PosRule
        and check the input glyphs.  If any of the glyphs are found in the
        Input array, we can eliminate that Rule because the context cannot
        be satisfied without the glyph being removed.
---------------------------------------------------------------------------- */
static LF_ERROR contextPos_removeFormat1(gpos_context_position_f1* cpf1, GlyphID glyphid)
{
    LF_ERROR error;
    ULONG        coverageIndex;

    ASSERT(cpf1);

    // 1rst stage, remove coverage match ups with the Sub-rule sets.
    error = Coverage_removeGlyphIndex(&cpf1->Coverage, glyphid, &coverageIndex);
    if (error == LF_EMPTY_TABLE)
    {
        // no Coverage, then no rule ...
        return error;
    }

    // According to the rules, The number of SubRuleSet tables-must be 
    // equal to GlyphCount in the Coverage Table.
    if ( error == LF_ERROR_OK )
    {
        // Top level pruning of the rules - match Coverage index to SubRuleSets index.
        // find the SubRuleSet that matches coverage index
        context_rule_set* prs = (context_rule_set*)vector_at(&cpf1->PosRuleSet, coverageIndex);

        ContextSet_freeRuleSet(prs);
        FREE(prs);
        vector_erase(&cpf1->PosRuleSet, coverageIndex);
    }


    // 2nd Stage, now search all SubRuleSets and remove any SubRules
    // that contain the glyph as they are no longer relevant if one
    // of the sequences has been removed.
    error = ContextSet_pruneRuleSets(&cpf1->PosRuleSet, &cpf1->Coverage, glyphid);

    return error;
}

static LF_ERROR contextPos_remapTableFormat1(gpos_context_position_f1* f1, LF_MAP *remap)
{
    LF_ERROR error = Coverage_remapAll(&f1->Coverage, remap);

    if((error == LF_ERROR_OK) || (error == LF_EMPTY_TABLE))
    {
        error = ContextSet_remapRuleSets(&f1->PosRuleSet, remap);
    }

    return error;
}



/* ****************************************************************************
    FORMAT 2

**************************************************************************** */
static LF_ERROR contextPos_readFormat2(gpos_context_position_f2* cpf2, LF_STREAM* stream)
{
    LF_ERROR    error;
    USHORT      count;
    size_t      curOffset, newOffset, baseOffset;
    size_t      classOffset;

    ASSERT(cpf2);
    ASSERT(stream);

    baseOffset = STREAM_streamPos(stream) - 2L;                     // store off base offset (subtract 2 because of substitution format)
    newOffset = STREAM_readUShort(stream) + baseOffset;             // get the coverage offset
    curOffset = STREAM_streamPos(stream);                           // save where we are in stream

    STREAM_streamSeek(stream, newOffset);                           // seek out coverage table in stream
    error = Coverage_readTable(&cpf2->Coverage, stream);            // read coverage
    if (error != LF_ERROR_OK)
    {
        if (error == LF_EMPTY_TABLE)
        {
            DEBUG_LOG_ERROR("GPOS Context - empty CoverageTable");
        }
        else
        {
            DEBUG_LOG_ERROR("GPOS Context failed to read CoverageTable");
            return error;
        }
    }

    STREAM_streamSeek(stream, curOffset);                           // restore stream back to the gpos context format 2 stream

    classOffset = STREAM_readUShort(stream) + baseOffset;           // read in offset to the class definitions

    // subclass count is the upper limit for class values, therefore we
    // read it now to make an addition safety check
    count = STREAM_readUShort(stream);                              // PosClassSetCnt

    curOffset = STREAM_streamPos(stream);
    STREAM_streamSeek(stream, classOffset);

    error = ClassDef_readTable(&cpf2->ClassDef, stream);            // read ClassDef
    if (error != LF_ERROR_OK)
    {
        DEBUG_LOG_ERROR("Failed to read the ClassDef");
        contextPos_freeFormat2(cpf2);
        return error;
    }

    STREAM_streamSeek(stream, curOffset);
    error = ClassSets_readClassSets(&cpf2->PosClassSet, &cpf2->ClassDef, count, stream, (ULONG)baseOffset);
    if (error != LF_ERROR_OK)
    {
        DEBUG_LOG_ERROR("Failed to read ClassSets from stream");
        contextPos_freeFormat2(cpf2);
        return error;
    }

    return LF_ERROR_OK;
}

static size_t contextPos_buildFormat2(gpos_context_position_f2* cpf2, LF_STREAM* stream)
{
    size_t  baseOffset = STREAM_streamPos(stream) - 2L;
    size_t  coverageOffset;
    size_t  curOffset;
    size_t  classdefOffset;
    size_t  offset;
    USHORT  count;

    size_t SubClassSetOffset;

    ASSERT(stream);
    ASSERT(cpf2);

    // Coverage OFFSET
    coverageOffset = STREAM_streamPos(stream);
    STREAM_writeOffset(stream, 0);

    // ClassDef OFFSET
    classdefOffset = STREAM_streamPos(stream);
    STREAM_writeOffset(stream, 0);

    // SubClassSet Count
    count = UTILS_getCount(&cpf2->PosClassSet);
    STREAM_writeUShort(stream, count);

    // SubClassSet OFFSET Array - write out placeholders
    SubClassSetOffset = Common_buildEmptyArray(stream, count);

    /* Stay in the order that the font was read in */
    /* Start by writing out the coverage table */
    curOffset = STREAM_streamPos(stream);
    offset = curOffset - baseOffset;
    STREAM_streamSeek(stream, coverageOffset);
    STREAM_writeUShort(stream, (USHORT)offset);
    STREAM_streamSeek(stream, curOffset);

    Coverage_buildTable(&cpf2->Coverage, stream);

    /* Next write out the Class table */
    curOffset = STREAM_streamPos(stream);
    offset = curOffset - baseOffset;
    STREAM_streamSeek(stream, classdefOffset);
    STREAM_writeUShort(stream, (USHORT)offset);
    STREAM_streamSeek(stream, curOffset);

    ClassDef_buildTable(&cpf2->ClassDef, stream);

    /* now build out the class sets and the OFFSET array */
    ClassSet_buildClassSets(&cpf2->PosClassSet, (LONG)baseOffset, (LONG)SubClassSetOffset, stream);

    return STREAM_streamPos(stream);
}

static size_t contextPos_sizeFormat2(gpos_context_position_f2* cpf2)
{
    size_t      size = 0;
    size_t      coverageSize, classSize;
    USHORT      count, n;
    //LF_ERROR     error;

    ASSERT(cpf2);

    count = UTILS_getCount(&cpf2->PosClassSet);

    size += sizeof(OFFSET);                        // Coverage offset
    size += sizeof(OFFSET);                        // ClassDef offset
    size += sizeof(USHORT);                        // PosClassSetCnt
    size += sizeof(OFFSET) * count;                // Offset Array PosClassSet

    /*error = */Coverage_getTableSize(&cpf2->Coverage, &coverageSize);
    /*error = */ClassDef_getTableSize(&cpf2->ClassDef, &classSize);

    size += coverageSize;
    size += classSize;

    for (n = 0; n < count; n++)
    {
        class_set* set = (class_set*)vector_at(&cpf2->PosClassSet, n);
        size += ClassSet_sizeClassSet(set);
    }

    return size;
}

static void contextPos_freeFormat2(gpos_context_position_f2* cpf2)
{
    ULONG i = 0;
    ASSERT(cpf2);

    Coverage_deleteTable(&cpf2->Coverage);
    ClassDef_freeTable(&cpf2->ClassDef);

    while (i < UTILS_getCount(&cpf2->PosClassSet))
    {
        class_set* set = (class_set*)vector_at(&cpf2->PosClassSet, i++);
        ClassSet_freeClassSet(set);
        FREE(set);
    }
    vector_delete(&cpf2->PosClassSet);
}



/* ----------------------------------------------------------------------------
    @description
        The coverage table lists indices for the complete set of glyphs
        that may appear as the first glyph of any class-based context.  In
        other words, the Coverage table contains the list of glyph indices
        for all the glyphs in all classes that may be first in any of the
        context class sequences.  For example, if the contexts begine with
        a Class 1 or Class 2 glyph, then the coverage table will list the
        indices of all Class 1 and Class 2 glyphs.
---------------------------------------------------------------------------- */
static LF_ERROR contextPos_removeFormat2(gpos_context_position_f2* cpf2, GlyphID glyphid)
{
    LF_ERROR error;
    LF_ERROR coverageStatus;
    ULONG coverageIndex;
    USHORT removeSet = 0;

    // remove from coverage ....
    coverageStatus = Coverage_removeGlyphIndex(&cpf2->Coverage, glyphid, &coverageIndex);
    if (coverageStatus == LF_EMPTY_TABLE)
    {
        // we can remove the entire table if Coverage table is empty
        return coverageStatus;
    }

    error = ClassDef_removeGlyph(&cpf2->ClassDef, glyphid, &removeSet);

    if (error == LF_EMPTY_TABLE && removeSet != 0)
    {
        // we can remove a set from the system
        USHORT count = UTILS_getCount(&cpf2->PosClassSet);

        if (removeSet < count)
        {
            class_set* pcs = (class_set*)vector_at(&cpf2->PosClassSet, removeSet);

            // get rid of the subclass rules
            ClassSet_freeClassSet(pcs);

            // now it is just an empty class rule.
            DEBUG_LOG_VALUE("Removing PosClassSet ", removeSet);
        }
    }
    return error;
}

static LF_ERROR contextPos_remapTableFormat2(gpos_context_position_f2* f2, LF_MAP *remap)
{
    LF_ERROR error = Coverage_remapAll(&f2->Coverage, remap);

    if((error == LF_ERROR_OK) || (error == LF_EMPTY_TABLE))
    {
        error = ClassDef_remapGlyphs(&f2->ClassDef, remap);
    }

    return error;
}



/* ****************************************************************************

    FORMAT 3

**************************************************************************** */
static LF_ERROR    contextPos_readFormat3(gpos_context_position_f3* cpf3, LF_STREAM* stream)
{
    LF_ERROR error;
    USHORT n, glyphCount, posCount;
    size_t baseOffset, curOffset, newOffset;

    ASSERT(cpf3);
    ASSERT(stream);

    baseOffset = STREAM_streamPos(stream) - sizeof(USHORT);        // position - PosFormat (stream already read this in)

    glyphCount = STREAM_readUShort(stream);
    posCount   = STREAM_readUShort(stream);

    vector_init(&cpf3->Coverage, glyphCount, sizeof(ULONG));

    // read in the coverage offsets, and coverage tables
    for (n = 0; n < glyphCount; n++)
    {
        coverage_table* ct = (coverage_table*)malloc(sizeof(coverage_table));
        if (NULL == ct)
        {
            DEBUG_LOG_ERROR("failed to allocate coverage table structure");
            contextPos_freeFormat3(cpf3);
            return LF_OUT_OF_MEMORY;
        }

        newOffset = STREAM_readUShort(stream) + baseOffset;
        curOffset = STREAM_streamPos(stream);
        STREAM_streamSeek(stream, newOffset);

        error = Coverage_readTable(ct, stream);

        if (error != LF_ERROR_OK)
        {
            if (error != LF_EMPTY_TABLE)
            {
                DEBUG_LOG_ERROR("Coverage_readTable failed");
                free(ct);
                contextPos_freeFormat3(cpf3);
                return error;
            }
        }

        vector_push_back(&cpf3->Coverage, ct);

        STREAM_streamSeek(stream, curOffset);
    }

    error = Common_readSubstLookupRecords(&cpf3->PosLookupRecord, posCount, stream);

    return error;
}

static size_t contextPos_buildFormat3(gpos_context_position_f3* cpf3, LF_STREAM* stream)
{
    size_t baseOffset = STREAM_streamPos(stream) - 2L;
    size_t coverageOffset;
    size_t curOffset = 0;
    size_t offset = 0;

    USHORT n, coverageCount, lookupCount;

    ASSERT(stream);
    ASSERT(cpf3);

    coverageCount = UTILS_getCount(&cpf3->Coverage);
    lookupCount = UTILS_getCount(&cpf3->PosLookupRecord);

    STREAM_writeUShort(stream, coverageCount);            // GlyphCount
    STREAM_writeUShort(stream, lookupCount);              // SubstCount

    // Coverage Array of Offset Coverage[GlyphCount]
    coverageOffset = STREAM_streamPos(stream);
    for ( n = 0; n < coverageCount; n++)
    {
        STREAM_writeUShort(stream, 0);
    }

    for ( n = 0; n < coverageCount; n++)
    {
        coverage_table* ct = (coverage_table*)vector_at(&cpf3->Coverage, n);

        curOffset = STREAM_streamPos(stream);
        offset = curOffset - baseOffset;

        STREAM_streamSeek(stream, coverageOffset);
        STREAM_writeUShort(stream, (USHORT)offset);
        coverageOffset += sizeof(OFFSET);

        // build coverage
        STREAM_streamSeek(stream, curOffset);
        Coverage_buildTable(ct, stream);
    }

    // write out lookup records
    Common_buildSubstLookupRecords(&cpf3->PosLookupRecord, stream);

    return STREAM_streamPos(stream);
}

static size_t contextPos_sizeFormat3(gpos_context_position_f3* cpf3)
{
    size_t size;
    size_t coverageSize;

    USHORT n, coverageCount, posCount;
    LF_ERROR error;

    ASSERT(cpf3);

    coverageCount = UTILS_getCount(&cpf3->Coverage);
    posCount = UTILS_getCount(&cpf3->PosLookupRecord);

    size = sizeof(USHORT);
    size += sizeof(USHORT);
    size += (sizeof(OFFSET) * coverageCount);
    size += (sizeof(OFFSET) * posCount);

    for (n = 0; n < coverageCount; n++)
    {
        coverage_table* table = (coverage_table*)vector_at(&cpf3->Coverage, n);
        error = Coverage_getTableSize(table, &coverageSize);
        if (error != LF_ERROR_OK) {
            DEBUG_LOG_WARNING("coverage table size problem");
        }

        size += coverageSize;
    }

    size += Common_sizeSubstLookupRecords(&cpf3->PosLookupRecord);

    return size;
}

static void contextPos_freeFormat3(gpos_context_position_f3* cpf3)
{
    ASSERT(cpf3);

    Coverage_deleteCoverageTables(&cpf3->Coverage);
    Common_freeSubstLookupRecords(&cpf3->PosLookupRecord);
}

static LF_ERROR contextPos_removeFormat3(gpos_context_position_f3* cpf3, GlyphID glyphid)
{
    LF_ERROR error;

    ASSERT(cpf3);

    error = Coverage_removeCoveragesGlyphIndex(&cpf3->Coverage, glyphid);

    if (error == LF_EMPTY_TABLE)
        return LF_EMPTY_TABLE;

    return LF_ERROR_OK;
}

static LF_ERROR contextPos_remapTableFormat3(gpos_context_position_f3* f3, LF_MAP *remap)
{
    LF_ERROR error = LF_ERROR_OK;
    USHORT i, numCoverageTables = UTILS_getCount(&f3->Coverage);

    for(i = 0; i < numCoverageTables; i++)
    {
        coverage_table *ct = (coverage_table *)vector_at(&f3->Coverage, i);

        error = Coverage_remapAll(ct, remap);

        if ((error != LF_ERROR_OK) && (error != LF_EMPTY_TABLE))
        {
            break;
        }
    }

    return error;
}



////

static LF_ERROR contextPos_removeLookupIndexFormat1(gpos_context_position_f1* f1, USHORT lookupIndex, SHORT deltaIndex)
{
    USHORT n, i;
    LF_ERROR error = LF_ERROR_OK;

    n = 0;
    while (n < f1->PosRuleSet.count)
    {
        context_rule_set* ruleset = (context_rule_set*)vector_at(&f1->PosRuleSet, n);
        if (NULL == ruleset)
            return LF_BAD_FORMAT;

        i = 0;
        while (i < ruleset->RuleSet.count)
        {
            context_rule* pr = (context_rule*)vector_at(&ruleset->RuleSet, i);
            error = Common_removeLookupListIndex(&pr->LookupRecords, lookupIndex, deltaIndex);

            if (error == LF_EMPTY_TABLE)
            {
                ContextRule_freeRule(pr);
                vector_erase(&ruleset->RuleSet, i);
            }
            else
            {
                i++;
            }
        }

        if (!ruleset->RuleSet.count)
        {
            ContextSet_freeRuleSet(ruleset);
            FREE(ruleset);
            vector_erase(&f1->PosRuleSet, n);

            // because a RuleSet is associated with Coverage in coverage order, we
            // need to clear the coverage index as well.
            Coverage_eraseIndex(&f1->Coverage, n);
        }
        else
        {
            n++;
        }
    }


    // check if there are any RuleSets left ...
    if (!f1->PosRuleSet.count)
        return LF_EMPTY_TABLE;

    return LF_ERROR_OK;
}

static LF_ERROR contextPos_removeLookupIndexFormat2(gpos_context_position_f2* f2, USHORT lookupIndex, SHORT deltaIndex)
{
    ULONG n, i;
    LF_ERROR error;

    n = 0;
    while ( n < f2->PosClassSet.count)
    {
        class_set* pcs = (class_set*)vector_at(&f2->PosClassSet, n);
        if (pcs && pcs->ClassRules != NULL)
        {
            i = 0;
            while (i < pcs->ClassRules->count)
            {
                class_rule* pcr = (class_rule*)vector_at(pcs->ClassRules, i);
                if (pcr)
                {
                    error = Common_removeLookupListIndex(&pcr->LookupRecords, lookupIndex, deltaIndex);
                    if (error == LF_EMPTY_TABLE)
                    {
                        ClassRule_freeRule(pcr);
                        vector_erase(pcs->ClassRules, i);
                        free(pcr);
                    }
                    else
                    {
                        i++;
                    }
                }
            }
        }

        if (pcs && pcs->ClassRules && !pcs->ClassRules->count)
        {
            ClassSet_freeClassSet(pcs);
            FREE(pcs);
//          vector_erase(&f2->PosClassSet, n);
            vector_set_data(&f2->PosClassSet, n, NULL);
            n++;
            DEBUG_LOG_VALUE("removing ClassRules", n);
        }
        else
        {
            n++;
        }
    }

    return ClassSets_validClassRules(&f2->PosClassSet);
}

static LF_ERROR contextPos_removeLookupIndexFormat3(gpos_context_position_f3* f3, USHORT lookupIndex, SHORT deltaIndex)
{
    LF_ERROR error = Common_removeLookupListIndex(&f3->PosLookupRecord, lookupIndex, deltaIndex);
    return error;
}

LF_ERROR GPOS_removeContextPositioningLookupIndex(gpos_context_positioning* cp, USHORT lookupIndex, SHORT deltaIndex)
{
    LF_ERROR error = LF_ERROR_OK;

    switch (cp->PosFormat)
    {
    case 1:    error = contextPos_removeLookupIndexFormat1(&cp->csf.cpf1, lookupIndex, deltaIndex);    break;
    case 2:    error = contextPos_removeLookupIndexFormat2(&cp->csf.cpf2, lookupIndex, deltaIndex);    break;
    case 3:    error = contextPos_removeLookupIndexFormat3(&cp->csf.cpf3, lookupIndex, deltaIndex);    break;
    default: error = LF_BAD_FORMAT;                                                                    break;
    }

    return error;
}


/* ============================================================================
    @description
        remaps glyphid in the table


    @param
        cp          : pointer to context positioning structure
        remap       : pointer to map of old & new glyph ids

    @return
        OK          : ok.
        NOT COVERED : original glyph wast not in the table (not an error) .
============================================================================ */
LF_ERROR GPOS_contextPositioningRemapTable(gpos_context_positioning* cp, LF_MAP *remap)
{
    LF_ERROR error = LF_ERROR_OK;

    switch (cp->PosFormat)
    {
    case 1:     error = contextPos_remapTableFormat1(&cp->csf.cpf1, remap); break;
    case 2:     error = contextPos_remapTableFormat2(&cp->csf.cpf2, remap); break;
    case 3:     error = contextPos_remapTableFormat3(&cp->csf.cpf3, remap); break;
    default:    error = LF_BAD_FORMAT;                                      break;
    }

    return error;
}

/* ============================================================================
    @description
        prune the lookup records for each of the context positioning.


    @param
        cp          : pointer to context positioning structure

    @return
        OK          : everything pruned ok.
        EMPTY       : the rule is empty.
============================================================================ */
LF_ERROR GPOS_pruneContextPositioningLookupRecords(gpos_context_positioning* cp)
{
    LF_ERROR error = LF_ERROR_OK;

    switch (cp->PosFormat)
    {
    case 1:        error = contextPos_pruneLookupRecordsFormat1(&cp->csf.cpf1);        break;
    case 2:        error = contextPos_pruneLookupRecordsFormat2(&cp->csf.cpf2);        break;
    case 3:        error = contextPos_pruneLookupRecordsFormat3(&cp->csf.cpf3);        break;
    default:    error = LF_BAD_FORMAT;                                                 break;
    }

    return error;
}



static LF_ERROR contextPos_pruneLookupRecordsFormat1(gpos_context_position_f1* cpf1)
{
#ifdef LF_OT_DUMP
    contextPos_dumpFormat1(cpf1);
#else
    (void)cpf1;
#endif
    return LF_ERROR_OK;
}


static LF_ERROR contextPos_pruneLookupRecordsFormat2(gpos_context_position_f2* cpf2)
{
    LF_ERROR error;

    error = ClassSet_pruneEmptyClasses(&cpf2->ClassDef, &cpf2->PosClassSet);
    if (error == LF_EMPTY_TABLE)
        return error;

    ClassSet_cleanupCoverageClasses(&cpf2->ClassDef, &cpf2->PosClassSet, &cpf2->Coverage);

    if (Coverage_getCoverageCount(&cpf2->Coverage) == 0)
        error = LF_EMPTY_TABLE;

    error = ClassSets_validClassRules(&cpf2->PosClassSet);

    return error;
}


static LF_ERROR contextPos_pruneLookupRecordsFormat3(gpos_context_position_f3* cpf3)
{
    UNUSED(cpf3);
    return LF_ERROR_OK;
}


#ifdef LF_OT_DUMP
static void contextPos_dumpFormat1(gpos_context_position_f1* cpf1)
{
#if _DEBUG
    USHORT i;
    DEBUG_LOG("-------------------------------------");

    Coverage_dumpTable(&cpf1->Coverage);

    for (i = 0; i < cpf1->PosRuleSet.count; i++)
    {
        context_rule_set* crs = (context_rule_set*)vector_at(&cpf1->PosRuleSet, i);
        ContextSet_dumpSet(crs);
    }

    DEBUG_LOG("-------------------------------------");
#else
    UNUSED(cpf1);
#endif
}

#if 0 //not used
static void contextPos_dumpFormat2(gpos_context_position_f2* cpf2)
{
#if _DEBUG

    DEBUG_LOG("-------------------------------------");

    Coverage_dumpTable(&cpf2->Coverage);
    ClassDef_dump(&cpf2->ClassDef);
    ClassSets_dumpClassSets(&cpf2->PosClassSet);

    DEBUG_LOG("-------------------------------------");
#endif
}
#endif
#endif



LF_ERROR GPOS_cleanupContextLookups(gpos_context_positioning* cp, TABLE_HANDLE hLookup)
{
    LF_ERROR    error;

    switch(cp->PosFormat)
    {
    case 1:        error = contextSubst_cleanupLookupsFormat1(&cp->csf.cpf1, hLookup);        break;
    case 2:        error = contextSubst_cleanupLookupsFormat2(&cp->csf.cpf2, hLookup);        break;
    case 3:        error = contextSubst_cleanupLookupsFormat3(&cp->csf.cpf3, hLookup);        break;
    default:       error = LF_BAD_FORMAT;                                                     break;
    }

    return error;
}


static LF_ERROR contextSubst_cleanupLookupsFormat1(gpos_context_position_f1* cpf1, TABLE_HANDLE hLookup)
{
    LF_ERROR error = ContextSet_cleanupLookups(&cpf1->PosRuleSet, hLookup);
    return error;
}

static LF_ERROR contextSubst_cleanupLookupsFormat2(gpos_context_position_f2* cpf2, TABLE_HANDLE hLookup)
{
    LF_ERROR    error = LF_ERROR_OK;
    ULONG i;
    for (i = 0; i < cpf2->PosClassSet.count; i++)
    {
        class_set* crs = (class_set*)vector_at(&cpf2->PosClassSet, i);
        if (crs)
            ClassSet_cleanupLookups(crs, hLookup);
    }

    return error;
}

static LF_ERROR contextSubst_cleanupLookupsFormat3(gpos_context_position_f3* cpf3, TABLE_HANDLE hLookup)
{
    LF_ERROR    error = LF_ERROR_OK;
    Common_cleanupLookups(&cpf3->PosLookupRecord, hLookup);    
    return error;
}
