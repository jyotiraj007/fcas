// Copyright (C) 2014 , 2016 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// gpos_pair_adjustment.c

#include <stdlib.h>
#include "gpos_lookup/gpos_pair_adjustment.h"
#include "common_table.h"
#include "utils.h"

static LF_ERROR removeFormat1(gpos_pair_adjustment* table, GlyphID glyphID);
static LF_ERROR removeFormat2(gpos_pair_adjustment* table, GlyphID glyphID);

static void     freePairAdjustFormat1(gpos_pair_adjustment_1* f1);
static void     freePairAdjustFormat2(gpos_pair_adjustment_2* f2);
static void     freePairSetTable(LF_VECTOR* pairset);

static LF_ERROR prunePairAdjustmentLookupRecordsFormat1(gpos_pair_adjustment* table);
static LF_ERROR prunePairAdjustmentLookupRecordsFormat2(gpos_pair_adjustment* table);

static LF_ERROR buildFormat1(gpos_pair_adjustment* table, LF_STREAM* stream, size_t tableStart, size_t coverageOffset);
static LF_ERROR isValueRecordValid(ValueRecord* valueRecord);
//static USHORT gpos_validateCoverage(gpos_pair_adjustment* table);

// helper accessors
static LF_VECTOR* getPairSet(gpos_pair_adjustment* table, USHORT index);
static USHORT getPairSetKey(gpos_pair_adjustment* table, USHORT index);
static LF_ERROR eraseCoveragePairSet(gpos_pair_adjustment* table, USHORT index);
static boolean erasePairSet(gpos_pair_adjustment* table, USHORT offset);
static boolean removePairSet(gpos_pair_adjustment* table, USHORT offset);
static LF_VECTOR* getPairSetByOffset(gpos_pair_adjustment* table, USHORT offset);

// return a PairSet associated with an index value.
static LF_VECTOR* getPairSet(gpos_pair_adjustment* table, USHORT index)
{
    gpos_pair_adjustment_1* f1 = &table->pair_format.format1;
    USHORT pairSetOffset = (USHORT)(intptr_t)vector_at(&f1->PairOffsets, index);
    LF_VECTOR* pairSet = (LF_VECTOR*)map_at(&f1->PairSetMap, (void*)(intptr_t)pairSetOffset);

    return pairSet;
}

static LF_VECTOR* getPairSetByOffset(gpos_pair_adjustment* table, USHORT offset)
{
    gpos_pair_adjustment_1* f1 = &table->pair_format.format1;
    LF_VECTOR* pairSet = (LF_VECTOR*)map_at(&f1->PairSetMap, (void*)(intptr_t)offset);

    return pairSet;
}

static USHORT getPairSetKey(gpos_pair_adjustment* table, USHORT index)
{
    gpos_pair_adjustment_1* f1 = &table->pair_format.format1;
    USHORT pairSetOffset = (USHORT)(intptr_t)vector_at(&f1->PairOffsets, index);

    return pairSetOffset;
}

static LF_ERROR eraseCoveragePairSet(gpos_pair_adjustment* table, USHORT index)
{
    gpos_pair_adjustment_1* f1 = &table->pair_format.format1;
    LF_VECTOR* pairSet = getPairSet(table, index);
    if (pairSet)
    {
        USHORT key = getPairSetKey(table, index);
        USHORT n;

        // removes the one instance of the coverage table
        vector_erase(&f1->PairOffsets, index);
        Coverage_eraseIndex(&table->Coverage, index);

        // loop through and see if the table is referenced
        // anywhere else in the PairOffsets.
        for (n = 0; n < f1->PairOffsets.count; n++)
        {
            USHORT offset = getPairSetKey(table, n);
            if (key == offset)
            {
                // still referenced, so return OK
                return LF_ERROR_OK;
            }
        }
    }
    // not referenced, so return EMPTY.
    return LF_EMPTY_TABLE;
}

static boolean erasePairSet(gpos_pair_adjustment* table, USHORT offset)
{
    gpos_pair_adjustment_1* f1 = &table->pair_format.format1;

    LF_VECTOR* pairSet = getPairSetByOffset(table, offset);
    if (pairSet)
    {
        freePairSetTable(pairSet);
        map_erase(&f1->PairSetMap, (void*)(intptr_t)offset);
    }

    return TRUE;
}

static boolean removePairSet(gpos_pair_adjustment* table, USHORT offset)
{
    gpos_pair_adjustment_1* f1 = &table->pair_format.format1;
    size_t n = 0;

    // loop through the offset table
    while (n < f1->PairOffsets.count)
    {
        USHORT pairSetOffset = (USHORT)(intptr_t)vector_at(&f1->PairOffsets, n);
        if (pairSetOffset == offset)
        {
            // PairSets and coverages must be in sync
            vector_erase(&f1->PairOffsets, n);
            Coverage_eraseIndex(&table->Coverage, (USHORT)n);
        }
        else
        {
            n++;
        }
    }
    return erasePairSet(table, offset);

}

// Function name   : GPOS_readPairSetTable
// Description     : A PairSet table enumerates all the glyph pairs that begin with a covered
//                     glyph. An array of PairValueRecords (PairValueRecord) contains one record
//                     for each pair and lists the records sorted by the GlyphID of the second
//                     glyph in each pair. PairValueCount specifies the number of PairValueRecords
//                     in the set.
//                     A PairValueRecord specifies the second glyph in a pair (SecondGlyph) and
//                     defines a ValueRecord for each glyph (Value1 and Value2). If ValueFormat1
//                     is set to zero (0) in the PairPos subtable, ValueRecord1 will be empty;
//                     similarly, if ValueFormat2 is 0, Value2 will be empty.
// Return type     : static TABLE_HANDLE
// Argument        : gpos_pair_adjustment* table
// Argument        : LF_STREAM* stream

static TABLE_HANDLE GPOS_readPairSetTable(const gpos_pair_adjustment* table, LF_STREAM* stream)
{
    LF_VECTOR* pairSetTable;
    USHORT pairValueCount = STREAM_readUShort(stream);
    USHORT i;

    pairSetTable = (LF_VECTOR*)calloc(1, sizeof(LF_VECTOR));

    if(pairSetTable == NULL)
        return NULL;

    if(LF_ERROR_OK != vector_init(pairSetTable, pairValueCount, 4))
    {
        free(pairSetTable);
        return NULL;
    }

    for(i = 0; i < pairValueCount; i++)
    {
        pair_value_record* record = (pair_value_record*)calloc(1, sizeof(pair_value_record));

        if(record == NULL)
        {
            for(size_t j = 0; j < pairSetTable->count; j++)
                free(vector_at(pairSetTable, j));
            vector_delete(pairSetTable);
            free(pairSetTable);
            return NULL;
        }
        record->SecondGlyph = STREAM_readUShort(stream);

        readValueRecord(table->ValueFormat1, &record->Value1, stream);
        readValueRecord(table->ValueFormat2, &record->Value2, stream);

        if (LF_ERROR_OK != vector_push_back(pairSetTable, record))
        {
            for (size_t j = 0; j < pairSetTable->count; j++)
                free(vector_at(pairSetTable, j));
            vector_delete(pairSetTable);
            free(pairSetTable);
            return NULL;
        }
    }

    return pairSetTable;
}

// Function name   : GPOS_buildPairSetTable
// Description     :
// Return type     : static ULONG
// Argument        : gpos_pair_adjustment* table
// Argument        : LF_VECTOR* pairSetTable
// Argument        : LF_STREAM* stream
static ULONG GPOS_buildPairSetTable(const gpos_pair_adjustment* table, LF_VECTOR* pairSetTable, LF_STREAM* stream)
{
    ULONG outSize = sizeof(USHORT);
    ULONG i;
    USHORT count = UTILS_getCount(pairSetTable);

    STREAM_writeUShort(stream, count);

    for(i = 0; i < pairSetTable->count; i++)
    {
        pair_value_record* record = (pair_value_record*)vector_at(pairSetTable, i);

        STREAM_writeUShort(stream, record->SecondGlyph);
        outSize += sizeof(USHORT);

        outSize += writeValueRecord(table->ValueFormat1, &record->Value1, stream);
        outSize += writeValueRecord(table->ValueFormat2, &record->Value2, stream);
    }
    return outSize;
}

// Function name   : GPOS_readPairAdjustment
// Description     :
// Return type     : TABLE_HANDLE
// Argument        : LF_STREAM* stream

TABLE_HANDLE GPOS_readPairAdjustment(LF_STREAM* stream)
{
    LF_ERROR error;
    gpos_pair_adjustment* table;
    base_table* base;
    size_t tableStart = STREAM_streamPos(stream);
    size_t oldOffset;
    OFFSET coverageOffset;

    table = (gpos_pair_adjustment*)calloc(1, sizeof(gpos_pair_adjustment));
    if(table == NULL)
        return NULL;

    base = (base_table*)table;

    table->PosFormat = STREAM_readUShort(stream);

    coverageOffset = STREAM_readOffset(stream);
    oldOffset = STREAM_streamPos(stream);
    STREAM_streamSeek(stream, tableStart + coverageOffset);

    error = Coverage_readTable(&table->Coverage, stream);
    if (error != LF_ERROR_OK)
    {
        if (error != LF_EMPTY_TABLE)
        {
            free(table);
            return NULL;
        }
    }

    STREAM_streamSeek(stream, oldOffset);

    table->ValueFormat1 = STREAM_readUShort(stream);
    table->ValueFormat2 = STREAM_readUShort(stream);

    if(table->PosFormat == 1)
    {
        USHORT i, pairSetCount = STREAM_readUShort(stream);
        LF_MAP* duplicateMap = &table->pair_format.format1.PairSetMap;

        map_init(duplicateMap, integer_compare);

        error = vector_init(&table->pair_format.format1.PairOffsets, pairSetCount, 4);
        if (error != LF_ERROR_OK)
        {
            Coverage_deleteTable(&table->Coverage);
            free(table);
            return NULL;
        }

        for(i = 0; i < pairSetCount; i++)
        {
            OFFSET pairOffset = STREAM_readOffset(stream);
            TABLE_HANDLE pairSetTable = NULL;

            // new duplicate detection method ...
            if (map_key_exists(duplicateMap, (void*)(intptr_t)pairOffset) == FALSE)
            {
                oldOffset = STREAM_streamPos(stream);
                STREAM_streamSeek(stream, tableStart + pairOffset);

                pairSetTable = GPOS_readPairSetTable(table, stream);
                if (pairSetTable == NULL)
                {
                    freePairAdjustFormat1(&table->pair_format.format1);
                    Coverage_deleteTable(&table->Coverage);
                    free(table);
                    return NULL;
                }

                STREAM_streamSeek(stream, oldOffset);
                map_insert(duplicateMap, (void*)(intptr_t)pairOffset, (void*)pairSetTable);
            }
            else
            {
                DEBUG_LOG_VALUE("found duplicate", i);
            }
            vector_push_back(&table->pair_format.format1.PairOffsets, (void*)(intptr_t)pairOffset);
        }
#if 0 //LF_OT_DUMP
        XML_START("Read");
        GPOS_dumpPairAdjustment(table);
        XML_END("Read");
#endif
    }
    else
    {
        OFFSET classDef1 = STREAM_readOffset(stream);
        OFFSET classDef2 = STREAM_readOffset(stream);
        USHORT i;

        table->pair_format.format2.Class1Count = STREAM_readUShort(stream);
        table->pair_format.format2.Class2Count = STREAM_readUShort(stream);

        oldOffset = STREAM_streamPos(stream);
        STREAM_streamSeek(stream, tableStart + classDef1);
        ClassDef_readTable(&table->pair_format.format2.ClassDef1, stream);

        STREAM_streamSeek(stream, tableStart + classDef2);
        ClassDef_readTable(&table->pair_format.format2.ClassDef2, stream);
        STREAM_streamSeek(stream, oldOffset);

        error = vector_init(&table->pair_format.format2.Class1Records, table->pair_format.format2.Class1Count, 4);
        if (error != LF_ERROR_OK)
        {
            ClassDef_freeTable(&table->pair_format.format2.ClassDef2);
            ClassDef_freeTable(&table->pair_format.format2.ClassDef1);
            Coverage_deleteTable(&table->Coverage);
            free(table);
            return NULL;
        }

        for(i = 0; i < table->pair_format.format2.Class1Count; i++)
        {
            USHORT j;
            LF_VECTOR* class2Records = vector_create(table->pair_format.format2.Class2Count, 4);

            for(j = 0; j < table->pair_format.format2.Class2Count; j++)
            {
                gpos_class2_record* record = (gpos_class2_record*)calloc(1, sizeof(gpos_class2_record));

                if (record == NULL)
                {
                    for (size_t k = 0; k < class2Records->count; k++)
                        free(vector_at(class2Records, k));
                    vector_delete(class2Records);
                    free(class2Records);
                    freePairAdjustFormat2(&table->pair_format.format2);
                    Coverage_deleteTable(&table->Coverage);
                    free(table);
                    return NULL;
                }

                readValueRecord(table->ValueFormat1, &record->Value1, stream);
                readValueRecord(table->ValueFormat2, &record->Value2, stream);

                vector_push_back(class2Records, record);
            }

            error = vector_push_back(&table->pair_format.format2.Class1Records, class2Records);
            if (error != LF_ERROR_OK)
            {
                for (size_t k = 0; k < class2Records->count; k++)
                    free(vector_at(class2Records, k));
                vector_delete(class2Records);
                free(class2Records);
                freePairAdjustFormat2(&table->pair_format.format2);
                Coverage_deleteTable(&table->Coverage);
                free(table);
                return NULL;
            }
        }
    }

    return table;
}

// Function name   : GPOS_getPairAdjustmentSize
// Description     :
// Return type     : size_t
// Argument        : gpos_pair_adjustment* table
size_t GPOS_getPairAdjustmentSize(gpos_pair_adjustment* table)
{
    size_t tableSize = 0;

    Coverage_getTableSize(&table->Coverage, &tableSize);
    tableSize += sizeof(USHORT) * 5;

    if(table->PosFormat == 1)
    {
        ULONG pairSize = sizeof(GlyphID);
        LF_MAP_ITER* mapIter;
        rb_tree_node* node;

        pairSize += getValueRecordSize(table->ValueFormat1);
        pairSize += getValueRecordSize(table->ValueFormat2);

        tableSize += sizeof(OFFSET) * table->pair_format.format1.PairOffsets.count;

        mapIter = map_begin(&table->pair_format.format1.PairSetMap);
        if (mapIter == NULL)
        {
            DEBUG_LOG_ERROR("out of memory parsing the pair size table");
            return 0;
        }

        node = map_next(mapIter);
        while (node)
        {
            LF_VECTOR* pairSet = (LF_VECTOR*)node->data;
            tableSize += sizeof(USHORT) + pairSet->count * pairSize;
            node = map_next(mapIter);
        }

        map_free_iter(mapIter);
    }
    else
    {
        size_t classDefSize = 0;
        ULONG recordSize = getValueRecordSize(table->ValueFormat1);
        recordSize += getValueRecordSize(table->ValueFormat2);

        ClassDef_sizeTableFormat(&table->pair_format.format2.ClassDef1, &classDefSize);
        tableSize += classDefSize;

        ClassDef_sizeTableFormat(&table->pair_format.format2.ClassDef2, &classDefSize);
        tableSize += classDefSize;

        tableSize += sizeof(OFFSET) * 2 + sizeof(USHORT) * 2;
        tableSize += recordSize * table->pair_format.format2.Class1Count * table->pair_format.format2.Class2Count;
    }

    //tableSize = (tableSize + 3) & ~3;
    return tableSize;
}


/*
    @desc
        build the pair adjust for format 1.
*/
static LF_ERROR buildFormat1(gpos_pair_adjustment* table, LF_STREAM* stream, size_t tableStart, size_t coverageOffset)
{
    LF_VECTOR*      pairSet;
    LF_ERROR        status;

    USHORT          i, pairSetCount;
    size_t          arrayPairSetOffset;
    size_t          tableOffset;

    LF_MAP*         remapMap = map_create(integer_compare);

    LF_MAP_ITER*    mapIter;
    rb_tree_node*   node;

    gpos_pair_adjustment_1* f1 = &table->pair_format.format1;

    pairSet = &f1->PairOffsets;
    pairSetCount = UTILS_getCount(pairSet);

    // write out PairSetCount
    STREAM_writeUShort(stream, pairSetCount);

    // write out temporary OFFSET array PairSetOffset[PairSetCount]
    arrayPairSetOffset = Common_buildEmptyArray(stream, pairSetCount);
    tableOffset = STREAM_streamPos(stream) - tableStart;

    STREAM_streamSeek(stream, coverageOffset);

    status = STREAM_writeOffset(stream, tableOffset);
    if (status != LF_ERROR_OK)
    {
        DEBUG_LOG_ERROR("Pairs adjustment exceeds current 16bit offset value");
        DEBUG_LOG("Failed writing coverage");
        return status;
    }

    STREAM_streamSeek(stream, tableStart + tableOffset);
    Coverage_buildTable(&table->Coverage, stream);

    // calculate the latest offset from table start for PairSetOffset[]

    mapIter = map_begin(&f1->PairSetMap);
    if (mapIter == NULL)
    {
        DEBUG_LOG_ERROR("out of memory while freeing pair adjustment");
        return LF_OUT_OF_MEMORY;
    }

    tableOffset = STREAM_streamPos(stream) - tableStart;

    node = map_next(mapIter);
    while (node)
    {
        pairSet = (LF_VECTOR*)node->data;
        ULONG key = (ULONG)(intptr_t)node->key;

        // this will store off the new PairSet offset value.  it will use
        // old key as reference to the data.
        map_insert(remapMap, (void*)(intptr_t)key, (void*)tableOffset);                   // store off new map

        tableOffset += GPOS_buildPairSetTable(table, pairSet, stream);
        node = map_next(mapIter);
    }
    map_free_iter(mapIter);


    // now we need to populate the PairSet offset table with
    // the newly calculated offsets.
    tableOffset = STREAM_streamPos(stream);
    STREAM_streamSeek(stream, arrayPairSetOffset);
    for (i = 0; i < pairSetCount; i++)
    {
        USHORT key = (USHORT)(intptr_t)vector_at(&f1->PairOffsets, i);
        USHORT offset = (USHORT)(intptr_t)map_at(remapMap, (void*)(intptr_t)key);
        status = STREAM_writeOffset(stream, offset);
        if (status != LF_ERROR_OK)
        {
            DEBUG_LOG_ERROR("Pairs adjustment exceeds current 16bit offset value");
            DEBUG_LOG_VALUE("Failed at pairSet index: ", i);
            DEBUG_LOG_VALUE("of total pairSet: ", pairSetCount);

            return status;
        }
    }

    map_clear(remapMap);
    free(remapMap);
    STREAM_streamSeek(stream, tableOffset);

    return LF_ERROR_OK;
}


// Function name   : GPOS_buildPairAdjustment
// Description     :
// Return type     : LONG
// Argument        : gpos_pair_adjustment* table
// Argument        : LF_STREAM* stream

size_t GPOS_buildPairAdjustment(gpos_pair_adjustment* table, LF_STREAM* stream)
{
    size_t tableStart = STREAM_streamPos(stream);
    size_t coverageOffset;
    size_t tableOffset = 0;
    size_t curOffset;

    STREAM_writeUShort(stream, table->PosFormat);
    coverageOffset = STREAM_streamPos(stream);    //for assignment later
    STREAM_writeUShort(stream, 0);
    STREAM_writeUShort(stream, table->ValueFormat1);
    STREAM_writeUShort(stream, table->ValueFormat2);

    if(table->PosFormat == 1)
    {
        LF_ERROR status = buildFormat1(table, stream, tableStart, coverageOffset);
        if (status != LF_ERROR_OK)
            goto Fail1;
    }
    else
    {
        size_t classDef1Offset;
        size_t classDef2Offset;
        size_t classDef1Count;
        size_t classDef2Count;
        size_t class1Count;
        size_t class2Count = 0;
        ULONG  i;

        classDef1Offset = STREAM_streamPos(stream);
        STREAM_writeOffset(stream, 0);

        classDef2Offset = STREAM_streamPos(stream);
        STREAM_writeOffset(stream, 0);

        classDef1Count = STREAM_streamPos(stream);
        STREAM_writeUShort(stream, table->pair_format.format2.Class1Count);

        classDef2Count = STREAM_streamPos(stream);
        STREAM_writeUShort(stream, table->pair_format.format2.Class2Count);

        class1Count = table->pair_format.format2.Class1Records.count;
        for(i = 0; i < class1Count; i++)
        {
            ULONG j;
            LF_VECTOR* class2Records = (LF_VECTOR*)vector_at(&table->pair_format.format2.Class1Records, i);

            class2Count = class2Records->count;

            for(j = 0; j < class2Records->count; j++)
            {
                gpos_class2_record* record = (gpos_class2_record*)vector_at(class2Records, j);

                writeValueRecord(table->ValueFormat1, &record->Value1, stream);
                writeValueRecord(table->ValueFormat2, &record->Value2, stream);
            }
        }

        // Make a change here to write the coverage table first before the class tables.  
        // This should prevent the coverage offset overflow seen in a few fonts	
        // record coverage offset and write Coverage table
        tableOffset = STREAM_streamPos(stream) - tableStart;
        STREAM_streamSeek(stream, coverageOffset);
        STREAM_writeOffset(stream, tableOffset);
        STREAM_streamSeek(stream, tableStart + tableOffset);

        Coverage_buildTable(&table->Coverage, stream);

        tableOffset = STREAM_streamPos(stream) - tableStart;
        STREAM_streamSeek(stream, classDef1Offset);
        STREAM_writeOffset(stream, tableOffset);
        STREAM_streamSeek(stream, tableStart + tableOffset);

        ClassDef_buildTableFormat(&table->pair_format.format2.ClassDef1, stream);

        tableOffset = STREAM_streamPos(stream) - tableStart;
        STREAM_streamSeek(stream, classDef2Offset);
        STREAM_writeOffset(stream, tableOffset);
        STREAM_streamSeek(stream, tableStart + tableOffset);

        ClassDef_buildTableFormat(&table->pair_format.format2.ClassDef2, stream);

        curOffset = STREAM_streamPos(stream);

        // clean up the class definition counts
        STREAM_streamSeek(stream, classDef1Count);
        STREAM_writeUShort(stream, (USHORT)class1Count);

        STREAM_streamSeek(stream, classDef2Count);
        STREAM_writeUShort(stream, (USHORT)class2Count);

        STREAM_streamSeek(stream, curOffset);
    }

#if 0// LF_OT_DUMP
    XML_START("Build")
    GPOS_dumpPairAdjustment(table);
    XML_END("Build")
#endif

    return STREAM_streamPos(stream) - tableStart;

Fail1:
    DEBUG_LOG_ERROR("failed to write entire table");

#if _DEBUG
//    XML_START("FailedBuild")
//        GPOS_dumpPairAdjustment(table);
//    XML_END("FailedBuild")
#endif

    return STREAM_streamPos(stream) - tableStart;
}

LF_ERROR GPOS_pairAdjustRemoveGlyph(gpos_pair_adjustment* table, GlyphID glyphID)
{
    LF_ERROR    error = LF_ERROR_OK;
    base_table* base = (base_table*)table;

#if _DEBUG
    if (base->ignore == 1)
    {
        DEBUG_LOG_VALUE("[GPOS Pair Adjustment] ignore this glyph removal: ", glyphID);
    }
#endif

    if (base->ignore == 0)
    {
        switch (table->PosFormat)
        {
            case 1:        error = removeFormat1(table, glyphID);        break;
            case 2:        error = removeFormat2(table, glyphID);        break;
            default:       error = LF_BAD_FORMAT;                        break;
        }
    }

    return error;
}

static LF_ERROR remapFormat1(gpos_pair_adjustment_1* f1Table, LF_MAP *remap)
{
    LF_MAP_ITER* mapIter;
    rb_tree_node* node;

    mapIter = map_begin(&f1Table->PairSetMap);
    if (mapIter == NULL)
    {
        DEBUG_LOG_ERROR("out of memory while freeing pair adjustment");
        return LF_OUT_OF_MEMORY;
    }

    node = map_next(mapIter);
    while (node)
    {
        LF_VECTOR* pairSet = (LF_VECTOR*)node->data;
        USHORT  j, numPairs;
        GlyphID origGlyphID, newGlyphID;

        numPairs = (USHORT)vector_size(pairSet);

        for (j = 0; j < numPairs; j++)
        {
            pair_value_record *pvr = (pair_value_record *)vector_at(pairSet, j);
            boolean bStatus;

            origGlyphID = pvr->SecondGlyph;

            bStatus = map_key_exists(remap, (void*)(intptr_t)origGlyphID);
            if (bStatus == FALSE)
            {
                DEBUG_LOG_VALUE("Remap failed: ", origGlyphID);
            }
            newGlyphID = (GlyphID)(intptr_t)map_at(remap, (void*)(intptr_t)origGlyphID);
            pvr->SecondGlyph = newGlyphID;
        }
        node = map_next(mapIter);
    }
    map_free_iter(mapIter);

    return LF_ERROR_OK;
}

static LF_ERROR GPOS_checkCoverageExtras(gpos_pair_adjustment* table, LF_MAP *remap)
{
    size_t numRemainingGlyphs = map_size(remap);

    BYTE* coveredArray = (BYTE*)calloc(numRemainingGlyphs, sizeof(BYTE));
    if (NULL == coveredArray)
        return LF_OUT_OF_MEMORY;
    // Array is now all zeros

    // Loop over the coverage table, and set glyphs in that to 1
    size_t i;
    for (i = 0; i < table->Coverage.CoverageMap.count; i++)
    {
        GlyphID gid = (GlyphID)(intptr_t)vector_at(&table->Coverage.CoverageMap, i);

        if (gid < numRemainingGlyphs)
            coveredArray[gid] = 1;
    }
    // Array now has any glyphs in the coverage table set to 1

    // Loop over the ClassDef1's and set back to zero the glyphs which are covered by them
    boolean doNothing = FALSE;
    size_t numGlyphsCovered = table->pair_format.format2.ClassDef1.MapGlyph.count;

    for (i = 0; i < numGlyphsCovered; i++)
    {
        class_map* cm = (class_map*)vector_at(&table->pair_format.format2.ClassDef1.MapGlyph, i);

        if (cm != NULL)
        {
            if (cm->Class == 0)
            {
                doNothing = TRUE;       // Explict class 0, so don't mess with anything
                break;
            }
            if (cm->Glyph < numRemainingGlyphs)
                coveredArray[cm->Glyph] = 0;
        }
    }
    // Array now has any glyphs which are in the coverage but not classdefs set to 1.
    // These are the coverage extras which are assumed to be class 0

    if (doNothing == FALSE)
    {
        // if there are no coverage extras, then there is no need to have any data for the
        // ValueRecords for left class zero in the valueRecord array, unless there is/are
        // explicit class 0 records in the classDef1 list

        // See if there are any coverage extras
        for (i = 0; i < numRemainingGlyphs; i++)
        {
            if (coveredArray[i] == 1)
                break;
        }

        if (i == numRemainingGlyphs)
        {
            // no extras
            LF_VECTOR* class0vec = vector_at(&table->pair_format.format2.Class1Records, 0);

            for (size_t j = 0; j < table->pair_format.format2.Class2Count; j++)
            {
                gpos_class2_record* gcr = (gpos_class2_record*)vector_at(class0vec, j);

                memset(&gcr->Value1, 0, sizeof(ValueRecord));
            }
        }
    }

    free(coveredArray);

    prunePairAdjustmentLookupRecordsFormat2(table);

    return LF_ERROR_OK;
}

static LF_ERROR GPOS_purgeRightSideClassZero(gpos_pair_adjustment* table)
{
    gpos_pair_adjustment_2* gpa2 = &table->pair_format.format2;

    for (size_t i = 0; i < gpa2->ClassDef2.MapGlyph.count; i++)
    {
        class_map* cm = (class_map*)vector_at(&gpa2->ClassDef2.MapGlyph, i);
        if (cm && cm->Defined == TRUE && cm->Class == 0)
            cm->Defined = FALSE;
    }

    return LF_ERROR_OK;
}

static LF_ERROR remapFormat2(gpos_pair_adjustment_2* f2Table, LF_MAP *remap)
{
    LF_ERROR error;

    error = ClassDef_remapGlyphs(&f2Table->ClassDef2, remap);

    if (error == LF_ERROR_OK)
    {
        error = ClassDef_remapGlyphs(&f2Table->ClassDef1, remap);
    }

    return error;
}

LF_ERROR GPOS_pairAdjustRemapTable(gpos_pair_adjustment* table, LF_MAP *remap)
{
    LF_ERROR error;

    error = Coverage_remapAll(&table->Coverage, remap);

    if ((error == LF_ERROR_OK) || (error == LF_EMPTY_TABLE))
    {
        switch (table->PosFormat)
        {
            case 1:     error = remapFormat1(&table->pair_format.format1, remap);    break;
            case 2:
                {
                        error = remapFormat2(&table->pair_format.format2, remap);
                        if (error == LF_ERROR_OK)
                            error = GPOS_checkCoverageExtras(table, remap);
                        if (error == LF_ERROR_OK)
                            error = GPOS_purgeRightSideClassZero(table);
                }
                break;
            default:    error = LF_BAD_FORMAT;                                       break;
        }
    }

    return error;
}

/* ------------------------------------------------------------------
    @summary
        free the pair adjustment memory and all of it's tables

------------------------------------------------------------------ */
void GPOS_freePairAdjust(gpos_pair_adjustment* table)
{
    Coverage_deleteTable(&table->Coverage);
    switch (table->PosFormat)
    {
    case 1:        freePairAdjustFormat1(&table->pair_format.format1);            break;
    case 2:        freePairAdjustFormat2(&table->pair_format.format2);            break;
    default:    break;
    }

    free(table);
}


/* ------------------------------------------------------------------
    @summary
        free format 1 resources

------------------------------------------------------------------ */
static void freePairAdjustFormat1(gpos_pair_adjustment_1* f1)
{
    LF_MAP_ITER* mapIter;
    rb_tree_node* node;

    mapIter = map_begin(&f1->PairSetMap);
    if (mapIter == NULL)
    {
        DEBUG_LOG_ERROR("out of memory while freeing pair adjustment");
        return;
    }

    node = map_next(mapIter);
    while (node)
    {
        LF_VECTOR* pairSet = (LF_VECTOR*)node->data;
        ULONG j = 0;

        while (j < pairSet->count)
        {
            pair_value_record* record = (pair_value_record*)vector_at(pairSet, j++);
            FREE(record);
        }

        vector_delete(pairSet);
        FREE(pairSet);

        node = map_next(mapIter);
    }

    map_free_iter(mapIter);
    map_clear(&f1->PairSetMap);

    vector_delete(&f1->PairOffsets);
}

/* ------------------------------------------------------------------
    @summary
        free format 2 resources

------------------------------------------------------------------ */
static void freePairAdjustFormat2(gpos_pair_adjustment_2* f2)
{
    USHORT n, m, count1, count2;

    ClassDef_freeTable(&f2->ClassDef1);
    ClassDef_freeTable(&f2->ClassDef2);

    count1 = UTILS_getCount(&f2->Class1Records);
    for (n = 0; n < count1; n++)
    {
        LF_VECTOR* class1Record = (LF_VECTOR*)vector_at(&f2->Class1Records, n);
        count2 = UTILS_getCount(class1Record);
        for (m = 0; m < count2; m++)
        {
            gpos_class2_record* record = (gpos_class2_record*)vector_at(class1Record, m);
            free(record);
        }
        vector_delete(class1Record);
        free(class1Record);
    }

    vector_delete(&f2->Class1Records);
}


/* ----------------------------------------------------------------------------
    @desc
        free up a pair set from memory

    @param
        pairSet     :   pointer to pair set LF_VECTOR.

---------------------------------------------------------------------------- */
static void freePairSetTable(LF_VECTOR* pairset)
{
    USHORT n, count;
    if (pairset)
    {
        count = UTILS_getCount(pairset);                                // get PairSetCount
        for (n = 0; n < count; n++)
        {
            // get the ValueRecord at the pair set
            pair_value_record* record = (pair_value_record*)vector_at(pairset, n);
            free(record);
        }

        vector_delete(pairset);
        free(pairset);
    }
}

static LF_ERROR removeFormat1(gpos_pair_adjustment* table, GlyphID glyphID)
{
    ULONG index = 0;
    USHORT pairOffsetKey;
    gpos_pair_adjustment_1*    f1 = &table->pair_format.format1;
    LF_ERROR error;
    LF_MAP_ITER* mapIter;
    rb_tree_node* node;

    // first examine the FirstGlyph in the pair contained in the coverage
    // table.  if it removes the first glyph, we will need to remove the
    // associated pairset.
//    error = Coverage_removeGlyphIndex(&table->Coverage, glyphID, &index);

    error = Coverage_findGlyphIndex(&table->Coverage, glyphID, &index);

    // was glyph removed from coverage ?
    if (error == LF_ERROR_OK)
    {
        // yes .. so remove the associated pairset
        USHORT pairOffset = (USHORT)(intptr_t)vector_at(&f1->PairOffsets, index);
        error = eraseCoveragePairSet(table, (USHORT)index);
        if (error == LF_EMPTY_TABLE)
        {
            // pairset isn't reference by other first glyph (coverage), so
            // we can remove it from the PairSets.
            erasePairSet(table, pairOffset);
        }
    }

    mapIter = map_begin(&f1->PairSetMap);
    if (mapIter == NULL)
    {
        DEBUG_LOG_ERROR("out of memory while freeing pair adjustment");
        return LF_OUT_OF_MEMORY;
    }

    node = map_next(mapIter);
    while (node)
    {
        LF_VECTOR* pairSetTable = (LF_VECTOR*)node->data;       // get the PairSetTable
        ULONG n2 = 0;

        pairOffsetKey = (USHORT)(intptr_t)node->key;                      // what key are we working on

        // iterate through the pairSetTable, and remove glyphs
        while (n2 < pairSetTable->count)
        {
            pair_value_record* record = (pair_value_record*)vector_at(pairSetTable, n2);

            if (NULL == record)
                return LF_BAD_FORMAT;

            if (record->SecondGlyph == glyphID)
            {
                FREE(record);
                vector_erase(pairSetTable, n2);
            }
            else
            {
                n2++;
            }
        }

        // if the pairSetTable is cleared, then we can clean up the coverage
        // table and remove any other references to this table.
        if (pairSetTable->count == 0)
        {
            removePairSet(table, pairOffsetKey);
        }
        node = map_next(mapIter);
    }
    map_free_iter(mapIter);

    // if the map table is empty, then this rule can removed ... return EMPTY to caller
    if (f1->PairSetMap.count == 0)
    {
        return LF_EMPTY_TABLE;
    }

    return LF_ERROR_OK;
}

/* ----------------------------------------------------------------------------
    @description
        Remove the class reference from the ClassRecords in the Class1Def.  This
        will remove the class reference row in the matrix and remap the the
        Class1Def definitions.

        The Class1Def classes represent the rows in the ClassRecords, so
        by removing a row, we need to free up all of the ClassRecords that are
        associated with the class references.  These are the Class2Def records.

    @param
        f2            : pointer to the pairs format.
        classref    : class that is to be removed from matrix.

    @return
        OK            : removed class reference successfully.
---------------------------------------------------------------------------- */
static LF_ERROR removeClassRecordClassDef1(gpos_pair_adjustment_2* f2, USHORT classref)
{
    LF_ERROR    error = LF_ERROR_OK;
    ULONG       count;
    USHORT      j;

    LF_VECTOR* class2Records = (LF_VECTOR*)vector_at(&f2->Class1Records, classref);

    if (class2Records)
    {
        count = UTILS_getCount(class2Records);

        // loop through the Class2Def ClassRecords, and free the Value1, and Value2
        for (j = 0; j < count; j++)
        {
            gpos_class2_record* record = (gpos_class2_record*)vector_at(class2Records, j);
            free(record);
        }
        vector_delete(class2Records);                                // delete Class2Def ClassRecords vector array
        free(class2Records);                                         // free Class2Def references

        vector_erase(&f2->Class1Records, classref);                  // remove the class reference from matrix

        ClassDef_removeClassID(&f2->ClassDef1, classref, -1);        // remap the classes
        f2->Class1Count = UTILS_getCount(&f2->Class1Records);        // keep the ClassCount in sync
    }
    return error;
}

/* ----------------------------------------------------------------------------
    @description
        Remove the class reference from the ClassRecords in the Class2Def.  This
        will remove the class reference column in the matrix and remap the the
        Class2Def definitions.

        The Class2Def classes represent the columns in the ClassRecords, so
        by removing a column, we need to free the ClassRecords that are
        associated with the class references.

    @param
        f2            : pointer to the pairs format.
        classref      : class2def reference to be removed from matrix.


    @return
        OK            : removed class reference successfully.

---------------------------------------------------------------------------- */
static LF_ERROR removeClassRecordClassDef2(gpos_pair_adjustment_2* f2, USHORT classref)
{
    LF_ERROR ref = LF_ERROR_OK;
    USHORT n;

    for (n = 0; n < f2->Class1Records.count; n++)
    {
        LF_VECTOR* class2Records = (LF_VECTOR*)vector_at(&f2->Class1Records, n);

        if (class2Records)
        {
            gpos_class2_record* record = (gpos_class2_record*)vector_at(class2Records, classref);
            free(record);
            vector_erase(class2Records, classref);
        }

        if (vector_empty(class2Records))
            ref = LF_EMPTY_TABLE;
        else
            ref = LF_ERROR_OK;

        f2->Class2Count = UTILS_getCount(class2Records);
    }
    ClassDef_removeClassID(&f2->ClassDef2, classref, -1);

    return ref;
}

static LF_ERROR validClass2DefClassRecords(gpos_pair_adjustment_2* f2, USHORT classref)
{
    for (size_t n = 0; n < f2->Class1Records.count; n++)
    {
        LF_VECTOR* class2Records = (LF_VECTOR*)vector_at(&f2->Class1Records, n);

        if (class2Records)
        {
            gpos_class2_record* record = (gpos_class2_record*)vector_at(class2Records, classref);
            if (isValueRecordValid(&record->Value1) == LF_ERROR_OK)
                return LF_ERROR_OK;

            if (isValueRecordValid(&record->Value2) == LF_ERROR_OK)
                return LF_ERROR_OK;
        }
    }

    return LF_EMPTY_TABLE;
}

static LF_ERROR removeClass1DefClassReference(gpos_pair_adjustment* table, USHORT classref)
{
    LF_ERROR ref;

    gpos_pair_adjustment_2* f2 = &table->pair_format.format2;

    ref = ClassDef_isClassFormatReferenced(&f2->ClassDef1, classref);
    if (ref == LF_NOT_COVERED)
    {
        DEBUG_LOG_VALUE("ClassDef1 class not referenced", classref);
        removeClassRecordClassDef1(f2, classref);

        f2->Class1Count = UTILS_getCount(&f2->Class1Records);
    }
    return ref;
}

static LF_ERROR removeClass2DefClassReference(gpos_pair_adjustment* table, USHORT classref)
{
    LF_ERROR ref;

    gpos_pair_adjustment_2* f2 = &table->pair_format.format2;

    ref = ClassDef_isClassFormatReferenced(&f2->ClassDef2, classref);
    if (ref == LF_NOT_COVERED)
    {
        ref = removeClassRecordClassDef2(f2, classref);
    }
    return ref;
}

static LF_ERROR removeFormat2(gpos_pair_adjustment* table, GlyphID glyphID)
{
    ULONG index = 0;
    USHORT class_removed = 0;

    LF_ERROR error, coverageError;

    gpos_pair_adjustment_2*    f2 = &table->pair_format.format2;

    error = ClassDef_removeGlyph(&f2->ClassDef2, glyphID, &class_removed);
    if (error == LF_EMPTY_TABLE)
        return error;

    if (error == LF_ERROR_OK)
        error = removeClass2DefClassReference(table, class_removed);

    coverageError = Coverage_removeGlyphIndex(&table->Coverage, glyphID, &index);
    if (coverageError == LF_EMPTY_TABLE)
    {
        return coverageError;
    }

    error = ClassDef_removeGlyph(&f2->ClassDef1, glyphID, &class_removed);
    if (error == LF_ERROR_OK)
        error = removeClass1DefClassReference(table, class_removed);

    return error;
}

static LF_ERROR prunePairAdjustmentLookupRecordsFormat1(gpos_pair_adjustment* table)
{
    LF_ERROR error = LF_ERROR_OK;

    if (Coverage_getCoverageCount(&table->Coverage) == 0)
        error = LF_EMPTY_TABLE;

    return error;
}

/* ------------------------------------------------------------------
    @description
        go through the ValueRecord and checks if there are any
        instructions contained in them.  if the value record
        contains any instruction, then the function returns
        OK, otherwise it returns EMPTY.

    @param
        valueRecord = pointer to ValueRecord structure.

    @return
        OK - ValueRecords contains instructions
        EMPTY - the value records contain no instructions, so
                the record is considered empty.
------------------------------------------------------------------ */
static LF_ERROR isValueRecordValid(ValueRecord* valueRecord)
{
    USHORT value = 0;
    USHORT k, count;
    USHORT* values = (USHORT*)valueRecord;

    count = sizeof(ValueRecord) / sizeof(USHORT);

    for (k = 0; k < count; k++, values++)
    {
        value |= *values;
    }

    if (value)
        return LF_ERROR_OK;

    return LF_EMPTY_TABLE;
}

/* ------------------------------------------------------------------
    @description
        Parses through all of the classes and determines if they are
        relevant any longer, and if not they will remove the
        dependencies that are associated with that class

        go through the Class1Records structure and check if the
        pairing records contain instructions to do any GPOS
        stuff.

        During the removal process, empty place holder value records
        may be the only thing present in the matrix for the pairing.

        if the pairing matrix only contains empty placeholder
        Value records, this function will return EMPTY_TABLE,
        otherwise it will return OK.

    @param
        table = pointer to GPOS pair table.

    @return
        OK - valid ValueRecords are contained in the Matrix
        EMPTY - the value records contain no instructions, so
                the table is considered empty.
------------------------------------------------------------------ */
static LF_ERROR prunePairAdjustmentLookupRecordsFormat2(gpos_pair_adjustment* table)
{
    USHORT n, m, i;
    gpos_pair_adjustment_2* f2 = &table->pair_format.format2;

    ULONG totalClass1Def = ClassDef_getMaxClass(&f2->ClassDef1);
    ULONG totalClass2Def = ClassDef_getMaxClass(&f2->ClassDef2);


    // check if classes match vector count ...
    if (totalClass1Def != (f2->Class1Records.count - 1))
    {
        DEBUG_LOG_ERROR("totalClass1Def count doesn't match ClassRecords count");
    }

    n = 1;
    while (n <= totalClass2Def)
    {
        LF_ERROR status = validClass2DefClassRecords(f2, n);
        if (status == LF_EMPTY_TABLE)
        {
            DEBUG_LOG_VALUE("Removing Class2Def ClassRecord: Value1, Value2 are all zero", n);
            removeClassRecordClassDef2(f2, n);
            totalClass2Def = ClassDef_getMaxClass(&f2->ClassDef2);
        }
        else
        {
            n++;
        }
    }

    if (ClassDef_getMaxClass(&f2->ClassDef2) == 0)
    {
        return LF_EMPTY_TABLE;
    }

    n = 1;
    while ( n < f2->Class1Records.count )
    {
        boolean valid = FALSE;
        LF_VECTOR* records = (LF_VECTOR*)vector_at(&f2->Class1Records, n);

        if (records)
        {
            for (m = 0; m < records->count; m++)
            {
                gpos_class2_record* record = (gpos_class2_record*)vector_at(records, m);
                if (record)
                {
                    if (isValueRecordValid(&record->Value1) == LF_ERROR_OK)
                    {
                        valid = TRUE;
                        break;
                    }

                    if (isValueRecordValid(&record->Value2) == LF_ERROR_OK)
                    {
                        valid = TRUE;
                        break;
                    }
                }
            }
        }
        if (valid == FALSE)
        {
            // this needs to remove the class reference from ClassDef1 and sync up
            // the Coverage table.  ClassDef1 glyphs are all contained in the Coverage
            // table, so any class removal may get rid of
            LF_VECTOR* removedGlyphs = ClassDef_getGlyphsByClass(&f2->ClassDef1, n);
            ULONG index;

            DEBUG_LOG_VALUE("Removing Class1Def ClassRecord: Value1, Value2 are all zero", n);
            removeClassRecordClassDef1(f2, n);
            if (removedGlyphs)
            {
                for (i = 0; i < removedGlyphs->count; i++)
                {
                    GlyphID glyph = (GlyphID)(intptr_t)vector_at(removedGlyphs, i);
                    Coverage_removeGlyphIndex(&table->Coverage, glyph, &index);
                }
                vector_delete(removedGlyphs);
                free(removedGlyphs);
            }

            if (Coverage_getCoverageCount(&table->Coverage) == 0)
            {
                return LF_EMPTY_TABLE;
            }
        }
        else
        {
            n++;
        }
    }

    if (!f2->Class1Records.count)
    {
        return LF_EMPTY_TABLE;
    }

    return LF_ERROR_OK;
}

/* ============================================================================
    @description
        final clean up pass Pairs adjustment
============================================================================ */
LF_ERROR GPOS_prunePairAdjustmentLookupRecords(gpos_pair_adjustment* table)
{
    LF_ERROR error = LF_ERROR_OK;
    base_table* base = (base_table*)table;

    if (base->ignore == 0)
    {
        switch (table->PosFormat)
        {
        case 1:        error = prunePairAdjustmentLookupRecordsFormat1(table);            break;
        case 2:        error = prunePairAdjustmentLookupRecordsFormat2(table);            break;
        default:       error = LF_BAD_FORMAT;                                             break;
        }
    }

    return error;
}

#ifdef LF_OT_DUMP
/* ----------------------------------------------------------------------------
@desc:
dump the PairSet Table to the XML stream.

@param
table           : pointer to the pair_adjustment structure

pairSetTable    : pointer to LF_VECTOR structure containing
pair_value_record structures.

firstGlyph      : the first glyph associated with the pair
adjustment. This is found in the coverage table.

---------------------------------------------------------------------------- */
static void GPOS_dumpPairSetTable(const gpos_pair_adjustment* table, LF_VECTOR* pairSetTable, GlyphID firstGlyph)
{
    ULONG i;

    for (i = 0; i < pairSetTable->count; i++)
    {
        pair_value_record* record = (pair_value_record*)vector_at(pairSetTable, i);

        XML_START_COMMENT_INDEX("PairSetTable", "PairSetTable: ", i, (int)pairSetTable->count - 1);

        XML_DATA_NODE("FirstGlyph", firstGlyph);
        XML_DATA_NODE("SecondGlyph", record->SecondGlyph);

        if (table->ValueFormat1)
        {
            XML_START("Value1");
            dumpValueRecord(table->ValueFormat1, &record->Value1);
            XML_END("Value1");
        }


        if (table->ValueFormat2)
        {
            XML_START("Value2");
            dumpValueRecord(table->ValueFormat2, &record->Value2);
            XML_END("Value2");
        }
        XML_END("PairSetTable");
    }
}


/* ----------------------------------------------------------------------------
@desc:
dump all of the Pair Sets to the XML stream.  creates comments with
each of the pair sets to match up with the coverage table indices and
first glyph reference.

@param
table           : pointer to the pair_adjustment structure

---------------------------------------------------------------------------- */
static void GPOS_dumpPairSetTables(gpos_pair_adjustment* table)
{
    size_t j;
    gpos_pair_adjustment_1* f1 = &table->pair_format.format1;

    Coverage_dumpTable(&table->Coverage);

    for (j = 0; j < f1->PairOffsets.count; j++)
    {
        LF_VECTOR* pairSet = getPairSet(table, (USHORT)j);

        if (pairSet)
        {
            XML_START_COMMENT_INDEX("PairSet", "PairSet: ", (int)j, (int)f1->PairOffsets.count - 1);

            GlyphID firstGlyph;
            LF_ERROR error = Coverage_getCoverageAt(&table->Coverage, (USHORT)j, &firstGlyph);
            if(error == LF_ERROR_OK)
                GPOS_dumpPairSetTable(table, pairSet, firstGlyph);
            else
                XML_DATA_NODE("Coverage_getCoverageAt failed", 0);

            XML_END("PairSet");
        }
    }
}

/* ----------------------------------------------------------------------------
@desc
dump the class records to the XML stream

---------------------------------------------------------------------------- */
static LF_ERROR gpos_dumpClassRecord(gpos_pair_adjustment* table)
{
    LF_VECTOR* records = &table->pair_format.format2.Class1Records;
    USHORT n, i;

    XML_START("ClassPairValues")
        for (n = 0; n < records->count; n++)
        {
            LF_VECTOR* class1Records = (LF_VECTOR*)vector_at(records, n);

            XML_START_COMMENT_INDEX("ClassPairs", "ClassPair for Class1Def: ", n, (int)records->count);

            XML_DATA_NODE("Class1", n);
            XML_START("ClassPair");
            for (i = 0; i < class1Records->count; i++)
            {
                gpos_class2_record* record = (gpos_class2_record*)vector_at(class1Records, i);
                XML_DATA_NODE("Class2", i);
                XML_COMMENT_INDEX("ClassPair Values: ", n, i);

                if (table->ValueFormat1)
                {
                    XML_START("Value1");
                    dumpValueRecord(table->ValueFormat1, &record->Value1);
                    XML_END("Value1");
                }

                if (table->ValueFormat2)
                {
                    XML_START("Value2");
                    dumpValueRecord(table->ValueFormat2, &record->Value2);
                    XML_END("Value2");
                }
            }
            XML_END("ClassPair");
            XML_END("ClassPairs");
    }
    XML_END("ClassPairValues")

        return LF_ERROR_OK;
}

/* ============================================================================
    @description
        dumpe the pair adjustment rule
============================================================================ */
LF_ERROR GPOS_dumpPairAdjustment(gpos_pair_adjustment* table)
{
    XML_START("GPOSPairPositionAdjust");

    XML_DATA_NODE("PosFormat", table->PosFormat);

    switch (table->PosFormat)
    {
    case 1:
        GPOS_dumpPairSetTables(table);
        break;

    case 2:
        Coverage_dumpTable(&table->Coverage);

        XML_DATA_NODE("ValueFormat1", table->ValueFormat1);
        XML_DATA_NODE("ValueFormat2", table->ValueFormat2);

        XML_DATA_NODE("Class1Count", table->pair_format.format2.Class1Count);
        XML_DATA_NODE("Class2Count", table->pair_format.format2.Class2Count);

        XML_START("ClassDef1");
        ClassDef_dump(&table->pair_format.format2.ClassDef1);
        XML_END("ClassDef1");

        XML_START("ClassDef2");
        ClassDef_dump(&table->pair_format.format2.ClassDef2);
        XML_END("ClassDef2");

        gpos_dumpClassRecord(table);
        break;
    default:
        break;
    }

    XML_END("GPOSPairPositionAdjust");

    return LF_ERROR_OK;
}
#endif
