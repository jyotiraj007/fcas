// Copyright (C) 2014 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// gpos_marktoligature.c

#include <stdlib.h>
#include "coverage_table.h"
#include "gpos_lookup/gpos_marktoligature.h"
#include "mark_array.h"

static LF_ERROR GPOS_readLigatureAttach(LF_VECTOR* ligatureAttach, USHORT classCount, LF_STREAM* stream)
{
    size_t tableStart = STREAM_streamPos(stream);
    size_t currPos;
    USHORT componentCount = STREAM_readUShort(stream);
    USHORT i, j = 0;

    vector_init(ligatureAttach, componentCount, 4);

    for(i = 0; i < componentCount; i++)
    {
        LF_VECTOR* componentRecord = vector_create(classCount, 4);

        for(j = 0; j < classCount; j++)
        {
            OFFSET anchorOffset = STREAM_readOffset(stream);

            if(anchorOffset > 0)
            {
                anchor_table* anchorTable = (anchor_table*)malloc(sizeof(anchor_table));

                currPos = STREAM_streamPos(stream);
                STREAM_streamSeek(stream, tableStart + anchorOffset);
                Anchor_readTable(anchorTable, stream);

                vector_push_back(componentRecord, anchorTable);
                STREAM_streamSeek(stream, currPos);
            }
            else
            {
                vector_push_back(componentRecord, NULL);
            }
        }

        vector_push_back(ligatureAttach, componentRecord);
    }

    return LF_ERROR_OK;
}

static LF_ERROR GPOS_readLigatureArray(gpos_marktoligature* table, LF_STREAM* stream)
{
    size_t tableStart = STREAM_streamPos(stream);
    size_t currPos;
    USHORT ligatureCount = STREAM_readUShort(stream);
    USHORT i;

    vector_init(&table->LigatureArray, ligatureCount, 4);

    for(i = 0; i < ligatureCount; i ++)
    {
        OFFSET attachOffset = STREAM_readUShort(stream);
        LF_VECTOR* ligatureAttach = (LF_VECTOR*)malloc(sizeof(LF_VECTOR));

        currPos = STREAM_streamPos(stream);
        STREAM_streamSeek(stream, tableStart + attachOffset);
        GPOS_readLigatureAttach(ligatureAttach, table->ClassCount, stream);

        vector_push_back(&table->LigatureArray, ligatureAttach);
        STREAM_streamSeek(stream, currPos);
    }

    return LF_ERROR_OK;
}

TABLE_HANDLE GPOS_readMarkToLigature(LF_STREAM* stream)
{
    gpos_marktoligature* table = (gpos_marktoligature*)malloc(sizeof(gpos_marktoligature));
    size_t tableStart = STREAM_streamPos(stream);
    size_t oldOffset;
    size_t coverageOffset;
    size_t markOffset;
    size_t baseOffset;

    if(table == NULL)
        return NULL;

    table->PosFormat = STREAM_readUShort(stream);

    //read mark coverage
    coverageOffset = STREAM_readOffset(stream);
    oldOffset = STREAM_streamPos(stream);
    STREAM_streamSeek(stream, tableStart + coverageOffset);
    Coverage_readTable(&table->MarkCoverage, stream);
    STREAM_streamSeek(stream, oldOffset);

    //read base coverage
    coverageOffset = STREAM_readOffset(stream);
    oldOffset = STREAM_streamPos(stream);
    STREAM_streamSeek(stream, tableStart + coverageOffset);
    Coverage_readTable(&table->LigatureCoverage, stream);
    STREAM_streamSeek(stream, oldOffset);

    table->ClassCount = STREAM_readUShort(stream);
    markOffset = STREAM_readOffset(stream);
    baseOffset = STREAM_readOffset(stream);

    STREAM_streamSeek(stream, tableStart + markOffset);
    Mark_readArray(&table->MarkArray, stream);

    //read LigatureArray table
    STREAM_streamSeek(stream, tableStart + baseOffset);
    GPOS_readLigatureArray(table, stream);

    return table;
}

static size_t GPOS_getLigatureAttachSize(LF_VECTOR* ligatureAttach)
{
    size_t tableSize = sizeof(USHORT);
    ULONG i, j;

    for(i = 0; i < ligatureAttach->count; i++)
    {
        LF_VECTOR* record = (LF_VECTOR*)vector_at(ligatureAttach, i);

        for(j = 0; j < record->count; j++)
        {
            size_t anchorSize = 0;
            anchor_table* anchor = (anchor_table*)vector_at(record, j);
            if(anchor)
                Anchor_getTableSize(anchor, &anchorSize);
            tableSize += anchorSize + sizeof(OFFSET);
        }
    }

    return tableSize;
}

static size_t GPOS_getLigatureArraySize(LF_VECTOR* ligatureArray)
{
    size_t tableSize = sizeof(USHORT);
    ULONG i;

    for(i = 0; i < ligatureArray->count; i++)
    {
        LF_VECTOR* ligatureAttach = (LF_VECTOR*)vector_at(ligatureArray, i);
        tableSize += GPOS_getLigatureAttachSize(ligatureAttach);
        tableSize += sizeof(OFFSET);
    }

    return tableSize;
}

size_t GPOS_getMarkToLigatureSize(gpos_marktoligature* table)
{
    size_t tableSize = sizeof(USHORT) * 2 + sizeof(OFFSET) * 4;
    size_t markSize = 0;
    size_t baseSize = 0;

    Coverage_getTableSize(&table->MarkCoverage, &markSize);
    Coverage_getTableSize(&table->LigatureCoverage, &baseSize);
    tableSize += markSize + baseSize;

    Mark_getArraySize(&table->MarkArray, &markSize);
    baseSize = GPOS_getLigatureArraySize(&table->LigatureArray);

    tableSize += markSize + baseSize;

    //tableSize = (tableSize + 3) & ~3;
    return tableSize;
}

static LF_ERROR GPOS_buildLigatureAttach(LF_VECTOR* ligatureAttach, LF_STREAM* stream)
{
    size_t tableStart = STREAM_streamPos(stream);
    size_t endPos;
    size_t currPos;
    ULONG i, j = 0;
    LF_VECTOR* record;

    record = (LF_VECTOR*)vector_at(ligatureAttach, 0);

    // #components * #classes -  All the class counts for the components should be the same since they will
    // have a NULL filler if a class isn't covered.
    endPos = tableStart + sizeof(USHORT) + sizeof(OFFSET) * (ligatureAttach->count * record->count) ;

    STREAM_writeUShort(stream, (USHORT)ligatureAttach->count);

    for(i = 0; i < ligatureAttach->count; i++)
    {
        record = (LF_VECTOR*)vector_at(ligatureAttach, i);

        for(j = 0; j < record->count; j++)
        {
            anchor_table* anchor = (anchor_table*)vector_at(record, j);

            if(anchor)
                STREAM_writeOffset(stream, (LONG)(endPos - tableStart));
            else
                STREAM_writeOffset(stream, 0);

            currPos = STREAM_streamPos(stream);
            STREAM_streamSeek(stream, endPos);

            if(anchor)
                Anchor_buildTable(anchor, stream);
            endPos = STREAM_streamPos(stream);
            STREAM_streamSeek(stream, currPos);
        }
    }
    STREAM_streamSeek(stream,endPos);                // Restore to end of table for calling function
    return LF_ERROR_OK;
}

static LF_ERROR GPOS_buildLigatureArray(gpos_marktoligature* table, LF_STREAM* stream)
{
    size_t tableStart = STREAM_streamPos(stream);
    size_t endPos = tableStart + sizeof(USHORT) + sizeof(OFFSET) * table->LigatureArray.count;
    size_t currPos;
    ULONG i;

    STREAM_writeUShort(stream, (USHORT)table->LigatureArray.count);

    for(i = 0; i < table->LigatureArray.count; i++)
    {
        LF_VECTOR* ligatureAttach = (LF_VECTOR*)vector_at(&table->LigatureArray, i);

        STREAM_writeOffset(stream, (USHORT)(endPos - tableStart));
        currPos = STREAM_streamPos(stream);
        STREAM_streamSeek(stream, endPos);
        GPOS_buildLigatureAttach(ligatureAttach, stream);
        endPos = STREAM_streamPos(stream);
        STREAM_streamSeek(stream, currPos);
    }
    STREAM_streamSeek(stream,endPos);            // Restore to end of table for calling function
    return LF_ERROR_OK;
}

size_t GPOS_buildMarkToLigature(gpos_marktoligature* table, LF_STREAM* stream)
{
    size_t tableStart = STREAM_streamPos(stream);
    size_t currPos;
    size_t endPos = sizeof(USHORT) * 2 + sizeof(OFFSET) * 4;

    STREAM_writeUShort(stream, table->PosFormat);

    //write mark coverage table
    STREAM_writeOffset(stream, (OFFSET)endPos);
    currPos = STREAM_streamPos(stream);
    STREAM_streamSeek(stream, tableStart + endPos);
    Coverage_buildTable(&table->MarkCoverage, stream);
    endPos = STREAM_streamPos(stream) - tableStart;

    //write base coverage table
    STREAM_streamSeek(stream, currPos);
    STREAM_writeOffset(stream, (OFFSET)endPos);
    currPos = STREAM_streamPos(stream);
    STREAM_streamSeek(stream, tableStart + endPos);
    Coverage_buildTable(&table->LigatureCoverage, stream);
    endPos = STREAM_streamPos(stream) - tableStart;

    STREAM_streamSeek(stream, currPos);
    STREAM_writeUShort(stream, table->ClassCount);

    //write mark array
    STREAM_writeOffset(stream, (OFFSET)endPos);
    currPos = STREAM_streamPos(stream);
    STREAM_streamSeek(stream, tableStart + endPos);
    Mark_buildArray(&table->MarkArray, stream);
    endPos = STREAM_streamPos(stream) - tableStart;

    //write ligature array table
    STREAM_streamSeek(stream, currPos);
    STREAM_writeOffset(stream, (OFFSET)endPos);
    STREAM_streamSeek(stream, tableStart + endPos);
    GPOS_buildLigatureArray(table, stream);

    return STREAM_streamPos(stream) - tableStart;
}

LF_ERROR GPOS_markToLigatureRemoveGlyph(gpos_marktoligature* table, GlyphID glyphID)
{
    ULONG index = 0;
    LF_VECTOR* ligatureAttach;
    LF_ERROR error = Coverage_removeGlyphIndex(&table->MarkCoverage, glyphID, &index);

    // no coverage, then we are done and we can eliminate the entire table
    if (error == LF_EMPTY_TABLE)
        return error;

    if(error == LF_ERROR_OK)
    {
        error = Mark_removeAtIndex(&table->MarkArray, index);
    }

    error = Coverage_removeGlyphIndex(&table->LigatureCoverage, glyphID, &index);

    if(error == LF_ERROR_OK)
    {

// Remove the entire Ligature Attach table associated with the covered glyph.
// Walk each LigatureAttach table in the Ligature Array and then free up all of the
// anchor tables for each of them.  Don't bother to erase the vectors underneath the one at ligatureAttach
// they will all get rolled up with ligatureAttach.

        ligatureAttach = (LF_VECTOR*)vector_at(&table->LigatureArray, index);
        if (ligatureAttach)
        {
            ULONG i = 0;
            while (i < ligatureAttach->count)
            {
                LF_VECTOR* compoundRecord = (LF_VECTOR*)vector_at(ligatureAttach, i++);
                ULONG j = 0;

                while (j < compoundRecord->count)
                {
                    anchor_table* anchorTable = (anchor_table*)vector_at(compoundRecord, j++);
                    if (anchorTable)
                    {
                        free(anchorTable);
                    }
                }
                vector_delete(compoundRecord);
                free(compoundRecord);
            }
            vector_delete(ligatureAttach);
            free(ligatureAttach);
        }
        error = vector_erase(&table->LigatureArray, index);
    }
    return error;
}

LF_ERROR GPOS_markToLigatureRemapTable(gpos_marktoligature* table, LF_MAP *remap)
{
    LF_ERROR error = Coverage_remapAll(&table->MarkCoverage, remap);

    if((error == LF_ERROR_OK) || (error == LF_EMPTY_TABLE))
    {
        error = Coverage_remapAll(&table->LigatureCoverage, remap);
    }

    return error;
}

LF_ERROR GPOS_markToLigatureSetAnchorFmt1(gpos_marktoligature* table)
{
    for (size_t i = 0; i < table->LigatureArray.count; i++)
    {
        LF_VECTOR* ligatureAttach = (LF_VECTOR*)vector_at(&table->LigatureArray, i);

        for (size_t j = 0; j < ligatureAttach->count; j++)
        {
            LF_VECTOR* componentRecord = (LF_VECTOR*)vector_at(ligatureAttach, j);

            for (size_t k = 0; k < componentRecord->count; k++)
            {
                anchor_table* anchor = (anchor_table*)vector_at(componentRecord, k);

                if (anchor)
                {
                    if (anchor->AnchorFormat == 2)
                        anchor->AnchorFormat = 1;
                }
            }
        }
    }

    return Mark_setAnchorFormat1(&table->MarkArray);
}

#ifdef LF_OT_DUMP
#include "utils.h"

LF_ERROR GPOS_dumpMarkToLigature(gpos_marktoligature* table)
{
    ULONG i, j, k;

    XML_START("GPOSMarkToLigature");

    XML_DATA_NODE("PosFormat", table->PosFormat);

    XML_START("LigatureCoverage");
    Coverage_dumpTable(&table->LigatureCoverage);
    XML_END("LigatureCoverage");

    XML_START("MarkCoverage");
    Coverage_dumpTable(&table->MarkCoverage);
    XML_END("MarkCoverage");

    XML_START("LigatureArray")
    for (i = 0; i < table->LigatureArray.count; i++)
    {
        LF_VECTOR* ligatureAttach = (LF_VECTOR*)vector_at(&table->LigatureArray, i);

        if (ligatureAttach)
        {
            XML_START("CompoundRecords")
            for (j = 0; j < ligatureAttach->count; j++)
            {
                LF_VECTOR* compoundRecord = (LF_VECTOR*)vector_at(ligatureAttach, j);

                XML_START("AnchorTables");
                for (k = 0; k < compoundRecord->count; k++)
                {
                    anchor_table* anchorTable = (anchor_table*)vector_at(compoundRecord, k);
                    XML_COMMENT_INDEX("AnchorTable", k, (int)compoundRecord->count);
                    Anchor_dumpTable(anchorTable);
                }
                XML_END("AnchorTables");
            }
            XML_END("CompoundRecords")
        }
    }
    XML_END("LigatureArray")


    // TODO: output the table->MarkArray

    XML_END("GPOSMarkToLigature");
    return LF_ERROR_OK;
}
#endif

void GPOS_freeMarkToLigature(gpos_marktoligature* table)
{
    ULONG i = 0;
    Coverage_deleteTable(&table->LigatureCoverage);
    Coverage_deleteTable(&table->MarkCoverage);

    Mark_freeArray(&table->MarkArray);

    while (i < table->LigatureArray.count)
    {
        LF_VECTOR* ligatureAttach = (LF_VECTOR*)vector_at(&table->LigatureArray, i++);

        if (ligatureAttach)
        {
            ULONG j = 0;
            while (j < ligatureAttach->count)
            {
                LF_VECTOR* compoundRecord = (LF_VECTOR*)vector_at(ligatureAttach, j++);
                ULONG k = 0;

                while (k < compoundRecord->count)
                {
                    anchor_table* anchorTable = (anchor_table*)vector_at(compoundRecord, k++);
                    if (anchorTable)
                    {
                        Anchor_freeTable(anchorTable);
                        free(anchorTable);
                    }
                }
                vector_delete(compoundRecord);
                free(compoundRecord);
            }
            vector_delete(ligatureAttach);
            free(ligatureAttach);
        }
    }
    vector_delete(&table->LigatureArray);

    free(table);
}


