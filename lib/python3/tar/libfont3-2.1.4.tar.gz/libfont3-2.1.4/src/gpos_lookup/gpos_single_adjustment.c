// Copyright (C) 2014 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// gpos_single_adjustment.c

#include <stdlib.h>
#include "data_types.h"
#include "stream.h"
#include "utils.h"
//#include "gpos_table.h"
#include "gpos_lookup/gpos_single_adjustment.h"

static void freeSingleAdjust1(gpos_single_adjustment_1* sa1);
static void freeSingleAdjust2(gpos_single_adjustment_2* sa2);


TABLE_HANDLE GPOS_readSingleAdjustment(LF_STREAM* stream)
{
    gpos_single_adjustment* table = (gpos_single_adjustment*)calloc(1, sizeof(gpos_single_adjustment));
    if(table == NULL)
        return NULL;

    size_t tableStart = STREAM_streamPos(stream);
    size_t oldOffset = 0;
    OFFSET coverageOffset = 0;

    table->PosFormat = STREAM_readUShort(stream);

    if (table->PosFormat == 0 || table->PosFormat > 2)
    {
        DEBUG_LOG_ERROR("GPOS single substitution format invalid");
        free(table);
        return NULL;
    }

    coverageOffset = STREAM_readOffset(stream);
    oldOffset = STREAM_streamPos(stream);
    STREAM_streamSeek(stream, tableStart + coverageOffset);

    LF_ERROR error = Coverage_readTable(&table->Coverage, stream);
    if (error != LF_ERROR_OK)
    {
        if (error != LF_EMPTY_TABLE)
            goto singleFailed;
    }

    STREAM_streamSeek(stream, oldOffset);
    table->ValueFormat = STREAM_readUShort(stream);

    if(table->PosFormat == 1)
    {
        readValueRecord(table->ValueFormat, &table->format.format1.Value, stream);
    }
    else
    {
        USHORT valueCount = STREAM_readUShort(stream);
        USHORT i = 0;

        error = vector_init(&table->format.format2.Values, valueCount, 4);
        if (error != LF_ERROR_OK)
        {
            //TODO cleanup
            free(table);
            return NULL;
        }

        for(i = 0; i < valueCount; i++)
        {
            ValueRecord* value = (ValueRecord*)malloc(sizeof(ValueRecord));
            if (value == NULL)
            {
                //TODO cleanup
                free(table);
                return NULL;
            }

            readValueRecord(table->ValueFormat, value, stream);

            vector_push_back(&table->format.format2.Values, value);
        }
    }
    return table;

singleFailed:
    GPOS_freeSingleAdjust(table);
    return NULL;
}

size_t GPOS_getSingleAdjustmentSize(gpos_single_adjustment* table)
{
    size_t tableSize = 0;
    ULONG valueSize = getValueRecordSize(table->ValueFormat);

    Coverage_getTableSize(&table->Coverage, &tableSize);
    tableSize += sizeof(USHORT) * 2 + sizeof(OFFSET);

    if(table->PosFormat == 1)
    {
        tableSize += valueSize;
    }
    else
    {
        if (table->Coverage.isAscending == TRUE)
        {
            tableSize += sizeof(USHORT) + valueSize * table->format.format2.Values.count;
        }
        else
        {
            // the coverage table is out of order, so some things in it will
            // be removed when constructed so that is accounted for here
            tableSize += sizeof(USHORT) + valueSize * table->Coverage.build_1.GlyphCount;
        }
    }

    //tableSize = (tableSize + 3) & ~3;
    return tableSize;
}

size_t GPOS_buildSingleAdjustment(gpos_single_adjustment* table, LF_STREAM* stream)
{
    size_t tableStart = STREAM_streamPos(stream);
    size_t coverageOffset = 0;
    size_t offset = 0;
    size_t oldPos = 0;

    STREAM_writeUShort(stream, table->PosFormat);
    coverageOffset = STREAM_streamPos(stream);    //for assigment later
    STREAM_writeUShort(stream, 0);
    STREAM_writeUShort(stream, table->ValueFormat);

    if (table->PosFormat == 1)
    {
        writeValueRecord(table->ValueFormat, &table->format.format1.Value, stream);
    }
    else
    {
        ULONG i = 0;

        if (table->Coverage.isAscending == FALSE)
        {
            size_t count = table->Coverage.CoverageMap.count;

            boolean* skipArray = calloc(count, sizeof(boolean));
            if (skipArray == NULL)
                return 0;

            GlyphID lastUsed = 0;

            for (size_t n = 0; n < count; n++)
            {
                GlyphID gid = (GlyphID)(intptr_t)vector_at(&table->Coverage.CoverageMap, n);

                if ((n != 0) && (gid <= lastUsed))
                    skipArray[n] = TRUE;
                else
                    lastUsed = gid;
            }

            for (LONG j = (LONG)(count - 1); j >= 0; j--)
            {
                if (skipArray[j] == TRUE)
                {
                    ValueRecord* value = (ValueRecord*)vector_at(&table->format.format2.Values, j);
                    free(value);
                    vector_erase(&table->format.format2.Values, j);
                }
            }
            free(skipArray);
        }

        STREAM_writeUShort(stream, (USHORT)table->format.format2.Values.count);

        for (i = 0; i < table->format.format2.Values.count; i++)
        {
            ValueRecord* value = (ValueRecord*)vector_at(&table->format.format2.Values, i);
            writeValueRecord(table->ValueFormat, value, stream);
        }
    }

    oldPos = STREAM_streamPos(stream);
    offset = oldPos - tableStart;
    STREAM_streamSeek(stream, coverageOffset);
    STREAM_writeUShort(stream, (USHORT)offset);
    STREAM_streamSeek(stream, oldPos);

    Coverage_buildTable(&table->Coverage, stream);

    return STREAM_streamPos(stream) - tableStart;
}

LF_ERROR GPOS_singleAdjustRemoveGlyph(gpos_single_adjustment* table, GlyphID glyphID)
{
    ULONG index = 0;
    LF_ERROR error = Coverage_removeGlyphIndex(&table->Coverage, glyphID, &index);


    // if not Ok, then we are done here
    if(error != LF_ERROR_OK)
        return error;


    if(table->PosFormat == 2)
    {
        ValueRecord* value = (ValueRecord*)vector_at(&table->format.format2.Values, index);
        free(value);
        vector_erase(&table->format.format2.Values, index);
    }

    return error;
}

LF_ERROR GPOS_singleAdjustRemapTable(gpos_single_adjustment* table, LF_MAP *remap)
{
    return Coverage_remapAll(&table->Coverage, remap);
}

void GPOS_freeSingleAdjust(gpos_single_adjustment* sa)
{
    switch (sa->PosFormat)
    {
    case 1:        freeSingleAdjust1(&sa->format.format1);        break;
    case 2:        freeSingleAdjust2(&sa->format.format2);        break;
    default:    break;
    }
    Coverage_deleteTable(&sa->Coverage);
    free(sa);
}

#ifdef LF_OT_DUMP
/* ============================================================================
    @brief 
        dump the single adjust structure.

============================================================================ */
LF_ERROR GPOS_dumpSingleAdjust(gpos_single_adjustment* sa)
{
    XML_START("GPOSSingle");

    XML_DATA_NODE("PosFormat", sa->PosFormat);

    Coverage_dumpTable(&sa->Coverage);

    // TODO: finish the dump code for multiple formats

    XML_END("GPOSSingle");
    return LF_ERROR_OK;
}
#endif

// free up single adjust format 2
static void freeSingleAdjust1(gpos_single_adjustment_1* sa1)
{
    UNUSED(sa1);
}


static void freeSingleAdjust2(gpos_single_adjustment_2* sa2)
{
    ULONG i = 0;
    // loop through the vector array and free all of the elements...
    while(i < sa2->Values.count)
    {
        ValueRecord* value = (ValueRecord*)vector_at(&sa2->Values, i++);
        free(value);
    }
    vector_delete(&sa2->Values);
}

