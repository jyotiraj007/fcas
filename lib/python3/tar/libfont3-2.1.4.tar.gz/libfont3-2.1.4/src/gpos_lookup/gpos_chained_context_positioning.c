// Copyright (C) 2014 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// gpos_chained_context_positioning.c

#include <memory.h>
#include <stdlib.h>

#include "utils.h"
#include "coverage_table.h"
#include "gpos_lookup/gpos_chained_context_positioning.h"
#include "chain_set.h"
#include "chain_class_set.h"
#include "classdef.h"


static LF_ERROR    contextPos_readFormat1(chain_context_pos_format1* cpf1, LF_STREAM* stream);
static size_t      contextPos_buildFormat1(chain_context_pos_format1* cpf1, LF_STREAM* stream);
static size_t      contextPos_sizeFormat1(chain_context_pos_format1* cpf1);
static void        contextPos_freeFormat1(chain_context_pos_format1* cpf1);
static LF_ERROR    contextPos_removeFormat1(chain_context_pos_format1* cpf1, GlyphID glyphid);
static LF_ERROR    chainContextPos_cleanupLookupsFormat1(chain_context_pos_format1* ccpf1, TABLE_HANDLE hLookup);


static LF_ERROR    contextPos_readFormat2(chain_context_pos_format2* cpf2, LF_STREAM* stream);
static size_t      contextPos_buildFormat2(chain_context_pos_format2* cpf2, LF_STREAM* stream);
static size_t      contextPos_sizeFormat2(chain_context_pos_format2* cpf2);
static void        contextPos_freeFormat2(chain_context_pos_format2* cpf2);
static LF_ERROR    contextPos_removeFormat2(chain_context_pos_format2* cpf2, GlyphID glyphid);
static LF_ERROR    chainContextPos_removeLookupIndexFormat2(chain_context_pos_format2* cpf2, USHORT lookupIndex, SHORT deltaIndex);
static LF_ERROR    chainContextPos_pruneLookupRecordsFormat2(chain_context_pos_format2* csf2);
//static void        contextPos_dumpFormat2(chain_context_pos_format2* cpf2);
static LF_ERROR    chainContextPos_cleanupLookupsFormat2(chain_context_pos_format2* ccpf2, TABLE_HANDLE hLookup);


static LF_ERROR    contextPos_readFormat3(chain_context_pos_format3* cpf3, LF_STREAM* stream);
static size_t      contextPos_buildFormat3(chain_context_pos_format3* cpf3, LF_STREAM* stream);
static size_t      contextPos_sizeFormat3(chain_context_pos_format3* cpf3);
static void        contextPos_freeFormat3(chain_context_pos_format3* cpf3);
static LF_ERROR    contextPos_removeFormat3(chain_context_pos_format3* cpf3, GlyphID glyphid);
static LF_ERROR    chainContextPos_cleanupLookupsFormat3(chain_context_pos_format3* ccpf3, TABLE_HANDLE hLookup);


/* ****************************************************************************

    Chained Context Positioning

**************************************************************************** */

TABLE_HANDLE GPOS_readChainContextPositioning(LF_STREAM* stream)
{
    gpos_chain_context_positioning*    cp;
    LF_ERROR error = LF_ERROR_OK;

    ASSERT(stream);

    cp = (gpos_chain_context_positioning*)malloc(sizeof(gpos_chain_context_positioning));
    if (!cp)
    {
        DEBUG_LOG_ERROR("Failed to allocated gpos_context_positioning structure");
        return NULL;
    }

    memset(cp, 0, sizeof(gpos_chain_context_positioning));
    cp->PosFormat = STREAM_readUShort(stream);                            // stream format ...

    switch (cp->PosFormat)
    {
    case 1:        error = contextPos_readFormat1(&cp->ccp.f1, stream);        break;
    case 2:        error = contextPos_readFormat2(&cp->ccp.f2, stream);        break;
    case 3:        error = contextPos_readFormat3(&cp->ccp.f3, stream);        break;
    default:    break;
    }

    if (error != LF_ERROR_OK)
    {
        DEBUG_LOG_ERROR("Failed to gpos chained context positioning");
        FREE(cp);
        return NULL;
    }

    return (TABLE_HANDLE)cp;
}

LF_ERROR GPOS_removeChainContextPositioning(gpos_chain_context_positioning* cp, GlyphID glyphid)
{
    LF_ERROR error = LF_ERROR_OK;

    switch (cp->PosFormat)
    {
    case 1:    error = contextPos_removeFormat1(&cp->ccp.f1, glyphid);    break;
    case 2:    error = contextPos_removeFormat2(&cp->ccp.f2, glyphid);    break;
    case 3:    error = contextPos_removeFormat3(&cp->ccp.f3, glyphid);    break;
    default: error = LF_BAD_FORMAT;                                       break;
    }

    return error;
}

size_t GPOS_buildChainContextPositioning(gpos_chain_context_positioning* cp, LF_STREAM* stream)
{
    size_t ret = 0;

    ASSERT(cp);
    ASSERT(stream);

    if (cp)
    {
        STREAM_writeUShort(stream, cp->PosFormat);

        switch (cp->PosFormat)
        {
            case 1:     ret = contextPos_buildFormat1(&cp->ccp.f1, stream);     break;
            case 2:     ret = contextPos_buildFormat2(&cp->ccp.f2, stream);     break;
            case 3:     ret = contextPos_buildFormat3(&cp->ccp.f3, stream);     break;
            default:    ret = (size_t)-1;                                       break;
        }
    }
    return ret;
}

size_t GPOS_sizeChainContextPositioning(gpos_chain_context_positioning* cp)
{
    size_t size = 0;
    ASSERT(cp);

    if (cp)
    {
        size = sizeof(USHORT);                            // PosFormat

        switch (cp->PosFormat)
        {
            case 1:        size += contextPos_sizeFormat1(&cp->ccp.f1);        break;
            case 2:        size += contextPos_sizeFormat2(&cp->ccp.f2);        break;
            case 3:        size += contextPos_sizeFormat3(&cp->ccp.f3);        break;
            default:    size = 0;
        }
    }
    return size;
}

void GPOS_freeChainContextPositioning(gpos_chain_context_positioning* cp)
{
    ASSERT(cp);

    if (cp)
    {
        switch (cp->PosFormat)
        {
            case 1:        contextPos_freeFormat1(&cp->ccp.f1);        break;
            case 2:        contextPos_freeFormat2(&cp->ccp.f2);        break;
            case 3:        contextPos_freeFormat3(&cp->ccp.f3);        break;
            default:    break;
        }
    }
    FREE(cp);
}


/* ****************************************************************************

    FORMAT 1

**************************************************************************** */

static LF_ERROR contextPos_readFormat1(chain_context_pos_format1* cpf1, LF_STREAM* stream)
{
    LF_ERROR error = LF_ERROR_OK;
    USHORT    count;
    size_t    curOffset, newOffset, baseOffset;

    ASSERT(cpf1);
    ASSERT(stream);

    // read Coverage
    baseOffset = STREAM_streamPos(stream) - sizeof(USHORT);            // base offset - SubstFormat
    newOffset = STREAM_readOffset(stream) + baseOffset;                // Coverage OFFSET
    curOffset = STREAM_streamPos(stream);
    STREAM_streamSeek(stream, newOffset);

    error = Coverage_readTable(&cpf1->Coverage, stream);
    if (error != LF_ERROR_OK)
    {
        if (error != LF_EMPTY_TABLE)
        {
            DEBUG_LOG_ERROR("Problem reading coverage table");
            return error;
        }
    }

    STREAM_streamSeek(stream, curOffset);

    // read SubRuleSet
    count = STREAM_readUShort(stream);
    error = vector_init(&cpf1->ChainPosRuleSet, count, sizeof(ULONG));
    if (error != LF_ERROR_OK)
    {
        DEBUG_LOG_ERROR("Problem creating SubRuleSet");
        goto Fail1;
    }

    error = ChainSets_readRuleSets(&cpf1->ChainPosRuleSet, count, stream, (ULONG)baseOffset);
    if (error != LF_ERROR_OK)
    {
        DEBUG_LOG_ERROR("failed to read ChainPosRuleSet");
        goto Fail1;
    }

    return error;

Fail1:
    contextPos_freeFormat1(cpf1);
    return error;
}

static size_t contextPos_buildFormat1(chain_context_pos_format1* cpf1, LF_STREAM* stream)
{
    size_t  baseOffset, curOffset;
    size_t  coverageOffset, arrayOffset, offset;
    USHORT  n, count;

    ASSERT(cpf1);
    ASSERT(stream);

    baseOffset = STREAM_streamPos(stream) - sizeof(USHORT);           // start of positioning table minus PosFormat
    coverageOffset = STREAM_streamPos(stream);                        // Coverage OFFSET inside stream
    STREAM_writeOffset(stream, 0);                                    // placeholder value for coverage offset

    count = UTILS_getCount(&cpf1->ChainPosRuleSet);
    STREAM_writeUShort(stream, count);                                // ChainSubRuleSetCount

    arrayOffset = Common_buildEmptyArray(stream, count);
    Coverage_buildCoverage(&cpf1->Coverage, stream, (ULONG)coverageOffset, (ULONG)baseOffset);

    // loop through subrule sets
    for (n = 0; n < count; n++)
    {
        chain_set* cs = (chain_set*)vector_at(&cpf1->ChainPosRuleSet, n);

        // update offset array
        curOffset = STREAM_streamPos(stream);
        offset = curOffset - baseOffset;
        STREAM_streamSeek(stream, arrayOffset);
        STREAM_writeOffset(stream, (USHORT)offset);
        arrayOffset += sizeof(OFFSET);

        STREAM_streamSeek(stream, curOffset);

        ChainSet_buildRuleSet(cs, stream);
    }
    return STREAM_streamPos(stream);
}

static size_t contextPos_sizeFormat1(chain_context_pos_format1* cpf1)
{
    size_t size = 0;
    size_t coverageSize;
    // LF_ERROR error;

    ASSERT(cpf1);

    /*error = */Coverage_getTableSize(&cpf1->Coverage, &coverageSize);
    size += coverageSize;
    size += sizeof(OFFSET);                                    // Coverage Offset
    size += sizeof(USHORT);                                    // ChainSubRuleSetCount
    size += sizeof(OFFSET) * cpf1->ChainPosRuleSet.count;      // ChainSubRuleSet[ChainSubRuleSetCount]

    size += ChainSets_sizeRuleSets(&cpf1->ChainPosRuleSet);

    return size;
}

static void contextPos_freeFormat1(chain_context_pos_format1* cpf1)
{
    Coverage_deleteTable(&cpf1->Coverage);
    ChainSets_freeRuleSets(&cpf1->ChainPosRuleSet);
}

static LF_ERROR contextPos_removeFormat1(chain_context_pos_format1* cpf1, GlyphID glyphid)
{
    LF_ERROR error = LF_ERROR_OK;
    ULONG    coverageIndex;

    ASSERT(cpf1);

    // 1rst stage, remove coverage match ups with the posrule sets.
    error = Coverage_removeGlyphIndex(&cpf1->Coverage, glyphid, &coverageIndex);
    if (error == LF_EMPTY_TABLE)
        return error;

    if ( error == LF_ERROR_OK)
    {
        // Top level pruning of the rules - match Coverage index to SubRuleSets index.
        chain_set* cs = (chain_set*)vector_at(&cpf1->ChainPosRuleSet, coverageIndex);

        ChainSet_freeRuleSet(cs);
        FREE(cs);
        vector_erase(&cpf1->ChainPosRuleSet, coverageIndex);
    }

    error = ChainSets_pruneRuleSets(&cpf1->ChainPosRuleSet, &cpf1->Coverage, glyphid);

    return error;
}




/* ****************************************************************************

    FORMAT 2

**************************************************************************** */
static LF_ERROR contextPos_readFormat2(chain_context_pos_format2* cpf2, LF_STREAM* stream)
{
    LF_ERROR    error;
    USHORT      count;
    size_t      curOffset, newOffset, baseOffset;
    ULONG       backtrackOffset, inputOffset, lookaheadOffset;

    ASSERT(cpf2);
    ASSERT(stream);

    baseOffset = STREAM_streamPos(stream) - sizeof(USHORT);

    // Coverage
    newOffset = STREAM_readUShort(stream) + baseOffset;
    curOffset = STREAM_streamPos(stream);
    STREAM_streamSeek(stream, newOffset);

    error    = Coverage_readTable(&cpf2->Coverage, stream);
    STREAM_streamSeek(stream, curOffset);

    // Offsets
    backtrackOffset        = STREAM_readOffset(stream);
    inputOffset            = STREAM_readOffset(stream);
    lookaheadOffset        = STREAM_readOffset(stream);

    count = STREAM_readUShort(stream);

    error = ClassDef_readEmptyOrClassDefinition(&cpf2->BacktrackClassDef, MAX_CLASSDEF, backtrackOffset, (ULONG)baseOffset, stream);
    if (error != LF_ERROR_OK)
    {
        DEBUG_LOG_ERROR("problem reading Backtrack ClassDef");
        goto Fail1;
    }

    error = ClassDef_readEmptyOrClassDefinition(&cpf2->InputClassDef, count, inputOffset, (ULONG)baseOffset, stream);
    if (error != LF_ERROR_OK)
    {
        DEBUG_LOG_ERROR("problem reading Input ClassDef");
        goto Fail1;
    }

    error = ClassDef_readEmptyOrClassDefinition(&cpf2->LookaheadClassDef, MAX_CLASSDEF, lookaheadOffset, (ULONG)baseOffset, stream);
    if (error != LF_ERROR_OK)
    {
        DEBUG_LOG_ERROR("problem reading Lookahead ClassDef");
        goto Fail1;
    }

    error = ChainClassSets_readSets(&cpf2->InputClassDef,
                                    &cpf2->BacktrackClassDef,
                                    &cpf2->LookaheadClassDef,
                                    &cpf2->ChainPosClassSet, count, stream, (ULONG)baseOffset);

    if (error != LF_ERROR_OK)
        goto Fail1;

    return LF_ERROR_OK;

Fail1:
    contextPos_freeFormat2(cpf2);
    return error;
}

static size_t contextPos_buildFormat2(chain_context_pos_format2* cpf2, LF_STREAM* stream)
{
    size_t    baseOffset;
    size_t    coverageOffset, arrayOffset;
    size_t    BacktrackOffset, InputClassOffset, LookaheadOffset;
    USHORT   count;

    ASSERT(cpf2);
    ASSERT(stream);

    baseOffset = STREAM_streamPos(stream) - sizeof(USHORT);           // start of Substitution table

    coverageOffset = STREAM_streamPos(stream);
    STREAM_writeOffset(stream, 0);                                    // placeholder value for coverage offset

    BacktrackOffset = STREAM_streamPos(stream);                       // BacktrackOffset Offset position
    STREAM_writeOffset(stream, 0);                                    // placeholder value for BacktrackOffset offset

    InputClassOffset = STREAM_streamPos(stream);                      // InputClassOffset Offset position
    STREAM_writeOffset(stream, 0);                                    // placeholder value for InputClassOffset offset

    LookaheadOffset = STREAM_streamPos(stream);                       // LookaheadOffset Offset position
    STREAM_writeOffset(stream, 0);                                    // placeholder value for LookaheadOffset offset

    count = UTILS_getCount(&cpf2->ChainPosClassSet);
    STREAM_writeUShort(stream, count);                                // ChainPosClassSetCnt
    arrayOffset = Common_buildEmptyArray(stream, count);              // Create empty array

    Coverage_buildCoverage(&cpf2->Coverage, stream, (ULONG)coverageOffset, (ULONG)baseOffset);
    Common_buildClassDef(&cpf2->BacktrackClassDef, stream, (ULONG)BacktrackOffset, (ULONG)baseOffset);
    Common_buildClassDef(&cpf2->InputClassDef, stream, (ULONG)InputClassOffset, (ULONG)baseOffset);
    Common_buildClassDef(&cpf2->LookaheadClassDef, stream, (ULONG)LookaheadOffset, (ULONG)baseOffset);

    ChainClassSets_buildSets(&cpf2->ChainPosClassSet, stream, (ULONG)arrayOffset, (ULONG)baseOffset);

    return STREAM_streamPos(stream);
}

static size_t contextPos_sizeFormat2(chain_context_pos_format2* cpf2)
{
    size_t size = 0, coverageSize, classSize;

    ASSERT(cpf2);

    size += sizeof(OFFSET);                // Coverage OFFSET
    size += sizeof(OFFSET);                // BacktrackClassDef OFFSET
    size += sizeof(OFFSET);                // InputClassDef OFFSET
    size += sizeof(OFFSET);                // LookaheadClassDef OFFSET

    size += sizeof(USHORT);                // ChainSubClassSetCnt

    size += sizeof(OFFSET) * cpf2->ChainPosClassSet.count;        // Offset array for ChainPosClassSetCnt]
    size += ChainClassSets_sizeSets(&cpf2->ChainPosClassSet);

    Coverage_getTableSize(&cpf2->Coverage, &coverageSize);
    size += coverageSize;

    ClassDef_getTableSize(&cpf2->BacktrackClassDef, &classSize);
    size += classSize;

    ClassDef_getTableSize(&cpf2->InputClassDef, &classSize);
    size += classSize;

    ClassDef_getTableSize(&cpf2->LookaheadClassDef, &classSize);
    size += classSize;

    return size;
}

static void contextPos_freeFormat2(chain_context_pos_format2* cpf2)
{
    ASSERT(cpf2);

    Coverage_deleteTable(&cpf2->Coverage);

    ClassDef_freeTable(&cpf2->BacktrackClassDef);
    ClassDef_freeTable(&cpf2->InputClassDef);
    ClassDef_freeTable(&cpf2->LookaheadClassDef);

    ChainClassSets_freeSets(&cpf2->ChainPosClassSet);
}

static LF_ERROR contextPos_removeFormat2(chain_context_pos_format2* cpf2, GlyphID glyphid)
{
    LF_ERROR     error;
    ULONG        coverageIndex;
    USHORT       removeSet;

    ASSERT(cpf2);

    // 1rst stage, remove coverage match ups with the subrule sets.
    error = Coverage_removeGlyphIndex(&cpf2->Coverage, glyphid, &coverageIndex);

    if (error == LF_EMPTY_TABLE)
    {
        // no coverage, the subrule can be eliminated
        return error;
    }

    error = ClassDef_removeGlyph(&cpf2->BacktrackClassDef, glyphid, &removeSet);
    error = ClassDef_removeGlyph(&cpf2->LookaheadClassDef, glyphid, &removeSet);
    error = ClassDef_removeGlyph(&cpf2->InputClassDef, glyphid, &removeSet);

    return error;
}


#if 0 // not used
static void contextPos_dumpFormat2(chain_context_pos_format2* cpf2)
{
    Coverage_dumpTable(&cpf2->Coverage);

    DEBUG_LOG("===== Backtrack ClassDef");
    ClassDef_dump(&cpf2->BacktrackClassDef);

    DEBUG_LOG("===== Input ClassDef");
    ClassDef_dump(&cpf2->InputClassDef);

    DEBUG_LOG("===== Lookahead ClassDef");
    ClassDef_dump(&cpf2->LookaheadClassDef);

    ChainClassSets_dumpSets(&cpf2->ChainPosClassSet);
}
#endif



/* ****************************************************************************

    FORMAT 3

**************************************************************************** */
static LF_ERROR contextPos_readFormat3(chain_context_pos_format3* cpf3, LF_STREAM* stream)
{
    LF_ERROR error = LF_ERROR_OK;
    size_t        baseOffset;
    USHORT        count;

    ASSERT(cpf3);
    ASSERT(stream);

    baseOffset = STREAM_streamPos(stream) - sizeof(USHORT);            // account for the format identifier

    count = STREAM_readUShort(stream);
    error = Coverage_readArray(&cpf3->BacktrackGlyphCoverage, count, stream, (ULONG)baseOffset);
    if (error != LF_ERROR_OK)
        goto Fail1;


    count = STREAM_readUShort(stream);
    error = Coverage_readArray(&cpf3->InputGlyphCoverage, count, stream, (ULONG)baseOffset);
    if (error != LF_ERROR_OK)
        goto Fail1;

    count = STREAM_readUShort(stream);
    error = Coverage_readArray(&cpf3->LookaheadGlyphCoverage, count, stream, (ULONG)baseOffset);
    if (error != LF_ERROR_OK)
        goto Fail1;


    count = STREAM_readUShort(stream);
    error = Common_readSubstLookupRecords(&cpf3->PosLookupRecord, count, stream);
    if (error != LF_ERROR_OK)
        goto Fail1;

    return error;

Fail1:
    DEBUG_LOG_ERROR("Problem occurred reading in Chained Context Format 3");
    contextPos_freeFormat3(cpf3);
    return error;
}

static size_t contextPos_buildFormat3(chain_context_pos_format3* cpf3, LF_STREAM* stream)
{
    USHORT    count;
    size_t    baseOffset;
    size_t    BacktrackOffset, InputClassOffset, LookaheadOffset;

    ASSERT(cpf3);
    ASSERT(stream);

    baseOffset = STREAM_streamPos(stream) - sizeof(USHORT);             // start of Substitution table

    count = UTILS_getCount(&cpf3->BacktrackGlyphCoverage);
    STREAM_writeUShort(stream, count);                                  // BacktrackGlyphCount
    BacktrackOffset = Common_buildEmptyArray(stream, count);            // Coverage[BacktrackGlyphCount] Array of Offsets

    count = UTILS_getCount(&cpf3->InputGlyphCoverage);
    STREAM_writeUShort(stream, count);                                  // InputGlyphCount
    InputClassOffset = Common_buildEmptyArray(stream, count);           // Coverage[InputGlyphCount] Array of Offsets

    count = UTILS_getCount(&cpf3->LookaheadGlyphCoverage);
    STREAM_writeUShort(stream, count);                                  // LookaheadGlyphCount
    LookaheadOffset = Common_buildEmptyArray(stream, count);            // Coverage[LookaheadGlyphCount] Array of Offsets

    count = UTILS_getCount(&cpf3->PosLookupRecord);
    STREAM_writeUShort(stream, count);
    Common_buildSubstLookupRecords(&cpf3->PosLookupRecord, stream);

    Coverage_buildTables(&cpf3->BacktrackGlyphCoverage, stream, (ULONG)baseOffset, (ULONG)BacktrackOffset);
    Coverage_buildTables(&cpf3->InputGlyphCoverage, stream, (ULONG)baseOffset, (ULONG)InputClassOffset);
    Coverage_buildTables(&cpf3->LookaheadGlyphCoverage, stream, (ULONG)baseOffset, (ULONG)LookaheadOffset);

    return STREAM_streamPos(stream);
}

static size_t contextPos_sizeFormat3(chain_context_pos_format3* cpf3)
{
    size_t size = 0;

    ASSERT(cpf3);

    size += sizeof(USHORT);                                         // BacktrackGlyphCount
    size += sizeof(OFFSET) * cpf3->BacktrackGlyphCoverage.count;    // Coverage[BacktrackGlyphCount]

    size += sizeof(USHORT);                                         // InputGlyphCount
    size += sizeof(OFFSET) * cpf3->InputGlyphCoverage.count;        // Coverage[InputGlyphCount]

    size += sizeof(USHORT);                                         // LookaheadGlyphCount
    size += sizeof(OFFSET) * cpf3->LookaheadGlyphCoverage.count;    // Coverage[LookaheadGlyphCount]

    size += sizeof(USHORT);                                         // PosCount
    size += Common_sizeSubstLookupRecords(&cpf3->PosLookupRecord);  // PosLookupRecord[PosCount]

    size += Coverage_sizeCoverages(&cpf3->BacktrackGlyphCoverage);
    size += Coverage_sizeCoverages(&cpf3->InputGlyphCoverage);
    size += Coverage_sizeCoverages(&cpf3->LookaheadGlyphCoverage);

    return size;
}

static void contextPos_freeFormat3(chain_context_pos_format3* cpf3)
{
    ASSERT(cpf3);

    Coverage_deleteCoverageTables(&cpf3->BacktrackGlyphCoverage);
    Coverage_deleteCoverageTables(&cpf3->InputGlyphCoverage);
    Coverage_deleteCoverageTables(&cpf3->LookaheadGlyphCoverage);
    Common_freeSubstLookupRecords(&cpf3->PosLookupRecord);
}


/* ----------------------------------------------------------------------------
    @description
        Checks if the coverage table for input is empty, and if it
        is, the entire subrule is eliminated.

        it will also prune the backtrack and lookahead coverages as
        well.

---------------------------------------------------------------------------- */
static LF_ERROR contextPos_removeFormat3(chain_context_pos_format3* cpf3, GlyphID glyphid)
{
    LF_ERROR error;

    ASSERT(cpf3);

    error = Coverage_removeCoveragesGlyphIndex(&cpf3->BacktrackGlyphCoverage, glyphid);
    if (error == LF_EMPTY_TABLE)
        return LF_EMPTY_TABLE;

    error = Coverage_removeCoveragesGlyphIndex(&cpf3->LookaheadGlyphCoverage, glyphid);
    if (error == LF_EMPTY_TABLE)
        return LF_EMPTY_TABLE;

    error = Coverage_removeCoveragesGlyphIndex(&cpf3->InputGlyphCoverage, glyphid);
    if (error == LF_EMPTY_TABLE)
        return LF_EMPTY_TABLE;

    return LF_ERROR_OK;
}


static LF_ERROR chainContextPos_removeLookupIndexFormat1(chain_context_pos_format1* f1, USHORT lookupIndex, SHORT deltaIndex)
{
    LF_ERROR error = ChainSets_removeLookupRecordIndex(&f1->ChainPosRuleSet, lookupIndex, deltaIndex);
    return error;
}

static LF_ERROR chainContextPos_removeLookupIndexFormat2(chain_context_pos_format2* cpf2, USHORT lookupIndex, SHORT deltaIndex)
{
    return ChainClassSets_removeLookupRecordIndex(&cpf2->ChainPosClassSet, lookupIndex, deltaIndex);
}

static LF_ERROR    chainContextPos_removeLookupIndexFormat3(chain_context_pos_format3* f3, USHORT lookupIndex, SHORT deltaIndex)
{
    LF_ERROR error = Common_removeLookupListIndex(&f3->PosLookupRecord, lookupIndex, deltaIndex);
    return error;
}

LF_ERROR GPOS_removeChainContextPositioningLookupIndex(gpos_chain_context_positioning* cp, USHORT lookupIndex, SHORT deltaIndex)
{
    LF_ERROR error = LF_ERROR_OK;

    switch (cp->PosFormat)
    {
    case 1:    error = chainContextPos_removeLookupIndexFormat1(&cp->ccp.f1, lookupIndex, deltaIndex);    break;
    case 2:    error = chainContextPos_removeLookupIndexFormat2(&cp->ccp.f2, lookupIndex, deltaIndex);    break;
    case 3:    error = chainContextPos_removeLookupIndexFormat3(&cp->ccp.f3, lookupIndex, deltaIndex);    break;
    default: error = LF_BAD_FORMAT;                                                                       break;
    }

    return error;
}

static LF_ERROR chainContextPos_remapTableFormat1(chain_context_pos_format1* f1, LF_MAP *remap)
{
    LF_ERROR error = Coverage_remapAll(&f1->Coverage, remap);

    if((error == LF_ERROR_OK) || (error == LF_EMPTY_TABLE))
    {
        error = ChainSet_remapRulesSets(&f1->ChainPosRuleSet, remap);
    }

    return error;
}

static LF_ERROR chainContextPos_remapTableFormat2(chain_context_pos_format2* f2, LF_MAP *remap)
{
    LF_ERROR error = Coverage_remapAll(&f2->Coverage, remap);

    if((error == LF_ERROR_OK) || (error == LF_EMPTY_TABLE))
    {
        error = ClassDef_remapGlyphs(&f2->BacktrackClassDef, remap);
    }
    if((error == LF_ERROR_OK) || (error == LF_EMPTY_TABLE))
    {
        error = ClassDef_remapGlyphs(&f2->InputClassDef, remap);
    }
    if((error == LF_ERROR_OK) || (error == LF_EMPTY_TABLE))
    {
        error = ClassDef_remapGlyphs(&f2->LookaheadClassDef, remap);
    }

    return error;
}

static LF_ERROR chainContextPos_remapTableFormat3(chain_context_pos_format3* f3, LF_MAP *remap)
{
    LF_ERROR error;
    USHORT i, count;
    coverage_table *ct;

    count = UTILS_getCount(&f3->BacktrackGlyphCoverage);
    
    for(i = 0; i < count; i++)
    {
        ct = (coverage_table *)vector_at(&f3->BacktrackGlyphCoverage, i);

        error = Coverage_remapAll(ct, remap);
    }

    count = UTILS_getCount(&f3->InputGlyphCoverage);

    for(i = 0; i < count; i++)
    {
        ct = (coverage_table *)vector_at(&f3->InputGlyphCoverage, i);

        error = Coverage_remapAll(ct, remap);
    }

    count = UTILS_getCount(&f3->LookaheadGlyphCoverage);

    for(i = 0; i < count; i++)
    {
        ct = (coverage_table *)vector_at(&f3->LookaheadGlyphCoverage, i);

        error = Coverage_remapAll(ct, remap);
    }

    (void)error; // only real error could be LF_INVALID_INDEX;  LF_EMPTY_TABLE is not a problem

    return LF_ERROR_OK;
}

LF_ERROR GPOS_ChainContextPositioningRemapTable(gpos_chain_context_positioning* ccp, LF_MAP *remap)
{
    LF_ERROR error = LF_ERROR_OK;

    switch (ccp->PosFormat)
    {
    case 1:    error = chainContextPos_remapTableFormat1(&ccp->ccp.f1, remap);    break;
    case 2:    error = chainContextPos_remapTableFormat2(&ccp->ccp.f2, remap);    break;
    case 3:    error = chainContextPos_remapTableFormat3(&ccp->ccp.f3, remap);    break;
    default: error = LF_BAD_FORMAT;                                               break;
    }

    return error;
}


/* ****************************************************************************


    PRUNE CHAIN CONTEXT RECORDS


**************************************************************************** */
static LF_ERROR chainContextPos_pruneLookupRecordsFormat1(chain_context_pos_format1* csf1)
{
    UNUSED(csf1);
    return LF_ERROR_OK;
}

static LF_ERROR chainContextPos_pruneLookupRecordsFormat2(chain_context_pos_format2* cpf2)
{
    LF_ERROR        error = LF_ERROR_OK;

    error = ChainClassSets_validClassRules(&cpf2->ChainPosClassSet);

    if (error != LF_EMPTY_TABLE)
    {
        context_classes    context;

        memset(&context, 0, sizeof(context_classes));

        context.Backtrack    = &cpf2->BacktrackClassDef;
        context.Input        = &cpf2->InputClassDef;
        context.LookAhead    = &cpf2->LookaheadClassDef;
        context.Coverage    = &cpf2->Coverage;

        error = ChainClassSets_pruneLookupRecords(&cpf2->ChainPosClassSet, &context);
        if (error == LF_EMPTY_TABLE)
            return LF_EMPTY_TABLE;

        // after pruning is complete, there may be some unused classes lying about,
        // so this method will remove them from the ClassDef structures if they
        // exist, or rather don't exist in the ClassRules.
        ChainClassSets_removeUnusedClasses(&cpf2->ChainPosClassSet, &context);


        // if there is nothing in the input class definition, then all of the
        // sequences have no possible context for matching.  Therefore we
        // can eliminate this rule.
        if (ClassDef_isTableEmpty(&cpf2->InputClassDef))
            return LF_EMPTY_TABLE;

        // check if final cleanup cleared the coverage table?
        if (Coverage_getCoverageCount(&cpf2->Coverage) == 0)
            return LF_EMPTY_TABLE;
    }
    return error;
}

static LF_ERROR chainContextPos_pruneLookupRecordsFormat3(chain_context_pos_format3* csf3)
{
    UNUSED(csf3);
    return LF_ERROR_OK;
}

LF_ERROR GPOS_pruneChainContextPosLookupRecords(gpos_chain_context_positioning* ccp)
{
    LF_ERROR error = LF_ERROR_OK;

    switch(ccp->PosFormat)
    {
    case 1:        error = chainContextPos_pruneLookupRecordsFormat1(&ccp->ccp.f1);        break;
    case 2:        error = chainContextPos_pruneLookupRecordsFormat2(&ccp->ccp.f2);        break;
    case 3:        error = chainContextPos_pruneLookupRecordsFormat3(&ccp->ccp.f3);        break;
    default:    error = LF_BAD_FORMAT;                                                     break;
    }
    return error;
}

LF_ERROR GPOS_cleanupChainContextLookups(gpos_chain_context_positioning* ccp, TABLE_HANDLE hLookup)
{
    LF_ERROR    error;

    switch(ccp->PosFormat)
    {
    case 1:        error = chainContextPos_cleanupLookupsFormat1(&ccp->ccp.f1, hLookup);            break;
    case 2:        error = chainContextPos_cleanupLookupsFormat2(&ccp->ccp.f2, hLookup);            break;
    case 3:        error = chainContextPos_cleanupLookupsFormat3(&ccp->ccp.f3, hLookup);            break;
    default:    error = LF_BAD_FORMAT;                                                              break;
    }

    return error;
}

static LF_ERROR chainContextPos_cleanupLookupsFormat1(chain_context_pos_format1* ccpf1, TABLE_HANDLE hLookup)
{
    LF_ERROR    error = ChainSets_cleanupLookups(&ccpf1->ChainPosRuleSet, hLookup);
    return error;
}

static LF_ERROR chainContextPos_cleanupLookupsFormat2(chain_context_pos_format2* ccpf2, TABLE_HANDLE hLookup)
{
    LF_ERROR    error = LF_ERROR_OK;
    error = ChainClassSets_cleanupLookups(&ccpf2->ChainPosClassSet, hLookup);

    return error;
}

static LF_ERROR chainContextPos_cleanupLookupsFormat3(chain_context_pos_format3* ccpf3, TABLE_HANDLE hLookup)
{
    LF_ERROR    error = LF_ERROR_OK;
    Common_cleanupLookups(&ccpf3->PosLookupRecord, hLookup);
    return error;
}
