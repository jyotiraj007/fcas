// Copyright (C) 2014 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// base_table.c

#include <memory.h>
#include "data_types.h"
#include "base_table.h"

/* ============================================================================
    @summary
        initialize the base instance for the substitution structure.  this
        base class is always at the start of the gsub structure and will
        contain all of the common structures and data members required
        for parsing the substitution rules.

    @param
        table   :    pointer to the subtable containing the base_table.

        parent  :    the parent table.

============================================================================ */
void BaseTable_init(TABLE_HANDLE table, TABLE_HANDLE parent)
{
    base_table* base = (base_table*)table;

    memset(base, 0, sizeof(base_table));

    base->parent = (base_table*)parent;
}

void BaseTable_setType(TABLE_HANDLE table, eBaseTableTypes type, eBaseSubTableTypes subtype)
{
    base_table* base = (base_table*)table;

    base->type = type;
    base->subType = subtype;
}

eBaseSubTableTypes BaseTable_getSubType(TABLE_HANDLE table)
{
    base_table* base = (base_table*)table;
    return base->subType;
}

void BaseTable_setParent(TABLE_HANDLE table, TABLE_HANDLE parent)
{
    base_table* base = (base_table*)table;
    base->parent = (base_table*)parent;
}


void BaseTable_setPrevLookup(TABLE_HANDLE table, ULONG index)
{
    base_table* base = (base_table*)table;
    base->prevLookupIndex = index;
    base->nextLookupIndex = index;
}

void BaseTable_setNextLookup(TABLE_HANDLE table, ULONG index)
{
    base_table* base = (base_table*)table;
    base->nextLookupIndex = index;
}

#ifdef LF_OT_DUMP
#include "utils.h"

/* ----------------------------------------------------------------------------
    @desc
        dump the table type

    @param
        table       :   pointer to base_table structure
---------------------------------------------------------------------------- */
static void BaseTable_dumpType(TABLE_HANDLE table)
{
    base_table* base = (base_table*)table;
    char strtype[2048];

    switch (base->type)
    {
    case TABLETYPE_GPOS:
        sprintf(strtype, "GPOS");
        break;
    case TABLETYPE_GSUB:
        sprintf(strtype, "GSUB");
        break;
    case TABLETYPE_FEATURE:
        sprintf(strtype, "FEATURE");
        break;
    case TABLETYPE_SCRIPT:
        sprintf(strtype, "SCRIPT");
        break;
    case TABLETYPE_LOOKUP:
        sprintf(strtype, "LOOKUP");
        break;
    default:
        sprintf(strtype, "Unknown");
        break;
    }
    XML_NODE("Type", strtype);
}

void BaseTable_dump(TABLE_HANDLE table)
{
    base_table* base = (base_table*)table;
    XML_START("BaseTable");
    BaseTable_dumpType(table);
    XML_DATA_NODE("PrevLookupIndex", base->prevLookupIndex);
    XML_DATA_NODE("NextLookupIndex", base->nextLookupIndex);
    XML_DATA_NODE("Ignore", base->ignore);
    XML_END("BaseTable");
}

USHORT BaseTable_isDump(TABLE_HANDLE table)
{
    base_table* base = (base_table*)table;

    return base->dump;
}
#endif
