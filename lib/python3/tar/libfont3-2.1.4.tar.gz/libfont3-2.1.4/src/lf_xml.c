// Copyright (C) 2014 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// lf_xml.c

#include <string.h>
#include "stream.h"
#include "lf_xml.h"

LF_ERROR XML_WriteStartTag(LF_STREAM* stream, const char* name, boolean newLine, size_t* size)
{
    if (stream) {
        *size += STREAM_writeByte(stream, XML_CHAR_LT);
        *size += STREAM_writeChunk(stream, (const BYTE*)name, strlen(name));
        *size += STREAM_writeByte(stream, XML_CHAR_GT);

        if (newLine)
            *size += STREAM_writeByte(stream, XML_NEWLINE);
    }
    else {
        *size += (newLine ? 3 : 2) + strlen(name);
    }

    return LF_ERROR_OK;
}

LF_ERROR XML_WriteEndTag(LF_STREAM* stream, const char* name, size_t* size)
{
    if (stream) {
        *size += STREAM_writeChunk(stream, (const BYTE*)XML_END_TAG, 2);
        *size += STREAM_writeChunk(stream, (const BYTE*)name, strlen(name));
        *size += STREAM_writeByte(stream, XML_CHAR_GT);
        *size += STREAM_writeByte(stream, XML_NEWLINE);
    }
    else {
        *size += 4 + strlen(name);
    }

    return LF_ERROR_OK;
}

LF_ERROR XML_WriteAttribute(LF_STREAM* stream, const char* attribute, const char* value, size_t* size)
{
    if (stream) {
        *size += STREAM_writeByte(stream, XML_SPACE);
        *size += STREAM_writeChunk(stream, (const BYTE*)attribute, strlen(attribute));
        *size += STREAM_writeByte(stream, XML_EQUAL_SIGN);
        *size += STREAM_writeByte(stream, XML_CHAR_QUOTE);
        *size += STREAM_writeChunk(stream, (const BYTE*)value, strlen(value));
        *size += STREAM_writeByte(stream, XML_CHAR_QUOTE);
    }
    else {
        *size += 4 + strlen(attribute) + strlen(value);
    }

    return LF_ERROR_OK;
}

LF_ERROR XML_WriteXMLDeclaration(LF_STREAM* stream, const char* version, const char* encoding, const char* standalone, size_t* size)
{
    if (stream) {
        *size += STREAM_writeChunk(stream, (const BYTE*)XML_PROCESSING_INSTRUCTION_START, 2);
        *size += STREAM_writeChunk(stream, (const BYTE*)XML_PREFIX, 3);
    }
    else {
        *size += 5;
    }

    if (version)
    {
        XML_WriteAttribute(stream, XML_VERSION_ATTRIBUTE, version, size);
    }

    if (encoding)
    {
        XML_WriteAttribute(stream, XML_ENCODING_ATTRIBUTE, encoding, size);
    }

    UNUSED(standalone);

    if (stream) {
        *size += STREAM_writeChunk(stream, (const BYTE*)XML_PROCESSING_INSTRUCTION_END, 2);
        *size += STREAM_writeByte(stream, XML_NEWLINE);
    }
    else {
        *size += 3;
    }

    return LF_ERROR_OK;
}

LF_ERROR XML_WriteXMLDocumentType(LF_STREAM* stream, const char* name, const char* publicID, const char* systemID, size_t* size)
{
    if (stream) {
        *size += STREAM_writeChunk(stream, (const BYTE*)XML_DOCTYPE_START, 2);
        *size += STREAM_writeChunk(stream, (const BYTE*)XML_DOCTYPE_NAME, 7);
        *size += STREAM_writeByte(stream, XML_SPACE);
        *size += STREAM_writeChunk(stream, (const BYTE*)name, strlen(name));
        *size += STREAM_writeByte(stream, XML_SPACE);
        *size += STREAM_writeChunk(stream, (const BYTE*)XML_PUBLIC_ID_NAME, 6);
        *size += STREAM_writeByte(stream, XML_SPACE);
        *size += STREAM_writeChunk(stream, (const BYTE*)publicID, strlen(publicID));
        *size += STREAM_writeByte(stream, XML_SPACE);
        *size += STREAM_writeChunk(stream, (const BYTE*)systemID, strlen(systemID));
        *size += STREAM_writeByte(stream, XML_CHAR_GT);
        *size += STREAM_writeByte(stream, XML_NEWLINE);
    }
    else {
        *size += 21 + strlen(name) + strlen(publicID) + strlen(systemID);
    }

    return LF_ERROR_OK;
}
