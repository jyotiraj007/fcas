// Copyright (C) 2015 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// cff_dump.c

#include "cff_table.h"
#include "cff_core.h"
#include "lf_map.h"
#include "table_tags.h"


static void dump_summary(const cff_table *table)
{
    printf("Summary {\n");
    printf("    CID font: %s\n", (table->cffTable->isCID == TRUE) ? "Yes" : "No");
    printf("    Charstring Index size: %u\n", cff_indexGetLength(table->cffTable->charStringsIndex));
    printf("    Global subroutine Index size: %u\n", cff_indexGetLength(table->cffTable->globalSubrIndex));
    if (table->cffTable->isCID == TRUE)
    {
        LONG numFDs = cff_indexGetCount(table->cffTable->FDIndex);
        printf("    Number of FONT Dicts: %d\n", numFDs);
        printf("    Sizes of local subroutine Indexes: ");
        for (LONG i = 0; i < numFDs; i++)
            printf("%u ", (table->cffTable->fdInfo[i].localSubr != NULL) ? cff_indexGetLength(table->cffTable->fdInfo[i].localSubr) : 0);
        printf("\n");
    }
    else
        printf("    Local subroutine Index size: %u\n", (table->cffTable->localSubrIndex != NULL) ? cff_indexGetLength(table->cffTable->localSubrIndex) : 0);

    printf("}\n");
}

static void dump_header(const cff_table *table)
{
    printf("Table Header {\n");
    printf("    Major Version: %u\n", table->cffTable->header.major);
    printf("    Minor Version: %u\n", table->cffTable->header.minor);
    printf("    Header Size  : %u\n", table->cffTable->header.hdrSize);
    printf("    Offset Size  : %u\n", table->cffTable->header.offSize);
    printf("}\n");
}

static void dump_nameINDEX(const cff_table *table)
{
    cffIndex* nmIndex = table->cffTable->nameIndex;

    printf("Name Index {\n");
    printf("    Size of Name Index   : %u\n", cff_indexGetLength(nmIndex));
    printf("    Number of font names : %u\n", nmIndex->count);
    printf("    Size of array element: %u\n", nmIndex->offSize);

    printf("    Names:\n");
    for (ULONG i = 0; i < nmIndex->content.count; i++)
    {
        cffIndexItem* obj = cff_indexGetItem(nmIndex, i);
        char tmpName[128];
        if (obj->length > 127)
            printf("warning! invalid name length!!\n");
        size_t tocopy = (obj->length > 127) ? 127 : obj->length;
        memcpy(tmpName, obj->data, tocopy);
        tmpName[tocopy] = 0;
        printf("        %s\n", (char*)tmpName);
    }
    printf("}\n");
}

static void dump_topDictINDEX(const cff_table *table)
{
    cffIndex* tdIndex = table->cffTable->topDictIndex;

    printf("Top DICT Index {\n");
    printf("    Number of Top Dicts  : %u\n", tdIndex->count);
    printf("    Size of array element: %u\n", tdIndex->offSize);

    printf("    Top DICTs info       :\n");
    for (ULONG i = 0; i < tdIndex->content.count; i++)
    {
        cffIndexItem* obj = cff_indexGetItem(tdIndex, i);

        printf("        length of Top DICT %u: %u\n", i, obj->length);
    }
    printf("}\n");
}

static void dump_aTopDict(const CFFTOPDICT *td, boolean isFONTDICT)
{
    if (isFONTDICT == FALSE)
        printf("Top DICT Content {\n");
    else
        printf("Font DICT Content {\n");
    printf("    version SID: %u\n", td->version);
    printf("    Notice SID: %u\n", td->Notice);
    printf("    Copyright SID: %u\n", td->copyright);
    printf("    FullName SID: %u\n", td->FullName);
    printf("    FamilyName SID: %u\n", td->FamilyName);
    printf("    Weight SID: %u\n", td->Weight);
    printf("    isFixedPitch: %s\n", td->isFixedPitch ? "YES" : "NO");
    printf("    ItalicAngle: %1.3f\n", td->italicAngle);
    printf("    UnderlinePosition: %d\n", td->underlinePosition);
    printf("    UnderlineThickness: %d\n", td->underlineThickness);
    printf("    PaintType: %d\n", td->PaintType);
    printf("    CharstringType: %d\n", td->charstringType);
    printf("    FontMatrix: [%1.5f %1.5f %1.5f %1.5f %1.5f %1.5f]\n", td->fontmatrix[0], td->fontmatrix[1], td->fontmatrix[2],
                                                                      td->fontmatrix[3], td->fontmatrix[4], td->fontmatrix[5]);
    printf("    UniqueID: %d\n", td->UniqueID);
    printf("    FontBBox: [%d %d %d %d]\n", td->fontbbox[0], td->fontbbox[1], td->fontbbox[2], td->fontbbox[3]);
    printf("    XUID: ");
    if (td->numXUID == 0)
        printf(" <none>\n");
    else
    {
        for (int i = 0; i < td->numXUID; i++)
            printf("%d ", td->XUID[i]);
        printf("\n");
    }
    printf("    charset:  offset %d\n", td->charsetOffset);
    printf("    Encoding:  offset %d\n", td->encodingOffset);
    printf("    CharStrings:  offset %d\n", td->charStringsOffset);
    printf("    Private Dict:  offset %d size %d\n", td->privateDictOffset, td->privateDictSize);
    printf("    SyntheticBase: %d\n", td->SyntheticBase);
    printf("    PostScript SID: %u\n", td->PostScript);
    printf("    BaseFontName SID: %u\n", td->BaseFontName);
    printf("    BaseFontBlend:   ");
    if (td->numBaseFontBlendVals == 0)
        printf("<none>\n");
    else
    {
        for (int i = 0; i < td->numBaseFontBlendVals; i++)
            printf("%d ", td->BaseFontBlend[i]);
        printf("\n");
    }
    printf("\n");
    printf("    CID info:\n");
    printf("    ROS: %u %u %d\n", td->ros.Registry, td->ros.Ordering, td->ros.Supplement);
    printf("    CIDFontVersion: %1.3f\n", td->CIDFontVersion);
    printf("    CIDFontRevision: %d\n", td->CIDFontRevision);
    printf("    CIDFontType: %d\n", td->CIDFontType);
    printf("    CIDCount: %d\n", td->CIDcount);
    printf("    UIDBase: %d\n", td->UIDBase);
    printf("    FDArray: offset %d\n", td->FDArrayOffset);
    printf("    FDSelect: offset %d\n", td->FDSelectOffset);
    printf("    FDFontName: %u\n", td->FDFontName);
    printf("}\n");
}

static void dump_theTopDict(const cff_table *table)
{
    dump_aTopDict(table->cffTable->mainTopDict, FALSE);
}

static void dump_stringINDEX(const cff_table *table)
{
    cffIndex* strIndex = table->cffTable->stringIndex;

    printf("String Index {\n");
    printf("    Size of String Index : %u\n", cff_indexGetLength(strIndex));
    printf("    Number of Strings    : %u\n", cff_indexGetCount(strIndex));
    printf("    Size of array element: %u\n", strIndex->offSize);

    int numStdStrings = 391;// NUM_STD_STRINGS;// sizeof(ISOAdobeNAME) / 24; // == 391

    printf("    Strings:\n");
    for (ULONG i = 0; i < strIndex->content.count; i++)
    {
        cffIndexItem* obj = cff_indexGetItem(strIndex, i);

        char tmpName[256];
        if (obj->length > 255)
            printf("warning - string below is truncated\n");
        memcpy(tmpName, obj->data, obj->length > 255 ? 255 : obj->length);
        tmpName[obj->length > 255 ? 255 : obj->length] = 0;
        printf("        (%u) %s\n", numStdStrings + i, (char*)tmpName);
    }
    printf("}\n");
}

static void dump_globalSubrINDEX(const cff_table *table, boolean brief)
{
    cffIndex* gsubrIndex = table->cffTable->globalSubrIndex;

    printf("Global Subroutine Index {\n");
    printf("    Size of Global Subroutine Index : %u\n", cff_indexGetLength(gsubrIndex));
    printf("    Number of Global Subroutines    : %u\n", cff_indexGetCount(gsubrIndex));

    if (gsubrIndex->count)
    {
        printf("    Size of array element           : %u\n", gsubrIndex->offSize);

        if (FALSE == brief)
        {
            printf("    Subroutines:\n");
            for (ULONG i = 0; i < gsubrIndex->content.count; i++)
            {
                cffIndexItem* obj = cff_indexGetItem(gsubrIndex, i);

                printf("        %u {\n", i);
                printf("        Len: %u\n", obj->length);
                printf("        Raw: ");
                for (size_t j = 0; j < obj->length; j++)
                {
                    printf("%02x", obj->data[j]);
                    if (j != 0 && (j + 1) % 20 == 0)
                        printf("\n             ");
                }
                printf("\n");
                printf("        Expanded: {\n");
                cff_dumpCharString(table->cffTable, obj->data, obj->length, -1, TRUE);
                printf("            }\n");
                printf("        }\n");
            }
        }
    }
    printf("}\n");
}

static void dump_encodings(cff_table *table)
{
    printf("Encodings {\n");
    printf("    <encodings are not processed by this code>\n");
    printf("}\n");

    (void)table;
}

static void dump_charsets(const cff_table *table)
{
    CFFTOPDICT* td = table->cffTable->mainTopDict;

    printf("Charsets {\n");
    printf("    Offset Info:\n");
    printf("        Offset : %d\n", td->charsetOffset);

    if (td->charsetOffset == 0)
        printf("    Using predefined ISOAdobe charset\n");
    else if (td->charsetOffset == 1)
        printf("    Using predefined Expert charset\n");
    else if (td->charsetOffset == 2)
        printf("    Using predefined ExperSubset charset\n");
    else
        printf("    Using custom charset\n");

    printf("    Number of glyphs %u\n", table->cffTable->numGlyphs);

    if (table->cffTable->isCID == TRUE)
        printf("    GID:CID:\n");
    else
        printf("    GID:SID:\n");
    printf("        ");
    for (USHORT i = 0; i < table->cffTable->numGlyphs; i++)
    {
        printf("%u:%u  ", i, table->cffTable->charset[i]);
        if ((i != 0) && (i % 20 == 0))
            printf("\n        ");
    }
    if (table->cffTable->numGlyphs % 20)
        printf("\n");
    printf("}\n");
}

static void dump_fdSelect(const cff_table *table)
{
    printf("FDSelect {\n");
    if (table->cffTable->isCID)
    {
        printf("    Original Format: %u\n", table->cffTable->fdSelect.origFormat);

        LONG nGlyphs = table->cffTable->numGlyphs;
        printf("    Data (GID:FDindex):\n");
        printf("    ");
        for (LONG i = 0; i < nGlyphs; i++)
        {
            printf("%d:%u ", i, table->cffTable->fdSelect.fdIndexArray[i]);
            if ((i != 0) && (i % 20 == 0))
                printf("\n    ");
        }
        if (nGlyphs%20)
            printf("\n");
    }
    else
        printf("    <not a CID font>\n");
    printf("}\n");
}

#if 0
static char* opcodeToStr(int opcode, int opcode2)
{
    switch (opcode)
    {
    case 1:  return "hstem";
    case 18: return "hstemhm";
    case 3: return "vstem";
    case 23: return "vstemhm";
    case 4: return "vmoveto";
    case 5: return "rlineto";
    case 6: return "hlineto";
    case 7: return "vlineto";
    case 8: return "rrcurveto";
    case 10: return "callsubr";
    case 11: return "return";
    case 14: return "endchar";
    case 12: // double byte opcodes
    {
        switch ((BYTE)opcode2)
        {
        case 3: return "AND";
        case 4: return "OR";
        case 5: return "NOT";
        case 9: return "ABS";
        case 10: return "ADD";
        case 11: return "SUB";
        case 12: return "DIV";
        case 14: return "NEG";
        case 15: return "EQ";
        case 18: return "DROP";
        case 20: return "PUT";
        case 21: return "GET";
        case 22: return "IFELSE";
        case 24: return "MUL";
        case 26: return "SQRT";
        case 27: return "DUP";
        case 28: return "EXCH";
        case 29: return "INDEX";
        case 30: return "ROLL";
        case 34: return "hflex";
        case 35: return "flex";
        case 36: return "hflex1";
        case 37: return "flex1";
        default: return "<bad opcode>";
        }  /* end of case 12's switch */
    }
    break; /* end of case 12: */
    case 19: return "hintmask";
    case 20: return "cntrmask";
    case 21: return "rmoveto";
    case 22: return "hmoveto";
    case 24: return "rcurveline";
    case 25: return "rlinecurve";
    case 26: return "vvcurveto";
    case 27: return "hhcurveto";
    case 29: return "call gsbr";
    case 30: return "vhcurveto";
    case 31: return "hvcurveto";
    default: return "<bad opcode>";
    }
}
#endif

static void dump_charStringsINDEX(const cff_table *table, boolean showParsed, boolean brief)
{
    cffIndex* charstringsIndex = table->cffTable->charStringsIndex;
    ULONG c = cff_indexGetCount(charstringsIndex);

    (void)showParsed;

    printf("Charstrings Index {\n");
    printf("    Number of Charstrings     : %u\n", c);

    if (c)
    {
        printf("    Size of Charstrings Index : %u\n", cff_indexGetLength(charstringsIndex));
        printf("    Size of array element     : %u\n", charstringsIndex->offSize);

        if (FALSE == brief)
        {
            printf("    charstrings               :\n");
            for (ULONG i = 0; i < charstringsIndex->content.count; i++)
            {
                cffIndexItem* obj = cff_indexGetItem(charstringsIndex, i);

                printf("        %u {\n", i);
                printf("        Len: %u\n", obj->length);
                printf("        Raw: ");
                for (size_t j = 0; j < obj->length; j++)
                {
                    printf("%02x", obj->data[j]);
                    if ((j != 0) && ((j + 1) % 20 == 0) && (j != obj->length - 1))
                        printf("\n             ");
                }
                printf("\n");
                printf("        Expanded: {\n");
                cff_dumpCharString(table->cffTable, obj->data, obj->length, i, FALSE);
                printf("            }\n");

#if 0
                if (showParsed)
                {
                    printf("        Parsed: {\n");
                    cffAnalyzedCharstring* acs = map_at(table->charStringMap, (void*)i);
                    cffParsedCharstring* pcs = acs->parsed;

                    for (size_t j = 0; j < pcs->instructions.count; j++)
                    {
                        cffCSIntruction* inst = (cffCSIntruction*)vector_at(&pcs->instructions, j);

                        printf("            ");

                        for (size_t k = 0; k < inst->args.count; k++)
                        {
                            int arg = (int)vector_at(&inst->args, k);
                            printf("%d ", arg >> 16);
                        }

                        if (inst->opcode2 != 0)
                        {
                            printf(": %d %d (%s)\n", inst->opcode, inst->opcode2, opcodeToStr(inst->opcode, inst->opcode2));
                        }
                        else
                        {
                            printf(": %d (%s)\n", inst->opcode, opcodeToStr(inst->opcode, inst->opcode2));
                        }
                    }


                    printf("            }\n");
                }
#endif
                printf("        }\n");
            }
        }
    }
    printf("}\n");
}

static void dump_aPrivateDICT(const PRIVATEDICT *pd)
{
    int i;
    printf("    {\n");
    printf("        BlueValues:");
    if (pd->BlueValues == NULL)
        printf(" <none>\n");
    else
    {
        for (i = 0; i < pd->numBlueValues - 1; i++)
            printf(" %d,", pd->BlueValues[i]);
        printf(" %d\n", pd->BlueValues[pd->numBlueValues - 1]);
    }
    printf("        OtherBlues:");
    if (pd->OtherBlues == NULL)
        printf(" <none>\n");
    else
    {
        for (i = 0; i < pd->numOtherBlues - 1; i++)
            printf(" %d,", pd->OtherBlues[i]);
        printf(" %d\n", pd->OtherBlues[pd->numOtherBlues - 1]);
    }
    printf("        FamilyBlues:");
    if (pd->FamilyBlues == NULL)
        printf(" <none>\n");
    else
    {
        for (i = 0; i < pd->numFamilyBlues - 1; i++)
            printf(" %d,", pd->FamilyBlues[i]);
        printf(" %d\n", pd->FamilyBlues[pd->numFamilyBlues - 1]);
    }
    printf("        FamilyOtherBlues:");
    if (pd->FamilyOtherBlues == NULL)
        printf(" <none>\n");
    else
    {
        for (i = 0; i < pd->numFamilyOtherBlues - 1; i++)
            printf(" %d,", pd->FamilyOtherBlues[i]);
        printf(" %d\n", pd->FamilyOtherBlues[pd->numFamilyOtherBlues - 1]);
    }
    printf("        BlueScale: %1.5f\n", pd->BlueScale);
    printf("        BlueShift: %1.3f\n", pd->BlueShift);
    printf("        BlueFuzz: %1.3f\n", pd->BlueFuzz);
    printf("        StdHW: %1.3f\n", pd->StdHW);
    printf("        StdVW: %1.3f\n", pd->StdVW);
    printf("        StemSnapH:");
    if (pd->StemSnapH == NULL)
        printf(" <none>\n");
    else
    {
        for (i = 0; i < pd->numStemSnapH - 1; i++)
            printf(" %d,", pd->StemSnapH[i]);
        printf(" %d\n", pd->StemSnapH[pd->numStemSnapH - 1]);
    }
    printf("        StemSnapV:");
    if (pd->StemSnapV == NULL)
        printf(" <none>\n");
    else
    {
        for (i = 0; i < pd->numStemSnapV - 1; i++)
            printf(" %d,", pd->StemSnapV[i]);
        printf(" %d\n", pd->StemSnapV[pd->numStemSnapV - 1]);
    }
    printf("        ForceBold : %s\n", pd->ForceBold ? "YES" : "NO");
    printf("        LanguageGroup: %d\n", pd->LanguageGroup);
    printf("        ExpansionFactor: %1.3f\n", pd->ExpansionFactor);
    printf("        initialRandomSeed: %1.3f\n", pd->initialRandomSeed);
    printf("        Subrs offset: %d\n", pd->subrsoff);
    printf("        defaultWidthX: %1.3f\n", pd->defaultwidthX);
    printf("        nominalWidthX: %1.3f\n", pd->nominalwidthX);
    printf("    }\n");
}

static void dump_thePrivateDICT(const cff_table *table)
{
    CFFTOPDICT* td = table->cffTable->mainTopDict;

    printf("Private Dict {\n");
    printf("    Offset Info:\n");
    printf("        Offset : %d\n", td->privateDictOffset);
    printf("        Size   : %d\n", td->privateDictSize);

    if (td->privateDictSize != 0)
    {
        PRIVATEDICT* pd = table->cffTable->privateDict;
        printf("    Info:\n");
        dump_aPrivateDICT(pd);
    }
    printf("}\n");
}

static void dump_localSubrINDEX(const cff_table *table, int index /* -1 for main subr*/, boolean brief)
{
    cffIndex* lsIndex;

    if (index == -1)
        lsIndex = table->cffTable->localSubrIndex;
    else
        lsIndex = table->cffTable->fdInfo[index].localSubr;

    ULONG c = cff_indexGetCount(lsIndex);

    if (index == -1)
        printf("Local Subroutine Index {\n");
    printf("    Number of Subroutines          : %u\n", c);

    if (c)
    {
        printf("    Size of Local Subroutine Index : %u\n", cff_indexGetLength(lsIndex));
        printf("    Size of array element          : %u\n", lsIndex->offSize);

        if (FALSE == brief)
        {
            for (ULONG i = 0; i < c; i++)
            {
                cffIndexItem* obj = cff_indexGetItem(lsIndex, i);

                printf("        %u {\n", i);
                printf("        Len: %u\n", obj->length);
                printf("        Raw: ");
                for (size_t j = 0; j < obj->length; j++)
                {
                    printf("%02x", obj->data[j]);
                    if ((j != 0) && ((j + 1) % 20 == 0) && (j != obj->length - 1))
                        printf("\n             ");
                }
                printf("\n");
                printf("        Expanded: {\n");
                cff_dumpCharString(table->cffTable, obj->data, obj->length, -1, TRUE);
                printf("            }\n");
                printf("        }\n");
            }
        }
    }
    printf("}\n");
}

static void dump_fontDICTINDEX(const cff_table *table, boolean brief)
{
    cffIndex* fdIndex = table->cffTable->FDIndex;
    ULONG i, c = cff_indexGetCount(fdIndex);

    printf("FD Index {\n");
    printf("    Number of Font DICTs: %u\n", c);

    if (c)
    {
        printf("    Size of array element: %u\n", fdIndex->offSize);
        printf("    Font Dicts           : {\n");
        for (i = 0; i < c; i++)
        {
            cffIndexItem* obj = cff_indexGetItem(fdIndex, i);

            printf("        %u:\n", i);
            printf("            Len: %u\n", obj->length);
            printf("            Raw: ");
            for (size_t j = 0; j < obj->length; j++)
            {
                printf("%02x", obj->data[j]);
                if (j != 0 && j % 20 == 0)
                    printf("\n                  ");
            }
            printf("\n");



            dump_aTopDict(table->cffTable->fdInfo[i].topdict, TRUE);
        }
        printf("    }\n");
        printf("    Private DICTs Info: {\n");
        for (i = 0; i < c; i++)
        {
            printf("    %u:\n", i);
            dump_aPrivateDICT(table->cffTable->fdInfo[i].privateDict);
        }
        printf("    }\n");
        printf("    Local Subroutines: {\n");
        for (i = 0; i < c; i++)
        {
            printf("    %u: {\n", i);
            if (table->cffTable->fdInfo[i].privateDict->subrsoff == 0)
                printf("        <no subr>\n");
            else
                dump_localSubrINDEX(table, i, brief);
            printf("    }\n");
        }
        printf("    }\n");
    }
    printf("}\n");
}

#if 0
static void dump_charstrings(const cff_table *table)
{
    printf("Parsed Charstrings {\n");

    ULONG i, numGylphs = map_size(table->charStringMap);

    for (i = 0; i < numGylphs; i++)
    {
        printf("    %d {\n", i);

        cffAnalyzedCharstring* acs = map_at(table->charStringMap, (void*)i);
        cffParsedCharstring* pcs = acs->parsed;

        for (size_t j = 0; j < pcs->instructions.count; j++)
        {

            cffCSIntruction* inst = (cffCSIntruction*)vector_at(&pcs->instructions, j);

            for (size_t k = 0; k < inst->args.count; k++)
            {
                int arg = (int)vector_at(&inst->args, k);
                printf("            %d\n", arg >> 16);
            }


            if (inst->opcode2 != 0)
            {
                printf("        %d %d    %s\n", inst->opcode, inst->opcode2, opcodeToStr(inst->opcode, inst->opcode2));
            }
            else
            {
                printf("        %d    %s\n", inst->opcode, opcodeToStr(inst->opcode, inst->opcode2));
            }
        }

        printf("    }\n");
    }

    printf("}\n");
}
#endif

#if 0
static void dump_SubroutineHistos(const cff_table *table)
{
    if (table->cffTable->globalSubrIndex != NULL)
    {
        ULONG numSubrs = cff_indexGetCount(table->cffTable->globalSubrIndex);

        USHORT* gsubrHist = (USHORT*)calloc(numSubrs, sizeof(USHORT));
        if (gsubrHist == NULL)
        {
            return;
        }

        ULONG i, numGlyphs = map_size(table->charStringMap);

        for (i = 0; i < numGlyphs; i++)
        {
            cffAnalyzedCharstring* acs = map_at(table->charStringMap, (void*)i);

            if (acs->gsubrArray != NULL)
            {
                for (USHORT j = 0; j < acs->gsubrArray->count; j++)
                {
                    int index = (int)vector_at(acs->gsubrArray, j);

                    gsubrHist[index]++;
                }
            }
        }

        printf("Global subroutine histogram:");

        int numUnused = 0;

        for (i = 0; i < gsubrHist; i++)
        {
            printf("%d    %d\n", i, gsubrHist[i]);
            if (gsubrHist[i] == 0)
                numUnused++;
        }

        if (numUnused > 0)
            printf("%d subroutines are not referenced");
    }
}
#endif

LF_ERROR CFF__Dump(LF_FONT* lfFont, ULONG flags)
{
    LF_ERROR  error = LF_ERROR_OK;

    if (lfFont == NULL)
        return LF_INVALID_PARAM;

    // make sure tables are unpacked
    if (map_empty(&lfFont->table_map))
    {
        return LF_BAD_FORMAT;   // client should unpack the tables.
    }

    cff_table* cfftable = map_at(&lfFont->table_map, (void*)TAG_CFF);
    if (NULL == cfftable)
        return LF_BAD_FORMAT;

    boolean parsedCharstrings = ((flags & CFF_DUMP_PARSED_CHARSTRINGS) != 0) ? TRUE : FALSE;

    boolean brief = ((flags & CFF_DUMP_BRIEF) != 0) ? TRUE : FALSE;

#if 0
    if (parsedCharstrings)
    {
        CFF_ERROR cffErr = cff_parseCharstrings(cfftable->charStringMap);
        if (cffErr != CFF_ERR_OK)
        {
            printf("Failed to parse charstrings");
            return cff_mapCffErrorToLfError(cffErr);
        }
    }
#endif
    printf("Dump of CFF Table:\n\n");

    dump_summary(cfftable);
    dump_header(cfftable);
    dump_nameINDEX(cfftable);
    dump_topDictINDEX(cfftable);
    dump_theTopDict(cfftable);
    dump_stringINDEX(cfftable);
    dump_globalSubrINDEX(cfftable, brief);
    dump_encodings(cfftable);
    dump_charsets(cfftable);
    dump_fdSelect(cfftable);
    dump_charStringsINDEX(cfftable, parsedCharstrings, brief);
    dump_fontDICTINDEX(cfftable, brief);
    dump_thePrivateDICT(cfftable);
    if (cfftable->cffTable->isCID == FALSE)
        dump_localSubrINDEX(cfftable, -1, brief);

    printf("End of dump\n\n");

#if 0
    if ((flags & CFF_DUMP_PARSED_CHARSTRINGS) != 0)
    {
        CFF_ERROR cffErr = cff_parseCharstrings(cfftable->charStringMap);
        if (cffErr != CFF_ERR_OK)
        {
            printf("Failed to parse charstrings");
            return cff_mapCffErrorToLfError(cffErr);
        }

        dump_charstrings(cfftable);

    }
#endif

    if ((flags & CFF_DUMP_SUBROUTINE_HISTOGRAM) != 0)
    {
        //dump_SubroutineHistos(cfftable);
    }

    return error;
}
