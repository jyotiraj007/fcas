// Copyright (C) 2014, 2015 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// kern_table.c

#include "kern_table.h"
#include "utils.h"
#include "table_tags.h"

static void KERN_cleanupSubtables(kern_table_header* table)
{
    USHORT i;

    for (i = 0; i < table->nTables; i++)
    {
        USHORT j;

        kern_subtable *subtable = (kern_subtable *)vector_at(&table->subtables, i);
        if (subtable == NULL)
        {
            DEBUG_LOG_ERROR("NULL subtable found in KERN_cleanupSubtables");
            continue;
        }

        if (subtable->header.version == 0)
        {
            for (j = 0; j < subtable->info.f0.nPairs; j++)
            {
                kern_pair *pair = (kern_pair *)vector_at(&subtable->info.f0.pairs, j);
                free(pair);
            }

            vector_delete(&subtable->info.f0.pairs);
        }

        free(subtable);
    }

    vector_delete(&table->subtables);
} //lint !e429 (freeing of the table itself is done after a call to this function)

static boolean KERN_checkFormatOfSubtables(LF_STREAM* stream, const kern_table_header *table)
{
    USHORT i;
    size_t subtableOffset;
    kern_subtable_header subtable;

    // stream is at beginning of subtables

    for(i = 0; i < table->nTables; i++)
    {
        subtableOffset = STREAM_streamPos(stream);

        subtable.version = STREAM_readUShort(stream);
        if(subtable.version != 0)
            return FALSE;

        subtable.length = STREAM_readUShort(stream);

        if(STREAM_streamSeek(stream, subtableOffset + subtable.length) != 0)
            return FALSE;
    }

    return TRUE;
}

static LF_ERROR KERN_readSubtables(LF_STREAM* stream, kern_table_header *table)
{
    USHORT i;

    LF_ERROR error = vector_init(&table->subtables, table->nTables, 1);
    if (error != LF_ERROR_OK)
        return error;

    // stream is at beginning of subtables

    for(i = 0; i < table->nTables; i++)
    {
        kern_subtable *subtable = (kern_subtable *)calloc(1, sizeof(kern_subtable));

        if(subtable == NULL)
        {
            KERN_cleanupSubtables(table);
            return LF_OUT_OF_MEMORY;
        }

        subtable->header.version  = STREAM_readUShort(stream);
        subtable->header.length   = STREAM_readUShort(stream);
        subtable->header.coverage = STREAM_readUShort(stream);

        if(subtable->header.version == 0)
        {
            USHORT j;
            const size_t f0PairSize = 6;  // left, right, and value. 2 bytes each.

            subtable->info.f0.nPairs         = STREAM_readUShort(stream);
            subtable->info.f0.searchRange    = STREAM_readUShort(stream);
            subtable->info.f0.entrySelector  = STREAM_readUShort(stream);
            subtable->info.f0.rangeShift     = STREAM_readUShort(stream);

            if (subtable->info.f0.nPairs > (65536 / f0PairSize)) // reject the table like OT Sanitizer would
            {
                KERN_cleanupSubtables(table);
                free(subtable);
                return LF_INVALID_SUBTABLE;
            }


            // now at beginning of pairs

            error = vector_init(&subtable->info.f0.pairs, subtable->info.f0.nPairs, 1);
            if (error != LF_ERROR_OK)
            {
                KERN_cleanupSubtables(table);
                free(subtable);
                return error;
            }

            for (j = 0; j < subtable->info.f0.nPairs; j++)
            {
                kern_pair *pair = (kern_pair *)calloc(1, sizeof(kern_pair));

                if (pair == NULL)
                {
                    KERN_cleanupSubtables(table);
                    free(subtable);
                    return LF_OUT_OF_MEMORY;
                }

                pair->left  = STREAM_readUShort(stream);
                pair->right = STREAM_readUShort(stream);
                pair->value = STREAM_readFWord(stream);

                vector_push_back(&subtable->info.f0.pairs, pair);
            }
        }
        else
        {
            // this subtable version is not handled
            // should not get here, other code checks for all the subtables being format 0
            KERN_cleanupSubtables(table);
            free(subtable);
            return LF_INVALID_SUBTABLE;
        }

        vector_push_back(&table->subtables, subtable);
    }

    return LF_ERROR_OK;
} //lint !e429 (freeing of the table itself is done in KERN_freeTable)

LF_ERROR KERN_readTable(LF_FONT* lfFont, const sfnt_table_record* record, LF_STREAM* stream)
{
    if(STREAM_streamSeek(stream, record->offset) == 0)
    {
        if(record->length > 0)
        {
            kern_table_header* table = (kern_table_header*)malloc(sizeof(kern_table_header));
            if(table == NULL)
                return LF_OUT_OF_MEMORY;

            table->data = NULL;
            table->length   = record->length;

            table->version  = STREAM_readUShort(stream);
            table->nTables  = STREAM_readUShort(stream);

            table->isParsed = FALSE;
            table->calculatedTableSize = 0;

            size_t offsetToSubtables = STREAM_streamPos(stream);

            if((table->version == 0) && (table->nTables > 0) && KERN_checkFormatOfSubtables(stream, table))
            {
                if(STREAM_streamSeek(stream, offsetToSubtables) == 0)
                {
                    if(KERN_readSubtables(stream, table) == LF_ERROR_OK)
                    {
                        table->isParsed = TRUE;
                    }
                    else
                    {
                        DEBUG_LOG_ERROR("failed to read kern subtables, kern table will not be subsetted");
                        table->nTables = 0;
                        table->length = 0;
                    }
                }
                else
                {
                    free(table);
                    return LF_INVALID_OFFSET;
                }
            }

            if(table->isParsed == FALSE)
            {
                if(STREAM_streamSeek(stream, record->offset) == 0)
                {
                    table->data = STREAM_readChunk(stream, table->length);
                }
                else
                {
                    free(table);
                    return LF_INVALID_OFFSET;
                }
            }

            map_insert(&lfFont->table_map, (void*)(intptr_t)record->tag, table);

            return LF_ERROR_OK;
        }
    }

    return LF_INVALID_OFFSET;
}

static void KERN_updateFormat0(kern_subtable *subtable)
{
    USHORT maxPow2;
    USHORT subtableLen = (USHORT)(sizeof(USHORT) * 7); // version, length, coverage + nPairs, searchRange, entrySelector, and rangeShift
    USHORT entrySize = (2*sizeof(USHORT) + sizeof(FWORD));

    subtable->info.f0.nPairs = (USHORT)vector_size(&subtable->info.f0.pairs);

    subtableLen += (USHORT)(subtable->info.f0.nPairs * entrySize);

    if ((int)(subtable->info.f0.nPairs * entrySize) > 65535)
    {
        DEBUG_LOG_ERROR("warning! - invalid kern subtable detected!!");
    }

    subtable->header.length = subtableLen;

    maxPow2 = offset_log2Floor(subtable->info.f0.nPairs);

    subtable->info.f0.entrySelector = maxPow2;
    subtable->info.f0.searchRange = (USHORT)(((unsigned) 1 << maxPow2) * entrySize);
    subtable->info.f0.rangeShift = (USHORT)((subtable->info.f0.nPairs - ((unsigned) 1 << maxPow2)) * entrySize);
}

LF_ERROR KERN_isTableEmpty(LF_FONT* lfFont)
{
    size_t size;

    LF_ERROR error = KERN_getTableSize(lfFont, &size);

    if (error != LF_ERROR_OK)
        return error;

    return (size > 4) ? LF_ERROR_OK : LF_EMPTY_TABLE;
}

LF_ERROR KERN_getTableSize(LF_FONT* lfFont, size_t* tableSize)
{
    kern_table_header* header = (kern_table_header*)map_at(&lfFont->table_map, (void*)TAG_KERN);
    if(header == NULL)
        return LF_TABLE_MISSING;

    if (header->calculatedTableSize != 0)
    {
        *tableSize = header->calculatedTableSize;
        return LF_ERROR_OK;
    }

    *tableSize = sizeof(USHORT) * 2; // version and number of tables

    for(int  i = (int)header->nTables-1; i >= 0; i--)
    {
        kern_subtable *subtable = (kern_subtable *)vector_at(&header->subtables, (ULONG)i);
        ASSERT(subtable);
        if (!subtable) continue;

        if (subtable->header.version == 0)
        {
            // check for now-empty subtable
            if(vector_empty(&subtable->info.f0.pairs))
            {
                header->nTables--;
                vector_delete(&subtable->info.f0.pairs);
                free(subtable);
                vector_erase(&header->subtables, (ULONG)i);
                continue;
            }

            if(vector_size(&subtable->info.f0.pairs) != subtable->info.f0.nPairs)
            {
                KERN_updateFormat0(subtable);
            }
        }
        else
        {
            // should never get here
            DEBUG_LOG_ERROR("unhandled subtable format in KERN_getTableSize");
            continue;
        }

        *tableSize += subtable->header.length;
    }

    header->calculatedTableSize = *tableSize;

    return LF_ERROR_OK;
}

static BYTE* KERN_buildTable(LF_FONT* lfFont, size_t* tableSize)
{
    BYTE* tableData = NULL;

    if(LF_ERROR_OK == KERN_getTableSize(lfFont, tableSize))
    {
        size_t paddedSize = *tableSize;
        tableData = UTILS_AllocTable(&paddedSize);
        if(tableData != NULL)
        {
            LF_STREAM stream;
            USHORT i;

            kern_table_header* table = (kern_table_header*)map_at(&lfFont->table_map, (void*)TAG_KERN);

            STREAM_initMemStream(&stream, tableData, *tableSize);

            STREAM_writeUShort(&stream, table->version);
            STREAM_writeUShort(&stream, table->nTables);

            for (i = 0; i < table->nTables; i++)
            {
                kern_subtable *subtable = (kern_subtable *)vector_at(&table->subtables, i);

                STREAM_writeUShort(&stream, subtable->header.version);
                STREAM_writeUShort(&stream, subtable->header.length);
                STREAM_writeUShort(&stream, subtable->header.coverage);

                if(subtable->header.version == 0)
                {
                    USHORT j;

                    STREAM_writeUShort(&stream, subtable->info.f0.nPairs);
                    STREAM_writeUShort(&stream, subtable->info.f0.searchRange);
                    STREAM_writeUShort(&stream, subtable->info.f0.entrySelector);
                    STREAM_writeUShort(&stream, subtable->info.f0.rangeShift);

                    for(j = 0; j < subtable->info.f0.nPairs; j++)
                    {
                        kern_pair *pair = (kern_pair *)vector_at(&subtable->info.f0.pairs, j);
                        ASSERT(pair);
                        if (!pair) continue;
                        STREAM_writeUShort(&stream, pair->left);
                        STREAM_writeUShort(&stream, pair->right);
                        STREAM_writeFWord(&stream, pair->value);
                    }
                }
            }
        }
        else
        {
            DEBUG_LOG_ERROR("allocation failure in KERN_buildTable");
        }
    }

    return tableData;
}

LF_ERROR KERN_removeGlyph(LF_FONT* lfFont, ULONG index)
{
    kern_table_header* table = (kern_table_header*)map_at(&lfFont->table_map, (void*)TAG_KERN);
    if (table == NULL)
        return LF_TABLE_MISSING;

    table->calculatedTableSize = 0;

    if(table->isParsed)
    {
        USHORT i;

        // loop over the sub tables and remove any pair that involves the passed in index

        for(i = 0; i < table->nTables; i++)
        {
            LONG numPairs, j;
            kern_subtable *subtable = (kern_subtable *)vector_at(&table->subtables, i);

            ASSERT(subtable);

            if (subtable)
            {
                ASSERT(subtable->header.version == 0);

                numPairs = (LONG)vector_size(&subtable->info.f0.pairs);

                for(j = numPairs-1; j >= 0; j--)
                {
                    kern_pair* pair = (kern_pair *)vector_at(&subtable->info.f0.pairs, j);
                    ASSERT(pair);

                    if(pair && ((pair->left == index) || (pair->right == index)))
                    {
                        vector_erase(&subtable->info.f0.pairs, j);
                        free(pair);
                    }
                }
             }
        }
    }

    return LF_ERROR_OK;
}

LF_ERROR KERN_remapTable(LF_FONT* lfFont, LF_MAP *remap)
{
    if ((lfFont == NULL) || (remap == NULL))
        return LF_INVALID_PARAM;

    kern_table_header* table = (kern_table_header*)map_at(&lfFont->table_map, (void*)TAG_KERN);
    if (table == NULL)
        return LF_TABLE_MISSING;

    if(table->isParsed)
    {
        USHORT i;

        // loop over the subtables
        for(i = 0; i < table->nTables; i++)
        {
            // go through the subtable, and change any instance of the srcIndex to the newGlyphIndex

            size_t numPairs, j;
            kern_subtable *subtable = (kern_subtable *)vector_at(&table->subtables, i);

            numPairs = vector_size(&subtable->info.f0.pairs);

            for(j = 0; j < numPairs; j++)
            {
                kern_pair* pair = (kern_pair *)vector_at(&subtable->info.f0.pairs, j);
                ASSERT(pair);

                if (pair)
                {
#if 1
                    pair->left = (USHORT)(intptr_t)map_at(remap, (void*)(intptr_t)pair->left);
                    pair->right = (USHORT)(intptr_t)map_at(remap, (void*)(intptr_t)pair->right);
#else
                    // enable this if necessary to debug the table
                    USHORT newGlyphID = (USHORT)(intptr_t)map_at(remap, (void*)(intptr_t)pair->left);

                    if((newGlyphID == 0) && (pair->left != 0))
                    {
                        DEBUG_LOG_WARNING("map_at returned a zero for replacement glyph");
                    }

                    pair->left = newGlyphID;

                    newGlyphID = (USHORT)(intptr_t)map_at(remap, (void*)(intptr_t)pair->right);

                    if((newGlyphID == 0) && (pair->right != 0))
                    {
                        DEBUG_LOG_WARNING("map_at returned a zero for replacement glyph");
                    }

                    pair->right = newGlyphID;
#endif
                }
            }
        }
    }

    return LF_ERROR_OK;
}

LF_ERROR KERN_writeTable(LF_FONT* lfFont, sfnt_table_record* record, LF_STREAM* stream)
{
    //ULONG padLen = 0;
    size_t table_size = 0;
    BYTE* tableData = NULL;

    kern_table_header* table = (kern_table_header*)map_at(&lfFont->table_map, (void*)(intptr_t)record->tag);

    if(table->isParsed)
    {
        tableData = KERN_buildTable(lfFont, &table_size);
        if(tableData == NULL)
            return LF_OUT_OF_MEMORY;
    }
    else
    {
        tableData = table->data;
        table_size = table->length;
    }

    //UTILS_PadTable(&tableData, table_size, &padLen);

    record->checkSum = UTILS_CalcTableChecksum(tableData, table_size);
    record->length = (ULONG)table_size;
    record->offset = (ULONG)STREAM_streamPos(stream);

    STREAM_writeChunk(stream, tableData, (table_size + 3) & ~3);

    if(table->isParsed)
        free(tableData);

    return LF_ERROR_OK;
}

LF_ERROR KERN_freeTable(LF_FONT* lfFont)
{
    kern_table_header* table = (kern_table_header*)map_at(&lfFont->table_map, (void*)TAG_KERN);

    if (table)
    {
        if (table->isParsed)
        {
            KERN_cleanupSubtables(table);
        }

        free(table->data);
        free(table);
    }

    return LF_ERROR_OK;
}
