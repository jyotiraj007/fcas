// Copyright (C) 2016 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// fvar_table.c

#include <stdlib.h>
#include "fvar_table.h"
#include "table_tags.h"
#include "utils.h"

static void FVAR_cleanupAxisArray(LF_VECTOR* v);
static void FVAR_cleanupInstanceArray(LF_VECTOR* instanceArray);

LF_ERROR FVAR_readTable(LF_FONT* lfFont, const sfnt_table_record* record, LF_STREAM* stream)
{
    if (record->length == 0)
        return LF_BAD_FORMAT;

    if (STREAM_streamSeek(stream, record->offset) != 0)
        return LF_INVALID_OFFSET;

    fvar_table* table = (fvar_table*)calloc(1, sizeof(fvar_table));

    if (NULL == table)
        return LF_OUT_OF_MEMORY;

    // pass through way -- to be removed
    table->length = record->length;
    table->data = STREAM_readChunk(stream, table->length);

    if (STREAM_streamSeek(stream, record->offset) != 0)
    {
        free(table);
        return LF_INVALID_OFFSET;
    }

    table->version = STREAM_readFixed(stream);
    table->offsetToData = STREAM_readUShort(stream);
    table->countSizePairs = STREAM_readUShort(stream);
    table->axisCount = STREAM_readUShort(stream);
    table->axisSize = STREAM_readUShort(stream);
    table->instanceCount = STREAM_readUShort(stream);
    table->instanceSize = STREAM_readUShort(stream);

    if (STREAM_streamSeek(stream, record->offset + table->offsetToData) != 0)       // should be there already so this is redundant
    {
        free(table);
        return LF_INVALID_OFFSET;
    }

    // init arrays
    LF_ERROR error = vector_init(&table->axisArray, table->axisCount, 1);
    if (LF_ERROR_OK != error)
    {
        free(table);
        return error;
    }

    error = vector_init(&table->instanceArray, table->instanceCount, 1);
    if (LF_ERROR_OK != error)
    {
        vector_free(&table->axisArray);
        free(table);
        return error;
    }

    // read axis array
    for (int i = 0; i < table->axisCount; i++)
    {
        sfnt_variation_axis* sva = calloc(1, sizeof(sfnt_variation_axis));
        if (NULL == sva)
        {
            vector_free(&table->axisArray);
            vector_free(&table->instanceArray);
            free(table);
            return LF_OUT_OF_MEMORY;
        }

        sva->axisTag = STREAM_readULong(stream);
        sva->maxValue = STREAM_readFixed(stream);
        sva->defaultValue = STREAM_readFixed(stream);
        sva->maxValue = STREAM_readFixed(stream);
        sva->flags = STREAM_readUShort(stream);
        sva->nameID = STREAM_readUShort(stream);

        error = vector_push_back(&table->axisArray, sva);
        if (LF_ERROR_OK != error)
        {
            FVAR_cleanupAxisArray(&table->axisArray);
            vector_free(&table->instanceArray);
            free(table);
            return LF_OUT_OF_MEMORY;
        }
    }

    // Read instance array
    for (int i = 0; i < table->instanceCount; i ++)
    {
        sfnt_instance* si = (sfnt_instance*)calloc(1, sizeof(sfnt_instance));

        if (NULL == si)
        {
            FVAR_cleanupAxisArray(&table->axisArray);
            FVAR_cleanupInstanceArray(&table->instanceArray);
            free(table);
            return LF_OUT_OF_MEMORY;
        }

        si->nameID = STREAM_readUShort(stream);
        si->flags = STREAM_readUShort(stream);

        error = vector_init(&si->coords, table->axisCount, 1);
        if (LF_ERROR_OK != error)
        {
            free(si);
            FVAR_cleanupAxisArray(&table->axisArray);
            FVAR_cleanupInstanceArray(&table->instanceArray);
            free(table);
            return LF_OUT_OF_MEMORY;
        }

        for (int j = 0; j < table->axisCount; j++)
        {
            FIXED val = STREAM_readFixed(stream);

            error = vector_push_back(&si->coords, (void*)(intptr_t)val);

            if (LF_ERROR_OK != error)
            {
                free(si);
                FVAR_cleanupAxisArray(&table->axisArray);
                FVAR_cleanupInstanceArray(&table->instanceArray);
                free(table);
                return LF_OUT_OF_MEMORY;
            }
        }

        error = vector_push_back(&table->instanceArray, si);
        if (LF_ERROR_OK != error)
        {
            FVAR_cleanupAxisArray(&table->axisArray);
            FVAR_cleanupInstanceArray(&table->instanceArray);
            free(table);
            return LF_OUT_OF_MEMORY;
        }
    }

    if (table->countSizePairs != 2)
    {
        DEBUG_LOG_ERROR("invalid countSizePairs in fvar table");
    }
    if (table->axisSize != 20)
    {
        DEBUG_LOG_ERROR("invalid axisSize in fvar table");
    }
    if (table->instanceSize != (sizeof(FIXED) * table->axisCount) + (2 * sizeof(USHORT)))
    {
        DEBUG_LOG_ERROR("invalid instanceSize in fvar table");
    }

    map_insert(&lfFont->table_map, (void*)(intptr_t)record->tag, table);

    return LF_ERROR_OK;
}

LF_ERROR FVAR_getAxisCount(LF_FONT* lfFont, USHORT* count)
{
    *count = 0;

    fvar_table* table = (fvar_table*)map_at(&lfFont->table_map, (void*)(long)TAG_FVAR);
    if (NULL == table)
        return LF_TABLE_MISSING;

    *count = table->axisCount;

    return LF_ERROR_OK;
}

LF_ERROR FVAR_getAxisTag(LF_FONT* lfFont, USHORT axis, ULONG* tag)
{
    *tag = 0;

    fvar_table* table = (fvar_table*)map_at(&lfFont->table_map, (void*)(long)TAG_FVAR);
    if (NULL == table)
        return LF_TABLE_MISSING;

    if (axis >= table->axisCount)
        return LF_INVALID_PARAM;

    sfnt_variation_axis* sva = (sfnt_variation_axis*)vector_at(&table->axisArray, axis);
    if (NULL == sva)
        return LF_BAD_FORMAT;

    *tag = sva->axisTag;

    return LF_ERROR_OK;
}

LF_ERROR FVAR_getAxisCoordinates(LF_FONT* lfFont, USHORT axis, FIXED* min, FIXED* dflt, FIXED* max)
{
    *min = *dflt = *max = 0;

    fvar_table* table = (fvar_table*)map_at(&lfFont->table_map, (void*)(long)TAG_FVAR);
    if (NULL == table)
        return LF_TABLE_MISSING;

    if (axis >= table->axisCount)
        return LF_INVALID_PARAM;

    sfnt_variation_axis* sva = (sfnt_variation_axis*)vector_at(&table->axisArray, axis);
    if (NULL == sva)
        return LF_BAD_FORMAT;

    *min = sva->minValue;
    *dflt = sva->defaultValue;
    *max = sva->maxValue;

    return LF_ERROR_OK;
}

LF_ERROR FVAR_getAxisNameID(LF_FONT* lfFont, USHORT axis, USHORT* id)
{
    *id = 0;

    fvar_table* table = (fvar_table*)map_at(&lfFont->table_map, (void*)(long)TAG_FVAR);
    if (NULL == table)
        return LF_TABLE_MISSING;

    if (axis >= table->axisCount)
        return LF_INVALID_PARAM;

    sfnt_variation_axis* sva = (sfnt_variation_axis*)vector_at(&table->axisArray, axis);
    if (NULL == sva)
        return LF_BAD_FORMAT;

    *id = sva->nameID;

    return LF_ERROR_OK;
}

LF_ERROR FVAR_getInstanceCount(LF_FONT* lfFont, USHORT* count)
{
    *count = 0;

    fvar_table* table = (fvar_table*)map_at(&lfFont->table_map, (void*)(long)TAG_FVAR);
    if (NULL == table)
        return LF_TABLE_MISSING;

    *count = table->instanceCount;

    return LF_ERROR_OK;
}

LF_ERROR FVAR_getInstanceNameID(LF_FONT* lfFont, USHORT instance, USHORT* id)
{
    *id = 0;

    fvar_table* table = (fvar_table*)map_at(&lfFont->table_map, (void*)(long)TAG_FVAR);
    if (NULL == table)
        return LF_TABLE_MISSING;

    if (instance >= table->instanceCount)
        return LF_INVALID_PARAM;

    sfnt_instance* si = (sfnt_instance*)vector_at(&table->instanceArray, instance);
    if (NULL == si)
        return LF_BAD_FORMAT;

    *id = si->nameID;

    return LF_ERROR_OK;
}

LF_ERROR FVAR_getInstanceCoords(LF_FONT* lfFont, USHORT instance, FIXED* coordArray, USHORT avail)
{
    fvar_table* table = (fvar_table*)map_at(&lfFont->table_map, (void*)(long)TAG_FVAR);
    if (NULL == table)
        return LF_TABLE_MISSING;

    if (instance >= table->instanceCount)
        return LF_INVALID_PARAM;

    sfnt_instance* si = (sfnt_instance*)vector_at(&table->instanceArray, instance);
    if (NULL == si)
        return LF_BAD_FORMAT;

    FIXED* ptr = coordArray;
    for (int i = 0; i < avail && i < table->axisCount; i++)
    {
        *ptr++ = (FIXED)(intptr_t)vector_at(&si->coords, i);
    }

    return LF_ERROR_OK;
}

LF_ERROR FVAR_getTableSize(LF_FONT* lfFont, size_t* tableSize)
{
    fvar_table* table = (fvar_table*)map_at(&lfFont->table_map, (void*)(long)TAG_FVAR);

    *tableSize = 0;

    if(table == NULL)
        return LF_EMPTY_TABLE;

    *tableSize = table->length;

    return LF_ERROR_OK;
}

LF_ERROR FVAR_writeTable(LF_FONT* lfFont, sfnt_table_record* record, LF_STREAM* stream)
{
    // For now this code just passes through the fvar table
    // There is nothing to subset in the fvar table, so unpacking it is for dumping it only.

    ULONG padLen = 0;
    fvar_table* table = (fvar_table*)map_at(&lfFont->table_map, (void*)(intptr_t)record->tag);

    if(table == NULL)
        return LF_EMPTY_TABLE;

    UTILS_PadTable(&table->data, table->length, &padLen);

    record->checkSum = UTILS_CalcTableChecksum(table->data, table->length);
    record->length = table->length;
    record->offset = (ULONG)STREAM_streamPos(stream);

    STREAM_streamSeek(stream, record->offset);
    STREAM_writeChunk(stream, table->data, padLen);

    return LF_ERROR_OK;
}

static void FVAR_cleanupAxisArray(LF_VECTOR* v)
{
    for (size_t i = 0; i < v->count; i++)
        free(vector_at(v, i));
    vector_free(v);
}

static void FVAR_cleanupInstanceArray(LF_VECTOR* instanceArray)
{
    for (size_t i = 0; i < instanceArray->count; i++)
    {
        sfnt_instance* si = (sfnt_instance*)vector_at(instanceArray, i);

        if (NULL != si)
        {
            vector_free(&si->coords);
            free(si);
        }
    }
    vector_free(instanceArray);
}

LF_ERROR FVAR_freeTable(LF_FONT* lfFont)
{
    fvar_table* table = (fvar_table*)map_at(&lfFont->table_map, (void*)(long)TAG_FVAR);

    if(table)
    {
        FVAR_cleanupInstanceArray(&table->instanceArray);
        FVAR_cleanupAxisArray(&table->axisArray);

        free(table->data);      // to be removed?
        free(table);
    }

    return LF_ERROR_OK;
}
