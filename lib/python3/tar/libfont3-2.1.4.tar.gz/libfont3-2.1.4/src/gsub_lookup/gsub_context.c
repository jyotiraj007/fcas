// Copyright (C) 2014 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// gsub_context.c

#include "gsub_lookup/gsub_context.h"
#include "utils.h"
#include "common_table.h"

// format 1 private functions
static LF_ERROR contextSubst_readFormat1(gsub_context_subst_f1* csf1, LF_STREAM* stream);
static size_t   contextSubst_buildFormat1(gsub_context_subst_f1* csf1, LF_STREAM* stream);
static size_t   contextSubst_getFormat1Size(gsub_context_subst_f1* csf1);
static LF_ERROR contextSubst_removeFormat1(gsub_context_subst_f1* cs, GlyphID glyphid);
static void     contextSubst_freeFormat1(gsub_context_subst_f1* csf1);
static LF_ERROR contextSubst_removeLookupIndexFormat1(gsub_context_subst_f1* csf1, USHORT refIndex, SHORT deltaIndex);
static LF_ERROR contextSubst_pruneLookupRecordsFormat1(gsub_context_subst_f1* csf1);
static LF_ERROR contextSubst_cleanupLookupsFormat1(gsub_context_subst_f1* csf1, TABLE_HANDLE hLookup);
static LF_ERROR contextSubst_collectContextSubstGlyphsFormat1(GlyphList* keepList, TABLE_HANDLE hTable, gsub_context_subst_f1* csf1);


// format 2 private functions
static LF_ERROR contextSubst_readFormat2(gsub_context_substitution* cs, LF_STREAM* stream);
static size_t   contextSubst_buildFormat2(gsub_context_subst_f2* csf2, LF_STREAM* stream);
static size_t   contextSubst_getFormat2Size(gsub_context_subst_f2* csf2);
static LF_ERROR contextSubst_removeFormat2(gsub_context_subst_f2* csf2, GlyphID glyphid);
static void     contextSubst_freeFormat2(gsub_context_subst_f2* csf2);
static LF_ERROR contextSubst_removeLookupIndexFormat2(gsub_context_subst_f2* table, USHORT refIndex, SHORT deltaIndex);
static LF_ERROR contextSubst_pruneLookupRecordsFormat2(gsub_context_subst_f2* csf2);
static LF_ERROR contextSubst_cleanupLookupsFormat2(gsub_context_subst_f2* csf2, TABLE_HANDLE hLookup);
static LF_ERROR contextSubst_collectContextSubstGlyphsFormat2(GlyphList* keepList, TABLE_HANDLE hTable, gsub_context_subst_f2* csf2);


// format 3 private functions
static LF_ERROR contextSubst_readFormat3(gsub_context_substitution* cs, LF_STREAM* stream);
static size_t   contextSubst_buildFormat3(gsub_context_subst_f3* csf3, LF_STREAM* stream);
static size_t   contextSubst_getFormat3Size(gsub_context_subst_f3* csf3);
static LF_ERROR contextSubst_removeFormat3(gsub_context_subst_f3* csf3, GlyphID glyphid);
static void     contextSubst_freeFormat3(gsub_context_subst_f3* csf3);
static LF_ERROR contextSubst_removeLookupIndexFormat3(gsub_context_subst_f3* csf3, USHORT refIndex, SHORT deltaIndex);
static LF_ERROR contextSubst_cleanupLookupsFormat3(gsub_context_subst_f3* csf3, TABLE_HANDLE hLookup);
static LF_ERROR contextSubst_collectContextSubstGlyphsFormat3(GlyphList* keepList, TABLE_HANDLE hTable, gsub_context_subst_f3* csf3);
static LF_ERROR contextSubst_pruneLookupRecordsFormat3(gsub_context_subst_f3* csf3);




/* ============================================================================
    @summary
        read in substitution context and return the table back to the
        caller.

    @param
        stream    : pointer to the stream to read the context subtable
                    from.

    @return
        pointer to the substitution context subtable
        NULL if error occurred.
============================================================================ */
TABLE_HANDLE GSUB_readContextSubst(LF_STREAM* stream)
{
    LF_ERROR                    error;
    gsub_context_substitution*  cs = (gsub_context_substitution*)calloc(1, sizeof(gsub_context_substitution));
    if (!cs)
    {
        return NULL;
    }

    cs->SubstFormat = STREAM_readUShort(stream);
    switch (cs->SubstFormat)
    {
    case 1:        error = contextSubst_readFormat1(&cs->csf.csf1, stream);    break;
    case 2:        error = contextSubst_readFormat2(cs, stream);               break;
    case 3:        error = contextSubst_readFormat3(cs, stream);               break;
    default:       error = LF_BAD_FORMAT;                                      break;
    }

    if (error == LF_ERROR_OK)
        return (TABLE_HANDLE)cs;

    DEBUG_LOG_STATUS("failed to read context substitution", error);

    GSUB_freeContextSubst(cs);
    return NULL;
}



/* ============================================================================

============================================================================ */
size_t GSUB_buildContextSubst(gsub_context_substitution* cs, LF_STREAM* stream)
{
    //size_t streamPos = 0;  not used

    ASSERT(cs);
    ASSERT(stream);

#ifdef LF_OT_DUMP
    if (BaseTable_isDump(cs) == TRUE)
    {
        GSUB_dumpContextSubst(cs);
    }
#endif


    // first write out the substitution format
    STREAM_writeUShort(stream, cs->SubstFormat);

    switch(cs->SubstFormat)
    {
    case 1:        /*streamPos = */ contextSubst_buildFormat1(&cs->csf.csf1, stream);        break;
    case 2:        /*streamPos = */ contextSubst_buildFormat2(&cs->csf.csf2, stream);        break;
    case 3:        /*streamPos = */ contextSubst_buildFormat3(&cs->csf.csf3, stream);        break;
    default:    break;
    }


    return STREAM_streamPos(stream);
}



/* ============================================================================

============================================================================ */
size_t GSUB_getContextSubstSize(gsub_context_substitution* cs)
{
    size_t    size = 0;
    ASSERT(cs);

    size = sizeof(cs->SubstFormat);

    switch(cs->SubstFormat)
    {
    case 1:        size += contextSubst_getFormat1Size(&cs->csf.csf1);        break;
    case 2:        size += contextSubst_getFormat2Size(&cs->csf.csf2);        break;
    case 3:        size += contextSubst_getFormat3Size(&cs->csf.csf3);        break;
    default:       DEBUG_LOG_WARNING("Unknown SubstFormat getting size");     break;
    }

    return size;
}


/* ============================================================================

============================================================================ */
void GSUB_freeContextSubst(gsub_context_substitution* cs)
{
    ASSERT(cs);

    switch (cs->SubstFormat)
    {
    case 1:        contextSubst_freeFormat1(&cs->csf.csf1);        break;
    case 2:        contextSubst_freeFormat2(&cs->csf.csf2);        break;
    case 3:        contextSubst_freeFormat3(&cs->csf.csf3);        break;
    default:    break;
    }

    FREE(cs);
}



/* ============================================================================

============================================================================ */
LF_ERROR GSUB_removeContextGlyphIndex(gsub_context_substitution* cs, GlyphID glyphid)
{
    LF_ERROR error = LF_ERROR_OK;

    ASSERT(cs);

    switch(cs->SubstFormat)
    {
    case 1:        error = contextSubst_removeFormat1(&cs->csf.csf1, glyphid);        break;
    case 2:        error = contextSubst_removeFormat2(&cs->csf.csf2, glyphid);        break;
    case 3:        error = contextSubst_removeFormat3(&cs->csf.csf3, glyphid);        break;
    default:
        break;
    }

    return error;
}


/* ----------------------------------------------------------------------------
    @summary
        read context format 1 from the stream.

---------------------------------------------------------------------------- */
static LF_ERROR contextSubst_readFormat1(gsub_context_subst_f1* csf1, LF_STREAM* stream)
{
    LF_ERROR    error;
    USHORT      n, count;
    size_t      curOffset, newOffset, baseOffset;
    size_t      coverageCount;

    baseOffset = STREAM_streamPos(stream) - 2L;

    newOffset = STREAM_readUShort(stream) + baseOffset;
    curOffset = STREAM_streamPos(stream);

    STREAM_streamSeek(stream, newOffset);
    error = Coverage_readTable(&csf1->Coverage, stream);    // read coverage
    if (error != LF_ERROR_OK)
    {
        if (error != LF_EMPTY_TABLE)
        {
            DEBUG_LOG_ERROR("GSUB Context failed to read CoverageTable");
            return error;
        }
    }

    coverageCount = Coverage_getCoverageCount(&csf1->Coverage);
    STREAM_streamSeek(stream, curOffset);

    count = STREAM_readUShort(stream);        // how many sub rules are there ?

    ASSERT(coverageCount == count);                         // check to ensure the coverage and subrule sets match up...

    if (coverageCount != count)
    {
        return LF_BAD_FORMAT;
    }

    error = vector_init(&csf1->SubRuleSet, count, sizeof(ULONG));   // create a collection to hold the sub-rule sets
    if (error != LF_ERROR_OK)
    {
        return error;
    }

    // loop through the stream and get all of the sets
    for (n = 0; n < count; n++)
    {
        context_rule_set* srs = NULL;
        newOffset = STREAM_readUShort(stream) + baseOffset;
        curOffset = STREAM_streamPos(stream);
        STREAM_streamSeek(stream, newOffset);

        srs = (context_rule_set*)malloc(sizeof(context_rule_set));
        if (!srs)
        {
            ContextSet_freeRuleSets(&csf1->SubRuleSet);            // free up any resources and then bail
            DEBUG_LOG_ERROR("GSUB Context ran out of memory");
            return LF_OUT_OF_MEMORY;
        }

        error = ContextSet_readRuleSet(srs, stream);
        if (error != LF_ERROR_OK)
        {
            ContextSet_freeRuleSets(&csf1->SubRuleSet);            // free up any resources and then bail
            DEBUG_LOG_ERROR("GSUB Context ran out of memory");
            return error;
        }

        STREAM_streamSeek(stream, curOffset);

        vector_push_back(&csf1->SubRuleSet, srs);
    }

    return LF_ERROR_OK;
}

/* ----------------------------------------------------------------------------
    @summary
        free all of the resources used by substitution context format 1

    @param
        csf1    :    pointer to the format 1 structure

---------------------------------------------------------------------------- */
static void    contextSubst_freeFormat1(gsub_context_subst_f1* csf1)
{
    ContextSet_freeRuleSets(&csf1->SubRuleSet);
    vector_delete(&csf1->SubRuleSet);

    Coverage_deleteTable(&csf1->Coverage);
}

/* ----------------------------------------------------------------------------
    @summary
        parse all of the context substitution structures and determine
        what size it needs to be.
---------------------------------------------------------------------------- */
static size_t contextSubst_getFormat1Size(gsub_context_subst_f1* csf1)
{
    size_t        size = 0;
    size_t        coverageSize;
    size_t        coverageGlyphCount;
    USHORT        n, count;

    //LF_ERROR    error; not used

    Coverage_getTableSize(&csf1->Coverage, &coverageSize);
    //error = Coverage_getTableSize(&csf1->Coverage, &coverageSize);
    coverageGlyphCount = Coverage_getCoverageCount(&csf1->Coverage);

    if (csf1->SubRuleSet.count != coverageGlyphCount)
    {
        DEBUG_LOG_WARNING("gsub context subrules out of sync with coverage");
    }

    count = UTILS_getCount(&csf1->SubRuleSet);

    size += sizeof(OFFSET);                                 // sizeof Coverage Offset
    size += coverageSize;                                   // add in the coverage size as well
    size += sizeof(USHORT);                                 // SubRuleSetCount
    size += sizeof(OFFSET) * count;                         // create the array of OFFSETS to match set count

    // loop through the sub-rule sets
    for ( n = 0; n < count; n++)
    {
        context_rule_set* srs = (context_rule_set*)vector_at(&csf1->SubRuleSet, n);
        size += ContextSet_sizeRuleSet(srs);
    }
    return size;
}


/* ----------------------------------------------------------------------------
    @summary
        parse all of the context substitution structures and determine
        what size it needs to be.
---------------------------------------------------------------------------- */
static size_t contextSubst_buildFormat1(gsub_context_subst_f1* csf1, LF_STREAM* stream)
{
    size_t baseOffset = STREAM_streamPos(stream) - 2L;  /* Minus 2 since we've already grabbed the format earlier */
    size_t coverageOffset = 0;
    size_t setOffset = 0;
    size_t curOffset = 0;
    size_t offset = 0;
    size_t n, count, subruleSetCount;

    size_t SubRuleSetOffset;

    coverageOffset = STREAM_streamPos(stream);
    STREAM_writeOffset(stream, 0);

    subruleSetCount = (USHORT)csf1->SubRuleSet.count;
    STREAM_writeUShort(stream, (USHORT)subruleSetCount);
    SubRuleSetOffset = STREAM_streamPos(stream);
    (void)SubRuleSetOffset; //not used


    /*
     *    Lets do some sanity checks!
     *
     *    Number of SubRuleSet tables-must equal GlyphCount
     *    in Coverage Table.
     */
    count = Coverage_getCoverageCount(&csf1->Coverage);
    ASSERT(count == csf1->SubRuleSet.count);
    if (count != csf1->SubRuleSet.count)
    {

        // TODO: LOG an error in the file ...
        // "ERROR: coverage glyph count does not match SubRuleSet count"
        STREAM_streamSeek(stream, baseOffset);            // reset the stream
        return 0;
    }


    count = (USHORT)csf1->SubRuleSet.count;

    // write all of the Offsets into the sub-rule set offset array
    setOffset = STREAM_streamPos(stream);                    // save set OFFSET in the stream, so we get back to it.
    for ( n = 0; n < count; n++)
    {
        STREAM_writeOffset(stream, 0);
    }


    // write all of the Offsets into the sub-rule set offset array
    for ( n = 0; n < count; n++)
    {
        context_rule_set* srs = (context_rule_set*)vector_at(&csf1->SubRuleSet, n);
        curOffset = STREAM_streamPos(stream);               // get our current stream position
        offset = curOffset - baseOffset;                    // calculate the offset
        STREAM_streamSeek(stream, setOffset);               // seek out the set offset table

        STREAM_writeOffset(stream, (OFFSET)offset);         // write the offset into the set offset 
        setOffset += sizeof(OFFSET);                        // increment to the next offset in the array.

        STREAM_streamSeek(stream, curOffset);               // go back to stream current position
        ContextSet_buildRuleSet(srs, stream);
    }

    curOffset = STREAM_streamPos(stream);
    offset = curOffset - baseOffset;
    STREAM_streamSeek(stream, coverageOffset);
    STREAM_writeUShort(stream, (USHORT)offset);
    STREAM_streamSeek(stream, curOffset);

    Coverage_buildTable(&csf1->Coverage, stream);

    return STREAM_streamPos(stream);
}

/* ----------------------------------------------------------------------------
    @summary
        remove a specific rule from the format.

        this context is about the sequence, and therefore we need to
        check if the glyph being removed is in a context sequence and
        should be removed.

        The coverage table lists the first glyph in the sequence, and
        a SubRule table identifies the remaining glyphs.  To describe
        the >abc< context, the Coverage table lists the glyph index
        of the first component of the sequence-the "a" glyph.  A sub
        rule table defines the indices for the "b" and "c" glyphs.

---------------------------------------------------------------------------- */
static LF_ERROR contextSubst_removeFormat1(gsub_context_subst_f1* cs, GlyphID glyphid)
{
    LF_ERROR    error;
    ULONG        coverageIndex;

    // 1rst stage, remove coverage match ups with the Sub-rule sets.
    error = Coverage_removeGlyphIndex(&cs->Coverage, glyphid, &coverageIndex);
    if (error == LF_EMPTY_TABLE)
    {
        // if the coverage is empty, then this rule can be removed
        return error;
    }

    // According to the rules, The number of SubRuleSet tables-must be equal to GlyphCount
    // in the Coverage Table.
    if ( error == LF_ERROR_OK )
    {
        // Top level pruning of the rules - match Coverage index to SubRuleSets index.
        // find the SubRuleSet that matches coverage index
        context_rule_set* srs = (context_rule_set*)vector_at(&cs->SubRuleSet, coverageIndex);

        ContextSet_freeRuleSet(srs);
        FREE(srs);
        vector_erase(&cs->SubRuleSet, coverageIndex);
    }

    // 2nd Stage, now search all SubRuleSets and remove any SubRules
    // that contain the glyph as they are no longer relevant if one
    // of the sequences has been removed.
    error = ContextSet_pruneRuleSets(&cs->SubRuleSet, &cs->Coverage, glyphid);

    return error;
}


/* ============================================================================
    @summary
        FORMAT 2

    @description

============================================================================ */
static LF_ERROR    contextSubst_readFormat2(gsub_context_substitution* cs, LF_STREAM* stream)
{
    LF_ERROR                 error = LF_ERROR_OK;
    gsub_context_subst_f2*   csf2;
    USHORT                   count;
    size_t                   curOffset, newOffset, baseOffset;
    size_t                   coverageCount;
    size_t                   classOffset;


    ASSERT(cs);
    ASSERT(stream);

    csf2 = &cs->csf.csf2;

    baseOffset = STREAM_streamPos(stream) - 2L;                    // store off base offset (subtract 2 because of substitution format)
    newOffset  = STREAM_readUShort(stream) + baseOffset;           // get the coverage offset
    curOffset  = STREAM_streamPos(stream);                         // save where we are in stream

    STREAM_streamSeek(stream, newOffset);                          // seek out coverage table in stream
    error = Coverage_readTable(&csf2->Coverage, stream);           // read coverage
    if ((error != LF_ERROR_OK) && (error != LF_EMPTY_TABLE))
    {
        goto readFormat2CoverageFailed;
    }

    coverageCount = Coverage_getCoverageCount(&csf2->Coverage);      // figure out how many elements are in the coverage
    (void)coverageCount; //not used
    STREAM_streamSeek(stream, curOffset);                            // restore stream back to the gsub context format 2 stream

    classOffset = STREAM_readUShort(stream) + baseOffset;            // read in offset to the class definitions

    // subclass count is the upper limit for class values, therefore we
    // read it now to make an addition safety check
    count = csf2->SubClassSetCnt = STREAM_readUShort(stream);        // read number of SubClassSet tables there are

    curOffset = STREAM_streamPos(stream);
    STREAM_streamSeek(stream, classOffset);

    error = ClassDef_readTable(&csf2->ClassDef, stream);             // read in the class definition table
    if (error != LF_ERROR_OK) {
        DEBUG_LOG_ERROR("Failed to read the ClassDef for Context Subst format 2");
        goto Fail1;
    }


    STREAM_streamSeek(stream, curOffset);
    error = ClassSets_readClassSets(&csf2->SubClassSet, &csf2->ClassDef, count, stream, (ULONG)baseOffset);
    if (error != LF_ERROR_OK)
    {
        DEBUG_LOG_ERROR("Failed to read ClassSets from stream");
        goto Fail1;
    }

//#if _DEBUG && 0
#ifdef LF_OT_DUMP
    {
    ULONG maxClasses = 0;
    ClassDef_dump(&csf2->ClassDef);
    ClassSets_dumpClassSets(&csf2->SubClassSet);

    maxClasses = ClassDef_getMaxClass(&csf2->ClassDef);
//    ASSERT_MSG((maxClasses == (csf2->SubClassSet.count - 1)), "class sets and number of classes mismatch");

    if (maxClasses != (csf2->SubClassSet.count - 1))
    {
        DEBUG_LOG_ERROR("class sets and number of classes mismatch");
        error = LF_INVALID_SUBTABLE;
        goto Fail1;

    }
    }
#endif

    return LF_ERROR_OK;


Fail1:
    contextSubst_freeFormat2(csf2);
    return error;

readFormat2CoverageFailed:
    DEBUG_LOG_ERROR("Failed to read CoverageTable");
    return LF_BAD_FORMAT;
}

static size_t    contextSubst_buildFormat2(gsub_context_subst_f2* csf2, LF_STREAM* stream)
{
    size_t    baseOffset = STREAM_streamPos(stream) - 2L;
    size_t    coverageOffset = 0;
    size_t    curOffset = 0;
    size_t    classdefOffset = 0;
    size_t    offset = 0;
    USHORT  count, maxClasses;

    size_t SubClassSetOffset = 0;

    ASSERT(stream);
    ASSERT(csf2);

    // Coverage OFFSET
    coverageOffset = STREAM_streamPos(stream);
    STREAM_writeOffset(stream, 0);

    // ClassDef OFFSET
    classdefOffset = STREAM_streamPos(stream);
    STREAM_writeOffset(stream, 0);

    maxClasses = (USHORT)ClassDef_getMaxClass(&csf2->ClassDef);

    // SubClassSet Count
    count = UTILS_getCount(&csf2->SubClassSet);
    STREAM_writeUShort(stream, count);                                // SubClassSetCnt

    ASSERT_MSG((maxClasses == (count - 1)), "class sets and number of classes mismatch");

    (void)maxClasses; // not used TODO make above an error?

    // SubClassSet OFFSET Array - write out placeholders
    SubClassSetOffset = Common_buildEmptyArray(stream, count);        // SubClassSetOffet[SubClassSetCnt]

    /* Stay in the order that the font was read in */
    /* Start by writing out the coverage table */
    curOffset = STREAM_streamPos(stream);
    offset = curOffset - baseOffset;
    STREAM_streamSeek(stream, coverageOffset);
    STREAM_writeUShort(stream, (USHORT)offset);
    STREAM_streamSeek(stream, curOffset);

    Coverage_buildTable(&csf2->Coverage, stream);

    /* Next write out the Class table */
    curOffset = STREAM_streamPos(stream);
    offset = curOffset - baseOffset;
    STREAM_streamSeek(stream, classdefOffset);
    STREAM_writeUShort(stream, (USHORT)offset);
    STREAM_streamSeek(stream, curOffset);
    ClassDef_buildTable(&csf2->ClassDef, stream);

    /* now build out the class sets and the OFFSET array */
    ClassSet_buildClassSets(&csf2->SubClassSet, (LONG)baseOffset, (LONG)SubClassSetOffset, stream);

    return STREAM_streamPos(stream);
}

static size_t contextSubst_getFormat2Size(gsub_context_subst_f2* csf2)
{
    LF_VECTOR* list;
    size_t coverageSize, classSize, size, n;
    //LF_ERROR error;

    ASSERT(csf2);

    list = &csf2->SubClassSet;
    /*error = */Coverage_getTableSize(&csf2->Coverage, &coverageSize);
    /*error = */ClassDef_getTableSize(&csf2->ClassDef, &classSize);

    size  = sizeof(OFFSET);                    // offset to Coverage
    size += coverageSize;
    size += sizeof(OFFSET);                    // offset to ClassDef
    size += classSize;

    size += sizeof(csf2->SubClassSetCnt);      // number of SubClassSet tables
    size += (sizeof(OFFSET) * list->count);    // Array of offsets to the SubClassSet tables

    // loop through class sets and retrieve their sizes
    for ( n = 0; n < list->count; n++)
    {
        class_set* scs = (class_set*)vector_at(list, n);
        size += ClassSet_sizeClassSet(scs);
    }

    return size;
}


/* ----------------------------------------------------------------------------
    @desc
        remove a glyph from format 2.

        when removing a glyph from a class, we must ensure that the 
        class sets stay in sync.

    @note
        due to time, it was decided NOT to remap classes when they are 
        empty so we must maintain placeholder classes/empty classes.  this
        creates a difficult situation with ClassSets.

        ClassSets must maintain a class set for each class, regardless if 
        it is empty or not, otherwise the font becomes corrupt.  However if
        a class is empty, we need to cleanup the class rules and remove any
        rules that use an empty font.


    @date
        roba: Oct. 21/2014

---------------------------------------------------------------------------- */
static LF_ERROR contextSubst_removeFormat2(gsub_context_subst_f2* csf2, GlyphID glyphid)
{
    LF_ERROR    error = LF_ERROR_OK;
    ULONG       coverageIndex;
    USHORT      removeSet = 0;

    // remove glyph from coverage ....
    error = Coverage_removeGlyphIndex(&csf2->Coverage, glyphid, &coverageIndex);
    if (error == LF_EMPTY_TABLE)
    {
        // we can remove the entire table if coverage table is empty
        return error;
    }

    error = ClassDef_removeGlyph(&csf2->ClassDef, glyphid, &removeSet);
    if (error == LF_EMPTY_TABLE && removeSet != 0)
    {
        // we can remove a set from the system
        size_t count = csf2->SubClassSet.count;

        if (removeSet < count)
        {
            class_set* scs = (class_set*)vector_at(&csf2->SubClassSet, removeSet);

            // get rid of the subclass rules
            ClassSet_freeClassSet(scs);

            // now it is just an empty class rule.
            DEBUG_LOG_VALUE("Removing SubClassSet ", removeSet);
        }
    }
    return error;
}

static void contextSubst_freeFormat2(gsub_context_subst_f2* csf2)
{
    LF_VECTOR* v;

    ASSERT(csf2);

    v = &csf2->SubClassSet;

    Coverage_deleteTable(&csf2->Coverage);
    ClassDef_freeTable(&csf2->ClassDef);

    // loop through class sets
    while (v->count)
    {
        class_set* scs = (class_set*)vector_at(v, 0);
        ClassSet_freeClassSet(scs);
        FREE(scs);

        vector_erase(v, 0);
    };
    vector_delete(&csf2->SubClassSet);
}







/* ****************************************************************************
    FORMAT 3

**************************************************************************** */
static LF_ERROR contextSubst_readFormat3(gsub_context_substitution* cs, LF_STREAM* stream)
{
    gsub_context_subst_f3* csf3;
    USHORT n;
    LF_ERROR error;
    size_t baseOffset, curOffset, newOffset;

    ASSERT(cs);
    ASSERT(stream);

    baseOffset = STREAM_streamPos(stream) - sizeof(cs->SubstFormat);

    csf3 = &cs->csf.csf3;

    csf3->GlyphCount = STREAM_readUShort(stream);
    csf3->SubstCount = STREAM_readUShort(stream);

    vector_init(&csf3->Coverage, csf3->GlyphCount, sizeof(ULONG));

    // read in the coverage offsets, and coverage tables
    for (n = 0; n < csf3->GlyphCount; n++)
    {
        coverage_table* ct = (coverage_table*)malloc(sizeof(coverage_table));
        if (!ct)
        {
            DEBUG_LOG_ERROR("Out of Memory - unable to allocate coverage table");
            goto Fail1;
        }

        newOffset = STREAM_readUShort(stream) + baseOffset;
        curOffset = STREAM_streamPos(stream);
        STREAM_streamSeek(stream, newOffset);

        error = Coverage_readTable(ct, stream);
        if ((error != LF_ERROR_OK) && (error != LF_EMPTY_TABLE))
        {
            DEBUG_LOG_ERROR("failed to read coverage table");
            goto Fail1;
        }

        vector_push_back(&csf3->Coverage, ct);

        STREAM_streamSeek(stream, curOffset);
    }

    error = Common_readSubstLookupRecords(&csf3->SubstLookupRecord, csf3->SubstCount, stream);

    return error;

Fail1:
    contextSubst_freeFormat3(csf3);
    return LF_OUT_OF_MEMORY;
}

static size_t contextSubst_buildFormat3(gsub_context_subst_f3* csf3, LF_STREAM* stream)
{
    size_t baseOffset = STREAM_streamPos(stream) - 2L;
    size_t coverageOffset = 0;
    size_t curOffset = 0;
    size_t offset = 0;
    ULONG n;

    ASSERT(stream);
    ASSERT(csf3);

    if (NULL == csf3)
        return 0;

    STREAM_writeUShort(stream, (USHORT)csf3->Coverage.count);                    // GlyphCount
    STREAM_writeUShort(stream, (USHORT)csf3->SubstLookupRecord.count);           // SubstCount

    // Coverage Array of Offset Coverage[GlyphCount]
    coverageOffset = STREAM_streamPos(stream);
    for (n = 0; n < csf3->Coverage.count; n++)
    {
        STREAM_writeUShort(stream, 0);
    }


    for (n = 0; n < csf3->Coverage.count; n++)
    {
        coverage_table* ct = (coverage_table*)vector_at(&csf3->Coverage, n);

        curOffset = STREAM_streamPos(stream);
        offset = curOffset - baseOffset;

        STREAM_streamSeek(stream, coverageOffset);
        STREAM_writeUShort(stream, (USHORT)offset);
        coverageOffset += sizeof(OFFSET);

        // build coverage
        STREAM_streamSeek(stream, curOffset);
        Coverage_buildTable(ct, stream);
    }

    // write out lookup records
    Common_buildSubstLookupRecords(&csf3->SubstLookupRecord, stream);

    return STREAM_streamPos(stream);
}

static size_t contextSubst_getFormat3Size(gsub_context_subst_f3* csf3)
{
    size_t size;
    size_t coverageSize;
    USHORT n, count;
    LF_ERROR error;

    size = sizeof(csf3->SubstCount);
    size += sizeof(csf3->GlyphCount);
    size += (sizeof(OFFSET) * csf3->Coverage.count);
    size += (sizeof(OFFSET) * csf3->SubstLookupRecord.count);

    count = (USHORT)csf3->Coverage.count;
    for (n = 0; n < count; n++)
    {
        coverage_table* table = (coverage_table*)vector_at(&csf3->Coverage, n);
        error = Coverage_getTableSize(table, &coverageSize);
        if (error != LF_ERROR_OK) {
            DEBUG_LOG_WARNING("coverage table size problem");
        }

        size += coverageSize;
    }
    size += Common_sizeSubstLookupRecords(&csf3->SubstLookupRecord);

    return size;
}


/* ----------------------------------------------------------------------------
    @description
        go through coverage set and remove the glyph from all of the 
        tables.

---------------------------------------------------------------------------- */
static LF_ERROR contextSubst_removeFormat3(gsub_context_subst_f3* csf3, GlyphID glyphid)
{
    LF_ERROR error;

    ASSERT(csf3);

    error = Coverage_removeCoveragesGlyphIndex(&csf3->Coverage, glyphid);

    if (error == LF_EMPTY_TABLE)
        return LF_EMPTY_TABLE;

    return LF_ERROR_OK;
}

static void contextSubst_freeFormat3(gsub_context_subst_f3* csf3)
{
    USHORT n, count;

    count = (USHORT)csf3->Coverage.count;
    for (n = 0; n < count; n++)
    {
        coverage_table* table = (coverage_table*)vector_at(&csf3->Coverage, n);
        Coverage_deleteTable(table);
        free(table);
    }
    vector_delete(&csf3->Coverage);

    Common_freeSubstLookupRecords(&csf3->SubstLookupRecord);
}

static LF_ERROR contextSubst_removeLookupIndexFormat1(gsub_context_subst_f1* csf1, USHORT refIndex, SHORT deltaIndex)
{
    LF_ERROR error = LF_ERROR_OK;
    ULONG n, i;

    // loop through the sub-rule sets
    for ( n = 0; n < csf1->SubRuleSet.count; n++)
    {
        context_rule_set* srs = (context_rule_set*)vector_at(&csf1->SubRuleSet, n);

        // loop through the sub-rules
        for ( i = 0; i < srs->RuleSet.count; i++)
        {
            context_rule* sr = (context_rule*)vector_at(&srs->RuleSet, i);
            error = Common_removeLookupListIndex(&sr->LookupRecords, refIndex, deltaIndex);
            if (error == LF_EMPTY_TABLE)
            {
                DEBUG_LOG("empty table");
            }
        }
    }
    return LF_ERROR_OK;
}

static LF_ERROR contextSubst_removeLookupIndexFormat2(gsub_context_subst_f2* table, USHORT refIndex, SHORT deltaIndex)
{
    ULONG n, i;
    LF_ERROR error = LF_ERROR_OK;

    n = 0;

    while ( n < table->SubClassSet.count)
    {
        class_set* scs = (class_set*)vector_at(&table->SubClassSet, n);
        if (scs && (scs->ClassRules != NULL))
        {
            i = 0;
            while (i < scs->ClassRules->count)
            {
                class_rule* scr = (class_rule*)vector_at(scs->ClassRules, i);
                if (scr)
                {
                    error = Common_removeLookupListIndex(&scr->LookupRecords, refIndex, deltaIndex);

                    if (error == LF_EMPTY_TABLE)
                    {
                        ClassRule_freeRule(scr);
                        FREE(scr);
                        vector_set_data(scs->ClassRules, i, NULL);
                        DEBUG_LOG_VALUE("removing ClassRules", i);
                    }
                }
                i++;
            }
        }

        n++;
    }

    return ClassSets_validClassRules(&table->SubClassSet);
}

static LF_ERROR contextSubst_removeLookupIndexFormat3(gsub_context_subst_f3* csf3, USHORT refIndex, SHORT deltaIndex)
{
    LF_ERROR error = Common_removeLookupListIndex(&csf3->SubstLookupRecord, refIndex, deltaIndex);
    return error;
}

LF_ERROR GSUB_removeContextSubstLookupIndex(gsub_context_substitution* cs, USHORT refIndex, SHORT deltaIndex)
{
    LF_ERROR error = LF_ERROR_OK;

    switch(cs->SubstFormat)
    {
    case 1:        error = contextSubst_removeLookupIndexFormat1(&cs->csf.csf1, refIndex, deltaIndex);        break;
    case 2:        error = contextSubst_removeLookupIndexFormat2(&cs->csf.csf2, refIndex, deltaIndex);        break;
    case 3:        error = contextSubst_removeLookupIndexFormat3(&cs->csf.csf3, refIndex, deltaIndex);        break;
    default:
        break;
    }
    return error;
}

static LF_ERROR contextSubst_pruneLookupRecordsFormat1(gsub_context_subst_f1* csf1)
{
    UNUSED(csf1);
    return LF_ERROR_OK;
}

/* ----------------------------------------------------------------------------
    @description
        do a final cleanup of format 2, by checking ClassRules, class
        context validation, empty classes, coverage tables.

    @param
---------------------------------------------------------------------------- */
static LF_ERROR contextSubst_pruneLookupRecordsFormat2(gsub_context_subst_f2* csf2)
{
    LF_ERROR error = LF_ERROR_OK;

    error = ClassSet_pruneEmptyClasses(&csf2->ClassDef, &csf2->SubClassSet);
    if (error == LF_EMPTY_TABLE)
        return error;

    ClassSet_cleanupCoverageClasses(&csf2->ClassDef, &csf2->SubClassSet, &csf2->Coverage);

    // check if final cleanup cleared the coverage table?
    if (Coverage_getCoverageCount(&csf2->Coverage) == 0)
        return LF_EMPTY_TABLE;

    error = ClassSets_validClassRules(&csf2->SubClassSet);

    return error;
}

static LF_ERROR contextSubst_pruneLookupRecordsFormat3(gsub_context_subst_f3* csf3)
{
    UNUSED(csf3);
    return LF_ERROR_OK;
}

LF_ERROR GSUB_pruneContextSubstLookupRecords(gsub_context_substitution* cs)
{
    LF_ERROR error = LF_ERROR_OK;

    switch(cs->SubstFormat)
    {
    case 1:        error = contextSubst_pruneLookupRecordsFormat1(&cs->csf.csf1);        break;
    case 2:        error = contextSubst_pruneLookupRecordsFormat2(&cs->csf.csf2);        break;
    case 3:        error = contextSubst_pruneLookupRecordsFormat3(&cs->csf.csf3);        break;
    default:
        break;
    }

    return error;
}

#ifdef LF_OT_DUMP
static void contextSubst_dumpFormat1(gsub_context_subst_f1* csf1)
{
#if _DEBUG
    USHORT i;
    DEBUG_LOG("-------------------------------------");
    DEBUG_LOG("Context Substitution Format 1");

    Coverage_dumpTable(&csf1->Coverage);

    for (i = 0; i < csf1->SubRuleSet.count; i++)
    {
        context_rule_set* crs = (context_rule_set*)vector_at(&csf1->SubRuleSet, i);
        ContextSet_dumpSet(crs);
    }

    DEBUG_LOG("-------------------------------------");
#else
    UNUSED(csf1);
#endif
}

static void contextSubst_dumpFormat2(gsub_context_subst_f2* csf2)
{
    XML_START("GSUBContextFormat2");

    Coverage_dumpTable(&csf2->Coverage);

    XML_START("ClassDef");
    ClassDef_dump(&csf2->ClassDef);
    XML_END("ClassDef");

    XML_START("ClassSets");
    ClassSets_dumpClassSets(&csf2->SubClassSet);
    XML_END("ClassSets");

    XML_END("GSUBContextFormat2");
}

static void contextSubst_dumpFormat3(gsub_context_subst_f3* csf3)
{
    (void)csf3;

    DEBUG_LOG("---- GSUB Context Format 3  ---------");
    DEBUG_LOG("-------------------------------------");
}

void GSUB_dumpContextSubst(gsub_context_substitution* cs)
{
    XML_START("ContextSubst");

    BaseTable_dump(cs);

    switch (cs->SubstFormat)
    {
    case 1:        contextSubst_dumpFormat1(&cs->csf.csf1);        break;
    case 2:        contextSubst_dumpFormat2(&cs->csf.csf2);        break;
    case 3:        contextSubst_dumpFormat3(&cs->csf.csf3);        break;
    default:                                                       break;
    }

    XML_END("ContextSubst");
}
#endif

static LF_ERROR contextSubst_remapGlyphsFormat1(gsub_context_subst_f1* csf1, LF_MAP* remap)
{
    Coverage_remapAll(&csf1->Coverage, remap);
    ContextSet_remapRuleSets(&csf1->SubRuleSet, remap);

    return LF_ERROR_OK;
}

static LF_ERROR contextSubst_remapGlyphsFormat2(gsub_context_subst_f2* csf2, LF_MAP* remap)
{
    Coverage_remapAll(&csf2->Coverage, remap);
    ClassDef_remapGlyphs(&csf2->ClassDef, remap);

    return LF_ERROR_OK;
}

static LF_ERROR contextSubst_remapGlyphsFormat3(gsub_context_subst_f3* csf3, LF_MAP* remap)
{
    return Coverage_remapTables(&csf3->Coverage, remap);
}

LF_ERROR GSUB_remapContextSubstGlyphs(gsub_context_substitution* cs, LF_MAP* remap)
{
    LF_ERROR error = LF_ERROR_OK;

    switch (cs->SubstFormat)
    {
    case 1:        contextSubst_remapGlyphsFormat1(&cs->csf.csf1, remap);        break;
    case 2:        contextSubst_remapGlyphsFormat2(&cs->csf.csf2, remap);        break;
    case 3:        contextSubst_remapGlyphsFormat3(&cs->csf.csf3, remap);        break;
    default:       error = LF_BAD_FORMAT;                                        break;
    }

    return error;
}

LF_ERROR GSUB_cleanupContextLookups(gsub_context_substitution* cs, TABLE_HANDLE hLookup)
{
    LF_ERROR    error;

    switch(cs->SubstFormat)
    {
    case 1:        error = contextSubst_cleanupLookupsFormat1(&cs->csf.csf1, hLookup);        break;
    case 2:        error = contextSubst_cleanupLookupsFormat2(&cs->csf.csf2, hLookup);        break;
    case 3:        error = contextSubst_cleanupLookupsFormat3(&cs->csf.csf3, hLookup);        break;
    default:       error = LF_BAD_FORMAT;                                                     break;
    }

    return error;
}

static LF_ERROR contextSubst_cleanupLookupsFormat1(gsub_context_subst_f1* csf1, TABLE_HANDLE hLookup)
{
    LF_ERROR    error = LF_ERROR_OK;
    ContextSet_cleanupLookups(&csf1->SubRuleSet, hLookup);
    return error;
}

static LF_ERROR contextSubst_cleanupLookupsFormat2(gsub_context_subst_f2* csf2, TABLE_HANDLE hLookup)
{
    ULONG i;
    for (i = 0; i < csf2->SubClassSet.count; i++)
    {
        class_set* crs = (class_set*)vector_at(&csf2->SubClassSet, i);
        if (crs)
            ClassSet_cleanupLookups(crs, hLookup);
    }

    return LF_ERROR_OK;
}

static LF_ERROR contextSubst_cleanupLookupsFormat3(gsub_context_subst_f3* csf3, TABLE_HANDLE hLookup)
{
    Common_cleanupLookups(&csf3->SubstLookupRecord, hLookup);

    return LF_ERROR_OK;
}

/* ============================================================================
    @summary
        process the context substitution lookup records and add any
        glyphs that may be present to the keep table stored in LF_FONT
        structure.

    @param
        keepList    :    pointer to glyph ids to keep
        hTable      :    pointer to the gsub_header structure
        table       :    pointer to the context substitution structure

    @return
        error       :    returns whether the context added glyphs

============================================================================ */
LF_ERROR GSUB_collectContextSubstGlyphs(GlyphList* keepList, TABLE_HANDLE hTable, gsub_context_substitution* table)
{
    LF_ERROR error = LF_ERROR_OK;

    switch (table->SubstFormat)
    {
    case 1:        error = contextSubst_collectContextSubstGlyphsFormat1(keepList,  hTable, &table->csf.csf1);        break;
    case 2:        error = contextSubst_collectContextSubstGlyphsFormat2(keepList, hTable, &table->csf.csf2);        break;
    case 3:        error = contextSubst_collectContextSubstGlyphsFormat3(keepList, hTable, &table->csf.csf3);        break;
    default:       error = LF_BAD_FORMAT;                                                                        break;
    }
    return error;
}

/* ----------------------------------------------------------------------------
    @summary
        process the context substitution lookup records that are stored
        as a format 1.

    @param
        keepList    :   pointer to glyph ids to keep
        hTable      :   pointer to the gsub_header structure
        csf1        :   pointer to the context substitution format 1
                        structure
    @return
        error       :    returns whether the context added glyphs
---------------------------------------------------------------------------- */
static LF_ERROR contextSubst_collectContextSubstGlyphsFormat1(GlyphList* keepList, TABLE_HANDLE hTable, gsub_context_subst_f1* csf1)
{
    LF_ERROR error = ContextSet_collectGlyphs(keepList, &csf1->SubRuleSet, hTable, &csf1->Coverage);
    return error;
}


/* ----------------------------------------------------------------------------
    @summary
        process the context substitution lookup records that are stored
        as a format 2.

    @param
        keepList    :    pointer to glyph ids to keep
        hTable      :    pointer to the gsub_header structure
        csf2        :    pointer to the context substitution format 2
                         structure
    @return
        error       :    returns whether the context added glyphs
---------------------------------------------------------------------------- */
static LF_ERROR contextSubst_collectContextSubstGlyphsFormat2(GlyphList* keepList, TABLE_HANDLE hTable, gsub_context_subst_f2* csf2)
{
    LF_ERROR error = LF_ERROR_OK;
    ULONG i;
    for (i = 0; i < csf2->SubClassSet.count; i++)
    {
        class_set* crs = (class_set*)vector_at(&csf2->SubClassSet, i);

        ClassSet_collectGlyphs(crs, keepList, hTable, &csf2->ClassDef);
    }

    return error;
}


/* ----------------------------------------------------------------------------
    @summary
        process the context substitution lookup records that are stored
        as a format 3.

        this will parse the coverage tables and determine if the coverage
        exists within the keepList.  if the keepList can match up a possible
        coverage context, the lookup records will be parsed.

    @param
        keepList    :   pointer to glyph ids to keep
        hTable      :   pointer to the gsub_header structure
        csf3        :   pointer to the context substitution format 2
                        structure
    @return
        error       :   returns whether the context added glyphs
---------------------------------------------------------------------------- */
static LF_ERROR contextSubst_collectContextSubstGlyphsFormat3(GlyphList* keepList, TABLE_HANDLE hTable, gsub_context_subst_f3* csf3)
{
    LF_ERROR    error = LF_ERROR_OK;
    ULONG        n;

    // check if the coverages exist to build the entire context
    for (n = 0; n < csf3->Coverage.count; n++)
    {
        coverage_table* coverage = (coverage_table*)vector_at(&csf3->Coverage, n);
        LF_ERROR coverageStatus = Coverage_existsInKeepList(coverage, keepList);

        if (coverageStatus != LF_ERROR_OK)
            return LF_NOT_COVERED;
    }

    error = Common_collectLookupRecordGlyphs(&csf3->SubstLookupRecord, keepList, hTable);

    return error;
}
