// Copyright (C) 2014 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// gsub_multiple.c

#include "gsub_lookup/gsub_multiple.h"
#include "common_table.h"
#include "utils.h"

// private multiple substitution functions
static LF_ERROR multipleSubst_readSequence(gsub_multiple_substitution* ms, gsub_subst_sequence* seq, USHORT coverageIndex, LF_STREAM* stream);
static void     multipleSubst_freeSequence(gsub_subst_sequence* seq);
static ULONG    multipleSubst_getSequenceSize(gsub_subst_sequence* seq);
static LF_ERROR multipleSubst_removeGlyphMultiple(gsub_multiple_substitution* ms, ULONG index);
static void     multipleSubst_freeSequenceList(link_list* list);


/* ----------------------------------------------------------------------------
    @summary
        stream in the sequence and store them in an array of glyphs.

        as the stream is read in, store off the any glyphs referenced
        glyphs into the master glyph list.  the function passes in the
        coverage glyph and will add the pair into the master list.

    @param
        ms  =           pointer to the multiple substitution structure
        seq =           pointer to the sequence structure that will populated from
                        the stream.

        coverageIndex = index into the coverage table that this sequence
                        is associated with.

        stream =        pointer to the stream at the beginning of the
                        sequence chunk.

    @returns
        status of the stream.

---------------------------------------------------------------------------- */
static LF_ERROR multipleSubst_readSequence(gsub_multiple_substitution* ms,
                                           gsub_subst_sequence* seq,
                                           USHORT coverageIndex, LF_STREAM* stream)
{
    USHORT      n, count;
    USHORT      coverageGlyph;
    //LF_ERROR    error;

    // Coverage_getCoverageAt always returns ok
    //error = Coverage_getCoverageAt(&ms->Coverage, coverageIndex, &coverageGlyph);
    Coverage_getCoverageAt(&ms->Coverage, coverageIndex, &coverageGlyph);

    count = seq->GlyphCount = STREAM_readUShort(stream);
    vector_init(&seq->Substitute, count, sizeof(ULONG));

    for ( n = 0; n < count; n++ )
    {
        USHORT glyph = STREAM_readUShort(stream);            // read in glyph ID
        vector_push_back(&seq->Substitute, (void*)(intptr_t)glyph);
    }
    return LF_ERROR_OK;
}


static void multipleSubst_freeSequence(gsub_subst_sequence* seq)
{
    vector_delete(&seq->Substitute);
}


/* ----------------------------------------------------------------------------
    @summary
        calculate the size of the sequence table.

    @param
        seq = pointer to the sequence
---------------------------------------------------------------------------- */
static ULONG multipleSubst_getSequenceSize(gsub_subst_sequence* seq)
{
    int size = sizeof(seq->GlyphCount);
    size += sizeof(GlyphID) * seq->GlyphCount;
    return ( size );
}


/* ============================================================================
    @summary
        read in multiple substitution lookup type and return the handle
        back to the caller.

        this function will create a structure containing a linked list
        which holds all of the substitution sequences that relate to
        the coverage index.



    @param
        lfFont    :    pointer to the LF_FONT structure that holds the
                       keep list for glyphs.

        stream    :    pointer to the start of the substitution rule in the
                       current stream.

    @return
        pointer to the multiple substitution rule, or NULL.

============================================================================ */
TABLE_HANDLE GSUB_readMultipleSubst(LF_STREAM* stream)
{
    gsub_multiple_substitution* ms;
    LF_ERROR                    error;
    USHORT                      n = 0, count;
    size_t                      curOffset, newOffset, baseOffset, coverageOffset;


    baseOffset = STREAM_streamPos(stream);                    // get the base offset of stream
    ms = (gsub_multiple_substitution*)calloc(1, sizeof(gsub_multiple_substitution));
    if (ms == NULL)
    {
        DEBUG_LOG_ERROR("failed to allocate multiple substitution structure");
        return NULL;
    }

    ms->SubstFormat = STREAM_readUShort(stream);            // copy substitution format
    if (ms->SubstFormat != 1)
    {
        DEBUG_LOG_ERROR("Unknown format found in multiple substitution");
        goto Fail;
    }

    coverageOffset        = STREAM_readUShort(stream);       // read the coverage table offset
    newOffset            = coverageOffset + baseOffset;
    curOffset            = STREAM_streamPos(stream);

    STREAM_streamSeek(stream, newOffset);                    // seek to the coverage table
    error = Coverage_readTable(&ms->Coverage, stream);       // read in the coverage table
    if ((error != LF_ERROR_OK) && (error != LF_EMPTY_TABLE)) // valid coverage table?
    {
        if (error != LF_EMPTY_TABLE)
            // TODO: Coverage failed
            goto Fail;
    }
    STREAM_streamSeek(stream, curOffset);
    count = STREAM_readUShort(stream);                       // get the SequenceCount
    list_init(&ms->SequenceList);                            // create Sequence[SequenceCount]

    for ( n = 0; n < count; n++)
    {
        gsub_subst_sequence* sequence;

        newOffset = STREAM_readUShort(stream) + baseOffset;  // get the sequence offset
        curOffset = STREAM_streamPos(stream);                // save current stream position
        STREAM_streamSeek(stream, newOffset);                // seek to sequence table

        // create the sequence
        sequence = (gsub_subst_sequence*)calloc(1, sizeof(gsub_subst_sequence));
        if (!sequence)
        {
            DEBUG_LOG_ERROR("failed to allocate memory for multiple substitution sequence");
            goto Fail1;
        }

        error = multipleSubst_readSequence(ms, sequence, n, stream);
        if (error != LF_ERROR_OK)
        {
            DEBUG_LOG_ERROR("failed to read multiple substitution sequence");
            goto Fail1;
        }

        if(NULL == list_append(&ms->SequenceList, (void*)sequence))
            goto Fail1;
        STREAM_streamSeek(stream, curOffset);
    }

    return (TABLE_HANDLE)ms;

Fail1:
    multipleSubst_freeSequenceList(&ms->SequenceList);

Fail:
    Coverage_deleteTable(&ms->Coverage);        // delete the coverage table
    FREE(ms);                                   // free the multiple substitution table
    return NULL;                                // return NULL back to caller
}


/* ============================================================================
    @summary
        free up the multiple substitution resources

============================================================================ */
void GSUB_freeMultipleSubst(gsub_multiple_substitution* ms)
{
    ASSERT(ms);

    multipleSubst_freeSequenceList(&ms->SequenceList);

    // release the coverage table
    Coverage_deleteTable(&ms->Coverage);

    FREE(ms);
}


/* ----------------------------------------------------------------------------
    @summary
        free up the sequence list and remove all of the nodes in the 
        SequenceList.

    @param
        list = pointer to the sequence linked list
---------------------------------------------------------------------------- */
static void multipleSubst_freeSequenceList(link_list* list)
{
    ASSERT(list);

    if (list)
    {
        // loop through the linked list and free up all of the tables
        while (list->count)
        {
            link_node* node = list_at(list, 0);
            gsub_subst_sequence* seq = (gsub_subst_sequence*)node->data;
            multipleSubst_freeSequence(seq);
            node->data = NULL;
            list_delete(list, node);
            FREE(seq);
        };
    }
}


/* ----------------------------------------------------------------------------
    @brief 
        build the multiple substitution sequence records.
---------------------------------------------------------------------------- */
static void multipleSubst_buildSequence(gsub_subst_sequence* seq, LF_STREAM* stream)
{
    USHORT n, count;

    count = UTILS_getCount(&seq->Substitute);
    STREAM_writeUShort(stream, count);

    for ( n = 0; n < count; n++ )
    {
        GlyphID id = (GlyphID)(intptr_t)vector_at(&seq->Substitute, n);
        STREAM_writeUShort(stream, id);
    }
}


/* ----------------------------------------------------------------------------
    @brief
        build the multiple substitution and send it to the stream
---------------------------------------------------------------------------- */
size_t GSUB_buildMultipleSubst(gsub_multiple_substitution* ms, LF_STREAM* stream)
{
    size_t    baseOffset = STREAM_streamPos(stream);
    size_t    coverageOffset = 0;
    size_t    sequenceOffset = 0;
    size_t    curOffset = 0;
    size_t    offset = 0;
    ULONG     n;

    STREAM_writeUShort(stream, ms->SubstFormat);            // save the multiple subst format.
    coverageOffset = STREAM_streamPos(stream);              // save the coverage position, so we can get back to it
    STREAM_writeOffset(stream, 0);                          // place holder coverage offset, until we get back

    // Stream sequence lists ....
    STREAM_writeUShort(stream, (USHORT)ms->SequenceList.count);           // save out the sequence count.

    sequenceOffset = STREAM_streamPos(stream);              // save the sequence offset stream position

    for ( n = 0; n < ms->SequenceList.count; n++ )
    {
        STREAM_writeUShort(stream, 0);                      // write temporary offset for sequence
    }

    // stream the sequence tables by looping through all sequences
    for ( n = 0; n < ms->SequenceList.count; n++ )
    {
        link_node* node = list_at(&ms->SequenceList, n);
        gsub_subst_sequence* seq = (gsub_subst_sequence*)node->data;

        curOffset = STREAM_streamPos(stream);               // get our current stream position
        offset = curOffset - baseOffset;                    // calculate the offset
        STREAM_streamSeek(stream, sequenceOffset);          // seek out the sequence offset table

        STREAM_writeOffset(stream, (OFFSET)offset);         // write the offset into the sequence offset
        sequenceOffset += sizeof(OFFSET);                   // increment to the next offset in the array.

        STREAM_streamSeek(stream, curOffset);               // go back to stream current position

        multipleSubst_buildSequence(seq, stream);
    }

    // Coverage table stream
    curOffset = STREAM_streamPos(stream);                   // get current stream position
    offset = curOffset - baseOffset;                        // calculate coverage offset
    STREAM_streamSeek(stream, coverageOffset);              // save offset into the stream coverage offset
    STREAM_writeUShort(stream, (USHORT)offset);
    STREAM_streamSeek(stream, curOffset);                   // back to where the coverage will be placed

    Coverage_buildTable(&ms->Coverage, stream);             // build the coverage table

    return STREAM_streamPos(stream);                        // return the current stream position ?
}


/* ============================================================================
    @brief
        returns the sizeof of the multiple substitution and all of it's
        sequence table sizes back to the caller.

        mainly used for memory allocation purposes.

    @param
        ms = pointer to the multiple substitution structure

    @return
        the size of the table.
============================================================================ */
size_t GSUB_getMultipleSubstSize(gsub_multiple_substitution* ms)
{
    size_t                    tableSize    = 0;
    USHORT                    n;

    // get the coverage table size
    Coverage_getTableSize(&ms->Coverage, &tableSize);            // first get the coverage size
    tableSize += sizeof(gsub_multiple_substitution_stream);      // add the multiple substitution size

    tableSize += ms->SequenceList.count * sizeof(OFFSET);        // add the table of sequence offsets

    // now we need to figure out all of the arrays and structures
    if (ms->SequenceList.count)
    {
        for (n = 0; n < ms->SequenceList.count; n++)
        {
            link_node* node = list_at(&ms->SequenceList, n);
            gsub_subst_sequence* seq = (gsub_subst_sequence*)node->data;
            tableSize += multipleSubst_getSequenceSize(seq);
        }
    }
    return tableSize;
}


LF_ERROR GSUB_removeMultipleGlyphIndex(gsub_multiple_substitution* ms, GlyphID glyphid)
{
    LF_ERROR    error;
    ULONG       index;

    // find the glyph in the coverage table

    error = Coverage_removeGlyphIndex(&ms->Coverage, glyphid, &index);
    if ( error == LF_ERROR_OK)
    {
        error = multipleSubst_removeGlyphMultiple(ms, index);
    }
    return error;
}


static LF_ERROR multipleSubst_removeGlyphMultiple(gsub_multiple_substitution* ms, ULONG index)
{
    link_node* node = NULL;
    gsub_subst_sequence* seq = NULL;

    ASSERT(ms);

    if (ms)
    {
        node = list_at(&ms->SequenceList, index);
        seq = (gsub_subst_sequence*)node->data;
        multipleSubst_freeSequence(seq);
        node->data = NULL;
        list_delete(&ms->SequenceList, node);
        free(seq);

        if(ms->SequenceList.count == 0)
            return LF_EMPTY_TABLE;
    }
    return LF_ERROR_OK;
}


LF_ERROR GSUB_remapMultipleSubstGlyphs(gsub_multiple_substitution* ms, LF_MAP* remap)
{
    LF_ERROR     error = LF_ERROR_OK;
    size_t       count;
    ULONG        n, i, seqcount;

    count = ms->SequenceList.count;

    for (n = 0; n < count; n++)
    {
        link_node* node = list_at(&ms->SequenceList, n);

        gsub_subst_sequence* seq = (gsub_subst_sequence*)node->data;

        seqcount = UTILS_getCount(&seq->Substitute);
        for (i = 0; i < seqcount; i++)
        {
            GlyphID oldid = (GlyphID)(intptr_t)vector_at(&seq->Substitute, i);
            GlyphID newid;

            error = Common_remapGlyph(remap, oldid, &newid);

            vector_set_data(&seq->Substitute, i, (void*)(intptr_t)newid);

            if (error != LF_ERROR_OK)
            {
                DEBUG_LOG_VALUE("Unable to remap glyph ID: ", oldid);
            }
        }
    };

    Coverage_remapAll(&ms->Coverage, remap);

    return error;
}


/* ============================================================================
    @summary
        parse the multiple substitution rule and determine if we
        need to add to the keep list or not.

    @param
        ms          :    pointer to the multiple substitution structure
        keepList    :    pointer to the keep list.

============================================================================ */
LF_ERROR GSUB_keepMultipleSubstGlyphs(gsub_multiple_substitution* ms, GlyphList* keepList)
{
    LF_ERROR    error, status;
    USHORT      i, j;
    USHORT      added = 0;

    status = LF_ERROR_OK;

    // loop through all of the sequence lists, and coverages
    for (i = 0; i < ms->SequenceList.count; i++)
    {
        GlyphID    coverageID;

        Coverage_getCoverageAt(&ms->Coverage, i, &coverageID);                    // get the coverage ID

        // check if coverage exists ...
        if (Keep_coverageExists(keepList, coverageID) == LF_ERROR_OK)
        {
            link_node*              node = (link_node*)list_at(&ms->SequenceList, i);
            gsub_subst_sequence*    seq = (gsub_subst_sequence*)node->data;

            // yes ... coverage exists, so add in substitution sequence 
            // into the keep list as well.
            for (j = 0; j < seq->Substitute.count; j++)
            {
                GlyphID glyph =  (GlyphID)(intptr_t)vector_at(&seq->Substitute, j);
                error = Keep_addGlyph(keepList, glyph);
                if (error == LF_ADDED_GLYPH)
                {
                    DEBUG_LOG_VALUE("GSUB Multiple added glyphID: ", glyph);
                    added++;
                }
            }
        }
    }

    if (added)
    {
        status = LF_ADDED_GLYPH;
    }

    return status;
}

#ifdef LF_OT_DUMP
void GSUB_dumpMultipleSubst(gsub_multiple_substitution* ms)
{
    size_t      count;
    ULONG       n, i, seqcount;

    XML_START("GSUBMultiple");
    Coverage_dumpTable(&ms->Coverage);

    count = ms->SequenceList.count;

    XML_START("Sequences");
    for (n = 0; n < count; n++)
    {
        link_node* node = list_at(&ms->SequenceList, n);

        gsub_subst_sequence* seq = (gsub_subst_sequence*)node->data;

        XML_START("Sequence")
        XML_COMMENT("Sequence", n);
        seqcount = UTILS_getCount(&seq->Substitute);
        for (i = 0; i < seqcount; i++)
        {
            GlyphID glyphid = (GlyphID)(long)vector_at(&seq->Substitute, i);
            XML_DATA_NODE("gid", glyphid);
        }
        XML_END("Sequence");
    }
    XML_END("Sequences");

    XML_END("GSUBMultiple");
}
#endif
