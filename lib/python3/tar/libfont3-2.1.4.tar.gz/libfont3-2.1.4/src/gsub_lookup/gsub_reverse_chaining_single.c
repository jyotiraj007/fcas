// Copyright (C) 2014 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// gsub_reverse_chaining_single.c

#include "utils.h"
#include "coverage_table.h"
#include "gsub_lookup/gsub_reverse_chaining_single.h"


TABLE_HANDLE GSUB_readReverseChainSingleSubst(LF_STREAM* stream)
{
    LF_ERROR    error = LF_EMPTY_TABLE;
    USHORT      n, count;
    size_t      curOffset, newOffset, baseOffset;
    OFFSET      coverageOffset;

    gsub_reverse_chain_single_substitution* rcs = (gsub_reverse_chain_single_substitution*)calloc(1, sizeof(gsub_reverse_chain_single_substitution));

    if (!rcs)
    {
        DEBUG_LOG_ERROR("gsub structure failed to allocate memory");
        goto readContextFailure;
    }

    baseOffset = STREAM_streamPos(stream);                           // beginning of substitution table

    rcs->SubstFormat = STREAM_readUShort(stream);                    // Read SubstFormat
    if (rcs->SubstFormat != 1)
        goto Fail1;

    coverageOffset = STREAM_readOffset(stream);                      // get Coverage Offset
    newOffset = coverageOffset + baseOffset;
    curOffset = STREAM_streamPos(stream);
    STREAM_streamSeek(stream, newOffset);                            // goto the coverage table
    error = Coverage_readTable(&rcs->Coverage, stream);
    if (error != LF_ERROR_OK)
    {
        if (error != LF_EMPTY_TABLE)
        {
            DEBUG_LOG_ERROR("problem reading coverage table");
            goto Fail1;
        }
    }

    STREAM_streamSeek(stream, curOffset);
    count = rcs->BacktrackGlyphCount = STREAM_readUShort(stream);
    error = Coverage_readArray(&rcs->BacktrackGlyphCoverage, count, stream, (ULONG)baseOffset);
    if (error != LF_ERROR_OK)
    {
        DEBUG_LOG_ERROR("problem reading backtrack glyph coverage");
        goto Fail1;
    }

    count = rcs->LookaheadGlyphCount = STREAM_readUShort(stream);
    error = Coverage_readArray(&rcs->LookaheadGlyphCoverage, count, stream, (ULONG)baseOffset);
    if (error != LF_ERROR_OK)
    {
        DEBUG_LOG_ERROR("problem reading lookahead glyph coverage");
        goto Fail1;
    }

    count = rcs->GlyphCount = STREAM_readUShort(stream);
    error = vector_init(&rcs->Substitute, count, sizeof(ULONG));
    if (error != LF_ERROR_OK)
    {
        DEBUG_LOG_ERROR("problem reading Substitute glyphs");
        goto Fail1;
    }

    for ( n = 0; n < count; n++)
    {
        vector_push_back(&rcs->Substitute, (void*)(intptr_t)STREAM_readUShort(stream));
    }

    return (TABLE_HANDLE)rcs;

Fail1:
    GSUB_freeReverseChainSingleSubst(rcs);

readContextFailure:
    return NULL;
}



size_t GSUB_buildReverseChainSingleSubst(gsub_reverse_chain_single_substitution* rcs, LF_STREAM* stream)
{
    size_t  baseOffset;
    size_t  coverageOffset, backtrackOffset, lookaheadOffset;
    USHORT  n, count;

    baseOffset = STREAM_streamPos(stream);                            // start of Substitution table
    STREAM_writeUShort(stream, rcs->SubstFormat);

    coverageOffset = STREAM_streamPos(stream);
    STREAM_writeOffset(stream, 0);                                    // placeholder value for coverage offset

    count = (USHORT)rcs->BacktrackGlyphCoverage.count;
    STREAM_writeUShort(stream, count);                                // BacktrackGlyphCount
    backtrackOffset = STREAM_streamPos(stream);                       // BacktrackGlyphOffset

    // placeholder array
    for (n = 0; n < count; n++)
    {
        STREAM_writeOffset(stream, 0);
    }

    count = (USHORT)rcs->LookaheadGlyphCoverage.count;
    STREAM_writeUShort(stream, count);                                // BacktrackGlyphCount
    lookaheadOffset = STREAM_streamPos(stream);                       // BacktrackGlyphOffset

    // placeholder array
    for (n = 0; n < count; n++)
    {
        STREAM_writeOffset(stream, 0);
    }


    count = (USHORT)rcs->Substitute.count;
    STREAM_writeUShort(stream, count);
    for ( n = 0; n < count; n++)
    {
        STREAM_writeUShort(stream, (USHORT)(intptr_t)vector_at(&rcs->Substitute, n));
    }

    Coverage_buildTables(&rcs->BacktrackGlyphCoverage, stream, (ULONG)baseOffset, (ULONG)backtrackOffset);
    Coverage_buildTables(&rcs->LookaheadGlyphCoverage, stream, (ULONG)baseOffset, (ULONG)lookaheadOffset);
    Coverage_buildCoverage(&rcs->Coverage, stream, (ULONG)coverageOffset, (ULONG)baseOffset);

    return STREAM_streamPos(stream);
}


size_t GSUB_sizeReverseChainSingleSubst(gsub_reverse_chain_single_substitution* rcs)
{
    size_t coverageSize, size;
    size = sizeof(rcs->SubstFormat);

    size += sizeof(OFFSET);                        // Coverage Offset
    size += sizeof(USHORT);                        // BacktrackGlyphCount
    size += sizeof(USHORT);                        // LookaheadGlyphCount
    size += sizeof(USHORT);                        // GlyphCount

    // all of the offset arrays
    size += sizeof(OFFSET) * rcs->BacktrackGlyphCoverage.count;
    size += sizeof(OFFSET) * rcs->LookaheadGlyphCoverage.count;

    // Coverage
    Coverage_getTableSize(&rcs->Coverage, &coverageSize);
    size += coverageSize;

    size += Coverage_sizeCoverages(&rcs->BacktrackGlyphCoverage);
    size += Coverage_sizeCoverages(&rcs->LookaheadGlyphCoverage);
    size += (rcs->Substitute.count * sizeof(USHORT));

    return size;
}


static void freeCoverages(LF_VECTOR* coverages)
{
    USHORT n;
    for ( n = 0; n < coverages->count; n++)
    {
        coverage_table* table = (coverage_table*)vector_at(coverages, n);
        Coverage_deleteTable(table);
        free(table);
    }
    vector_delete(coverages);
}


void GSUB_freeReverseChainSingleSubst(gsub_reverse_chain_single_substitution* rcs)
{
    Coverage_deleteTable(&rcs->Coverage);
    freeCoverages(&rcs->BacktrackGlyphCoverage);
    freeCoverages(&rcs->LookaheadGlyphCoverage);
    vector_delete(&rcs->Substitute);

    FREE(rcs);
}

LF_ERROR GSUB_removeReverseChainSingleSubst(gsub_reverse_chain_single_substitution* rcs, GlyphID glyphid)
{
    LF_ERROR    error;
    ULONG       coverageIndex;

    // 1rst stage, remove coverage match ups.
    error = Coverage_removeGlyphIndex(&rcs->Coverage, glyphid, &coverageIndex);
    if ( error == LF_EMPTY_TABLE)
    {
        return error;
    }


    // keep coverage and substitution tables in sync ...
    if (error == LF_ERROR_OK)
    {
        vector_erase(&rcs->Substitute, coverageIndex);
    }


    // TODO: go through the Backtrack, and Lookahead for glyph removal
    if (rcs->BacktrackGlyphCount)
    {
        // We can prune this list of coverages

    }


    if (rcs->LookaheadGlyphCount)
    {
        // We can prune this list of coverages

    }
    return error;
}

LF_ERROR GSUB_removeReverseChainSingleSubstLookupIndex(gsub_reverse_chain_single_substitution* table, USHORT refIndex, SHORT deltaIndex)
{
    UNUSED(table);
    UNUSED(refIndex);
    UNUSED(deltaIndex);
    return LF_ERROR_OK;
}

LF_ERROR GSUB_remapReverseChainSingleSubstGlyphs(gsub_reverse_chain_single_substitution* ss, LF_MAP* remap)
{
    LF_ERROR error = LF_ERROR_OK;
    ULONG n;

    Coverage_remapTables(&ss->BacktrackGlyphCoverage, remap);
    Coverage_remapTables(&ss->LookaheadGlyphCoverage, remap);
    Coverage_remapAll(&ss->Coverage, remap);

    for (n = 0; n < ss->Substitute.count; n++)
    {
        GlyphID oldid = (GlyphID)(intptr_t)vector_at(&ss->Substitute, n);
        GlyphID newid = (GlyphID)(intptr_t)map_at(remap, (void*)(intptr_t)oldid);
        if (newid)
            vector_set_data(&ss->Substitute, n, (void*)(intptr_t)newid);
    }

    return error;
}
