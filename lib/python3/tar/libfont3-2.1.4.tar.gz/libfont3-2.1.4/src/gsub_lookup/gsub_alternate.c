// Copyright (C) 2014, 2017 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// gsub_alternate.c

#include "utils.h"
#include "common_table.h"
#include "gsub_lookup/gsub_alternate.h"

static LF_ERROR altSubst_readAlternateSet(gsub_alternate_set* set, LF_STREAM* stream)
{
    USHORT      n;
    LF_ERROR    error;

    set->GlyphCount = STREAM_readUShort(stream);
    error = vector_init(&set->Alternate, set->GlyphCount, sizeof(ULONG));

    if (error != LF_ERROR_OK)
    {
        DEBUG_LOG_ERROR("failed to allocate memory for GSUB_alternate");
        return error;
    }

    for (n = 0; n < set->GlyphCount; n++)
    {
        GlyphID glyph = STREAM_readUShort(stream);
        error = vector_push_back(&set->Alternate, (void*)(intptr_t)glyph);
        if (error != LF_ERROR_OK)
        {
            // cleanup needed
            return error;
        }
    }

    return error;
}

/* ----------------------------------------------------------------------------
@brief
free the alternate set resources

@param
set = pointer to the alternate set
---------------------------------------------------------------------------- */
static void altSubst_freeAlternateSet(gsub_alternate_set* set)
{
    vector_delete(&set->Alternate);
    free(set);
}

/* ----------------------------------------------------------------------------
@summary
free up the sequence list and remove all of the nodes in the
SequenceList.

@param
list = pointer to the sequence linked list
---------------------------------------------------------------------------- */
static void altSubst_freeAlternateSetList(link_list* list)
{
    ASSERT(list);

    // loop through the linked list and free up all of the tables
    while (list->count)
    {
        link_node* node = list_at(list, 0);
        gsub_alternate_set* set = (gsub_alternate_set*)node->data;
        altSubst_freeAlternateSet(set);
        list_delete(list, node);
    };
}

/* ============================================================================
    @summary
        LookupType 3: Alternate Substitution Subtable

        read in the alternate substitution table from the stream and store
        it in the TABLE_HANDLE instance.

    @param
        stream = pointer to the stream that contains the input stream

    @return
        pointer to the alternate substitution subtable and all of
        its components.  returns NULL if an error occurred while
        loading the the subtable.

    @see also
        http://partners.adobe.com/public/developer/opentype/index_table_formats1.html#ASF1

============================================================================ */
TABLE_HANDLE GSUB_readAlternateSubst(LF_STREAM* stream)
{
    LF_ERROR    error;
    USHORT      n = 0, count;
    size_t      curOffset, newOffset, baseOffset;
    gsub_alternate_substitution*    as;

    baseOffset = STREAM_streamPos(stream);

    as = (gsub_alternate_substitution*)calloc(1, sizeof(gsub_alternate_substitution));
    if (as == NULL)
    {
        DEBUG_LOG_ERROR("failed to allocate memory for GSUB alternate substitution");
        return NULL;
    }

    //    GSUB_initBase(lfFont, (TABLE_HANDLE)as);

    as->SubstFormat = STREAM_readUShort(stream);
    if (as->SubstFormat != 1)
    {
        DEBUG_LOG_ERROR("bad SubstFormat in GSUB alternate substitution");
        goto CoverageFailure;
    }

    newOffset = STREAM_readUShort(stream) + baseOffset;
    curOffset = STREAM_streamPos(stream);

    STREAM_streamSeek(stream, newOffset);
    error = Coverage_readTable(&as->Coverage, stream);
    if (error != LF_ERROR_OK)
    {
        if (error != LF_EMPTY_TABLE)
        {
            DEBUG_LOG_ERROR("failed to read Coverage in GSUB alternate substitution");
            goto CoverageFailure;
        }
    }

    STREAM_streamSeek(stream, curOffset);
    count = STREAM_readUShort(stream);

    list_init(&as->AlternateSetList);

    for ( n = 0; n < count; n++ )
    {
        gsub_alternate_set* set = (gsub_alternate_set*)calloc(1, sizeof(gsub_alternate_set));

        if (!set)
        {
            DEBUG_LOG_ERROR("failed to allocate GSUB alternate set");
            goto ReadAlternateSetFailure;
        }

        newOffset = STREAM_readUShort(stream) + baseOffset;
        curOffset = STREAM_streamPos(stream);
        STREAM_streamSeek(stream, newOffset);                // seek to alternate set table

        error = altSubst_readAlternateSet(set, stream);
        if (error != LF_ERROR_OK)
        {
            DEBUG_LOG_ERROR("failed to read GSUB alternate set");
            free(set);
            goto ReadAlternateSetFailure;
        }

        // create link_node and add it to the list of sets
        if(NULL == list_append(&as->AlternateSetList, (void*)set))        // append it to list
            goto ReadAlternateSetFailure;

        STREAM_streamSeek(stream, curOffset);            // go back to offset
    }

    return (TABLE_HANDLE)as;


ReadAlternateSetFailure:
    altSubst_freeAlternateSetList(&as->AlternateSetList);
    Coverage_deleteTable(&as->Coverage);

CoverageFailure:
    free(as);
    return NULL;
}

/* ----------------------------------------------------------------------------
@brief
build the alternate set and write it out to the stream

@param
aset = pointer to the alternate set structure.
stream = pointer to the stream.
---------------------------------------------------------------------------- */
static void altSubst_buildAlternateSet(gsub_alternate_set* aset, LF_STREAM* stream)
{
    USHORT count, n;

    count = UTILS_getCount(&aset->Alternate);

    STREAM_writeUShort(stream, count);
    for (n = 0; n < count; n++)
    {
        GlyphID glyph = (GlyphID)(intptr_t)vector_at(&aset->Alternate, n);
        STREAM_writeUShort(stream, glyph);
    }
}

/* ----------------------------------------------------------------------------
    @brief
        Build the alternate substitution and send it to the stream

        -----------------------------------------------------------------
        Type    Name                Description
        -----------------------------------------------------------------
        USHORT    SubstFormat         Format identifier-format = 1

        OFFSET    Coverage            Offset to Coverage table-from
                                      beginning of Substitution table

        USHORT    AlternateSetCount   Number of AlternateSet tables

        OFFSET    AlternateSet
                 [AlternateSetCount]  Array of offsets to AlternateSet
                                      tables-from beginning of Substitution
                                      table-ordered by Coverage Index

---------------------------------------------------------------------------- */
size_t GSUB_buildAlternateSubst(gsub_alternate_substitution* asub, LF_STREAM* stream)
{
    size_t  baseOffset = STREAM_streamPos(stream);
    size_t  coverageOffset = 0;
    size_t  setOffset = 0;
    size_t  setArrayOffset = 0;
    size_t  curOffset = 0;
    size_t  offset = 0;
    size_t  n, count;

    STREAM_writeUShort(stream, asub->SubstFormat);            // save the alternate subst format. (should be 1)
    coverageOffset = STREAM_streamPos(stream);                // save the coverage position, so we can get back to it
    STREAM_writeOffset(stream, 0);                            // place holder coverage offset.

    count = asub->AlternateSetList.count;

    STREAM_writeUShort(stream, (USHORT)count);                // write out a number of alternate set counts
    setArrayOffset = STREAM_streamPos(stream);                // save position for the set of offsets.

    for (n = 0; n < count; n++)                               // loop through the alternate set offset array
    {
        STREAM_writeUShort(stream, 0);                        // write out placeholders for offsets
    }

    for (n = 0; n < count; n++)
    {
        link_node* node;
        gsub_alternate_set* aset;

        setOffset = STREAM_streamPos(stream);                    // save the current offset

        node = list_at(&asub->AlternateSetList, (int)n);
        aset = (gsub_alternate_set*)node->data;

        altSubst_buildAlternateSet(aset, stream);                // write out the set table

        curOffset = STREAM_streamPos(stream);                    // save current offset
        STREAM_streamSeek(stream, setArrayOffset);               // go back to offset array
        STREAM_writeOffset(stream, (OFFSET)(setOffset - baseOffset));    // write out the set offset into stream
        STREAM_streamSeek(stream, curOffset);                    // restore current stream offset

        setArrayOffset += sizeof(OFFSET);                        // increment set offset to the next array element
    }


    // Coverage table stream
    curOffset = STREAM_streamPos(stream);                        // get current stream position
    offset = curOffset - baseOffset;                             // calculate coverage offset
    STREAM_streamSeek(stream, coverageOffset);                   // save offset into the stream coverage offset 
    STREAM_writeOffset(stream, (OFFSET)offset);
    STREAM_streamSeek(stream, curOffset);                        // back to where the coverage will be placed

    Coverage_buildTable(&asub->Coverage, stream);                // build the coverage table

    return STREAM_streamPos(stream);
}

/* ============================================================================
    @brief
        return the chunk size of the alternate substitution table.

    @param
        as = pointer to the alternate substitution table to calculate

    @return
        size = the size of the alternate substitution table

============================================================================ */
size_t GSUB_getAlternateSubstSize(gsub_alternate_substitution* as)
{
    size_t size = 0;
    ULONG n;

    Coverage_getTableSize(&as->Coverage, &size);            // Coverage Table size
    size += sizeof(as->SubstFormat);                        // Substitution Format
    size += sizeof(OFFSET);                                 // Coverage OFFSET
    size += sizeof(USHORT);                                 // AlternateSetCount
    size += sizeof(USHORT) * as->AlternateSetList.count;    // array of OFFSETS for AlternateSet[AlternateSetCount]

    for (n = 0; n < as->AlternateSetList.count; n++)
    {
        link_node* node = list_at(&as->AlternateSetList, n);
        gsub_alternate_set* aset = (gsub_alternate_set*)node->data;
        size += sizeof(USHORT) + (sizeof(GlyphID) * aset->Alternate.count);
    }

    return size;
}

/* ----------------------------------------------------------------------------
    @desc
        free up the alternate substitution resources.

    @param 
        as = pointer to the substitution class.

---------------------------------------------------------------------------- */
void GSUB_freeAlternateSubst(gsub_alternate_substitution* as)
{
    altSubst_freeAlternateSetList(&as->AlternateSetList);
    Coverage_deleteTable(&as->Coverage);

    free(as);
}

/* ----------------------------------------------------------------------------
@summary
remove the set that is associated with the index that is passed.  the
coverage table must be in sync with set table.

@param
as = pointer to the alternate substitution rule.
index = coverage index.

---------------------------------------------------------------------------- */
static LF_ERROR altSubst_removeGlyphAlternate(gsub_alternate_substitution* as, ULONG index)
{
    link_node* node = NULL;
    gsub_alternate_set* set = NULL;
    link_list* list = NULL;

    ASSERT(as);

    list = &as->AlternateSetList;

    node = list_at(list, index);

    if (node)
    {
        set = (gsub_alternate_set*)node->data;
        altSubst_freeAlternateSet(set);
        list_delete(list, node);
    }

    return (list->count == 0) ? LF_EMPTY_TABLE : LF_ERROR_OK;
}

LF_ERROR GSUB_removeAlternateGlyphIndex(gsub_alternate_substitution* as, GlyphID glyphid)
{
    ULONG       index;

    // find the glyph in the coverage table
    LF_ERROR error = Coverage_removeGlyphIndex(&as->Coverage, glyphid, &index);

    if (error == LF_ERROR_OK)
    {
        error = altSubst_removeGlyphAlternate(as, index);

#ifdef _DEBUG
        ASSERT(as->Coverage.CoverageMap.count == as->AlternateSetList.count);
#endif
    }

    // TODO: prune the Alternate sets as well
    return error;
}

LF_ERROR GSUB_remapAlternateGlyphs(gsub_alternate_substitution* as, LF_MAP* remap)
{
    LF_ERROR    error = LF_ERROR_OK;
    USHORT        i, j;

    for (i = 0; i < as->AlternateSetList.count; i++)
    {
        link_node*          node = list_at(&as->AlternateSetList, i);
        gsub_alternate_set* set = (gsub_alternate_set*)node->data;

        for (j = 0; j < set->Alternate.count; j++)
        {
            GlyphID seqid = (GlyphID)(intptr_t)vector_at(&set->Alternate, j);
            GlyphID newid;

            LF_ERROR status = Common_remapGlyph(remap, seqid, &newid);

            vector_set_data(&set->Alternate, j, (void*)(intptr_t)newid);

            if (status != LF_ERROR_OK)
            {
                DEBUG_LOG_VALUE("problem remapping glyphid", seqid);
            }
        }
    }

    Coverage_remapAll(&as->Coverage, remap);

    return error;
}

LF_ERROR GSUB_keepAlternateSubstGlyphs(gsub_alternate_substitution* as, GlyphList* keepList)
{
    GlyphID     coverageGlyph;
    USHORT      coverageCount;
    USHORT      n;
    USHORT      added = 0;
    LF_ERROR    status = LF_NOT_COVERED;
    LF_ERROR    error;

    coverageCount = (USHORT)Coverage_getCoverageCount(&as->Coverage);

    for (n = 0; n < coverageCount; n++)
    {
        gsub_alternate_set* set;
        link_node*          node;

        error = Coverage_getCoverageAt(&as->Coverage, n, &coverageGlyph);

        if (error == LF_ERROR_OK)
        {
            // check if the coverage exists in the keep list ...
            if (Keep_coverageExists(keepList, coverageGlyph) == LF_ERROR_OK)
            {
                USHORT    i;
                node = list_at(&as->AlternateSetList, n);
                set  = (gsub_alternate_set*)node->data;

                for (i = 0; i < set->Alternate.count; i++)
                {
                    GlyphID glyph = (GlyphID)(intptr_t)vector_at(&set->Alternate, i);

                    error = Keep_addGlyph(keepList, glyph);
                    if (error == LF_ADDED_GLYPH)
                        added++;
                }
            }
        }
    }

    if (added)
    {
        status = LF_ADDED_GLYPH;
    }

    return status;
}

#ifdef LF_OT_DUMP
void GSUB_dumpAlternateSubst(gsub_alternate_substitution* as)
{
    XML_START("GSUBAlternate");
    Coverage_dumpTable(&as->Coverage);

    XML_START("AlternateSetList");
    for (ULONG n = 0; n < as->AlternateSetList.count; n++)
    {
        link_node* node = list_at(&as->AlternateSetList, n);

        if (node != NULL)
        {
            XML_START("AlternateSet");
            gsub_alternate_set* altSet = (gsub_alternate_set*)node->data;

            for (size_t i = 0; i < altSet->Alternate.count; i++)
            {
                GlyphID gid = (GlyphID)(long)vector_at(&altSet->Alternate, i);
                XML_DATA_NODE("GID", gid);
            }
            XML_END("AlternateSet");
        }
    }
    XML_END("AlternateSetList");
    XML_END("GSUBAlternate");
}
#endif
