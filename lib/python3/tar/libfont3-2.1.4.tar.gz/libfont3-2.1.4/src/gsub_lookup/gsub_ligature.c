// Copyright (C) 2014 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// gsub_ligature.c

/* ----------------------------------------------------------------------------
    @summary
        LookupType 4: Ligature Substitution Subtable

        A Ligature Substitution (LigatureSubst) subtable identifies ligature
        substitutions where a single glyph replaces multiple glyphs. One
        LigatureSubst subtable can specify any number of ligature substitutions.

        The subtable uses a single format: LigatureSubstFormat1. It contains
        a format identifier (SubstFormat), a Coverage table offset (Coverage),
        a count of the ligature sets defined in this table (LigSetCount), and
        an array of offsets to LigatureSet tables (LigatureSet). The Coverage
        table specifies only the index of the first glyph component of each
        ligature set.

    @example
        a LigatureSubstFormat1 subtable that defines data to 
        replace a string of glyphs with a single ligature glyph. Because a 
        LigatureSubstFormat1 subtable can specify glyph substitutions for 
        more than one ligature, this subtable defines three ligatures: 
            "etc" 
            "ffi"
            "fi"

        The sample subtable contains a format identifier (4) and an offset to 
        a Coverage table. The Coverage table, which lists an index for each first 
        glyph in the ligatures, lists indices for the "e" and "f" glyphs. The 
        Coverage table range format is used here because the "e" and "f" glyph 
        indices are numbered consecutively.

        In the LigatureSubst subtable, LigSetCount specifies two LigatureSet 
        tables, one for each covered glyph, and the LigatureSet array stores 
        offsets to them. In this array, the "e" LigatureSet precedes the "f" 
        LigatureSet, matching the order of the corresponding first-glyph 
        components in the Coverage table.

        Each LigatureSet table identifies all ligatures that begin with a 
        covered glyph. The sample LigatureSet table defined for the "e" 
        glyph contains only one ligature, "etc." A LigatureSet table defined 
        for the "f" glyph contains two ligatures, "ffi" and "fi."

        The sample FLigaturesSet table has offsets to two Ligature tables, 
        one for "ffi" and one for "fi." The Ligature array lists the "ffi" 
        Ligature table first to indicate that the "ffi" ligature is preferred 
        to the "fi" ligature.

---------------------------------------------------------------------------- */

#include "utils.h"
#include "gsub_lookup/gsub_ligature.h"
#include "common_table.h"

static LF_ERROR ligSubst_readLigatureSet(gsub_ligature_set_table* ligSet, GlyphID coverageID, LF_STREAM* stream);
static LF_ERROR ligSubst_readLigatureTable(gsub_ligature_table* lig, GlyphID coverageID, LF_STREAM* stream);

static void     ligSubst_freeLigatureTable(gsub_ligature_table* lig);
static void     ligSubst_freeLigatureSet(gsub_ligature_set_table* ligSet);
static void     ligSubst_freeLigatureSetList(LF_VECTOR* list);

static size_t   ligSubst_sizeofLigatureSetList(gsub_ligature* lig);
static size_t   ligSubst_sizeofLigatureSet(gsub_ligature_set_table* set);
static ULONG    ligSubst_sizeofLigatureTable(gsub_ligature_table* table);

static size_t   ligSubst_buildLigatureSetList(gsub_ligature* lig, LF_STREAM* stream);
static size_t   ligSubst_buildLigatureSet(gsub_ligature_set_table* set, LF_STREAM* stream);
static size_t   ligSubst_buildLigatureTable(gsub_ligature_table* table, LF_STREAM* stream);

static LF_ERROR ligSubst_removeLigatureSet(gsub_ligature* lig, ULONG index);
static LF_ERROR ligSubst_removeLigatureTables(gsub_ligature* lig, GlyphID id);


/* ============================================================================
    @summary
        read and create a new instance of the Ligature substitution format
        and return it back to the caller.  The function creates a new ligature
        structure and uses the stream to populate the structure.

        There is 1 format for the ligature substitution rule and it contains
        multiple types of structures that reflect the substitution values

        The function will populate the master glyph list by reading the
        substitution tables.

    @param
        stream = pointer to the stream
        font = pointer to LF_FONT structure.

    @returns
        pointer to the ligature substitution table.

============================================================================ */
TABLE_HANDLE GSUB_readLigatureSubst(LF_STREAM* stream)
{
    LF_ERROR                    error;
    gsub_ligature*              lig;
    gsub_ligature_set_table*    ligSet;
    LF_VECTOR*                  list;
    USHORT                      n = 0, count;
    size_t                      baseOffset, newOffset, currOffset;
    size_t                      coverageOffset;


    lig = (gsub_ligature*)calloc(1, sizeof(gsub_ligature));
    if (lig == NULL) 
    {
        DEBUG_LOG_ERROR("failed to allocate gsub_ligature structure");
        return NULL;
    }
//    GSUB_initBase(lfFont, (TABLE_HANDLE)lig);

    baseOffset = STREAM_streamPos(stream);                          // get the base offset
    lig->SubstFormat = STREAM_readUShort(stream);                   // read format

    // read in the coverage table
    coverageOffset = STREAM_readUShort(stream) + baseOffset;        // get coverage offset
    currOffset = STREAM_streamPos(stream);                          // save current offset
    STREAM_streamSeek(stream, coverageOffset);                      // seek coverage table
    error = Coverage_readTable(&lig->Coverage, stream);             // read coverage table
    if (error != LF_ERROR_OK)
    {
        if (error != LF_EMPTY_TABLE)
        {
            DEBUG_LOG_ERROR("failed to read coverage table");
            goto CoverageFailure;
        }
    }

    STREAM_streamSeek(stream, currOffset);                          // seek back to table
    count = STREAM_readUShort(stream);                              // read in LigSetCount


    list = &lig->LigatureSetList;                                   // create a linked list
    vector_init(list, count, sizeof(ULONG));


    // loop through the ligature set array of offsets
    for ( n = 0; n < count; n++ )
    {
        LONG streamStatus;
        GlyphID coverageID;
        newOffset = STREAM_readUShort(stream) + baseOffset;         // get the LigatureSet Offset
        currOffset = STREAM_streamPos(stream);                      // save current offset
        streamStatus = STREAM_streamSeek(stream, newOffset);        // seek the ligature set

        if (streamStatus != -1)
        {
            ligSet = (gsub_ligature_set_table*)calloc(1, sizeof(gsub_ligature_set_table));
            if (!ligSet)
            {
                DEBUG_LOG_ERROR("failed to allocate gsub ligature set table structure");
                goto LigatureSetFailure;
            }

            error = Coverage_getCoverageAt(&lig->Coverage, n, &coverageID);
            if (error != LF_ERROR_OK)
            {
                DEBUG_LOG_ERROR("mismatched coverage table to ligature set tables");
                goto LigatureSetFailure;
            }


            error = ligSubst_readLigatureSet( ligSet, coverageID, stream);
            if (error != LF_ERROR_OK)
            {
                DEBUG_LOG_ERROR("failed to read ligature set");
                goto LigatureSetReadFailure;
            }

            vector_push_back(list, ligSet);
        }
        STREAM_streamSeek(stream, currOffset);

    }

    return lig;


LigatureSetReadFailure:
    ligSubst_freeLigatureSet(ligSet);

LigatureSetFailure:
    FREE(ligSet);
    ligSubst_freeLigatureSetList(list);
    Coverage_deleteTable(&lig->Coverage);

CoverageFailure:
    FREE(lig);
    return NULL;
}


size_t GSUB_buildLigatureSubst(gsub_ligature* lig, LF_STREAM* stream)
{
    ASSERT(lig);

//#if _ROBA && _DEBUG
#ifdef LF_OT_DEBUG
    if (BaseTable_isDump(lig) == TRUE)
        GSUB_dumpLigatureSubst(lig);
#endif

    ligSubst_buildLigatureSetList(lig, stream);

    return STREAM_streamPos(stream);
}


size_t GSUB_getLigatureSubstSize(gsub_ligature* lig)
{
    ASSERT(lig);

    return (ligSubst_sizeofLigatureSetList(lig));
}

LF_ERROR GSUB_getMaxComponentCount(gsub_ligature* lig, USHORT* max)
{
    LF_VECTOR* list = &lig->LigatureSetList;

    *max = 0;

    for (size_t i = 0; i < list->count; i++)
    {
        gsub_ligature_set_table* glst = (gsub_ligature_set_table*)vector_at(list, i);

        for (size_t j = 0; j < glst->LigatureList.count; j++)
        {
            gsub_ligature_table* ligatureSet = (gsub_ligature_table*)vector_at(&glst->LigatureList, j);

            if (ligatureSet->CompCount > *max)
                *max = ligatureSet->CompCount;
        }
    }

    return LF_ERROR_OK;
}


/* ============================================================================
    @summary
        free the ligature substitution rule from the resources.

    @param
        lig = pointer to the ligature substitution table.

============================================================================ */
void GSUB_freeLigatureSubst(gsub_ligature* lig)
{
    ULONG i = 0;
    LF_VECTOR* list;

    list = &lig->LigatureSetList;

    ASSERT(list);

    if (list)
    {
        Coverage_deleteTable(&lig->Coverage);

        // loop through the linked list and free up all of the tables
        while (i < list->count)
        {
            gsub_ligature_set_table* ls = (gsub_ligature_set_table*)vector_at(list, i++);
            ligSubst_freeLigatureSet(ls);
            free(ls);
        };
        vector_delete(list);
    }

    free(lig);
}

/* ============================================================================
    @desc
        remove the coverage id first, and if the function removes a
        coverage value, we can get rid of the entire ligature set
        associated with that coverage id.

    TODO:
        if the coverage doesn't get happen, we can go through each
        of the ligature sets associated with the rule and clean
        up the ligature tables.  if the ligature tables contain
        the glyph we can remove that table, and prune the sets
        accordingly if they become empty. 

        this can go up through the set as well and if there is
        only the coverage left, we can prune that one as well
        since the ligature doesn't exist anymore.

    @param
        lig = pointer to the ligature table
        glyph = what glyph to remove.

    @return
        OK = if a glyph got removed
        NOT_COVERAGED = if the glyph doesn't exist in the rule
        EMPTY = if the rule got removed.
============================================================================ */
LF_ERROR GSUB_removeLigatureGlyphIndex(gsub_ligature* lig, GlyphID glyph)
{
    LF_ERROR error;
    ULONG    index;

    ASSERT(lig);
    if (NULL == lig)
        return LF_BAD_FORMAT;

    error = Coverage_removeGlyphIndex(&lig->Coverage, glyph, &index);
    if (error == LF_EMPTY_TABLE)
        return error;

    if (error == LF_ERROR_OK)
    {
        error = ligSubst_removeLigatureSet(lig, index);
        if (error == LF_EMPTY_TABLE)
            return error;
    }

    error = ligSubst_removeLigatureTables(lig, glyph);
    if (error == LF_EMPTY_TABLE)
        return LF_EMPTY_TABLE;

    return LF_ERROR_OK;
}


/* ----------------------------------------------------------------------------
    @desc
        remove a ligature set from the rule.  this would occur if
        the coverage id associated with the set has been removed as
        this invalidates all of the table.

    @param
        lig = pointer to the ligature table containing the coverage
              and ligature sets.

        index = index value into the set array that is to be
                removed.

    @return
        OK = set was removed.

---------------------------------------------------------------------------- */
static LF_ERROR ligSubst_removeLigatureSet(gsub_ligature* lig, ULONG index)
{
    gsub_ligature_set_table* set;

    ASSERT(lig);

    if (lig)
    {
        set = (gsub_ligature_set_table*)vector_at(&lig->LigatureSetList, index);

        if (set)
        {
            ligSubst_freeLigatureSet(set);
            vector_erase(&lig->LigatureSetList, index);
            free(set);
        }

        if (lig->LigatureSetList.count == 0)
            return LF_EMPTY_TABLE;
    }
    return LF_ERROR_OK;
}


/* ----------------------------------------------------------------------------
    @summary
        filter out the id glyph from the ligature sets/tables and prune
        the vector collection.  if all of the sets and tables are
        removed, the return EMPTY to the caller.

    @param
        lig         :    pointer to the ligature structure containing the
                         ligature sets and their tables

        id          :    the glyph id we are removing.

    @output
        LF_EMPTY_TABLE     :    The ligature sets are empty.
        LF_ERROR_OK        :    removed the id from the ligature sets/tables.

---------------------------------------------------------------------------- */
static LF_ERROR ligSubst_removeLigatureTables(gsub_ligature* lig, GlyphID id)
{
    size_t n = 0, i;

    while( n < lig->LigatureSetList.count )
    {
        gsub_ligature_set_table* lset = (gsub_ligature_set_table*)vector_at(&lig->LigatureSetList, n);
        if (NULL == lset)
            return LF_BAD_FORMAT;

        i = 0;

        while(i < lset->LigatureList.count)
        {
            gsub_ligature_table* table = (gsub_ligature_table*)vector_at(&lset->LigatureList, i);
            ASSERT(table);
            if (NULL == table)
                continue;

            if (id == table->LigGlyph)
            {
                // substitute glyph has been removed, so we can remove this
                // ligature table from set.
                vector_erase(&lset->LigatureList, i);
                ligSubst_freeLigatureTable(table);
                FREE(table);
                continue;
            }
            else
            {
                if (id >= table->minComponent && id <= table->maxComponent)
                {
                    size_t j;

                    for (j = 0; j < table->Component.count; j++)
                    {
                        GlyphID comp = (GlyphID)(intptr_t)vector_at(&table->Component, j);
                        if (comp == id)
                        {
                            // Found match, so we can remove this table
                            vector_erase(&lset->LigatureList, i);
                            ligSubst_freeLigatureTable(table);
                            FREE(table);
                            break;
                        }
                    }
                    if(NULL == table)   // table was removed
                        continue;
                }
            }

            i++;
        }

        // check if there are any ligature tables left
        if (lset->LigatureList.count == 0)
        {
            vector_erase(&lig->LigatureSetList, n);
            ligSubst_freeLigatureSet(lset);
            FREE(lset);

            Coverage_eraseIndex(&lig->Coverage, (USHORT)n);
        }
        else
        {
            n++;
        }
    }

    // check if all of the ligature sets were cleared out
    // and return EMPTY if they are gone.
    if (lig->LigatureSetList.count == 0)
        return LF_EMPTY_TABLE;

    return LF_ERROR_OK;
}

/* ----------------------------------------------------------------------------
    @desc
    For each ligature in the set, a Ligature table specifies the GlyphID of the
    output ligature glyph (LigGlyph); a count of the total number of component
    glyphs in the ligature, including the first component (CompCount); and an
    array of GlyphIDs for the components (Component). The array starts with the
    second component glyph (array index = 1) in the ligature because the first
    component glyph is specified in the Coverage table.

    @notes
    The Component array lists GlyphIDs according to the writing direction of
    the text. For text written right to left, the right-most glyph will be
    first. Conversely, for text written left to right, the left-most glyph will
    be first.

    @structure
    Type       Name                        Description
    GlyphID    LigGlyph                    GlyphID of ligature to substitute
    USHORT     CompCount                   Number of components in the ligature
    GlyphID    Component[CompCount - 1]    Array of component GlyphIDs-start with 
                                           the second component-ordered in writing 
                                           direction.
    @param
        lig = pointer to the ligature table to be populated
        font = pointer to the font table.
        stream = pointer to the stream that we read from

    @return
        status from streaming in the ligature table.
---------------------------------------------------------------------------- */
static LF_ERROR ligSubst_readLigatureTable(gsub_ligature_table* lig, GlyphID coverageId, LF_STREAM* stream)
{
    USHORT n, count;
    LF_ERROR error;

    ASSERT(lig);
    UNUSED(coverageId);

    lig->LigGlyph = STREAM_readUShort(stream);
    lig->CompCount = STREAM_readUShort(stream);

    lig->maxComponent = 0;
    lig->minComponent = 0xFFFF;

    count = lig->CompCount - 1;                        // only component count - 1 elements ???

    error = vector_init(&lig->Component, lig->CompCount, sizeof(ULONG));
    if (error != LF_ERROR_OK)
    {
        DEBUG_LOG_ERROR("memory problem");
        return error;
    }

    // loop through the ligature, and populate the ligature array
    for ( n = 0; n < count; n++ )
    {
        GlyphID id = STREAM_readUShort(stream);

        if (id < lig->minComponent)
            lig->minComponent = id;

        if (id > lig->maxComponent)
            lig->maxComponent = id;

        vector_push_back(&lig->Component, (void*)(intptr_t)id);
    }

    return LF_ERROR_OK;
}


/* ----------------------------------------------------------------------------
    @summary
        A LigatureSet table, one for each covered glyph, specifies all the 
        ligature strings that begin with the covered glyph. For example, if the 
        Coverage table lists the glyph index for a lowercase "f," then a 
        LigatureSet table will define the "ffl," "fl," "ffi," "fi," and "ff" 
        ligatures. If the Coverage table also lists the glyph index for a 
        lowercase "e," then a different LigatureSet table will define the 
        "etc" ligature.

        A LigatureSet table consists of a count of the ligatures that begin 
        with the covered glyph (LigatureCount) and an array of offsets to 
        Ligature tables, which define the glyphs in each ligature (Ligature). 
        The order in the Ligature offset array defines the preference for 
        using the ligatures. For example, if the "ffl" ligature is preferable 
        to the "ff" ligature, then the Ligature array would list the offset to 
        the "ffl" Ligature table before the offset to the "ff" Ligature table.

    @param
        ligset = pointer to the Ligature set table to stream to.
        font = pointer to LF_FONT structure
        stream = pointer to stream at the start of the Ligature set table

    @returns
        status of streaming in the ligature set table.
---------------------------------------------------------------------------- */
static LF_ERROR ligSubst_readLigatureSet(gsub_ligature_set_table* ligSet, GlyphID coverageID, LF_STREAM* stream)
{
    gsub_ligature_table*    lig;
    LF_ERROR                error;
    USHORT                  n, count;
    size_t                  curOffset, newOffset, baseOffset;
    LONG                    streamStatus;

    ASSERT(ligSet);
    if (NULL == ligSet)
        return LF_BAD_FORMAT;

    baseOffset = STREAM_streamPos(stream);

    count = ligSet->LigatureCount = STREAM_readUShort(stream);

    error = vector_init(&ligSet->LigatureList, count, sizeof(ULONG));
    if (error != LF_ERROR_OK)
        return error;

    for (n = 0; n < count; n++)
    {
        // create a new ligature table element to read in...
        lig = (gsub_ligature_table*)malloc(sizeof(gsub_ligature_table));
        if (NULL == lig)
        {
            ligSubst_freeLigatureSet(ligSet);
            return LF_OUT_OF_MEMORY;
        }

        // clear the new resource, and setup stream
        memset(lig, 0, sizeof(gsub_ligature_table));
        newOffset = STREAM_readUShort(stream) + baseOffset;
        curOffset = STREAM_streamPos(stream);

        streamStatus = STREAM_streamSeek(stream, newOffset);
        if (streamStatus == -1)
        {
            free(lig);
            ligSubst_freeLigatureSet(ligSet);
            return  LF_BAD_FORMAT;
        }

        error = ligSubst_readLigatureTable(lig, coverageID, stream);
        if (error != LF_ERROR_OK)
        {
            free(lig);
            ligSubst_freeLigatureSet(ligSet);
            return error;
        }

        error = vector_push_back(&ligSet->LigatureList, lig);
        if (error != LF_ERROR_OK)
        {
            free(lig);
            ligSubst_freeLigatureSet(ligSet);
            return error;
        }

        STREAM_streamSeek(stream, curOffset);
    }

    return LF_ERROR_OK;
}


/* ----------------------------------------------------------------------------
    @summary
        free the ligature set table from system resources.  this structure
        contains a linked list of ligature table elements that must be
        removed.

    @param
        ligSet = pointer to the ligature set table.
---------------------------------------------------------------------------- */
static void ligSubst_freeLigatureSet(gsub_ligature_set_table* ligSet)
{
    ligSubst_freeLigatureSetList(&ligSet->LigatureList);
}


/* ----------------------------------------------------------------------------
    @summary
        free the ligature table.  the only resource that is allocated in
        this structure is the Component member.
    @param
        lig = pointer to the ligature table.
---------------------------------------------------------------------------- */
static void ligSubst_freeLigatureTable(gsub_ligature_table* lig)
{
    ASSERT(lig);
    vector_delete(&lig->Component);
//    FREE(lig->Component);
}


/* ----------------------------------------------------------------------------
    @summary
        free up the sequence list and remove all of the nodes in the
        SequenceList.

    @param
        list = pointer to the sequence linked list
---------------------------------------------------------------------------- */
static void ligSubst_freeLigatureSetList(LF_VECTOR* list)
{
    ULONG i = 0;
    ASSERT(list);

    if (list)
    {
        // loop through the vector and free the ligature tables
        while (i < list->count)
        {
            gsub_ligature_table* lig = (gsub_ligature_table*)list->vector_array[i++];
            ligSubst_freeLigatureTable(lig);
            free(lig);
        }
        vector_delete(list);
    }
}


/*
    USHORT                    SubstFormat;        // format identifier - format is always 1
    OFFSET                    Coverage;           // The Coverage Table
    USHORT                    LigSetCount;        // Number of Ligature Set tables

    OFFSET                    LigatureSet;        // Array of offsets to Ligature Set tables from
*/
static size_t ligSubst_sizeofLigatureSetList(gsub_ligature* lig)
{
    size_t size = 0;
    //LF_ERROR error;
    size_t count, n;

    //error = Coverage_getTableSize(&lig->Coverage, &size);    // Coverage size
    Coverage_getTableSize(&lig->Coverage, &size);    // Coverage size (always   returns OK)

    count = lig->LigatureSetList.count;

    size += sizeof(lig->SubstFormat);                        // SubstFormat
    size += sizeof(OFFSET);                                  // Coverage OFFSET
    size += sizeof(USHORT);                                  // LigSetCount
    size += count * sizeof(OFFSET);                          // OFFSET LigatureSet[LigSetCount]

    // loop through the LigatureSet[] array ...
    for ( n = 0; n < count; n++ )
    {
        gsub_ligature_set_table* set = (gsub_ligature_set_table*)vector_at(&lig->LigatureSetList, n);
        size += ligSubst_sizeofLigatureSet(set);
    }
    return size;
}


static size_t ligSubst_sizeofLigatureSet(gsub_ligature_set_table* set)
{
    size_t size = 0;
    size_t count, n;

    ASSERT(set);

    if (set)
    {
        count = set->LigatureList.count;

        size = sizeof(USHORT);                        // LigatureCount
        size += sizeof(OFFSET) * count;               // offset array Ligature[LigatureCount]

        // loop through Ligature[] array ...
        for ( n = 0; n < count; n++)
        {
            gsub_ligature_table* table = (gsub_ligature_table*)vector_at(&set->LigatureList, n);
            size += ligSubst_sizeofLigatureTable(table);
        }
    }

    return size;
}


/* ----------------------------------------------------------------------------
    @summary
        return the size of the ligature table structure

    @param
        table = pointer to the ligature table structure.

    @see also
---------------------------------------------------------------------------- */
static ULONG ligSubst_sizeofLigatureTable(gsub_ligature_table* table)
{
    ULONG size = 0;

    size  = sizeof(table->LigGlyph);
    size += sizeof(table->CompCount);
    size += sizeof(GlyphID) * (table->CompCount - 1);  // Doesn't include first glyph so -1

    return size;
}


static size_t ligSubst_buildLigatureSetList(gsub_ligature* lig, LF_STREAM* stream)
{
    size_t    baseOffset = STREAM_streamPos(stream);         // save the start of the lig table in stream.
    size_t    coverageOffset = 0;
    size_t    setOffset = 0;
    USHORT  n, setCount;

    STREAM_writeUShort(stream, lig->SubstFormat);            // write SubstFormat

    coverageOffset = STREAM_streamPos(stream);               // save the coverage position, so we get back to it.
    STREAM_writeOffset(stream, 0);                           // TEMP coverage Offset

    setCount = UTILS_getCount(&lig->LigatureSetList);        // save the number of ligature sets
    STREAM_writeUShort(stream, setCount);                    // write LigSetCount

    ASSERT(setCount == Coverage_getCoverageCount(&lig->Coverage));

    // create an empty array of OFFSETs.
    setOffset = Common_buildEmptyArray(stream, setCount);    // OFFSET array - LigatureSet[LigSetCount]


    for ( n = 0; n < setCount; n++ )
    {
        gsub_ligature_set_table* set = (gsub_ligature_set_table*)vector_at(&lig->LigatureSetList, n);

        // update the OFFSET array for the LigatureSet[LigSetCount]
        setOffset = Common_writeOffset(stream, (ULONG)setOffset, (ULONG)baseOffset);
        ligSubst_buildLigatureSet(set, stream);
    }

    Common_writeOffset(stream, (ULONG)coverageOffset, (ULONG)baseOffset);
    Coverage_buildTable(&lig->Coverage, stream);

    return STREAM_streamPos(stream);
}


static size_t    ligSubst_buildLigatureSet(gsub_ligature_set_table* set, LF_STREAM* stream)
{
    size_t baseOffset = STREAM_streamPos(stream);                // save the start of the lig set table in stream.
    size_t setOffset = 0;                                        // start of the offset array
    size_t curOffset = 0;
    size_t offset = 0;
    size_t n, ligCount;                                        // counters
    LF_VECTOR* list = &set->LigatureList;                      // get pointer to linked list

    ligCount = list->count;                                    // how many ligature sets are there
    STREAM_writeUShort(stream, (USHORT)ligCount);              // save ligature set count
    setOffset = STREAM_streamPos(stream);                      // save offset table array starting point

    // loop through stream and write out temporary offset array
    for ( n = 0; n < ligCount; n++ )
    {
        STREAM_writeUShort(stream, 0);                         // save off temporary values for offset array
    }

    // loop through the link list and write out the tables and update the offset array
    for ( n = 0; n < ligCount; n++ )
    {
        gsub_ligature_table* table;

        table = (gsub_ligature_table*)vector_at(list, n);
        ASSERT(table);

        curOffset = STREAM_streamPos(stream);                // get our current stream position
        offset = curOffset - baseOffset;                     // calculate the offset
        STREAM_streamSeek(stream, setOffset);                // seek out the set offset table

        STREAM_writeOffset(stream, (OFFSET)offset);          // write the offset into the set offset 
        setOffset += sizeof(OFFSET);                         // increment to the next offset in the array.
        STREAM_streamSeek(stream,curOffset);                 // Back to location to write the table
        ligSubst_buildLigatureTable(table, stream);          // write out the ligature table
    }
    return STREAM_streamPos(stream);
}


static size_t    ligSubst_buildLigatureTable(gsub_ligature_table* table, LF_STREAM* stream)
{
    USHORT n, count;

    count = UTILS_getCount(&table->Component);
    STREAM_writeUShort(stream, table->LigGlyph);
    STREAM_writeUShort(stream, count + 1);

    // loop through the component array which contains glyph IDs (aka USHORT)
    for ( n = 0; n < count; n++)
    {
        GlyphID glyph = (GlyphID)(intptr_t)vector_at(&table->Component, n);
        STREAM_writeUShort(stream, glyph);
    }
    return STREAM_streamPos(stream);
}


LF_ERROR GSUB_remapLigatureSubstGlyphs(gsub_ligature* lig, LF_MAP* remap)
{
    gsub_ligature_set_table*    ligatureSets;
    LF_ERROR                    error = LF_ERROR_OK;
    USHORT                        n, count;
    USHORT                        i, j;

    ASSERT(lig);

    count = UTILS_getCount(&lig->LigatureSetList);

    // go through all of the LigatureSets
    for ( n = 0; n < count; n++ )
    {
        ligatureSets = (gsub_ligature_set_table*)vector_at(&lig->LigatureSetList, n);

        for (i = 0; i < ligatureSets->LigatureList.count; i++)
        {
            gsub_ligature_table* ligatureSet = (gsub_ligature_table*)vector_at(&ligatureSets->LigatureList, i);
            GlyphID newid;

            error = Common_remapGlyph(remap, ligatureSet->LigGlyph, &newid);
            ligatureSet->LigGlyph = newid;

            for (j = 0; j < ligatureSet->CompCount - 1; j++)
            {
                GlyphID oldid = (GlyphID)(intptr_t)vector_at(&ligatureSet->Component, j);

                error = Common_remapGlyph(remap, oldid, &newid);

                vector_set_data(&ligatureSet->Component, j, (void*)(intptr_t)newid);

                if (error != LF_ERROR_OK)
                {
                    DEBUG_LOG_VALUE("unable to remap ligature", oldid);
                }
            }
        }
    }
    Coverage_remapAll(&lig->Coverage, remap);

    return error;
}


/* ----------------------------------------------------------------------------
    @summary
        parse the ligature list and add any glyphs required to the
        keep list to ensure they stay.

    @param
        lig             :    pointer to the ligature list
        keepList        :    pointer to the keep glyph list

    @return
        LF_ADDED_GLYPH    :    added a glyph to the keep table.
        NOT_COVERED       :    nothing added.

---------------------------------------------------------------------------- */
LF_ERROR GSUB_keepLigSubstGlyphs(gsub_ligature* lig, GlyphList* keepList)
{
    USHORT      i, j;
    LF_ERROR    status = LF_NOT_COVERED;
    USHORT      added = 0;
    size_t       coverageCount = Coverage_getCoverageCount(&lig->Coverage);


    if (coverageCount != lig->LigatureSetList.count)
        return LF_INVALID_SUBTABLE;

    ASSERT(lig->LigatureSetList.count == coverageCount );

    for (i = 0; i < lig->LigatureSetList.count; i++)
    {
        gsub_ligature_set_table*    ligSet;
        GlyphID                     coverageID;
        LF_ERROR                    error;

        error = Coverage_getCoverageAt(&lig->Coverage, i, &coverageID);


        if (error == LF_ERROR_OK)
        {
            // first, check the coverage exists?
            if (Keep_coverageExists(keepList, coverageID) == LF_ERROR_OK)
            {
                ligSet = (gsub_ligature_set_table*)vector_at(&lig->LigatureSetList, i);


                // these ligature lists exist based upon the above coverageID
                for (j = 0; j < ligSet->LigatureList.count; j++)
                {
                    gsub_ligature_table* ligTable;

                    ligTable = (gsub_ligature_table*)vector_at(&ligSet->LigatureList, j);

                    // second, check if the set exists?  The set is in combination with the coverageID
                    if (Keep_setExists(keepList, &ligTable->Component) == LF_ERROR_OK)
                    {
                        // yes, so we need to add the substitution glyph as well
                        Keep_addGlyph(keepList, ligTable->LigGlyph);
                        if (error == LF_ADDED_GLYPH)
                            added++;
                    }
                }
            }
        }
    }

    if (added)
    {
        status = LF_ADDED_GLYPH;
#if _DEBUG
        DEBUG_LOG_VALUE("Added keepGlyphs: ", added);
#endif
    }
    return status;
}

#ifdef LF_OT_DUMP
/* ==================================================================
    @desc
        dump the ligature substitution table to the XML data
        stream.

    @param
        lig         :       pointer to the ligature

================================================================== */
void GSUB_dumpLigatureSubst(gsub_ligature* lig)
{
    USHORT    n, i, j, count;
    gsub_ligature_set_table*    ligatureSets;

    XML_START("GSUBLigature");
    BaseTable_dump(lig);
    Coverage_dumpTable(&lig->Coverage);

    count = UTILS_getCount(&lig->LigatureSetList);

    XML_START("LigatureSets");
    // go through all of the LigatureSets
    for ( n = 0; n < count; n++ )
    {
        ligatureSets = (gsub_ligature_set_table*)vector_at(&lig->LigatureSetList, n);

        XML_COMMENT_INDEX("LigatureSets", n, (count - 1));

        XML_START("LigatureSet");
        for (i = 0; i < ligatureSets->LigatureList.count; i++)
        {
            gsub_ligature_table* ligatureSet = (gsub_ligature_table*)vector_at(&ligatureSets->LigatureList, i);
            XML_DATA_NODE("LigGlyph", ligatureSet->LigGlyph);
            XML_START("Ligature");
            for (j = 0; j < ligatureSets->LigatureList.count; j++)
            {
                GlyphID glyphid = (GlyphID)(long)vector_at(&ligatureSet->Component, j);
                XML_DATA_NODE("gid", glyphid);
            }
            XML_END("Ligature");
        }
        XML_END("LigatureSet");
    }
    XML_END("LigatureSets");

    XML_END("GSUBLigature");
}
#endif
