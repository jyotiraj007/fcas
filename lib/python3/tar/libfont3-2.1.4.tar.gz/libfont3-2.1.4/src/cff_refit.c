// Copyright (C) 2015 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// cff_refit.c

#include "cff_refit.h"
#include "cff_table.h"
#include "cff_core.h"
#include "cff_conversion.h"
#include "table_tags.h"
#include "Conversion.h"
#include "head_table.h"
#include "utils.h"

extern CFF_ERROR cff_loadCharStringIntoGlyph(const cff_table* cffTable, USHORT index, Glyph* cubicGlyph);
extern CFF_ERROR cff_loadSEACIntoGlyph(const cff_table* cffTable, USHORT index, Glyph* cubicGlyph);

// The Cff spec allows a stack depth of 48. If we allow 4 curvetos in one go,
// that is 6*4 + 1 = 25 items, which is well below the limit.
// combining mutiple cubics with one opcode saves some space
#define MAX_SEQUENTIAL_CURVETOS 4

static CFF_ERROR updateAnalyzedCharstring(cffAnalyzedCharstring*acs, BYTE* scratch, ULONG sz, Simple_Outline* so, boolean purgeSubroutines)
{
    if (so->types[0] != MOVE_TO)
        return CFF_ERR_INTERNAL;  // first point must be a moveto

    // allocate a temp buffer into which the new charstring will be written
    ULONG scratchSize;
    BYTE* scratchBuf;

    if (scratch == NULL)
    {
        scratchSize = acs->rawLen * 2;
        scratchBuf = (BYTE*)malloc(scratchSize * sizeof(BYTE));
        if (scratchBuf == NULL)
            return CFF_ERR_MEMORY;
    }
    else
    {
        scratchSize = sz;
        scratchBuf = scratch;
    }

    LF_STREAM csStream;
    STREAM_initMemStream(&csStream, scratchBuf, scratchSize);

    // insert advance offset
    if (acs->hasAdwAdj == TRUE)
        STREAM_writeCffIntegerOperand(&csStream, (acs->advanceWidthAdj >> 16)); //lint !e702

    if (acs->hstems != NULL)
    {
        size_t numPairs = acs->hstems->count;
        for (size_t j = 0; j < numPairs; j++)
        {
            cffHint* hint = (cffHint*)vector_at(acs->hstems, j);
            STREAM_writeCffIntegerOperand(&csStream, hint->first);
            STREAM_writeCffIntegerOperand(&csStream, hint->second);
        }
        STREAM_writeByte(&csStream, 1);     // hstem
    }

    if (acs->vstems != NULL)
    {
        size_t numPairs = acs->vstems->count;
        for (size_t j = 0; j < numPairs; j++)
        {
            cffHint* hint = (cffHint*)vector_at(acs->vstems, j);
            STREAM_writeCffIntegerOperand(&csStream, hint->first);
            STREAM_writeCffIntegerOperand(&csStream, hint->second);
        }
        STREAM_writeByte(&csStream, 3);     // vstem
    }

    SHORT loopstartx = 0, loopstarty = 0;
    int i = 0;

    int numSequentialCurveTos = 0;

    BYTE* tempCurveToBuf = (BYTE*)malloc(256);
    if (tempCurveToBuf == NULL)
    {
        if (scratch == NULL)
            free(scratchBuf);
        return CFF_ERR_MEMORY;
    }

    LF_STREAM curvetoStream;
    STREAM_initMemStream(&curvetoStream, tempCurveToBuf, 256);

    while (i < so->np)
    {
        SHORT curx, cury, prevx, prevy;

        if (so->types[i] == MOVE_TO)    // first point of a contour
        {
            if (numSequentialCurveTos)
            {
                STREAM_writeChunk(&csStream, curvetoStream.Base, STREAM_streamPos(&curvetoStream));
                STREAM_writeByte(&csStream, 8);     // rrcurveto
                numSequentialCurveTos = 0;
                STREAM_streamSeek(&curvetoStream, 0);
            }

            curx = (i == 0) ? (SHORT)so->x[i] : (SHORT)so->x[i] - (SHORT)so->x[i - 1];
            cury = (i == 0) ? (SHORT)so->y[i] : (SHORT)so->y[i] - (SHORT)so->y[i - 1];

            STREAM_writeCffIntegerOperand(&csStream, curx); // dx for rmoveto
            STREAM_writeCffIntegerOperand(&csStream, cury); // dy for rmoveto
            STREAM_writeByte(&csStream, 21);                // rmoveto

            loopstartx = (SHORT)so->x[i];
            loopstarty = (SHORT)so->y[i];

            i++;
        }
        else if ((so->types[i] == LINE_TO) || (so->types[i] == ON_CURVE))   // on curve
        {
            if (numSequentialCurveTos)
            {
                STREAM_writeChunk(&csStream, curvetoStream.Base, STREAM_streamPos(&curvetoStream));
                STREAM_writeByte(&csStream, 8);     // rrcurveto
                numSequentialCurveTos = 0;
                STREAM_streamSeek(&curvetoStream, 0);
            }

            ASSERT(so->types[i - 1] != OFF_CURVE);

            prevx = (SHORT)so->x[i - 1];
            prevy = (SHORT)so->y[i - 1];
            curx = (SHORT)so->x[i];
            cury = (SHORT)so->y[i];

            if (curx == prevx)
            {
                STREAM_writeCffIntegerOperand(&csStream, cury - prevy);
                STREAM_writeByte(&csStream, 7);  // vlineto
            }
            else if (cury == prevy)
            {
                STREAM_writeCffIntegerOperand(&csStream, curx - prevx);
                STREAM_writeByte(&csStream, 6);  // hlineto
            }
            else
            {
                STREAM_writeCffIntegerOperand(&csStream, curx - prevx);
                STREAM_writeCffIntegerOperand(&csStream, cury - prevy);
                STREAM_writeByte(&csStream, 5);  // rlineto
            }

            i++;
        }
        else // off curve
        {
            ASSERT(i < so->np - 1);
            ASSERT((so->types[i - 1] != OFF_CURVE) && (so->types[i + 1] == OFF_CURVE));

            if (numSequentialCurveTos == MAX_SEQUENTIAL_CURVETOS)
            {
                STREAM_writeChunk(&csStream, curvetoStream.Base, STREAM_streamPos(&curvetoStream));
                STREAM_writeByte(&csStream, 8);     // rrcurveto
                numSequentialCurveTos = 0;
                STREAM_streamSeek(&curvetoStream, 0);
            }

            prevx = (SHORT)so->x[i - 1];
            prevy = (SHORT)so->y[i - 1];
            curx = (SHORT)so->x[i];
            cury = (SHORT)so->y[i];

            SHORT nextx = (SHORT)so->x[i + 1];
            SHORT nexty = (SHORT)so->y[i + 1];
            SHORT nextnextx = (so->types[i + 2] == MOVE_TO) ? loopstartx : (SHORT)so->x[i + 2];
            SHORT nextnexty = (so->types[i + 2] == MOVE_TO) ? loopstarty : (SHORT)so->y[i + 2];

            STREAM_writeCffIntegerOperand(&curvetoStream, curx - prevx);
            STREAM_writeCffIntegerOperand(&curvetoStream, cury - prevy);
            STREAM_writeCffIntegerOperand(&curvetoStream, nextx - curx);
            STREAM_writeCffIntegerOperand(&curvetoStream, nexty - cury);
            STREAM_writeCffIntegerOperand(&curvetoStream, nextnextx - nextx);
            STREAM_writeCffIntegerOperand(&curvetoStream, nextnexty - nexty);

            numSequentialCurveTos++;

            i += 3;
        }
    }

    if (numSequentialCurveTos)
    {
        STREAM_writeChunk(&csStream, curvetoStream.Base, STREAM_streamPos(&curvetoStream));
        STREAM_writeByte(&csStream, 8);     // rrcurveto
    }

    STREAM_writeByte(&csStream, 14); // endchar

    free(tempCurveToBuf);

    if (!STREAM_isValid(csStream))
    {
        if (scratch == NULL)
            free(scratchBuf);
        return CFF_ERR_CS_BUF_EXCEEDED; // an indication that the available space was not enough
    }

    free(acs->rawData);

    acs->rawLen = (LONG)STREAM_streamPos(&csStream);
    acs->rawData = (BYTE*)malloc(acs->rawLen * sizeof(BYTE));
    if (acs->rawData == NULL)
    {
        if (scratch == NULL)
            free(scratchBuf);
        return CFF_ERR_MEMORY;
    }

    memcpy(acs->rawData, scratchBuf, acs->rawLen);

    if (scratch == NULL)
        free(scratchBuf);

    if (purgeSubroutines == TRUE)
    {
        if (acs->gsubrArray != NULL)
        {
            vector_delete(acs->gsubrArray);
            free(acs->gsubrArray);
            acs->gsubrArray = NULL;
        }
        if (acs->subrArray != NULL)
        {
            vector_delete(acs->subrArray);
            free(acs->subrArray);
            acs->subrArray = NULL;
        }
    }

    return CFF_ERR_OK;
}

static CFF_ERROR updateEmptyAnalyzedCharstring(cffAnalyzedCharstring*acs, BYTE* scratch, ULONG sz)
{
    LF_STREAM csStream;
    STREAM_initMemStream(&csStream, scratch, sz);

    // insert advance offset
    if (acs->hasAdwAdj == TRUE)
        STREAM_writeCffIntegerOperand(&csStream, (acs->advanceWidthAdj >> 16)); //lint !e702

    STREAM_writeByte(&csStream, 14); // endchar

    free(acs->rawData);

    acs->rawLen = (LONG)STREAM_streamPos(&csStream);
    acs->rawData = (BYTE*)malloc(acs->rawLen * sizeof(BYTE));
    if (acs->rawData == NULL)
    {
        return CFF_ERR_MEMORY;
    }

    memcpy(acs->rawData, scratch, acs->rawLen);

    return CFF_ERR_OK;
}

static LF_ERROR refit_cff_default(cff_table* cffTable, USHORT upm, float fitTolerance, refitCBInfo* progCBInfo)
{
    //
    // Currently only refits charstrings which do not call any subroutines at all
    //

    // Remove existing charstring map
    cleanupCharStringMap(cffTable);

    // Regenerate charstring map
    cffTable->charStringMap = map_create(integer_compare);
    if (cffTable->charStringMap == NULL)
    {
        cff_unload(cffTable->cffTable);
        free(cffTable->rawTableBlock);
        free(cffTable);
        return LF_OUT_OF_MEMORY;
    }

    if (progCBInfo != NULL)
        progCBInfo->progressCB(progCBInfo->userState, 6);

    CFF_ERROR cffErr = cff_analyzeCharstringsFully(cffTable->cffTable, cffTable->charStringMap);
    if (cffErr != CFF_ERR_OK)
    {
        cleanupCharStringMap(cffTable);
        cff_unload(cffTable->cffTable);
        free(cffTable->rawTableBlock);
        free(cffTable);
        return cff_mapCffErrorToLfError(cffErr);
    }

    USHORT i;

    if (progCBInfo != NULL)
        progCBInfo->progressCB(progCBInfo->userState, 7);

    // number of glyphs
    USHORT numGlyphs = (USHORT)map_size(cffTable->charStringMap);

    // Now determine if we can refit each of the charstrings.
    // The criteria are that 1) the charstring must not contain subroutines which contain
    // anything other than stems, or are empty. 2) the charstring does not have any hints other than
    // at the beginning of the charstring

    for (i = 0; i < numGlyphs; i++)
    {
        cffAnalyzedCharstring* acs = (cffAnalyzedCharstring*)map_at(cffTable->charStringMap, (void*)(intptr_t)i);

        acs->canRefit = TRUE;

        if (acs->hasNonInitialHints == TRUE)
        {
            acs->canRefit = FALSE;
        }
        if (acs->numHintmasks > 1)
        {
            acs->canRefit = FALSE;
        }
        if ((acs->gsubrArray != NULL) || (acs->subrArray != NULL))
        {
            acs->canRefit = FALSE;
        }
    }

    if (progCBInfo != NULL)
        progCBInfo->progressCB(progCBInfo->userState, 8);

    float minX, maxX, minY, maxY;

    // Start with existing bounding box
    minX = (float)cffTable->cffTable->mainTopDict->fontbbox[0];
    minY = (float)cffTable->cffTable->mainTopDict->fontbbox[1];
    maxX = (float)cffTable->cffTable->mainTopDict->fontbbox[2];
    maxY = (float)cffTable->cffTable->mainTopDict->fontbbox[3];

    float scaledTolerance = fitTolerance * (upm / 1000.0f);

    // progress in this functions starts at 5% and ends at 85%
    USHORT curProg = 10;
    USHORT progMod = numGlyphs / 14;    // report at approx. 5% intervals

    //int numGlyphsReplaced = 0;

    // Loop over charstrings
    for (i = 0; i < numGlyphs; i++)
    {
        if ((progCBInfo != NULL) && (progMod != 0) && (i % progMod == 0))
        {
            progCBInfo->progressCB(progCBInfo->userState, curProg);
            curProg += 5;
        }

        cffAnalyzedCharstring* acs = (cffAnalyzedCharstring*)map_at(cffTable->charStringMap, (void*)(intptr_t)i);

        if ((acs->isEmpty == FALSE) && (acs->seacInfo == NULL) && (acs->canRefit == TRUE))
        {
            Glyph cubicGlyph;

            memset(&cubicGlyph, 0, sizeof(Glyph));

            // convert charstring to SimpleOutline
            cffErr = cff_loadCharStringIntoGlyph(cffTable, i, &cubicGlyph);

            if (cffErr != CFF_ERR_OK)
            {
                //todo
                return cff_mapCffErrorToLfError(cffErr);
            }

            // match it
            Glyph refittedGlyph;

            Simple_Outline* origCubicOutline = &cubicGlyph.glyphOutline.component.outline;
            Simple_Outline* refitCubicOutline = &refittedGlyph.glyphOutline.component.outline;

            refittedGlyph.glyphOutline.numberOfComponents = 1;
            refitCubicOutline->designUnits = upm;
            origCubicOutline->designUnits = upm;

            //printf("refitting glyph %d\n", i);

            Conversion_Error err = refitCubic(origCubicOutline, scaledTolerance, refitCubicOutline);

            if (CONVERSION_SUCCESS != err)
            {
                conversion_freeGlyphOutline(&cubicGlyph);

                //todo
                return (err == CONVERSION_MEMORY) ? LF_OUT_OF_MEMORY : LF_CONVERSION;
            }

            // NOTE the -2 is to account for the two side bearing points that are added.
            if (refitCubicOutline->np < origCubicOutline->np - 2)
            {
                //printf("replacing glyph %d    orig = %d   new = %d\n", i, origCubicOutline->np, refitCubicOutline->np);

                // compute outline bounding box
                conversion_computeCubicBoundingBox(&refittedGlyph);

                // update font bb
                if (refittedGlyph.glyphOutline.xMin < minX)
                    minX = refittedGlyph.glyphOutline.xMin;
                if (refittedGlyph.glyphOutline.xMax > maxX)
                    maxX = refittedGlyph.glyphOutline.xMax;
                if (refittedGlyph.glyphOutline.yMin < minY)
                    minY = refittedGlyph.glyphOutline.yMin;
                if (refittedGlyph.glyphOutline.yMax > maxY)
                    maxY = refittedGlyph.glyphOutline.yMax;

                acs->bb.xMax = (FIXED)(refittedGlyph.glyphOutline.xMax * 65536.0f);
                acs->bb.xMin = (FIXED)(refittedGlyph.glyphOutline.xMin * 65536.0f);
                acs->bb.yMax = (FIXED)(refittedGlyph.glyphOutline.yMax * 65536.0f);
                acs->bb.yMin = (FIXED)(refittedGlyph.glyphOutline.yMin * 65536.0f);

                //DumpCubic(&cubicGlyph.glyphOutline);

                //numGlyphsReplaced++;

                // Replace the raw data in the acs
                cffErr = updateAnalyzedCharstring(acs, NULL, 0, refitCubicOutline, FALSE);
                if (cffErr != CFF_ERR_OK)
                {
                    conversion_freeGlyphOutline(&refittedGlyph);
                    conversion_freeGlyphOutline(&cubicGlyph);

                    //todo
                    return cff_mapCffErrorToLfError(cffErr);
                }
            }

            conversion_freeGlyphOutline(&refittedGlyph);
            conversion_freeGlyphOutline(&cubicGlyph);
        }
    }

    //printf("\nreplaced %d glyphs\n", numGlyphsReplaced);

    // See if the subroutines can be refitted
    //cffErr = refitSubroutines(cffTable );

    return cff_mapCffErrorToLfError(cffErr);
}

static LF_ERROR refit_cff_force(cff_table* cffTable, USHORT upm, float fitTolerance, refitCBInfo* progCBInfo)
{
    CFF_ERROR cffErr = CFF_ERR_OK;

    if (progCBInfo != NULL)
        progCBInfo->progressCB(progCBInfo->userState, 8);

    float minX, maxX, minY, maxY;

    // Start with existing bounding box
    minX = (float)cffTable->cffTable->mainTopDict->fontbbox[0];
    minY = (float)cffTable->cffTable->mainTopDict->fontbbox[1];
    maxX = (float)cffTable->cffTable->mainTopDict->fontbbox[2];
    maxY = (float)cffTable->cffTable->mainTopDict->fontbbox[3];

    // number of glyphs
    USHORT i, numGlyphs = (USHORT)map_size(cffTable->charStringMap);

    float scaledTolerance = fitTolerance * (upm / 1000.0f);

    // progress in this functions starts at 5% and ends at 85%
    USHORT curProg = 10;
    USHORT progMod = numGlyphs / 14;    // report at approx. 5% intervals


    BYTE* newCharstringsBuf = (BYTE*)malloc(4096 * sizeof(BYTE));
    if (newCharstringsBuf == NULL)
    {
        return LF_OUT_OF_MEMORY;
    }

    // Loop over charstrings
    for (i = 0; i < numGlyphs; i++)
    {
        if ((progCBInfo != NULL) && (progMod != 0) && (i % progMod == 0))
        {
            progCBInfo->progressCB(progCBInfo->userState, curProg);
            curProg += 5;
        }

        cffAnalyzedCharstring* acs = (cffAnalyzedCharstring*)map_at(cffTable->charStringMap, (void*)(intptr_t)i);

        if (acs->isEmpty == TRUE)
        {
            if ((acs->subrArray != NULL) || (acs->gsubrArray != NULL))
            {
                // Assumption is that the subr has only the advance width and stems (we lose the stems in this path anyway)
                cffErr = updateEmptyAnalyzedCharstring(acs, newCharstringsBuf, 4096);
                if (cffErr != CFF_ERR_OK)
                {
                    free(newCharstringsBuf);
                    return cff_mapCffErrorToLfError(cffErr);
                }
            }
            continue;
        }


        Glyph cubicGlyph;

        memset(&cubicGlyph, 0, sizeof(Glyph));

        // convert charstring to SimpleOutline
        if (acs->seacInfo != NULL)
            cffErr = cff_loadSEACIntoGlyph(cffTable, i, &cubicGlyph);
        else
            cffErr = cff_loadCharStringIntoGlyph(cffTable, i, &cubicGlyph);

        if (cffErr != CFF_ERR_OK)
        {
            free(newCharstringsBuf);
            return cff_mapCffErrorToLfError(cffErr);
        }

        // match it
        Glyph refittedGlyph;

        Simple_Outline* origCubicOutline = &cubicGlyph.glyphOutline.component.outline;
        Simple_Outline* refitCubicOutline = &refittedGlyph.glyphOutline.component.outline;

        refittedGlyph.glyphOutline.numberOfComponents = 1;
        refitCubicOutline->designUnits = upm;
        origCubicOutline->designUnits = upm;

        //printf("refitting glyph %d\n", i);

        Conversion_Error err = refitCubic(origCubicOutline, scaledTolerance, refitCubicOutline);

        if (CONVERSION_SUCCESS != err)
        {
            conversion_freeGlyphOutline(&cubicGlyph);
            free(newCharstringsBuf);
            return (err == CONVERSION_MEMORY) ? LF_OUT_OF_MEMORY : LF_CONVERSION;
        }

        // compute outline bounding box
        conversion_computeCubicBoundingBox(&refittedGlyph);

        // update font bb
        if (refittedGlyph.glyphOutline.xMin < minX)
            minX = refittedGlyph.glyphOutline.xMin;
        if (refittedGlyph.glyphOutline.xMax > maxX)
            maxX = refittedGlyph.glyphOutline.xMax;
        if (refittedGlyph.glyphOutline.yMin < minY)
            minY = refittedGlyph.glyphOutline.yMin;
        if (refittedGlyph.glyphOutline.yMax > maxY)
            maxY = refittedGlyph.glyphOutline.yMax;

        acs->bb.xMax = (FIXED)(refittedGlyph.glyphOutline.xMax * 65536.0f);
        acs->bb.xMin = (FIXED)(refittedGlyph.glyphOutline.xMin * 65536.0f);
        acs->bb.yMax = (FIXED)(refittedGlyph.glyphOutline.yMax * 65536.0f);
        acs->bb.yMin = (FIXED)(refittedGlyph.glyphOutline.yMin * 65536.0f);

        //DumpCubic(&cubicGlyph.glyphOutline);

        // Replace the raw data in the acs
        cffErr = updateAnalyzedCharstring(acs, newCharstringsBuf, 4096, refitCubicOutline, TRUE);
        if (cffErr != CFF_ERR_OK)
        {
            conversion_freeGlyphOutline(&refittedGlyph);
            conversion_freeGlyphOutline(&cubicGlyph);
            free(newCharstringsBuf);
            return cff_mapCffErrorToLfError(cffErr);
        }

        conversion_freeGlyphOutline(&refittedGlyph);
        conversion_freeGlyphOutline(&cubicGlyph);
    }

    free(newCharstringsBuf);

    // Get rid of the subroutines

    if (cffTable->cffTable->globalSubrIndex)
    {
        cff_indexDestroy(cffTable->cffTable->globalSubrIndex);
        cffTable->cffTable->globalSubrIndex = NULL;
        cffErr = cff_indexInitializeWithSize(0, &cffTable->cffTable->globalSubrIndex);
        if (cffErr != CFF_ERR_OK)
        {
            //todo
            return cff_mapCffErrorToLfError(cffErr);
        }
    }

    if (cffTable->cffTable->isCID == FALSE)
    {
        if (cffTable->cffTable->localSubrIndex != NULL)
        {
            cff_indexDestroy(cffTable->cffTable->localSubrIndex);
            cffTable->cffTable->localSubrIndex = NULL;
        }
    }
    else
    {
        ULONG numFontDicts = cff_indexGetCount(cffTable->cffTable->FDIndex);

        for (i = 0; i < numFontDicts; i++)
        {
            if (cffTable->cffTable->fdInfo[i].localSubr != NULL)
            {
                cff_indexDestroy(cffTable->cffTable->fdInfo[i].localSubr);
                cffTable->cffTable->fdInfo[i].localSubr = NULL;
            }
        }
    }

    return cff_mapCffErrorToLfError(cffErr);
}

LF_ERROR cff_refit(LF_FONT* lfFont, float fitTolerance, boolean replaceAll, refitCBInfo* progCBInfo)
{
    if (progCBInfo != NULL)
        progCBInfo->progressCB(progCBInfo->userState, 5);

    // Get the design units from the head table.
    USHORT origUPM = HEAD_getUnitsPerEM(lfFont);
    if (origUPM == 0)
    {
        //todo
        return LF_TABLE_MISSING;
    }

    // Get the CFF table.
    cff_table* cffTable = (cff_table*)map_at(&lfFont->table_map, (void*)TAG_CFF);
    if (cffTable == NULL)
        return LF_TABLE_MISSING;

    if (replaceAll == TRUE)
        return refit_cff_force(cffTable, origUPM, fitTolerance, progCBInfo);
    else
        return refit_cff_default(cffTable, origUPM, fitTolerance, progCBInfo);
}
