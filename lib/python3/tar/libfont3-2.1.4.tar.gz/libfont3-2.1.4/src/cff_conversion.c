// Copyright (C) 2014, 2015 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// cff_conversion.c

#include <stdlib.h> // for NULL
#include "cff_conversion.h"
#include "cff_core_prv.h"
//lint -esym(528,ExpertSID, ExpertSubsetSID,adobestdvector,ISOAdobeSID) don't complain if not referenced
#include "cff_data.h"
#include "name_table.h"
#include "hmtx_table.h"
#include "utils.h"
#include "head_table.h"
#include "os2_table.h"
#include "post_table.h"
#include "cmap_table.h"

// func is in cff_core.c
extern CFF_ERROR cff_loadCharStringIntoGlyph(const cff_table* cffTable, USHORT index, Glyph* cubicGlyph);

typedef struct
{
    LONG delta;
    boolean equalsDefaultWidth;
} ADVANCEDELTA;

void conversion_freeScratchSpace(const glyfBuildScratchSpace* ss)
{
    free(ss->flags);
    free(ss->xCoords);
    free(ss->yCoords);
}

// 0 = ok; 1 = malloc fail
int conversion_allocateScratchSpace(glyfBuildScratchSpace* ss, size_t size)
{
    memset(ss, 0, sizeof(glyfBuildScratchSpace));

    ss->flags = (BYTE*)malloc(size*sizeof(BYTE));
    if (ss->flags == NULL)
    {
        conversion_freeScratchSpace(ss);
        return 1;
    }

    ss->xCoords = (BYTE*)malloc(size*sizeof(SHORT));
    if (ss->xCoords == NULL)
    {
        conversion_freeScratchSpace(ss);
        return 1;
    }

    ss->yCoords = (BYTE*)malloc(size*sizeof(SHORT));
    if (ss->yCoords == NULL)
    {
        conversion_freeScratchSpace(ss);
        return 1;
    }

    ss->allocated = size;

    return 0;
}

// 0 = ok; 1 = malloc fail; 2 = bad size
int conversion_reallocateScratchSpace(glyfBuildScratchSpace* ss, size_t size)
{
    if (size <= ss->allocated)
        return 2;

    BYTE*tmp = (BYTE*)realloc(ss->flags, size*sizeof(BYTE));
    if (tmp == NULL)
    {
        conversion_freeScratchSpace(ss);
        return 1;
    }
    ss->flags = tmp;

    tmp = (BYTE*)realloc(ss->xCoords, size*sizeof(SHORT));
    if (tmp == NULL)
    {
        conversion_freeScratchSpace(ss);
        return 1;
    }
    ss->xCoords = tmp;

    tmp = (BYTE*)realloc(ss->yCoords, size*sizeof(SHORT));
    if (tmp == NULL)
    {
        conversion_freeScratchSpace(ss);
        return 1;
    }
    ss->yCoords = tmp;

    ss->allocated = size;

    return 0;
}

static LF_ERROR convertCompositeGlyphToCompressedGlyf(const Glyph *glyph, glyf *glyf_object)
{
    glyf_object->numberOfContours = -1;
    glyf_object->xMin = (SHORT)glyph->glyphOutline.xMin;
    glyf_object->yMin = (SHORT)glyph->glyphOutline.yMin;
    glyf_object->xMax = (SHORT)glyph->glyphOutline.xMax;
    glyf_object->yMax = (SHORT)glyph->glyphOutline.yMax;

    // there will only ever be two components (the base and the accent)
    USHORT firstGlyfFlags = (MORE_COMPONENTS | ARG_1_AND_2_ARE_WORDS | ARGS_ARE_XY_VALUES);
    USHORT firstGlyfIndex = glyph->glyphOutline.component.glyphIndex;
    SHORT firstGlyfArg1 = (SHORT)glyph->glyphOutline.component.xoffset;
    SHORT firstGlyfArg2 = (SHORT)glyph->glyphOutline.component.yoffset;
    //USHORT firstGlyfscale = (USHORT)glyph->glyphOutline.component.xscale * 0x4000; // = yscale = 1.0
    USHORT secondGlyfFlags = (ARG_1_AND_2_ARE_WORDS | ARGS_ARE_XY_VALUES);
    USHORT secondGlyfIndex = glyph->glyphOutline.component.next->glyphIndex;
    USHORT secondGlyfArg1 = (USHORT)(glyph->glyphOutline.component.next->xoffset);
    USHORT secondGlyfArg2 = (USHORT)(glyph->glyphOutline.component.next->yoffset);
    //USHORT secondGlyfscale = (USHORT)(glyph->glyphOutline.component.next->xscale * 0x4000); // = yscale = 1.0

    // calculate the size of the glyf data
    glyf_object->glyfSize = sizeof(USHORT) * 8;                     // size of above variables

    //glyf_object->glyfSize = (glyf_object->glyfSize + 1) & ~1;     // Make sure the size is even

    // create the glyfBlock
    glyf_object->glyfBlock = (BYTE*)calloc(glyf_object->glyfSize, 1);
    if (glyf_object->glyfBlock == NULL)
        return LF_OUT_OF_MEMORY;

    LF_STREAM glyfStream;

    STREAM_initMemStream(&glyfStream, glyf_object->glyfBlock, glyf_object->glyfSize);

    STREAM_writeUShort(&glyfStream, firstGlyfFlags);
    STREAM_writeUShort(&glyfStream, firstGlyfIndex);
    STREAM_writeShort(&glyfStream, firstGlyfArg1);
    STREAM_writeShort(&glyfStream, firstGlyfArg2);
    //STREAM_writeUShort(&glyfStream, firstGlyfscale);
    STREAM_writeUShort(&glyfStream, secondGlyfFlags);
    STREAM_writeUShort(&glyfStream, secondGlyfIndex);
    STREAM_writeUShort(&glyfStream, secondGlyfArg1);
    STREAM_writeUShort(&glyfStream, secondGlyfArg2);
    //STREAM_writeUShort(&glyfStream, secondGlyfscale);

    return LF_ERROR_OK;
}

LF_ERROR conversion_convertGlyphToCompressedGlyf(Glyph *glyph, const glyfBuildScratchSpace* ss, glyf *glyf_object)
{
    glyf_object->numberOfContours = glyph->glyphOutline.component.outline.nc;
    glyf_object->xMin = (SHORT)glyph->glyphOutline.xMin;
    glyf_object->yMin = (SHORT)glyph->glyphOutline.yMin;
    glyf_object->xMax = (SHORT)glyph->glyphOutline.xMax;
    glyf_object->yMax = (SHORT)glyph->glyphOutline.yMax;

    if (glyf_object->numberOfContours == 0)
        return LF_ERROR_OK;

    Simple_Outline *outl = &glyph->glyphOutline.component.outline;

    glyf_object->parsed = FALSE;

    size_t i, flagsBytesNeeded = 0, instructionBytesNeeded = 0, xBytesNeeded = 0, yBytesNeeded = 0;
    size_t repeatCount = 0;
    size_t nPoints = glyph->glyphOutline.component.outline.np;

    // index 0
    {
    // x
    SHORT firstpt = (SHORT)outl->x[0];

    ss->flags[0] = (outl->types[0] == OFF_CURVE) ? 0 : FLAG_ON_CURVE;

    if ((firstpt <= 255) && (firstpt >= -255))
    {
        ss->flags[0] |= FLAG_X_SHORT_VECTOR;

        if (firstpt >= 0)
            ss->flags[0] |= FLAG_X_SAME;
        else
            firstpt = -firstpt;
        ss->xCoords[xBytesNeeded++] = (BYTE)(firstpt);
    }
    else
    {
        ss->xCoords[xBytesNeeded++] = (BYTE)((firstpt & 0xFF00) >> 8);
        ss->xCoords[xBytesNeeded++] = (firstpt & 0x00FF);
    }

    // y
    firstpt = (SHORT)outl->y[0];

    if ((firstpt <= 255) && (firstpt >= -255))
    {
        ss->flags[0] |= FLAG_Y_SHORT_VECTOR;

        if (firstpt >= 0)
            ss->flags[0] |= FLAG_Y_SAME;
        else
            firstpt = -firstpt;

        ss->yCoords[yBytesNeeded++] = (BYTE)(firstpt);
    }
    else
    {
        ss->yCoords[yBytesNeeded++] = (BYTE)((firstpt & 0xFF00) >> 8);
        ss->yCoords[yBytesNeeded++] = (firstpt & 0x00FF);
    }
    }

    BYTE lastFlag = ss->flags[0];

    for (i = 1; i < nPoints; i++)
    {
        SHORT x2 = (SHORT)(outl->x[i]);
        SHORT x1 = (SHORT)(outl->x[i - 1]);
        SHORT y2 = (SHORT)(outl->y[i]);
        SHORT y1 = (SHORT)(outl->y[i - 1]);

        SHORT deltax = x2 - x1;
        SHORT deltay = y2 - y1;

        BYTE curFlag = (outl->types[i] == OFF_CURVE) ? 0 : FLAG_ON_CURVE;

        if (deltax == 0)
            curFlag |= FLAG_X_SAME;
        else if ((deltax <= 255) && (deltax >= -255))
        {
            curFlag |= FLAG_X_SHORT_VECTOR;

            if (deltax > 0)
                curFlag |= FLAG_X_SAME;
            else
                deltax = -deltax;

            ss->xCoords[xBytesNeeded++] = (BYTE)(deltax);
        }
        else
        {
            ss->xCoords[xBytesNeeded++] = (BYTE)((deltax & 0xFF00) >> 8);
            ss->xCoords[xBytesNeeded++] = (deltax & 0x00FF);
        }

        if (deltay == 0)
            curFlag |= FLAG_Y_SAME;
        else if ((deltay <= 255) && (deltay >= -255))
        {
            curFlag |= FLAG_Y_SHORT_VECTOR;

            if (deltay > 0)
                curFlag |= FLAG_Y_SAME;
            else
                deltay = -deltay;

            ss->yCoords[yBytesNeeded++] = (BYTE)(deltay);
        }
        else
        {
            ss->yCoords[yBytesNeeded++] = (BYTE)((deltay & 0xFF00) >> 8);
            ss->yCoords[yBytesNeeded++] = (deltay & 0x00FF);
        }

        if (curFlag == lastFlag)
        {
            repeatCount++;

            if (repeatCount == 255)
            {
                ss->flags[flagsBytesNeeded++] = curFlag | FLAG_REPEAT;
                ss->flags[flagsBytesNeeded++] = 255;
                repeatCount = 0;
            }
        }
        else
        {
            if (repeatCount == 0)
                ss->flags[flagsBytesNeeded++] = lastFlag;
            else
            {
                ss->flags[flagsBytesNeeded++] = lastFlag | FLAG_REPEAT;
                ss->flags[flagsBytesNeeded++] = (BYTE)repeatCount;
                repeatCount = 0;
            }

            lastFlag = curFlag;
        }
    }

    if (repeatCount == 0)
        ss->flags[flagsBytesNeeded++] = lastFlag;
    else
    {
        ss->flags[flagsBytesNeeded++] = lastFlag | FLAG_REPEAT;
        ss->flags[flagsBytesNeeded++] = (BYTE)repeatCount;
    }

    // calculate the size of the glyf data
    glyf_object->glyfSize  = sizeof(USHORT) * glyf_object->numberOfContours;
    glyf_object->glyfSize += sizeof(USHORT);                                // instruction length (zero)
    glyf_object->glyfSize += instructionBytesNeeded;

    glyf_object->glyfSize += flagsBytesNeeded;                              // flags bytes
    glyf_object->glyfSize += xBytesNeeded + yBytesNeeded;                   // x and y
    glyf_object->glyfSize  = (glyf_object->glyfSize + 1) & ~1;              // Make sure the size is even

    if (glyf_object->glyfSize != 0)
    {
        // create the glyfBlock
        glyf_object->glyfBlock = (BYTE*)calloc(glyf_object->glyfSize, 1);
        if (glyf_object->glyfBlock == NULL)
        {
            return LF_OUT_OF_MEMORY;
        }

        LF_STREAM glyfStream;

        STREAM_initMemStream(&glyfStream, glyf_object->glyfBlock, glyf_object->glyfSize);

        // contour ends
        for (SHORT j = 0; j < glyf_object->numberOfContours; ++j)
            STREAM_writeUShort(&glyfStream, outl->endPtsOfContours[j]);

        // instruction length (should be zero)
        instructionBytesNeeded = glyph->glyphHints.hintsLength;
        STREAM_writeUShort(&glyfStream, (USHORT)instructionBytesNeeded);

        // instructions (should not be any)
        if (instructionBytesNeeded != 0)
            STREAM_writeChunk(&glyfStream, glyph->glyphHints.hintsData, instructionBytesNeeded);

        STREAM_writeChunk(&glyfStream, ss->flags, flagsBytesNeeded);    // flags
        STREAM_writeChunk(&glyfStream, ss->xCoords, xBytesNeeded);      // x's
        STREAM_writeChunk(&glyfStream, ss->yCoords, yBytesNeeded);      // y's
    }

    return LF_ERROR_OK;
}

LF_ERROR conversion_addPointsToGlyphOutline(LF_VECTOR* pointsData, Glyph_Outline* quadGlyphOutline)
{
    size_t i, numDataItems = vector_size(pointsData);
    unsigned short numPoints = (unsigned short)(numDataItems / 4);

    // the points list has 4 data items per point: flags, x, y, bool for end of contour

    // figure out the (original) end of contours
    size_t numContours = 0;
    for (i = 0; i < numDataItems; i+=4)
    {
        boolean isEnd = (boolean)(intptr_t)vector_at(pointsData, (i + 3));

        if (isEnd == TRUE)
            numContours++;
    }

    if (numContours == 0)
        return LF_ERROR_OK;

    USHORT* origEOC = (USHORT*)calloc(numContours, sizeof(USHORT));

    if (origEOC == NULL)
        return LF_OUT_OF_MEMORY;

    size_t curContour = 0;

    for (i = 0; i < numPoints; i++)
    {
        boolean isEnd = (boolean)(intptr_t)vector_at(pointsData, (i*4 + 3));
        if (isEnd == TRUE)
            origEOC[curContour++] = (USHORT)i;
    }

    boolean* needClosingPointArray = (boolean *)calloc(numContours, sizeof(boolean));
    if (needClosingPointArray == NULL)
    {
        free(origEOC);
        return LF_OUT_OF_MEMORY;
    }

    // for each contour, check to see if the last point is the same as the first.
    // if not we need to add the closing point
    unsigned short numAdditionalPoints = 0;

    for (i = 0; i < numContours; i++)
    {
        size_t startIndex, endIndex;

        if (i == 0)
            startIndex = 0;
        else
            startIndex = origEOC[i - 1] + 1;

        endIndex = origEOC[i];
        ASSERT((i == 0) || (endIndex != 0));    // it is possible that a single point contour is the first thing in the glyph

        SHORT firstX = (SHORT)(intptr_t)vector_at(pointsData, (startIndex * 4) + 1);
        SHORT firstY = (SHORT)(intptr_t)vector_at(pointsData, (startIndex * 4) + 2);
        SHORT lastX = (SHORT)(intptr_t)vector_at(pointsData, (endIndex * 4) + 1);
        SHORT lastY = (SHORT)(intptr_t)vector_at(pointsData, (endIndex * 4) + 2);

        BYTE  firstFlags = (BYTE)(intptr_t)vector_at(pointsData, (startIndex * 4));
        BYTE  lastFlags =  (BYTE)(intptr_t)vector_at(pointsData, (endIndex * 4));

        if ((firstX != lastX) || (firstY != lastY) || ((lastFlags & FLAG_ON_CURVE) == 0))
        {
            needClosingPointArray[i] = TRUE;
            numAdditionalPoints++;
            if (!(firstFlags & FLAG_ON_CURVE) && (endIndex != startIndex))
            {
                BYTE  secondFlags = (BYTE)(intptr_t)vector_at(pointsData, ((startIndex+1) * 4));

                if (!(secondFlags & FLAG_ON_CURVE))
                    numAdditionalPoints++; // account for implicit point added at the beginning
            }
        }
    }

    Simple_Outline* so = &quadGlyphOutline->component.outline;

    so->np = numPoints + numAdditionalPoints;
    so->nc = (unsigned short)numContours;
    so->endPtsOfContours = (unsigned short*)malloc(numContours*sizeof(unsigned short));
    if (so->endPtsOfContours == NULL)
    {
        free(needClosingPointArray);
        free(origEOC);
        return LF_OUT_OF_MEMORY;
    }

    so->types = (Point_Type*)malloc(so->np*sizeof(Point_Type));
    if (so->types == NULL)
    {
        free(so->endPtsOfContours);
        free(needClosingPointArray);
        free(origEOC);
        return LF_OUT_OF_MEMORY;
    }

    so->x = (float*)malloc(so->np*sizeof(float));
    if (so->x == NULL)
    {
        free(so->endPtsOfContours);
        free(so->types);
        free(needClosingPointArray);
        free(origEOC);
        return LF_OUT_OF_MEMORY;
    }

    so->y = (float*)malloc(so->np*sizeof(float));
    if (so->y == NULL)
    {
        free(so->endPtsOfContours);
        free(so->types);
        free(so->x);
        free(needClosingPointArray);
        free(origEOC);
        return LF_OUT_OF_MEMORY;
    }

    size_t origPointIndex = 0;
    size_t destPointIndex = 0;
    size_t origContourStartIndex, origContourEndIndex;

    for (i = 0; i < numContours; i++)
    {
        float firstX, firstY, secondX, secondY;
        BYTE flag, firstFlag, secondFlag;

        if (i == 0)
            origContourStartIndex = 0;
        else
            origContourStartIndex = origEOC[i - 1] + 1;

        origContourEndIndex = origEOC[i];

        // handle the initial MOVE_TO which may not be the first point
        // see fill_outline() in iType's fs_outline.c
        firstFlag = (BYTE)(intptr_t)vector_at(pointsData, (origPointIndex * 4));
        firstX = (float)(intptr_t)vector_at(pointsData, (origPointIndex * 4) + 1);
        firstY = (float)(intptr_t)vector_at(pointsData, (origPointIndex * 4) + 2);
        secondX = firstX;
        secondY = firstY;
        //secondFlag = firstFlag;

        if (firstFlag & FLAG_ON_CURVE)
        {
            so->x[destPointIndex] = firstX;
            so->y[destPointIndex] = firstY;
            so->types[destPointIndex] = MOVE_TO;
        }
        else if (origPointIndex < origContourEndIndex)
        {
            origPointIndex++;
            secondFlag = (BYTE)(intptr_t)vector_at(pointsData, (origPointIndex * 4));
            secondX = (float)(intptr_t)vector_at(pointsData, (origPointIndex * 4) + 1);
            secondY = (float)(intptr_t)vector_at(pointsData, (origPointIndex * 4) + 2);
            if (secondFlag & FLAG_ON_CURVE)
            {
                so->x[destPointIndex] = secondX;
                so->y[destPointIndex] = secondY;
                so->types[destPointIndex] = MOVE_TO;

            }
            else
            {
                so->x[destPointIndex] = (firstX + secondX) / 2.0f;
                so->y[destPointIndex] = (firstY + secondY) / 2.0f;
                so->types[destPointIndex] = MOVE_TO; // implicit on-curve point becomes the moveto
                destPointIndex++;
                so->x[destPointIndex] = secondX;
                so->y[destPointIndex] = secondY;
                so->types[destPointIndex] = OFF_CURVE;
                secondX = (firstX + secondX) / 2.0f;
                secondY = (firstY + secondY) / 2.0f;
            }
        }
        else if (origPointIndex == origContourEndIndex)
        {
            so->x[destPointIndex] = firstX;
            so->y[destPointIndex] = firstY;
            so->types[destPointIndex] = MOVE_TO;
            firstFlag = FLAG_ON_CURVE; // treat single point off-curve contour as on-curve
        }

        origPointIndex++;
        destPointIndex++;

        while (origPointIndex <= origContourEndIndex)
        {
            flag = (BYTE)(intptr_t)vector_at(pointsData, (origPointIndex * 4));

            if (flag & FLAG_ON_CURVE)
            {
                if (so->types[destPointIndex - 1] != OFF_CURVE)
                    so->types[destPointIndex] = LINE_TO;
                else
                    so->types[destPointIndex] = ON_CURVE;
            }
            else
            {
                so->types[destPointIndex] = OFF_CURVE;
            }

            so->x[destPointIndex] = (float)(intptr_t)vector_at(pointsData, (origPointIndex * 4) + 1);
            so->y[destPointIndex] = (float)(intptr_t)vector_at(pointsData, (origPointIndex * 4) + 2);

            origPointIndex++;
            destPointIndex++;
        }

        if (needClosingPointArray[i] == TRUE)
        {
            if (firstFlag & FLAG_ON_CURVE)
            {
                so->x[destPointIndex] = (float)(intptr_t)vector_at(pointsData, (origContourStartIndex * 4) + 1);
                so->y[destPointIndex] = (float)(intptr_t)vector_at(pointsData, (origContourStartIndex * 4) + 2);

                if (so->types[destPointIndex - 1] == OFF_CURVE)
                    so->types[destPointIndex] = ON_CURVE;
                else
                    so->types[destPointIndex] = LINE_TO;
            }
            else
            {
                so->x[destPointIndex] = firstX;
                so->y[destPointIndex] = firstY;
                so->types[destPointIndex] = OFF_CURVE;
                destPointIndex++;
                so->x[destPointIndex] = secondX;
                so->y[destPointIndex] = secondY;
                so->types[destPointIndex] = ON_CURVE;
            }

            destPointIndex++;
        }

        so->endPtsOfContours[i] = (unsigned short)(destPointIndex - 1);
    }

    free(needClosingPointArray);
    free(origEOC);

    return LF_ERROR_OK;
}

LF_ERROR conversion_addPointsToGlyphOutlineV2(LF_VECTOR* pointsData, Glyph_Outline* quadGlyphOutline)
{
    size_t i, numDataItems = vector_size(pointsData);
    unsigned short numPoints = (unsigned short)(numDataItems / 4);

    // the points list has 4 data items per point: flags, x, y, bool for end of contour

    // figure out the (original) end of contours
    size_t numContours = 0;
    for (i = 0; i < numDataItems; i += 4)
    {
        boolean isEnd = (boolean)(intptr_t)vector_at(pointsData, (i + 3));

        if (isEnd == TRUE)
            numContours++;
    }

    if (numContours == 0)
        return LF_ERROR_OK;

    USHORT* origEOC = (USHORT*)calloc(numContours, sizeof(USHORT));

    if (origEOC == NULL)
        return LF_OUT_OF_MEMORY;

    size_t curContour = 0;

    for (i = 0; i < numPoints; i++)
    {
        boolean isEnd = (boolean)(intptr_t)vector_at(pointsData, (i * 4 + 3));
        if (isEnd == TRUE)
            origEOC[curContour++] = (USHORT)i;
    }

    boolean* needClosingPointArray = (boolean *)calloc(numContours, sizeof(boolean));
    if (needClosingPointArray == NULL)
    {
        free(origEOC);
        return LF_OUT_OF_MEMORY;
    }

    // for each contour, check to see if the last point is the same as the first.
    // if not we need to add the closing point
    unsigned short numAdditionalPoints = 0;

    for (i = 0; i < numContours; i++)
    {
        size_t startIndex, endIndex;

        if (i == 0)
            startIndex = 0;
        else
            startIndex = origEOC[i - 1] + 1;

        endIndex = origEOC[i];
        ASSERT((i == 0) || (endIndex != 0));    // it is possible that a single point contour is the first thing in the glyph

        SHORT firstX = (SHORT)(intptr_t)vector_at(pointsData, (startIndex * 4) + 1);
        SHORT firstY = (SHORT)(intptr_t)vector_at(pointsData, (startIndex * 4) + 2);
        SHORT lastX = (SHORT)(intptr_t)vector_at(pointsData, (endIndex * 4) + 1);
        SHORT lastY = (SHORT)(intptr_t)vector_at(pointsData, (endIndex * 4) + 2);

        //BYTE  firstFlags = (BYTE)(long)vector_at(pointsData, (startIndex * 4));
        //BYTE  lastFlags = (BYTE)(long)vector_at(pointsData, (endIndex * 4));

        if ((firstX != lastX) || (firstY != lastY) /* || ((lastFlags & FLAG_ON_CURVE) == 0) */)
        {
            needClosingPointArray[i] = TRUE;
            numAdditionalPoints++;
#if 0
            if (!(firstFlags & FLAG_ON_CURVE) && (endIndex != startIndex))
            {
                BYTE  secondFlags = (BYTE)(long)vector_at(pointsData, ((startIndex + 1) * 4));

                if (!(secondFlags & FLAG_ON_CURVE))
                    numAdditionalPoints++; // account for implicit point added at the beginning
            }
#endif
        }
    }

    Simple_Outline* so = &quadGlyphOutline->component.outline;

    so->np = numPoints + numAdditionalPoints;
    so->nc = (unsigned short)numContours;
    so->endPtsOfContours = (unsigned short*)malloc(numContours*sizeof(unsigned short));
    if (so->endPtsOfContours == NULL)
    {
        free(needClosingPointArray);
        free(origEOC);
        return LF_OUT_OF_MEMORY;
    }

    so->types = (Point_Type*)malloc(so->np*sizeof(Point_Type));
    if (so->types == NULL)
    {
        free(so->endPtsOfContours);
        free(needClosingPointArray);
        free(origEOC);
        return LF_OUT_OF_MEMORY;
    }

    so->x = (float*)malloc(so->np*sizeof(float));
    if (so->x == NULL)
    {
        free(so->endPtsOfContours);
        free(so->types);
        free(needClosingPointArray);
        free(origEOC);
        return LF_OUT_OF_MEMORY;
    }

    so->y = (float*)malloc(so->np*sizeof(float));
    if (so->y == NULL)
    {
        free(so->endPtsOfContours);
        free(so->types);
        free(so->x);
        free(needClosingPointArray);
        free(origEOC);
        return LF_OUT_OF_MEMORY;
    }

    size_t origPointIndex = 0;
    size_t destPointIndex = 0;
    size_t origContourStartIndex, origContourEndIndex;

    for (i = 0; i < numContours; i++)
    {
        float firstX, firstY, secondX, secondY;
        BYTE flag, firstFlag;
        size_t indexOfFirstOnCurvePoint;

        if (i == 0)
            origContourStartIndex = 0;
        else
            origContourStartIndex = origEOC[i - 1] + 1;

        indexOfFirstOnCurvePoint = origContourStartIndex;

        origContourEndIndex = origEOC[i];

        // handle the initial MOVE_TO which may not be the first point
        // see fill_outline() in iType's fs_outline.c
        firstFlag = (BYTE)(intptr_t)vector_at(pointsData, (origPointIndex * 4));
        firstX = (float)(intptr_t)vector_at(pointsData, (origPointIndex * 4) + 1);
        firstY = (float)(intptr_t)vector_at(pointsData, (origPointIndex * 4) + 2);
        secondX = firstX;
        secondY = firstY;

        if (firstFlag & FLAG_ON_CURVE)
        {
            so->x[destPointIndex] = firstX;
            so->y[destPointIndex] = firstY;
            so->types[destPointIndex] = MOVE_TO;
        }
        else if (origPointIndex < origContourEndIndex)
        {
            // determine index of first on-curve point

            size_t curIndex = origPointIndex++;
            boolean found = FALSE;

            while ((FALSE == found) && (curIndex < origContourEndIndex))
            {
                BYTE f = (BYTE)(intptr_t)vector_at(pointsData, (curIndex * 4));

                if (f & FLAG_ON_CURVE)
                {
                    found = TRUE;
                    break;
                }

                curIndex++;
            };


            if (FALSE == found)
            {
                free(so->endPtsOfContours);
                free(so->types);
                free(so->x);
                free(needClosingPointArray);
                free(origEOC);
                return LF_BAD_FORMAT;
            }

            indexOfFirstOnCurvePoint = curIndex;

            so->x[destPointIndex] = (float)(intptr_t)vector_at(pointsData, (indexOfFirstOnCurvePoint * 4) + 1);
            so->y[destPointIndex] = (float)(intptr_t)vector_at(pointsData, (indexOfFirstOnCurvePoint * 4) + 2);
            so->types[destPointIndex] = MOVE_TO;

            origPointIndex = indexOfFirstOnCurvePoint;


#if 0
            origPointIndex++;
            secondFlag = (BYTE)(long)vector_at(pointsData, (origPointIndex * 4));
            secondX = (float)(long)vector_at(pointsData, (origPointIndex * 4) + 1);
            secondY = (float)(long)vector_at(pointsData, (origPointIndex * 4) + 2);

            if (secondFlag & FLAG_ON_CURVE)
            {
                indexOfFirstOnCurvePoint = 1;
                so->x[destPointIndex] = secondX;
                so->y[destPointIndex] = secondY;
                so->types[destPointIndex] = MOVE_TO;

            }
            else
            {
                so->x[destPointIndex] = (firstX + secondX) / 2.0f;
                so->y[destPointIndex] = (firstY + secondY) / 2.0f;
                so->types[destPointIndex] = MOVE_TO; // implicit on-curve point becomes the moveto
                destPointIndex++;
                so->x[destPointIndex] = secondX;
                so->y[destPointIndex] = secondY;
                so->types[destPointIndex] = OFF_CURVE;
                secondX = (firstX + secondX) / 2.0f;
                secondY = (firstY + secondY) / 2.0f;
            }
#endif

        }
        else if (origPointIndex == origContourEndIndex)
        {
            so->x[destPointIndex] = firstX;
            so->y[destPointIndex] = firstY;
            so->types[destPointIndex] = MOVE_TO;
            firstFlag = FLAG_ON_CURVE; // treat single point off-curve contour as on-curve
        }

        origPointIndex++;
        destPointIndex++;

        while (origPointIndex <= origContourEndIndex)
        {
            flag = (BYTE)(intptr_t)vector_at(pointsData, (origPointIndex * 4));

            if (flag & FLAG_ON_CURVE)
            {
                if (so->types[destPointIndex - 1] != OFF_CURVE)
                    so->types[destPointIndex] = LINE_TO;
                else
                    so->types[destPointIndex] = ON_CURVE;
            }
            else
            {
                so->types[destPointIndex] = OFF_CURVE;
            }

            so->x[destPointIndex] = (float)(intptr_t)vector_at(pointsData, (origPointIndex * 4) + 1);
            so->y[destPointIndex] = (float)(intptr_t)vector_at(pointsData, (origPointIndex * 4) + 2);

            origPointIndex++;
            destPointIndex++;
        }


        if (indexOfFirstOnCurvePoint != origContourStartIndex)
        {
            size_t numOffCurve = indexOfFirstOnCurvePoint - origContourStartIndex;
            size_t theIndex = origContourStartIndex;

            for (size_t j = 0; j < numOffCurve; j++)
            {
                so->x[destPointIndex] = (float)(intptr_t)vector_at(pointsData, (theIndex * 4) + 1);
                so->y[destPointIndex] = (float)(intptr_t)vector_at(pointsData, (theIndex * 4) + 2);
                so->types[destPointIndex] = OFF_CURVE;

                theIndex++;
                destPointIndex++;
            }
        }


        if (needClosingPointArray[i] == TRUE)
        {
            if (firstFlag & FLAG_ON_CURVE)
            {
                so->x[destPointIndex] = (float)(intptr_t)vector_at(pointsData, (origContourStartIndex * 4) + 1);
                so->y[destPointIndex] = (float)(intptr_t)vector_at(pointsData, (origContourStartIndex * 4) + 2);

                if (so->types[destPointIndex - 1] == OFF_CURVE)
                    so->types[destPointIndex] = ON_CURVE;
                else
                    so->types[destPointIndex] = LINE_TO;
            }
            else
            {
                so->x[destPointIndex] = (float)(intptr_t)vector_at(pointsData, (indexOfFirstOnCurvePoint * 4) + 1);
                so->y[destPointIndex] = (float)(intptr_t)vector_at(pointsData, (indexOfFirstOnCurvePoint * 4) + 2);
                so->types[destPointIndex] = ON_CURVE;



#if 0
                so->x[destPointIndex] = firstX;
                so->y[destPointIndex] = firstY;
                so->types[destPointIndex] = OFF_CURVE;
                destPointIndex++;
                so->x[destPointIndex] = secondX;
                so->y[destPointIndex] = secondY;
                so->types[destPointIndex] = ON_CURVE;
#endif


            }

            destPointIndex++;
        }

        so->endPtsOfContours[i] = (unsigned short)(destPointIndex - 1);
    }

    free(needClosingPointArray);
    free(origEOC);

    return LF_ERROR_OK;
}

void conversion_removeSinglePointContours(Glyph_Outline* glyphOutline)
{
    if (glyphOutline->numberOfComponents > 0)
    {
        Glyph_Component* gc = &glyphOutline->component;
        Simple_Outline* so = &gc->outline;

        if (so->nc > 0)
        {
            unsigned short orignc = so->nc;
            short i;
            for (i = orignc - 1; i > 0; i--)
            {
                if (1 == so->endPtsOfContours[i] - so->endPtsOfContours[i-1])
                {
                    // single point contour
                    for (int j = so->endPtsOfContours[i]; j < so->np-1; j++)
                    {
                        so->x[j] = so->x[j + 1];
                        so->y[j] = so->y[j + 1];
                        so->types[j] = so->types[j + 1];
                    }
                    for (int j = i; j < orignc-1; j++)
                    {
                        so->endPtsOfContours[j] = so->endPtsOfContours[j+1] - 1;
                    }

                    so->nc--;
                    so->np--;
                }
            }
        }
    }
}

void conversion_setGlyphOutlineParams(Glyph_Outline* quadGlyphOutline, size_t index)
{
    // This code currently always flattens composite glyphs into a simple glyph
    quadGlyphOutline->numberOfComponents = 1;
    quadGlyphOutline->component.next = 0;
    quadGlyphOutline->component.glyphIndex = (unsigned short)index;
    quadGlyphOutline->component.type = eSimple;
}

LF_ERROR conversion_getCFFGlyph(const cff_table* cffTable, USHORT index, Glyph* cubicGlyph)
{
    CFF_ERROR cffErr = cff_loadCharStringIntoGlyph(cffTable, index, cubicGlyph);

    return cff_mapCffErrorToLfError(cffErr);
}

LF_ERROR conversion_convertCharstringsToGlyphs(const cff_table* cffTable, LF_MAP* glyphMap, Glyph* glyphDataBlock)
{
    USHORT i, numGlyphs = (USHORT)map_size(cffTable->charStringMap);

    for (i = 0; i < numGlyphs; i++)
    {
        Glyph* cubicGlyph = glyphDataBlock + i;

        CFF_ERROR cffErr = cff_loadCharStringIntoGlyph(cffTable, i, cubicGlyph);

        if (cffErr != CFF_ERR_OK)
            return cff_mapCffErrorToLfError(cffErr);

        map_insert(glyphMap, (void*)(intptr_t)i, cubicGlyph);
    }

    return LF_ERROR_OK;
}

//#define DUMP_ON
#ifdef DUMP_ON

static void dumpQuad(Glyph_Outline* go)
{
    Simple_Outline *quadOutline = &go->component.outline;

    printf("\nQuad Glyph:\n");

    for (int j = 0; j < quadOutline->np - 2; j++)
    {
        printf("%d %f %f %d\n", j, quadOutline->x[j], quadOutline->y[j], quadOutline->types[j]);
    }

    printf("num points = %d\n", quadOutline->np - 2);  //excludes phantom points
    printf("lsb, rsb = %f,%f\n", quadOutline->x[quadOutline->np - 2], quadOutline->x[quadOutline->np - 1]);
    printf("bounds = %f,%f,%f,%f\n", go->xMax, go->xMin, go->yMax, go->yMin);
    printf("\n");
}

static void dumpCubic(Glyph_Outline* go)
{
    Simple_Outline *cubicOutline = &go->component.outline;

    printf("\nCubic Glyph:\n");

    for (int j = 0; j < cubicOutline->np - 2; j++)
    {
        printf("%d %f %f %d\n", j, cubicOutline->x[j], cubicOutline->y[j], cubicOutline->types[j]);
    }

    printf("num points = %d\n", cubicOutline->np - 2);  //excludes phantom points
    printf("lsb, rsb = %f,%f\n", cubicOutline->x[cubicOutline->np - 2], cubicOutline->x[cubicOutline->np - 1]);
    printf("bounds = %f,%f,%f,%f\n", go->xMax, go->xMin, go->yMax, go->yMin);
    printf("\n");
}

#define DumpQuad(q) dumpQuad(q)
#define DumpCubic(q) dumpCubic(q)
#else

#define DumpQuad(q)
#define DumpCubic(q)
#endif


#if _DEBUG
#include <math.h>
#define PT_ROUND(f) (float)(floor((f + 0.5)))

static void checkRounding(Simple_Outline* o, size_t index, boolean doAssert)
{
    // check that the points are integers
    for (int j = 0; j < o->np; j++)
    {
        float beforex = o->x[j];
        float beforey = o->y[j];
        float afterx = PT_ROUND(beforex);
        float aftery = PT_ROUND(beforey);

        if ((beforex != afterx) || (beforey != aftery))
        {
            printf("non-integer point: glyph %d point %d\n", (int)index, j);
        }

        if (doAssert)
        {
            ASSERT((beforex == afterx) && (beforey == aftery));
        }
    }
}

#define checkRnd(x, i, a) checkRounding(x, i, a)
#else
#define checkRnd(x, i, a)
#endif

// Compute the bounding box of a quadratic glyph
void conversion_computeQuadBoundingBox(Glyph* quadGlyph)
{
    Simple_Outline *quadOutline = &quadGlyph->glyphOutline.component.outline;

    if (quadGlyph->glyphOutline.component.type == eIsComposite)
        return;

    if (quadOutline->np == 0)
    {
        quadGlyph->glyphOutline.xMax = 0;
        quadGlyph->glyphOutline.xMin = 0;
        quadGlyph->glyphOutline.yMax = 0;
        quadGlyph->glyphOutline.yMin = 0;
        return;
    }

    quadGlyph->glyphOutline.xMax = quadGlyph->glyphOutline.xMin = quadOutline->x[0];
    quadGlyph->glyphOutline.yMax = quadGlyph->glyphOutline.yMin = quadOutline->y[0];

    for (int j = 1; j < quadOutline->np; j++)
    {
        if (quadOutline->x[j] > quadGlyph->glyphOutline.xMax)
            quadGlyph->glyphOutline.xMax = quadOutline->x[j];
        if (quadOutline->x[j] < quadGlyph->glyphOutline.xMin)
            quadGlyph->glyphOutline.xMin = quadOutline->x[j];
        if (quadOutline->y[j] > quadGlyph->glyphOutline.yMax)
            quadGlyph->glyphOutline.yMax = quadOutline->y[j];
        if (quadOutline->y[j] < quadGlyph->glyphOutline.yMin)
            quadGlyph->glyphOutline.yMin = quadOutline->y[j];
    }
}

//
// Converts the cubic outlines in the glyph map to quadratic outlines and inserts
// a corresponding glyf object into the glyfTable.
//
// Note that in the glyf table, the data for each glyph is in the data block for each glyph. i.e.
// the parsed flags and coordinates for the glyphs will not be present in the glyf table.
// (since that doens't seem to be needed anyway and it is faster not to)
//
// This function operates by allocating scratch space that is reused for the compressed
// flags and coords which end up in the data block for each glyph.
//
static LF_ERROR convertGlyphsToGlyfs(const LF_MAP* glyphMap, USHORT origUnitsPerEm, USHORT outputUnitsPerEm, float tolerance, glyf_table* glyfTable)
{
    if (glyphMap == NULL || glyfTable == NULL)
        return LF_INVALID_PARAM;

    USHORT i, numGlyphs = (USHORT)map_size(glyphMap);

    if (numGlyphs == 0)
        return LF_ERROR_OK;

    // allocate some temp space for the compressed data, start with enough for max of 256 points
    glyfBuildScratchSpace scratch;

    if (0 != conversion_allocateScratchSpace(&scratch, 256))
        return LF_OUT_OF_MEMORY;

    USHORT* pointCounts = (USHORT*)calloc(numGlyphs, sizeof(USHORT));
    if (pointCounts == NULL)
    {
        conversion_freeScratchSpace(&scratch);
        return LF_OUT_OF_MEMORY;
    }

    float scaledTolerance = tolerance * (origUnitsPerEm / 1000.0f);

    boolean hasComposites = FALSE;

    // now convert the cubic CFF glyphs to quads and store in glyf table
    for (i = 0; i < numGlyphs; i++)
    {
        Glyph *cubicGlyph, quadGlyph;

        //if (i % 1000 == 0)
        //printf("Glyph %d\n", i);

        memset(&quadGlyph, 0, sizeof(Glyph)); // reset temp object

        cubicGlyph = (Glyph*)map_at(glyphMap, (void*)(intptr_t)i);
        if (cubicGlyph == NULL)
            continue;

        glyf* quad_glyf = (glyfTable->glyphDataBlock + i);

        if (cubicGlyph->glyphOutline.numberOfComponents > 1)
        {
            hasComposites = TRUE;

            LF_ERROR error = convertCompositeGlyphToCompressedGlyf(cubicGlyph, quad_glyf);

            if (error != LF_ERROR_OK)
            {
                free(pointCounts);
                conversion_freeScratchSpace(&scratch);
                return error;
            }

            map_insert(glyfTable->glyfMap, (void*)(intptr_t)i, quad_glyf);
        }
        else if (cubicGlyph->glyphOutline.component.outline.nc == 0)
        {
            quad_glyf->glyfBlock = NULL;   // probably redundant
            map_insert(glyfTable->glyfMap, (void*)(intptr_t)i, NULL);
        }
        else
        {
            quadGlyph.glyphType = eGlyph_TTF;

            DumpCubic(&cubicGlyph->glyphOutline);

            // single component quad glyph
            quadGlyph.glyphOutline.numberOfComponents = 1;
            quadGlyph.glyphOutline.component.next = 0;
            quadGlyph.glyphOutline.component.glyphIndex = cubicGlyph->glyphOutline.component.glyphIndex;
            quadGlyph.glyphOutline.component.type = eSimple;

            Simple_Outline *cubicOutline = &cubicGlyph->glyphOutline.component.outline;
            Simple_Outline *quadOutline = &quadGlyph.glyphOutline.component.outline;

            cubicOutline->designUnits = origUnitsPerEm;
            quadOutline->designUnits = outputUnitsPerEm;

            // metrics
            quadGlyph.glyphMetrics.aw  = cubicOutline->x[cubicOutline->np - 1];
            quadGlyph.glyphMetrics.lsb = cubicOutline->x[cubicOutline->np - 2];
            quadGlyph.glyphMetrics.ah  = cubicOutline->y[cubicOutline->np - 1];
            quadGlyph.glyphMetrics.tsb = cubicOutline->y[cubicOutline->np - 2];

            // convert to quads
            Conversion_Error err = convertCubic(cubicOutline, scaledTolerance, quadOutline);
            if (CONVERSION_SUCCESS != err)
            {
                free(pointCounts);
                conversion_freeScratchSpace(&scratch);
                return (err == CONVERSION_MEMORY) ? LF_OUT_OF_MEMORY : LF_CONVERSION;
            }

            checkRnd(quadOutline, i, TRUE);

            // compute outline bounding box
            conversion_computeQuadBoundingBox(&quadGlyph);

            DumpQuad(&quadGlyph.glyphOutline);

            // update the maxp info

            pointCounts[i] = quadGlyph.glyphOutline.component.outline.np;

            if (quadGlyph.glyphOutline.component.outline.nc > glyfTable->derivedMaxp.maxContours)
                glyfTable->derivedMaxp.maxContours = quadGlyph.glyphOutline.component.outline.nc;
            if (quadGlyph.glyphOutline.component.outline.np > glyfTable->derivedMaxp.maxPoints)
                glyfTable->derivedMaxp.maxPoints = quadGlyph.glyphOutline.component.outline.np;

            if (quadGlyph.glyphOutline.component.outline.np > scratch.allocated)
            {
                size_t newSize = scratch.allocated;
                while (newSize < quadGlyph.glyphOutline.component.outline.np)
                    newSize += 256;
                if (0 != conversion_reallocateScratchSpace(&scratch, newSize))
                {
                    free(pointCounts);
                    return LF_OUT_OF_MEMORY;
                }
            }

            LF_ERROR error = conversion_convertGlyphToCompressedGlyf(&quadGlyph, &scratch, quad_glyf);

            conversion_freeGlyphOutline(&quadGlyph);

            if (error != LF_ERROR_OK)
            {
                free(pointCounts);
                conversion_freeScratchSpace(&scratch);
                return error;
            }

            map_insert(glyfTable->glyfMap, (void*)(intptr_t)i, quad_glyf);
        }
    }

    if (hasComposites == TRUE)
    {
        USHORT maxCompContours = 0;
        USHORT maxCompPoints = 0;

        // update bounding boxes for composites
        for (i = 0; i < numGlyphs; i++)
        {
            Glyph* origCubicGlyph = (Glyph*)map_at(glyphMap, (void*)(intptr_t)i);
            glyf* quad_glyf = (glyf*)map_at(glyfTable->glyfMap, (void*)(intptr_t)i);

            if (quad_glyf && quad_glyf->numberOfContours == -1)
            {
                USHORT baseIndex = origCubicGlyph->glyphOutline.component.glyphIndex;
                USHORT accentIndex = origCubicGlyph->glyphOutline.component.next->glyphIndex;

                glyf* base = (glyf*)map_at(glyfTable->glyfMap, (void*)(intptr_t)baseIndex);
                glyf* acnt = (glyf*)map_at(glyfTable->glyfMap, (void*)(intptr_t)accentIndex);

                if (base == NULL)
                {
                    free(pointCounts);
                    conversion_freeScratchSpace(&scratch);
                    return LF_BAD_FORMAT;
                }

                if (acnt == NULL)
                {
                    quad_glyf->xMin = base->xMin;
                    quad_glyf->xMax = base->xMax;
                    quad_glyf->yMin = base->yMin;
                    quad_glyf->yMax = base->yMax;

                    if (base->numberOfContours > maxCompContours)
                        maxCompContours = base->numberOfContours;
                    if (pointCounts[baseIndex] > maxCompPoints)
                        maxCompPoints = pointCounts[baseIndex];
                }
                else
                {
                    SHORT baseXoff = (SHORT)origCubicGlyph->glyphOutline.component.xoffset;  // always zero?
                    SHORT baseYoff = (SHORT)origCubicGlyph->glyphOutline.component.yoffset;
                    SHORT accentXoff = (SHORT)origCubicGlyph->glyphOutline.component.next->xoffset;
                    SHORT accentYoff = (SHORT)origCubicGlyph->glyphOutline.component.next->yoffset;

                    SHORT adjustedBase = base->xMin + baseXoff;
                    SHORT adjustedAccent = acnt->xMin + accentXoff;
                    quad_glyf->xMin = (adjustedBase < adjustedAccent) ? adjustedBase : adjustedAccent;

                    adjustedBase = base->xMax + baseXoff;
                    adjustedAccent = acnt->xMax + accentXoff;
                    quad_glyf->xMax = (adjustedBase > adjustedAccent) ? adjustedBase : adjustedAccent;

                    adjustedBase = base->yMin + baseYoff;
                    adjustedAccent = acnt->yMin + accentYoff;
                    quad_glyf->yMin = (adjustedBase < adjustedAccent) ? adjustedBase : adjustedAccent;

                    adjustedBase = base->yMax + baseYoff;
                    adjustedAccent = acnt->yMax + accentYoff;
                    quad_glyf->yMax = (adjustedBase > adjustedAccent) ? adjustedBase : adjustedAccent;

                    USHORT totalContours = base->numberOfContours + acnt->numberOfContours;
                    USHORT totalPoints = pointCounts[baseIndex] + pointCounts[accentIndex];

                    if (totalContours > maxCompContours)
                        maxCompContours = totalContours;
                    if (totalPoints > maxCompPoints)
                        maxCompPoints = totalPoints;
                }
            }
        }

        glyfTable->derivedMaxp.maxCompositePoints = maxCompPoints;
        glyfTable->derivedMaxp.maxCompositeContours = maxCompContours;
        glyfTable->derivedMaxp.maxComponentElements = 2;
        glyfTable->derivedMaxp.maxComponentDepth = 1;
    }

    glyfTable->derivedMaxp.maxZones = 1;            // we do not process the hints from the cff table, so there are no instructions, so we can set this to 1.
    glyfTable->maxpInfoUpdated = TRUE;

    free(pointCounts);
    conversion_freeScratchSpace(&scratch);

    return LF_ERROR_OK;
}

static LF_ERROR getNameString(LF_FONT* lfFont, USHORT id, BYTE** buf, ULONG* bufLen)
{
    BYTE tmpBuf[256];
    USHORT strLen;

    *buf = NULL;

    LF_ERROR error = NAME_getNameStringLength(lfFont, id, &strLen);
    if (error == LF_INVALID_TYPE)
    {
        *bufLen = 0;
        return LF_ERROR_OK;
    }
    else if (error != LF_ERROR_OK)
        return error;

    if (strLen > 256)
        strLen = 256;

    error = NAME_getNameString(lfFont, id, tmpBuf, strLen);
    if (error != LF_ERROR_OK)
    {
        *bufLen = 0;
        return error;
    }

    SHORT* ptr = (SHORT*)tmpBuf;

    *bufLen = strLen >> 1;

    *buf = malloc(*bufLen*sizeof(BYTE));
    if (*buf == NULL)
        return LF_OUT_OF_MEMORY;

    for (ULONG i = 0; i < *bufLen; i++)
    {
        if ((*ptr & 0xFF00) != 0)
        {
            DEBUG_LOG_ERROR("non-latin character ");
        }

        (*buf)[i] = (BYTE)(*ptr++);         // Note: false VS2015 analyzer warning here; can't get here if *bufLen = 0
    }
    return LF_ERROR_OK;
}

static void sanitizeNameString(BYTE* buf, ULONG bufLen)
{
    // OpenType Sanitizer requires CFF font names not include spaces and
    // special characters
    if (buf == NULL)
        return;

    for (ULONG i = 0; i < bufLen; i++)
    {
        if (buf[i] < 33 || buf[i] > 126)  // OT Sanitizer requirement
        {
            // replace invalid characters
            buf[i] = '_';
        }
    }
}

typedef struct
{
    cffSID versionSID;
    cffSID noticeSID;
    cffSID copyrightSID;
    cffSID fullNameSID;
    cffSID familyNameSID;
    cffSID weightSID;
    cffSID firstGlyphSID;
} topDictSids;


static LF_ERROR getStringInfo(LF_FONT* lfFont, topDictSids* tdSids, cffIndex* stringIndex)
{
    CFF_ERROR cffErr;
    cffIndexItem item;
    cffSID nextSID = 391;

    memset(tdSids, 0, sizeof(topDictSids));

    LF_ERROR error = getNameString(lfFont, NAME_VERSION_NAME_TABLE, &item.data, &item.length);
    if (error != LF_ERROR_OK)
        return error;

    if (item.data != NULL)
    {
        cffErr = cff_indexAppendCopy(stringIndex, &item);

        free(item.data);
        item.data = NULL;
        if (cffErr != CFF_ERR_OK)
            return cff_mapCffErrorToLfError(cffErr);

        tdSids->versionSID = nextSID++;
    }

    error = getNameString(lfFont, NAME_TRADEMARK_NOTICE, &item.data, &item.length);
    if (error != LF_ERROR_OK)
        return error;

    if (item.data != NULL)
    {
        cffErr = cff_indexAppendCopy(stringIndex, &item);

        free(item.data);
        item.data = NULL;
        if (cffErr != CFF_ERR_OK)
            return cff_mapCffErrorToLfError(cffErr);

        tdSids->noticeSID = nextSID++;
    }

    error = getNameString(lfFont, NAME_COPYRIGHT_NOTICE, &item.data, &item.length);
    if (error != LF_ERROR_OK)
        return error;

    if (item.data != NULL)
    {
        cffErr = cff_indexAppendCopy(stringIndex, &item);

        free(item.data);
        item.data = NULL;
        if (cffErr != CFF_ERR_OK)
            return cff_mapCffErrorToLfError(cffErr);

        tdSids->copyrightSID = nextSID++;
    }

    error = getNameString(lfFont, NAME_FONT_FULL_NAME, &item.data, &item.length);
    if (error != LF_ERROR_OK)
        return error;

    if (item.data != NULL)
    {
        cffErr = cff_indexAppendCopy(stringIndex, &item);

        free(item.data);
        item.data = NULL;
        if (cffErr != CFF_ERR_OK)
            return cff_mapCffErrorToLfError(cffErr);

        tdSids->fullNameSID = nextSID++;
    }

    error = getNameString(lfFont, NAME_FONT_FAMILY_NAME, &item.data, &item.length);
    if (error != LF_ERROR_OK)
        return error;

    if (item.data != NULL)
    {
        cffErr = cff_indexAppendCopy(stringIndex, &item);

        free(item.data);
        item.data = NULL;
        if (cffErr != CFF_ERR_OK)
            return cff_mapCffErrorToLfError(cffErr);

        tdSids->familyNameSID = nextSID++;
    }

    error = getNameString(lfFont, NAME_FONT_SUBFAMILY_NAME, &item.data, &item.length);
    if (error != LF_ERROR_OK)
        return error;

    if (item.data != NULL)
    {
        cffErr = cff_indexAppendCopy(stringIndex, &item);

        free(item.data);

        if (cffErr != CFF_ERR_OK)
            return cff_mapCffErrorToLfError(cffErr);

        tdSids->weightSID = nextSID++;
    }

    tdSids->firstGlyphSID = nextSID;

    return LF_ERROR_OK;
}

// Idea is to return the sid from the Adobe standard encoding for the given Unicode.
// Things that were sid 0 above unicode 0x32 are not mapped since it wasn't clear which Unicode those corresponded to.
// not sure if mapping is quite right.
// values were filled by looking up in agl2uv.h in the ADFDK and using http://www.fileformat.info/info/unicode/
static boolean getAdobeStdID(USHORT unicode, cffSID* sid)
{
    if (unicode < 0x0020)
    {
        *sid = 0;
        return TRUE;
    }
    else if (unicode < 0x007F)
    {
        *sid = unicode - 31;
        return TRUE;
    }
    else
    {
        *sid = 0xFF;

        switch (unicode)
        {
        case 0x00A1: *sid = 96; break; //exclamdown
        case 0x00A2: *sid = 97; break; // cent
        case 0x00A3: *sid = 98; break; // sterling
        case 0x2044: *sid = 99; break; // fraction
        case 0x00A5: *sid = 100; break; // yen
        case 0x0192: *sid = 101; break; // florin
        case 0x00A7: *sid = 102; break; // section
        case 0x00A4: *sid = 103; break; // currency
        //case 0x0027: *sid = 104; break; // quotesingle note
        case 0x201c: *sid = 105; break; // quotedblleft
        case 0x00AB: *sid = 106; break; // guillemotleft
        case 0x2039: *sid = 107; break; // guilsinglleft
        case 0x203A: *sid = 108; break; // guilsinglright
        case 0xFB01: *sid = 109; break; // fi
        case 0xFB02: *sid = 110; break; // fl
        case 0x2013: *sid = 111; break; // endash
        case 0x2020: *sid = 112; break; // dagger
        case 0x2021: *sid = 113; break; // daggerdbl
        case 0x00B7: *sid = 114; break; // periodcentered  note: assuming MIDDLE DOT
        case 0x2029: *sid = 115; break; // paragraph
        case 0x2022: *sid = 116; break; // bullet
        case 0x201A: *sid = 117; break; // quotesinglbase      (SINGLE LOW-9 QUOTATION MARK)
        case 0x201E: *sid = 118; break; // quotedblbase (DOUBLE LOW-9 QUOTATION MARK)
        case 0x201D: *sid = 119; break; // quotedblright (RIGHT DOUBLE QUOTATION MARK)
        case 0x00BB: *sid = 120; break; // guillemotright   (RIGHT-POINTING DOUBLE ANGLE QUOTATION MARK)
        case 0x2026: *sid = 121; break; // ellipsis
        case 0x2030: *sid = 122; break; // perthousand
        case 0x00BF: *sid = 123; break; // questiondown
        //case 0x0060: *sid = 124; break; // grave
        case 0x00B4: *sid = 125; break; // acute
        //case 0x005E: *sid = 126; break; // circumflex
        //case 0x007E: *sid = 127; break; // tilde
        case 0x00AF: *sid = 128; break; // macron
        case 0x02D8: *sid = 129; break; // breve
        case 0x02D9: *sid = 130; break; // dotaccent
        case 0x00A8: *sid = 131; break; // dieresis
        case 0x02DA: *sid = 132; break; // ring
        case 0x00B8: *sid = 133; break; // cedilla
        case 0x02DD: *sid = 134; break; // hungarumlaut  note assuming DOUBLE ACUTE ACCENT as per agl2uv.h
        case 0x02DB: *sid = 135; break; // ogonek
        case 0x02C7: *sid = 136; break; // caron
        case 0x2014: *sid = 137; break; // emdash
        case 0x00C6: *sid = 138; break; // AE
        case 0x00AA: *sid = 139; break; // ordfeminine
        case 0x0141: *sid = 140; break; // Lslash
        case 0x00D8: *sid = 141; break; // Oslash
        case 0x0152: *sid = 142; break; // OE
        case 0x00Ba: *sid = 143; break; // ordmasculine
        case 0x00E6: *sid = 144; break; // ae
        case 0x0131: *sid = 145; break; // dotlessi
        case 0x0142: *sid = 146; break; // lslash
        case 0x00F8: *sid = 147; break; // oslash
        case 0x0153: *sid = 148; break; // oe
        case 0x00DF: *sid = 149; break; // germandbls
        default:                 break;
        }

        if (*sid == 0xFF)
            return FALSE;
        else
            return TRUE;
    }
}

static CFF_ERROR createEmptyCharstring(const ADVANCEDELTA* advanceDelta, BYTE* charStringBuf, LONG spaceAvailable, LONG* charStringBufLen)
{
    LF_STREAM csStream;
    STREAM_initMemStream(&csStream, charStringBuf, spaceAvailable);

    if (advanceDelta->equalsDefaultWidth == FALSE)
        STREAM_writeCffIntegerOperand(&csStream, advanceDelta->delta);

    STREAM_writeByte(&csStream, 14); //endchar

    if (!STREAM_isValid(csStream))
        return CFF_ERR_CS_BUF_EXCEEDED; // an indication that the size was not enough

    *charStringBufLen = (LONG)STREAM_streamPos(&csStream);

    return CFF_ERR_OK;
}

static LF_ERROR createCharset(const LF_FONT* lfFont, ULONG numGlyphsInFont, cffSID firstSid,
                              cffIndex* stringIndex, BYTE** charsetBuf, LONG* charsetLen)
{
    glyf_table* glyfTable = (glyf_table*)map_at(&lfFont->table_map, (void*)(long)TAG_GLYF);
    if (glyfTable == NULL)
        return LF_TABLE_MISSING;

    ULONG postVers = POST_getVersion(lfFont);
    boolean havePostNames = (postVers == 0x00020000) ? TRUE : FALSE;

    if (numGlyphsInFont == 0)
        return LF_BAD_FORMAT;

    // We need the original gids in order to look up the names in the post table.
    // In the case that the glyph table has already been reindexed (svg was created),
    // the remap map in the glyph table has the original ids as the keys.
    LF_MAP* glyphIDMap = (glyfTable->remap != NULL) ? glyfTable->remap : glyfTable->glyfMap;

    cffSID* charset = (cffSID*)malloc(numGlyphsInFont * sizeof(cffSID));
    if (charset == NULL)
        return LF_OUT_OF_MEMORY;

    // create map: key = GID, data = unicode
    LF_MAP inverseCmap;
    map_init(&inverseCmap, integer_compare);

    ULONG i;

    for (i = 0; i < 65536; i++)
    {
        GlyphID gid;
        CMAP_getGlyphID(lfFont, i, &gid);

        if (gid != 0)
        {
            if (map_key_exists(glyphIDMap, (void*)(intptr_t)gid))
                map_insert(&inverseCmap, (void*)(intptr_t)gid, (void*)(intptr_t)i);
        }
    }

    LF_MAP_ITER* iter = map_begin(glyphIDMap);
    if (iter == NULL)
    {
        free(charset);
        map_clear(&inverseCmap);
        return LF_OUT_OF_MEMORY;
    }

    (void)map_next(iter); // skip glyph 0

    rb_tree_node* node = map_next(iter);

    charset[0] = 0;

    CFF_ERROR cffErr;
    cffIndexItem item;
    cffSID nextNonStdSID = firstSid;
    USHORT index = 1;
    CHAR *c;

    if (numGlyphsInFont == 1)
        return LF_BAD_FORMAT;

    while (node != NULL)
    {
        GlyphID gid = (GlyphID)(intptr_t)node->key;

        USHORT unicode = (USHORT)(intptr_t)map_at(&inverseCmap, (void*)(intptr_t)gid);

        cffSID sid;
        if ((getAdobeStdID(unicode, &sid) == TRUE) && ((gid == 0) || (sid != 0)))
        {
            charset[index++] = sid;
        }
        else if ((havePostNames == TRUE) && (c = POST_getGlyfNameFromIndex(lfFont, gid)) != NULL)
        {

            //printf("gid %d name %s\n", gid, c);

            item.data = (BYTE*)c;
            item.length = (ULONG)strlen((const char*)c);

            cffErr = cff_indexAppendCopy(stringIndex, &item);
            if (cffErr != CFF_ERR_OK)
            {
                map_free_iter(iter);
                map_clear(&inverseCmap);
                free(charset);
                return cff_mapCffErrorToLfError(cffErr);
            }

            charset[index++] = nextNonStdSID++;
        }
        else
        {
            if (unicode == 0)
            {
                // unencoded glyph

                BYTE gidstr[10];
                gidstr[0] = 'g';
                gidstr[1] = 'i';
                gidstr[2] = 'd';

                sprintf((char*)&gidstr[3], "%05u", index);
                item.data = gidstr;                             //lint !e733
                item.length = 8;
            }
            else
            {
                BYTE unistr[10];
                unistr[0] = 'u';
                unistr[1] = 'n';
                unistr[2] = 'i';

                sprintf((char*)&unistr[3], "%04x", unicode);
                item.data = unistr;                             //lint !e733
                item.length = 7;
            }

            cffErr = cff_indexAppendCopy(stringIndex, &item);
            if (cffErr != CFF_ERR_OK)
            {
                map_free_iter(iter);
                map_clear(&inverseCmap);
                free(charset);
                return cff_mapCffErrorToLfError(cffErr);
            }

            charset[index++] = nextNonStdSID++;
        }

        node = map_next(iter);
    }

    map_free_iter(iter);
    map_clear(&inverseCmap);

    cffErr = cff_encodeCharset(charset, numGlyphsInFont, charsetBuf, charsetLen);

    free(charset);

    return cff_mapCffErrorToLfError(cffErr);
}

static LONG getBias(int totalSubroutines)
{
    if (totalSubroutines < 1240)
        return 107;
    else if (totalSubroutines < 33900)
        return 1131;
    else
        return 32768;
}

static CFF_ERROR createCompositeCharstring(LF_VECTOR* compVec, const CSInfo* infoArray, LONG bias, const ADVANCEDELTA*  advanceDelta,
                                           BYTE* charStringBuf, LONG spaceAvailable, LONG* charStringBufLen)
{
    // Create a charstring of a composite glyph. The charstring calls the
    // subroutine(s) for each of the components. A moveto is inserted prior
    // to each of the subroutine calls. The movetos are deltas between the
    // endpoints (same as start points since they are always closed) of each
    // contour and the next contour.
    // Function assumes that the arguments are offsets (not points).

    *charStringBufLen = 0;

    LF_STREAM csStream;
    STREAM_initMemStream(&csStream, charStringBuf, spaceAvailable);

    // insert advance offset
    if (advanceDelta->equalsDefaultWidth == FALSE)
        STREAM_writeCffIntegerOperand(&csStream, advanceDelta->delta);

    int prevContourEndX = 0, prevContourEndY = 0;
    int prevComponentXOffset = 0, prevComponentYOffset = 0;

    // loop over the components
    for (size_t i = 0; i < compVec->count; i++)
    {
        composite_glyf* cg = (composite_glyf*)vector_at(compVec, i);

        subrInfo* curInfo = infoArray[cg->glyphIndex].info;

        boolean firstContourOfComp = TRUE;

        while (curInfo != NULL)
        {
            int dx, dy;

            if (firstContourOfComp)
            {
                dx = (cg->argument1 + curInfo->startx) - prevContourEndX;
                dx -= prevComponentXOffset;
                dy = (cg->argument2 + curInfo->starty) - prevContourEndY;
                dy -= prevComponentYOffset;
            }
            else
            {
                dx = curInfo->startx - prevContourEndX;
                dy = curInfo->starty - prevContourEndY;
            }

            STREAM_writeCffIntegerOperand(&csStream, dx);
            STREAM_writeCffIntegerOperand(&csStream, dy);
            STREAM_writeByte(&csStream, 21);                                        // rmoveto

            STREAM_writeCffIntegerOperand(&csStream, curInfo->subrIndex - bias);    // biased subroutine index
            STREAM_writeByte(&csStream, 29);                                        // call gsubr operator

            prevContourEndX = curInfo->startx;
            prevContourEndY = curInfo->starty;

            curInfo = curInfo->next;
            firstContourOfComp = FALSE;
        }

        prevComponentXOffset = cg->argument1;
        prevComponentYOffset = cg->argument2;
    }

    STREAM_writeByte(&csStream, 14); // endchar

    if (!STREAM_isValid(csStream))
        return CFF_ERR_CS_BUF_EXCEEDED;     // an indication that the available space was not enough

    *charStringBufLen = (LONG)STREAM_streamPos(&csStream);

    return CFF_ERR_OK;
}

// The Cff spec allows a stack depth of 48. If we allow 4 curvetos in one go,
// that is 6*4 + 1 = 25 items, which is well below the limit.
// combining mutiple cubics with one opcode saves some space
#define MAX_SEQUENTIAL_CURVETOS 4

static CFF_ERROR createCharstring(const ADVANCEDELTA*  advanceDelta, Glyph* glyph, BYTE* charStringBuf, LONG spaceAvailable, LONG* charStringBufLen)
{
    *charStringBufLen = 0;

    if (glyph->glyphOutline.numberOfComponents != 1)
        return CFF_ERR_INTERNAL; // should not ever get composites

    Simple_Outline* so = &glyph->glyphOutline.component.outline;

    if (so->types[0] != MOVE_TO)
        return CFF_ERR_INTERNAL;  // first point must be a moveto

    LF_STREAM csStream;
    STREAM_initMemStream(&csStream, charStringBuf, spaceAvailable);

    // insert advance offset
    if (advanceDelta->equalsDefaultWidth == FALSE)
        STREAM_writeCffIntegerOperand(&csStream, advanceDelta->delta);

    SHORT loopstartx = 0, loopstarty = 0;
    int i = 0;

    int numSequentialCurveTos = 0;

    BYTE* tempCurveToBuf = (BYTE*)malloc(256);
    if (tempCurveToBuf == NULL)
        return CFF_ERR_MEMORY;

    LF_STREAM curvetoStream;
    STREAM_initMemStream(&curvetoStream, tempCurveToBuf, 256);

    while (i < so->np)
    {
        SHORT curx, cury, prevx, prevy;

        if (so->types[i] == MOVE_TO)    // first point of a contour
        {
            if (numSequentialCurveTos)
            {
                STREAM_writeChunk(&csStream, curvetoStream.Base, STREAM_streamPos(&curvetoStream));
                STREAM_writeByte(&csStream, 8);     // rrcurveto
                numSequentialCurveTos = 0;
                STREAM_streamSeek(&curvetoStream, 0);
            }

            curx = (i == 0) ? (SHORT)so->x[i] : (SHORT)so->x[i] - (SHORT)so->x[i - 1];
            cury = (i == 0) ? (SHORT)so->y[i] : (SHORT)so->y[i] - (SHORT)so->y[i - 1];

            if (curx == 0)
            {
                STREAM_writeCffIntegerOperand(&csStream, cury); // dy for vmoveto
                STREAM_writeByte(&csStream, 4);                 // vmoveto
            }
            else if (cury == 0)
            {
                STREAM_writeCffIntegerOperand(&csStream, curx); // dx for hmoveto
                STREAM_writeByte(&csStream, 22);                // hmoveto
            }
            else
            {
                STREAM_writeCffIntegerOperand(&csStream, curx); // dx for rmoveto
                STREAM_writeCffIntegerOperand(&csStream, cury); // dy for rmoveto
                STREAM_writeByte(&csStream, 21);                // rmoveto
            }

            loopstartx = (SHORT)so->x[i];
            loopstarty = (SHORT)so->y[i];

            i++;
        }
        else if ((so->types[i] == LINE_TO) || (so->types[i] == ON_CURVE))   // on curve
        {
            if (numSequentialCurveTos)
            {
                STREAM_writeChunk(&csStream, curvetoStream.Base, STREAM_streamPos(&curvetoStream));
                STREAM_writeByte(&csStream, 8);     // rrcurveto
                numSequentialCurveTos = 0;
                STREAM_streamSeek(&curvetoStream, 0);
            }

            ASSERT(so->types[i - 1] != OFF_CURVE);

            prevx = (SHORT)so->x[i - 1];
            prevy = (SHORT)so->y[i - 1];
            curx = (SHORT)so->x[i];
            cury = (SHORT)so->y[i];

            if (curx == prevx)
            {
                STREAM_writeCffIntegerOperand(&csStream, cury - prevy);
                STREAM_writeByte(&csStream, 7);  // vlineto
            }
            else if (cury == prevy)
            {
                STREAM_writeCffIntegerOperand(&csStream, curx - prevx);
                STREAM_writeByte(&csStream, 6);  // hlineto
            }
            else
            {
                STREAM_writeCffIntegerOperand(&csStream, curx - prevx);
                STREAM_writeCffIntegerOperand(&csStream, cury - prevy);
                STREAM_writeByte(&csStream, 5);  // rlineto
            }

            i++;
        }
        else // off curve
        {
            ASSERT(i < so->np - 1);
            ASSERT((so->types[i - 1] != OFF_CURVE) && (so->types[i + 1] == OFF_CURVE));

            if (numSequentialCurveTos == MAX_SEQUENTIAL_CURVETOS)
            {
                STREAM_writeChunk(&csStream, curvetoStream.Base, STREAM_streamPos(&curvetoStream));
                STREAM_writeByte(&csStream, 8);     // rrcurveto
                numSequentialCurveTos = 0;
                STREAM_streamSeek(&curvetoStream, 0);
            }

            prevx = (SHORT)so->x[i - 1];
            prevy = (SHORT)so->y[i - 1];
            curx = (SHORT)so->x[i];
            cury = (SHORT)so->y[i];

            SHORT nextx = (SHORT)so->x[i + 1];
            SHORT nexty = (SHORT)so->y[i + 1];
            SHORT nextnextx = (so->types[i + 2] == MOVE_TO) ? loopstartx : (SHORT)so->x[i + 2];
            SHORT nextnexty = (so->types[i + 2] == MOVE_TO) ? loopstarty : (SHORT)so->y[i + 2];

            STREAM_writeCffIntegerOperand(&curvetoStream, curx - prevx);
            STREAM_writeCffIntegerOperand(&curvetoStream, cury - prevy);
            STREAM_writeCffIntegerOperand(&curvetoStream, nextx - curx);
            STREAM_writeCffIntegerOperand(&curvetoStream, nexty - cury);
            STREAM_writeCffIntegerOperand(&curvetoStream, nextnextx - nextx);
            STREAM_writeCffIntegerOperand(&curvetoStream, nextnexty - nexty);

            numSequentialCurveTos++;

            i += 3;
        }
    }

    if (numSequentialCurveTos)
    {
        STREAM_writeChunk(&csStream, curvetoStream.Base, STREAM_streamPos(&curvetoStream));
        STREAM_writeByte(&csStream, 8);     // rrcurveto
    }

    STREAM_writeByte(&csStream, 14); // endchar

    free(tempCurveToBuf);

    if (!STREAM_isValid(csStream))
        return CFF_ERR_CS_BUF_EXCEEDED; // an indication that the available space was not enough

    *charStringBufLen = (LONG)STREAM_streamPos(&csStream);

    return CFF_ERR_OK;
}

static CFF_ERROR createSubroutinizedCharstring(const ADVANCEDELTA*  advanceDelta, Glyph* glyph, CSInfo* infoArray,
                                               LONG bias, cffIndex* subrIndex,
                                               BYTE* charStringBuf, LONG spaceAvailable, LONG* charStringBufLen,
                                               BYTE* gsubrStringBuf, LONG gsubrBufSize)
{
    *charStringBufLen = 0;

    if (glyph->glyphOutline.numberOfComponents != 1)
        return CFF_ERR_INTERNAL; // should not ever get composites

    Simple_Outline* so = &glyph->glyphOutline.component.outline;

    if (so->types[0] != MOVE_TO)
        return CFF_ERR_INTERNAL;  // first point must be a moveto

    LF_STREAM csStream;
    STREAM_initMemStream(&csStream, charStringBuf, spaceAvailable);

    LF_STREAM subrStream;
    STREAM_initMemStream(&subrStream, gsubrStringBuf, gsubrBufSize);

    int numSequentialCurveTos = 0;

    BYTE* tempCurveToBuf = (BYTE*)malloc(256);
    if (tempCurveToBuf == NULL)
        return CFF_ERR_MEMORY;

    LF_STREAM curvetoStream;
    STREAM_initMemStream(&curvetoStream, tempCurveToBuf, 256);

    // insert advance offset
    if (advanceDelta->equalsDefaultWidth == FALSE)
        STREAM_writeCffIntegerOperand(&csStream, advanceDelta->delta);

    cffIndexItem gsubrItem;

    // each contour will become a subroutine.
    ULONG countOfSubroutines = cff_indexGetCount(subrIndex);
    ULONG initialCountOfSubroutines = countOfSubroutines;

    (void)infoArray;
    //TODO - the indexes of subroutines found in the array should match the indexes which are actually being inserted

    SHORT loopstartx = 0, loopstarty = 0;
    int i = 0;

    while (i < so->np)
    {
        SHORT curx, cury, prevx, prevy;

        if (so->types[i] == MOVE_TO)            // first point of a contour
        {
            if (numSequentialCurveTos)
            {
                STREAM_writeChunk(&subrStream, curvetoStream.Base, STREAM_streamPos(&curvetoStream));
                STREAM_writeByte(&subrStream, 8);     // rrcurveto
                numSequentialCurveTos = 0;
                STREAM_streamSeek(&curvetoStream, 0);
            }

            if (i == 0)
            {
                if ((LONG)so->x[i] == 0)
                {
                    STREAM_writeCffIntegerOperand(&csStream, (LONG)so->y[i]);   // dy for vmoveto
                    STREAM_writeByte(&csStream, 4);                             // vmoveto
                }
                else if ((LONG)so->y[i] == 0)
                {
                    STREAM_writeCffIntegerOperand(&csStream, (LONG)so->x[i]);   // dx for hmoveto
                    STREAM_writeByte(&csStream, 22);                            // hmoveto
                }
                else
                {
                    STREAM_writeCffIntegerOperand(&csStream, (LONG)so->x[i]);   // dx for rmoveto
                    STREAM_writeCffIntegerOperand(&csStream, (LONG)so->y[i]);   // dy for rmoveto
                    STREAM_writeByte(&csStream, 21);                            // rmoveto
                }
            }
            else
            {
                STREAM_writeCffIntegerOperand(&csStream, countOfSubroutines - bias); // index of subroutine
                STREAM_writeByte(&csStream, 29); // call gsubr operator

                // finish the subroutine, initialize next
                countOfSubroutines++;

                STREAM_writeByte(&subrStream, 11); // return

                if (!STREAM_isValid(subrStream))
                {
                    // An indication that the available space in the buffer for subroutines was not enough.
                    // Try to recover by removing any items that were added to the subroutine index. Caller
                    // will reallocate and try again.
                    for (int k = countOfSubroutines - 1; k >= (int)initialCountOfSubroutines; k--)
                        cff_indexRemoveItem(subrIndex, k);

                    free(tempCurveToBuf);

                    return CFF_ERR_SUBR_BUF_EXCEEDED;
                }

                // Add to global subroutine index
                gsubrItem.data = gsubrStringBuf;
                gsubrItem.length = (ULONG)STREAM_streamPos(&subrStream);

                CFF_ERROR cffErr = cff_indexAppendCopy(subrIndex, &gsubrItem);
                if (cffErr != CFF_ERR_OK)
                {
                    free(tempCurveToBuf);
                    return cffErr;
                }

                STREAM_initMemStream(&subrStream, gsubrStringBuf, gsubrBufSize);

                STREAM_writeCffIntegerOperand(&csStream, (SHORT)so->x[i] - (SHORT)so->x[i - 1]);    // dx for rmoveto
                STREAM_writeCffIntegerOperand(&csStream, (SHORT)so->y[i] - (SHORT)so->y[i - 1]);    // dy for rmoveto
                STREAM_writeByte(&csStream, 21);                                                    // rmoveto
            }

            loopstartx = (SHORT)so->x[i];
            loopstarty = (SHORT)so->y[i];

            i++;
        }
        else if ((so->types[i] == LINE_TO) || (so->types[i] == ON_CURVE))   // on curve
        {
            ASSERT(so->types[i - 1] != OFF_CURVE);

            if (numSequentialCurveTos)
            {
                STREAM_writeChunk(&subrStream, curvetoStream.Base, STREAM_streamPos(&curvetoStream));
                STREAM_writeByte(&subrStream, 8);     // rrcurveto
                numSequentialCurveTos = 0;
                STREAM_streamSeek(&curvetoStream, 0);
            }

            prevx = (SHORT)so->x[i - 1];
            prevy = (SHORT)so->y[i - 1];
            curx = (SHORT)so->x[i];
            cury = (SHORT)so->y[i];

            if (curx == prevx)
            {
                STREAM_writeCffIntegerOperand(&subrStream, cury - prevy);
                STREAM_writeByte(&subrStream, 7);  // vlineto
            }
            else if (cury == prevy)
            {
                STREAM_writeCffIntegerOperand(&subrStream, curx - prevx);
                STREAM_writeByte(&subrStream, 6);  // hlineto
            }
            else
            {
                STREAM_writeCffIntegerOperand(&subrStream, curx - prevx);
                STREAM_writeCffIntegerOperand(&subrStream, cury - prevy);
                STREAM_writeByte(&subrStream, 5);  // rlineto
            }

            i++;
        }
        else    // off curve
        {
            ASSERT(i < so->np - 1);
            ASSERT((so->types[i - 1] != OFF_CURVE) && (so->types[i + 1] == OFF_CURVE));

            if (numSequentialCurveTos == MAX_SEQUENTIAL_CURVETOS)
            {
                STREAM_writeChunk(&subrStream, curvetoStream.Base, STREAM_streamPos(&curvetoStream));
                STREAM_writeByte(&subrStream, 8);     // rrcurveto
                numSequentialCurveTos = 0;
                STREAM_streamSeek(&curvetoStream, 0);
            }

            prevx = (SHORT)so->x[i - 1];
            prevy = (SHORT)so->y[i - 1];
            curx = (SHORT)so->x[i];
            cury = (SHORT)so->y[i];

            SHORT nextx = (SHORT)so->x[i + 1];
            SHORT nexty = (SHORT)so->y[i + 1];
            SHORT nextnextx = (so->types[i + 2] == MOVE_TO) ? loopstartx : (SHORT)so->x[i + 2];
            SHORT nextnexty = (so->types[i + 2] == MOVE_TO) ? loopstarty : (SHORT)so->y[i + 2];

            STREAM_writeCffIntegerOperand(&curvetoStream, curx - prevx);
            STREAM_writeCffIntegerOperand(&curvetoStream, cury - prevy);
            STREAM_writeCffIntegerOperand(&curvetoStream, nextx - curx);
            STREAM_writeCffIntegerOperand(&curvetoStream, nexty - cury);
            STREAM_writeCffIntegerOperand(&curvetoStream, nextnextx - nextx);
            STREAM_writeCffIntegerOperand(&curvetoStream, nextnexty - nexty);

            numSequentialCurveTos++;

            i += 3;
        }
    }

    if (numSequentialCurveTos)
    {
        STREAM_writeChunk(&subrStream, curvetoStream.Base, STREAM_streamPos(&curvetoStream));
        STREAM_writeByte(&subrStream, 8);     // rrcurveto
    }

    // finish charstring
    STREAM_writeCffIntegerOperand(&csStream, countOfSubroutines - bias); // biased index
    STREAM_writeByte(&csStream, 29); // call gsubr operator
    STREAM_writeByte(&csStream, 14); // endchar

    free(tempCurveToBuf);

    if (!STREAM_isValid(csStream))
    {
        // An indication that the available space was not enough
        for (int k = countOfSubroutines-1; k >= (int)initialCountOfSubroutines; k--)
            cff_indexRemoveItem(subrIndex, k);

        return CFF_ERR_CS_BUF_EXCEEDED;
    }

    // Finish last subroutine.
    STREAM_writeByte(&subrStream, 11); // return

    if (!STREAM_isValid(subrStream))
    {
        // An indication that the available space was not enough.
        for (int k = countOfSubroutines-1; k >= (int)initialCountOfSubroutines; k--)
            cff_indexRemoveItem(subrIndex, k);

        return CFF_ERR_SUBR_BUF_EXCEEDED;
    }

    gsubrItem.data = gsubrStringBuf;
    gsubrItem.length = (ULONG)STREAM_streamPos(&subrStream);

    CFF_ERROR cffErr = cff_indexAppendCopy(subrIndex, &gsubrItem);
    if (cffErr != CFF_ERR_OK)
        return cffErr;

    *charStringBufLen = (LONG)STREAM_streamPos(&csStream);

    return CFF_ERR_OK;
}

//#define USE_MEAN

static LF_ERROR calculateWidths(LF_FONT* lfFont, LONG* defaultWidth, LONG* nominalWidth)
{
    *nominalWidth = 0;
    *defaultWidth = 0;

    USHORT i, numGlyphs = HMTX_getNumHMetrics(lfFont);
    USHORT maxAdv = HMTX_getAdvanceWidthMax(lfFont);
#ifdef USE_MEAN
    ULONG total = 0;
#endif

    USHORT* histo = (USHORT*)calloc(maxAdv + 1, sizeof(USHORT));
    if (histo == NULL)
        return LF_OUT_OF_MEMORY;

    for (i = 0; i < numGlyphs; i++)
    {
        USHORT adv = HMTX_getAdvanceWidth(lfFont, i);

        histo[adv]++;

#ifdef USE_MEAN
        total += adv;
#endif
    }

    USHORT mostCommonAdv = 0;
    USHORT max = 0;

    for (i = 0; i <= maxAdv; i++)
    {
        if (histo[i] > max)
        {
            max = histo[i];
            mostCommonAdv = i;
        }
    }

    *defaultWidth = mostCommonAdv;

#ifdef USE_MEAN
    // mean
    *nominalWidth = total / numGlyphs;
#else
    // median
    USHORT halfOfGlyphs = numGlyphs / 2;
    USHORT totalSoFar = 0;
    for (i = 0; i <= maxAdv; i++)
    {
        totalSoFar += histo[i];
        if (totalSoFar >= halfOfGlyphs)
            break;
    }

    *nominalWidth = i;
#endif

    free(histo);

    return LF_ERROR_OK;
}

static boolean hasAsian(LF_FONT* lfFont)
{
    // Use the OS/2 table to see if the font has Asian glyphs.
    // A more accurate way would be to check the corresponding unicodes
    // for the remaining glyphs, or have the subset process update the OS/2
    // table to match the content of the remaining glyphs.

    ULONG range1, range2, range3, range4;
    LF_ERROR error = OS2_getUnicodeRange(lfFont, &range1, &range2, &range3, &range4);
    if (error != LF_ERROR_OK)
    {
        DEBUG_LOG_ERROR("OS2_getUnicodeRange failed.");
        return FALSE;
    }

    // return true if any of bits 48 - 56, 59, 61 are set
    // 0010 1001 1111 1111 0000 0000 0000 0000
    int mask = 0x29FF0000;

    if ((range2 & mask) != 0)
        return TRUE;

    return FALSE;
}

LF_ERROR getPostInfo(const LF_FONT* lfFont, LONG* underlinePosition, LONG* underlineThickness, boolean *isFixedPitch, double* italicAngle)
{
    post_table* pt = (post_table*)map_at(&lfFont->table_map, (void*)TAG_POST);
    if (pt == NULL)
        return LF_TABLE_MISSING;

    *underlinePosition = (LONG)pt->underlinePosition;
    *underlineThickness = (LONG)pt->underlineThickness;
    *isFixedPitch = (pt->isFixedPitch == 0) ? FALSE : TRUE;
    *italicAngle = FIXED_TO_DOUBLE(pt->italicAngle);

    return LF_ERROR_OK;
}

static void cleanupInfoArray(CSInfo* infoArray, LONG count)
{
    for (long i = 0; i < count; i++)
    {
        CSInfo* csi = infoArray + i;

        subrInfo* info = csi->info;

        while (info != NULL)
        {
            subrInfo* next = info->next;
            free(info);
            info = next;
        }
    }

    free(infoArray);
}


//
// public functions
//


LF_ERROR conversion_allocateGlyphOutline(int numPoints, int numContours, Simple_Outline* outl)
{
    outl->x = (float *)malloc(numPoints * sizeof(float));
    if (outl->x == NULL)
        return LF_OUT_OF_MEMORY;

    outl->y = (float *)malloc(numPoints * sizeof(float));
    if (outl->y == NULL)
    {
        free(outl->x);
        outl->x = NULL;
        return LF_OUT_OF_MEMORY;
    }

    outl->types = (Point_Type *)malloc(numPoints * sizeof(Point_Type));
    if (outl->types == NULL)
    {
        free(outl->x);
        outl->x = NULL;
        free(outl->y);
        outl->y = NULL;
        return LF_OUT_OF_MEMORY;
    }

    outl->endPtsOfContours = (USHORT *)malloc(numContours * sizeof(USHORT));
    if (outl->endPtsOfContours == NULL)
    {
        free(outl->types);
        outl->types = NULL;
        free(outl->x);
        outl->x = NULL;
        free(outl->y);
        outl->y = NULL;
        return LF_OUT_OF_MEMORY;
    }

    return LF_ERROR_OK;
}

void conversion_freeGlyphOutline(Glyph *glyph)
{
    if (glyph)
    {
        if (glyph->glyphOutline.numberOfComponents > 1)
        {
            Glyph_Component* cur = glyph->glyphOutline.component.next;

            while (cur != NULL)
            {
                Glyph_Component* next = cur->next;
                free(cur);
                cur = next;
            };
        }

        Simple_Outline* so = &glyph->glyphOutline.component.outline;

        free(so->endPtsOfContours);
        free(so->x);
        free(so->y);
        free(so->types);
    }
}

LF_ERROR conversion_populateGLYFTable(LF_FONT *lfFont, float tolerance, USHORT outputUnitsPerEm)
{
    // at this point the font will have both a cff and an (empty) glyf table

    cff_table* cffTable = (cff_table*)map_at(&lfFont->table_map, (void*)TAG_CFF);
    if (cffTable == NULL)
        return LF_TABLE_MISSING;

    glyf_table* glyfTable = (glyf_table*)map_at(&lfFont->table_map, (void*)(long)TAG_GLYF);
    if (glyfTable == NULL)
        return LF_TABLE_MISSING;

    Glyph* tempGlyphDataBlock = (Glyph*)calloc(map_size(cffTable->charStringMap), sizeof(Glyph));
    if (tempGlyphDataBlock == NULL)
        return LF_OUT_OF_MEMORY;

    LF_MAP* tempGlyphMap = map_create(integer_compare);
    if (tempGlyphMap == NULL)
    {
        free(tempGlyphDataBlock);
        return LF_OUT_OF_MEMORY;
    }

    // Fill in the Glyphs in the temp block
    LF_ERROR  error = conversion_convertCharstringsToGlyphs(cffTable, tempGlyphMap, tempGlyphDataBlock);

    if (error == LF_ERROR_OK)
    {
        // Get the design units from the head table
        USHORT origUPM = HEAD_getUnitsPerEM(lfFont);
        if (origUPM != 0)
        {
            // Convert to TTF format
            error = convertGlyphsToGlyfs(tempGlyphMap, origUPM, outputUnitsPerEm, tolerance, glyfTable);
        }
        else
            error = LF_TABLE_MISSING;
    }

    // Cleanup temp things
    LF_MAP_ITER* mapIter = map_begin(tempGlyphMap);
    if (mapIter != NULL)
    {
        rb_tree_node* node = map_next(mapIter);

        while (node)
        {
            conversion_freeGlyphOutline((Glyph*)node->data);
            node = map_next(mapIter);
        }

        map_free_iter(mapIter);
    }
    free(tempGlyphDataBlock);
    map_clear(tempGlyphMap);
    free(tempGlyphMap);

    return error;
}

LF_ERROR conversion_populatePOSTTable(const LF_FONT *lfFont)
{
    // Add names to the post table using the names from the string index
    // or the standard name.

    // get cff table
    cff_table* cffTable = (cff_table*)map_at(&lfFont->table_map, (void*)TAG_CFF);
    if (cffTable == NULL)
        return LF_TABLE_MISSING;

    if (cffTable->cffTable->isCID == TRUE)
        return LF_ERROR_OK;                     // we can not produce the names

    // get post table
    post_table* postTable = (post_table*)map_at(&lfFont->table_map, (void*)TAG_POST);
    if (postTable == NULL)
        return LF_TABLE_MISSING;

    ULONG numGlyphs = (ULONG)map_size(cffTable->charStringMap);

    LF_ERROR error = vector_init(&postTable->glyphNameIndex, numGlyphs, 4);
    if (LF_ERROR_OK != error)
        return LF_OUT_OF_MEMORY;

    error = vector_init(&postTable->names, numGlyphs, 4);
    if (LF_ERROR_OK != error)
        return LF_OUT_OF_MEMORY;

    LF_MAP_ITER* iter = map_begin(cffTable->charStringMap);
    if (iter == NULL)
        return LF_OUT_OF_MEMORY;

    rb_tree_node* node = map_next(iter);

    USHORT gIndex = 0;
    char* name;
    size_t len;

    while (node != NULL)
    {
        error = vector_push_back(&postTable->glyphNameIndex, (void*)(intptr_t)(gIndex + 258));
        if (error != LF_ERROR_OK)
        {
            map_free_iter(iter);
            return error;
        }

        cffAnalyzedCharstring* acs = (cffAnalyzedCharstring*)node->data;

        cffSID sid = acs->sid;

        if (sid < NUM_STD_STRINGS)
        {
            len = strlen(ISOAdobeNAME[sid]);

            name = (char*)malloc(len + 1);
            if (name == NULL)
            {
                map_free_iter(iter);
                return LF_OUT_OF_MEMORY;
            }

            strcpy(name, ISOAdobeNAME[sid]);
        }
        else
        {
            cffIndexItem* ii = cff_indexGetItem(cffTable->cffTable->stringIndex, sid - NUM_STD_STRINGS);

            len = ii->length;
            name = (char*)calloc(len + 1, sizeof(char));
            if (name == NULL)
            {
                map_free_iter(iter);
                return LF_OUT_OF_MEMORY;
            }

            strncpy(name, (char*)ii->data, len);
        }

        error = vector_push_back(&postTable->names, (void*)name);
        if (error != LF_ERROR_OK)
        {
            map_free_iter(iter);
            return error;
        }

        gIndex++;

        node = map_next(iter);
    }

    map_free_iter(iter);

    postTable->Version = 0x00020000;
    postTable->namesParsed = TRUE;
    postTable->subsetted = TRUE;
    return LF_ERROR_OK;
}

static LF_ERROR getSubroutineInfo(USHORT numGlyphs, glyf_table* glyfTable, CSInfo* charStrInfoArray, LONG* numSubroutines)
{
    LF_ERROR error = LF_ERROR_OK;
    LONG i, nextSubroutineIndex = 0;
    CSInfo* infoArray = charStrInfoArray;       // Assigning to a local is done to silence a Klocwork error.
                                                // The array at charStrInfoArray will not be accessed past numGlyphs.

    LF_VECTOR* points = vector_create(128, 64); // each point consumes 4 entries, so this starts with space for 32 points and grows by 16
    if (points == NULL)
        return LF_OUT_OF_MEMORY;

    // Go through all the glyphs, for the ones that are going to be turned into subroutines
    // get the starting points of each of the contours, and assign the subroutine indexes
    for (i = 0; i < numGlyphs; i++)
    {
        if (infoArray[i].type == eCSSubroutinized)
        {
            glyf curGlyf;

            error = GLYF_getGlyf(glyfTable, i, &curGlyf);
            if (error != LF_ERROR_OK)
                return error;

            if (curGlyf.numberOfContours == -1) // should not have a composite here
            {
                GLYF_destroyGlyf(&curGlyf);
                return LF_BAD_FORMAT; // internal error
            }

            // Get the points for the glyph
            error = GLYF_getGlyfPointsInternal(glyfTable, &curGlyf, points);
            if (error != LF_ERROR_OK)
            {
                vector_free(points);
                free(points);
                GLYF_destroyGlyf(&curGlyf);
                return error;
            }

            subrInfo* curInfo = NULL;

            for (int k = 0; k < curGlyf.numberOfContours; k++)
            {
                boolean firstPointIsOffCurve = FALSE;
                boolean secondPointIsOffCurve = FALSE;

                if (k == 0)
                {
                    curInfo = infoArray[i].info = (subrInfo*)calloc(1, sizeof(subrInfo));
                }
                else
                {
                    if (curInfo == NULL)
                    {
                        GLYF_destroyGlyf(&curGlyf);
                        return LF_BAD_FORMAT;  // internal error
                    }

                    curInfo->next = (subrInfo*)calloc(1, sizeof(subrInfo));
                    curInfo = curInfo->next;
                }

                if (curInfo == NULL)
                {
                    GLYF_destroyGlyf(&curGlyf);
                    return LF_OUT_OF_MEMORY;
                }

                int startOfContourIndex = (k == 0) ? 0 : curGlyf.glyf_data.simple.endPtsOfContours[k - 1] + 1;

                curInfo->subrIndex = nextSubroutineIndex++;
                curInfo->startx = (int)(intptr_t)vector_at(points, (startOfContourIndex * 4) + 1);
                curInfo->starty = (int)(intptr_t)vector_at(points, (startOfContourIndex * 4) + 2);

                int flags = (int)(intptr_t)vector_at(points, (startOfContourIndex * 4) + 0);

                if ((flags & FLAG_ON_CURVE) == 0)
                {
                    firstPointIsOffCurve = TRUE;

                    int secondFlags = (int)(intptr_t)vector_at(points, ((startOfContourIndex+1) * 4) + 0);

                    if ((secondFlags & FLAG_ON_CURVE) == 0)
                        secondPointIsOffCurve = TRUE;
                }

                if (secondPointIsOffCurve == TRUE)
                {
                    // The moveto point will be the implicit point between the first two off-curve points
                    long firstX = (long)(intptr_t)vector_at(points, (startOfContourIndex * 4) + 1);
                    long firstY = (long)(intptr_t)vector_at(points, (startOfContourIndex * 4) + 2);
                    long secndX = (long)(intptr_t)vector_at(points, ((startOfContourIndex + 1) * 4) + 1);
                    long secndY = (long)(intptr_t)vector_at(points, ((startOfContourIndex + 1) * 4) + 2);

                    curInfo->startx = (int)((firstX + secndX + 1) >> 1); //lint !e704 rounded midpoint
                    curInfo->starty = (int)((firstY + secndY + 1) >> 1); //lint !e704
                }
                else if (firstPointIsOffCurve == TRUE)
                {
                    // The moveto point will be the second point
                    curInfo->startx = (int)(intptr_t)vector_at(points, ((startOfContourIndex+1) * 4) + 1);
                    curInfo->starty = (int)(intptr_t)vector_at(points, ((startOfContourIndex+1) * 4) + 2);
                }
            }

            vector_clear(points);
            GLYF_destroyGlyf(&curGlyf);
        }
    }

    vector_free(points);
    free(points);

    *numSubroutines = nextSubroutineIndex;

    return error;
}

void conversion_computeCubicBoundingBox(Glyph* cubicGlyph)
{
    Simple_Outline *cubicOutline = &cubicGlyph->glyphOutline.component.outline;
    Glyph_Outline* go = &cubicGlyph->glyphOutline;

    go->xMax = go->yMax = -32768;
    go->xMin = go->yMin =  32768;

    int j = 0;
    while (j < cubicOutline->np)
    {
        if (cubicOutline->types[j] != OFF_CURVE)
        {
            if (cubicOutline->x[j] > go->xMax)
                go->xMax = cubicOutline->x[j];
            if (cubicOutline->x[j] < go->xMin)
                go->xMin = cubicOutline->x[j];
            if (cubicOutline->y[j] > go->yMax)
                go->yMax = cubicOutline->y[j];
            if (cubicOutline->y[j] < go->yMin)
                go->yMin = cubicOutline->y[j];

            j++;
        }
        else
        //lint -e{578} suppress symbol y0,y1 hides y0,y1(double)
        {

            float x1 = cubicOutline->x[j];
            float y1 = cubicOutline->y[j];
            float x2 = cubicOutline->x[j + 1];
            float y2 = cubicOutline->y[j + 1];
            float x3 = cubicOutline->x[j + 2];
            float y3 = cubicOutline->y[j + 2];

            ASSERT(cubicOutline->types[j] == OFF_CURVE);
            ASSERT(cubicOutline->types[j+1] == OFF_CURVE);
            ASSERT(cubicOutline->types[j+2] == ON_CURVE);

            j += 3;

            // update bounding box
            if (go->xMin > x1) go->xMin = x1;
            if (go->xMax < x1) go->xMax = x1;
            if (go->yMin > y1) go->yMin = y1;
            if (go->yMax < y1) go->yMax = y1;
            if (go->xMin > x2) go->xMin = x2;
            if (go->xMax < x2) go->xMax = x2;
            if (go->yMin > y2) go->yMin = y2;
            if (go->yMax < y2) go->yMax = y2;
            if (go->xMin > x3) go->xMin = x3;
            if (go->xMax < x3) go->xMax = x3;
            if (go->yMin > y3) go->yMin = y3;
            if (go->yMax < y3) go->yMax = y3;

        }
    }
}

LF_ERROR conversion_populateCFFTable(LF_FONT *lfFont, float tolerance, USHORT outputUnitsPerEm)
{
    // This function creates a CFF_TAB_BUILD.
    // The cff table will be a non-CID font. Strings for the name index and string index
    // are retrieved from the name table. The first few strings/SIDs are for fields of the top dict.
    // Some values are read from the POST table to populate the top dict.
    // A global subroutine is created (not local). The charstrings in it are contours
    // from glyphs which participate in composite glyphs. The charstrings
    // do not start with a moveto instruction. That is put into the charstrings
    // which call the subroutines.

    // at this point the font will have both a (possibly subsetted) glyf and an (empty) cff table

    // we get various strings from the name table, so it needs to be parsed
    LF_ERROR error = NAME_parseTable(lfFont);
    if (error != LF_ERROR_OK)
        return error;

    // Get the tables
    cff_table* cffTable = (cff_table*)map_at(&lfFont->table_map, (void*)TAG_CFF);
    if (cffTable == NULL)
        return LF_TABLE_MISSING;

    glyf_table* glyfTable = (glyf_table*)map_at(&lfFont->table_map, (void*)(long)TAG_GLYF);
    if (glyfTable == NULL)
        return LF_TABLE_MISSING;

    // Create new object
    CFF_TAB_BUILD* newCff = (CFF_TAB_BUILD*)calloc(1, sizeof(CFF_TAB_BUILD));
    if (newCff == NULL)
        return LF_OUT_OF_MEMORY;

    LONG i;
    CFF_ERROR cffErr;

    //
    // fill in the newCff
    //

    // number of glyphs
    newCff->numGlyphs = (USHORT)map_size(glyfTable->glyfMap);

    // Header
    newCff->header.major = 1;
    newCff->header.minor = 0;
    newCff->header.offSize = 4;         // offsets will always be written as 4 byte values (5 bytes to encode)
    newCff->header.hdrSize = 4;

    // Name INDEX
    cffErr = cff_indexInitializeWithSize(1, &newCff->nameIndex);
    if (cffErr != CFF_ERR_OK)
    {
        cff_destroyCFF_TAB(newCff);
        return cff_mapCffErrorToLfError(cffErr);
    }

    BYTE* tempStr;
    ULONG strLen = 0;

    error = getNameString(lfFont, NAME_POSTSCRIPT_FONT_NAME, &tempStr, &strLen);
    if (error != LF_ERROR_OK)
    {
        error = getNameString(lfFont, NAME_FONT_FULL_NAME, &tempStr, &strLen);
        if (error != LF_ERROR_OK)
        {
            cff_destroyCFF_TAB(newCff);
            return error;
        }
    }
    sanitizeNameString(tempStr, strLen);

    cffIndexItem item;
    item.data = tempStr;
    item.length = strLen;

    cffErr = cff_indexAppendCopy(newCff->nameIndex, &item);
    free(tempStr);
    if (cffErr != CFF_ERR_OK)
    {
        cff_destroyCFF_TAB(newCff);
        return cff_mapCffErrorToLfError(cffErr);
    }

    // Create empty String Index. The maximum size it could be is numGlyphs + 6 (6 for the SIDs in the topdict)
    cffErr = cff_indexInitializeWithSize(newCff->numGlyphs + 6, &newCff->stringIndex);
    if (cffErr != CFF_ERR_OK)
    {
        cff_destroyCFF_TAB(newCff);
        return cff_mapCffErrorToLfError(cffErr);
    }

    // Get the Top Dict strings. The strings go into the string index, the SIDs go into the topdict later.
    topDictSids tdSids;

    error = getStringInfo(lfFont, &tdSids, newCff->stringIndex);
    if (error != LF_ERROR_OK)
    {
        cff_destroyCFF_TAB(newCff);
        return error;
    }

    // Create a charset and fill the rest of the string index
    error = createCharset(lfFont, newCff->numGlyphs, tdSids.firstGlyphSID,
                          newCff->stringIndex, &newCff->encodedCharset, &newCff->encodedCharsetSize);
    if (error != LF_ERROR_OK)
    {
        cff_destroyCFF_TAB(newCff);
        return error;
    }

    // Determine the widths for the font
    LONG defaultWidth, nominalWidth;
    error = calculateWidths(lfFont, &defaultWidth, &nominalWidth);
    if (error != LF_ERROR_OK)
    {
        cff_destroyCFF_TAB(newCff);
        return error;
    }

    // Reindex the glyphs 0->nLeft-1 (if doing a subset) (so we can loop over them, otherwise need to use iterator)
    error = GLYF_remapTable(lfFont);
    if (error != LF_ERROR_OK)
    {
        cff_destroyCFF_TAB(newCff);
        return error;
    }

    // create an nGlyphs long array to contain info as to which type of charstring will be created for it
    CSInfo* charStrInfoArray = (CSInfo*)calloc(newCff->numGlyphs, sizeof(CSInfo));
    if (charStrInfoArray == NULL)
    {
        cff_destroyCFF_TAB(newCff);
        return LF_OUT_OF_MEMORY;
    }

    // go through all the glyphs and figure out how charstrings for them will be done.
    // they all start as eCSRegular
    for (i = 0; i < newCff->numGlyphs; i++)
    {
        glyf curGlyf;

        error = GLYF_getGlyf(glyfTable, i, &curGlyf);
        if (error != LF_ERROR_OK)
        {
            cff_destroyCFF_TAB(newCff);
            free(charStrInfoArray);
            return error;
        }

        // if it is a composite and the components are not scaled, and the
        // components are only one level deep, we can turn the components into subroutines
        if (curGlyf.numberOfContours == -1)
        {
            charStrInfoArray[i].type = eCSCompositeFlat;

            boolean canMakeSubrs = TRUE;

            for (size_t j = 0; j < curGlyf.glyf_data.composite.count; j++)
            {
                composite_glyf* cg = (composite_glyf*)vector_at(&curGlyf.glyf_data.composite, j);

                if (!((cg->xscale == 0x4000) && (cg->yscale == 0x4000) && (cg->scale01 == 0) && (cg->scale10 == 0)))
                {
                    canMakeSubrs = FALSE;
                    break;
                }

                glyf tempGlyf;

                error = GLYF_getGlyf(glyfTable, cg->glyphIndex, &tempGlyf);
                if (error != LF_ERROR_OK)
                {
                    GLYF_destroyGlyf(&curGlyf);
                    cff_destroyCFF_TAB(newCff);
                    free(charStrInfoArray);
                    return error;
                }

                if (tempGlyf.numberOfContours == -1)
                {
                    GLYF_destroyGlyf(&tempGlyf);
                    canMakeSubrs = FALSE;
                    break;
                }

                GLYF_destroyGlyf(&tempGlyf);
            }

            if (canMakeSubrs == TRUE)
            {
                // mark it as going to be made of subroutines
                charStrInfoArray[i].type = eCSCompositeSubr;

                // mark its components as going to be turned into subroutines
                for (size_t j = 0; j < curGlyf.glyf_data.composite.count; j++)
                {
                    composite_glyf* cg = (composite_glyf*)vector_at(&curGlyf.glyf_data.composite, j);

                    charStrInfoArray[cg->glyphIndex].type = eCSSubroutinized;
                }
            }
        }

        GLYF_destroyGlyf(&curGlyf);
    }

    LONG numGlobalSubroutines;

    // Go through all the glyphs, for the ones that are going to be turned into subroutines
    // get the starting points of each of the contours, and assign the subroutine indexes
    error = getSubroutineInfo(newCff->numGlyphs, glyfTable, charStrInfoArray, &numGlobalSubroutines);
    if (error != LF_ERROR_OK)
    {
        cff_destroyCFF_TAB(newCff);
        cleanupInfoArray(charStrInfoArray, newCff->numGlyphs);
        return error;
    }

    LONG subroutineBias = getBias(numGlobalSubroutines);

    // Create gsubr index
    cffErr = cff_indexInitializeWithSize(numGlobalSubroutines, &newCff->globalSubrIndex);
    if (cffErr != CFF_ERR_OK)
    {
        cleanupInfoArray(charStrInfoArray, newCff->numGlyphs);
        cff_destroyCFF_TAB(newCff);
        return cff_mapCffErrorToLfError(cffErr);
    }

    // Create charstring index
    cffErr = cff_indexInitializeWithSize(newCff->numGlyphs, &newCff->charStringsIndex);
    if (cffErr != CFF_ERR_OK)
    {
        cleanupInfoArray(charStrInfoArray, newCff->numGlyphs);
        cff_destroyCFF_TAB(newCff);
        return cff_mapCffErrorToLfError(cffErr);
    }

    // Set an initial buffer size for the charstrings, based on the max points in the font.
    // If the initial guess is insufficient, the code below will detect that and double the size
    // until it is enough. Initial values below determined experimentally with a set of 72 fonts.
    LONG initCharStringBufSize;
    USHORT maxPoints = MAXP_getMaxPoints(lfFont);

    if (maxPoints < 450)
        initCharStringBufSize = 1536;
    else if (maxPoints < 1200)
        initCharStringBufSize = 3072;
    else
        initCharStringBufSize = 5120;

    // Allocate a scratch buffer into which the charstrings for each glyph will be written.
    LONG charStringBufSize = initCharStringBufSize;
    BYTE* charStringBuf = (BYTE*)malloc(charStringBufSize*sizeof(BYTE));
    if (charStringBuf == NULL)
    {
        cleanupInfoArray(charStrInfoArray, newCff->numGlyphs);
        cff_destroyCFF_TAB(newCff);
        return cff_mapCffErrorToLfError(cffErr);
    }

    // Allocate a scratch buffer into which the charstrings for subroutines will be written.
    LONG gsubrBufSize = initCharStringBufSize;
    BYTE* gsubrStringBuf = (BYTE*)malloc(gsubrBufSize*sizeof(BYTE));
    if (gsubrStringBuf == NULL)
    {
        cleanupInfoArray(charStrInfoArray, newCff->numGlyphs);
        free(charStringBuf);
        cff_destroyCFF_TAB(newCff);
        return cff_mapCffErrorToLfError(cffErr);
    }

    // Get the design units from the head table
    USHORT origUPM = HEAD_getUnitsPerEM(lfFont);
    if (origUPM == 0)
    {
        cleanupInfoArray(charStrInfoArray, newCff->numGlyphs);
        free(charStringBuf);
        free(gsubrStringBuf);
        cff_destroyCFF_TAB(newCff);
        return LF_TABLE_MISSING;
    }

    // Init font bb (use floats to avoid conversions inside loop)
    float minX, maxX, minY, maxY;
    minX = minY = (float)MYINFINITY;
    maxX = maxY = -minX;

    float scaledTolerance = tolerance * (origUPM / 1000.0f);

    // Loop over glyphs and create charstrings / subroutines.
    for (i = 0; i < newCff->numGlyphs; i++)
    {
        glyf curGlyf;
        LONG charStringBufLen = 0;

        error = GLYF_getGlyf(glyfTable, i, &curGlyf);
        if (error != LF_ERROR_OK)
        {
            cff_destroyCFF_TAB(newCff);
            cleanupInfoArray(charStrInfoArray, newCff->numGlyphs);
            free(charStringBuf);
            free(gsubrStringBuf);
            return error;
        }

        // create empty cffAnalyzedCharString and insert into map. Needed for the bounding box.
        cffAnalyzedCharstring* acs = calloc(1, sizeof(cffAnalyzedCharstring));
        if (acs == NULL)
        {
            GLYF_destroyGlyf(&curGlyf);
            free(gsubrStringBuf);
            free(charStringBuf);
            cff_destroyCFF_TAB(newCff);
            cleanupInfoArray(charStrInfoArray, newCff->numGlyphs);
            return LF_OUT_OF_MEMORY;
        }

        map_insert(cffTable->charStringMap, (void*)(intptr_t)i, acs);

        USHORT width = HMTX_getAdvanceWidth(lfFont, i);

        ADVANCEDELTA advanceDelta;
        advanceDelta.equalsDefaultWidth = (boolean)(width == defaultWidth);
        advanceDelta.delta = width - nominalWidth;

        if (eCSCompositeSubr == charStrInfoArray[i].type)
        {
            // Create charstring which references the subroutines, with appropriate offsetting
            cffErr = createCompositeCharstring(&curGlyf.glyf_data.composite, charStrInfoArray, subroutineBias, &advanceDelta,
                                               charStringBuf, charStringBufSize, &charStringBufLen);
            if (cffErr != CFF_ERR_OK)
            {
                GLYF_destroyGlyf(&curGlyf);
                cff_destroyCFF_TAB(newCff);
                cleanupInfoArray(charStrInfoArray, newCff->numGlyphs);
                free(charStringBuf);
                free(gsubrStringBuf);
                return cff_mapCffErrorToLfError(cffErr);
            }
        }
        else
        {
            // create 'regular' charstring
            if (curGlyf.numberOfContours == 0)
            {
                cffErr = createEmptyCharstring(&advanceDelta, charStringBuf, charStringBufSize, &charStringBufLen);
                if (cffErr != CFF_ERR_OK)
                {
                    GLYF_destroyGlyf(&curGlyf);
                    cff_destroyCFF_TAB(newCff);
                    cleanupInfoArray(charStrInfoArray, newCff->numGlyphs);
                    free(charStringBuf);
                    free(gsubrStringBuf);
                    return cff_mapCffErrorToLfError(cffErr);
                }

                acs->isEmpty = TRUE;
            }
            else
            {
                // get the points for it
                LF_VECTOR* points = vector_create(128, 64); // each point consumes 4 entries, so this starts with space for 32 points and grows by 16

                // TODO have a function which counts the points? to avoid reallocs when above fills up
                // TODO or a version of getglyfpoints that allocs the array

                if (points == NULL)
                {
                    GLYF_destroyGlyf(&curGlyf);
                    cleanupInfoArray(charStrInfoArray, newCff->numGlyphs);
                    free(charStringBuf);
                    free(gsubrStringBuf);
                    cff_destroyCFF_TAB(newCff);
                    return LF_OUT_OF_MEMORY;
                }

                error = GLYF_getGlyfPointsInternal(glyfTable, &curGlyf, points);
                if (error != LF_ERROR_OK)
                {
                    vector_free(points);
                    free(points);
                    GLYF_destroyGlyf(&curGlyf);
                    cleanupInfoArray(charStrInfoArray, newCff->numGlyphs);
                    free(charStringBuf);
                    free(gsubrStringBuf);
                    cff_destroyCFF_TAB(newCff);
                    return error;
                }

                // convert the glyf to a temp (quad) Glyph
                Glyph quadGlyph;
                conversion_setGlyphOutlineParams(&quadGlyph.glyphOutline, i);

                error = conversion_addPointsToGlyphOutline(points, &quadGlyph.glyphOutline);
                if (error != LF_ERROR_OK)
                {
                    vector_free(points);
                    free(points);
                    GLYF_destroyGlyf(&curGlyf);
                    conversion_freeGlyphOutline(&quadGlyph);
                    cleanupInfoArray(charStrInfoArray, newCff->numGlyphs);
                    free(charStringBuf);
                    free(gsubrStringBuf);
                    cff_destroyCFF_TAB(newCff);
                    return error;
                }

                Glyph cubicGlyph;
                Simple_Outline *cubicOutline = &cubicGlyph.glyphOutline.component.outline;
                Simple_Outline *quadOutline = &quadGlyph.glyphOutline.component.outline;

                cubicGlyph.glyphOutline.numberOfComponents = 1;
                cubicOutline->designUnits = outputUnitsPerEm;
                quadOutline->designUnits = origUPM;

                DumpQuad(&quadGlyph.glyphOutline);

                // Convert to cubics
                Conversion_Error err = convertQuadratic(quadOutline, scaledTolerance, cubicOutline);
                if (CONVERSION_SUCCESS != err)
                {
                    vector_free(points);
                    free(points);
                    conversion_freeGlyphOutline(&quadGlyph);
                    GLYF_destroyGlyf(&curGlyf);
                    free(charStringBuf);
                    free(gsubrStringBuf);
                    cleanupInfoArray(charStrInfoArray, newCff->numGlyphs);
                    cff_destroyCFF_TAB(newCff);
                    return (err == CONVERSION_MEMORY) ? LF_OUT_OF_MEMORY : LF_CONVERSION;
                }

                checkRnd(cubicOutline, i, FALSE);

                // compute outline bounding box
                conversion_computeCubicBoundingBox(&cubicGlyph);

                // update font bb
                if (cubicGlyph.glyphOutline.xMin < minX)
                    minX = cubicGlyph.glyphOutline.xMin;
                if (cubicGlyph.glyphOutline.xMax > maxX)
                    maxX = cubicGlyph.glyphOutline.xMax;
                if (cubicGlyph.glyphOutline.yMin < minY)
                    minY = cubicGlyph.glyphOutline.yMin;
                if (cubicGlyph.glyphOutline.yMax > maxY)
                    maxY = cubicGlyph.glyphOutline.yMax;

                acs->bb.xMax = (FIXED)(cubicGlyph.glyphOutline.xMax * 65536.0f);
                acs->bb.xMin = (FIXED)(cubicGlyph.glyphOutline.xMin * 65536.0f);
                acs->bb.yMax = (FIXED)(cubicGlyph.glyphOutline.yMax * 65536.0f);
                acs->bb.yMin = (FIXED)(cubicGlyph.glyphOutline.yMin * 65536.0f);

                DumpCubic(&cubicGlyph.glyphOutline);

                if ((eCSRegular == charStrInfoArray[i].type) || (eCSCompositeFlat == charStrInfoArray[i].type))
                {
                    // create a (regular) charstring from the Glyph
                    do {
                        cffErr = createCharstring(&advanceDelta, &cubicGlyph, charStringBuf, charStringBufSize, &charStringBufLen);
                        if (cffErr == CFF_ERR_CS_BUF_EXCEEDED)
                        {
                            free(charStringBuf);
                            charStringBuf = (BYTE*)malloc(charStringBufSize * 2);
                            if (charStringBuf == NULL)
                            {
                                GLYF_destroyGlyf(&curGlyf);
                                free(gsubrStringBuf);
                                conversion_freeGlyphOutline(&quadGlyph);
                                conversion_freeGlyphOutline(&cubicGlyph);
                                cff_destroyCFF_TAB(newCff);
                                cleanupInfoArray(charStrInfoArray, newCff->numGlyphs);
                                return LF_OUT_OF_MEMORY;
                            }
                            charStringBufSize *= 2;
                        }
                        else if (cffErr != CFF_ERR_OK)
                        {
                            GLYF_destroyGlyf(&curGlyf);
                            conversion_freeGlyphOutline(&quadGlyph);
                            conversion_freeGlyphOutline(&cubicGlyph);
                            cff_destroyCFF_TAB(newCff);
                            free(gsubrStringBuf);
                            cleanupInfoArray(charStrInfoArray, newCff->numGlyphs);
                            return cff_mapCffErrorToLfError(cffErr);
                        }
                    } while (cffErr != CFF_ERR_OK);
                }
                else // (eCSSubroutinized == charStrInfoArray[i].type)
                {
                    // create subroutine(s) from the glyph and a charstring which calls the subroutine(s)
                    do {
                        cffErr = createSubroutinizedCharstring(&advanceDelta, &cubicGlyph,
                                                               charStrInfoArray, subroutineBias, newCff->globalSubrIndex,
                                                               charStringBuf, charStringBufSize, &charStringBufLen,
                                                               gsubrStringBuf, gsubrBufSize);
                        if (cffErr == CFF_ERR_CS_BUF_EXCEEDED)
                        {
                            free(charStringBuf);
                            charStringBuf = (BYTE*)malloc(charStringBufSize * 2);
                            if (charStringBuf == NULL)
                            {
                                free(gsubrStringBuf);
                                GLYF_destroyGlyf(&curGlyf);
                                conversion_freeGlyphOutline(&quadGlyph);
                                conversion_freeGlyphOutline(&cubicGlyph);
                                cff_destroyCFF_TAB(newCff);
                                cleanupInfoArray(charStrInfoArray, newCff->numGlyphs);
                                return LF_OUT_OF_MEMORY;
                            }
                            charStringBufSize *= 2;
                        }
                        else if (cffErr == CFF_ERR_SUBR_BUF_EXCEEDED)
                        {
                            free(gsubrStringBuf);
                            gsubrStringBuf = (BYTE*)malloc(gsubrBufSize * 2);
                            if (gsubrStringBuf == NULL)
                            {
                                free(charStringBuf);
                                GLYF_destroyGlyf(&curGlyf);
                                conversion_freeGlyphOutline(&quadGlyph);
                                conversion_freeGlyphOutline(&cubicGlyph);
                                cff_destroyCFF_TAB(newCff);
                                cleanupInfoArray(charStrInfoArray, newCff->numGlyphs);
                                return LF_OUT_OF_MEMORY;
                            }
                            gsubrBufSize *= 2;
                        }
                        else if (cffErr != CFF_ERR_OK)
                        {
                            free(gsubrStringBuf);
                            GLYF_destroyGlyf(&curGlyf);
                            conversion_freeGlyphOutline(&quadGlyph);
                            conversion_freeGlyphOutline(&cubicGlyph);
                            cff_destroyCFF_TAB(newCff);
                            cleanupInfoArray(charStrInfoArray, newCff->numGlyphs);
                            return cff_mapCffErrorToLfError(cffErr);
                        }
                    } while (cffErr != CFF_ERR_OK);
                }

                conversion_freeGlyphOutline(&quadGlyph);
                conversion_freeGlyphOutline(&cubicGlyph);
                vector_free(points);
                free(points);
            }
        }

        // Add the glyph's charstring to the charstring index
        cffIndexItem charStringItem;
        charStringItem.data = charStringBuf;
        charStringItem.length = charStringBufLen;

        cffErr = cff_indexAppendCopy(newCff->charStringsIndex, &charStringItem);

        GLYF_destroyGlyf(&curGlyf);

        if (cffErr != CFF_ERR_OK)
        {
            cff_destroyCFF_TAB(newCff);
            free(gsubrStringBuf);
            cleanupInfoArray(charStrInfoArray, newCff->numGlyphs);
            return cff_mapCffErrorToLfError(cffErr);
        }
    }

    // Loop over glyphs and compute the bounding boxes for the composites
    for (i = 0; i < newCff->numGlyphs; i++)
    {
        if (eCSCompositeSubr == charStrInfoArray[i].type)
        {
            glyf curGlyf;

            cffAnalyzedCharstring* acs = (cffAnalyzedCharstring*)map_at(cffTable->charStringMap, (void*)(intptr_t)i);

            cffBoundingBox* fixedBB = &acs->bb;
            fixedBB->xMin = fixedBB->yMin = MYINFINITY;
            fixedBB->xMax = fixedBB->yMax = -fixedBB->xMin;

            error = GLYF_getGlyf(glyfTable, i, &curGlyf);
            if (error != LF_ERROR_OK)
            {
                cff_destroyCFF_TAB(newCff);
                cleanupInfoArray(charStrInfoArray, newCff->numGlyphs);
                free(charStringBuf);
                free(gsubrStringBuf);
                return error;
            }

            ASSERT(curGlyf.numberOfContours == -1);

            LF_VECTOR* compVec = &curGlyf.glyf_data.composite;

            // loop over the components
            for (size_t j = 0; j < compVec->count; j++)
            {
                composite_glyf* cg = (composite_glyf*)vector_at(compVec, j);

                // get the bounding box for the component
                cffAnalyzedCharstring* acsComp = (cffAnalyzedCharstring*)map_at(cffTable->charStringMap, (void*)(intptr_t)cg->glyphIndex);

                cffBoundingBox fixedComponentBB = acsComp->bb;

                // offset it
                if ((cg->flags & ARGS_ARE_XY_VALUES) != 0)
                {
                    float offsetMinX = (fixedComponentBB.xMin / 65536.0f) + cg->argument1;
                    float offsetMaxX = (fixedComponentBB.xMax / 65536.0f) + cg->argument1;
                    float offsetMinY = (fixedComponentBB.yMin / 65536.0f) + cg->argument2;
                    float offsetMaxY = (fixedComponentBB.yMax / 65536.0f) + cg->argument2;

                    FIXED fixedArg1 = cg->argument1 << 16;      //lint !e701
                    FIXED fixedArg2 = cg->argument2 << 16;      //lint !e701

                    // update composite bb
                    if (fixedComponentBB.xMin + fixedArg1 < fixedBB->xMin)
                        fixedBB->xMin = fixedComponentBB.xMin + fixedArg1;
                    if (fixedComponentBB.xMax + fixedArg1 > fixedBB->xMax)
                        fixedBB->xMax = fixedComponentBB.xMax + fixedArg1;
                    if (fixedComponentBB.yMin + fixedArg2 < fixedBB->yMin)
                        fixedBB->yMin = fixedComponentBB.yMin + fixedArg2;
                    if (fixedComponentBB.yMax + fixedArg2 > fixedBB->yMax)
                        fixedBB->yMax = fixedComponentBB.yMax + fixedArg2;

                    // update font bb
                    if (offsetMinX < minX)
                        minX = offsetMinX;
                    if (offsetMaxX > maxX)
                        maxX = offsetMaxX;
                    if (offsetMinY < minY)
                        minY = offsetMinY;
                    if (offsetMaxY > maxY)
                        maxY = offsetMaxY;
                }
            }

            GLYF_destroyGlyf(&curGlyf);
        }
    }

    free(charStringBuf);
    free(gsubrStringBuf);
    cleanupInfoArray(charStrInfoArray, newCff->numGlyphs);

    // set font bb
    newCff->bb.xMin = FLOAT_TO_FIXED(minX);
    newCff->bb.xMax = FLOAT_TO_FIXED(maxX);
    newCff->bb.yMin = FLOAT_TO_FIXED(minY);
    newCff->bb.yMax = FLOAT_TO_FIXED(maxY);

    // Private dict
    // Note: The private dict is allowed to be zero size, but this code always creates one with entries.
    boolean isAsian = hasAsian(lfFont);
    cffErr = cff_createPrivateDict(isAsian, defaultWidth, nominalWidth, &newCff->encodedPrivateDict, &newCff->encodedPrivateDictSize);
    if (cffErr != CFF_ERR_OK)
    {
        cff_destroyCFF_TAB(newCff);
        return cff_mapCffErrorToLfError(cffErr);
    }

    // Top dict
    CFFTOPDICT* newTopDict = (CFFTOPDICT*)calloc(1, sizeof(CFFTOPDICT));
    if (newTopDict == NULL)
    {
        cff_destroyCFF_TAB(newCff);
        return cff_mapCffErrorToLfError(cffErr);
    }

    newTopDict->charstringType = 2;
    newTopDict->privateDictSize = newCff->encodedPrivateDictSize;

    // set sids
    newTopDict->version = tdSids.versionSID;
    newTopDict->Notice = tdSids.noticeSID;
    newTopDict->copyright = tdSids.copyrightSID;
    newTopDict->FullName = tdSids.fullNameSID;
    newTopDict->FamilyName = tdSids.familyNameSID;
    newTopDict->Weight = tdSids.weightSID;

    // Set bounding box
    newTopDict->fontbbox[0] = (LONG)minX;
    newTopDict->fontbbox[1] = (LONG)minY;
    newTopDict->fontbbox[2] = (LONG)maxX;
    newTopDict->fontbbox[3] = (LONG)maxY;

    // Set things from post table
    error = getPostInfo(lfFont, &newTopDict->underlinePosition, &newTopDict->underlineThickness, &newTopDict->isFixedPitch, &newTopDict->italicAngle);
    if (error != LF_ERROR_OK)
    {
        free(newTopDict);
        cff_destroyCFF_TAB(newCff);
        return error;
    }

    // Set font matrix
    if (origUPM != 1000)
    {
        newTopDict->fontmatrix[0] = newTopDict->fontmatrix[3] = 1.0f / origUPM;
        newTopDict->nonDefaultMatrix = TRUE;
    }

    // Set dummy offsets for now
    newTopDict->privateDictOffset = 1234;
    newTopDict->encodingOffset = 0;
    newTopDict->charsetOffset = 1234;
    newTopDict->charStringsOffset = 1234;

    BYTE*   encodedTopDict;
    ULONG   encodedTopDictSize;

    // Encode the top dict with the incorrect offsets, so that we can get the size of the top dict
    cffErr = cff_encodeTopDict(newTopDict, NULL, &encodedTopDictSize);
    if (cffErr != CFF_ERR_OK)
    {
        free(newTopDict);
        cff_destroyCFF_TAB(newCff);
        return cff_mapCffErrorToLfError(cffErr);
    }

    LONG topDictIndexSize = cff_indexGetLengthForSingleItemIndex(encodedTopDictSize);

    // Calculate the correct offsets
    newTopDict->charsetOffset = 4                                                           // header
                                + cff_indexGetLength(newCff->nameIndex)                     // name index
                                + topDictIndexSize                                          // top dict
                                + cff_indexGetLength(newCff->stringIndex)                   // string index
                                + cff_indexGetLength(newCff->globalSubrIndex);              // global subroutine index

    newTopDict->charStringsOffset = newTopDict->charsetOffset                               // total so far
                                    + newCff->encodedCharsetSize;                           // charset

    newTopDict->privateDictOffset = newTopDict->charStringsOffset + cff_indexGetLength(newCff->charStringsIndex);

    // now encode it for real
    cffErr = cff_encodeTopDict(newTopDict, &encodedTopDict, &encodedTopDictSize);
    if (cffErr != CFF_ERR_OK)
    {
        free(newTopDict);
        cff_destroyCFF_TAB(newCff);
        return cff_mapCffErrorToLfError(cffErr);
    }

    // create Top Dict Index
    cffErr = cff_indexInitializeWithSize(1, &newCff->topDictIndex);
    if (cffErr != CFF_ERR_OK)
    {
        free(newTopDict);
        free(encodedTopDict);
        cff_destroyCFF_TAB(newCff);
        return cff_mapCffErrorToLfError(cffErr);
    }

    item.data = encodedTopDict;
    item.length = encodedTopDictSize;

    cffErr = cff_indexAppendCopy(newCff->topDictIndex, &item);
    if (cffErr != CFF_ERR_OK)
    {
        free(newTopDict);
        free(encodedTopDict);
        cff_destroyCFF_TAB(newCff);
        return cff_mapCffErrorToLfError(cffErr);
    }

    free(encodedTopDict);
    free(newTopDict);

    cffTable->builtTable = newCff;

    return error;
}

LF_ERROR conversion_createCharstring(LF_FONT *lfFont, USHORT index, Glyph *glyph, cffAnalyzedCharstring** cs)
{
    CFF_ERROR cffErr;
    LONG charStringBufLen = 0;

    // Determine the widths for the font
    LONG defaultWidth, nominalWidth;
    LF_ERROR error = calculateWidths(lfFont, &defaultWidth, &nominalWidth);
    if (error != LF_ERROR_OK)
    {
        return error;
    }

    // Set an initial buffer size for the charstring, based on the max points in the font.
    // If the initial guess is insufficient, the code below will detect that and double the size
    // until it is enough. Initial values below determined experimentally with a set of 72 fonts.
    LONG initCharStringBufSize;
    USHORT maxPoints = MAXP_getMaxPoints(lfFont);

    if (maxPoints < 450)
        initCharStringBufSize = 1536;
    else if (maxPoints < 1200)
        initCharStringBufSize = 3072;
    else
        initCharStringBufSize = 5120;

    // Allocate a scratch buffer into which the charstrings for each glyph will be written.
    LONG charStringBufSize = initCharStringBufSize;
    BYTE* charStringBuf = (BYTE*)malloc(charStringBufSize*sizeof(BYTE));
    if (charStringBuf == NULL)
    {
        return LF_OUT_OF_MEMORY;
    }

    cffAnalyzedCharstring* acs = calloc(1, sizeof(cffAnalyzedCharstring));
    if (acs == NULL)
    {
        free(charStringBuf);
        return LF_OUT_OF_MEMORY;
    }

    memset(acs, 0, sizeof(cffAnalyzedCharstring));

    USHORT width = HMTX_getAdvanceWidth(lfFont, index);

    ADVANCEDELTA advanceDelta;
    advanceDelta.equalsDefaultWidth = (boolean)(width == defaultWidth);
    advanceDelta.delta = width - nominalWidth;


    if (glyph->glyphOutline.component.outline.nc == 0)
    {
        cffErr = createEmptyCharstring(&advanceDelta, charStringBuf, charStringBufSize, &charStringBufLen);
        if (cffErr != CFF_ERR_OK)
        {
            free(acs);
            free(charStringBuf);
            return cff_mapCffErrorToLfError(cffErr);
        }
    }
    else
    {
#if 0
        // compute outline bounding box
        conversion_computeCubicBoundingBox(glyph);


        acs->bb.xMax = (FIXED)(glyph->glyphOutline.xMax * 65536.0f);
        acs->bb.xMin = (FIXED)(glyph->glyphOutline.xMin * 65536.0f);
        acs->bb.yMax = (FIXED)(glyph->glyphOutline.yMax * 65536.0f);
        acs->bb.yMin = (FIXED)(glyph->glyphOutline.yMin * 65536.0f);
#endif

        // create a (regular) charstring from the Glyph
        do {
            cffErr = createCharstring(&advanceDelta, glyph, charStringBuf, charStringBufSize, &charStringBufLen);
            if (cffErr == CFF_ERR_CS_BUF_EXCEEDED)
            {
                free(charStringBuf);
                charStringBuf = (BYTE*)malloc(charStringBufSize * 2);
                if (charStringBuf == NULL)
                {
                    free(acs);
                    free(charStringBuf);
                    return LF_OUT_OF_MEMORY;
                }
                charStringBufSize *= 2;
            }
            else if (cffErr != CFF_ERR_OK)
            {
                free(acs);
                free(charStringBuf);
                return cff_mapCffErrorToLfError(cffErr);
            }
        } while (cffErr != CFF_ERR_OK);

    }

    free(charStringBuf);

    *cs = acs;


    return LF_ERROR_OK;
}
