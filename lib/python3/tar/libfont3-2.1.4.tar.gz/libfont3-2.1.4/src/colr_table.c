// Copyright (C) 2016 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// colr_table.c

#include "colr_table.h"
#include "table_tags.h"
#include "utils.h"

static void COLR_freeBaseGlyphRecords(colr_table* table);
static void COLR_freeLayerRecords(colr_table* table);


LF_ERROR COLR_readTable(LF_FONT* lfFont, const sfnt_table_record* record, LF_STREAM* stream)
{
    if (record->length == 0)
        return LF_BAD_FORMAT;

    if (STREAM_streamSeek(stream, record->offset) != 0)
        return LF_INVALID_OFFSET;

    colr_table* table = (colr_table*)calloc(1, sizeof(colr_table));
    if (NULL == table)
        return LF_OUT_OF_MEMORY;

    //table->remapped = FALSE; done above

    table->version = STREAM_readUShort(stream);
    table->numBaseGlyphRecords = STREAM_readUShort(stream);
    table->offsetBaseGlyphRecord = STREAM_readULong(stream);
    table->offsetLayerRecord = STREAM_readULong(stream);
    table->numLayerRecords = STREAM_readUShort(stream);

    // Read in base glyph records
    map_init(&table->baseGlyphsMap, integer_compare);

    STREAM_streamSeek(stream, record->offset + table->offsetBaseGlyphRecord);

    for (USHORT i = 0; i < table->numBaseGlyphRecords; i++)
    {
        base_glyph_record* bgr = (base_glyph_record*)calloc(1, sizeof(base_glyph_record));
        if (NULL == bgr)
        {
            COLR_freeBaseGlyphRecords(table);
            free(table);
            return LF_OUT_OF_MEMORY;
        }

        GlyphID gid = STREAM_readUShort(stream);
        bgr->firstLayerIndex = STREAM_readUShort(stream);
        bgr->numLayers = STREAM_readUShort(stream);

        if (NULL == map_insert(&table->baseGlyphsMap, (void*)(intptr_t)gid, bgr))
        {
            free(bgr);
            COLR_freeBaseGlyphRecords(table);
            free(table);
            return LF_OUT_OF_MEMORY;
        }
    }

    // Read in Layer records
    LF_ERROR error = vector_init(&table->layerRecords, table->numLayerRecords, 4);
    if (error != LF_ERROR_OK)
    {
        COLR_freeBaseGlyphRecords(table);
        free(table);
        return error;
    }

    STREAM_streamSeek(stream, record->offset + table->offsetLayerRecord);

    for (USHORT i = 0; i < table->numLayerRecords; i++)
    {
        layer_record* lr = (layer_record*)calloc(1, sizeof(layer_record));
        if (NULL == lr)
        {
            COLR_freeBaseGlyphRecords(table);
            COLR_freeLayerRecords(table);
            free(table);
            return error;
        }

        lr->GID = STREAM_readUShort(stream);
        lr->paletteIndex = STREAM_readUShort(stream);

        error = vector_push_back(&table->layerRecords, lr);
        if (error != LF_ERROR_OK)
        {
            free(lr);
            COLR_freeBaseGlyphRecords(table);
            COLR_freeLayerRecords(table);
            free(table);
            return error;
        }
    }

    map_insert(&lfFont->table_map, (void*)(intptr_t)record->tag, table);

    return LF_ERROR_OK;
}

static void COLR_freeBaseGlyphRecords(colr_table* table)
{
    LF_MAP_ITER* mapIter = map_begin(&table->baseGlyphsMap);
    if (mapIter == NULL)
    {
        DEBUG_LOG_ERROR("allocation failed in COLR_freeBaseGlyphRecords()");
        return;
    }

    rb_tree_node* node = map_next(mapIter);

    while (node)
    {
        base_glyph_record* bgr = node->data;

        free(bgr);

        node = map_next(mapIter);
    }

    map_free_iter(mapIter);

    map_clear(&table->baseGlyphsMap);
} //lint !e429

static void COLR_freeLayerRecords(colr_table* table)
{
    for (size_t i = 0; i < table->layerRecords.count; i++)
    {
        layer_record* lr = vector_at(&table->layerRecords, i);
        free(lr);
    }

    vector_free(&table->layerRecords);
}

LF_ERROR COLR_keepGlyphs(const LF_FONT* lfFont, GlyphList* keepList)
{
    colr_table* table = (colr_table*)map_at(&lfFont->table_map, (void*)(long)TAG_COLR);

    if (NULL == table)
        return LF_TABLE_MISSING;

    ULONG numKeepGlyphs;
    GlyphID* glyphList = Keep_getSortedGlyphIDList(keepList, &numKeepGlyphs);
    if (glyphList == NULL)
        return LF_OUT_OF_MEMORY;

    GlyphID* gidEnd = glyphList + numKeepGlyphs;
    for (GlyphID* gidPtr = glyphList; gidPtr < gidEnd; gidPtr++)
    {
        base_glyph_record* bgr = (base_glyph_record*)map_at(&table->baseGlyphsMap, (void*)(intptr_t)(*gidPtr));

        if (bgr != NULL)
        {
            // Mark all the corresponding layers as to be kept
            for (USHORT i = bgr->firstLayerIndex; i < bgr->firstLayerIndex + bgr->numLayers; i++)
            {
                layer_record* lr = vector_at(&table->layerRecords, i);

                if (lr)
                {
                    lr->retain = TRUE;

                    LF_ERROR status = Keep_addGlyph(keepList, lr->GID);
                    if ((status != LF_ADDED_GLYPH) && (status != LF_ERROR_OK))
                        return status;
                }
            }
        }
    }

    free(glyphList);

    return LF_ERROR_OK;
}

LF_ERROR COLR_getTableSize(LF_FONT* lfFont, size_t* tableSize)
{
    colr_table* table = (colr_table*)map_at(&lfFont->table_map, (void*)(long)TAG_COLR);

    *tableSize = 0;

    if (table == NULL)
        return LF_TABLE_MISSING;

    *tableSize = 3 * sizeof(USHORT) /* version, numBaseGlyphRecords, numLayerRecords */
               + 2 * sizeof(ULONG); /* offsetBaseGlyphRecord, offsetLayerRecord      */

    size_t numBaseGlyphs = map_size(&table->baseGlyphsMap);
    size_t numLayerRecords = 0;

    if (numBaseGlyphs == 0)
        return LF_EMPTY_TABLE;

    for (size_t i = 0; i < table->layerRecords.count; i++)
    {
        layer_record* lr = vector_at(&table->layerRecords, i);

        if (lr)
        {
            if (lr->retain == TRUE)
                numLayerRecords++;
        }
    }

    *tableSize += numBaseGlyphs * (3 * sizeof(USHORT) /* GID, firstLayerIndex, numLayers */);
    *tableSize += numLayerRecords * (2 * sizeof(USHORT) /* GID, paletteIndex */);

    return LF_ERROR_OK;
}

LF_ERROR COLR_removeGlyph(LF_FONT* lfFont, ULONG index)
{
    colr_table* table = (colr_table*)map_at(&lfFont->table_map, (void*)(long)TAG_COLR);
    if (table == NULL)
        return LF_TABLE_MISSING;

    base_glyph_record* bgr = (base_glyph_record*)map_at(&table->baseGlyphsMap, (void*)(intptr_t)index);

    if (bgr)
    {
        map_erase(&table->baseGlyphsMap, (void*)(intptr_t)index);
        free(bgr);
    }

    return LF_ERROR_OK;
}

LF_ERROR COLR_isTableEmpty(LF_FONT* lfFont)
{
    colr_table* table = (colr_table*)map_at(&lfFont->table_map, (void*)(long)TAG_COLR);
    if (table == NULL)
        return LF_TABLE_MISSING;

    return (0 == map_size(&table->baseGlyphsMap) ? LF_EMPTY_TABLE : LF_ERROR_OK);
}

LF_ERROR COLR_remapTable(LF_FONT* lfFont, LF_MAP *remap)
{
    colr_table* table = (colr_table*)map_at(&lfFont->table_map, (void*)(long)TAG_COLR);
    if (table == NULL)
        return LF_TABLE_MISSING;

    // Remap the base glyphs list
    LF_MAP_ITER* mapIter = map_begin(&table->baseGlyphsMap);
    if (mapIter == NULL)
    {
        DEBUG_LOG_ERROR("allocation failed in COLR_remapTable()");
        return LF_OUT_OF_MEMORY;
    }

    rb_tree_node* node = map_next(mapIter);

    while (node)
    {
        node->key = map_at(remap, node->key);

        node = map_next(mapIter);
    }

    map_free_iter(mapIter);

    // Remap the GIDs in the layer records
    for (size_t i = 0; i < table->layerRecords.count; i++)
    {
        layer_record* lr = vector_at(&table->layerRecords, i);

        if (lr)
        {
            lr->GID = (USHORT)(intptr_t)map_at(remap, (void*)(intptr_t)lr->GID);
        }
    }

    return LF_ERROR_OK;
}

static LF_ERROR COLR_remapLayerIndexes(colr_table* table)
{
    if (table->remapped == TRUE)
        return LF_ERROR_OK;

    LF_MAP layerMap;

    map_init(&layerMap, integer_compare);

    size_t nextIndex = 0;

    for (size_t i = 0; i < table->layerRecords.count; i++)
    {
        layer_record* lr = vector_at(&table->layerRecords, i);

        if (lr)
        {
            if (NULL == map_insert(&layerMap, (void*)i, (void*)nextIndex))
            {
                DEBUG_LOG_ERROR("allocation failure in COLR_remapLayerIndexes");
                map_clear(&layerMap);
                return LF_OUT_OF_MEMORY;
            }

            if (lr->retain == TRUE)
                nextIndex++;
        }
    }

    LF_MAP_ITER* mapIter = map_begin(&table->baseGlyphsMap);
    if (mapIter == NULL)
    {
        DEBUG_LOG_ERROR("allocation failed in COLR_remapLayerIndexes()");
        map_clear(&layerMap);
        return LF_OUT_OF_MEMORY;
    }

    rb_tree_node* node = map_next(mapIter);

    while (node)
    {
        base_glyph_record* bgr = node->data;

        bgr->firstLayerIndex = (USHORT)(intptr_t)map_at(&layerMap, (void*)(intptr_t)bgr->firstLayerIndex);

        node = map_next(mapIter);
    }

    map_free_iter(mapIter);

    map_clear(&layerMap);

    table->remapped = TRUE;

    return LF_ERROR_OK;
}

static LF_ERROR COLR_buildTable(LF_FONT* lfFont, BYTE** tableData, size_t* tableSize)
{
    *tableData = NULL;
    *tableSize = 0;

    colr_table* table = (colr_table*)map_at(&lfFont->table_map, (void*)(long)TAG_COLR);
    if (table == NULL)
        return LF_TABLE_MISSING;

    // Remap the first layer indexes
    LF_ERROR error = COLR_remapLayerIndexes(table);
    if (error != LF_ERROR_OK)
        return error;

    error = COLR_getTableSize(lfFont, tableSize);
    if (error != LF_ERROR_OK)
        return error;

    size_t paddedSize = *tableSize;
    *tableData = UTILS_AllocTable(&paddedSize);
    if (*tableData == NULL)
    {
        DEBUG_LOG_ERROR("allocation failure in COLR_buildTable");
        return LF_OUT_OF_MEMORY;
    }

    LF_STREAM stream;
    STREAM_initMemStream(&stream, *tableData, *tableSize);

    size_t numBaseGlyphs = map_size(&table->baseGlyphsMap);
    size_t numLayerRecords = 0;

    for (size_t i = 0; i < table->layerRecords.count; i++)
    {
        layer_record* lr = vector_at(&table->layerRecords, i);

        if (lr)
        {
            if (lr->retain == TRUE)
                numLayerRecords++;
        }
    }



    size_t offsetToBaseGlyphRecords = (3 * sizeof(USHORT)) + (2 * sizeof(ULONG));   // Base glyphs are written right after header
    size_t offsetToLayerRecords = offsetToBaseGlyphRecords + (numBaseGlyphs * (3 * sizeof(USHORT))); // Layer records are written after base glyph records

    STREAM_writeUShort(&stream, table->version); // version
    STREAM_writeUShort(&stream, (USHORT)numBaseGlyphs); // numBaseGlyphRecords
    STREAM_writeULong(&stream, (ULONG)offsetToBaseGlyphRecords); // offsetBaseGlyphRecord
    STREAM_writeULong(&stream, (ULONG)offsetToLayerRecords); // offsetLayerRecord
    STREAM_writeUShort(&stream, (USHORT)numLayerRecords); // numLayerRecords

    LF_MAP_ITER* mapIter = map_begin(&table->baseGlyphsMap);
    if (mapIter == NULL)
    {
        DEBUG_LOG_ERROR("allocation failed in COLR_buildTable()");
        return LF_OUT_OF_MEMORY;
    }

    rb_tree_node* node = map_next(mapIter);

    while (node)
    {
        GlyphID gid = (GlyphID)(intptr_t)node->key;
        base_glyph_record* bgr = node->data;

        STREAM_writeUShort(&stream, gid);
        STREAM_writeUShort(&stream, bgr->firstLayerIndex);
        STREAM_writeUShort(&stream, bgr->numLayers);

        node = map_next(mapIter);
    }

    map_free_iter(mapIter);

    for (size_t i = 0; i < table->layerRecords.count; i++)
    {
        layer_record* lr = vector_at(&table->layerRecords, i);

        if ((lr) && (TRUE == lr->retain))
        {
            STREAM_writeUShort(&stream, lr->GID);
            STREAM_writeUShort(&stream, lr->paletteIndex);
        }
    }

    return LF_ERROR_OK;
}

LF_ERROR COLR_writeTable(LF_FONT* lfFont, sfnt_table_record* record, LF_STREAM* stream)
{
    size_t tableSize;
    BYTE* tableData;

    LF_ERROR error = COLR_buildTable(lfFont, &tableData, &tableSize);
    if (error != LF_ERROR_OK)
        return error;

    record->checkSum = UTILS_CalcTableChecksum(tableData, tableSize);
    record->length = (ULONG)tableSize;
    record->offset = (ULONG)STREAM_streamPos(stream);

    STREAM_writeChunk(stream, tableData, (tableSize + 3) & ~3);
    free(tableData);

    return LF_ERROR_OK;
}

LF_ERROR COLR_freeTable(LF_FONT* lfFont)
{
    colr_table* table = (colr_table*)map_at(&lfFont->table_map, (void*)(long)TAG_COLR);

    if (table)
    {
        COLR_freeBaseGlyphRecords(table);
        COLR_freeLayerRecords(table);
        free(table);
    }

    return LF_ERROR_OK;
}
