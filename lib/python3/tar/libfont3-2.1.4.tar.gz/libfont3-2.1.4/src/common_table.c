// Copyright (C) 2014 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// common_table.c

#include <stdio.h>

#include "common_table.h"
#include "data_types.h"
#include "utils.h"
#include "stream.h"
#include "lf_vector.h"
#include "lookup_table.h"


/* ----------------------------------------------------------------------------
    @summary
        stream in the lookup record into the structure.

    @description
        All three formats of ContextSubst subtables specify substitution data
        in a SubstLookupRecord.  For purposes of this library, this
        structure is context_lookup_record.

        The SequenceIndex in a lookup record must take into consideration
        the order in which lookups are applied to the entire glyph sequence.
        Because multiple substitutions may occur per context, the
        SequenceIndex and LookupListIndex refer to the glyph sequence
        after the text-processing client has applied previous lookups.  In
        other words, the SequenceIndex identifies the location for the
        substitution at the time that the lookup is to be applied.  For
        example, consider an input glyph sequence of four glyphs.  The
        first glyph does not have a substitute, but the middle two glyphs
        will be replaced with a ligature and a single glyph will replace
        the fourth glyph:


        -    The first glyph is in position 0. No lookups will be applied
            at position 0, so no SubstLookupRecord is defined.


        -    The SubstLookupRecord defined for the ligature substitution
            specifies the SequenceIndex as position 1, which is the
            position of the first-glyph component in the ligature string.
            After the ligature replaces the glyphs in positions 1 and 2,
            however, the input glyph sequence consists of only three
            glyphs, not the original four.

        -    To replace the last glyph in the sequence, the SubstLookupRecord
            defines the SequenceIndex as position 2 instead of position 3.
            This position reflects the effect of the ligature substitution
            applied before this single substitution.

---------------------------------------------------------------------------- */
LF_ERROR Common_readSubstLookupRecord(context_lookup_record* slr, LF_STREAM* stream)
{
    slr->SequenceIndex = STREAM_readUShort(stream);              // read in sequence index
    slr->LookupListIndex = STREAM_readUShort(stream);            // read in the lookup list index

    return LF_ERROR_OK;
}



LF_ERROR Common_readSubstLookupRecords(LF_VECTOR* records, USHORT count, LF_STREAM* stream)
{
    USHORT      n;
    LF_ERROR    error;

    error = vector_init(records, count, sizeof(ULONG));
    if (error != LF_ERROR_OK)
        goto Fail1;

    for (n = 0; n < count; n++ )
    {
        context_lookup_record* slr = (context_lookup_record*)malloc(sizeof(context_lookup_record));
        if (!slr)
        {
            DEBUG_LOG_ERROR("failed to allocate context lookup record");
            error = LF_OUT_OF_MEMORY;
            goto Fail2;
        }

        error = Common_readSubstLookupRecord(slr, stream);
        if (error != LF_ERROR_OK)
        {
            DEBUG_LOG_ERROR("failed to read lookup records");
            goto Fail2;
        }
        vector_push_back(records, slr);
    }
    return LF_ERROR_OK;

Fail2:
    Common_freeSubstLookupRecords(records);

Fail1:
    return error;
}


LF_ERROR Common_buildSubstLookupRecords(LF_VECTOR* records, LF_STREAM* stream)
{
    USHORT      n;
    LF_ERROR    error = LF_ERROR_OK;


    for (n = 0; n < records->count; n++ )
    {
        context_lookup_record* slr = (context_lookup_record*)vector_at(records, n);
        if (slr)
            Common_buildSubstLookupRecord(slr, stream);
        else
        {
            DEBUG_LOG_VALUE("unable to retrieve lookup record at ", n);
            error = LF_INVALID_INDEX;
        }
    }
    return error;
}


#if _DEBUG && 0
static void lookup_unittest(LF_VECTOR* records)
{
    ULONG n;
    context_lookup_record* record;
    for (n = 0; n < 10; n++)
    {
        record = (context_lookup_record*)calloc(1, sizeof(context_lookup_record));

        record->LookupListIndex = 5;
        vector_push_back(records, (void*)record);
    }


    record = (context_lookup_record*)vector_at(records, 4);
    record->LookupListIndex = 6;

    record = (context_lookup_record*)vector_at(records, 5);
    record->LookupListIndex = 7;

    record = (context_lookup_record*)vector_at(records, 6);
    record->LookupListIndex = 3;
}
#endif


/* ============================================================================
    @desc
        go through the lookup records and remap the indexes using a delta
        value.  the function goes through and looks for all indices that
        are greater than the reference index and then applies the delta
        calculation to the that index.

        The basic concept is that a lookup table has removed lookup entry
        5, and therefore 5 no longer exists.  All of the references to
        lookup index 5 will be removed, but we also need to address all
        of the lookups above 5 and apply the delta, so as an example

        lookup => 6     would become 5.
        lookup => 10    would become 9.

        The basic idea being we remove one index at 5, so we need to apply
        a delta of -1 to all of the indices that are > 5.

============================================================================ */
LF_ERROR Common_removeLookupListIndex(LF_VECTOR* records, USHORT refIndex, SHORT deltaIndex)
{
    USHORT      n = 0;
    LF_ERROR    error = LF_ERROR_OK;

#if _DEBUG && 0
    // TODO: remove this
    LF_VECTOR* test = vector_create(10, 4);
    records = test;
    lookup_unittest(records);
    refIndex = 5;
#endif


    while (n < records->count)
    {
        context_lookup_record* slr = (context_lookup_record*)vector_at(records, n);
        if (slr)
        {
            if (slr->LookupListIndex > refIndex)
            {
                slr->LookupListIndex += deltaIndex;
                n++;
            }
            else if (slr->LookupListIndex == refIndex)
            {
                FREE(slr);
                vector_erase(records, n);
            }
            else
            {
                n++;
            }
        }
    }

    if (records->count == 0)
        error = LF_EMPTY_TABLE;

    return error;
}


/* ============================================================================
    @desc
        free the lookup records resources from the system.


============================================================================ */
void Common_freeSubstLookupRecords(LF_VECTOR* records)
{
    ULONG i = 0;
    while (i < records->count)
    {
        context_lookup_record* lr = (context_lookup_record*)vector_at(records, i++);
        free(lr);
    }
    vector_delete(records);
}



/* ============================================================================
    @desc
        return the stream size of the lookup records.

============================================================================ */
ULONG    Common_sizeSubstLookupRecords(LF_VECTOR* records)
{
    ULONG size = 0;
    USHORT n;
    context_lookup_record* record;

    for (n = 0; n < vector_size(records); n++)
    {
        record = (context_lookup_record*)vector_at(records, n);
        size += Common_sizeSubstLookupRecord(record);
    }
    return size;
}



/* ============================================================================
    @desc
        write a lookup record to the stream.

============================================================================ */
size_t Common_buildSubstLookupRecord(context_lookup_record* slr, LF_STREAM* stream)
{
    STREAM_writeUShort(stream, slr->SequenceIndex);
    STREAM_writeUShort(stream, slr->LookupListIndex);

    return STREAM_streamPos(stream);
}



/* ----------------------------------------------------------------------------
    @desc
        return the size of the lookup record

---------------------------------------------------------------------------- */
ULONG Common_sizeSubstLookupRecord(context_lookup_record* slr)
{
    return sizeof(slr->SequenceIndex) + sizeof(slr->LookupListIndex);
}

#ifdef LF_OT_DUMP
void Common_dumpSubstLookupRecords(LF_VECTOR* records)
{
    USHORT i;
    XML_START("LookupRecords");
    for (i = 0; i < records->count; i++)
    {
        context_lookup_record* record = (context_lookup_record*)vector_at(records, i);

        XML_START_COMMENT("LookupRecord", i, (int)records->count - 1);
        XML_DATA_NODE("LookupListIndex", record->LookupListIndex);
        XML_DATA_NODE("SequenceIndex", record->SequenceIndex);
        XML_END("LookupRecord");
    }
    XML_END("LookupRecords");
}
#endif

void Common_buildGlyphArray(LF_VECTOR* glyphs, LF_STREAM* stream)
{
    USHORT n, count;

    count = (USHORT)vector_size(glyphs);
    for (n = 0; n < count; n++)
    {
        STREAM_writeUShort(stream, (GlyphID)(intptr_t)vector_at(glyphs, n));
    }
}

/*
    build a glyph array that uses the following structure format

        USHORT        GlyphCount
        GlyphID       Glyphs[GlyphCount]


    The above format is common among format 2 for context and 
    chained context, so this function streams the Glyph count by
    getting the VECTOR count, and storing it in the stream.

    followed by writing out the array.

*/
void Common_buildGlyphCountArray(LF_VECTOR* glyphs, LF_STREAM* stream, USHORT adjustment)
{
    USHORT count;

    count = UTILS_getCount(glyphs);                      // how big is the vector array

    STREAM_writeUShort(stream, (count + adjustment));    // Count, Input[] sometimes are - 1 from actual account
    Common_buildGlyphArray(glyphs, stream);
}

void Common_buildClassArray(LF_VECTOR* classes, LF_STREAM* stream)
{
    USHORT n, count;

    count = UTILS_getCount(classes);                        // how big is the vector array

    for ( n = 0; n < count; n++ )
    {
        STREAM_writeUShort(stream, (USHORT)(intptr_t)vector_at(classes, n));
    }
}



void Common_buildClassCountArray(LF_VECTOR* classes, LF_STREAM* stream, USHORT adjustment)
{
    USHORT count;

    count = UTILS_getCount(classes);                     // how big is the vector array
    STREAM_writeUShort(stream, (count + adjustment));    // Count, Input[] sometimes are - 1 from actual account
    Common_buildClassArray(classes, stream);
}



void Common_buildClassDef(class_def* cd, LF_STREAM* stream, ULONG arrayOffset, ULONG baseOffset)
{
    size_t    curOffset, offset;

    curOffset = STREAM_streamPos(stream);
    offset = curOffset - baseOffset;
    STREAM_streamSeek(stream, arrayOffset);
    STREAM_writeOffset(stream, (OFFSET)offset);

    STREAM_streamSeek(stream, curOffset);

    // build class_def
    ClassDef_buildTable(cd, stream);
}



/* ----------------------------------------------------------------------------
    @summary
        build an array of offsets into the stream and return the starting
        stream position.

    @param
        stream = pointer to the start of the stream
        count = how many offset values are in the array

    @return
        the start position of the array in the stream.

---------------------------------------------------------------------------- */
size_t Common_buildEmptyArray(LF_STREAM* stream, USHORT count)
{
    USHORT n;
    size_t arrayStart = STREAM_streamPos(stream);
    for (n = 0; n < count; n++)
    {
        STREAM_writeUShort(stream, 0);
    }
    return arrayStart;
}



/* ============================================================================
    @desc
        given a current position in the stream, which you want to build
        a specific coverage, set, or whatever.  This table that you want
        to build is associated with a offset array based upon the start of
        the rule table (or baseOffset).

        This function, given the original baseOffset and the seek position
        of the Offset[] array, being arrayOffset will write out the offset
        value and stream.


============================================================================ */
ULONG Common_writeOffset(LF_STREAM* stream, ULONG arrayOffset, ULONG baseOffset)
{
    size_t    curOffset, offset;

    curOffset = STREAM_streamPos(stream);
    offset = curOffset - baseOffset;
    STREAM_streamSeek(stream, arrayOffset);

    STREAM_writeOffset(stream, (OFFSET)offset);
    STREAM_streamSeek(stream, curOffset);

    return (arrayOffset + sizeof(OFFSET));
}



LF_ERROR Common_remapGlyph(LF_MAP* remap, GlyphID oldid, GlyphID* newid)
{
    *newid = (GlyphID)(intptr_t)map_at(remap, (void*)(intptr_t)oldid);

    return ((*newid == 0) && (oldid != 0)) ? LF_NOT_COVERED : LF_ERROR_OK;
}


void Common_cleanupLookups(LF_VECTOR* records, TABLE_HANDLE hLookup)
{
    USHORT n;
    context_lookup_record* slr;

    for (n = 0; n < records->count; n++)
    {
        slr = (context_lookup_record*)vector_at(records, n);
        if (slr)
        {
            Lookup_cleanupLookups(hLookup, slr->LookupListIndex);
        }
    }
}




/* ============================================================================
    @summary
        go through the lookup records and collect glyphs using the 
        record's index.

    @param
        records     :    pointer to a vector collection of lookup records.
        keepList    :    pointer to glyph ids to keep
        hTable      :    pointer to the gsub_header. needs to be cast as it
                         is passed in as a void* pointer.

    @return
        LF_ADDED_GLYPH      :   the lookup records have added a glyph to
                                the keep table.

        LF_ERROR_OK         :   the lookup records completed and nothing
                                was added to the keep table.

============================================================================ */
LF_ERROR Common_collectLookupRecordGlyphs(LF_VECTOR* records, GlyphList* keepList, TABLE_HANDLE hTable)
{
    USHORT n;
    context_lookup_record* slr;
    LF_ERROR error = LF_ERROR_OK;

    for (n = 0; n < records->count; n++)
    {
        slr = (context_lookup_record*)vector_at(records, n);
        if (slr)
        {
            LF_ERROR status = Lookup_collectGlyphs(keepList, hTable, slr->LookupListIndex);
            if (status == LF_ADDED_GLYPH)
                error = status;
        }
    }
    return error;
}
