/* ============================================================================
    Copyright (C) 2014, 2015 Monotype Imaging Inc. All rights reserved.
    Confidential information of Monotype Imaging Inc.

    classdef.c
============================================================================ */

/* ----------------------------------------------------------------------------
    @summary
        The class definition structure holds the OpenType common definition
        for the glyphs and classes.

        When it is read it, the format is converted to a couple of collections
        to help speed up searches, and choosing optimized formats that reduce
        the memory.

        2 collections are maintained, one that holds all of glyphs in a
        sequential collection, while the second duplicates and groups the
        glyphs into classes.  Both collections are used to speed up searches
        and to determine whether of not the glyphs are in sequential formats.

---------------------------------------------------------------------------- */
#include <stdlib.h>
#include "classdef.h"
#include "utils.h"
#include "common_table.h"

static LF_ERROR ClassDef_readEmptyClass(class_def* cd);

// format 1
static LF_ERROR ClassDef_buildFormat1(class_format1* table, LF_STREAM* stream);
static LF_ERROR ClassDef_readFormat1(class_def* cd, LF_STREAM* stream);
static size_t   ClassDef_sizeFormat1(const class_format1* cf1);
static LF_ERROR ClassDef_isClassSequential(class_def* cd);
static LF_ERROR ClassDef_buildMapped1(class_def* cd, class_def* format1);

// format 2
static LF_ERROR ClassDef_readFormat2(class_def* table, LF_STREAM* stream);
static LF_ERROR ClassDef_buildFormat2(class_format2* table, LF_STREAM* stream);
static size_t   ClassDef_sizeFormat2(const class_format2* cf2);
static LF_ERROR ClassDef_buildMapped2(class_def* cd, class_def* f2);

#ifdef OPTIMIZED_LOOKUP
#define MAX_ARRAY_CLASSID       255
// optimized lookup tables for the class definition structure
static LF_ERROR classdef_initMap(class_def* cd, USHORT count);
static void     classdef_freeMap(class_def* cd);
static LF_ERROR classdef_addGlyph(class_def* cd, class_map* map);
static LF_ERROR classdef_removeClassID(class_def* cd, USHORT refClass, SHORT deltaValue);
static LF_ERROR classdef_removeGlyphID(class_def* cd, GlyphID glyph, USHORT* remove);
static void     classdef_setClassID(class_def* cd, USHORT classRef, USHORT classData);
static void     classdef_applyRemapClassID(class_def* cd, USHORT classRef, SHORT delta);
static USHORT   classdef_getClassID(class_def* cd, USHORT classRef);
#endif


/* ----------------------------------------------------------------------------
    @summary
        read in class definition format 1

        The range of glyph indices covered by the table is identified by two
        values: the GlyphID of the first glyph (StartGlyph), and the number of
        consecutive GlyphIDs (including the first one) that will be assigned
        class values (GlyphCount).  The ClassValueArray lists the class value
        assigned to each GlyphID, starting with the class value for StartGlyph
        and following the same order as the GlyphIDs.  Any glyph not included
        in the range of covered GlyphIDs automatically belongs to Class 0.

    @param
        cd          :   pointer to the class definition
        stream      :   pointer to the stream

---------------------------------------------------------------------------- */
static LF_ERROR ClassDef_readFormat1(class_def* cd, LF_STREAM* stream)
{
    LF_ERROR          error;
    USHORT            i;
    USHORT            count;
    class_format1*    cdf1 = &cd->class_format.format_1;

    cdf1->StartGlyph = STREAM_readUShort(stream);
    count = cdf1->GlyphCount = STREAM_readUShort(stream);

    if (cdf1->StartGlyph + (long)count > 0x10000L)
    {
        DEBUG_LOG_ERROR("StartGlyph and GlyphCount exceeds 16bit format");
        return LF_INVALID_SUBTABLE;
    }

#ifdef OPTIMIZED_LOOKUP
    classdef_initMap(cd, count);
#endif

    cd->TotalCount = count;

    error = vector_init(&cd->MapGlyph, count, 4);
    if (error != LF_ERROR_OK)
        return error;
    error = vector_init(&cdf1->ClassValueArray, count, sizeof(ULONG));
    if (error != LF_ERROR_OK)
    {
        vector_delete(&cd->MapGlyph);
        return error;
    }

    for(i = 0; i < count; i++)
    {
        class_map* map;
        USHORT data;

        data = STREAM_readUShort(stream);

        if (data >= CLASSDEF_LIMITS)
        {
            DEBUG_LOG_ERROR("ClassValueArray exceeds limits");
            error = LF_INVALID_SUBTABLE;
            vector_delete(&cdf1->ClassValueArray);
            vector_delete(&cd->MapGlyph);
            return error;
        }
        vector_push_back(&cdf1->ClassValueArray, (void*)(intptr_t)data);

        // map this out
        map = (class_map*)malloc(sizeof(class_map));
        if (!map)
        {
            DEBUG_LOG_ERROR("Failed to allocate class_map");
            vector_delete(&cdf1->ClassValueArray);
            vector_delete(&cd->MapGlyph);
            return LF_OUT_OF_MEMORY;
        }

        map->Glyph = i + cdf1->StartGlyph;
        map->Class = data;
        map->Defined = TRUE;

        vector_push_back(&cd->MapGlyph, map);

#ifdef OPTIMIZED_LOOKUP
        classdef_addGlyph(cd, map);
#endif
    }

    return LF_ERROR_OK;
}

/* ----------------------------------------------------------------------------
    @summary
        read in class definition format 2

    @param
        table       :   pointer to the class definition
        stream      :   pointer to the stream

---------------------------------------------------------------------------- */
static LF_ERROR ClassDef_readFormat2(class_def* table, LF_STREAM* stream)
{
    USHORT          i;
    USHORT          classRangeCount = STREAM_readUShort(stream);
    class_format2*  f2 = &table->class_format.format_2;
    table->TotalCount = 0;

#ifdef OPTIMIZED_LOOKUP
    classdef_initMap(table, 10);
#endif

    LF_ERROR error = vector_init(&f2->ClassRangeRecord, classRangeCount, 4);
    if (error != LF_ERROR_OK)
        return error;
    error = vector_init(&table->MapGlyph, 10, 4);
    if (error != LF_ERROR_OK)
    {
        vector_delete(&f2->ClassRangeRecord);
        return error;
    }

    for(i = 0; i < classRangeCount; i++)
    {
        GlyphID n;
        class_range_record* record = (class_range_record*)malloc(sizeof(class_range_record));

        if (record == NULL)
        {
            ClassDef_freeTable(table);
            return LF_OUT_OF_MEMORY;
        }

        record->Start = STREAM_readUShort(stream);
        record->End = STREAM_readUShort(stream);
        record->Class = STREAM_readUShort(stream);

        vector_push_back(&f2->ClassRangeRecord, record);

        for (n = record->Start; n <= record->End; n++)
        {
            class_map* map = (class_map*)malloc(sizeof(class_map));

            if (map == NULL)
            {
                ClassDef_freeTable(table);
                return LF_OUT_OF_MEMORY;
            }

            map->Glyph = n;
            map->Class = record->Class;
            map->Defined = TRUE;

            table->TotalCount++;

            vector_push_back(&table->MapGlyph, map);
#ifdef OPTIMIZED_LOOKUP
            classdef_addGlyph(table, map);
#endif
            if (n == 65535)
                break;
        }
    }
    return LF_ERROR_OK;
}

/* ----------------------------------------------------------------------------
    @summary
        read in the class table from the stream.

    @param
        table = pointer to the class_def
        stream = pointer to the input stream
---------------------------------------------------------------------------- */
LF_ERROR ClassDef_readTable(class_def* table, LF_STREAM* stream)
{
    LF_ERROR error = LF_ERROR_OK;
    size_t     size = STREAM_streamPos(stream);

    ASSERT(table);
    ASSERT(stream);

    if (NULL == table)
        return LF_BAD_FORMAT;

    memset(table, 0, sizeof(class_def));

    table->ClassFormat = STREAM_readUShort(stream);

    switch(table->ClassFormat)
    {
        case 1:        error = ClassDef_readFormat1(table, stream);        break;
        case 2:        error = ClassDef_readFormat2(table, stream);        break;
        default:       error = LF_BAD_FORMAT;                              break;
    }

    // save the original read in data.
    table->ReadSize  = STREAM_streamPos(stream) - size;
    table->ReadFormat  = table->ClassFormat;

    return error;
}

/* ----------------------------------------------------------------------------
    @summary
        returns the class definition structure size for
        format 1.

    @description
        calculates the ClassValueArray size and the addition structure
        requirements according to the OpenType specification.

    @param
        cf1 = pointer to the class_format1

---------------------------------------------------------------------------- */
static size_t ClassDef_sizeFormat1(const class_format1* cf1)
{
    size_t size = 0;

    size += cf1->ClassValueArray.count * sizeof(USHORT);        // ClassValueArray[GlyphCount]
    size += sizeof(USHORT);                                     // GlyphCount
    size += sizeof(GlyphID);                                    // StartGlyph

    return size;
}

/* ----------------------------------------------------------------------------
    @summary
        returns the class definition structure size for 
        format 2.

    @description
        calculates the ClassRangeRecord size and the addition structure
        requirements according to the OpenType specification.

    @param
        cf2 = pointer to the class_format2

---------------------------------------------------------------------------- */
static size_t ClassDef_sizeFormat2(const class_format2* cf2)
{
    size_t size = 0;
    ULONG sizeRangeRecord = sizeof(GlyphID) + sizeof(GlyphID) + sizeof(USHORT);        // ClassRangeRecord

    size += sizeof(USHORT);                                                            // Number of ClassRangeCount
    size += sizeRangeRecord * cf2->ClassRangeRecord.count;                             // ClassRangeRecord[ClassRangeCount]

    return size;
}

/* ============================================================================
    @summary
        returns the class definition structure size using the read in
        format.

    @param
        table        :    pointer to the class_def
        tableSize    :    pointer to the variable which will hold size

    @returns
        status of calculation, may return BAD_FORMAT if it cannot
        determine a class_def format to use.

============================================================================ */
LF_ERROR ClassDef_getTableSize(class_def* table, size_t* tableSize)
{
    LF_ERROR error = LF_ERROR_OK;
    class_def cd;

    *tableSize = sizeof(USHORT);                // ClassFormat

    memset(&cd, 0, sizeof(class_def));

    switch (table->ClassFormat)
    {
    case 1:
        ClassDef_buildMapped1(table, &cd);
        *tableSize += ClassDef_sizeFormat1(&cd.class_format.format_1);
        break;

    case 2:
        ClassDef_buildMapped2(table, &cd);
        *tableSize += ClassDef_sizeFormat2(&cd.class_format.format_2);
        break;

    default:
        *tableSize = 0;
        DEBUG_LOG_WARNING("Bad format detected in class_def");
        error = LF_BAD_FORMAT;
        ASSERT(table->ClassFormat == 1);
        break;
    }

    ClassDef_freeTable(&cd);

    return error;
}

static LF_ERROR ClassDef_buildFormat1(class_format1* table, LF_STREAM* stream)
{
    USHORT i;

    STREAM_writeUShort(stream, table->StartGlyph);
    STREAM_writeUShort(stream, table->GlyphCount);

    for(i = 0; i < table->ClassValueArray.count; i++)
    {
        USHORT data = (USHORT)(intptr_t)vector_at(&table->ClassValueArray, i);
        STREAM_writeUShort(stream, data);
    }

    return LF_ERROR_OK;
}

static LF_ERROR ClassDef_buildFormat2(class_format2* table, LF_STREAM* stream)
{
    ULONG i = 0;

    STREAM_writeUShort(stream, (USHORT)table->ClassRangeRecord.count);

    for(; i < table->ClassRangeRecord.count; i++)
    {
        class_range_record* record = (class_range_record*)vector_at(&table->ClassRangeRecord, i);
        STREAM_writeUShort(stream, record->Start);
        STREAM_writeUShort(stream, record->End);
        STREAM_writeUShort(stream, record->Class);
    }

    return LF_ERROR_OK;
}

/* ============================================================================
    @brief
        build the class definition table.

    @param
        table = pointer to the class definition
        stream = pointer to the stream

    @return
        status of the build process.

============================================================================ */
LF_ERROR ClassDef_buildTable(class_def* table, LF_STREAM* stream)
{
    LF_ERROR error = LF_ERROR_OK;
    class_def cd;

    memset(&cd, 0, sizeof(class_def));

    // reuse the same format as read it.  we do this to maintain all of the class
    // reference indices, which we currently do not remap at this point.  changing
    // formats was causing lots of problems and will require a significant reworking
    // of the context, chaining rules to do the remapping.
    STREAM_writeUShort(stream, table->ClassFormat);

    switch (table->ClassFormat)
    {
    case 1:
        ClassDef_buildMapped1(table, &cd);
        error = ClassDef_buildFormat1(&cd.class_format.format_1, stream);
        table->Count = cd.class_format.format_1.GlyphCount;
        table->Size  = cd.Size;
        break;

    case 2:
        ClassDef_buildMapped2(table, &cd);
        error = ClassDef_buildFormat2(&cd.class_format.format_2, stream);
        table->Count = (ULONG)cd.class_format.format_2.ClassRangeRecord.count;
        table->Size = cd.Size;
        break;

    default:
        error = LF_BAD_FORMAT;
        ASSERT(table->ClassFormat == 1);
        break;
    }

    ClassDef_freeTable(&cd);

    return error;
}

/* ----------------------------------------------------------------------------
    @summary
        free up all of the memory used by the Class definitions

    @param
        cd = pointer to the class definitions

---------------------------------------------------------------------------- */
void ClassDef_freeTable(class_def* cd)
{
    if (cd)
    {
        LF_VECTOR* range = NULL;
        ULONG i = 0;

        while (i< cd->MapGlyph.count)
        {
            class_map* map = (class_map*)vector_at(&cd->MapGlyph, i++);
            free(map);
        }
        vector_delete(&cd->MapGlyph);

#ifdef OPTIMIZED_LOOKUP
        // free up optimiztion search collections
        classdef_freeMap(cd);
#endif

        switch (cd->ClassFormat)
        {
        case 1:
            vector_delete(&cd->class_format.format_1.ClassValueArray);
            break;

        case 2:
             range = &cd->class_format.format_2.ClassRangeRecord;

             i = 0;
             while (i < range->count)
             {
                class_range_record* record = (class_range_record*)vector_at(range, i++);
                free(record);
             }
            vector_delete(range);
            break;

        default:
            break;
        }
        memset(cd, 0, sizeof(class_def));
    }
}

/* ----------------------------------------------------------------------------
    @summary
        read an empty class.  create an empty class definition

    @param
        cd = pointer to the class definition

    @error
        return
---------------------------------------------------------------------------- */
static LF_ERROR ClassDef_readEmptyClass(class_def* cd)
{
    LF_ERROR error;
    class_map* map;

    error = vector_init(&cd->MapGlyph, 1, sizeof(ULONG));
    if (error != LF_ERROR_OK)
    {
        DEBUG_LOG_ERROR("Failed to allocate MapGlyph collection");
        return error;
    }

    error = vector_init(&cd->class_format.format_1.ClassValueArray, 1, sizeof(ULONG));
    if (error != LF_ERROR_OK)
    {
        DEBUG_LOG_ERROR("Out of memory allocating ClassDef->ClassValueArray");
        goto Fail1;
    }

    map = (class_map*)malloc(sizeof(class_map));
    if (!map)
    {
        error = LF_OUT_OF_MEMORY;
        goto Fail2;
    }

    map->Class = 0;
    map->Glyph = 0;
    map->Defined = FALSE;

    vector_push_back(&cd->MapGlyph, map);

    cd->ClassFormat = 1;                                            // Empty class, is a format 1 class definition
    return LF_ERROR_OK;

Fail2:
    vector_delete(&cd->class_format.format_1.ClassValueArray);

Fail1:
    vector_delete(&cd->MapGlyph);
    return error;
}

/* ============================================================================
    @summary
        determines by the stream, whether a placeholder class definition
        or a defined class definition needs to be created.

    @param
        cd = pointer to the class definition structure
        limit = ???
        classOffset = stream offset value for class
        baseOffset  = stream offset for beginning of class definition tables.

        stream = pointer to the stream

============================================================================ */
LF_ERROR ClassDef_readEmptyOrClassDefinition(class_def* cd, USHORT limit,
                                             ULONG classOffset, ULONG baseOffset,
                                             LF_STREAM* stream)
{
    LF_ERROR    error;
    size_t      curOffset;

    (void)limit; //TODO remove from prototype?

    curOffset = STREAM_streamPos(stream);
    if (classOffset)
    {
        STREAM_streamSeek(stream, classOffset + baseOffset);
        error = ClassDef_readTable(cd, stream);
    }
    else
    {
        error = ClassDef_readEmptyClass(cd);
    }

    if (error == LF_ERROR_OK)
    {
        STREAM_streamSeek(stream, curOffset);
    }
    return error;
}

static class_map* ClassDef_binarySearchGlyph(class_def* cd, GlyphID glyphid)
{
    LONG mid = 0;
    class_map* map = NULL;
    LONG low = -1;
    LONG high = (LONG)cd->MapGlyph.count;

    if(high != 0)
    {
        while ((low + 1) != high)
        {
            mid = (high + low) >> 1;

            map = (class_map*)vector_at(&cd->MapGlyph, mid);

            if(map->Glyph < glyphid)
            {
                low = mid;
            }
            else
            {
                high = mid;
            }
        }

        if(high >= (LONG)cd->MapGlyph.count)
        {
            map = NULL;
        }
        else
        {
            if(high != mid)
                map = (class_map*)vector_at(&cd->MapGlyph, high);

            if(map->Glyph != glyphid)
                map = NULL;
        }
    }

    return map;
}

/* ============================================================================
    @summary
        removes a glyph and class reference associated with the glyph
        from the class definition.

    @param:
        cd = pointer to the class definition structure
        glyphid = the glyph id associated
        removed = the class reference removed.

    @return
        LF_ERROR status

    @example
        if the glyphid exists in the class definition and it referred to
        a class reference of 2.  the method would remove the glyphid from
        the class definition.  if class 2 is referred to by other glyphs,
        the remove would be set to 0, and status returned would be
        LF_ERROR_OK.

        if class 2 is NOT referred to by other glyphs, the remove parameter
        would be set to 2 and status returned would be LF_EMPTY_TABLE.

        if the glyphid does NOT exist in the class definition, the return
        status would be LF_NOT_COVERED

        version which avoids accessing the last vector item if not needed
        This was @ 3% faster than the original version.

============================================================================ */
LF_ERROR ClassDef_removeGlyph(class_def* cd, GlyphID glyphid, USHORT* removed)
{
    ASSERT(cd);
    ASSERT(removed);

#ifdef OPTIMIZED_LOOKUP
    classdef_removeGlyphID(cd, glyphid, remove);
#endif

    if(ClassDef_isTableEmpty(cd))
    {
        *removed = 0;
        return LF_EMPTY_TABLE;
    }
    else
    {
        class_map* map;

        //first
        map = (class_map*)vector_at(&cd->MapGlyph, 0);

        if(map->Glyph <= glyphid)
        {
            //last
            map = (class_map*)vector_at(&cd->MapGlyph, cd->MapGlyph.count-1);

            if(glyphid <= map->Glyph)
            {
                map = ClassDef_binarySearchGlyph(cd, glyphid);

                if(map != NULL)
                {
                    *removed = map->Class;          // save the class associated with glyph
                    map->Defined = 0;

                    cd->TotalCount--;               // decrement the count in the table

                    return (ClassDef_isTableEmpty(cd) ? LF_EMPTY_TABLE : LF_ERROR_OK);
                }
            }
        }

        *removed = 0;

        return LF_NOT_COVERED;
    }
}

/* ----------------------------------------------------------------------------
    @summary
        updates the glyph ids of the class_def according the the glyph index map

    @param:
        cd = pointer to the class definition structure
        glyphIndexMap = mapping between original glyph ids and new ones

    @return
        LF_ERROR status

---------------------------------------------------------------------------- */
LF_ERROR ClassDef_remapGlyphs(class_def* cd, LF_MAP *remap)
{
    USHORT i, count;

    if ((cd == NULL) || (remap == NULL))
        return LF_INVALID_SUBTABLE;

    count = (USHORT)vector_size(&cd->MapGlyph);

    for (i = 0; i < count; i++)
    {
        class_map*  map = (class_map*)vector_at(&cd->MapGlyph, i);

        if (map->Defined)
        {
            GlyphID newGlyphID;

            LF_ERROR error = Common_remapGlyph(remap, map->Glyph, &newGlyphID);

            map->Glyph = newGlyphID;

            if (error != LF_ERROR_OK)
            {
                DEBUG_LOG_VALUE("failed remapping occurred", map->Glyph);
            }
        }

//        ASSERT((map->Glyph != 0 && newGlyphID != 0) || (map->Glyph == 0 && newGlyphID == 0)); // i.e. remapping should be done after glyphs are removed
    }

    return LF_ERROR_OK;
}

/* ----------------------------------------------------------------------------
    @summary
        returns OK if the class id is referenced in the map collection

    @param:
        cd = pointer to the class definition structure
        classref = class id that we are checking.

    @return
        LF_ERROR status

---------------------------------------------------------------------------- */
LF_ERROR ClassDef_isClassFormatReferenced(class_def* cd, USHORT classid)
{
    LF_ERROR    error;

    ASSERT(cd);

    error = ClassDef_isClassReferenced(cd, classid);

    return error;
}

/* ----------------------------------------------------------------------------
    @summary
        returns OK if the class id is referenced in the class definition

    @param:
        cd = pointer to the class definition structure
        classid = class id that we are checking.

    @return
        LF_ERROR status

---------------------------------------------------------------------------- */
LF_ERROR ClassDef_isClassReferenced(class_def* cd, USHORT classid)
{
#ifdef OPTIMIZED_LOOKUP
    LF_VECTOR* classref = (LF_VECTOR*)vector_at(&cd->ClassIDArray, classid);

    if (classref && classref->count)
    {
        return LF_ERROR_OK;
    }

#else
    USHORT n, count;
    class_map* map;

    count = (USHORT)vector_size(&cd->MapGlyph);

    // now we need to see if the class reference removed exists anywhere 
    // else in the ClassValueArray. If the class does NOT exist, then 
    // we can remove it from the table completely.
    for ( n = 0; n < count; n++)
    {
        map = (class_map*)vector_at(&cd->MapGlyph, n);
        if (map->Defined == 1)
        {
            if (map->Class == classid)
            {
                // found a reference
                return LF_ERROR_OK;
            }
        }
    }
#endif
    return LF_NOT_COVERED;
}

/* ----------------------------------------------------------------------------
    @description
        build out mapped version 2.  This function will convert the 
        existing mapping format into a format 2 class definition.

        It will also return the memory requirements that are needed
        to save out the format.

    @param
        cd        = pointer to the class definition that needs to be
                  converted to format 1.

        format2 = NULL pointer that will hold the new built structure.

    @return
        format2 will be defined with the class definition, otherwise
        NULL if there are no mappings leftover.

---------------------------------------------------------------------------- */
static LF_ERROR ClassDef_buildMapped2(class_def* cd, class_def* f2)
{
    class_map*            map = NULL;            // next range element in mapped glyph collection
    class_map*            last = NULL;           // last range element grabbed
    class_map*            start = NULL;          // pointer to the starting range
    class_range_record*   record = NULL;

    USHORT                n, count;
    ULONG                 numRecords = 0;
    ULONG                 sizeFormat2;

    memset(&f2->MapGlyph, 0, sizeof(LF_VECTOR));            // TEMP: do this so free won't assert.  unused structure

    f2->ClassFormat = 2;
    count = (USHORT)cd->MapGlyph.count;                        // first check how many range records we have ...

    if (!count)
        return LF_EMPTY_TABLE;

    LF_ERROR error = vector_init(&f2->class_format.format_2.ClassRangeRecord, count, sizeof(ULONG));
    if (error != LF_ERROR_OK)
        return error;

    // get start of the range, by looking for first defined class
    for (n = 0; n < count; n++)
    {
        map = start = last = (class_map*)vector_at(&cd->MapGlyph, n);
        if (map && map->Defined)
            break;
    }
    n = n + 1;

    if (map == NULL || start == NULL || last == NULL)
    {
        // something wrong
        return LF_BAD_FORMAT;
    }

    // loop through all of the mapped glyphs ...
    for (; n < count; n++)
    {
        map = (class_map*)vector_at(&cd->MapGlyph, n);

        if (map->Class != last->Class || map->Glyph != last->Glyph + 1 || map->Defined == 0)
        {
            if (map->Defined)
            {
                // end of the range ...
                record = (class_range_record*)malloc(sizeof(class_range_record));
                if (record)
                {
                    record->Start = start->Glyph;
                    record->End = last->Glyph;
                    record->Class = last->Class;

                    vector_push_back(&f2->class_format.format_2.ClassRangeRecord, record);
                }
                else
                {
                    return LF_OUT_OF_MEMORY;
                }
                numRecords++;
                start = map;
            }
        }
        if (map->Defined)
            last = map;
    }

    record = (class_range_record*)malloc(sizeof(class_range_record));
    if (record)
    {
        record->Start = start->Glyph;

        if (map->Defined)
        {
            record->End = map->Glyph;
            record->Class = map->Class;
        }
        else
        {
            record->End = last->Glyph;
            record->Class = last->Class;
        }
        vector_push_back(&f2->class_format.format_2.ClassRangeRecord, record);
    }
    else
    {
        return LF_OUT_OF_MEMORY;
    }
    numRecords++;

    sizeFormat2 = sizeof(USHORT);
    sizeFormat2 += sizeof(USHORT);
    sizeFormat2 += sizeof(class_range_record) * numRecords;

    f2->Size = sizeFormat2;
    f2->Count = numRecords;

    return LF_ERROR_OK;
}

/* ----------------------------------------------------------------------------
    @description
        build out mapped version 1.  This function will convert the
        existing mapping format into a format 1 class definition.

        It will also return the memory requirements that are needed
        to save out the format.

    @param
        cd      = pointer to the class definition that needs to be
                  converted to format 1.

        format1 = NULL pointer that will hold the new built structure.

    @return
        format1 will be defined with the class definition, otherwise
        NULL if there are no mappings leftover.

---------------------------------------------------------------------------- */
static LF_ERROR ClassDef_buildMapped1(class_def* cd, class_def* format1)
{
    class_map* map;
    USHORT n, count;
    ULONG size;
    count = (USHORT)cd->MapGlyph.count;

    if (!count)
    {
        return LF_EMPTY_TABLE;
    }

    memset(&format1->MapGlyph, 0, sizeof(LF_VECTOR));

    LF_ERROR error = vector_init(&format1->class_format.format_1.ClassValueArray, count, sizeof(ULONG));
    if (error != LF_ERROR_OK)
        return error;

    // loop until we find a valid first glyph...
    for (n = 0; n < count; n++)
    {
        map = (class_map*)vector_at(&cd->MapGlyph, n);
        if (map->Defined == TRUE)
        {
            format1->class_format.format_1.StartGlyph = map->Glyph;
            break;
        }
    }

    // go through the map and convert it to format 1
    for (; n < count; n++)
    {
        USHORT classdata;

        map = (class_map*)vector_at(&cd->MapGlyph, n);

        if (map->Defined == 0)
            classdata = 0;
        else
            classdata = map->Class;

        vector_push_back(&format1->class_format.format_1.ClassValueArray, (void*)(intptr_t)classdata);
    }

    count = (USHORT)format1->class_format.format_1.ClassValueArray.count;

    size = sizeof(USHORT);                              // ClassFormat
    size += sizeof(GlyphID);                            // StartGlyph
    size += sizeof(USHORT);                             // GlyphCount
    size += (sizeof(USHORT) * count);                   // ClassValueArray[GlyphCount]

    format1->ClassFormat = 1;
    format1->class_format.format_1.GlyphCount = count;
    format1->Size = size;
    format1->Count = count;

    return LF_ERROR_OK;
}

// return the maximum class in the range.  used in conjunction with context pruning by
// looking at all of the supported classes defined and parsing the lookup records.
ULONG ClassDef_getMaxClass(class_def* cd)
{
    USHORT lastClass = 0;
    size_t n;
    if (cd)
    {
        for (n = 0; n < cd->MapGlyph.count; n++)
        {
            class_map* map = (class_map*)vector_at(&cd->MapGlyph, n);
            if (map->Class > lastClass)
            {
                lastClass = map->Class;
            }
        }

        cd->MaxClassValue = lastClass;
        cd->DirtyClassValue = FALSE;
    }

    return lastClass;
}

/* ============================================================================
    @description
        given a class reference, return back a vector collection of glyphs
        that are associated with this class.

    @param
        cd          : pointer to the class definition
        classref    : the class reference we want glyphs from.

    @return
        pointer to vector collection.  caller is responsible to free the
        memory allocated for the vector.

============================================================================ */
LF_VECTOR* ClassDef_getGlyphsByClass(class_def* cd, USHORT classref)
{
    LF_VECTOR* v = NULL;

    if (cd && cd->MapGlyph.count)
    {
        ULONG n;

        v = vector_create(1, 32);

        for (n = 0; n < cd->MapGlyph.count; n++)
        {
            class_map* map = (class_map*)vector_at(&cd->MapGlyph, n);
            if (map->Class == classref && map->Defined == 1)
            {
                vector_push_back(v, (void*)(intptr_t)map->Glyph);
            }
        }
    }

    return v;
}

/* ============================================================================

    @description
        remove a class id from the class definition structure and remap
        all of the other classes to accommodate the removed class.

    @param:
        cd          : pointer to class definition
        refClass    : class reference to remove
        deltaIndex  : apply delta to other classes affected by removal

    @return
        OK          : class was removed
        EMPTY       : class is empty of all classes

============================================================================ */
LF_ERROR ClassDef_removeClassID(class_def* cd, USHORT refClass, SHORT deltaIndex)
{
    USHORT      n = 0;
    LF_ERROR    error = LF_ERROR_OK;
    LF_VECTOR*  records = &cd->MapGlyph;

    while (n < records->count)
    {
        class_map* map = (class_map*)vector_at(records, n);
        if (map)
        {
            if (map->Class > refClass)
            {
                map->Class += deltaIndex;
                n++;
            }
            else if (map->Class == refClass)
            {
                free(map);
                vector_erase(records, n);
            }
            else
            {
                n++;
            }
        }
    }

#ifdef OPTIMIZED_LOOKUP
    classdef_removeClassID(cd, refClass, deltaIndex);
#endif

    if (records->count == 0)
        error = LF_EMPTY_TABLE;

    return error;
}

/* ============================================================================
    @desc
        returns the number of defined classes back to the caller.

    @param
        cd    = pointer to class definition
============================================================================ */
USHORT ClassDef_getCount(class_def* cd)
{
    USHORT        n, count;
    LF_VECTOR*    records;

    ASSERT(cd);

    count = 0;
    records = &cd->MapGlyph;

    // loop through the class structure.
    for (n = 0; n < cd->MapGlyph.count; n++)
    {
        class_map* map = (class_map*)vector_at(records, n);
        if (map && map->Class && map->Defined == TRUE)
        {
            count++;
        }
    }
    return count;
}

#ifdef LF_OT_DUMP
/* ============================================================================
    @desc
        dump the class definition to the XML file.  Goes through
        all of the classes (except class 0) and then writes out
        the glyph ids associated with each class.

    @param
        cd      :       pointer to the class definition structure.

============================================================================ */
void ClassDef_dump(class_def* cd)
{
    USHORT        n, i;
    LF_VECTOR*    records;
    ULONG         maxclass;
    USHORT        empty = FALSE;
    ASSERT(cd);

    records = &cd->MapGlyph;

    maxclass = ClassDef_getMaxClass(cd);

    XML_START("classdef");

    // loop through the class structure.
    for (i = 1; i <= maxclass; i++)
    {
        //lint -size(a, 2049)
        char nodename[2048];
        //lint -size(a, 0)
        sprintf(nodename, "class%d", i);

        XML_START(nodename);
        empty = TRUE;

        for (n = 0; n < records->count; n++)
        {
            class_map* map = (class_map*)vector_at(records, n);

            if (map && map->Class == i && map->Defined == TRUE)
            {
                XML_DATA_NODE("gid", map->Glyph);
                empty = FALSE;
            }
        }

        if (empty == TRUE)
        {
            XML_COMMENT("Class is empty", 0);
        }

        XML_END(nodename);

    }
    XML_END("classdef");
}
#endif

static LF_ERROR ClassDef_isClassSequential(class_def* cd)
{
    USHORT        n;
    LF_VECTOR*    records;
    GlyphID       startGlyph = 0;
    class_map*    map;
    USHORT        nFound = 0;
    USHORT        nStart = 0;

    ASSERT(cd);

    records = &cd->MapGlyph;

    for (n = 0; n < records->count; n++)
    {
        map = (class_map*)vector_at(records, n);

        if (map->Defined && map->Class != 0)
        {
            startGlyph = map->Glyph;
            nFound = 1;
            nStart = n + 1;
            break;
        }
    }

    if (nFound == 1)
    {
        USHORT prevGlyph = startGlyph;

        // loop through the class structure.
        for (n = nStart; n < records->count; n++)
        {
            map = (class_map*)vector_at(records, n);

            if (map->Defined == 0 || map->Class == 0)
                return LF_BAD_FORMAT;

            if (map->Glyph != prevGlyph + 1)
                return LF_BAD_FORMAT;

            prevGlyph = map->Glyph;
        }
    }
    else
    {
        // the class definition isn't sequential, so we will need to use
        // format 2 of class definition.
        return LF_BAD_FORMAT;
    }

    // the class definition is sequential, so we are good to go using format
    // 1 as an output.
    return LF_ERROR_OK;
}

/* ============================================================================
    @summary
        determine what is the best format to use by checking if the 
        glyphs are in sequence.  If the sequence is broken then we
        must use format 2, otherwise we can use format 1.

    @param
        table    :    pointer to the class definition
        stream   :    pointer to the stream

    @return
        LF_ERROR_OK      :    class build and streamed
        LF_BAD_FORMAT    :    unable to determine a valid format

============================================================================ */
USHORT ClassDef_whichFormat(class_def* table)
{
    LF_ERROR    status;
    USHORT      format = 0;

    status = ClassDef_isClassSequential(table);
    if (status != LF_ERROR_OK)
    {
        format = 2;
    }

    return format;
}

/* ============================================================================
    @summary
        build the class definition table by determining which is the best
        format to use.

    @param
        table    :    pointer to the class definition
        stream   :    pointer to the stream

    @return
        LF_ERROR_OK      :    class build and streamed
        LF_BAD_FORMAT    :    unable to determine a valid format

============================================================================ */
LF_ERROR ClassDef_buildTableFormat(class_def* table, LF_STREAM* stream)
{
    LF_ERROR    error = LF_ERROR_OK;
    class_def   f1, f2;
    USHORT      format;

    memset(&f1, 0, sizeof(class_def));
    memset(&f2, 0, sizeof(class_def));

    format = ClassDef_whichFormat(table);
    if (format == 0)
    {
        ClassDef_buildMapped1(table, &f1);
        ClassDef_buildMapped2(table, &f2);

        // determine the most optimized format to use.
        if (f2.Size < f1.Size)
            format = 2;
        else
            format = 1;
    }
    else
    {
        ClassDef_buildMapped2(table, &f2);
        format = 2;
    }

#if _DEBUG
    if (format != table->ReadFormat)
        DEBUG_LOG_VALUE("Changing ClassDef to Format", format);
    else
        DEBUG_LOG_VALUE("ClassDef using Format", format);
#endif

    STREAM_writeUShort(stream, format);                        // use format 1, because it is smaller

    switch (format)
    {
    case 1:
        error = ClassDef_buildFormat1(&f1.class_format.format_1, stream);
        table->Count = f1.class_format.format_1.GlyphCount;
        table->Size = f1.Size;
        break;

    case 2:
        error = ClassDef_buildFormat2(&f2.class_format.format_2, stream);
        table->Count = (ULONG)f2.class_format.format_2.ClassRangeRecord.count;
        table->Size = f2.Size;
        break;

    default:
        error = LF_BAD_FORMAT;
        break;
    }

    // release any resources allocated
    ClassDef_freeTable(&f1);
    ClassDef_freeTable(&f2);

    return error;
}

/* ============================================================================
    @summary
        by examining the modified/passed class_def structure, this function
        determines the best memory size that should be used.  it will build
        the class def in either/or ClassDef formats and return the size of
        the table requirements by picking the smallest size.

    @notes
        This is done with the current state, and if any modifications happen
        to the class_def structure, this returned value may change.

    @param
        table            :    pointer to the class_def
        tableSize        :    pointer to the variable which will hold size

    @returns
        LF_ERROR_OK      :    tableSize is defined with a size.
        LF_BAD_FORMAT    :    unable to determine a format for ClassDef.

============================================================================ */
LF_ERROR ClassDef_sizeTableFormat(class_def* table, size_t* tableSize)
{
    LF_ERROR error = LF_ERROR_OK;
    USHORT     format;

    class_def f1;
    class_def f2;

    memset(&f1, 0, sizeof(class_def));
    memset(&f2, 0, sizeof(class_def));

    *tableSize = sizeof(USHORT);                // ClassFormat

    format = ClassDef_whichFormat(table);

    if (format == 0)
    {
        ClassDef_buildMapped1(table, &f1);
        ClassDef_buildMapped2(table, &f2);

        // determine the most optimized format to use using memory
        if (f2.Size < f1.Size)
            format = 2;
        else
            format = 1;
    }
    else
    {
        ClassDef_buildMapped2(table, &f2);
        format = 2;
    }

    switch (format)
    {
    case 1:        *tableSize += ClassDef_sizeFormat1(&f1.class_format.format_1);    break;
    case 2:        *tableSize += ClassDef_sizeFormat2(&f2.class_format.format_2);    break;
    default:       error = LF_BAD_FORMAT;                                            break;
    }

    ClassDef_freeTable(&f1);
    ClassDef_freeTable(&f2);

    return error;
}

/* ============================================================================
    @summary
        parses the class definition structure and searches for all glyphs
        that match the classID.  if a classID is matched, the glyph is
        then checked if it is also in keepList.

        this function will check against the startClassID first, and
        will then parse the classIDs next.

        if any of the class ids do not find a match in the keep list,
        the function will exit early with a NOT_COVERED return.


    @param
        cd              :   pointer to the class definition structure
        startClassID    :   starting class ID value
        classIDs        :   collection of class ids to check against.
        keepList        :   pointer to the keep list containing the
                            current glyphs.
    @return
        LF_NOT_COVERED  :   the sequence of class ids could not be
                            found in the keepList.

        LF_ERROR_OK     :   the sequence of class ids found a match
                            in the keepList.

============================================================================ */
LF_ERROR ClassDef_classesExists(class_def* cd, TABLE_HANDLE keep, USHORT startClassID, LF_VECTOR* classIDs)
{
    LF_ERROR error = LF_NOT_COVERED;
    ULONG n;

    if (startClassID != 0)
    {
        error = ClassDef_classExists(cd, keep, startClassID);
        if (error == LF_NOT_COVERED)
            return error;
    }

    for (n = 0; n < classIDs->count; n++)
    {
        USHORT classID = (USHORT)(intptr_t)vector_at(classIDs, n);
        error = ClassDef_classExists(cd, keep, classID);
        if (error == LF_NOT_COVERED)
            return error;
    }
    return LF_ERROR_OK;
}

LF_ERROR ClassDef_classExists(class_def* cd, TABLE_HANDLE keep, USHORT classID)
{
    LF_ERROR error = LF_ERROR_OK;

    if (classID != 0)
    {
        GlyphList* keepList = (GlyphList*)keep;
        LF_VECTOR* classes = ClassDef_getGlyphsByClass(cd, classID);
        error = LF_NOT_COVERED;
        if (classes)
        {
            ULONG n;

            for (n = 0; n < classes->count; n++)
            {
                GlyphID glyph = (GlyphID)(intptr_t)vector_at(classes, n);
                LF_ERROR status = Keep_coverageExists(keepList, glyph);

                // it only takes one to match, then we can exit ...
                if (status == LF_ERROR_OK)
                {
                    error = status;
                    break;
                }
            }
        }
        vector_delete(classes);
        free(classes);
    }
    return error;
}

#ifdef OPTIMIZED_LOOKUP
/* ----------------------------------------------------------------------------
    @summary
        initialize the class definition collection arrays and maps for
        reading the file.


---------------------------------------------------------------------------- */
static LF_ERROR classdef_initMap(class_def* cd, USHORT count)
{
    USHORT      i;
    LF_ERROR    status;

    map_init(&cd->ClassGlyphMap, integer_compare);

    status = vector_init(&cd->ClassIDArray, MAX_ARRAY_CLASSID, 4);
    if (status != LF_ERROR_OK)
        goto fail1;

    status = vector_init(&cd->ClassIDRemap, MAX_ARRAY_CLASSID, 4);
    if (status != LF_ERROR_OK)
        goto fail1;


    // fill up the classid array with null pointers
    for (i = 0; i < MAX_ARRAY_CLASSID; i++)
    {
        vector_push_back(&cd->ClassIDArray, NULL);
        vector_push_back(&cd->ClassIDRemap, (void*)i);
    }

    cd->TotalCount = 0;

    return LF_ERROR_OK;

fail1:
    map_clear(&cd->ClassGlyphMap);
    vector_free(&cd->ClassIDArray);
    vector_free(&cd->MapGlyph);

    return LF_OUT_OF_MEMORY;
}

/* ----------------------------------------------------------------------------
    @summary
        free all of the resources to store the class_def structure.

    @param
        cd  :   pointer to the class_def structure

---------------------------------------------------------------------------- */
static void classdef_freeMap(class_def* cd)
{
    if (cd)
    {
        map_clear(&cd->ClassGlyphMap);
        vector_free(&cd->ClassIDRemap);

        while (cd->ClassIDArray.count)
        {
            LF_VECTOR* classArray = (LF_VECTOR*)vector_at(&cd->ClassIDArray, 0);
            vector_delete(classArray);
            FREE(classArray);
            vector_erase(&cd->ClassIDArray, 0);
        }
        vector_free(&cd->ClassIDArray);
    }
}

/* ----------------------------------------------------------------------------
@summary
    Add a glyph to a specific class identity.  this function will
    place the glyph id into a map collection that uses the class id
    for the key.  each of the class id data value also contains a
    map collection that uses the glyph id as a key and the data is
    a class_map structure.

    the class_map structure contains all of the information about
    the glyph and is useful when passing to other functions.  it
    contains the glyph id, class id the glyph is associated with,
    and whether it is defined.

    class<<glyphid><class_map* map>>

    classes<<classid><LF_MAP* class>>

    @param
        cd      :   pointer to the class_def structure
        map     :   pointer to the class_map structure

    @return
        LF_ERROR_OK         : glyph was added to the class_def structure
        LF_OUT_OF_MEMORY    : failed to allocate memory to add in the new
                              class_map structure.
---------------------------------------------------------------------------- */
static LF_ERROR classdef_addGlyph(class_def* cd, class_map* map)
{
    USHORT      classID = map->Class;
    GlyphID     glyph = map->Glyph;
    LF_VECTOR*  glyphs;

    map_insert(&cd->ClassGlyphMap, (void*)glyph, (void*)classID);

    glyphs = (LF_VECTOR*)vector_at(&cd->ClassIDArray, classID);
    if (glyphs == NULL)
    {
        // if glyphs isn't defined, then we need to create an array to
        // hold all of the glyphs associated with the class.
        glyphs = vector_create(4, 4);
        vector_set_data(&cd->ClassIDArray, classID, (void*)glyphs);
    }

    vector_push_back(glyphs, (void*)glyph);

    return LF_ERROR_OK;
}

/* ----------------------------------------------------------------------------
    @summary
        remove a class id from the class definition structure.  The function
        will retrieve a vector collection of all of the glyphs associated with
        the class reference value.

        it will go through the LF_MAP structure and remove those glyphs.

        once done, it will remove the vector and remap the classes in
        the mapping function

    @param
        cd          :   pointer to the class_def structure
        refClass    :   reference class id we want to remove

---------------------------------------------------------------------------- */
static LF_ERROR classdef_removeClassID(class_def* cd, USHORT refClass, SHORT deltaValue)
{
    LF_ERROR    error = LF_NOT_COVERED;

    LF_VECTOR*  classArray = (LF_VECTOR*)vector_at(&cd->ClassIDArray, refClass);

    if (classArray)
    {
        // we found some glyphs associated with the reference class
        USHORT n, count;

        // clean up the map of all glyphs
        for (n = 0; n < classArray->count; n++)
        {
            GlyphID glyphid = (GlyphID)vector_at(classArray, n);
            map_erase(&cd->ClassGlyphMap, (void*)glyphid);
        }

        // remove the array
        vector_delete(classArray);
        FREE(classArray);
        vector_erase(&cd->ClassIDArray, refClass);

        count = UTILS_getCount(&cd->ClassIDArray);

        // now remap all of the classes to the new value
        for (n = refClass; n < count; n++)
        {
            USHORT classid = (USHORT)vector_at(&cd->ClassIDRemap, n);
            classid += deltaValue;
            vector_set_data(&cd->ClassIDRemap, n, (void*)classid);
        }

        classdef_applyRemapClassID(cd, refClass, deltaValue);

        error = LF_ERROR_OK;
    }
    return error;
}

/* ----------------------------------------------------------------------------
    @summary
        remove a specific glyph id from the class definition structure.  This
        function will sync the LF_MAP, and LF_VECTOR structures.

        The function will find the glyph in the LF_MAP and remove it from
        the collection.  The LF_MAP collection will identifiy which class
        the glyph is associated with and use that reference to clean up
        the class structures as well.

        if the class structure is emptied, it will cleanup and remove
        the LF_VECTOR class structure as well.

---------------------------------------------------------------------------- */
static LF_ERROR classdef_removeGlyphID(class_def* cd, GlyphID glyph, USHORT* remove)
{
    USHORT classref = (USHORT)map_at(&cd->ClassGlyphMap, (void*)glyph);

    map_erase(&cd->ClassGlyphMap, (void*)glyph);

    *remove = classref;

    if (classref != 0)
    {
        LF_VECTOR*  arrayGlyphs = (LF_VECTOR*)vector_at(&cd->ClassIDArray, classref);
        USHORT      n;

        if (arrayGlyphs)
        {
            for (n = 0; n < arrayGlyphs->count; n++)
            {
                GlyphID glyphid = (GlyphID)vector_at(arrayGlyphs, n);
                if (glyphid == glyph)
                {
                    vector_erase(arrayGlyphs, n);
                    break;
                }
            }

            if (vector_empty(arrayGlyphs))
            {
                vector_delete(arrayGlyphs);
                FREE(arrayGlyphs);
                vector_set_data(&cd->ClassIDArray, classref, NULL);
            }
        }
    }

    return LF_ERROR_OK;
}

static void classdef_setClassID(class_def* cd, USHORT classRef, USHORT classData)
{
    vector_set_data(&cd->ClassIDRemap, classRef, (void*)classData);
}

// this function removes the classRef from the remap collection and remaps all
// of the greater than classes by applying a delta
static void classdef_applyRemapClassID(class_def* cd, USHORT classRef, SHORT delta)
{
    LF_MAP* classmap = &cd->ClassGlyphMap;
#if 0
    USHORT      n, count;

    count = UTILS_getCount(&cd->ClassIDArray);

    for (n = 0; n < count; n++)
    {
        USHORT classid = classdef_getClassID(cd, classRef);

        if (classid == classRef)
        {
            classdef_setClassID(cd, n, 0);
        }
        else if (classid > classRef)
        {
            classid += delta;
            classdef_setClassID(cd, n, classid);
        }
    }
#endif

    // first cleanup the resources for the reference class
    if (classmap)
    {
        LF_MAP_ITER*	classmapIter = map_begin(classmap);
        rb_tree_node*	classnode;

        if(classmapIter == NULL)
        {
            DEBUG_LOG_ERROR("out of memory in classdef_applyRemapClassID");
            return;
        }

        classnode = map_next(classmapIter);

        while (classnode)
        {
            USHORT classdata = (USHORT)classnode->data;

            if (classdata == classRef)
            {
                DEBUG_LOG_WARNING("shouldn't be here");
            }
            else if (classdata > classRef)
            {
                classdata += delta;
                classnode->data = (void*)classdata;
            }
            classnode = map_next(classmapIter);
        }

        map_free_iter(classmapIter);
    }
}

static USHORT classdef_getClassID(class_def* cd, USHORT classRef)
{
    USHORT data = (USHORT)vector_at(&cd->ClassIDRemap, classRef);
    return data;
}
#endif
