﻿// Copyright (C) 2014, 2016 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// svg_core.c

#include <stdio.h>
#include <stdlib.h>

#include "lf_xml.h"
#include "svg_core.h"
#include "svg_defs.h"
#include "os2_table.h"
#include "sfnt_core.h"
#include "name_table.h"
#include "hhea_table.h"
#include "head_table.h"
#include "hmtx_table.h"
#include "glyf_table.h"
#include "cmap_table.h"
#include "post_table.h"
#include "gsub_table.h"
#include "kern_table.h"


static LF_ERROR SVG_WriteUTF8String(USHORT* text, LF_STREAM* stream, size_t* size)
{
    while (*text)
    {
        if (*text < 0x007F)
        {
            *size += stream ? STREAM_writeByte(stream, *text & 0xFF) : 1;
        }
        else if (*text < 0x07FF)
        {
            *size += stream ? STREAM_writeByte(stream, 0xC0 | ((*text >> 6) & 0x1F)) : 1;
            *size += stream ? STREAM_writeByte(stream, 0x80 | (*text & 0x3F)) : 1;
        }
        else if (*text < 0xFFFF)
        {
            *size += stream ? STREAM_writeByte(stream, 0xE0 | ((*text >> 12) & 0x0F)) : 1;
            *size += stream ? STREAM_writeByte(stream, 0x80 | ((*text >> 6) & 0x3F)) : 1;
            *size += stream ? STREAM_writeByte(stream, 0x80 | (*text & 0x3F)) : 1;
        }

        text++;
    }

    return LF_ERROR_OK;
}

static LF_ERROR SVG_GetNameString(LF_FONT* lfFont, USHORT nameID, USHORT* buffer, int bufLen)
{
    buffer[0] = 0;

    USHORT length;
    LF_ERROR error = NAME_getNameStringLength(lfFont, nameID, &length);

    if ((error == LF_ERROR_OK) && (length > 0))
    {
        USHORT bytesToGet = (USHORT)((bufLen-2 < length) ? bufLen-2 : length);

        error = NAME_getNameString(lfFont, nameID, (BYTE*)buffer, bytesToGet);

        buffer[bytesToGet / 2] = 0;
    }

    return error;
}

static LF_ERROR SVG_WriteMetaData(LF_FONT* lfFont, LF_STREAM* stream, size_t* size)
{
    LF_ERROR error;
    USHORT fullFontName[1024];          //lint !e813
    USHORT copyrightNotice[1024];       //lint !e813
    USHORT trademarkName[1024];         //lint !e813

    error = SVG_GetNameString(lfFont, NAME_FONT_FULL_NAME, fullFontName, sizeof(fullFontName));
    if (error != LF_ERROR_OK)
        return error;

    error = SVG_GetNameString(lfFont, NAME_COPYRIGHT_NOTICE, copyrightNotice, sizeof(copyrightNotice));
    if ((error != LF_ERROR_OK) && (error != LF_INVALID_TYPE))
        return error;

    error = SVG_GetNameString(lfFont, NAME_TRADEMARK_NOTICE, trademarkName, sizeof(trademarkName));
    if ((error != LF_ERROR_OK) && (error != LF_INVALID_TYPE))
        return error;

    XML_WriteStartTag(stream, SVG_METADATA_TAG, TRUE, size);
    {
        XML_WriteStartTag(stream, SVG_METADATA_VERSION_TAG, FALSE, size);
        *size += stream ? STREAM_writeChunk(stream, (const BYTE*)SVG_METADATA_VERSION_VALUE, strlen(SVG_METADATA_VERSION_VALUE)) : strlen(SVG_METADATA_VERSION_VALUE);
        XML_WriteEndTag(stream, SVG_METADATA_VERSION_TAG, size);

        XML_WriteStartTag(stream, SVG_METADATA_ID_TAG, FALSE, size);
        *size += stream ? STREAM_writeChunk(stream, (const BYTE*)XML_CDATA_BEGIN, strlen(XML_CDATA_BEGIN)) : strlen(XML_CDATA_BEGIN);
        SVG_WriteUTF8String(fullFontName, stream, size);
        *size += stream ? STREAM_writeChunk(stream, (const BYTE*)XML_CDATA_END, strlen(XML_CDATA_END)) : strlen(XML_CDATA_END);
        XML_WriteEndTag(stream, SVG_METADATA_ID_TAG, size);

        XML_WriteStartTag(stream, SVG_METADATA_VENDOR_TAG, FALSE, size);
        *size += stream ? STREAM_writeChunk(stream, (const BYTE*)SVG_METADATA_VENDOR_VALUE, strlen(SVG_METADATA_VENDOR_VALUE)) : strlen(SVG_METADATA_VENDOR_VALUE);
        XML_WriteEndTag(stream, SVG_METADATA_VENDOR_TAG, size);

        XML_WriteStartTag(stream, SVG_METADATA_CREDITS_TAG, TRUE, size);
        {
            XML_WriteStartTag(stream, SVG_METADATA_NAME_TAG, FALSE, size);
            *size += stream ? STREAM_writeChunk(stream, (const BYTE*)SVG_METADATA_CREDITS_NAME_VALUE, strlen(SVG_METADATA_CREDITS_NAME_VALUE)) : strlen(SVG_METADATA_CREDITS_NAME_VALUE);
            XML_WriteEndTag(stream, SVG_METADATA_NAME_TAG, size);

            XML_WriteStartTag(stream, SVG_METADATA_URL_TAG, FALSE, size);
            *size += stream ? STREAM_writeChunk(stream, (const BYTE*)SVG_METADATA_CREDITS_URL_VALUE, strlen(SVG_METADATA_CREDITS_URL_VALUE)) : strlen(SVG_METADATA_CREDITS_URL_VALUE);
            XML_WriteEndTag(stream, SVG_METADATA_URL_TAG, size);

            XML_WriteStartTag(stream, SVG_MATADATA_ROLE_TAG, FALSE, size);
            *size += stream ? STREAM_writeChunk(stream, (const BYTE*)SVG_METADATA_CREDITS_ROLE_VALUE, strlen(SVG_METADATA_CREDITS_ROLE_VALUE)) : strlen(SVG_METADATA_CREDITS_ROLE_VALUE);
            XML_WriteEndTag(stream, SVG_MATADATA_ROLE_TAG, size);
        }
        XML_WriteEndTag(stream, SVG_METADATA_CREDITS_TAG, size);

        XML_WriteStartTag(stream, SVG_METADATA_LICENSE_TAG, TRUE, size);
        {
            XML_WriteStartTag(stream, SVG_METADATA_URL_TAG, FALSE, size);
            *size += stream ? STREAM_writeChunk(stream, (const BYTE*)SVG_METADATA_LICENSE_URL_VALUE, strlen(SVG_METADATA_LICENSE_URL_VALUE)) : strlen(SVG_METADATA_LICENSE_URL_VALUE);
            XML_WriteEndTag(stream, SVG_METADATA_URL_TAG, size);
        }
        XML_WriteEndTag(stream, SVG_METADATA_LICENSE_TAG, size);

        XML_WriteStartTag(stream, SVG_METADATA_COPYRIGHT_TAG, FALSE, size);
        *size += stream ? STREAM_writeChunk(stream, (const BYTE*)XML_CDATA_BEGIN, strlen(XML_CDATA_BEGIN)) : strlen(XML_CDATA_BEGIN);
        SVG_WriteUTF8String(copyrightNotice, stream, size);
        *size += stream ? STREAM_writeChunk(stream, (const BYTE*)XML_CDATA_END, strlen(XML_CDATA_END)) : strlen(XML_CDATA_END);
        XML_WriteEndTag(stream, SVG_METADATA_COPYRIGHT_TAG, size);

        XML_WriteStartTag(stream, SVG_METADATA_TRADEMARK_TAG, FALSE, size);
        *size += stream ? STREAM_writeChunk(stream, (const BYTE*)XML_CDATA_BEGIN, strlen(XML_CDATA_BEGIN)) : strlen(XML_CDATA_BEGIN);
        SVG_WriteUTF8String(trademarkName, stream, size);
        *size += stream ? STREAM_writeChunk(stream, (const BYTE*)XML_CDATA_END, strlen(XML_CDATA_END)) : strlen(XML_CDATA_END);
        XML_WriteEndTag(stream, SVG_METADATA_TRADEMARK_TAG, size);

        XML_WriteStartTag(stream, SVG_METADATA_LICENSEE_TAG, TRUE, size);
        {
            XML_WriteStartTag(stream, SVG_METADATA_NAME_TAG, FALSE, size);
            *size += stream ? STREAM_writeChunk(stream, (const BYTE*)SVG_METADATA_LICENSEE_NAME_VALUE, strlen(SVG_METADATA_LICENSEE_NAME_VALUE)) : strlen(SVG_METADATA_LICENSEE_NAME_VALUE);
            XML_WriteEndTag(stream, SVG_METADATA_NAME_TAG, size);
        }
        XML_WriteEndTag(stream, SVG_METADATA_LICENSEE_TAG, size);
    }
    XML_WriteEndTag(stream, SVG_METADATA_TAG, size);

    return LF_ERROR_OK;
}

static LF_ERROR SVG_WriteFontFace(LF_FONT* lfFont, CHAR* fontID, LF_STREAM* stream, size_t* size)
{
    LF_ERROR error;
    BYTE panose[10];
    char panoseAttr[64];
    char ascentAttr[8];
    char descentAttr[8];
    char unitsAttr[8];

    error = OS2_getPanoseValues(lfFont, panose);
    if (error != LF_ERROR_OK)
        return error;

    UTILS_snprintf(panoseAttr, 64, "%d %d %d %d %d %d %d %d %d %d", panose[0], panose[1], panose[2], panose[3],
                   panose[4], panose[5], panose[6], panose[7], panose[8], panose[9]);

    UTILS_snprintf(ascentAttr, 8, "%d", HHEA_getAscender(lfFont));
    UTILS_snprintf(descentAttr, 8, "%d", HHEA_getDescender(lfFont));
    UTILS_snprintf(unitsAttr, 8, "%d", HEAD_getUnitsPerEM(lfFont));

    *size += stream ? STREAM_writeByte(stream, XML_CHAR_LT) : 1;
    *size += stream ? STREAM_writeChunk(stream, (const BYTE*)SVG_FONTFACE_TAG, strlen(SVG_FONTFACE_TAG)) : strlen(SVG_FONTFACE_TAG);
    *size += stream ? STREAM_writeByte(stream, XML_SPACE) : 1;
    *size += stream ? STREAM_writeChunk(stream, (const BYTE*)SVG_FONT_FAMILY_ATTRIBUTE, strlen(SVG_FONT_FAMILY_ATTRIBUTE)) : strlen(SVG_FONT_FAMILY_ATTRIBUTE);
    *size += stream ? STREAM_writeByte(stream, XML_EQUAL_SIGN) : 1;
    *size += stream ? STREAM_writeByte(stream, XML_CHAR_QUOTE) : 1;
    if (fontID != NULL)
        *size += stream ? STREAM_writeChunk(stream, (const BYTE*)fontID, strlen((const char*)fontID)) : strlen((const char*)fontID);
    else
    {
        USHORT fontFamily[MAX_POSTSCRIPT_NAME_LEN];

        error = SVG_GetNameString(lfFont, NAME_FONT_FAMILY_NAME, fontFamily, sizeof(fontFamily));
        if ((error == LF_ERROR_OK) && (fontFamily[0] == 0))
            error = SVG_GetNameString(lfFont, NAME_POSTSCRIPT_FONT_NAME, fontFamily, sizeof(fontFamily));
        if (error != LF_ERROR_OK)
            return error;

        SVG_WriteUTF8String(fontFamily, stream, size);
    }
    *size += stream ? STREAM_writeByte(stream, XML_CHAR_QUOTE) : 1;
    XML_WriteAttribute(stream, SVG_PANOSE_ATTRIBUTE, panoseAttr, size);
    XML_WriteAttribute(stream, SVG_ASCENT_ATTRIBUTE, ascentAttr, size);
    XML_WriteAttribute(stream, SVG_DESCENT_ATTRIBUTE, descentAttr, size);
    XML_WriteAttribute(stream, SVG_UNITS_ATTRIBUTE, unitsAttr, size);
    XML_WriteAttribute(stream, SVG_ALPHABETIC_ATTRIBUTE, "0", size);
    *size += stream ? STREAM_writeByte(stream, XML_CHAR_GT) : 1;
    *size += stream ? STREAM_writeByte(stream, XML_NEWLINE) : 1;

    XML_WriteEndTag(stream, SVG_FONTFACE_TAG, size);

    return LF_ERROR_OK;
}

static LF_ERROR SVG_WritePathData(LF_STREAM* stream, int firstIndex, int count, LF_VECTOR* points, size_t* size)
{
    LF_ERROR error = LF_ERROR_OK;
    int offset = 0;
    char outText[64];
    boolean endpoint = (boolean)(intptr_t)vector_at(points, (firstIndex * 4) + 3);

    if (endpoint == TRUE)
        return LF_ERROR_OK;

    while (offset < count)
    {
        SHORT x0 = (SHORT)(intptr_t)vector_at(points, ((firstIndex + offset % count) * 4) + 1);
        SHORT y0 = (SHORT)(intptr_t)vector_at(points, ((firstIndex + offset % count) * 4) + 2);
        SHORT x1 = (SHORT)(intptr_t)vector_at(points, ((firstIndex + (offset + 1) % count) * 4) + 1);
        SHORT y1 = (SHORT)(intptr_t)vector_at(points, ((firstIndex + (offset + 1) % count) * 4) + 2);
        SHORT x2 = (SHORT)(intptr_t)vector_at(points, ((firstIndex + (offset + 2) % count) * 4) + 1);
        SHORT y2 = (SHORT)(intptr_t)vector_at(points, ((firstIndex + (offset + 2) % count) * 4) + 2);

        boolean pt0_onCurve = (0 != ((intptr_t)vector_at(points, (firstIndex + offset % count) * 4) & FLAG_ON_CURVE)) ? TRUE : FALSE;
        boolean pt1_onCurve = (0 != ((intptr_t)vector_at(points, (firstIndex + (offset + 1) % count) * 4) & FLAG_ON_CURVE)) ? TRUE : FALSE;
        boolean pt2_onCurve = (0 != ((intptr_t)vector_at(points, (firstIndex + (offset + 2) % count) * 4) & FLAG_ON_CURVE)) ? TRUE : FALSE;

        // case 1: check starting point
        if (offset == 0)
        {
            sprintf(outText, "M%d %d", x0, y0);
            *size += stream ? STREAM_writeChunk(stream, (const BYTE*)outText, strlen(outText)) : strlen(outText);
        }
        
        // case 2: pt and pt+1 is in same curve
        if (pt0_onCurve && pt1_onCurve)
        {
            if (y0 == y1)
            {
                sprintf(outText, "H%d", x1);
            }
            else if (x0 == x1)
            {
                sprintf(outText, "V%d", y1);
            }
            else
            {
                sprintf(outText, "L%d %d", x1, y1);
            }

            *size += stream ? STREAM_writeChunk(stream, (const BYTE*)outText, strlen(outText)) : strlen(outText);
            offset++;
        }
        // case 3: pt is on curve, pt+1 is not on curve and pt+2 is on curve
        else if (pt0_onCurve && !pt1_onCurve && pt2_onCurve)
        {
            sprintf(outText, "Q%d %d %d %d", x1, y1, x2, y2);
            *size += stream ? STREAM_writeChunk(stream, (const BYTE*)outText, strlen(outText)) : strlen(outText);
            offset += 2;
        }
        // case 4: pt is on curve, pt+1 and pt+2 both not on the curve
        else if (pt0_onCurve && !pt1_onCurve && !pt2_onCurve)
        {
            sprintf(outText, "Q%d %d %d %d", x1, y1, SVG_MID_VALUE(x1, x2), SVG_MID_VALUE(y1, y2));
            *size += stream ? STREAM_writeChunk(stream, (const BYTE*)outText, strlen(outText)) : strlen(outText);
            offset += 2;
        }
        // case 5: pt and pt+1 both not on the curve
        else if (!pt0_onCurve && !pt1_onCurve)
        {
            sprintf(outText, "T%d %d", SVG_MID_VALUE(x0, x1), SVG_MID_VALUE(y0, y1));
            *size += stream ? STREAM_writeChunk(stream, (const BYTE*)outText, strlen(outText)) : strlen(outText);
            offset++;
        }
        // case 6: pt is not on curve and pt+1 is on curve
        else if (!pt0_onCurve && pt1_onCurve)
        {
            sprintf(outText, "T%d %d", x1, y1);
            *size += stream ? STREAM_writeChunk(stream, (const BYTE*)outText, strlen(outText)) : strlen(outText);
            offset++;
        }
        else
        {
            break;
        }
    }

    *size += stream ? STREAM_writeByte(stream, SVG_PATH_CLOSE) : 1;

    return error;
}

static LF_ERROR SVG_WritePathAttribute(LF_FONT* lfFont, glyf* glyfObject, LF_STREAM* stream, size_t* size)
{
    int count = 0;
    int firstIndex = 0;
    LF_VECTOR* points = vector_create(32, 32);

    GLYF_getGlyfPoints(lfFont, glyfObject, points);

    *size += stream ? STREAM_writeChunk(stream, (const BYTE*)" d=\"", 4) : 4;

    for (size_t i = 0; i < points->count; i += 4)
    {
        boolean endpoint = (boolean)(intptr_t)vector_at(points, i + 3);
        count++;

        if (endpoint == TRUE)
        {
            SVG_WritePathData(stream, firstIndex, count, points, size);
            firstIndex = (int)(i/4 + 1);
            count = 0;
        }
    }

    *size += stream ? STREAM_writeByte(stream, XML_CHAR_QUOTE) : 1;
    *size += stream ? STREAM_writeByte(stream, XML_SPACE) : 1;

    vector_free(points);
    free(points);

    return LF_ERROR_OK;
}

static LF_ERROR SVG_WriteGlyphData(LF_FONT* lfFont, GlyphID index, LF_STREAM* stream, size_t* size)
{
    LF_ERROR error;
    USHORT avgCharWidth;

    error = OS2_getAvgCharWidth(lfFont, &avgCharWidth);
    if (error == LF_ERROR_OK)
    {
        char horizAdvX[8];
        glyf glyfObject;
        USHORT advanceX = HMTX_getAdvanceWidth(lfFont, index);

        if (advanceX != avgCharWidth)
        {
            UTILS_snprintf(horizAdvX, 8, "%d", HMTX_getAdvanceWidth(lfFont, index));
            XML_WriteAttribute(stream, SVG_HORIZ_ADV_X_ATTRIBUTE, horizAdvX, size);
        }

        error = GLYF_getGlyph(lfFont, &glyfObject, index);
        if (error == LF_ERROR_OK)
        {
            if (glyfObject.numberOfContours != 0)
                error = SVG_WritePathAttribute(lfFont, &glyfObject, stream, size);

            GLYF_destroyGlyf(&glyfObject);
        }
    }

    return error;
}

static LF_ERROR SVG_WriteMissingGlyph(LF_FONT* lfFont, LF_STREAM* stream, size_t* size)
{
    *size += stream ? STREAM_writeByte(stream, XML_CHAR_LT) : 1;
    *size += stream ? STREAM_writeChunk(stream, (const BYTE*)SVG_MISSING_TAG, strlen(SVG_MISSING_TAG)) : strlen(SVG_MISSING_TAG);

    LF_ERROR error = SVG_WriteGlyphData(lfFont, 0, stream, size);

    *size += stream ? STREAM_writeChunk(stream, (const BYTE*)XML_CLOSE_TAG_NO_CHILDREN, strlen(XML_CLOSE_TAG_NO_CHILDREN)) : strlen(XML_CLOSE_TAG_NO_CHILDREN);
    *size += stream ? STREAM_writeByte(stream, XML_NEWLINE) : 1;
    *size += stream ? STREAM_writeByte(stream, XML_NEWLINE) : 1;

    return error;
}

static GlyphID SVG_getSubstituteGlyphID(gsub_single_substitution* substTable, GlyphID id)
{
    ULONG index = 0;

    if (substTable && Coverage_findGlyphIndex(&substTable->Coverage, id, &index) == LF_ERROR_OK)
    {
        if (substTable->SubstFormat == 1)
            return id + substTable->format.f1.DeltaGlyphID;

        if (substTable->SubstFormat == 2)
        {
            return (GlyphID)(intptr_t)vector_at(&substTable->format.f2.Substitute, index);
        }
    }

    return id;
}

static void SVG_EncodeEntity(ULONG charCode, char* outText, boolean upper)
{
    if (32 <= charCode && charCode <= 127)
    {
        switch (charCode)
        {
        case XML_CHAR_GT: strcpy(outText, XML_ENTITY_GT); break;
        case XML_CHAR_LT: strcpy(outText, XML_ENTITY_LT); break;
        case XML_CHAR_APOS: strcpy(outText, XML_ENTITY_APOS); break;
        case XML_CHAR_AMP: strcpy(outText, XML_ENTITY_AMP); break;
        case XML_CHAR_COMMA: strcpy(outText, XML_ENTITY_COMMA); break;
        case XML_CHAR_QUOTE: strcpy(outText, XML_ENTITY_QUOT); break;
        default: sprintf(outText, "%c", (char)charCode); break;
        }
    }
    else
    {
        if (upper)
            sprintf(outText, "%s%X;", XML_CHAR_REF_PREFIX, charCode);
        else
            sprintf(outText, "%s%x;", XML_CHAR_REF_PREFIX, charCode);
    }
}

static LF_ERROR SVG_WriteGlyph(LF_FONT* lfFont, const cmap_encoding* encodingRecord, GlyphID glyphID, ULONG charCode, const char* arabicForm, LF_STREAM* stream, size_t* size)
{
    LF_ERROR error = LF_ERROR_OK;
    char outText[16];

    *size += stream ? STREAM_writeByte(stream, XML_CHAR_LT) : 1;
    *size += stream ? STREAM_writeChunk(stream, (const BYTE*)SVG_GLYPH_TAG, strlen(SVG_GLYPH_TAG)) : strlen(SVG_GLYPH_TAG);

    SVG_EncodeEntity(charCode, outText, TRUE);

    XML_WriteAttribute(stream, SVG_UNICODE_ATTRIBUTE, outText, size);

    {
        CHAR* glyfName = POST_getGlyfNameFromIndex(lfFont, CMAP_getIndexFromUnicode(lfFont, encodingRecord, charCode, FALSE));

        if (glyfName != NULL)
            XML_WriteAttribute(stream, SVG_GLYPH_NAME_ATTRIBUTE, (const char*)glyfName, size);
    }

    if (arabicForm != NULL)
    {
        XML_WriteAttribute(stream, SVG_ARABIC_FORM_ATTRIBUTE, arabicForm, size);
    }

    if (glyphID != 0)
    {
        error = SVG_WriteGlyphData(lfFont, glyphID, stream, size);
    }

    if (error == LF_ERROR_OK)
    {
        *size += stream ? STREAM_writeChunk(stream, (const BYTE*)XML_CLOSE_TAG_NO_CHILDREN, strlen(XML_CLOSE_TAG_NO_CHILDREN)) : strlen(SVG_GLYPH_TAG);
        *size += stream ? STREAM_writeByte(stream, XML_NEWLINE) : 1;
    }

    return error;
}

static LF_ERROR SVG_WriteGlyphSubst(LF_FONT* lfFont, const cmap_encoding* encodingRecord, ULONG charCode,
                                    gsub_single_substitution* initialSubst, gsub_single_substitution* medialSubst,
                                    gsub_single_substitution* finalSubst, LF_STREAM* stream, size_t* size)
{
    LF_ERROR error;
    GlyphID glyphID = CMAP_getIndexFromUnicode(lfFont, encodingRecord, charCode, TRUE);

    if ((charCode != CHARACTER_CODE_NEWLINE) && (charCode != CHARACTER_CODE_CARRIAGE_RETURN) && (glyphID == 0))
        return LF_ERROR_OK;

    GlyphID initialIndex = SVG_getSubstituteGlyphID(initialSubst, glyphID);
    GlyphID medialIndex = SVG_getSubstituteGlyphID(medialSubst, glyphID);
    GlyphID finalIndex = SVG_getSubstituteGlyphID(finalSubst, glyphID);
    boolean substitute = FALSE;

    if (initialIndex != glyphID)
    {
        error = SVG_WriteGlyph(lfFont, encodingRecord, initialIndex, charCode, SVG_INITIAL_VALUE, stream, size);
        if (error != LF_ERROR_OK)
            return error;
        substitute = TRUE;
    }

    if (medialIndex != glyphID)
    {
        error = SVG_WriteGlyph(lfFont, encodingRecord, medialIndex, charCode, SVG_MEDIAL_VALUE, stream, size);
        if (error != LF_ERROR_OK)
            return error;
        substitute = TRUE;
    }

    if (finalIndex != glyphID)
    {
        error = SVG_WriteGlyph(lfFont, encodingRecord, finalIndex, charCode, SVG_FINAL_VALUE, stream, size);
        if (error != LF_ERROR_OK)
            return error;
        substitute = TRUE;
    }

    if (substitute)
    {
        error = SVG_WriteGlyph(lfFont, encodingRecord, glyphID, charCode, SVG_ISOLATED_VALUE, stream, size);
    }
    else
    {
        error = SVG_WriteGlyph(lfFont, encodingRecord, glyphID, charCode, NULL, stream, size);
    }

    return error;
}

static LF_ERROR SVG_WriteTextElement(LF_FONT* lfFont, USHORT* text, int yPos, LF_STREAM* stream, size_t* size)
{
    char yAttributeValue[16];
    USHORT fontFamily[MAX_POSTSCRIPT_NAME_LEN];

    LF_ERROR error = SVG_GetNameString(lfFont, NAME_FONT_FAMILY_NAME, fontFamily, sizeof(fontFamily));
    if ((error == LF_ERROR_OK) && (fontFamily[0] == 0))
        error = SVG_GetNameString(lfFont, NAME_POSTSCRIPT_FONT_NAME, fontFamily, sizeof(fontFamily));

    sprintf(yAttributeValue, "%d", yPos);

    *size += stream ? STREAM_writeByte(stream, XML_CHAR_LT) : 1;
    *size += stream ? STREAM_writeChunk(stream, (const BYTE*)SV_TEXT_TAG, strlen(SV_TEXT_TAG)) : strlen(SV_TEXT_TAG);
    XML_WriteAttribute(stream, SVG_X_ATTRIBUTE, SVG_X_ATTRIBUTE_VALUE, size);
    XML_WriteAttribute(stream, SVG_Y_ATTRIBUTE, yAttributeValue, size);
    *size += stream ? STREAM_writeByte(stream, XML_SPACE) : 1;
    *size += stream ? STREAM_writeChunk(stream, (const BYTE*)SVG_FONT_FAMILY_ATTRIBUTE, strlen(SVG_FONT_FAMILY_ATTRIBUTE)) : strlen(SVG_FONT_FAMILY_ATTRIBUTE);
    *size += stream ? STREAM_writeByte(stream, XML_EQUAL_SIGN) : 1;
    *size += stream ? STREAM_writeByte(stream, XML_CHAR_QUOTE) : 1;
    SVG_WriteUTF8String(fontFamily, stream, size);
    *size += stream ? STREAM_writeByte(stream, XML_CHAR_QUOTE) : 1;
    XML_WriteAttribute(stream, SVG_FONT_SIZE_ATTRIBUTE, SVG_FONT_SIZE_ATTRIBUTE_VALUE, size);
    XML_WriteAttribute(stream, SVG_FILL_ATTRIBUTE, SVG_FILL_ATTRIBUTE_VALUE, size);
    *size += stream ? STREAM_writeByte(stream, XML_CHAR_GT) : 1;

#if defined(OS_MACOSX)
    *size += stream ? STREAM_writeChunk(stream, (const BYTE*)text, strlen((const char*)text)) : strlen((const char*)text);
#else
    SVG_WriteUTF8String(text, stream, size);
#endif
    
    *size += stream ? STREAM_writeChunk(stream, (const BYTE*)XML_END_TAG, strlen(XML_END_TAG)) : strlen(XML_END_TAG);
    *size += stream ? STREAM_writeChunk(stream, (const BYTE*)SV_TEXT_TAG, strlen(SV_TEXT_TAG)) : strlen(SV_TEXT_TAG);
    *size += stream ? STREAM_writeByte(stream, XML_CHAR_GT) : 1;
    *size += stream ? STREAM_writeByte(stream, XML_NEWLINE) : 1;

    return error;
}

#define CMAP_encodingFormat(e) (*(USHORT*)((e)->subtable))
#define CMAP_format4(e) ((cmap_format_4*)((e)->subtable))

static LF_ERROR SVG_WriteUnicodeList(LF_VECTOR* uniVec, LF_STREAM* stream, size_t* size)
{
    *size += stream ? STREAM_writeByte(stream, XML_CHAR_QUOTE) : 1;

    for (size_t i = 0; i < uniVec->count; i++)
    {
        char outText[16];

        ULONG unicode = (ULONG)(intptr_t)vector_at(uniVec, i);

        SVG_EncodeEntity(unicode, outText, FALSE);
        *size += stream ? STREAM_writeChunk(stream, (const BYTE*)outText, strlen(outText)) : strlen(outText);

        if (i != uniVec->count-1)
            *size += stream ? STREAM_writeByte(stream, XML_CHAR_COMMA) : 1;
    }

    *size += stream ? STREAM_writeByte(stream, XML_CHAR_QUOTE) : 1;

    return LF_ERROR_OK;
}

static void SVG_cleanupInverseCMAP(LF_MAP* inverseCmap)
{
    LF_MAP_ITER* iter = map_begin(inverseCmap);
    if (iter != NULL)
    {
        rb_tree_node* node = map_next(iter);

        while (node != NULL)
        {
            LF_VECTOR* vec = (LF_VECTOR*)node->data;

            vector_delete(vec);
            free(vec);

            node = map_next(iter);
        }

        map_free_iter(iter);
    }
    map_clear(inverseCmap);
}

static LF_ERROR SVG_createInverseCMAP(LF_FONT* lfFont, LF_MAP* inverseCmap)
{
    map_init(inverseCmap, integer_compare);

    cmap_header* header = (cmap_header*)map_at(&lfFont->table_map, (void*)TAG_CMAP);
    cmap_encoding* encodingRecord = NULL;

    for (size_t i = 0; i < header->encodings.count; i++)
    {
        cmap_encoding* encoding = (cmap_encoding*)vector_at(&header->encodings, i);

        if ((encoding->platformID == 3) && (encoding->encodingID == 1))
        {
            encodingRecord = encoding;
            break;
        }
    }

    if (encodingRecord == NULL)
        return LF_INVALID_PARAM;

    LF_ERROR error;

    USHORT format = CMAP_encodingFormat(encodingRecord);

    if (format != 4)
        return LF_UNSUPPORTED;

    for (ULONG unicode = 0; unicode < 65536; unicode++)
    {
        GlyphID gid = CMAP_format4(encodingRecord)->forwardMap[unicode];
        gid = (GlyphID)header->gidMappingArray[gid];

        if (gid != 0)
        {
            if (map_key_exists(inverseCmap, (void*)(intptr_t)gid))
            {
                LF_VECTOR* vec = (LF_VECTOR*)map_at(inverseCmap, (void*)(intptr_t)gid);

                error = vector_push_back(vec, (void*)(intptr_t)unicode);

                if (error != LF_ERROR_OK)
                {
                    SVG_cleanupInverseCMAP(inverseCmap);
                    return error;
                }
            }
            else
            {
                LF_VECTOR* uniVec = vector_create(1, 1);
                if (uniVec == NULL)
                {
                    SVG_cleanupInverseCMAP(inverseCmap);
                    return LF_OUT_OF_MEMORY;
                }

                error = vector_push_back(uniVec, (void*)(intptr_t)unicode);
                if (error != LF_ERROR_OK)
                {
                    SVG_cleanupInverseCMAP(inverseCmap);
                    return error;
                }

                if (NULL == map_insert(inverseCmap, (void*)(intptr_t)gid, (void*)uniVec))
                {
                    SVG_cleanupInverseCMAP(inverseCmap);
                    return LF_OUT_OF_MEMORY;
                }
            }
        }
    }

    return LF_ERROR_OK;
}

static LF_ERROR SVG_WriteKernPairs(LF_FONT* lfFont, LF_STREAM* stream, size_t* size)
{
    kern_table_header* header = (kern_table_header*)map_at(&lfFont->table_map, (void*)TAG_KERN);

    if (header != NULL)
    {
        // First see if there is at least one version 0 sub-table, otherwise there is nothing
        // to do since only format 0 is supported
        size_t i;
        for (i = 0; i < header->nTables; ++i)
        {
            kern_subtable* subTable = (kern_subtable*)vector_at(&header->subtables, i);
            if (subTable->header.version == 0)
                break;
        }
        if (i == header->nTables)
            return LF_ERROR_OK;

        // Create an inverse cmap, where key = glyphID data = vector of Unicodes
        LF_MAP inverseCmap;

        LF_ERROR error = SVG_createInverseCMAP(lfFont, &inverseCmap);
        if (error != LF_ERROR_OK)
            return error;

        char outText[16];

        *size += stream ? STREAM_writeByte(stream, XML_NEWLINE) : 1;

        for (i = 0; i < header->nTables; ++i)
        {
            kern_subtable* subTable = (kern_subtable*)vector_at(&header->subtables, i);

            if (subTable->header.version != 0)
                continue;

            for (size_t j = 0; j < subTable->info.f0.pairs.count; ++j)
            {
                kern_pair* kernPair = (kern_pair*)vector_at(&subTable->info.f0.pairs, j);

                // Write the pair to the file only if there is a Unicode for both the left and right GIDs
                if ((TRUE == map_key_exists(&inverseCmap, (void*)(intptr_t)kernPair->left)) &&
                    (TRUE == map_key_exists(&inverseCmap, (void*)(intptr_t)kernPair->right)))
                {
                    *size += stream ? STREAM_writeByte(stream, XML_CHAR_LT) : 1;
                    *size += stream ? STREAM_writeChunk(stream, (const BYTE*)SV_HKERN_TAG, strlen(SV_HKERN_TAG)) : strlen(SV_HKERN_TAG);
                    *size += stream ? STREAM_writeByte(stream, XML_SPACE) : 1;
                    *size += stream ? STREAM_writeChunk(stream, (const BYTE*)SVG_U1_ATTRIBUTE, strlen(SVG_U1_ATTRIBUTE)) : strlen(SVG_U1_ATTRIBUTE);

                    LF_VECTOR* uniVec = (LF_VECTOR*)map_at(&inverseCmap, (void*)(intptr_t)kernPair->left);
                    SVG_WriteUnicodeList(uniVec, stream, size);

                    *size += stream ? STREAM_writeByte(stream, XML_SPACE) : 1;
                    *size += stream ? STREAM_writeChunk(stream, (const BYTE*)SVG_U2_ATTRIBUTE, strlen(SVG_U2_ATTRIBUTE)) : strlen(SVG_U2_ATTRIBUTE);

                    uniVec = (LF_VECTOR*)map_at(&inverseCmap, (void*)(intptr_t)kernPair->right);
                    SVG_WriteUnicodeList(uniVec, stream, size);

                    *size += stream ? STREAM_writeByte(stream, XML_SPACE) : 1;

                    sprintf(outText, "k=\"%d\"", kernPair->value * -1);
                    *size += stream ? STREAM_writeChunk(stream, (const BYTE*)outText, strlen(outText)) : strlen(outText);

                    *size += stream ? STREAM_writeChunk(stream, (const BYTE*)XML_CLOSE_TAG_NO_CHILDREN, strlen(XML_CLOSE_TAG_NO_CHILDREN)) : strlen(XML_CLOSE_TAG_NO_CHILDREN);
                    *size += stream ? STREAM_writeByte(stream, XML_NEWLINE) : 1;
                }
            }
        }

        *size += stream ? STREAM_writeByte(stream, XML_NEWLINE) : 1;

        SVG_cleanupInverseCMAP(&inverseCmap);
    }

    return LF_ERROR_OK;
}

static LF_ERROR SVG_WriteFont(LF_FONT* lfFont, CHAR* fontID, LF_STREAM* stream, size_t* size)
{
    LF_ERROR error;
    USHORT avgCharWidth = 0;
    char horizAdvX[32];
    script_table* scriptTable;
    gsub_single_substitution* initialSubst = NULL;
    gsub_single_substitution* medialSubst = NULL;
    gsub_single_substitution* finalSubst = NULL;
    const cmap_encoding* encodingRecord;

    // font must have a 3,1 or 3,0 in order to create an svg (to match behavior of FontConverter)
    error = CMAP_hasEncoding(lfFont, 3, 1);
    if (error != LF_ERROR_OK)
    {
        error = CMAP_hasEncoding(lfFont, 3, 0);
        if (error != LF_ERROR_OK)
            return LF_UNSUPPORTED;
    }

    USHORT minCode, maxCode;
    error = CMAP_getMinMaxRemappedUnicodes(lfFont, &minCode, &maxCode);
    if (error != LF_ERROR_OK)
        return error;
    if (maxCode == 0)
        return LF_UNSUPPORTED;

    scriptTable = GSUB_getScriptTable(lfFont, GSUB_SCRIPT_TAG_ARAB);
    if (scriptTable != NULL)
    {
        if (scriptTable->DefaultLangSys != NULL)
        {
            TABLE_HANDLE table = NULL;
            feature_table* initialFeature = GSUB_getFeatureTable(lfFont, scriptTable->DefaultLangSys, GSUB_FEATURE_SCRIPT_TAG_INITIAL);
            feature_table* medialFeature = GSUB_getFeatureTable(lfFont, scriptTable->DefaultLangSys, GSUB_FEATURE_SCRIPT_TAG_MEDIAL);
            feature_table* finalFeature = GSUB_getFeatureTable(lfFont, scriptTable->DefaultLangSys, GSUB_FEATURE_SCRIPT_TAG_FINAL);

            if (initialFeature)
            {
                lookup_table* initialLookup = GSUB_getLookupTable(lfFont, initialFeature, 0);

                table = vector_at(&initialLookup->SubTables, 0);
                if (BaseTable_getSubType(table) == SUBTABLE_TYPE_GSUB_SINGLE)
                    initialSubst = table;
            }

            if (medialFeature)
            {
                lookup_table* medialLookup = GSUB_getLookupTable(lfFont, medialFeature, 0);

                table = vector_at(&medialLookup->SubTables, 0);
                if (BaseTable_getSubType(table) == SUBTABLE_TYPE_GSUB_SINGLE)
                    medialSubst = table;
            }

            if (finalFeature)
            {
                lookup_table* finalLookup = GSUB_getLookupTable(lfFont, finalFeature, 0);

                table = vector_at(&finalLookup->SubTables, 0);
                if (BaseTable_getSubType(table) == SUBTABLE_TYPE_GSUB_SINGLE)
                    finalSubst = table;
            }
        }
    }

    encodingRecord = CMAP_getEncodingRecord(lfFont, 0, 3);
    if (encodingRecord == NULL)
    {
        encodingRecord = CMAP_getEncodingRecord(lfFont, 3, 1);
        if (encodingRecord == NULL)
        {
            encodingRecord = CMAP_getEncodingRecord(lfFont, 3, 0);
            if (encodingRecord == NULL)
            {
                encodingRecord = CMAP_getEncodingRecord(lfFont, 0, 4);
            }
        }
    }

    if (encodingRecord == NULL)
        return LF_UNSUPPORTED;

    error = OS2_getAvgCharWidth(lfFont, &avgCharWidth);
    if (error != LF_ERROR_OK)
        return error;

    sprintf(horizAdvX, "%d", avgCharWidth);

    *size += stream ? STREAM_writeByte(stream, XML_CHAR_LT) : 1;
    *size += stream ? STREAM_writeChunk(stream, (const BYTE*)SVG_FONT_TAG, strlen(SVG_FONT_TAG)) : strlen(SVG_FONT_TAG);
    XML_WriteAttribute(stream, SVG_HORIZ_ADV_X_ATTRIBUTE, horizAdvX, size);
    *size += stream ? STREAM_writeByte(stream, XML_SPACE) : 1;
    *size += stream ? STREAM_writeChunk(stream, (const BYTE*)XML_ID_ATTRIBUTE, strlen(XML_ID_ATTRIBUTE)) : strlen(XML_ID_ATTRIBUTE);
    *size += stream ? STREAM_writeByte(stream, XML_EQUAL_SIGN) : 1;
    *size += stream ? STREAM_writeByte(stream, XML_CHAR_QUOTE) : 1;
    if (fontID != NULL)
        *size += stream ? STREAM_writeChunk(stream, (const BYTE*)fontID, strlen((const char*)fontID)) : strlen((const char*)fontID);
    else
    {
        USHORT familyName[MAX_POSTSCRIPT_NAME_LEN] = {0};

        error = SVG_GetNameString(lfFont, NAME_FONT_FAMILY_NAME, familyName, sizeof(familyName));
        if ((error == LF_ERROR_OK) && (familyName[0] == 0))
            error = SVG_GetNameString(lfFont, NAME_POSTSCRIPT_FONT_NAME, familyName, sizeof(familyName));
        if (error != LF_ERROR_OK)
            return error;

        SVG_WriteUTF8String(familyName, stream, size);
    }
    *size += stream ? STREAM_writeByte(stream, XML_CHAR_QUOTE) : 1;
    *size += stream ? STREAM_writeByte(stream, XML_CHAR_GT) : 1;
    *size += stream ? STREAM_writeByte(stream, XML_NEWLINE) : 1;

    error = SVG_WriteFontFace(lfFont, fontID, stream, size);
    if (error != LF_ERROR_OK)
        return error;

    error = SVG_WriteMissingGlyph(lfFont, stream, size);
    if (error != LF_ERROR_OK)
        return error;

    error = SVG_WriteGlyphSubst(lfFont, encodingRecord, CHARACTER_CODE_NEWLINE, NULL, NULL, NULL, stream, size);
    if (error != LF_ERROR_OK)
        return error;

    error = SVG_WriteGlyphSubst(lfFont, encodingRecord, CHARACTER_CODE_CARRIAGE_RETURN, NULL, NULL, NULL, stream, size);
    if (error != LF_ERROR_OK)
        return error;

    if (minCode < CHARACTER_CODE_SPACE)
        minCode = CHARACTER_CODE_SPACE;

    for (ULONG i = minCode; i <= maxCode; ++i)
    {
        error = SVG_WriteGlyphSubst(lfFont, encodingRecord, i, initialSubst, medialSubst, finalSubst, stream, size);
        if (error != LF_ERROR_OK)
            break;
    }

    if (error == LF_ERROR_OK)
    {
        error = SVG_WriteKernPairs(lfFont, stream, size);
        if (error == LF_ERROR_OK)
            error = XML_WriteEndTag(stream, SVG_FONT_TAG, size);
    }

    return error;
}

static LF_ERROR SVG_WriteDefs(LF_FONT* lfFont, CHAR* fontID, LF_STREAM* stream, size_t* size)
{
    XML_WriteStartTag(stream, SVG_DEFS_TAG, TRUE, size);

    LF_ERROR error = SVG_WriteFont(lfFont, fontID, stream, size);

    if (error == LF_ERROR_OK)
        XML_WriteEndTag(stream, SVG_DEFS_TAG, size);

    return error;
}

static LF_ERROR SVG_parseTables(LF_FONT* lfFont)
{
    LF_ERROR error;

    /* make sure we have unpacked the tables as we need to access them */
    if (map_empty(&lfFont->table_map))
    {
        error = SFNT_unpackTables(lfFont);
        if (error != LF_ERROR_OK)
            return error;
    }

    error = NAME_parseTable(lfFont);
    if (error != LF_ERROR_OK)
        return error;

    size_t ignore;
    error = CMAP_getTableSize(lfFont, &ignore);
    if (error != LF_ERROR_OK)
        return error;

    error = GLYF_remapTable(lfFont);

    return error;
}

LF_ERROR SVG_writeToStream(LF_FONT* lfFont, LF_WRITE_PARAMS *params, LF_STREAM* stream, size_t* size)
{
    UNUSED(params);

    LF_ERROR error;

    error = SVG_parseTables(lfFont);

    if (error == LF_ERROR_OK)
    {
        /* write out the XML declaration */
        XML_WriteXMLDeclaration(stream, XML_VERSION_10, XML_ENCODING, "yes", size);
        XML_WriteXMLDocumentType(stream, "svg", SVG_PUBLIC_ID, SVG_SYSTEM_ID, size);

        /* write out the SVG begin tag */
        *size += stream ? STREAM_writeChunk(stream, (const BYTE*)SVG_SVG_TAG_BEGIN, strlen(SVG_SVG_TAG_BEGIN)) : strlen(SVG_SVG_TAG_BEGIN);
        XML_WriteAttribute(stream, XMLNS_PREFIX, SVG_NAMESPACE_URI, size);
        *size += stream ? STREAM_writeChunk(stream, (const BYTE*)">\n", 2) : 2;

        error = SVG_WriteMetaData(lfFont, stream, size);

        if (error == LF_ERROR_OK)
        {
            error = SVG_WriteDefs(lfFont, (0 != strlen(params->svgID)) ? (CHAR*)params->svgID : NULL, stream, size);

            if (error == LF_ERROR_OK)
            {
                SVG_WriteTextElement(lfFont, (USHORT*)SVG_SAMPLE_TEXT_1, SVG_Y_ATTRIBUTE_VALUE, stream, size);
                SVG_WriteTextElement(lfFont, (USHORT*)SVG_SAMPLE_TEXT_2, SVG_Y_ATTRIBUTE_VALUE * 2, stream, size);
                SVG_WriteTextElement(lfFont, (USHORT*)SVG_SAMPLE_TEXT_3, SVG_Y_ATTRIBUTE_VALUE * 3, stream, size);
                SVG_WriteTextElement(lfFont, (USHORT*)SVG_SAMPLE_TEXT_4, SVG_Y_ATTRIBUTE_VALUE * 4, stream, size);

                /* write out the SVG end tag */
                *size += stream ? STREAM_writeChunk(stream, (const BYTE*)SVG_SVG_TAG_END, strlen(SVG_SVG_TAG_END)) : strlen(SVG_SVG_TAG_END);
            }
        }
    }

    return error;
}

LF_ERROR SVG_getMaxSize(LF_FONT* lfFont, LF_WRITE_PARAMS *params, size_t* size)
{
    *size = 0;

    return SVG_writeToStream(lfFont, params, NULL, size);
}
