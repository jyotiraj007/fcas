// Copyright (C) 2016 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// cblc_table.c

#include "cblc_table.h"
#include "eblc_table.h"
#include "table_tags.h"
#include "utils.h"

LF_ERROR CBLC_readTable(LF_FONT* lfFont, const sfnt_table_record* record, LF_STREAM* stream)
{
    if (record->length == 0)
        return LF_BAD_FORMAT;

    if (STREAM_streamSeek(stream, record->offset) != 0)
        return LF_INVALID_OFFSET;

    cblc_table* table = (cblc_table*)calloc(1, sizeof(cblc_table));
    if (table == NULL)
        return LF_OUT_OF_MEMORY;

    LF_ERROR error = EBLC_parseTable(table, record, stream);

    if (error == LF_ERROR_OK)
        map_insert(&lfFont->table_map, (void*)(intptr_t)record->tag, table);

    return error;
}

LF_ERROR CBLC_removeGlyph(const LF_FONT* lfFont, ULONG index)
{
    cblc_table* table = (cblc_table*)map_at(&lfFont->table_map, (void*)TAG_CBLC);

    return EBLC_internalRemoveGlyph(table, index);
}

LF_ERROR CBLC_remapTable(LF_FONT* lfFont, LF_MAP *remap)
{
    cblc_table* table = (cblc_table*)map_at(&lfFont->table_map, (void*)TAG_CBLC);

    return EBLC_internalRemap(lfFont, table, remap);
}

LF_ERROR CBLC_updateMetrics(LF_FONT* lfFont)
{
    cblc_table* table = (cblc_table*)map_at(&lfFont->table_map, (void*)TAG_CBLC);

    embedded_data_table* dataTable = (embedded_data_table*)map_at(&lfFont->table_map, (void*)TAG_CBDT);

    return EBLC_internalUpdate(table, dataTable);
}

LF_ERROR CBLC_getTableSize(LF_FONT* lfFont, size_t* tableSize)
{
    cblc_table* table = (cblc_table*)map_at(&lfFont->table_map, (void*)TAG_CBLC);

    return EBLC_internalGetSize(table, tableSize);
}

LF_ERROR CBLC_writeTable(LF_FONT* lfFont, sfnt_table_record* record, LF_STREAM* stream)
{
    size_t tableSize;
    BYTE* tableData;

    cblc_table* table = (cblc_table*)map_at(&lfFont->table_map, (void*)TAG_CBLC);
    if (table == NULL)
        return LF_TABLE_MISSING;

    embedded_data_table* dataTable = (embedded_data_table*)map_at(&lfFont->table_map, (void*)TAG_CBDT);
    if (dataTable == NULL)
        return LF_TABLE_MISSING;

    LF_ERROR error = EBLC_buildTable(table, dataTable, table->version, &tableData, &tableSize);
    if (error != LF_ERROR_OK)
        return error;

    record->checkSum = UTILS_CalcTableChecksum(tableData, tableSize);
    record->length = (ULONG)tableSize;
    record->offset = (ULONG)STREAM_streamPos(stream);

    STREAM_writeChunk(stream, tableData, (tableSize + 3) & ~3);
    free(tableData);

    return LF_ERROR_OK;
}

LF_ERROR CBLC_freeTable(LF_FONT* lfFont)
{
    cblc_table* table = (cblc_table*)map_at(&lfFont->table_map, (void*)TAG_CBLC);

    if (table != NULL)
    {
        EBLC_freeStrikes(table);
        vector_free(&table->bitmapSizeTables);
        free(table);
    }

    return LF_ERROR_OK;
}
