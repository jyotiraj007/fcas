// Copyright (C) 2014 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// hdmx_table.c

#include <stdlib.h>
#include "hdmx_table.h"
#include "utils.h"
#include "maxp_table.h"
#include "table_tags.h"

#define HDMX_INVALID_GLYPH      0x8000

#define HDMX_isValid(w) (((w) & HDMX_INVALID_GLYPH) ? LF_INVALID_TYPE : LF_ERROR_OK)


static void HDMX_cleanupDeviceRecords(hdmx_table *table)
{
    USHORT i;

    for(i = 0; i < table->numRecords; i++)
    {
        device_record *dr = (device_record *)vector_at(&table->deviceRecordList, i);

        ASSERT(dr);
        if (dr)
        {
            free(dr->widthsArray);
            free(dr);
        }
    }
} //lint !e429 In the current implementation the table itself is freed subsequent to calls to this function

LF_ERROR HDMX_readTable(LF_FONT* lfFont, const sfnt_table_record* record, LF_STREAM* stream)
{
    if(STREAM_streamSeek(stream, record->offset) == 0)
    {
        USHORT j, numGlyphs;
        ULONG deviceRecordPadding;
        LF_ERROR err;
        LONG i;
        hdmx_table* table;

        numGlyphs = MAXP_getNumGlyphs(lfFont);
        if(numGlyphs == 0)
            return LF_BAD_FORMAT;

        table = (hdmx_table *)malloc(sizeof(hdmx_table));
        if(table == NULL)
            return LF_OUT_OF_MEMORY;

        // read the header
        table->version            = STREAM_readUShort(stream);
        table->numRecords         = STREAM_readShort(stream);
        table->sizeDeviceRecord   = (LONG)STREAM_readULong(stream);

        err = vector_init(&table->deviceRecordList, table->numRecords, 1);
        if(err != LF_ERROR_OK)
        {
            free(table);
            return err;
        }

        deviceRecordPadding = (ULONG)(table->sizeDeviceRecord - (2 /* version and maxWidth */+ numGlyphs /* widths */));

        // read the device records
        for(i = 0; i < table->numRecords; i++)
        {
            BYTE *origData;
            device_record* dr = (device_record *)malloc(sizeof(device_record));
            if(dr == NULL)
            {
                HDMX_cleanupDeviceRecords(table);
                vector_delete(&table->deviceRecordList);
                free(table);
                return LF_OUT_OF_MEMORY;
            }

            dr->totalGlyphs = dr->widthsArrayLen = numGlyphs;
            dr->pixelSize = STREAM_readByte(stream);
            dr->maxWidth = STREAM_readByte(stream);

            origData = STREAM_readChunk(stream, numGlyphs);
            if (origData == NULL)
            {
                free(dr);
                HDMX_cleanupDeviceRecords(table);
                vector_delete(&table->deviceRecordList);
                free(table);
                return LF_OUT_OF_MEMORY;
            }

            dr->widthsArray = (USHORT*)malloc(numGlyphs * sizeof(USHORT));
            if (dr->widthsArray == NULL)
            {
                free(dr);
                HDMX_cleanupDeviceRecords(table);
                vector_delete(&table->deviceRecordList);
                free(table);
                free(origData);
                return LF_OUT_OF_MEMORY;
            }

            for (j = 0; j < numGlyphs; ++j)
                dr->widthsArray[j] = (USHORT)origData[j];

            free(origData);

            if(deviceRecordPadding != 0)
            {
                size_t pos = STREAM_streamPos(stream);
                STREAM_streamSeek(stream, pos + deviceRecordPadding);
            }

            vector_push_back(&table->deviceRecordList, (void*)dr);
        }

        map_insert(&lfFont->table_map, (void*)(intptr_t)record->tag, table);

        return LF_ERROR_OK;
    }

    return LF_INVALID_OFFSET;
}

static USHORT HDMX_GetNumGlyphs(hdmx_table* table)
{
    device_record* dr = (device_record *)vector_at(&table->deviceRecordList, 0);
    ASSERT(dr);

    return (USHORT)(dr ? (USHORT)dr->totalGlyphs : 0);
    //  return (USHORT)(dr ? map_size(&dr->widthsMap) : 0);
}

LF_ERROR HDMX_getTableSize(LF_FONT* lfFont, size_t* tableSize)
{
    USHORT numGlyphs;
    size_t deviceRecordSize;
    hdmx_table* table;

    *tableSize = 0;

    table = (hdmx_table*)map_at(&lfFont->table_map, (void*)TAG_HDMX);
    if(table == NULL)
        return LF_EMPTY_TABLE;

    numGlyphs = HDMX_GetNumGlyphs(table);

    *tableSize  = 8; /* 2 + 2 + 4 (version, numRecords, sizeDeviceRecord) */

    deviceRecordSize = 1 + 1 + numGlyphs;   /* pixelSize, maxWidths, widths */
    deviceRecordSize = (deviceRecordSize  + 3) & ~3;

    *tableSize += table->numRecords * deviceRecordSize;

    return LF_ERROR_OK;
}

static LF_ERROR HDMX_calculateMaxWidths(hdmx_table* table)
{
    USHORT i;

    for (i = 0; i < table->numRecords; i++)
    {
        ULONG n;
        device_record* dr = (device_record *)vector_at(&table->deviceRecordList, i);

        ASSERT(dr);
        if (NULL == dr)
            return LF_BAD_FORMAT;

        dr->maxWidth = 0;

        // calculate the maximum width
        for (n = 0; n < dr->widthsArrayLen; n++)
        {
            USHORT data = (USHORT)dr->widthsArray[n];

            if (HDMX_isValid(data) == LF_ERROR_OK)
            {
                if ((BYTE)data > dr->maxWidth)
                    dr->maxWidth = (BYTE)data;
            }
        }
    }

    return LF_ERROR_OK;
}

static BYTE* HDMX_buildTable(hdmx_table* table, ULONG* tableSize)
{
    USHORT numGlyphs;
    USHORT numPadBytes, deviceRecordSize;
    SHORT i;
    BYTE* tableData;
    LF_STREAM stream;

    *tableSize = 0;

    if(HDMX_calculateMaxWidths(table) != LF_ERROR_OK)
        return NULL;

    // calculate table size
    numGlyphs = HDMX_GetNumGlyphs(table);

    *tableSize  += 8; /* 2 + 2 + 4 (version, numRecords, sizeDeviceRecord) */

    deviceRecordSize = 1 + 1 + numGlyphs;   /* pixelSize, maxWidths, widths */

    numPadBytes = deviceRecordSize;
    deviceRecordSize = (deviceRecordSize  + 3) & ~3;
    numPadBytes = deviceRecordSize - numPadBytes;

    *tableSize += table->numRecords * deviceRecordSize;

    size_t paddedSize = *tableSize;
    tableData = UTILS_AllocTable(&paddedSize);
    if(tableData == NULL)
    {
        DEBUG_LOG_ERROR("allocation failure in HDMX_buildTable");
        return NULL;
    }

    STREAM_initMemStream(&stream, tableData, *tableSize);

    // write header
    STREAM_writeUShort(&stream, table->version);
    STREAM_writeShort(&stream, table->numRecords);
    STREAM_writeULong(&stream, deviceRecordSize);

    // write device records
    for(i = 0; i < table->numRecords; i++)
    {
        ULONG n;
        device_record* dr = (device_record *)vector_at(&table->deviceRecordList, i);
        ASSERT(dr);
        
        if (NULL == dr)
        {
            free(tableData);
            return NULL;
        }

        STREAM_writeByte(&stream, dr->pixelSize);
        STREAM_writeByte(&stream, dr->maxWidth);

        for (n = 0; n < dr->widthsArrayLen; n++)
        {
            USHORT data = dr->widthsArray[n];
            if (HDMX_isValid(data) == LF_ERROR_OK)
            {
                BYTE  width = (BYTE)data;
                STREAM_writeByte(&stream, width);
            }
        }

        if(numPadBytes != 0)
        {
            for (n = 0; n < numPadBytes; n++)
                STREAM_writeByte(&stream, 0);
        }
    }

    return tableData;
}

LF_ERROR HDMX_writeTable(LF_FONT* lfFont, sfnt_table_record* record, LF_STREAM* stream)
{
    USHORT numGlyphs, numMAXPGlyphs;
    hdmx_table* table = (hdmx_table*)map_at(&lfFont->table_map, (void*)TAG_HDMX);
    //ULONG paddedLen = 0;
    ULONG tableSize;
    BYTE* tableData;

    numGlyphs = HDMX_GetNumGlyphs(table);
    numMAXPGlyphs = MAXP_getNumGlyphs(lfFont);

    if(numGlyphs != numMAXPGlyphs)
    {
        DEBUG_LOG_ERROR("in HDMX_writeTable - mismatch between MAXP and HDMX info");
    }

    tableData = HDMX_buildTable(table, &tableSize);
    if(tableData == NULL)
        return LF_OUT_OF_MEMORY;

    //UTILS_PadTable(&tableData, tableSize, &paddedLen);

    record->checkSum = UTILS_CalcTableChecksum(tableData, tableSize);
    record->length = tableSize;
    record->offset = (ULONG)STREAM_streamPos(stream);

    STREAM_writeChunk(stream, tableData, (tableSize + 3) & ~3);
    free(tableData);

    return LF_ERROR_OK;
}

LF_ERROR HDMX_removeGlyph(LF_FONT* lfFont, ULONG index)
{
    USHORT i;
    hdmx_table* table = (hdmx_table*)map_at(&lfFont->table_map, (void*)TAG_HDMX);

    if(table == NULL)
        return LF_EMPTY_TABLE;

    for(i = 0; i < table->numRecords; i++)
    {
        USHORT data;
        device_record* dr = (device_record *)vector_at(&table->deviceRecordList, i);
        ASSERT(dr);
        if (NULL == dr)
            return LF_BAD_FORMAT;

        if(i == 0 && index >= dr->widthsArrayLen)
            return LF_INVALID_INDEX;

        // note: maxwidth is recalculated when table is written
        data = dr->widthsArray[index];

        if (HDMX_isValid(data) == LF_ERROR_OK)
        {
            // invalidate the HDMX width
            dr->totalGlyphs--;
            dr->widthsArray[index] = data | HDMX_INVALID_GLYPH;
        }
    }

    return LF_ERROR_OK;
}

LF_ERROR HDMX_freeTable(LF_FONT* lfFont)
{
    hdmx_table* table = (hdmx_table*)map_at(&lfFont->table_map, (void*)TAG_HDMX);

    if(table != NULL)
    {
        HDMX_cleanupDeviceRecords(table);

        vector_delete(&table->deviceRecordList);
        free(table);
    }

    return LF_ERROR_OK;
}
