// Copyright (C) 2014 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// mark_array.c

#include <stdlib.h>
#include "mark_array.h"


LF_ERROR Mark_readArray(LF_VECTOR* markArray, LF_STREAM* stream)
{
    LF_ERROR error;
    size_t tableStart = STREAM_streamPos(stream);
    USHORT markCount = STREAM_readUShort(stream);
    USHORT i = 0;

    error = vector_init(markArray, markCount, 4);
    if (error != LF_ERROR_OK)
        return error;

    for(; i < markCount; i++)
    {
        mark_record* record = (mark_record*)malloc(sizeof(mark_record));
        if (record == NULL)
        {
            Mark_freeArray(markArray);
            return LF_OUT_OF_MEMORY;
        }

        record->Class = STREAM_readUShort(stream);

        OFFSET anchorOffset = STREAM_readOffset(stream);
        size_t offsetTable = STREAM_streamPos(stream);
        STREAM_streamSeek(stream, tableStart + anchorOffset);
        Anchor_readTable(&record->MarkAnchor, stream);
        vector_push_back(markArray, record);
        STREAM_streamSeek(stream, offsetTable);
    }

    return error;
}

LF_ERROR Mark_getArraySize(LF_VECTOR* markArray, size_t* arraySize)
{
    ULONG i = 0;
    size_t anchorSize = 0;

    *arraySize = sizeof(USHORT);

    for(; i < markArray->count; i++)
    {
        mark_record* record = (mark_record*)vector_at(markArray, i);
        Anchor_getTableSize(&record->MarkAnchor, &anchorSize);
        *arraySize += sizeof(USHORT) + sizeof(OFFSET) + anchorSize;
    }

    return LF_ERROR_OK;
}

LF_ERROR Mark_buildArray(LF_VECTOR* markArray, LF_STREAM* stream)
{
    ULONG i = 0;
    size_t tableStart = STREAM_streamPos(stream);
    size_t endPos;
    size_t currPos;

    // Mark array count * (Class value + Anchor offset) + Mark Count size
    endPos = (sizeof(USHORT) + 2) * markArray->count + sizeof(OFFSET);
    STREAM_writeUShort(stream, (USHORT)markArray->count);
    currPos = STREAM_streamPos(stream);

    for(; i < markArray->count; i++)
    {
        mark_record* record = (mark_record*)vector_at(markArray, i);

        STREAM_streamSeek(stream, currPos);
        STREAM_writeUShort(stream, record->Class);

        STREAM_writeOffset(stream, (OFFSET)endPos);
        currPos = STREAM_streamPos(stream);
        STREAM_streamSeek(stream, tableStart + endPos);
        Anchor_buildTable(&record->MarkAnchor, stream);
        endPos = STREAM_streamPos(stream) - tableStart;
    }

    return LF_ERROR_OK;
}

LF_ERROR Mark_removeAtIndex(LF_VECTOR* markArray, ULONG index)
{
    mark_record* record = (mark_record*)vector_at(markArray, index);
    if(record)
    {
        Anchor_freeTable(&record->MarkAnchor);
        free(record);
        return vector_erase(markArray, index);        // Remove the mark record
    }
    else
    {
        return(LF_INVALID_INDEX);
    }
}

LF_ERROR Mark_setAnchorFormat1(LF_VECTOR* markArray)
{
    for (size_t i = 0; i < markArray->count; i++)
    {
        mark_record* record = (mark_record*)vector_at(markArray, i);

        if (record)
        {
            if (record->MarkAnchor.AnchorFormat == 2)
                record->MarkAnchor.AnchorFormat = 1;
        }
    }

    return LF_ERROR_OK;
}

void Mark_freeArray(LF_VECTOR* markArray)
{
    ULONG i = 0;
    while (i < markArray->count)
    {
        mark_record* record = (mark_record*)vector_at(markArray, i++);
        Anchor_freeTable(&record->MarkAnchor);
        free(record);
    }

    vector_delete(markArray);
}

#ifdef LF_OT_DUMP
#include "utils.h"

LF_ERROR Mark_dumpArray(LF_VECTOR* markArray)
{
    ULONG i;
    XML_START("MarkArray");

    for (i = 0; i < markArray->count; i++)
    {
        mark_record* record = (mark_record*)vector_at(markArray, i);
        XML_DATA_NODE("Class", record->Class);
        Anchor_dumpTable(&record->MarkAnchor);
    }
    XML_END("MarkArray");

    return LF_ERROR_OK;
}
#endif
