// Copyright (C) 2014 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// lig_caret_list.c

#include <stdlib.h>
#include "lig_caret_list.h"
#include "utils.h"


static LF_VECTOR* LigCaretList_readLigGlyphTable(LF_STREAM* stream)
{
    size_t tableStart = STREAM_streamPos(stream);
    USHORT caretCount = STREAM_readUShort(stream);
    USHORT i;
    LF_VECTOR* caretList = vector_create(caretCount, 4);

    if (caretList == NULL)
        return NULL;

    for (i = 0; i < caretCount; i++)
    {
        caret_value* caretValue = (caret_value*)calloc(1, sizeof(caret_value));

        if (caretValue == NULL)
        {
            for (size_t j = 0; j < caretList->count; j++)
            {
                caret_value* cv = (caret_value*)vector_at(caretList, j);
                free(cv);
            }

            vector_free(caretList);
            free(caretList);
            return NULL;
        }

        USHORT caretOffset = STREAM_readUShort(stream);

        size_t current = STREAM_streamPos(stream);
        STREAM_streamSeek(stream, tableStart + caretOffset);

        caretValue->CaretValueFormat = STREAM_readUShort(stream);

        switch (caretValue->CaretValueFormat)
        {
            case 1:    caretValue->Coordinate = STREAM_readShort(stream);          break;
            case 2:    caretValue->CaretValuePoint = STREAM_readUShort(stream);    break;
            case 3:
            {
                OFFSET deviceOffset;
                caretValue->Coordinate = STREAM_readShort(stream);
                deviceOffset = STREAM_readOffset(stream);
                STREAM_streamSeek(stream, current + deviceOffset);
                DeviceTable_readTable(&caretValue->DeviceTable, stream);
                break;
            }
            default:
                break;
        }

        STREAM_streamSeek(stream, current);
        vector_push_back(caretList, caretValue);
    }

    return caretList;
}

static OFFSET LigCaretList_writeCaretValue(caret_value* caretValue, LF_STREAM* stream)
{
    size_t tableStart = STREAM_streamPos(stream);
    STREAM_writeUShort(stream, caretValue->CaretValueFormat);

    switch (caretValue->CaretValueFormat)
    {
        case 1: STREAM_writeShort(stream, caretValue->Coordinate);           break;
        case 2: STREAM_writeUShort(stream, caretValue->CaretValuePoint);     break;
        case 3: STREAM_writeShort(stream, caretValue->Coordinate);
                STREAM_writeOffset(stream, (OFFSET)(STREAM_streamPos(stream) - tableStart + sizeof(OFFSET)));
                DeviceTable_buildTable(&caretValue->DeviceTable, stream);
                break;
        default:
                break;
    }

    return (OFFSET)(STREAM_streamPos(stream) - tableStart);
}

static OFFSET LigCaretList_writeLigGlyphTable(LF_VECTOR* ligGlyphTable, LF_STREAM* stream)
{
    ULONG j;
    size_t tableStart = STREAM_streamPos(stream);
    OFFSET tableOffset = (OFFSET)(sizeof(USHORT)+sizeof(OFFSET)*ligGlyphTable->count);
    size_t current = 0;

    STREAM_writeUShort(stream, (USHORT)ligGlyphTable->count);

    for (j = 0; j < ligGlyphTable->count; j++)
    {
        caret_value* caretValue = (caret_value*)vector_at(ligGlyphTable, j);

        STREAM_writeOffset(stream, tableOffset);
        current = STREAM_streamPos(stream);
        STREAM_streamSeek(stream, (OFFSET)tableStart + tableOffset);
        tableOffset += LigCaretList_writeCaretValue(caretValue, stream);
        STREAM_streamSeek(stream, current);
    }

    return tableOffset;
}

LF_ERROR LigCaretList_readTable(lig_caret_list* list, LF_STREAM* stream)
{
    USHORT      glyphCount;
    USHORT      i;
    LF_ERROR    status;
    size_t      tableStart = STREAM_streamPos(stream);

    OFFSET coverageOffset = STREAM_readOffset(stream);
    size_t current = STREAM_streamPos(stream);
    STREAM_streamSeek(stream, tableStart + coverageOffset);
    status = Coverage_readTable(&list->Coverage, stream);
    if (status != LF_ERROR_OK)
    {
        if (status == LF_EMPTY_TABLE)
        {
            DEBUG_LOG_WARNING("empty ligature caret list");
        }
        else
        {
            DEBUG_LOG_STATUS("coverage failed, skipping table", status);
        }

        return status;
    }

    STREAM_streamSeek(stream, current);

    glyphCount = STREAM_readUShort(stream);

    status = vector_init(&list->LigGlyph, glyphCount, 4);
    if (status != LF_ERROR_OK)
        return status;

    for (i = 0; i < glyphCount; i++)
    {
        OFFSET tableOffset = STREAM_readOffset(stream);
        current = STREAM_streamPos(stream);
        STREAM_streamSeek(stream, tableStart + tableOffset);
        vector_push_back(&list->LigGlyph, LigCaretList_readLigGlyphTable(stream));
        STREAM_streamSeek(stream, current);
    }

    return LF_ERROR_OK;
}

LF_ERROR LigCaretList_getTableSize(lig_caret_list* list, size_t* tableSize)
{
    ULONG i;

    Coverage_getTableSize(&list->Coverage, tableSize);
    *tableSize += list->LigGlyph.count * sizeof(OFFSET) + sizeof(OFFSET) + sizeof(USHORT);

    for (i = 0; i < list->LigGlyph.count; i++)
    {
        ULONG j;
        LF_VECTOR* ligGlyphTable = (LF_VECTOR*)vector_at(&list->LigGlyph, i);
        *tableSize += sizeof(USHORT)+sizeof(OFFSET)* ligGlyphTable->count;

        for (j = 0; j < ligGlyphTable->count; j++)
        {
            caret_value* caretValue = (caret_value*)vector_at(ligGlyphTable, j);
            *tableSize += sizeof(USHORT);

            switch (caretValue->CaretValueFormat)
            {
                case 1: *tableSize += sizeof(SHORT);    break;
                case 2: *tableSize += sizeof(USHORT);   break;
                case 3: *tableSize += sizeof(SHORT) + sizeof(OFFSET);    break;
                default:
                        break;
            }
        }
    }

    return LF_ERROR_OK;
}

LF_ERROR LigCaretList_buildTable(lig_caret_list* list, LF_STREAM* stream)
{
    size_t tableStart = STREAM_streamPos(stream);
    size_t current;
    ULONG i;
    OFFSET endSeek;

    OFFSET tableOffset = (OFFSET)(sizeof(OFFSET)+sizeof(USHORT)+sizeof(OFFSET)*list->LigGlyph.count);


    //write coverage table
    STREAM_writeOffset(stream, tableOffset);
    current = STREAM_streamPos(stream);
    STREAM_streamSeek(stream, (OFFSET)tableStart + tableOffset);
    Coverage_buildTable(&list->Coverage, stream);
    tableOffset = (OFFSET)(STREAM_streamPos(stream) - tableStart);
    STREAM_streamSeek(stream, current);

    STREAM_writeUShort(stream, (USHORT)list->LigGlyph.count);
    endSeek = (OFFSET)STREAM_streamPos(stream);
    for (i = 0; i < list->LigGlyph.count; i++)
    {
        LF_VECTOR* ligGlyphTable = (LF_VECTOR*)vector_at(&list->LigGlyph, i);

        STREAM_writeOffset(stream, tableOffset);
        current = STREAM_streamPos(stream);
        STREAM_streamSeek(stream, (OFFSET)tableStart + tableOffset);
        tableOffset += LigCaretList_writeLigGlyphTable(ligGlyphTable, stream);
        endSeek = ((OFFSET)tableStart + tableOffset);
        STREAM_streamSeek(stream, current);

    }
    STREAM_streamSeek(stream, endSeek);
    return LF_ERROR_OK;
}

LF_ERROR LigCaretList_freeTable(lig_caret_list* list)
{
    ULONG i;

    for (i = 0; i < list->LigGlyph.count; i++)
    {
        LF_VECTOR* caretList = (LF_VECTOR*)vector_at(&list->LigGlyph, i);
        ULONG j;

        for (j = 0; j < caretList->count; j++)
        {
            caret_value* caretValue = (caret_value*)vector_at(caretList, j);
            free(caretValue);
        }

        vector_free(caretList);
        free(caretList);
    }

    Coverage_deleteTable(&list->Coverage);
    vector_delete(&list->LigGlyph);

    return LF_ERROR_OK;
}
