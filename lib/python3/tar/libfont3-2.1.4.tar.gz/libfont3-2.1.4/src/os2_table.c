// Copyright (C) 2014, 2015, 2017 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// os2_table.c

#include <stdlib.h>
#include <string.h>
#include "os2_table.h"
#include "cmap_table.h"
#include "glyf_table.h"
#include "cff_table.h"
#include "utils.h"

LF_ERROR OS2_readTable(LF_FONT* lfFont, const sfnt_table_record* record, LF_STREAM* stream)
{
    if(STREAM_streamSeek(stream, record->offset) == 0)
    {
        os2_table* table = (os2_table*)calloc(1, sizeof(os2_table));
        if (table == NULL)
            return LF_OUT_OF_MEMORY;

        // read the whole table as before, table can be parsed on demand
        table->length = record->length;
        table->data = STREAM_readChunk(stream, table->length);

        table->isParsed = FALSE;
        table->modified = FALSE;

        map_insert(&lfFont->table_map, (void*)(intptr_t)record->tag, table);

        return LF_ERROR_OK;
    }

    return LF_INVALID_OFFSET;
}

static LF_ERROR OS2_parseTable(LF_FONT* lfFont)
{
    LF_ERROR error = LF_ERROR_OK;
    os2_table* table;
    LF_STREAM stream;

    table = (os2_table*)map_at(&lfFont->table_map, (void*)TAG_OS2);
    if(table == NULL)
        return LF_TABLE_MISSING;

    if (table->isParsed)
        return LF_ERROR_OK;

    STREAM_initMemStream(&stream, table->data, table->length);

    // try to parse it, handles versions 1, 2, 3, 4, and 5
    if(STREAM_streamSeek(&stream, 0) == 0)
    {
        table->v5.version = STREAM_readUShort(&stream);

        if(table->v5.version == 0x0)
            error = LF_INVALID_TYPE;
        else
        {
            USHORT i;

            table->v5.xAvgCharWidth = STREAM_readShort(&stream);
            table->v5.usWeightClass = STREAM_readUShort(&stream);
            table->v5.usWidthClass = STREAM_readUShort(&stream);
            table->v5.fsType = STREAM_readShort(&stream);
            table->v5.ySubscriptXSize = STREAM_readShort(&stream);
            table->v5.ySubscriptYSize = STREAM_readShort(&stream);
            table->v5.ySubscriptXOffset = STREAM_readShort(&stream);
            table->v5.ySubscriptYOffset = STREAM_readShort(&stream);
            table->v5.ySuperscriptXSize = STREAM_readShort(&stream);
            table->v5.ySuperscriptYSize = STREAM_readShort(&stream);
            table->v5.ySuperscriptXOffset = STREAM_readShort(&stream);
            table->v5.ySuperscriptYOffset = STREAM_readShort(&stream);
            table->v5.yStrikeoutSize = STREAM_readShort(&stream);
            table->v5.yStrikeoutPosition = STREAM_readShort(&stream);
            table->v5.sFamilyClass = STREAM_readShort(&stream);
            for(i = 0; i < 10; ++i)
            {
                table->v5.panose[i] = STREAM_readByte(&stream);
            }
            table->v5.ulUnicodeRange1 = STREAM_readULong(&stream);    //Bits 0-31
            table->v5.ulUnicodeRange2 = STREAM_readULong(&stream);    //Bits 32-63
            table->v5.ulUnicodeRange3 = STREAM_readULong(&stream);    //Bits 64-95
            table->v5.ulUnicodeRange4 = STREAM_readULong(&stream);    //Bits 96-127
            for(i = 0; i < 4; ++i)
            {
                table->v5.achVendID[i] = STREAM_readByte(&stream);
            }
            table->v5.fsSelection = STREAM_readUShort(&stream);
            table->v5.usFirstCharIndex = STREAM_readUShort(&stream);
            table->v5.usLastCharIndex = STREAM_readUShort(&stream);
            table->v5.sTypoAscender = STREAM_readShort(&stream);
            table->v5.sTypoDescender = STREAM_readShort(&stream);
            table->v5.sTypoLineGap = STREAM_readShort(&stream);
            table->v5.usWinAscent = STREAM_readUShort(&stream);
            table->v5.usWinDescent = STREAM_readUShort(&stream);
            table->v5.ulCodePageRange1 = STREAM_readULong(&stream);    //Bits 0-31
            table->v5.ulCodePageRange2 = STREAM_readULong(&stream);    //Bits 32-63

            if(table->v5.version > 0x0001)
            {
                table->v5.sxHeight = STREAM_readShort(&stream);
                table->v5.sCapHeight = STREAM_readShort(&stream);
                table->v5.usDefaultChar = STREAM_readUShort(&stream);
                table->v5.usBreakChar = STREAM_readUShort(&stream);
                table->v5.usMaxContext = STREAM_readUShort(&stream);
            }
            if (table->v5.version > 0x0004)
            {
                table->v5.usLowerOpticalPointSize = STREAM_readUShort(&stream);
                table->v5.usUpperOpticalPointSize = STREAM_readUShort(&stream);
            }

            table->isParsed = TRUE;
        }
    }
    else
        error = LF_EMPTY_TABLE;

    return error;
}

LF_ERROR OS2_getTableSize(LF_FONT* lfFont, size_t* tableSize)
{
    os2_table* table;

    *tableSize = 0;

    table = (os2_table*)map_at(&lfFont->table_map, (void*)TAG_OS2);
    if(table == NULL)
        return LF_TABLE_MISSING;

    if (table->modified == TRUE)
    {
        if (table->v5.version == 1)
            *tableSize = OS2_V1_TABLE_SIZE;
        else if (table->v5.version < 5)
            *tableSize = OS2_V3_TABLE_SIZE;
        else
            *tableSize = OS2_V5_TABLE_SIZE;
    }
    else
        *tableSize = table->length;

    return LF_ERROR_OK;
}

LF_ERROR OS2_updateHeights(LF_FONT* lfFont)
{
    if (lfFont->isSubsetted == FALSE)
        return LF_ERROR_OK;

    os2_table* table = (os2_table*)map_at(&lfFont->table_map, (void*)(long)TAG_OS2);
    if (table == NULL)
        return LF_TABLE_MISSING;

    if (table->v5.version == 0x001)
        return LF_ERROR_OK;     // version 1 does not have the sxHeight and sCapHeight fields; but should not get here since OS2_upgradeTable should be called first

    LF_ERROR error;
    GlyphID xid, Hid;

    error = CMAP_getGlyphID(lfFont, 0x78, &xid);
    if (error != LF_ERROR_OK)
        return error;

    if (xid != 0)
    {
        error = CMAP_getRemappedGlyphID(lfFont, xid, &xid);
        if (error != LF_ERROR_OK)
            return error;

        if (xid == 0xFFFF)
            table->v5.sxHeight = 0;
    }
    else
        table->v5.sxHeight = 0;

    error = CMAP_getGlyphID(lfFont, 0x48, &Hid);
    if (error != LF_ERROR_OK)
        return error;

    if (Hid != 0)
    {
        error = CMAP_getRemappedGlyphID(lfFont, Hid, &Hid);
        if (error != LF_ERROR_OK)
            return error;

        if (Hid == 0xFFFF)
            table->v5.sCapHeight = 0;
    }
    else
        table->v5.sCapHeight = 0;

    return LF_ERROR_OK;
}

// This is currently disabled since the algorithm in it needs more work and it does
// not come up with the result which Cloud Validator expects.
#if 0 // Function is currently disabled.
#include "gsub_table.h"
LF_ERROR OS2_updateMaxContent(LF_FONT* lfFont)
{
    os2_table* table = (os2_table*)map_at(&lfFont->table_map, (void*)(long)TAG_OS2);
    if (table == NULL)
        return LF_TABLE_MISSING;

    USHORT maxContext;

    if (LF_ERROR_OK != GSUB_getMaxLigaDepth(lfFont, &maxContext))
        maxContext = 1;

    if (maxContext < 2 && map_key_exists(&lfFont->table_map, (void*)TAG_KERN))
        maxContext = 2;

    table->v5.usMaxContext = maxContext;

    return LF_ERROR_OK;
}
#endif

LF_ERROR OS2_upgradeTable(LF_FONT* lfFont)
{
    os2_table* table = (os2_table*)map_at(&lfFont->table_map, (void*)(long)TAG_OS2);
    if (table == NULL)
        return LF_TABLE_MISSING;

    LF_ERROR error;

    USHORT version;
    os2_table_5* os2_tablev5 = (os2_table_5*)(void*)table->data;

    if (TRUE == table->isParsed)
        version = table->v5.version;
    else
        version = SWAP_USHORT(os2_tablev5->version);

    if (version >= 3)
        return LF_ERROR_OK;

    if (FALSE == table->isParsed)
    {
        error = OS2_parseTable(lfFont);
        if (error != LF_ERROR_OK)
            return error;
    }

    table->modified = TRUE;

    USHORT fsType = table->v5.fsType;

    if (fsType != 0)
    {
        // leave only the most permissive of bits 0-3 set
        if ((fsType & 0x8) != 0)
            fsType &= ~0x7;
        else if ((fsType & 0x4) != 0)
            fsType &= ~0x3;
        else if ((fsType & 0x2) != 0)
            fsType = 0x2;

        table->v5.fsType = fsType;
    }

    if (table->v5.version == 1)
    {
        // find the sxHeight and sCapHeight values since they were not there before

        SHORT xHeight = 0, capHeight = 0;

        GlyphID xid, Hid, remappedXid, remappedHid;
        error = CMAP_getGlyphID(lfFont, 0x78, &xid);
        if (error != LF_ERROR_OK)
            return error;
        error = CMAP_getGlyphID(lfFont, 0x48, &Hid);
        if (error != LF_ERROR_OK)
            return error;

        if (lfFont->isSubsetted == TRUE)
        {
            // If the remapped value is FFFF, that means the glyph
            // was removed and the corresponding field should be left at 0.
            error = CMAP_getRemappedGlyphID(lfFont, xid, &remappedXid);
            if (error != LF_ERROR_OK)
                return error;
            error = CMAP_getRemappedGlyphID(lfFont, Hid, &remappedHid);
            if (error != LF_ERROR_OK)
                return error;
        }
        else
        {
            remappedXid = (xid == 0) ? 0xFFFF : xid;
            remappedHid = (Hid == 0) ? 0xFFFF : Hid;
        }


        // Set the sxHeight and sxCapHeight based on the glyph table of the orginal font
        // Note this may give inaccurate results, for ex. if the operation is a subset to
        // a format with a different glyph table and the x were removed
        boolean useGlyf = (lfFont->origFlavor == SIG_CFF) ? FALSE : TRUE;

        if (useGlyf)
        {
            glyf_table* gt = (glyf_table*)map_at(&lfFont->table_map, (void*)TAG_GLYF);
            if (NULL == gt)
                return LF_BAD_FORMAT;

            glyf glyfObj;

            if (remappedXid != 0xFFFF)
            {
                error = GLYF_getGlyph(lfFont, &glyfObj, (TRUE == gt->remapped) ? remappedXid : xid);
                if (error != LF_ERROR_OK)
                    return error;
                xHeight = glyfObj.yMax;
                GLYF_destroyGlyf(&glyfObj);
            }
            if (remappedHid != 0xFFFF)
            {
                error = GLYF_getGlyph(lfFont, &glyfObj, (TRUE == gt->remapped) ? remappedHid : Hid);
                if (error != LF_ERROR_OK)
                    return error;

                capHeight = glyfObj.yMax;
                GLYF_destroyGlyf(&glyfObj);
            }
        }
        else
        {
            SHORT xMin, yMin, xMax, yMax;

            if (remappedXid != 0xFFFF)
            {
                error = CFF__getGlyphBoundingBox(lfFont, xid, &xMin, &yMin, &xMax, &yMax);
                if (error != LF_ERROR_OK)
                    return error;
                xHeight = yMax;
            }
            if (remappedHid != 0xFFFF)
            {
                error = CFF__getGlyphBoundingBox(lfFont, Hid, &xMin, &yMin, &xMax, &yMax);
                if (error != LF_ERROR_OK)
                    return error;
                capHeight = yMax;
            }
        }

        table->v5.sxHeight = xHeight;
        table->v5.sCapHeight = capHeight;
    }
    else
    {
        // update the sxHeight / sCapHeight to zero if the 'x' or 'H' is no longer in the font.
        error = OS2_updateHeights(lfFont);
        if (error != LF_ERROR_OK)
            return error;
    }

    //error = OS2_updateMaxContent(lfFont);

    table->v5.version = 3;
    table->v5.usDefaultChar = 0x0;
    table->v5.usBreakChar = 0x20;

    return error;
}

LF_ERROR OS2_writeTable(LF_FONT* lfFont, sfnt_table_record* record, LF_STREAM* stream)
{
    ULONG padLen = 0;
    os2_table* table = (os2_table*)map_at(&lfFont->table_map, (void*)(intptr_t)record->tag);
    if(table == NULL)
        return LF_TABLE_MISSING;

    BYTE* writeBuf;
    ULONG writeLen;

    if (table->modified == TRUE)
    {
        LF_STREAM tempStream;
        size_t tableSize;

        LF_ERROR error = OS2_getTableSize(lfFont, &tableSize);
        if (error != LF_ERROR_OK)
            return error;

         writeBuf = (BYTE*)calloc(tableSize, sizeof(BYTE));
        if (NULL == writeBuf)
            return LF_OUT_OF_MEMORY;

        STREAM_initMemStream(&tempStream, writeBuf, tableSize);

        STREAM_writeUShort(&tempStream, table->v5.version);
        STREAM_writeShort(&tempStream, table->v5.xAvgCharWidth);
        STREAM_writeUShort(&tempStream, table->v5.usWeightClass);
        STREAM_writeUShort(&tempStream, table->v5.usWidthClass);
        STREAM_writeShort(&tempStream, table->v5.fsType);
        STREAM_writeShort(&tempStream, table->v5.ySubscriptXSize);
        STREAM_writeShort(&tempStream, table->v5.ySubscriptYSize);
        STREAM_writeShort(&tempStream, table->v5.ySubscriptXOffset);
        STREAM_writeShort(&tempStream, table->v5.ySubscriptYOffset);
        STREAM_writeShort(&tempStream, table->v5.ySuperscriptXSize);
        STREAM_writeShort(&tempStream, table->v5.ySuperscriptYSize);
        STREAM_writeShort(&tempStream, table->v5.ySuperscriptXOffset);
        STREAM_writeShort(&tempStream, table->v5.ySuperscriptYOffset);
        STREAM_writeShort(&tempStream, table->v5.yStrikeoutSize);
        STREAM_writeShort(&tempStream, table->v5.yStrikeoutPosition);
        STREAM_writeShort(&tempStream, table->v5.sFamilyClass);
        USHORT i;
        for (i = 0; i < 10; ++i)
            STREAM_writeByte(&tempStream, table->v5.panose[i]);
        STREAM_writeULong(&tempStream, table->v5.ulUnicodeRange1);
        STREAM_writeULong(&tempStream, table->v5.ulUnicodeRange2);
        STREAM_writeULong(&tempStream, table->v5.ulUnicodeRange3);
        STREAM_writeULong(&tempStream, table->v5.ulUnicodeRange4);
        for (i = 0; i < 4; ++i)
            STREAM_writeByte(&tempStream, table->v5.achVendID[i]);
        STREAM_writeUShort(&tempStream, table->v5.fsSelection);
        STREAM_writeUShort(&tempStream, table->v5.usFirstCharIndex);
        STREAM_writeUShort(&tempStream, table->v5.usLastCharIndex);
        STREAM_writeShort(&tempStream, table->v5.sTypoAscender);
        STREAM_writeShort(&tempStream, table->v5.sTypoDescender);
        STREAM_writeShort(&tempStream, table->v5.sTypoLineGap);
        STREAM_writeUShort(&tempStream, table->v5.usWinAscent);
        STREAM_writeUShort(&tempStream, table->v5.usWinDescent);
        STREAM_writeULong(&tempStream, table->v5.ulCodePageRange1);
        STREAM_writeULong(&tempStream, table->v5.ulCodePageRange2);
        if (table->v5.version > 0x0001)
        {
            STREAM_writeShort(&tempStream, table->v5.sxHeight);
            STREAM_writeShort(&tempStream, table->v5.sCapHeight);
            STREAM_writeUShort(&tempStream, table->v5.usDefaultChar);
            STREAM_writeUShort(&tempStream, table->v5.usBreakChar);
            STREAM_writeUShort(&tempStream, table->v5.usMaxContext);
        }
        if (table->v5.version > 0x0004)
        {
            STREAM_writeUShort(&tempStream, table->v5.usLowerOpticalPointSize);
            STREAM_writeUShort(&tempStream, table->v5.usUpperOpticalPointSize);
        }

        writeLen = (ULONG)tableSize;
    }
    else
    {
        writeBuf = table->data;
        writeLen = table->length;
    }

    UTILS_PadTable(&writeBuf, writeLen, &padLen);

    record->checkSum = UTILS_CalcTableChecksum(writeBuf, writeLen);
    record->length = writeLen;
    record->offset = (ULONG)STREAM_streamPos(stream);

    STREAM_streamSeek(stream, record->offset);
    STREAM_writeChunk(stream, writeBuf, padLen);

    if (TRUE == table->modified)
    {
        free(writeBuf);

        table->isParsed = FALSE;
        table->modified = FALSE;
    }
    else if (table->data != writeBuf)
        table->data = writeBuf;

    return LF_ERROR_OK;
}

LF_ERROR OS2_freeTable(LF_FONT* lfFont)
{
    os2_table* table = (os2_table*)map_at(&lfFont->table_map, (void*)TAG_OS2);

    if(table)
    {
        free(table->data);
        free(table);
    }

    return LF_ERROR_OK;
}

LF_ERROR OS2_setCharIndex(LF_FONT* lfFont, USHORT firstIndex, USHORT lastIndex)
{
    os2_table* table = (os2_table*)map_at(&lfFont->table_map, (void*)TAG_OS2);
    if(table == NULL)
        return LF_TABLE_MISSING;

    if (FALSE == table->isParsed)
    {
        LF_ERROR error = OS2_parseTable(lfFont);
        if (error != LF_ERROR_OK)
            return error;
    }

    table->v5.usFirstCharIndex = firstIndex;
    table->v5.usLastCharIndex = lastIndex;

    table->modified = TRUE;

    return LF_ERROR_OK;
}

LF_ERROR OS2_setAvgCharWidth(LF_FONT* lfFont, SHORT avgWidth)
{
    os2_table* table = (os2_table*)map_at(&lfFont->table_map, (void*)TAG_OS2);
    os2_table_5* os2_tablev5;

    if (table == NULL)
        return LF_TABLE_MISSING;

    os2_tablev5 = (os2_table_5*)(void*)table->data;
    os2_tablev5->xAvgCharWidth = SWAP_SHORT(avgWidth);

    if (table->isParsed)
        table->v5.xAvgCharWidth = avgWidth;

    return LF_ERROR_OK;
}

LF_ERROR OS2_setFsType(LF_FONT* lfFont, USHORT value)
{
    if (lfFont == NULL)
        return LF_INVALID_PARAM;

    // Bit 4-7 and 10-15 are reserved for all versions
    USHORT unusedBits = 0xFCF0;
    if ((unusedBits & value) != 0)
        return LF_INVALID_PARAM;

    LF_ERROR error;
    USHORT version;

    error = OS2_getVersion(lfFont, &version);
    if (error != LF_ERROR_OK)
        return error;

    // In version 1, bits 8 and 9 are reserved
    if (version == 1)
    {
        if ((value & 0x0300) != 0)
            return LF_INVALID_PARAM;
    }

    // In version 3 and higher, bits 0-3 are exclusive
    if (version >= 3)
    {
        USHORT onBits = ((value >> 3) & 0x01) + ((value >> 2) & 0x01) + ((value >> 1) & 0x01) + (value & 0x01);
        if (onBits > 1)
            return LF_INVALID_PARAM;
    }

    os2_table* table = (os2_table*)map_at(&lfFont->table_map, (void*)TAG_OS2);
    if (table == NULL)
        return LF_TABLE_MISSING;

    if (FALSE == table->isParsed)
    {
        error = OS2_parseTable(lfFont);
        if (error != LF_ERROR_OK)
            return error;
    }

    // Update raw data
    os2_table_5* os2_tablev5 = (os2_table_5*)(void*)table->data;
    os2_tablev5->fsType = SWAP_SHORT(value);

    table->v5.fsType = value;
    table->modified = TRUE;

    return LF_ERROR_OK;
}

LF_ERROR OS2_setFsSelection(LF_FONT* lfFont, USHORT fsSelection)
{
    if (lfFont == NULL)
        return LF_INVALID_PARAM;

    // bits 10-15 are reserved
    if ((fsSelection & 0xFC00) != 0)
        return LF_INVALID_PARAM;

    os2_table* table = (os2_table*)map_at(&lfFont->table_map, (void*)TAG_OS2);
    if (table == NULL)
        return LF_TABLE_MISSING;

    if (FALSE == table->isParsed)
    {
        LF_ERROR error = OS2_parseTable(lfFont);
        if (error != LF_ERROR_OK)
            return error;
    }

    USHORT version;

    LF_ERROR error = OS2_getVersion(lfFont, &version);
    if (error != LF_ERROR_OK)
        return error;

    // Bits 8 and 9 are inappropriate for versions below version 4
    if (version < 4)
    {
        if ((fsSelection & 0x0180) != 0)
        {
            fsSelection &= 0xFE7F;
            DEBUG_LOG_WARNING("Clearing inappropriate bits in OS2_setFsSelection.");
            // return LF_INVALID_PARAM;
        }
    }

    // Update raw data
    os2_table_5* os2_tablev5 = (os2_table_5*)(void*)table->data;
    os2_tablev5->fsSelection = SWAP_SHORT(fsSelection);

    table->v5.fsSelection = fsSelection;
    table->modified = TRUE;

    return LF_ERROR_OK;
}

LF_ERROR OS2_setWeightClass(LF_FONT* lfFont, USHORT usWeightClass)
{
    if (lfFont == NULL)
        return LF_INVALID_PARAM;

    if ((usWeightClass < 1) || (usWeightClass > 1000))
        return LF_INVALID_PARAM;

    os2_table* table = (os2_table*)map_at(&lfFont->table_map, (void*)TAG_OS2);
    if (table == NULL)
        return LF_TABLE_MISSING;

    if (FALSE == table->isParsed)
    {
        LF_ERROR error = OS2_parseTable(lfFont);
        if (error != LF_ERROR_OK)
            return error;
    }

    // Update raw data
    os2_table_5* os2_tablev5 = (os2_table_5*)(void*)table->data;
    os2_tablev5->usWeightClass = SWAP_SHORT(usWeightClass);

    table->v5.usWeightClass = usWeightClass;
    table->modified = TRUE;

    return LF_ERROR_OK;
}

LF_ERROR OS2_getVersion(LF_FONT* lfFont, USHORT* version)
{
    os2_table* table = (os2_table*)map_at(&lfFont->table_map, (void*)TAG_OS2);
    if (table == NULL)
        return LF_TABLE_MISSING;

    if (FALSE == table->isParsed)
    {
        os2_table_5* os2_tablev5 = (os2_table_5*)(void*)table->data;
        *version = SWAP_SHORT(os2_tablev5->version);
    }
    else
        *version = table->v5.version;

    return LF_ERROR_OK;
}

LF_ERROR OS2_getFsType(LF_FONT* lfFont, USHORT* value)
{
    if((lfFont == NULL) || (value == NULL))
        return LF_INVALID_PARAM;

    *value = 0;

    os2_table* table = (os2_table*)map_at(&lfFont->table_map, (void*)TAG_OS2);
    if(table == NULL)
        return LF_TABLE_MISSING;

    if (FALSE == table->isParsed)
    {
        LF_ERROR error = OS2_parseTable(lfFont);
        if (error != LF_ERROR_OK)
            return error;
    }

    *value = table->v5.fsType;

    return LF_ERROR_OK;
}

LF_ERROR OS2_getPanoseValues(LF_FONT* lfFont, BYTE* values)
{
    if((lfFont == NULL) || (values == NULL))
        return LF_INVALID_PARAM;

    memset(values, 0, 10);

    os2_table* table = (os2_table*)map_at(&lfFont->table_map, (void*)TAG_OS2);
    if(table == NULL)
        return LF_TABLE_MISSING;

    if (FALSE == table->isParsed)
    {
        LF_ERROR error = OS2_parseTable(lfFont);
        if (error != LF_ERROR_OK)
            return error;
    }

    for(USHORT i = 0; i < 10; ++i)
        values[i] = table->v5.panose[i];

    return LF_ERROR_OK;
}

LF_ERROR OS2_getFsSelection(LF_FONT* lfFont, USHORT* fsSelection)
{
    if((lfFont == NULL) || (fsSelection == NULL))
        return LF_INVALID_PARAM;

    *fsSelection = 0;

    os2_table* table = (os2_table*)map_at(&lfFont->table_map, (void*)TAG_OS2);
    if(table == NULL)
        return LF_TABLE_MISSING;

    if (FALSE == table->isParsed)
    {
        LF_ERROR error = OS2_parseTable(lfFont);
        if (error != LF_ERROR_OK)
            return error;
    }

    *fsSelection = table->v5.fsSelection;

    return LF_ERROR_OK;
}

LF_ERROR OS2_getWeightClass(LF_FONT* lfFont, USHORT* weightClass)
{
    if((lfFont == NULL) || (weightClass == NULL))
        return LF_INVALID_PARAM;

    *weightClass = 0;

    os2_table* table = (os2_table*)map_at(&lfFont->table_map, (void*)TAG_OS2);
    if(table == NULL)
        return LF_TABLE_MISSING;

    if (FALSE == table->isParsed)
    {
        LF_ERROR error = OS2_parseTable(lfFont);
        if (error != LF_ERROR_OK)
            return error;
    }

    *weightClass = table->v5.usWeightClass;

    return LF_ERROR_OK;
}

LF_ERROR OS2_getUnicodeRange(LF_FONT* lfFont, ULONG* range1, ULONG* range2, ULONG* range3, ULONG* range4)
{
    if((lfFont == NULL) || (range1 == NULL) || (range2 == NULL) || (range3 == NULL) || (range4 == NULL))
        return LF_INVALID_PARAM;

    *range1 = 0;
    *range2 = 0;
    *range3 = 0;
    *range4 = 0;

    os2_table* table = (os2_table*)map_at(&lfFont->table_map, (void*)TAG_OS2);
    if(table == NULL)
        return LF_TABLE_MISSING;

    if (FALSE == table->isParsed)
    {
        LF_ERROR error = OS2_parseTable(lfFont);
        if (error != LF_ERROR_OK)
            return error;
    }

    *range1 = table->v5.ulUnicodeRange1;
    *range2 = table->v5.ulUnicodeRange2;
    *range3 = table->v5.ulUnicodeRange3;
    *range4 = table->v5.ulUnicodeRange4;

    return LF_ERROR_OK;
}

LF_ERROR OS2_getCodePageRange(LF_FONT* lfFont, ULONG* range1, ULONG* range2)
{
    if((lfFont == NULL) || (range1 == NULL) || (range2 == NULL))
        return LF_INVALID_PARAM;

    *range1 = 0;
    *range2 = 0;

    os2_table* table = (os2_table*)map_at(&lfFont->table_map, (void*)TAG_OS2);
    if (table == NULL)
        return LF_TABLE_MISSING;

    if (FALSE == table->isParsed)
    {
        LF_ERROR error = OS2_parseTable(lfFont);
        if (error != LF_ERROR_OK)
            return error;
    }

    *range1 = table->v5.ulCodePageRange1;
    *range2 = table->v5.ulCodePageRange2;

    return LF_ERROR_OK;
}

LF_ERROR OS2_getAscent(LF_FONT* lfFont, FWORD* ascent)
{
    if ((lfFont == NULL) || (ascent == NULL))
        return LF_INVALID_PARAM;

    *ascent = 0;

    os2_table* table = (os2_table*)map_at(&lfFont->table_map, (void*)TAG_OS2);
    if (table == NULL)
        return LF_TABLE_MISSING;

    if (FALSE == table->isParsed)
    {
        LF_ERROR error = OS2_parseTable(lfFont);
        if (error != LF_ERROR_OK)
            return error;
    }

    *ascent = table->v5.usWinAscent;

    return LF_ERROR_OK;
}

LF_ERROR OS2_getDescent(LF_FONT* lfFont, FWORD* descent)
{
    if ((lfFont == NULL) || (descent == NULL))
        return LF_INVALID_PARAM;

    os2_table* table = (os2_table*)map_at(&lfFont->table_map, (void*)TAG_OS2);
    if (table == NULL)
        return LF_TABLE_MISSING;

    if (FALSE == table->isParsed)
    {
        LF_ERROR error = OS2_parseTable(lfFont);
        if (error != LF_ERROR_OK)
            return error;
    }

    *descent = table->v5.usWinDescent;

    return LF_ERROR_OK;
}

LF_ERROR OS2_getAvgCharWidth(LF_FONT* lfFont, USHORT* value)
{
    if ((lfFont == NULL) || (value == NULL))
        return LF_INVALID_PARAM;

    *value = 0;

    os2_table* table = (os2_table*)map_at(&lfFont->table_map, (void*)TAG_OS2);
    if (table == NULL)
        return LF_TABLE_MISSING;

    if (FALSE == table->isParsed)
    {
        LF_ERROR error = OS2_parseTable(lfFont);
        if (error != LF_ERROR_OK)
            return error;
    }

    *value = table->v5.xAvgCharWidth;

    return LF_ERROR_OK;
}

LF_ERROR OS2_getVendor(LF_FONT* lfFont, CHAR vendor[4])
{
    if (lfFont == NULL)
        return LF_INVALID_PARAM;

    os2_table* table = (os2_table*)map_at(&lfFont->table_map, (void*)TAG_OS2);
    if (table == NULL)
        return LF_TABLE_MISSING;

    if (FALSE == table->isParsed)
    {
        LF_ERROR error = OS2_parseTable(lfFont);
        if (error != LF_ERROR_OK)
            return error;
    }

    for (USHORT i = 0; i < 4; ++i)
        vendor[i] = table->v5.achVendID[i];

    return LF_ERROR_OK;
}
