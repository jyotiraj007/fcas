// Copyright (C) 2014, 2015 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// vmtx_table.c

#include "vmtx_table.h"
#include "vhea_table.h"
#include "maxp_table.h"
#include "utils.h"
#include "glyf_table.h"
#include "cff_table.h"

static void VMTX_cleanupMetricsMap(vmtx_table* table)
{
    size_t i, metricsVectorSize;

    metricsVectorSize = table->metricsVector.count;

    for (i = 0; i < metricsVectorSize; i++)
    {
        longVerMetric* lvm = (longVerMetric *)vector_at(&table->metricsVector, i);
        if (lvm != (longVerMetric *)(intptr_t)VMTX_MARK_REMOVED)
            free(lvm);
    }
    vector_delete(&table->metricsVector);
} //lint !e429 table is freed following the call to this function

LF_ERROR VMTX_readTable(LF_FONT* lfFont, const sfnt_table_record* record, LF_STREAM* stream)
{
    if(STREAM_streamSeek(stream, record->offset) == 0)
    {
        if (NULL == map_at(&lfFont->table_map, (void*)TAG_VHEA))
            return LF_TABLE_MISSING;
        if (NULL == map_at(&lfFont->table_map, (void*)TAG_MAXP))
            return LF_TABLE_MISSING;

        USHORT numVMetrics = VHEA_getNumVMetrics(lfFont);
        USHORT numGlyphs = MAXP_getNumGlyphs(lfFont);

        vmtx_table* table = (vmtx_table*)malloc(sizeof(vmtx_table));
        if(table == NULL)
            return LF_OUT_OF_MEMORY;

        // initialize
        table->numVMetrics = 0;
        table->numMetricsCalculated = FALSE;
        table->calculatedTableSize = 0;

        if (LF_ERROR_OK != vector_init(&table->metricsVector, numGlyphs, 100))
        {
            free(table);
            return LF_OUT_OF_MEMORY;
        }

        USHORT i, advanceHeightOfTSBList = 0;

        for(i = 0; i < numGlyphs; i++)
        {
            longVerMetric* lvm = (longVerMetric*)malloc(sizeof(longVerMetric));
            if(lvm == NULL)
            {
                VMTX_cleanupMetricsMap(table);
                free(table);
                return LF_OUT_OF_MEMORY;
            }

            if(i < numVMetrics)
                lvm->advanceHeight = STREAM_readUShort(stream);
            else
                lvm->advanceHeight = advanceHeightOfTSBList;

            if(i == numVMetrics-1)
                advanceHeightOfTSBList = lvm->advanceHeight;

            lvm->topSideBearing = STREAM_readShort(stream);

            vector_push_back(&table->metricsVector, (void*)lvm);
        }

        map_insert(&lfFont->table_map, (void*)(intptr_t)record->tag, table);

        return LF_ERROR_OK;
    }

    return LF_INVALID_OFFSET;
}

LF_ERROR VMTX_expandTable(LF_FONT* lfFont, USHORT numGlyphs)
{
    vmtx_table* table = (vmtx_table*)map_at(&lfFont->table_map, (void*)TAG_VMTX);
    if (table == NULL)
        return LF_TABLE_MISSING;

    USHORT origSize = (USHORT)table->metricsVector.count;

    if (origSize >= numGlyphs)
        return LF_INVALID_PARAM;

    LF_ERROR error = vector_resize(&table->metricsVector, numGlyphs);
    if (error != LF_ERROR_OK)
        return error;

    for (size_t i = origSize; i < numGlyphs; i++)
    {
        longVerMetric *lvm = (longVerMetric*)calloc(1, sizeof(longVerMetric));
        if (lvm == NULL)
            return LF_OUT_OF_MEMORY;

        vector_push_back(&table->metricsVector, (void*)lvm);
    }

    return LF_ERROR_OK;
}

LF_ERROR VMTX_setMetric(LF_FONT* lfFont, size_t index, USHORT advanceHeight, SHORT tsb)
{
    vmtx_table* table = (vmtx_table*)map_at(&lfFont->table_map, (void*)TAG_VMTX);
    if (table == NULL)
        return LF_TABLE_MISSING;

    longVerMetric *lvm = vector_at(&table->metricsVector, index);

    lvm->advanceHeight = advanceHeight;
    lvm->topSideBearing = tsb;

    return LF_ERROR_OK;
}

static LF_ERROR VMTX_getNumMetrics(vmtx_table* table, USHORT *numVMetrics)
{
    USHORT index = 0, lastDelta = 0;
    USHORT indexOfLastDelta = 0;
    longVerMetric* lvm;
    boolean first = TRUE;

    if (table->numMetricsCalculated == TRUE)
    {
        *numVMetrics = table->numVMetrics;
        return LF_ERROR_OK;
    }

    // iterate through the current set of metrics and find the last change in
    // advance height, this determines how many Vmetrics there will be.
    // (the keys (glyph ids) are in ascending order)

    for (size_t i = 0; i < table->metricsVector.count; i++)
    {
        lvm = (longVerMetric *)vector_at(&table->metricsVector, i);

        if (lvm && (lvm != (longVerMetric *)(intptr_t)VMTX_MARK_REMOVED))
        {
            if (first)
            {
                first = FALSE;
                lastDelta = lvm->advanceHeight;
                index = 0;
                indexOfLastDelta = 0;
            }

            index++;

            if (lvm->advanceHeight != lastDelta)
            {
                lastDelta = lvm->advanceHeight;
                indexOfLastDelta = index;
            }
        }
    }

    if(indexOfLastDelta == 0)
        indexOfLastDelta = 1;   // there must be at least one item in the metrics list

    *numVMetrics = indexOfLastDelta;

    table->numMetricsCalculated = TRUE;
    table->numVMetrics = indexOfLastDelta;

    return LF_ERROR_OK;
}

LF_ERROR VMTX_getTableSize(LF_FONT* lfFont, size_t* tableSize)
{
    USHORT numGlyphs = 0, numVMetrics, numLSBs;

    *tableSize = 0;

    vmtx_table* table = (vmtx_table*)map_at(&lfFont->table_map, (void*)TAG_VMTX);
    if(table == NULL)
        return LF_EMPTY_TABLE;

    if (table->calculatedTableSize != 0)
    {
        *tableSize = table->calculatedTableSize;
        return LF_ERROR_OK;
    }

    // get the number of metrics
    LF_ERROR error = VMTX_getNumMetrics(table, &numVMetrics);
    if(error != LF_ERROR_OK)    // klocwork note: message about unreachable code is result of VMTX_getNumMetrics currently always returning ok.
        return error;

    for (size_t i = 0; i < table->metricsVector.count; i++)
    {
        longVerMetric* lvm = (longVerMetric *)vector_at(&table->metricsVector, i);

        if (lvm != (longVerMetric *)(intptr_t)VMTX_MARK_REMOVED)
            numGlyphs++;
    }
    numLSBs = numGlyphs - numVMetrics;

    *tableSize = numVMetrics * LONGVERMETRIC_SIZE;
    *tableSize += numLSBs * sizeof(SHORT);

    table->calculatedTableSize = *tableSize;

    return LF_ERROR_OK;
}

LF_ERROR VMTX_removeGlyph(LF_FONT* lfFont, ULONG index)
{
    vmtx_table* table = (vmtx_table*)map_at(&lfFont->table_map, (void*)TAG_VMTX);

    if (table == NULL)
        return LF_TABLE_MISSING;

    table->numMetricsCalculated = FALSE;
    table->calculatedTableSize = 0;

    longVerMetric* lvm = (longVerMetric *)vector_at(&table->metricsVector, index);
    if (lvm == NULL)
        return LF_INVALID_INDEX;

    if (lvm != (longVerMetric *)(intptr_t)VMTX_MARK_REMOVED)
    {
        free(lvm);

        vector_set_data(&table->metricsVector, index, (void*)(intptr_t)VMTX_MARK_REMOVED);
    }

    return LF_ERROR_OK;
}

UFWORD VMTX_getAdvanceHeightMax(LF_FONT* lfFont)
{
    UFWORD max = 0;
    vmtx_table* table = (vmtx_table*)map_at(&lfFont->table_map, (void*)TAG_VMTX);

    ASSERT(table);
    if (table == NULL)
        return LF_TABLE_MISSING;

    for (size_t i = 0; i < table->metricsVector.count; i++)
    {
        longVerMetric* lvm = (longVerMetric *)vector_at(&table->metricsVector, i);

        if (lvm && (lvm != (longVerMetric *)(intptr_t)VMTX_MARK_REMOVED))
        {
            if(lvm->advanceHeight > max)
                max = lvm->advanceHeight;
        }
    }

    return max;
}

UFWORD VMTX_getMinTopSidebearing(LF_FONT* lfFont)
{
    FWORD min = 32767;
    vmtx_table* table = (vmtx_table*)map_at(&lfFont->table_map, (void*)TAG_VMTX);

    ASSERT(table);
    if (table == NULL)
        return LF_TABLE_MISSING;

    for (size_t i = 0; i < table->metricsVector.count; i++)
    {
        longVerMetric* lvm = (longVerMetric *)vector_at(&table->metricsVector, i);

        if (lvm && lvm != (longVerMetric *)(intptr_t)VMTX_MARK_REMOVED)
        {
            if (lvm->topSideBearing < min)
                min = lvm->topSideBearing;
        }
    }

    return min;
}

// Calculate minimum top and bottom side bearings, the max advance height and yMaxExtent. yMaxExtent is calculated
// the way fontio does it.
LF_ERROR VMTX_updateSidebearings(LF_FONT* lfFont, LF_FONT_TYPE type, FWORD *mintsb, FWORD *minbsb, FWORD *maxadvance, FWORD* yMaxExtent)
{
    vmtx_table* table = (vmtx_table*)map_at(&lfFont->table_map, (void*)TAG_VMTX);

    *mintsb = 32767;
    *minbsb = 32767;
    *maxadvance = 0;
    *yMaxExtent = -32767;

    ASSERT(table);

    LF_MAP_ITER* mapIter;
    rb_tree_node* node;

    if (type == eLF_SFNT_FONT)
    {
        glyf_table* glyfTable = (glyf_table*)map_at(&lfFont->table_map, (void*)TAG_GLYF);
        if (glyfTable == NULL)
            return LF_EMPTY_TABLE;

        mapIter = map_begin(glyfTable->glyfMap);

        if (mapIter == NULL)
            return LF_OUT_OF_MEMORY;

        node = map_next(mapIter);
        size_t i, metricsVectorSize;
        glyf* glyf_object = (glyf*)node->data;

        metricsVectorSize = table->metricsVector.count;

        for (i = 0; i < metricsVectorSize; i++)
        {
            longVerMetric* lvm = (longVerMetric *)vector_at(&table->metricsVector, i);

            if (lvm && lvm != (longVerMetric *)(intptr_t)VMTX_MARK_REMOVED)
            {
                if (glyf_object && glyf_object->numberOfContours != 0)
                {
                    FWORD boxHeight = (glyf_object->yMax - glyf_object->yMin);

                    // fontio definition of yMaxExtent
                    if (*yMaxExtent < boxHeight + lvm->topSideBearing)
                        *yMaxExtent = boxHeight + lvm->topSideBearing;

                    if (lvm->topSideBearing < *mintsb)
                        *mintsb = lvm->topSideBearing;

                    FWORD bsb = (FWORD)(lvm->advanceHeight - lvm->topSideBearing - boxHeight);
                    if (bsb < *minbsb)
                        *minbsb = bsb;
                }

                if (lvm->advanceHeight > *maxadvance)
                    *maxadvance = lvm->advanceHeight;
                node = map_next(mapIter);
                if (node == NULL)
                    break;
                else
                    glyf_object = (glyf*)node->data;
            }
        }
        map_free_iter(mapIter);
    }
    else
    {
        cff_table* cffTable = (cff_table*)map_at(&lfFont->table_map, (void*)TAG_CFF);
        if (cffTable == NULL)
            return LF_EMPTY_TABLE;

        if (cffTable->charStringMap == NULL)
            return LF_BAD_FORMAT;

        size_t i, j = 0, metricsVectorSize;
        cffAnalyzedCharstring* acs;

        metricsVectorSize = table->metricsVector.count;

        for (i = 0; i < metricsVectorSize; i++)
        {
            longVerMetric* lvm = (longVerMetric *)vector_at(&table->metricsVector, i);

            if (lvm && lvm != (longVerMetric *)(intptr_t)VMTX_MARK_REMOVED)
            {
                acs = (cffAnalyzedCharstring*)map_at(cffTable->charStringMap, (void*)(intptr_t)j);
                if (acs && (acs->isEmpty == FALSE))
                {
                    if (acs->seacInfo == NULL)
                    {
                        FWORD boxHeight = ((acs->bb.yMax - acs->bb.yMin) >> 16);    //lint !e702

                        // fontio definition of yMaxExtent
                        if (*yMaxExtent < boxHeight + lvm->topSideBearing)
                            *yMaxExtent = boxHeight + lvm->topSideBearing;

                        if (lvm->topSideBearing < *mintsb)
                            *mintsb = lvm->topSideBearing;

                        FWORD bsb = (FWORD)(lvm->advanceHeight - lvm->topSideBearing - boxHeight);
                        if (bsb < *minbsb)
                            *minbsb = bsb;
                    }
                    else
                    {
                        // seacs are present only if subsetting a cff font, so the original lsb is valid.
                        if (lvm->topSideBearing < *mintsb)
                            *mintsb = lvm->topSideBearing;
                        // check of rsb not needed since the base character will be checked within this loop
                    }
                }
                if (lvm->advanceHeight > *maxadvance)
                    *maxadvance = lvm->advanceHeight;
                j++;
            }
        }
    }

    return LF_ERROR_OK;
}

USHORT VMTX_getNumVMetrics(LF_FONT* lfFont)
{
    USHORT numVMetrics = 0;
    vmtx_table* table = (vmtx_table*)map_at(&lfFont->table_map, (void*)TAG_VMTX);

    if(table)
        VMTX_getNumMetrics(table, &numVMetrics);

    return numVMetrics;
}

static LF_ERROR VMTX_buildTable(LF_FONT* lfFont, BYTE** tableData, size_t* tableSize)
{
    *tableData = NULL;
    *tableSize = 0;

    vmtx_table* table = (vmtx_table*)map_at(&lfFont->table_map, (void*)TAG_VMTX);
    if (table == NULL)
        return LF_TABLE_MISSING;

    LF_ERROR error = VMTX_getTableSize(lfFont, tableSize);
    if (error != LF_ERROR_OK)
        return error;

    size_t paddedSize = *tableSize;
    *tableData = UTILS_AllocTable(&paddedSize);

    if(*tableData == NULL)
    {
        DEBUG_LOG_ERROR("allocation failure in VMTX_buildTable");
        return LF_OUT_OF_MEMORY;
    }

    LF_STREAM stream;
    STREAM_initMemStream(&stream, *tableData, *tableSize);

    ASSERT(table->numVMetrics >= 1);

    USHORT index = 0;

    for (size_t i = 0; i < table->metricsVector.count; i++)
    {
        longVerMetric* lvm = (longVerMetric *)vector_at(&table->metricsVector, i);

        if(lvm && (lvm != (longVerMetric *)(intptr_t)VMTX_MARK_REMOVED))
        {
            if (index < table->numVMetrics)
            {
                STREAM_writeUShort(&stream, lvm->advanceHeight);
                STREAM_writeShort(&stream, lvm->topSideBearing);
            }
            else
            {
                STREAM_writeShort(&stream, lvm->topSideBearing);
            }

            index++;
        }
    }

    return LF_ERROR_OK;
}

LF_ERROR VMTX_writeTable(LF_FONT* lfFont, sfnt_table_record* record, LF_STREAM* stream)
{
    size_t tableSize;
    BYTE* tableData;

    LF_ERROR error = VMTX_buildTable(lfFont, &tableData, &tableSize);
    if (error != LF_ERROR_OK)
        return error;

    //UTILS_PadTable(&tableData, tableSize, &paddedLen);

    record->checkSum = UTILS_CalcTableChecksum(tableData, tableSize);
    record->length = (ULONG)tableSize;
    record->offset = (ULONG)STREAM_streamPos(stream);

    STREAM_writeChunk(stream, tableData, (tableSize + 3) & ~3);
    free(tableData);

    return LF_ERROR_OK;
}

LF_ERROR VMTX_freeTable(LF_FONT* lfFont)
{
    vmtx_table* table = (vmtx_table*)map_at(&lfFont->table_map, (void*)TAG_VMTX);

    if(table != NULL)
    {
        VMTX_cleanupMetricsMap(table);

        free(table);
    }
    return LF_ERROR_OK;
}
