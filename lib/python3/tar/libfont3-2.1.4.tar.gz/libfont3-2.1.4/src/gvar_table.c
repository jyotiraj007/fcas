// Copyright (C) 2016 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// gvar_table.c

#include <stdlib.h>
#include "gvar_table.h"
#include "table_tags.h"
#include "utils.h"

static void GVAR_cleanupVarMap(LF_MAP* varmap);

LF_ERROR GVAR_readTable(LF_FONT* lfFont, const sfnt_table_record* record, LF_STREAM* stream)
{
    if (record->length == 0)
        return LF_BAD_FORMAT;

    if (STREAM_streamSeek(stream, record->offset) != 0)
        return LF_INVALID_OFFSET;

    gvar_table* table = (gvar_table*)calloc(1, sizeof(gvar_table));
    if (NULL == table)
        return LF_OUT_OF_MEMORY;

    if (STREAM_streamSeek(stream, record->offset) != 0)
    {
        free(table);
        return LF_INVALID_OFFSET;
    }

    // Read header
    table->version = STREAM_readUShort(stream);
    table->reserved = STREAM_readUShort(stream);
    table->axisCount = STREAM_readUShort(stream);
    table->sharedCoordCount = STREAM_readUShort(stream);
    table->offsetToCoord = STREAM_readULong(stream);
    table->glyphCount = STREAM_readUShort(stream);
    table->flags = STREAM_readUShort(stream);
    table->offsetToData = STREAM_readULong(stream);

    // Read offset array
    boolean offsetsAreWords = ((table->flags & 0x1) == 0) ? TRUE : FALSE;

    LF_VECTOR offsetArray;

    LF_ERROR error = vector_init(&offsetArray, table->glyphCount+1, 1);
    if (LF_ERROR_OK != error)
    {
        free(table);
        return error;
    }

    for (int i = 0; i < table->glyphCount+1; i++)
    {
        if (TRUE == offsetsAreWords)
        {
            USHORT offset = STREAM_readUShort(stream);

            error = vector_push_back(&offsetArray, (void*)(intptr_t)offset);

            if (LF_ERROR_OK != error)
            {
                vector_free(&offsetArray);
                free(table);
                return error;
            }
        }
        else
        {
            ULONG offset = STREAM_readULong(stream);

            error = vector_push_back(&offsetArray, (void*)(intptr_t)offset);

            if (LF_ERROR_OK != error)
            {
                vector_free(&offsetArray);
                free(table);
                return error;
            }
        }
    }

    // Read shared coordinate
    USHORT numVals = (USHORT)(table->sharedCoordCount * table->axisCount);

    error = vector_init(&table->sharedCoords, numVals, 1);
    if (LF_ERROR_OK != error)
    {
        vector_free(&offsetArray);
        free(table);
        return error;
    }

    for (int i = 0; i < numVals; i++)
    {
        SHORTFIXED val = STREAM_readShort(stream);

        error = vector_push_back(&table->sharedCoords, (void*)(intptr_t)val);
        if (LF_ERROR_OK != error)
        {
            vector_free(&table->sharedCoords);
            vector_free(&offsetArray);
            free(table);
            return error;
        }
    }

    // Read variation data
    map_init(&table->variationMap, integer_compare);

    for (int i = 0; i < table->glyphCount; i++)
    {
        ULONG currentOffset = (ULONG)(intptr_t)vector_at(&offsetArray, i);
        ULONG nextOffset = (ULONG)(intptr_t)vector_at(&offsetArray, i+1);
        ULONG variationLen = nextOffset - currentOffset;

        glyph_variation* gv = (glyph_variation*)calloc(1, sizeof(glyph_variation));
        if (NULL == gv)
        {
            GVAR_cleanupVarMap(&table->variationMap);
            vector_free(&table->sharedCoords);
            vector_free(&offsetArray);
            free(table);
            return LF_OUT_OF_MEMORY;
        }

        if (variationLen != 0)
        {
            ULONG offsetToGV = record->offset + table->offsetToData + currentOffset;

            if (STREAM_streamSeek(stream, offsetToGV) != 0)
            {
                free(gv);
                GVAR_cleanupVarMap(&table->variationMap);
                vector_free(&table->sharedCoords);
                vector_free(&offsetArray);
                free(table);
                return LF_INVALID_OFFSET;
            }

            gv->length = variationLen;
            gv->data = STREAM_readChunk(stream, variationLen);
        }

        map_insert(&table->variationMap, (void*)(intptr_t)i, gv);
    }

    map_insert(&lfFont->table_map, (void*)(intptr_t)record->tag, table);

    vector_free(&offsetArray);

    return LF_ERROR_OK;
}

LF_ERROR GVAR_removeGlyph(LF_FONT* lfFont, ULONG index)
{
    gvar_table* table = (gvar_table*)map_at(&lfFont->table_map, (void*)(long)TAG_GVAR);
    if (table == NULL)
        return LF_TABLE_MISSING;

    glyph_variation* gv = (glyph_variation*)map_at(&table->variationMap, (void*)(intptr_t)index);

    if (NULL != gv)
    {
        free(gv->data);
        free(gv);

        map_erase(&table->variationMap, (void*)(intptr_t)index);
    }

    return LF_ERROR_OK;
}

LF_ERROR GVAR_remapTable(LF_FONT* lfFont, LF_MAP *glyphIndexMap)
{
    if ((lfFont == NULL) || (glyphIndexMap == NULL))
        return LF_INVALID_PARAM;

    gvar_table* table = (gvar_table*)map_at(&lfFont->table_map, (void*)(long)TAG_GVAR);
    if (table == NULL)
        return LF_TABLE_MISSING;

    LF_MAP_ITER* mapIter = map_begin(&table->variationMap);
    if (NULL == mapIter)
        return LF_OUT_OF_MEMORY;

    rb_tree_node* node = map_next(mapIter);

    while (node != NULL)
    {
        node->key = map_at(glyphIndexMap, node->key);
        node = map_next(mapIter);
    }

    map_free_iter(mapIter);

    return LF_ERROR_OK;
}

LF_ERROR GVAR_isTableEmpty(LF_FONT* lfFont)
{
    gvar_table* table = (gvar_table*)map_at(&lfFont->table_map, (void*)(long)TAG_GVAR);
    if (table == NULL)
        return LF_TABLE_MISSING;

    if (0 != map_size(&table->variationMap))
        return LF_ERROR_OK;

    return LF_EMPTY_TABLE;
}

static LF_ERROR GVAR_variationsSize(gvar_table* table, size_t* varsSize)
{
    *varsSize = 0;

    LF_MAP_ITER* mapIter = map_begin(&table->variationMap);
    if (NULL == mapIter)
        return LF_OUT_OF_MEMORY;

    rb_tree_node* node = map_next(mapIter);

    while (node != NULL)
    {
        glyph_variation* gv = (glyph_variation*)node->data;

        *varsSize += gv->length;

        node = map_next(mapIter);
    }

    map_free_iter(mapIter);

    return LF_ERROR_OK;
}

LF_ERROR GVAR_getTableSize(LF_FONT* lfFont, size_t* tableSize)
{
    gvar_table* table = (gvar_table*)map_at(&lfFont->table_map, (void*)(long)TAG_GVAR);

    *tableSize = 0;

    if(table == NULL)
        return LF_TABLE_MISSING;

    // Header
    size_t headerSize = (6 * sizeof(uint16)) + (2 * sizeof(ULONG));

    // Global coordinates
    size_t globalCoordsSize = table->sharedCoordCount * table->axisCount * sizeof(SHORTFIXED);

    // variation data
    size_t variationDataSize;

    LF_ERROR error = GVAR_variationsSize(table, &variationDataSize);
    if (error != LF_ERROR_OK)
        return error;

    // offset array
    size_t offsetArraySize;

    // if there is more than 64K of variation data, the offsets will be longs, otherwise words
    if (variationDataSize > 65535)
        offsetArraySize = (map_size(&table->variationMap) + 1) * sizeof(ULONG);
    else
        offsetArraySize = (map_size(&table->variationMap) + 1) * sizeof(uint16);

    *tableSize = headerSize + globalCoordsSize + offsetArraySize + variationDataSize;

    return LF_ERROR_OK;
}

static LF_ERROR GVAR_buildTable(LF_FONT* lfFont, BYTE** tableData, size_t* tableSize)
{
    *tableData = NULL;
    *tableSize = 0;

    gvar_table* table = (gvar_table*)map_at(&lfFont->table_map, (void*)(long)TAG_GVAR);
    if (table == NULL)
        return LF_TABLE_MISSING;

    LF_ERROR error = GVAR_getTableSize(lfFont, tableSize);
    if (error != LF_ERROR_OK)
        return error;

    size_t paddedSize = *tableSize;
    *tableData = UTILS_AllocTable(&paddedSize);

    if (*tableData == NULL)
    {
        DEBUG_LOG_ERROR("allocation failure in GVAR_buildTable");
        return LF_OUT_OF_MEMORY;
    }

    size_t variationsSize;

    error = GVAR_variationsSize(table, &variationsSize);
    if (error != LF_ERROR_OK)
        return error;

    boolean offsetsAreLongs = (variationsSize > 65535) ? TRUE : FALSE;

    size_t headerSize = (6 * sizeof(uint16)) + (2 * sizeof(ULONG));
    size_t offsetArraySize = (map_size(&table->variationMap) + 1) *  ((offsetsAreLongs) ? sizeof(ULONG) : sizeof(uint16));
    size_t globalCoordSize = table->sharedCoordCount * table->axisCount * sizeof(SHORTFIXED);

    LF_STREAM stream;
    STREAM_initMemStream(&stream, *tableData, *tableSize);

    // write header
    STREAM_writeUShort(&stream, table->version);
    STREAM_writeUShort(&stream, 0);                 // reserved
    STREAM_writeUShort(&stream, table->axisCount);
    STREAM_writeUShort(&stream, table->sharedCoordCount);
    STREAM_writeULong(&stream, (ULONG)(headerSize + offsetArraySize));
    STREAM_writeUShort(&stream, (USHORT)map_size(&table->variationMap));
    STREAM_writeUShort(&stream, (offsetsAreLongs) ? 0x1 : 0x0);
    STREAM_writeULong(&stream, (ULONG)(headerSize + offsetArraySize + globalCoordSize));

    // write offset array
    size_t curOffset = 0;
    size_t numGlyphs = map_size(&table->variationMap);

    if (offsetsAreLongs)
    {
        for (size_t i = 0; i < numGlyphs; i++)
        {
            STREAM_writeULong(&stream, (ULONG)curOffset);

            glyph_variation* gv = (glyph_variation*)map_at(&table->variationMap, (void*)(intptr_t)i);

            curOffset += gv->length;
        }
        STREAM_writeULong(&stream, (ULONG)curOffset);
    }
    else
    {
        for (size_t i = 0; i < numGlyphs; i++)
        {
            STREAM_writeUShort(&stream, (USHORT)(curOffset >> 1));

            glyph_variation* gv = (glyph_variation*)map_at(&table->variationMap, (void*)(intptr_t)i);

            curOffset += gv->length;
        }
        STREAM_writeUShort(&stream, (USHORT)(curOffset >> 1));
    }

    // write global coordinates
    size_t numSharedCoords = table->axisCount * table->sharedCoordCount;

    for (size_t i = 0; i < numSharedCoords; i++)
    {
        STREAM_writeUShort(&stream, (USHORT)(SHORTFIXED)(intptr_t)vector_at(&table->sharedCoords, i));
    }

    // write variations
    for (size_t i = 0; i < numGlyphs; i++)
    {
        glyph_variation* gv = (glyph_variation*)map_at(&table->variationMap, (void*)(intptr_t)i);

        STREAM_writeChunk(&stream, gv->data, gv->length);
    }

    return LF_ERROR_OK;
}

LF_ERROR GVAR_writeTable(LF_FONT* lfFont, sfnt_table_record* record, LF_STREAM* stream)
{
    size_t tableSize;
    BYTE* tableData;

    LF_ERROR error = GVAR_buildTable(lfFont, &tableData, &tableSize);
    if (error != LF_ERROR_OK)
        return error;

    record->checkSum = UTILS_CalcTableChecksum(tableData, tableSize);
    record->length = (ULONG)tableSize;
    record->offset = (ULONG)STREAM_streamPos(stream);

    STREAM_writeChunk(stream, tableData, (tableSize + 3) & ~3);
    free(tableData);

    return LF_ERROR_OK;
}

static void GVAR_cleanupVarMap(LF_MAP* varmap)
{
    LF_MAP_ITER* mapIter = map_begin(varmap);
    if (NULL == mapIter)
        return;

    rb_tree_node* node = map_next(mapIter);

    while (node != NULL)
    {
        glyph_variation* gv = (glyph_variation*)node->data;

        free(gv->data);
        free(gv);
        node = map_next(mapIter);
    }

    map_free_iter(mapIter);

    map_clear(varmap);
}

LF_ERROR GVAR_freeTable(LF_FONT* lfFont)
{
    gvar_table* table = (gvar_table*)map_at(&lfFont->table_map, (void*)(long)TAG_GVAR);

    if(table)
    {
        vector_free(&table->sharedCoords);

        GVAR_cleanupVarMap(&table->variationMap);

        free(table);
    }

    return LF_ERROR_OK;
}
