// Copyright (C) 2014, 2015 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// cff_table.c

#include "cff_table.h"
#include "cff_core.h"
//lint -esym(528,ExpertSID, ExpertSubsetSID,adobestdvector,ISOAdobeSID) don�t complain if not referenced
#include "cff_data.h"
#include "table_tags.h"
#include "utils.h"

LF_ERROR CFF__readTable(LF_FONT* lfFont, const sfnt_table_record* record, LF_STREAM* stream)
{
    if (record == NULL)
        return LF_INVALID_PARAM;

    if (STREAM_streamSeek(stream, record->offset) == 0)
    {
        // allocate table object
        cff_table* cffTable = (cff_table*)calloc(1, sizeof(cff_table));
        if (cffTable == NULL)
            return LF_OUT_OF_MEMORY;

        // allocate/read-in the raw cff data
        cffTable->rawTableBlock = (BYTE*)STREAM_readChunk(stream, record->length);
        if (cffTable->rawTableBlock == NULL)
        {
            free(cffTable);
            return LF_OUT_OF_MEMORY;
        }

        CFF_ERROR cffErr = cff_load(cffTable->rawTableBlock, record->length, &cffTable->cffTable);
        if (cffErr != CFF_ERR_OK)
        {
            free(cffTable->rawTableBlock);
            free(cffTable);
            return cff_mapCffErrorToLfError(cffErr);
        }

        ASSERT(cffTable->cffTable->numGlyphs == cff_indexGetCount(cffTable->cffTable->charStringsIndex));

        cffTable->charStringMap = map_create(integer_compare);
        if (cffTable->charStringMap == NULL)
        {
            cff_unload(cffTable->cffTable);
            free(cffTable->rawTableBlock);
            free(cffTable);
            return LF_OUT_OF_MEMORY;
        }

        cffErr = cff_analyzeCharstrings(cffTable->cffTable, cffTable->charStringMap);
        if (cffErr != CFF_ERR_OK)
        {
            cleanupCharStringMap(cffTable);
            cff_unload(cffTable->cffTable);
            free(cffTable->rawTableBlock);
            free(cffTable);
            return cff_mapCffErrorToLfError(cffErr);
        }

        map_insert(&lfFont->table_map, (void*)(intptr_t)record->tag, cffTable);
    }

    return LF_ERROR_OK;
}

LF_ERROR CFF__createTable(LF_FONT* lfFont)
{
    // create a new empty table
    cff_table* cffTable = (cff_table*)calloc(1, sizeof(cff_table));
    if (cffTable == NULL)
        return LF_OUT_OF_MEMORY;

    cffTable->charStringMap = map_create(integer_compare);
    if (cffTable->charStringMap == NULL)
    {
        free(cffTable);
        return LF_OUT_OF_MEMORY;
    }

    map_insert(&lfFont->table_map, (void*)TAG_CFF, cffTable);

    return LF_ERROR_OK;
}

LF_ERROR CFF__removeGlyph(const LF_FONT* lfFont, ULONG index)
{
    cff_table* cffTable = (cff_table*)map_at(&lfFont->table_map, (void*)TAG_CFF);
    if (cffTable == NULL)
        return LF_TABLE_MISSING;

    if (cffTable->SIDMap == NULL)   // defer creation until we know we are subsetting
    {
        cffTable->SIDMap = map_create(integer_compare);
        if (cffTable->SIDMap == NULL)
            return LF_OUT_OF_MEMORY;

        size_t numSIDs = cff_indexGetCount(cffTable->cffTable->stringIndex);

        for (size_t i = 0; i < numSIDs; i++)
            map_insert(cffTable->SIDMap, (void*)(i + NUM_STD_STRINGS), (void*)(i + NUM_STD_STRINGS));
    }

    cffAnalyzedCharstring* acs = (cffAnalyzedCharstring*)map_at(cffTable->charStringMap, (void*)(intptr_t)index);
    if (acs != NULL)
    {
        // mark that the sid is no longer needed (NOTE: assuming that the SID is referenced only by the charstring!!)
        if ((cffTable->cffTable->isCID == FALSE) && (acs->sid >= NUM_STD_STRINGS))
            map_erase(cffTable->SIDMap, (void*)(intptr_t)acs->sid);

        // get rid of it
        cff_analyzedCharStringDestroy(acs);
        map_erase(cffTable->charStringMap, (void*)(intptr_t)index);
    }

    if (cffTable->builtTable != NULL)
    {
        cff_destroyCFF_TAB(cffTable->builtTable);
        cffTable->builtTable = NULL;
    }

    return LF_ERROR_OK;
}

LF_ERROR CFF__keepGlyphs(const LF_FONT* lfFont, GlyphList* keepList)
{
    cff_table* table = (cff_table*)map_at(&lfFont->table_map, (void*)TAG_CFF);
    if (table == NULL)
        return LF_EMPTY_TABLE;

    size_t countGlyphs = 0;
    ULONG numKeepGlyphs;
    GlyphID* glyphList = Keep_getSortedGlyphIDList(keepList, &numKeepGlyphs);
    if (glyphList == NULL)
        return LF_OUT_OF_MEMORY;

    GlyphID* curGlyphPtr = glyphList;

    for (size_t i = 0; i < table->charStringMap->count; i++)
    {
        if (countGlyphs < numKeepGlyphs && i >= *curGlyphPtr)
        {
            cffAnalyzedCharstring* acs = (cffAnalyzedCharstring*)map_at(table->charStringMap, (void*)(intptr_t)i);

            if ((acs != NULL) && (acs->seacInfo != NULL))
            {
                LF_ERROR status = Keep_addGlyph(keepList, acs->seacInfo->base);
                if ((status != LF_ADDED_GLYPH) && (status != LF_ERROR_OK))
                {
                    free(glyphList);
                    return status;
                }
                status = Keep_addGlyph(keepList, acs->seacInfo->accent);
                if ((status != LF_ADDED_GLYPH) && (status != LF_ERROR_OK))
                {
                    free(glyphList);
                    return status;
                }
            }

            curGlyphPtr++;
            countGlyphs++;
        }
    }

    free(glyphList);

    return LF_ERROR_OK;
}

LF_ERROR CFF__remapTable(const LF_FONT* lfFont, LF_MAP *remap)
{
    cff_table* cffTable = (cff_table*)map_at(&lfFont->table_map, (void*)TAG_CFF);
    if (cffTable == NULL)
        return LF_EMPTY_TABLE;

    // create a new (analyzed) charstring map with keys 0 - (nGlyphs in subset -1), get rid of old map

    LF_MAP* newMap = map_create(integer_compare);
    if (newMap == NULL)
        return LF_OUT_OF_MEMORY;

    LF_MAP_ITER* mapIter = map_begin(remap);
    if (mapIter == NULL)
    {
        free(newMap);
        return LF_OUT_OF_MEMORY;
    }

    rb_tree_node* node = map_next(mapIter);

    while (node)
    {
        GlyphID oldIndex = (GlyphID)(intptr_t)node->key;
        GlyphID newIndex = (GlyphID)(intptr_t)node->data;

        cffAnalyzedCharstring* acs = (cffAnalyzedCharstring*)map_at(cffTable->charStringMap, (void*)(intptr_t)node->key);

        map_insert(cffTable->charStringMap, (void*)(intptr_t)oldIndex, NULL);
        map_insert(newMap, (void*)(intptr_t)newIndex, acs);
        node = map_next(mapIter);
    }

    map_free_iter(mapIter);

    // free anything left in the old map
    map_clear(cffTable->charStringMap);
    free(cffTable->charStringMap);

    cffTable->charStringMap = newMap;

    // TODO - this could be deferred until we know we have to write a cff
    // remap the SIDs (if needed)
    if (cffTable->SIDMap != NULL)
    {
        mapIter = map_begin(cffTable->SIDMap);
        if (mapIter == NULL)
            return LF_OUT_OF_MEMORY;

        cffSID newSID = NUM_STD_STRINGS;

        node = map_next(mapIter);

        while (node)
        {
            node->data = (void*)(intptr_t)(newSID++);

            node = map_next(mapIter);
        }

        map_free_iter(mapIter);
    }

    // now go through and remap the seacs
    mapIter = map_begin(cffTable->charStringMap);
    if (mapIter == NULL)
        return LF_OUT_OF_MEMORY;

    node = map_next(mapIter);

    while (node)
    {
        cffAnalyzedCharstring* acs = (cffAnalyzedCharstring*)map_at(cffTable->charStringMap, (void*)(intptr_t)node->key);
        if (acs == NULL)
            return LF_BAD_FORMAT;

        if (acs->seacInfo != NULL)
        {
            GlyphID oldBase = acs->seacInfo->base;
            GlyphID oldAccent = acs->seacInfo->accent;

            acs->seacInfo->base = (GlyphID)(intptr_t)map_at(remap, (void*)(intptr_t)oldBase);
            acs->seacInfo->accent = (GlyphID)(intptr_t)map_at(remap, (void*)(intptr_t)oldAccent);

            ASSERT(acs->seacInfo->base);
            ASSERT(acs->seacInfo->accent);
        }

        if ((cffTable->SIDMap != NULL) && (cffTable->cffTable->isCID == FALSE) && (acs->sid >= NUM_STD_STRINGS))
            acs->sid = (cffSID)(intptr_t)map_at(cffTable->SIDMap, (void*)(intptr_t)acs->sid); // could be deferred

        node = map_next(mapIter);
    }

    map_free_iter(mapIter);

    // remap sids in topdict (deferred til later)

    // remap the FD indexes if CID font
    if (cffTable->cffTable->isCID == TRUE)
    {
        CFF_TAB* ct = cffTable->cffTable;

        // just create a new array
        cffCard8* oldArray = ct->fdSelect.fdIndexArray;

        size_t numGlyphsInSubset = map_size(remap);

        cffCard8* newArray = (cffCard8*)calloc(numGlyphsInSubset, sizeof(cffCard8));
        if (newArray == NULL)
        {
            //todo
            return LF_OUT_OF_MEMORY;
        }

        mapIter = map_begin(remap);
        if (mapIter == NULL)
        {
            free(newArray);
            return LF_OUT_OF_MEMORY;
        }

        node = map_next(mapIter);

        while (node)
        {
            GlyphID oldID = (GlyphID)(intptr_t)node->key;
            GlyphID newID = (GlyphID)(intptr_t)node->data;

            newArray[newID] = oldArray[oldID];

            node = map_next(mapIter);
        }

        map_free_iter(mapIter);

        // switch over
        free(oldArray);

        ct->fdSelect.fdIndexArray = newArray;
    }

    return LF_ERROR_OK;
}

//lint -e{702} suppress Shift right of signed quantity (int) for this function
LF_ERROR CFF__getGlyphBoundingBox(const LF_FONT* lfFont, GlyphID id, SHORT* xMin, SHORT* yMin, SHORT* xMax, SHORT* yMax)
{
    cff_table* cffTable = (cff_table*)map_at(&lfFont->table_map, (void*)TAG_CFF);
    if (cffTable == NULL)
        return LF_EMPTY_TABLE;

    if (cffTable->charStringMap == NULL)
        return LF_BAD_FORMAT;

    cffAnalyzedCharstring*acs = (cffAnalyzedCharstring*)map_at(cffTable->charStringMap, (void*)(intptr_t)id);
    if (acs == NULL)
        return LF_BAD_FORMAT;

    if (acs->isEmpty == TRUE || acs->numContours == 0)
    {
        *xMin = *yMin = *xMax = *yMax = 0;
    }
    else if (acs->seacInfo)
    {
        GlyphID baseID = acs->seacInfo->base;
        GlyphID accentID = acs->seacInfo->accent;
        cffAnalyzedCharstring* baseacs = (cffAnalyzedCharstring*)map_at(cffTable->charStringMap, (void*)(intptr_t)baseID);
        cffAnalyzedCharstring* accentacs = (cffAnalyzedCharstring*)map_at(cffTable->charStringMap, (void*)(intptr_t)accentID);
        FIXED accentXmin = accentacs->bb.xMin + acs->seacInfo->accentX;
        FIXED accentXmax = accentacs->bb.xMax + acs->seacInfo->accentX;
        FIXED accentYmin = accentacs->bb.yMin + acs->seacInfo->accentY;
        FIXED accentYmax = accentacs->bb.yMax + acs->seacInfo->accentY;

        *xMin = (baseacs->bb.xMin < accentXmin) ? (SHORT)(baseacs->bb.xMin >> 16) : (SHORT)(accentXmin >> 16);
        *xMax = (baseacs->bb.xMax > accentXmax) ? (SHORT)(baseacs->bb.xMax >> 16) : (SHORT)(accentXmax >> 16);
        *yMin = (baseacs->bb.yMin < accentYmin) ? (SHORT)(baseacs->bb.yMin >> 16) : (SHORT)(accentYmin >> 16);
        *yMax = (baseacs->bb.yMax > accentYmax) ? (SHORT)(baseacs->bb.yMax >> 16) : (SHORT)(accentYmax >> 16);
    }
    else
    {
        *xMin = (SHORT)(acs->bb.xMin >> 16);
        *xMax = (SHORT)(acs->bb.xMax >> 16);
        *yMin = (SHORT)(acs->bb.yMin >> 16);
        *yMax = (SHORT)(acs->bb.yMax >> 16);
    }

    return LF_ERROR_OK;
}

//lint -e{702} suppress Shift right of signed quantity (int) for this function
LF_ERROR CFF__getBoundingBox(const LF_FONT* lfFont, SHORT* xMin, SHORT* yMin, SHORT* xMax, SHORT* yMax)
{
    cff_table* cffTable = (cff_table*)map_at(&lfFont->table_map, (void*)TAG_CFF);
    if (cffTable == NULL)
        return LF_EMPTY_TABLE;

    if (cffTable->charStringMap == NULL)
        return LF_BAD_FORMAT;

    if (cffTable->builtTable != NULL)
    {
        *xMin = (SHORT)(cffTable->builtTable->bb.xMin >> 16);
        *xMax = (SHORT)(cffTable->builtTable->bb.xMax >> 16);
        *yMin = (SHORT)(cffTable->builtTable->bb.yMin >> 16);
        *yMax = (SHORT)(cffTable->builtTable->bb.yMax >> 16);

        return LF_ERROR_OK;
    }

    LF_MAP_ITER* mapIter = map_begin(cffTable->charStringMap);
    if (mapIter == NULL)
    {
        return LF_OUT_OF_MEMORY;
    }

    rb_tree_node* node = map_next(mapIter);

    FIXED fxMax, fxMin, fyMax, fyMin;
    
    fxMin = fyMin = 2147483647L;
    fxMax = fyMax = -fxMin;

    while (node)
    {
        cffAnalyzedCharstring*acs = (cffAnalyzedCharstring*)node->data;

        if (acs->isEmpty == FALSE && acs->numContours != 0)
        {
            if (acs->bb.xMin < fxMin)
                fxMin = acs->bb.xMin;
            if (acs->bb.xMax > fxMax)
                fxMax = acs->bb.xMax;
            if (acs->bb.yMin < fyMin)
                fyMin = acs->bb.yMin;
            if (acs->bb.yMax > fyMax)
                fyMax = acs->bb.yMax;
        }
        else if (acs->seacInfo)
        {
            GlyphID baseID = acs->seacInfo->base;
            GlyphID accentID = acs->seacInfo->accent;
            cffAnalyzedCharstring* baseacs = (cffAnalyzedCharstring*)map_at(cffTable->charStringMap, (void*)(intptr_t)baseID);
            cffAnalyzedCharstring* accentacs = (cffAnalyzedCharstring*)map_at(cffTable->charStringMap, (void*)(intptr_t)accentID);
            FIXED accentXmin = accentacs->bb.xMin + acs->seacInfo->accentX;
            FIXED accentXmax = accentacs->bb.xMax + acs->seacInfo->accentX;
            FIXED accentYmin = accentacs->bb.yMin + acs->seacInfo->accentY;
            FIXED accentYmax = accentacs->bb.yMax + acs->seacInfo->accentY;
            if (accentXmin < fxMin)
                fxMin = accentXmin;
            if (accentXmax > fxMax)
                fxMax = accentXmax;
            if (accentYmin < fyMin)
                fyMin = accentYmin;
            if (accentYmax > fyMax)
                fyMax = accentYmax;
            if (baseacs->bb.xMin < fxMin)
                fxMin = baseacs->bb.xMin;
            if (baseacs->bb.xMax > fxMax)
                fxMax = baseacs->bb.xMax;
            if (baseacs->bb.yMin < fyMin)
                fyMin = baseacs->bb.yMin;
            if (baseacs->bb.yMax > fyMax)
                fyMax = baseacs->bb.yMax;
        }

        node = map_next(mapIter);
    }

    map_free_iter(mapIter);

    *xMin = (SHORT)(fxMin >> 16);            // floor
    *xMax = (SHORT)((fxMax + 0xFFFF) >> 16); // ceiling
    *yMin = (SHORT)(fyMin >> 16);            // floor
    *yMax = (SHORT)((fyMax + 0xFFFF) >> 16); // ceiling

    return LF_ERROR_OK;
}

static size_t CFF_getSizeInternal(const CFF_TAB_BUILD* cff)
{
    // estimate the size needed for the cff table
    size_t requiredSize = (3 * sizeof(cffCard8)) + sizeof(cffOffSize);         // header (4 bytes)
    requiredSize += cff_indexGetLength(cff->nameIndex);
    requiredSize += cff_indexGetLength(cff->topDictIndex);
    requiredSize += cff_indexGetLength(cff->stringIndex);
    requiredSize += cff_indexGetLength(cff->globalSubrIndex);
    requiredSize += 0;                                                  // encoding TODO - do we need to write encoding??
    requiredSize += cff->encodedCharsetSize;
    if (cff->isCID == TRUE)
    {
        requiredSize += cff->encodedFDSelectSize;                       // FDselect
        requiredSize += cff_indexGetLength(cff->FDIndex);               // Font Dict Index

        for (LONG i = 0; i < cff->FDcount; i++)
        {
            if (cff->FDinfoArray[i].localSubr != NULL)
                requiredSize += cff_indexGetLength(cff->FDinfoArray[i].localSubr);
            requiredSize += cff->FDinfoArray[i].encodedPrivateDictSize;
        }
    }
    requiredSize += cff_indexGetLength(cff->charStringsIndex);
    requiredSize += cff->encodedPrivateDictSize;
    if (cff->localSubrIndex != NULL)
        requiredSize += cff_indexGetLength(cff->localSubrIndex);

    return requiredSize;
}

LF_ERROR CFF__getTableSize(const LF_FONT* lfFont, size_t* tableSize)
{
    *tableSize = 0;

    cff_table* table = (cff_table*)map_at(&lfFont->table_map, (void*)TAG_CFF);
    if (table == NULL)
        return LF_TABLE_MISSING;

    if (table->builtTable == NULL)
    {
        CFF_ERROR cffErr = cff_buildCFF_TAB(table->cffTable, table->SIDMap, table->charStringMap, &table->builtTable);
        if (cffErr != CFF_ERR_OK)
        {
            return cff_mapCffErrorToLfError(cffErr);
        }
    }

    *tableSize = CFF_getSizeInternal(table->builtTable);

    return LF_ERROR_OK;
}

LF_ERROR CFF__replaceCharstring(const LF_FONT* lfFont, USHORT index, cffAnalyzedCharstring* cs)
{
    cff_table* table = (cff_table*)map_at(&lfFont->table_map, (void*)TAG_CFF);
    if (table == NULL)
        return LF_TABLE_MISSING;

    cffAnalyzedCharstring* old = map_at(table->charStringMap, (void*)(intptr_t)index);
    if (old)
        cff_analyzedCharStringDestroy(old);

    map_insert(table->charStringMap, (void*)(intptr_t)index, (void*)cs);

    return LF_ERROR_OK;
}

static LF_ERROR CFF__buildTable(const cff_table* table, BYTE** rawTable, size_t* tableSize, size_t* paddedTableSize)
{
    LF_ERROR error;

    // <assumption is that the content of table->builtTable has been created / updated / subsetted prior to this
    //  function. This function (only) calculates the size of the various pieces and puts the data into
    //  a stream. >

    // init result
    *rawTable = NULL;
    *tableSize = 0;
    *paddedTableSize = 0;

    CFF_TAB_BUILD* cff = table->builtTable;
    if (cff == NULL)
        return LF_BAD_FORMAT;

    // estimate the size needed for the cff table
    size_t requiredSize = CFF_getSizeInternal(cff);
    requiredSize = (requiredSize + 3) & ~3;

    // create a stream into which the cff table will be written
    BYTE* cffBuf = (BYTE*)calloc(requiredSize, sizeof(BYTE));
    if (cffBuf == NULL)
        return LF_OUT_OF_MEMORY;

    LF_STREAM cffBufStream;
    STREAM_initMemStream(&cffBufStream, cffBuf, requiredSize);

    // write header
    STREAM_writeByte(&cffBufStream, cff->header.major);
    STREAM_writeByte(&cffBufStream, cff->header.minor);
    STREAM_writeByte(&cffBufStream, cff->header.hdrSize);
    STREAM_writeByte(&cffBufStream, cff->header.offSize);

    // write name index
    error = cff_indexAppendToStream(cff->nameIndex, &cffBufStream);
    if (error != LF_ERROR_OK)
    {
        free(cffBuf);
        return error;
    }

    // write top dict index
    error = cff_indexAppendToStream(cff->topDictIndex, &cffBufStream);
    if (error != LF_ERROR_OK)
    {
        free(cffBuf);
        return error;
    }

    // write string index
    error = cff_indexAppendToStream(cff->stringIndex, &cffBufStream);
    if (error != LF_ERROR_OK)
    {
        free(cffBuf);
        return error;
    }

    // write global subroutine index
    error = cff_indexAppendToStream(cff->globalSubrIndex, &cffBufStream);
    if (error != LF_ERROR_OK)
    {
        free(cffBuf);
        return error;
    }

    // write encoding
    // TODO <for now the Encoding (offset) is set to 0 (standard encoding) in the top dict,
    //       so we don't have to write anything here, although the actual glyphs
    //       may not match the std encoding>


    // write charset
    STREAM_writeChunk(&cffBufStream, cff->encodedCharset, cff->encodedCharsetSize);

    // Note: spec has FDSelect next (CID only), but we write it after charstring index

    // write charstring index
    error = cff_indexAppendToStream(cff->charStringsIndex, &cffBufStream);
    if (error != LF_ERROR_OK)
    {
        free(cffBuf);
        return error;
    }

    if (cff->isCID == FALSE)
    {
        // Non-CID

        // write private dict
        STREAM_writeChunk(&cffBufStream, cff->encodedPrivateDict, cff->encodedPrivateDictSize);

        // write local subroutine index
        if (cff->localSubrIndex != NULL)
        {
            error = cff_indexAppendToStream(cff->localSubrIndex, &cffBufStream);
            if (error != LF_ERROR_OK)
            {
                free(cffBuf);
                return error;
            }
        }
    }
    else
    {
        // CID

        // write FDSelect
        STREAM_writeChunk(&cffBufStream, cff->encodedFDSelect, cff->encodedFDSelectSize);

        // write font dict index
        error = cff_indexAppendToStream(cff->FDIndex, &cffBufStream);
        if (error != LF_ERROR_OK)
        {
            free(cffBuf);
            return error;
        }

        // write private dict and the local subr indexes for each
        for (LONG i = 0; i < cff->FDcount; i++)
        {
            STREAM_writeChunk(&cffBufStream, cff->FDinfoArray[i].encodedPrivateDict, cff->FDinfoArray[i].encodedPrivateDictSize);

            if (cff->FDinfoArray[i].localSubr != NULL)
            {
                error = cff_indexAppendToStream(cff->FDinfoArray[i].localSubr, &cffBufStream);
                if (error != LF_ERROR_OK)
                {
                    free(cffBuf);
                    return error;
                }
            }
        }
    }

    *rawTable = cffBufStream.Base;
    *tableSize = STREAM_streamPos(&cffBufStream);
    *paddedTableSize = (*tableSize + 3) & ~3;
    ASSERT(requiredSize == *paddedTableSize);

    return LF_ERROR_OK;
}

LF_ERROR CFF__writeTable(const LF_FONT* lfFont, sfnt_table_record* record, LF_STREAM* stream)
{
    cff_table* table = (cff_table*)map_at(&lfFont->table_map, (void*)TAG_CFF);
    if (table == NULL)
        return LF_TABLE_MISSING;

    if (table->builtTable == NULL)
    {
        CFF_ERROR cffErr = cff_buildCFF_TAB(table->cffTable, table->SIDMap, table->charStringMap, &table->builtTable);
        if (cffErr != CFF_ERR_OK)
        {
            return cff_mapCffErrorToLfError(cffErr);
        }
    }

    BYTE* tableData = NULL;
    size_t tableLen = 0, paddedLen = 0;

    LF_ERROR error = CFF__buildTable(table, &tableData, &tableLen, &paddedLen);

    if (error == LF_ERROR_OK)
    {
        record->checkSum = UTILS_CalcTableChecksum(tableData, tableLen);
        record->length = (ULONG)tableLen;
        record->offset = (ULONG)STREAM_streamPos(stream);

        STREAM_streamSeek(stream, record->offset);
        STREAM_writeChunk(stream, tableData, paddedLen);

        free(tableData);
    }

    return error;
}

LF_ERROR CFF__getCount(const LF_FONT* lfFont, USHORT* numGlyphs)
{
    *numGlyphs = 0;

    cff_table* cffTable = (cff_table*)map_at(&lfFont->table_map, (void*)TAG_CFF);
    if (cffTable == NULL)
        return LF_TABLE_MISSING;

    if (cffTable->builtTable != NULL)
    {
        *numGlyphs = cffTable->builtTable->numGlyphs;
    }
    else if (cffTable->charStringMap == NULL)
        return LF_BAD_FORMAT;
    else
        *numGlyphs = (USHORT)map_size(cffTable->charStringMap);

    return LF_ERROR_OK;
}

LF_ERROR CFF__getNumContours(const LF_FONT* lfFont, USHORT index, SHORT* numContours)
{
    *numContours = 0;

    cff_table* cffTable = (cff_table*)map_at(&lfFont->table_map, (void*)TAG_CFF);
    if (cffTable == NULL)
        return LF_TABLE_MISSING;

    if (cffTable->builtTable != NULL)
        return LF_UNIMPLEMENTED;        // Path not supported yet
    else if (cffTable->charStringMap == NULL)
        return LF_BAD_FORMAT;
    else
    {
        cffAnalyzedCharstring* acs = (cffAnalyzedCharstring*)map_at(cffTable->charStringMap, (void*)(intptr_t)index);

        if (acs->seacInfo != NULL)
        {
            // find total points and contours
            cffAnalyzedCharstring* base = (cffAnalyzedCharstring*)map_at(cffTable->charStringMap, (void*)(intptr_t)acs->seacInfo->base);
            cffAnalyzedCharstring* accent = (cffAnalyzedCharstring*)map_at(cffTable->charStringMap, (void*)(intptr_t)acs->seacInfo->accent);

            *numContours = (SHORT)(base->numContours + accent->numContours);
        }
        else
        {
            *numContours = (SHORT)acs->numContours;
        }
    }

    return LF_ERROR_OK;
}

void cleanupCharStringMap(const cff_table* table)
{
    LF_MAP_ITER* mapIter;

    mapIter = map_begin(table->charStringMap);
    if (mapIter != NULL)
    {
        rb_tree_node* node = map_next(mapIter);

        while (node)
        {
            cffAnalyzedCharstring* acs = (cffAnalyzedCharstring*)node->data;

            if (acs)
            {
                cff_analyzedCharStringDestroy(acs);
            }

            node = map_next(mapIter);
        }

        map_free_iter(mapIter);
    }
    //else there will be memory leaks

    map_clear(table->charStringMap);
    free(table->charStringMap); //lint !e429
}

LF_ERROR CFF__freeTable(const LF_FONT* lfFont)
{
    cff_table* cffTable = (cff_table*)map_at(&lfFont->table_map, (void*)TAG_CFF);
    if (cffTable == NULL)
        return LF_EMPTY_TABLE;

    if (cffTable->SIDMap != NULL)
    {
        map_clear(cffTable->SIDMap);
        free(cffTable->SIDMap);
    }
    cleanupCharStringMap(cffTable);
    cff_unload(cffTable->cffTable);
    cff_destroyCFF_TAB(cffTable->builtTable);
    free(cffTable->rawTableBlock);
    free(cffTable);

    return LF_ERROR_OK;
}
