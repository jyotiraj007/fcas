// Copyright (C) 2014, 2016 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// lf_map.c

#include <stdlib.h>
#include "lf_map.h"

/*
    Red-Black Tree code borrowed from:
    http://en.literateprograms.org/Red-black_tree_%28C%29
*/

static void map_insert_case1(LF_MAP* map, rb_tree_node* node);
static void map_delete_case1(LF_MAP* map, rb_tree_node* node);

int integer_compare(void* left, void* right)
{
    if((intptr_t)left == (intptr_t)right)
        return 0;

    if((intptr_t)left < (intptr_t)right)
        return -1;

    return 1;
}

void map_init(LF_MAP* map, LF_COMPARE_FUNC func)
{
    map->root = NULL;
    map->compare = func;
    map->count = 0;
}   /*lint !e429*/

LF_MAP* map_create(LF_COMPARE_FUNC func)
{
    rb_tree* tree = (rb_tree*)malloc(sizeof(rb_tree));
    if(tree)
        map_init(tree, func);

    return tree;
}

ULONG map_size(const LF_MAP* map)
{
    return map->count;
}

static rb_tree_node* map_create_node(void* key, void* data,
    rb_node_color color, rb_tree_node* left, rb_tree_node* right)
{
    rb_tree_node* node = (rb_tree_node*)malloc(sizeof(rb_tree_node));

    if(node)
    {
        node->key = key;
        node->data = data;
        node->color = color;
        node->left = left;
        node->right = right;

        if(left != NULL) left->parent = node;
        if(right != NULL) right->parent = node;

        node->parent = NULL;
    }

    return node;
} //lint !e593 (data pointer is freed by client)

static void map_replace_node(LF_MAP* map, rb_tree_node* oldNode, rb_tree_node* newNode)
{
    if (oldNode->parent == NULL)
    {
        map->root = newNode;
    }
    else
    {
        if (oldNode == oldNode->parent->left)
            oldNode->parent->left = newNode;
        else
            oldNode->parent->right = newNode;
    }

    if (newNode != NULL) 
    {
        newNode->parent = oldNode->parent;
    }
}

static void map_rotate_left(LF_MAP* map, rb_tree_node* node) 
{
    rb_tree_node* rightNode = node->right;
    map_replace_node(map, node, rightNode);
    node->right = rightNode->left;

    if (rightNode->left != NULL)
    {
        rightNode->left->parent = node;
    }

    rightNode->left = node;
    node->parent = rightNode;
}

static void map_rotate_right(LF_MAP* map, rb_tree_node* node)
{
    rb_tree_node* leftNode = node->left;
    map_replace_node(map, node, leftNode);
    node->left = leftNode->right;

    if (leftNode->right != NULL)
    {
        leftNode->right->parent = node;
    }

    leftNode->right = node;
    node->parent = leftNode;
}

static rb_node_color map_node_color(rb_tree_node* node)
{
    return node == NULL ? BLACK : node->color;
}

static rb_tree_node* map_node_grandparent(rb_tree_node* node)
{
    return node->parent->parent;
}

static rb_tree_node* map_node_sibling(rb_tree_node* node)
{
    if (node == node->parent->left)
        return node->parent->right;
    else
        return node->parent->left;
}

static rb_tree_node* map_node_uncle(rb_tree_node* node)
{
    return map_node_sibling(node->parent);
}

static void map_insert_case5(LF_MAP* map, rb_tree_node* node)
{
    node->parent->color = BLACK;
    map_node_grandparent(node)->color = RED;

    if (node == node->parent->left && node->parent == map_node_grandparent(node)->left)
    {
        map_rotate_right(map, map_node_grandparent(node));
    }
    else
    {
        map_rotate_left(map, map_node_grandparent(node));
    }
}

static void map_insert_case4(LF_MAP* map, rb_tree_node* node)
{
    if (node == node->parent->right && node->parent == map_node_grandparent(node)->left)
    {
        map_rotate_left(map, node->parent);
        node = node->left;
    } 
    else if (node == node->parent->left && node->parent == map_node_grandparent(node)->right)
    {
        map_rotate_right(map, node->parent);
        node = node->right;
    }

    map_insert_case5(map, node);
}

static void map_insert_case3(LF_MAP* map, rb_tree_node* node)
{
    if (map_node_color(map_node_uncle(node)) == RED)
    {
        node->parent->color = BLACK;
        map_node_uncle(node)->color = BLACK;
        map_node_grandparent(node)->color = RED;
        map_insert_case1(map, map_node_grandparent(node));
    } 
    else 
    {
        map_insert_case4(map, node);
    }
}

static void map_insert_case2(LF_MAP* map, rb_tree_node* node)
{
    if (map_node_color(node->parent) == BLACK)
        return; /* Tree is still valid */
    else
        map_insert_case3(map, node);
}

static void map_insert_case1(LF_MAP* map, rb_tree_node* node)
{
    if (node->parent == NULL)
        node->color = BLACK;
    else
        map_insert_case2(map, node);
}

rb_tree_node* map_insert(LF_MAP* map, void* key, void* data)
{
    rb_tree_node* node = map_create_node(key, data, RED, NULL, NULL);

    if(node != NULL)
    {
        if(map->root == NULL)
        {
            map->root = node;
        }
        else
        {
            rb_tree_node* curNode = map->root;

            for(;;)    //while (1)
            {
                //int result = map->compare(key, curNode->key);
                if((intptr_t)key > (intptr_t)curNode->key)
                {
                    if(curNode->right == NULL)
                    {
                        curNode->right = node;
                        break;
                    }
                    else
                    {
                        curNode = curNode->right;
                    }
                }
                else if((intptr_t)key == (intptr_t)curNode->key)
                {
                    curNode->data = data;
                    free(node);
                    return curNode;
                }
                else// if((long)key < (long)curNode->key)
                {
                    if(curNode->left == NULL)
                    {
                        curNode->left = node;
                        break;
                    }
                    else
                    {
                        curNode = curNode->left;
                    }
                }
            }

            node->parent = curNode;
        }

        map_insert_case1(map, node);

        map->count++;
    }

    return node;
}

static rb_tree_node* map_lookup_node(const LF_MAP* map, void* key)
{
    rb_tree_node* node = map->root;

    while (node != NULL) 
    {
        //int comp_result = map->compare(key, node->key);

        if ((intptr_t)key == (intptr_t)node->key)
        {
            return node;
        } 
        else if ((intptr_t)key < (intptr_t)node->key)
        {
            node = node->left;
        }
        else
        {
            node = node->right;
        }
    }

    return NULL;
}

void* map_at(const LF_MAP* map, void* key)
{
    rb_tree_node* node = map_lookup_node(map, key);

    if(node)
        return node->data;

    return NULL;
}

boolean map_key_exists(LF_MAP* map, void* key)
{
    rb_tree_node* node = map_lookup_node(map, key);

    if (node)
        return TRUE;

    return FALSE;
}

LF_MAP_ITER* map_begin(LF_MAP* map)
{
    LF_MAP_ITER* iter = (LF_MAP_ITER*)calloc(1, sizeof(LF_MAP_ITER));
    rb_tree_node* node = map->root;

    if(iter)
    {
        stack_init(&iter->stack);

        while(node)
        {
            stack_push(&iter->stack, node);
            iter->node = node = node->left;
        }
    }

    return iter;
}

void map_free_iter(LF_MAP_ITER* iter)
{
    vector_free(&iter->stack);
    free(iter);
}

rb_tree_node* map_next(LF_MAP_ITER* iter)
{
    rb_tree_node* returnNode = NULL;

    while(stack_empty(&iter->stack) == FALSE || iter->node != NULL)
    {
        if(iter->node != NULL)
        {
            stack_push(&iter->stack, iter->node);
            iter->node = iter->node->left;
        }
        else
        {
            iter->node = (rb_tree_node*)stack_pop(&iter->stack);
            returnNode = iter->node;
            iter->node = iter->node->right;
            break;
        }
    }

    return returnNode;
}

static rb_tree_node* map_maximum_node(rb_tree_node* n) 
{
    while (n->right != NULL) 
    {
        n = n->right;
    }

    return n;
}

static void map_delete_case6(LF_MAP* map, rb_tree_node* node)
{
    map_node_sibling(node)->color = map_node_color(node->parent);
    node->parent->color = BLACK;

    if (node == node->parent->left) 
    {
        map_node_sibling(node)->right->color = BLACK;
        map_rotate_left(map, node->parent);
    }
    else
    {
        map_node_sibling(node)->left->color = BLACK;
        map_rotate_right(map, node->parent);
    }
}

static void map_delete_case5(LF_MAP* map, rb_tree_node* node)
{
    if (node == node->parent->left &&
        map_node_color(map_node_sibling(node)) == BLACK &&
        map_node_color(map_node_sibling(node)->left) == RED &&
        map_node_color(map_node_sibling(node)->right) == BLACK)
    {
        map_node_sibling(node)->color = RED;
        map_node_sibling(node)->left->color = BLACK;
        map_rotate_right(map, map_node_sibling(node));
    }
    else if (node == node->parent->right &&
             map_node_color(map_node_sibling(node)) == BLACK &&
             map_node_color(map_node_sibling(node)->right) == RED &&
             map_node_color(map_node_sibling(node)->left) == BLACK)
    {
        map_node_sibling(node)->color = RED;
        map_node_sibling(node)->right->color = BLACK;
        map_rotate_left(map, map_node_sibling(node));
    }

    map_delete_case6(map, node);
}

static void map_delete_case4(LF_MAP* map, rb_tree_node* node)
{
    if (map_node_color(node->parent) == RED &&
        map_node_color(map_node_sibling(node)) == BLACK &&
        map_node_color(map_node_sibling(node)->left) == BLACK &&
        map_node_color(map_node_sibling(node)->right) == BLACK)
    {
        map_node_sibling(node)->color = RED;
        node->parent->color = BLACK;
    }
    else
        map_delete_case5(map, node);
}

static void map_delete_case3(LF_MAP* map, rb_tree_node* node)
{
    if (map_node_color(node->parent) == BLACK &&
        map_node_color(map_node_sibling(node)) == BLACK &&
        map_node_color(map_node_sibling(node)->left) == BLACK &&
        map_node_color(map_node_sibling(node)->right) == BLACK)
    {
        map_node_sibling(node)->color = RED;
        map_delete_case1(map, node->parent);
    }
    else
        map_delete_case4(map, node);
}

static void map_delete_case2(LF_MAP* map, rb_tree_node* node)
{
    if (map_node_color(map_node_sibling(node)) == RED)
    {
        node->parent->color = RED;
        map_node_sibling(node)->color = BLACK;

        if (node == node->parent->left)
            map_rotate_left(map, node->parent);
        else
            map_rotate_right(map, node->parent);
    }

    map_delete_case3(map, node);
}

static void map_delete_case1(LF_MAP* map, rb_tree_node* node)
{
    if (node->parent == NULL)
        return;
    else
        map_delete_case2(map, node);
}

void map_erase(LF_MAP* map, void* key)
{
    rb_tree_node* node = map_lookup_node(map, key);
    rb_tree_node* child;

    if(node == NULL)
        return;

    if(node->left && node->right)
    {
        rb_tree_node* pred = map_maximum_node(node->left);
        node->key = pred->key;
        node->data = pred->data;
        node = pred;
    }

    child = node->right == NULL ? node->left : node->right;

    if(map_node_color(node) == BLACK)
    {
        node->color = map_node_color(child);
        map_delete_case1(map, node);
    }

    map_replace_node(map, node, child);

    if(node->parent == NULL && child)
        child->color = BLACK;

    free(node);
    map->count--;
}

boolean map_empty(LF_MAP* map)
{
    return map->root == NULL ? TRUE : FALSE;
}

static void map_delete_node(rb_tree_node* node)
{
    if(node->left)
        map_delete_node(node->left);

    if(node->right)
        map_delete_node(node->right);

    free(node);
}

void map_clear(LF_MAP* map)
{
    if(map->root)
    {
        map_delete_node(map->root);
        map->root = NULL;
    }
}

// Calling free from C++ on a pointer malloc'd in c results in
// exception: different runtimes so pointer not found.
// This function allows us to free up the pointer in the context it
// was malloc'd.
void map_free(LF_MAP* map)
{
    free(map);
}
