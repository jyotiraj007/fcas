// Copyright (C) 2014 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// offset_table_eot.c

#include <string.h>
#include "agfawrap.h"
#include "offset_table_eot.h"
#include "offset_table_sfnt.h"
#include "utils.h"


//#define TTEMBED_SUBSET                     0x00000001
#define TTEMBED_TTCOMPRESSED               0x00000004
//#define TTEMBED_FAILIFVARIATIONSIMULATED   0x00000010
//#define TTMBED_EMBEDEUDC                   0x00000020
//#define TTEMBED_VALIDATIONTESTS            0x00000040  // (Deprecated)
//#define TTEMBED_WEBOBJECT                  0x00000080
#define TTEMBED_XORENCRYPTDATA             0x10000000


// Define this macro to produce uncompressed EOTs. By default EOTs will be compressed (but not XOR'd).
//#define UNCOMPRESSED_EOT


LF_ERROR offset_eot_readTable(LF_STREAM* stream, eot_offset_table** pptable)
{
    ULONG i = 0;
    eot_offset_table* table = (eot_offset_table*)calloc(1, sizeof(eot_offset_table));

    if (table == NULL)
        return LF_OUT_OF_MEMORY;

    else
    {
        ULONG  ulValue;
        USHORT usValue;
        BYTE  *pbPtr;

        STREAM_streamSeek(stream, 0);
        ulValue = STREAM_readULong(stream);    table->eotHeader.eotSize        = SWAP_ULONG(ulValue);
        ulValue = STREAM_readULong(stream);    table->eotHeader.fontDataSize   = SWAP_ULONG(ulValue);
        ulValue = STREAM_readULong(stream);    table->eotHeader.version        = SWAP_ULONG(ulValue);
        ulValue = STREAM_readULong(stream);    table->eotHeader.flags          = SWAP_ULONG(ulValue);
        pbPtr = table->eotHeader.fontPanose;
        for (i=0; i<10; i++) *pbPtr++ = STREAM_readByte(stream);
        table->eotHeader.charset = STREAM_readByte(stream);
        table->eotHeader.italic  = STREAM_readByte(stream);
        ulValue = STREAM_readULong(stream);    table->eotHeader.weight         = SWAP_ULONG(ulValue);
        usValue = STREAM_readUShort(stream);   table->eotHeader.fsType         = SWAP_USHORT(usValue);
        usValue = STREAM_readUShort(stream);   table->eotHeader.magicNumber    = SWAP_USHORT(usValue);
        ulValue = STREAM_readULong(stream);    table->eotHeader.unicodeRange1  = SWAP_ULONG(ulValue);
        ulValue = STREAM_readULong(stream);    table->eotHeader.unicodeRange2  = SWAP_ULONG(ulValue);
        ulValue = STREAM_readULong(stream);    table->eotHeader.unicodeRange3  = SWAP_ULONG(ulValue);
        ulValue = STREAM_readULong(stream);    table->eotHeader.unicodeRange4  = SWAP_ULONG(ulValue);
        ulValue = STREAM_readULong(stream);    table->eotHeader.codePageRange1 = SWAP_ULONG(ulValue);
        ulValue = STREAM_readULong(stream);    table->eotHeader.codePageRange2 = SWAP_ULONG(ulValue);
        ulValue = STREAM_readULong(stream);    table->eotHeader.checkSumAdjustment = SWAP_ULONG(ulValue);
        stream->Current += 18; // skip 4 Reserved entries and Padding1
        usValue = STREAM_readUShort(stream);   table->eotHeader.familyNameSize = SWAP_USHORT(usValue);
        stream->Current += (table->eotHeader.familyNameSize + 2); // skip FamilyName and Padding2
        usValue = STREAM_readUShort(stream);   table->eotHeader.styleNameSize  = SWAP_USHORT(usValue);
        stream->Current += (table->eotHeader.styleNameSize + 2);  // skip StyleName and Padding3
        usValue = STREAM_readUShort(stream);   table->eotHeader.versionNameSize = SWAP_USHORT(usValue);
        stream->Current += (table->eotHeader.versionNameSize + 2);  // skip VersionName and Padding4
        usValue = STREAM_readUShort(stream);   table->eotHeader.fullNameSize = SWAP_USHORT(usValue);
        stream->Current += table->eotHeader.fullNameSize;  // skip FullName

        // stream now points to FontData for format 0x00010000

        if(table->eotHeader.version >= 0x00020001)
        {
            // skip RootString
            stream->Current += 2;  // skip Padding5
            usValue = STREAM_readUShort(stream);   table->eotHeader.rootStringSize = SWAP_USHORT(usValue);
            stream->Current += table->eotHeader.rootStringSize;  // skip RootString
        }

        if(table->eotHeader.version >= 0x00020002)
        {
            // skip Signature and EUDCFontData
            stream->Current += (10);  // skip RootStringCheckSum, EUDCCodePage, and Padding6
            usValue = STREAM_readUShort(stream);   usValue = SWAP_USHORT(usValue); // SignatureSize
            stream->Current += (usValue + 4);  // skip Signature and EUDCFlags
            ulValue = STREAM_readULong(stream);   ulValue = SWAP_ULONG(ulValue); // EUDCFontSize
            stream->Current += ulValue;                 // skip EUDCFontData
        }

        // stream now points to FontData for all formats so read the FontData
        table->eotHeader.fontData = stream->Current;
        STREAM_getChunk(stream, table->eotHeader.fontData, table->eotHeader.fontDataSize);

        // un-encrypt the data if needed
        if(table->eotHeader.flags & TTEMBED_XORENCRYPTDATA)
        {
            // decrypt the data by XORing each byte with 0x50
            pbPtr = table->eotHeader.fontData;
            for (i=0; i<table->eotHeader.fontDataSize; i++)
            {
                BYTE val = (*pbPtr) ^ 0x50;
                *pbPtr++ = val;
            }
        }

        // un-compress the data if needed
        if(table->eotHeader.flags & TTEMBED_TTCOMPRESSED)
        {
            int err;
            long lenc;
            err = AgfaUnPack_TTF_InMemory(table->eotHeader.fontData,table->eotHeader.fontDataSize,0,&pbPtr,&lenc,malloc,realloc,free);
            if(err)
            {
                free(table);
                return LF_COMPRESSION;
            }
            else
            {
                table->eotHeader.fontDataSize = (ULONG)lenc;
                table->eotHeader.fontData = pbPtr;
                table->srcWasCompressed = (boolean)TRUE;
            }
        }
        else
        {
            table->srcWasCompressed = (boolean)FALSE;
        }

        STREAM_streamSeek(stream, 0);

        *pptable = table;
    }

    return LF_ERROR_OK;
}

// writes a version 2.1 EOT file to the stream
// the fontdata pointer of the eot table should be populated with
// buffer with the uncompressed sfnt prior to calling this function
LF_ERROR offset_eot_writeEmbeddedFont(const eot_offset_table* table, LF_STREAM* stream)
{
    USHORT i, padding = 0;
    ULONG reserved = 0, dataSize, processingFlags;
    size_t eotSize;
    BYTE* compressedBuf, *dataToWrite;

    if(table == NULL)
        return LF_BAD_FORMAT;

    if(table->eotHeader.fontData == NULL)
        return LF_BAD_FORMAT;

#ifdef UNCOMPRESSED_EOT
    compressedBuf = NULL;
    dataSize = table->eotHeader.fontDataSize;
    processingFlags = 0;
    dataToWrite = table->eotHeader.fontData;
#else
    {
    // compress the sfnt into a buffer
    long compressedBuflength;
    int agfaErr = AgfaPack_TTF_InMemory(table->eotHeader.fontData, table->eotHeader.fontDataSize, FALSE,
                                    &compressedBuf, &compressedBuflength, 0, malloc, realloc, free);
    if (agfaErr == 0/*NO_ERROR*/)
    {
        dataToWrite = compressedBuf;
        dataSize = (ULONG)compressedBuflength;
        processingFlags = TTEMBED_TTCOMPRESSED;
    }
    else
    {
        DEBUG_LOG_WARNING("WARNING: AgfaPack_TTF_InMemory failed; saving as uncompressed EOT.");
        compressedBuf = NULL;
        dataSize = table->eotHeader.fontDataSize;
        processingFlags = 0;
        dataToWrite = table->eotHeader.fontData;
    }
    }
#endif

    STREAM_streamSeek(stream, 0);

    // write the EOT header
    STREAM_writeULong(stream, 0);                                               // this will be updated later
    STREAM_writeULong(stream, SWAP_ULONG(dataSize));
    STREAM_writeULong(stream, 0x01000200);
    STREAM_writeULong(stream, SWAP_ULONG(processingFlags));
    for(i = 0; i < 10; ++i)
        STREAM_writeByte(stream, table->eotHeader.fontPanose[i]);
    STREAM_writeByte(stream, table->eotHeader.charset);
    STREAM_writeByte(stream, table->eotHeader.italic);
    STREAM_writeULong(stream, SWAP_ULONG(table->eotHeader.weight));
    STREAM_writeUShort(stream, SWAP_USHORT(table->eotHeader.fsType));
    STREAM_writeUShort(stream, SWAP_USHORT(0x504C));
    STREAM_writeULong(stream, SWAP_ULONG(table->eotHeader.unicodeRange1));
    STREAM_writeULong(stream, SWAP_ULONG(table->eotHeader.unicodeRange2));
    STREAM_writeULong(stream, SWAP_ULONG(table->eotHeader.unicodeRange3));
    STREAM_writeULong(stream, SWAP_ULONG(table->eotHeader.unicodeRange4));
    STREAM_writeULong(stream, SWAP_ULONG(table->eotHeader.codePageRange1));
    STREAM_writeULong(stream, SWAP_ULONG(table->eotHeader.codePageRange2));
    STREAM_writeULong(stream, SWAP_ULONG(table->eotHeader.checkSumAdjustment));
    STREAM_writeULong(stream, reserved);
    STREAM_writeULong(stream, reserved);
    STREAM_writeULong(stream, reserved);
    STREAM_writeULong(stream, reserved);
    STREAM_writeUShort(stream, SWAP_USHORT(padding));
    STREAM_writeUShort(stream, SWAP_USHORT(table->eotHeader.familyNameSize));
    STREAM_writeChunk(stream, table->eotHeader.familyName, table->eotHeader.familyNameSize);
    STREAM_writeUShort(stream, padding);
    STREAM_writeUShort(stream, SWAP_USHORT(table->eotHeader.styleNameSize));
    STREAM_writeChunk(stream, table->eotHeader.styleName, table->eotHeader.styleNameSize);
    STREAM_writeUShort(stream, padding);
    STREAM_writeUShort(stream, SWAP_USHORT(table->eotHeader.versionNameSize));
    STREAM_writeChunk(stream, table->eotHeader.versionName, table->eotHeader.versionNameSize);
    STREAM_writeUShort(stream, padding);
    STREAM_writeUShort(stream, SWAP_USHORT(table->eotHeader.fullNameSize));
    STREAM_writeChunk(stream, table->eotHeader.fullName, table->eotHeader.fullNameSize);
    STREAM_writeUShort(stream, padding);
    STREAM_writeUShort(stream, SWAP_USHORT(table->eotHeader.rootStringSize));
    STREAM_writeChunk(stream, table->eotHeader.rootString, table->eotHeader.rootStringSize);

    // write the font data
    STREAM_writeChunk(stream, dataToWrite, dataSize);

    // update eot Size
    eotSize = STREAM_streamPos(stream);
    STREAM_streamSeek(stream, 0);
    STREAM_writeULong(stream, SWAP_ULONG(eotSize));

    // put the stream pos to the end so it can be used by caller to get the size
    STREAM_streamSeek(stream, eotSize);

    free(compressedBuf);

    return LF_ERROR_OK;
}

LF_ERROR offset_eot_freeTable(LF_FONT* lfFont)
{
    eot_offset_table* table = (eot_offset_table*)lfFont->offset_table.eot;

    for(ULONG i = 0; i < table->record_list.count; i++)
    {
        sfnt_table_record* record = (sfnt_table_record*)vector_at(&table->record_list, i);
        free(record);
    }

    vector_free(&table->record_list);

    free(table->eotHeader.familyName);
    free(table->eotHeader.fullName);
    free(table->eotHeader.rootString);
    free(table->eotHeader.styleName);
    free(table->eotHeader.versionName);

    free(table);

    lfFont->fontType = eLF_UNDETERMINED;

    return LF_ERROR_OK;
}
