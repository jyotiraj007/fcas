// Copyright (C) 2014 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// device_table.c

#include <stdlib.h>
#include "device_table.h"

LF_ERROR DeviceTable_readTable(device_table* table, LF_STREAM* stream)
{
    USHORT numValues;
    USHORT i;

    table->StartSize = STREAM_readUShort(stream);
    table->EndSize = STREAM_readUShort(stream);
    table->DeltaFormat = STREAM_readUShort(stream);

    vector_init(&table->DeltaValue, 4, 4);

    numValues = table->EndSize - table->StartSize + 1;

    switch (table->DeltaFormat)
    {
        case 1: numValues /= 8; break;
        case 2: numValues /= 4; break;
        case 3: numValues /= 2; break;
        default: break;
    }

    numValues += 1;

    for (i = 0; i < numValues; i++)
    {
        vector_push_back(&table->DeltaValue, (void*)(intptr_t)STREAM_readUShort(stream));
    }

    return LF_ERROR_OK;
}

LF_ERROR DeviceTable_getTableSize(const device_table* table, size_t* tableSize)
{
    *tableSize = sizeof(USHORT) * (3 + table->DeltaValue.count);
    return LF_ERROR_OK;
}

LF_ERROR DeviceTable_buildTable(device_table* table, LF_STREAM* stream)
{
    USHORT i;

    STREAM_writeUShort(stream, table->StartSize);
    STREAM_writeUShort(stream, table->EndSize);
    STREAM_writeUShort(stream, table->DeltaFormat);

    for (i = 0; i < table->DeltaValue.count; i++)
    {
        STREAM_writeUShort(stream, (USHORT)(intptr_t)vector_at(&table->DeltaValue, i));
    }
    return LF_ERROR_OK;
}

LF_ERROR DeviceTable_freeTable(device_table* table)
{
    vector_delete(&table->DeltaValue);
    return LF_ERROR_OK;
}

#ifdef LF_OT_DUMP
#include "utils.h"
void DeviceTable_dumpTable(device_table* table)
{
    ULONG i;

    XML_DATA_NODE("StartSize", table->StartSize);
    XML_DATA_NODE("EndSize", table->EndSize);
    XML_DATA_NODE("DeltaFormat", table->DeltaFormat);

    XML_START("DeltaValueArray");
    for (i = 0; i < table->DeltaValue.count; i++)
    {
        USHORT delta = (USHORT)(long)vector_at(&table->DeltaValue, i);
        XML_DATA_NODE("DeltaValue", delta);
    }
    XML_END("DeltaValueArray");
}
#endif
