// Copyright (C) 2015, 2016 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
//
/// \file lf_componentize.c

#include <math.h>
#include "lf_componentize.h"
#include "sfnt_core.h"
#include "maxp_table.h"
#include "loca_table.h"
#include "glyf_table.h"
#include "gpos_table.h"
#include "cff_conversion.h"
#include "Conversion.h"
#include "Compositor.h"
#include "head_table.h"
#include "hmtx_table.h"
#include "hhea_table.h"
#include "os2_table.h"
#include "vmtx_table.h"
#include "vhea_table.h"


static LF_ERROR checkGlyphTable(const LF_FONT* lfFont, boolean *hasGLYF)
{
    if (NULL != map_at(&lfFont->table_map, (void *)(long)TAG_GLYF))
    {
        *hasGLYF = TRUE;
        return LF_ERROR_OK;
    }
    if (NULL != map_at(&lfFont->table_map, (void *)(long)TAG_CFF))
    {
        *hasGLYF = FALSE;
        return LF_ERROR_OK;
    }
    return LF_TABLE_MISSING;
}

#if 0
static LF_ERROR checkGlyfTable(LF_FONT* lfFont)
{
    // Get glyf table.
    glyf_table* glyfTable = (glyf_table*)map_at(&lfFont->table_map, (void*)TAG_GLYF);
    if (glyfTable == NULL)
        return LF_TABLE_MISSING;

    boolean hasComposites = FALSE;

    USHORT i, numGlyphs = (USHORT)map_size(glyfTable->glyfMap);

    // loop over glyphs
    for (i = 0; ((hasComposites == FALSE) && (i < numGlyphs)); i++)
    {
        // Get Glyph
        glyf curGlyf;

        LF_ERROR error = GLYF_getGlyf(glyfTable, i, &curGlyf);
        if (error != LF_ERROR_OK)
            return error;

        if (curGlyf.numberOfContours == -1)
            hasComposites = TRUE;

        GLYF_destroyGlyf(&curGlyf);
    }

    return (hasComposites == FALSE) ? LF_ERROR_OK : LF_UNSUPPORTED;
}
#endif

static LF_ERROR createGlyphArray(LF_FONT* lfFont, Glyph** glyphArray, USHORT* numGlyphs)
{
    // Get glyf table.
    glyf_table* glyfTable = (glyf_table*)map_at(&lfFont->table_map, (void*)TAG_GLYF);
    if (glyfTable == NULL)
        return LF_TABLE_MISSING;

   *numGlyphs = (USHORT)map_size(glyfTable->glyfMap);

    *glyphArray = (Glyph*)calloc(*numGlyphs, sizeof(Glyph));
    if (*glyphArray == NULL)
        return LF_OUT_OF_MEMORY;

    LF_ERROR error;

    // loop over glyphs
    for (USHORT i = 0; i < *numGlyphs; i++)
    {
        // Get Glyph
        glyf curGlyf;

        error = GLYF_getGlyf(glyfTable, i, &curGlyf);
        if (error != LF_ERROR_OK)
        {
            free(*glyphArray);
            return error;
        }

        if (curGlyf.numberOfContours == 0)
        {
            (*glyphArray)[i].glyphType = eGlyph_TTF;
        }
        else if (curGlyf.numberOfContours == -1)
        {
            // composite glyph
            (*glyphArray)[i].glyphType = eGlyph_TTF;

            Glyph_Outline* go = &(*glyphArray)[i].glyphOutline;

            go->xMin = curGlyf.xMin;
            go->xMax = curGlyf.xMax;
            go->yMin = curGlyf.yMin;
            go->yMax = curGlyf.yMax;

            go->numberOfComponents = (short)curGlyf.glyf_data.composite.count;

            Glyph_Component* gc = &go->component;

            for (size_t j = 0; j < curGlyf.glyf_data.composite.count; j++)
            {
                if (j > 0)
                {
                    Glyph_Component* newgc = (Glyph_Component*)calloc(1, sizeof(Glyph_Component));
                    if (NULL == newgc)
                    {
                        // unwind glyphArray
                        free(*glyphArray);
                        return LF_OUT_OF_MEMORY;
                    }

                    gc->next = newgc;
                    gc = newgc;
                }

                composite_glyf* cg = vector_at(&curGlyf.glyf_data.composite, j);

                gc->type = eIsComposite;
                gc->flags = cg->flags;
                gc->glyphIndex = cg->glyphIndex;
                gc->xoffset = cg->argument1;
                gc->yoffset = cg->argument2;
                gc->xscale = (float)cg->xscale / (float)0x4000;
                gc->yscale = (float)cg->yscale / (float)0x4000;
                gc->scale10 = (float)cg->scale10 / (float)0x4000;
                gc->scale01 = (float)cg->scale01 / (float)0x4000;
            }
        }
        else
        {
            // get the points for it
            LF_VECTOR* points = vector_create(128, 64); // each point consumes 4 entries, so this starts with space for 32 points and grows by 16

            if (points == NULL)
            {
                GLYF_destroyGlyf(&curGlyf);
                for (USHORT j = 0; j < i; j++)
                    conversion_freeGlyphOutline(&(*glyphArray)[i]);
                free(*glyphArray);
                return LF_OUT_OF_MEMORY;
            }

            (*glyphArray)[i].glyphOutline.xMin = curGlyf.xMin;
            (*glyphArray)[i].glyphOutline.xMax = curGlyf.xMax;
            (*glyphArray)[i].glyphOutline.yMin = curGlyf.yMin;
            (*glyphArray)[i].glyphOutline.yMax = curGlyf.yMax;

            error = GLYF_getGlyfPointsInternal(glyfTable, &curGlyf, points);
            if (error != LF_ERROR_OK)
            {
                vector_free(points);
                free(points);
                GLYF_destroyGlyf(&curGlyf);
                for (USHORT j = 0; j < i; j++)
                    conversion_freeGlyphOutline(&(*glyphArray)[i]);
                free(*glyphArray);
                return error;
            }

            // convert the glyf to a quad Glyph
            (*glyphArray)[i].glyphType = eGlyph_TTF;
            conversion_setGlyphOutlineParams(&(*glyphArray)[i].glyphOutline, i);

            error = conversion_addPointsToGlyphOutline(points, &(*glyphArray)[i].glyphOutline);
            if (error != LF_ERROR_OK)
            {
                vector_free(points);
                free(points);
                GLYF_destroyGlyf(&curGlyf);
                for (USHORT j = 0; j < i; j++)
                    conversion_freeGlyphOutline(&(*glyphArray)[i]);
                free(*glyphArray);
                return error;
            }

            (*glyphArray)[i].glyphOutline.component.type = eSimple;

            vector_free(points);
            free(points);
        }

        GLYF_destroyGlyf(&curGlyf);
    }

    return LF_ERROR_OK;
}

static void destroyGlyphArray(Glyph* glyphArray, USHORT numGlyphs)
{
    for (USHORT i = 0; i < numGlyphs; i++)
    {
        conversion_freeGlyphOutline(&glyphArray[i]);
    }

    free(glyphArray);
}


static LF_ERROR convertMultiCompCompositeGlyphToCompressedGlyf(const Glyph *glyph, glyf *glyf_object)
{
    glyf_object->numberOfContours = -1;
    glyf_object->xMin = (SHORT)glyph->glyphOutline.xMin;
    glyf_object->yMin = (SHORT)glyph->glyphOutline.yMin;
    glyf_object->xMax = (SHORT)glyph->glyphOutline.xMax;
    glyf_object->yMax = (SHORT)glyph->glyphOutline.yMax;

    // figure out how many components there are
    USHORT numComps = 0;

    const Glyph_Component* gc = &glyph->glyphOutline.component;
    do
    {
        if (gc->type != eIsComposite)
            return LF_BAD_FORMAT;
        numComps++;
        gc = gc->next;
    } while (gc != NULL);


    // figure out size of glyph block
    // each glyph has a USHORT for the flags, index, arg1, and arg2  (8 bytes)
    // if a component has an x scale that will be another USHORT
    // if a component has a  y scale that will be another USHORT
    // (there won't be a transformation matirx)
    USHORT blockSize = 0;

    gc = &glyph->glyphOutline.component;

    do
    {
        blockSize += 2 * sizeof(USHORT); // flags and glyph index

        if ((fabs(gc->xoffset) < 128) && (fabs(gc->yoffset) < 128))
            blockSize += 2 * sizeof(BYTE);
        else
            blockSize += 2 * sizeof(USHORT);

        if ((gc->xscale != 1.0f) || (gc->yscale != 1.0f))
        {
            if (gc->xscale == gc->yscale)
                blockSize += sizeof(USHORT);
            else 
                blockSize += 2 * sizeof(USHORT);
        }

        gc = gc->next;
    } while (gc != NULL);


    // create the glyfBlock
    glyf_object->glyfSize = blockSize;
    glyf_object->glyfBlock = (BYTE*)calloc(glyf_object->glyfSize, 1);
    if (glyf_object->glyfBlock == NULL)
        return LF_OUT_OF_MEMORY;

    LF_STREAM glyfStream;

    STREAM_initMemStream(&glyfStream, glyf_object->glyfBlock, glyf_object->glyfSize);

    int numCompsLeft = numComps;

    gc = &glyph->glyphOutline.component;

    USHORT flags;

    while (numCompsLeft)
    {
        numCompsLeft--;

        flags = ARGS_ARE_XY_VALUES;

        if ((gc->flags & ROUND_XY_TO_GRID) != 0)
            flags |= ROUND_XY_TO_GRID;
        if ((gc->flags & USE_MY_METRICS) != 0)
            flags |= USE_MY_METRICS;

        boolean useBytes = ((fabs(gc->xoffset) < 128) && (fabs(gc->yoffset) < 128)) ? TRUE : FALSE;

        if (FALSE == useBytes)
            flags |= ARG_1_AND_2_ARE_WORDS;

        if (numCompsLeft)
            flags |= MORE_COMPONENTS;
        if ((gc->xscale != 1.0f) || (gc->yscale != 1.0f))
        {
            if (gc->xscale == gc->yscale)
                flags |= WE_HAVE_A_SCALE;
            else
                flags |= WE_HAVE_AN_X_AND_Y_SCALE;
        }

        STREAM_writeUShort(&glyfStream, flags);
        STREAM_writeUShort(&glyfStream, gc->glyphIndex);

        if (TRUE == useBytes)
        {
            STREAM_writeByte(&glyfStream, (CHAR)gc->xoffset);
            STREAM_writeByte(&glyfStream, (CHAR)gc->yoffset);
        }
        else
        {
            STREAM_writeShort(&glyfStream, (SHORT)gc->xoffset);
            STREAM_writeShort(&glyfStream, (SHORT)gc->yoffset);
        }

        USHORT scale;
        if ((flags & WE_HAVE_A_SCALE) != 0)
        {
            scale = (USHORT)(gc->xscale * 0x4000);
            STREAM_writeUShort(&glyfStream, scale);
        }
        else if ((flags & WE_HAVE_AN_X_AND_Y_SCALE) != 0)
        {
            scale = (USHORT)(gc->xscale * 0x4000);
            STREAM_writeUShort(&glyfStream, scale);
            scale = (USHORT)(gc->yscale * 0x4000);
            STREAM_writeUShort(&glyfStream, scale);
        }

        gc = gc->next;
    }

    return LF_ERROR_OK;
}

static void updateMaxpRegularFields(const Glyph* glyph, maxp_table* maxp)
{
    if (glyph->glyphOutline.component.outline.nc > maxp->maxContours)
        maxp->maxContours = glyph->glyphOutline.component.outline.nc;
    if (glyph->glyphOutline.component.outline.np > maxp->maxPoints)
        maxp->maxPoints = glyph->glyphOutline.component.outline.np;
}

static void countComp(const Glyph *glyphArray, USHORT index, unsigned short* totalContours, unsigned short* totalPoints)
{
    const Glyph* glyph = &glyphArray[index];

    const Glyph_Component* gc = &glyph->glyphOutline.component;

    do
    {
        const Glyph* compGlyph = &glyphArray[gc->glyphIndex];

        if (compGlyph->glyphOutline.numberOfComponents > 0)
        {
            countComp(glyphArray, gc->glyphIndex, totalContours, totalPoints);
        }
        else
        {
            *totalContours += compGlyph->glyphOutline.component.outline.nc;
            *totalPoints += compGlyph->glyphOutline.component.outline.np;
        }
        gc = gc->next;
    } while (gc != NULL);
}

static void updateMaxpCompositeFields(const Glyph *glyphArray, USHORT index, maxp_table* maxp)
{
    const Glyph* glyph = &glyphArray[index];

    if (glyph->glyphOutline.numberOfComponents > maxp->maxComponentElements)
        maxp->maxComponentElements = glyph->glyphOutline.numberOfComponents;

    // count total contours and total points
    unsigned short totalContours = 0;
    unsigned short totalPoints = 0;

    countComp(glyphArray, index, &totalContours, &totalPoints);

    if (totalContours > maxp->maxCompositeContours)
        maxp->maxCompositeContours = totalContours;
    if (totalPoints > maxp->maxCompositePoints)
        maxp->maxCompositePoints = totalPoints;
}

static LF_ERROR updateGlyfAndLoca(LF_FONT* lfFont, Glyph *glyphArray, USHORT numGlyphs)
{
    // Remove loca and glyf
    LOCA_freeTable(lfFont);
    map_erase(&lfFont->table_map, (void*)TAG_LOCA);
    GLYF_freeTable(lfFont);
    map_erase(&lfFont->table_map, (void*)TAG_GLYF);

    // Create new tables.
    LF_ERROR error = LOCA_createTable(lfFont, numGlyphs);
    if (error != LF_ERROR_OK)
        return error;

    // Assume we'll need long offsets for now, can shrink later.
    HEAD_setLocFormat(lfFont, 1);

    error = GLYF_createTable(lfFont, numGlyphs, FALSE);
    if (error != LF_ERROR_OK)
        return error;

    // Get glyf table.
    glyf_table* glyfTable = (glyf_table*)map_at(&lfFont->table_map, (void*)TAG_GLYF);
    if (glyfTable == NULL)
        return LF_TABLE_MISSING;

    // Set up maxp values (all values were initialized to 0 when glyf table created).

    // The algorithm will not add any recursive composites, but the original font may have them
    USHORT origMaxCompDepth = MAXP_getMaxCompDepth(lfFont);
    glyfTable->derivedMaxp.maxComponentDepth = (origMaxCompDepth > 1) ? origMaxCompDepth : 1;

    // Hints are removed as of now.
    glyfTable->derivedMaxp.maxZones = 1;

    // Allocate some temp space for the compressed glyf data, start with enough for max of 256 points
    glyfBuildScratchSpace scratch;

    if (0 != conversion_allocateScratchSpace(&scratch, 256))
        return LF_OUT_OF_MEMORY;

    // Loop over new Glyphs and convert them to glyfs
    for (USHORT i = 0; i < numGlyphs; i++)
    {
        glyf* quad_glyf = (glyfTable->glyphDataBlock + i);

        if ((glyphArray[i].glyphOutline.numberOfComponents >= 1) &&
            (glyphArray[i].glyphOutline.component.type == eIsComposite))
        {
            // Composite glyph.

            updateMaxpCompositeFields(glyphArray, i, &glyfTable->derivedMaxp);

            error = convertMultiCompCompositeGlyphToCompressedGlyf(&glyphArray[i], quad_glyf);

            if (error != LF_ERROR_OK)
            {
                conversion_freeScratchSpace(&scratch);
                return error;
            }

            map_insert(glyfTable->glyfMap, (void*)(intptr_t)i, quad_glyf);
        }
        else if (glyphArray[i].glyphOutline.component.outline.nc == 0)
        {
            // Empty glyph.

            quad_glyf->glyfBlock = NULL;   // probably redundant
            map_insert(glyfTable->glyfMap, (void*)(intptr_t)i, NULL);
        }
        else
        {
            // Regular glyph.

            if (glyphArray[i].glyphOutline.component.outline.np > scratch.allocated)
            {
                size_t newSize = scratch.allocated;
                while (newSize < glyphArray[i].glyphOutline.component.outline.np)
                    newSize += 256;
                if (0 != conversion_reallocateScratchSpace(&scratch, newSize))
                {
                    return LF_OUT_OF_MEMORY;
                }
            }

            updateMaxpRegularFields(&glyphArray[i], &glyfTable->derivedMaxp);

            error = conversion_convertGlyphToCompressedGlyf(&glyphArray[i], &scratch, quad_glyf);

            if (error != LF_ERROR_OK)
            {
                conversion_freeScratchSpace(&scratch);
                return error;
            }

            map_insert(glyfTable->glyfMap, (void*)(intptr_t)i, quad_glyf);
        }
    }

    conversion_freeScratchSpace(&scratch);


    glyfTable->maxpInfoUpdated = TRUE;

    return LF_ERROR_OK;
}

static LF_ERROR sfnt_componentize(LF_FONT* lfFont, float tolerance, componentizeCBInfo* progresInfo)
{
    if (progresInfo != NULL)
        progresInfo->progressCB(progresInfo->userState, 5);

    // Create an array of Glyph's
    Glyph* origGlyphArray = NULL;
    USHORT numGlyphs;

    // Read glyphs from glyf table and put into an array of Glyphs.
    LF_ERROR error = createGlyphArray(lfFont, &origGlyphArray, &numGlyphs);
    if (error != LF_ERROR_OK)
        return error;

    if (progresInfo != NULL)
        progresInfo->progressCB(progresInfo->userState, 10);

    Glyph *newGlyphArray = NULL;
    int newNumGlyphs = 0;

    // Composite the glyphs.
    Compositor_Error err = compositor_findQuadComposites(origGlyphArray, numGlyphs, tolerance, &newGlyphArray, &newNumGlyphs, NULL);
    if (err != COMPOSITOR_SUCCESS)
    {
        destroyGlyphArray(origGlyphArray, numGlyphs);
        return LF_COMPONENTIZE;
    }

    if (progresInfo != NULL)
        progresInfo->progressCB(progresInfo->userState, 95);

    // Update the HMTX table and VMTX table.
    if (newNumGlyphs > numGlyphs)
    {
        error = HMTX_expandTable(lfFont, (USHORT)newNumGlyphs);
        if (error != LF_ERROR_OK)
        {
            destroyGlyphArray(origGlyphArray, numGlyphs);
            compositor_freeQuadGlyphArray(newGlyphArray, newNumGlyphs);
            return error;
        }

        for (int i = numGlyphs; i < newNumGlyphs; i++)
        {
            Glyph g = newGlyphArray[i];

            //USHORT xmin = (USHORT)floor(g.glyphOutline.xMin);
            //USHORT xmax = (USHORT)ceil(g.glyphOutline.xMax);
            USHORT xmin = (USHORT)(g.glyphOutline.xMin);
            USHORT xmax = (USHORT)(g.glyphOutline.xMax);

            USHORT adv = (USHORT)(xmax - xmin);

            error = HMTX_setMetric(lfFont, i, adv, 0);
            if (error != LF_ERROR_OK)
            {
                destroyGlyphArray(origGlyphArray, numGlyphs);
                compositor_freeQuadGlyphArray(newGlyphArray, newNumGlyphs);
                return error;
            }
        }

        int *node = (int *)map_at(&lfFont->table_map, (void *)(long)TAG_VMTX);
        if (node != NULL)
        {
            error = VMTX_expandTable(lfFont, (USHORT)newNumGlyphs);
            if (error != LF_ERROR_OK)
            {
                destroyGlyphArray(origGlyphArray, numGlyphs);
                compositor_freeQuadGlyphArray(newGlyphArray, newNumGlyphs);
                return error;
            }

            for (int i = numGlyphs; i < newNumGlyphs; i++)
            {
                Glyph g = newGlyphArray[i];

                USHORT adv = (USHORT)(g.glyphOutline.yMax - g.glyphOutline.yMin);

                error = VMTX_setMetric(lfFont, i, adv, 0);
                if (error != LF_ERROR_OK)
                {
                    destroyGlyphArray(origGlyphArray, numGlyphs);
                    compositor_freeQuadGlyphArray(newGlyphArray, newNumGlyphs);
                    return error;
                }
            }
        }
    }

    // Replace the glyph table and loca table.
    error = updateGlyfAndLoca(lfFont, newGlyphArray, (USHORT)newNumGlyphs);

    if (error == LF_ERROR_OK)
        error = GPOS_removeAnchorPoints(lfFont);

    destroyGlyphArray(origGlyphArray, numGlyphs);
    compositor_freeQuadGlyphArray(newGlyphArray, newNumGlyphs);

    if (progresInfo != NULL)
        progresInfo->progressCB(progresInfo->userState, 96);

    return error;
}

LF_API LF_ERROR LF_componentizeFont(LF_FONT* lfFont, float tolerance, componentizeCBInfo* progresInfo)
{
    if (lfFont == NULL)
        return LF_INVALID_PARAM;

    LF_ERROR error;

    if (progresInfo != NULL)
        progresInfo->progressCB(progresInfo->userState, 0);

    // Tables must be unpacked in order to do it.
    if (map_empty(&lfFont->table_map))
    {
        error = SFNT_unpackTables(lfFont);
        if (error != LF_ERROR_OK)
            return error;
    }

    // font must have either glyf or cff
    boolean hasGLYF;
    error = checkGlyphTable(lfFont, &hasGLYF);
    if (error != LF_ERROR_OK)
        return error;

    if (hasGLYF == TRUE)
        error = sfnt_componentize(lfFont, tolerance, progresInfo); // Must not have composites already.
    else
        error = LF_UNSUPPORTED; // Works only with TTFs so far

    if (error != LF_ERROR_OK)
        return error;

    // Update other tables
    boolean hasVHEA, hasVMTX;

    LF_hasTable(lfFont, TAG_VHEA, &hasVHEA);
    LF_hasTable(lfFont, TAG_VMTX, &hasVMTX);

    MAXP_updateTable(lfFont, (hasGLYF) ? TAG_GLYF : TAG_CFF, TRUE, FALSE, FALSE);

    if (hasVHEA && hasVMTX)
    {
        VHEA_setAdvanceHeightMax(lfFont, VMTX_getAdvanceHeightMax(lfFont));
        VHEA_setNumVMetrics(lfFont, VMTX_getNumVMetrics(lfFont));
        VHEA_setTopSidebearingMin(lfFont, VMTX_getMinTopSidebearing(lfFont));
        VHEA_setVertTypoLineGap(lfFont, 0);
    }

    SHORT xMin, yMin, xMax, yMax;

    if (hasGLYF == TRUE)
        error = GLYF_getBoundingBox(lfFont, &xMin, &yMin, &xMax, &yMax);
    else
        error = CFF__getBoundingBox(lfFont, &xMin, &yMin, &xMax, &yMax);

    if (error != LF_ERROR_OK)
        return error;

    if (progresInfo != NULL)
        progresInfo->progressCB(progresInfo->userState, 97);

    // Update hmtx side bearings and get min values
    FWORD minlsb, minrsb, maxadvance;
    error = HMTX_updateSidebearings(lfFont, lfFont->fontType, &minlsb, &minrsb, &maxadvance);
    if (error != LF_ERROR_OK)
        return error;

    HEAD_setBoundingBox(lfFont, xMin, yMin, xMax, yMax);
    HHEA_setXMaxExtent(lfFont, xMax);
    HHEA_setLeftSidebearingMin(lfFont, minlsb);
    HHEA_setRightSidebearingMin(lfFont, minrsb);
    HHEA_setAdvanceWidthMax(lfFont, maxadvance);
    HHEA_setNumHMetrics(lfFont, HMTX_getNumHMetrics(lfFont));

    if (TRUE == hasGLYF)
        error = SFNT_removeHints(lfFont);

    SFNT_removeTable(lfFont, TAG_DSIG);
    SFNT_removeTable(lfFont, TAG_LTSH);

    USHORT os2Version;
    OS2_getVersion(lfFont, &os2Version);
    if (os2Version < 3)
        OS2_upgradeTable(lfFont);
    else
    {
        OS2_updateHeights(lfFont);
        //OS2_updateMaxContent(lfFont);
    }
    OS2_setAvgCharWidth(lfFont, HMTX_getAdvanceWidthAvg(lfFont));

    if (progresInfo != NULL)
        progresInfo->progressCB(progresInfo->userState, 100);

    lfFont->isRefitted = TRUE;

    return error;
}
