// Copyright (C) 2014 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// unknown_table.c

#include <stdlib.h>
#include "unknown_table.h"
#include "utils.h"

LF_ERROR UNKNOWN_readTable(LF_FONT* lfFont, const sfnt_table_record* record, LF_STREAM* stream)
{
    if(STREAM_streamSeek(stream, record->offset) == 0)
    {
        if(record->length > 0)
        {
            unknown_table* table = (unknown_table*)malloc(sizeof(unknown_table));
            if(table)
            {
                table->length = record->length;
                table->data = STREAM_readChunk(stream, table->length);

                map_insert(&lfFont->table_map, (void*)(intptr_t)record->tag, table);
                return LF_ERROR_OK;
            }
            else
                return LF_OUT_OF_MEMORY;
        }
    }

    return LF_INVALID_OFFSET;
}

LF_ERROR UNKNOWN_getTableSize(LF_FONT* lfFont, ULONG tag, size_t* tableSize)
{
    unknown_table* table = (unknown_table*)map_at(&lfFont->table_map, (void*)(intptr_t)tag);

    *tableSize = 0;

    if(table == NULL)
        return LF_EMPTY_TABLE;

    *tableSize = table->length;

    return LF_ERROR_OK;
}

LF_ERROR UNKNOWN_writeTable(LF_FONT* lfFont, sfnt_table_record* record, LF_STREAM* stream)
{
    ULONG padLen = 0;
    unknown_table* table = (unknown_table*)map_at(&lfFont->table_map, (void*)(intptr_t)record->tag);

    if(table == NULL)
        return LF_EMPTY_TABLE;

    UTILS_PadTable(&table->data, table->length, &padLen);

    record->checkSum = UTILS_CalcTableChecksum(table->data, table->length);
    record->length = table->length;
    record->offset = (ULONG)STREAM_streamPos(stream);

    STREAM_streamSeek(stream, record->offset);
    STREAM_writeChunk(stream, table->data, padLen);

    return LF_ERROR_OK;
}

LF_ERROR UNKNOWN_freeTable(LF_FONT* lfFont, const sfnt_table_record* record)
{
    unknown_table* table = (unknown_table*)map_at(&lfFont->table_map, (void*)(intptr_t)record->tag);

    if(table)
    {
        free(table->data);
        free(table);
    }

    return LF_ERROR_OK;
}
