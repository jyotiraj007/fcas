// Copyright (C) 2014, 2015 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// keep_table.c

#include "keep_table.h"
#include "utils.h"

GlyphList* Keep_createGlyphList()
{
    GlyphList* keepList = (GlyphList*)calloc(1, sizeof(GlyphList));

    if (keepList != NULL)
        map_init(&keepList->Glyphs, integer_compare);
    else
    {
        DEBUG_LOG_ERROR("unable to allocate keep glyph list");
    }

    return keepList;
}

LF_ERROR Keep_destroyGlyphList(GlyphList* keepList)
{
    if (keepList == NULL)
        return LF_INVALID_PARAM;

    map_clear(&keepList->Glyphs);

    free(keepList);

    return LF_ERROR_OK;
}

LF_ERROR Keep_populateGlyphList(GlyphList* keepList, const GlyphID* gids, ULONG numGids)
{
    if ((keepList == NULL) || (gids == NULL))
        return LF_INVALID_PARAM;

    // Add the passed in glyph ids to the map
    for (size_t i = 0; i < numGids; ++i)
    {
        LF_ERROR status = Keep_addGlyph(keepList, gids[i]);
        if ((status != LF_ERROR_OK) && (status != LF_ADDED_GLYPH))
            return status;
    }

    return LF_ERROR_OK;
}

/* ============================================================================
@summary
add a glyph reference to the list using the default values

@param
list          = pointer to the linked list
id            = the glyph we are looking for

@return
status        = returns status of operation
============================================================================ */
LF_ERROR Keep_addGlyph(GlyphList* keepList, GlyphID id)
{
    if (keepList == NULL)
        return LF_INVALID_PARAM;

    if (TRUE == map_key_exists(&keepList->Glyphs, (void*)(intptr_t)id))
    {
        return LF_ERROR_OK;
    }
    else
    {
        map_insert(&keepList->Glyphs, (void*)(intptr_t)id, (void*)(intptr_t)id);

        return LF_ADDED_GLYPH;
    }
}

/* ==================================================================
@summary
check if the glyphID passed is present in the keepList.

@param
list            :   pointer to the keepList
glyphID         :   the glyphID we want to see if exists in
the keepList.

@return
LF_ERROR_OK     :   glyphID is covered
LF_NOT_COVERED  :   glyphID is NOT found in the keepList
================================================================== */
LF_ERROR Keep_coverageExists(GlyphList* keepList, GlyphID glyphID)
{
    if (keepList == NULL)
        return LF_INVALID_PARAM;

    return (map_key_exists(&keepList->Glyphs, (void*)(intptr_t)glyphID) ? LF_ERROR_OK : LF_NOT_COVERED);
}

/* ----------------------------------------------------------------------------
@summary
    determines if a set of glyphs are present in the KEEP list.

    @param
        keepList        :    pointer to the keepGlyph collection
        glyphs          :    pointer to the glyphs we want to check
                             if exists

    @return
        LF_ERROR_OK     :    sequence exists in the keep table
        LF_NOT_COVERED  :    sequence isn't covered in the keep table.

---------------------------------------------------------------------------- */
LF_ERROR Keep_setExists(GlyphList* keepList, LF_VECTOR* glyphs)
{
    if ((keepList == NULL) || (glyphs == NULL))
        return LF_INVALID_PARAM;

    for (size_t n = 0; n < glyphs->count; n++)
    {
        GlyphID glyph = (GlyphID)(intptr_t)vector_at(glyphs, n);
        LF_ERROR error = Keep_coverageExists(keepList, glyph);
        if (error != LF_ERROR_OK)
            return error;
    }

    return LF_ERROR_OK;
}
/* ============================================================================
    @summary
        Returns a buffer containing a sorted list of glyph ids to keeps.
        Client must free the returned pointer.

    @param
        list    [in ] =   pointer to the glyph collection
        length  [out] =   pointer to the length value.

    @return
        pointer to a table of glyph ids.  the length of the array
        is stored in length.
============================================================================ */
GlyphID* Keep_getSortedGlyphIDList(GlyphList* keepList, ULONG* length)
{
    if ((keepList == NULL) || (length == NULL))
        return NULL;

    *length = keepList->Glyphs.count;

    GlyphID*  glyphs = NULL;

    if (*length)
    {
        ULONG    n = 0;

        glyphs = (USHORT*)malloc(sizeof(USHORT) * (*length));

        if (glyphs)
        {
            LF_MAP*         map = &keepList->Glyphs;
            LF_MAP_ITER*    mapIter = map_begin(map);
            rb_tree_node*   node;

            if(mapIter == NULL)
            {
                free(glyphs);
                return NULL;
            }

            node = map_next(mapIter);

            while(node)
            {
                glyphs[n] = (GlyphID)(intptr_t)node->data;
                node = map_next(mapIter);
                n++;
            }

            map_free_iter(mapIter);

            // now sort the glyph IDs in the array
            LONG sortLength = (LONG)((*length) - 1);
            UTILS_quicksortGlyphID((USHORT*)glyphs, 0, sortLength);
        }
        else
        {
            DEBUG_LOG_ERROR("failed to allocate memory in Keep_getSortedGlyphIDList");
        }
    }

    return glyphs;
}

LF_ERROR Keep_dumpKeepList(GlyphList* keepList)
{
#if _DEBUG

    LF_MAP_ITER*    mapIter = map_begin(&keepList->Glyphs);

    if(mapIter)
        return LF_OUT_OF_MEMORY;

    rb_tree_node* node = map_next(mapIter);

    DEBUG_LOG("-------------------------------------");
    DEBUG_LOG("Keep List Dump");
    DEBUG_LOG_VALUE("Glyph total", keepList->Glyphs.count);

    while(node)
    {
        char            msg[2048];

        sprintf(msg, "gid = %d)", (int)(intptr_t)node->data);
        DEBUG_LOG(msg);

        node = map_next(mapIter);
    }

    DEBUG_LOG("-------------------------------------");

    map_free_iter(mapIter);
#else
    UNUSED(keepList);
#endif
    return LF_ERROR_OK;
}
