// Copyright (C) 2014 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// woff_core.c

#include "zlib.h"   //lint -esym(652, gzgetc)
#include "lf_core.h"
#include "utils.h"
#include "woff_core.h"
#include "woff2_core.h"
#include "sfnt_core.h"
#include "table_tags.h"

LF_ERROR WOFF_readOffsetTable(LF_FONT* lfFont, LF_STREAM* stream, int keepFlags)
{
    lfFont->offset_table.woff = offset_woff_readTable(stream, keepFlags);

    return (lfFont->offset_table.woff != NULL) ? LF_ERROR_OK : LF_OUT_OF_MEMORY;
}

LF_ERROR WOFF_getData(LF_FONT* lfFont, LF_STREAM* stream)
{
    size_t curPos;
    woff_offset_table *woffTable;

    if (lfFont == NULL)
        return LF_INVALID_PARAM;
    if (lfFont->fontType != eLF_WOFF_FONT)
        return LF_BAD_FORMAT;

    curPos = STREAM_streamPos(stream);

    woffTable = (woff_offset_table*)lfFont->offset_table.woff;

    if ((woffTable == NULL) || (woffTable->woffHeader.signature != 0x774F4646))
        return LF_BAD_FORMAT;

    lfFont->woffInfo.majorVersion = woffTable->woffHeader.majorVersion;
    lfFont->woffInfo.minorVersion = woffTable->woffHeader.minorVersion;

    if (woffTable->woffHeader.metaLength != 0)
    {
        STREAM_streamSeek(stream, (size_t)woffTable->woffHeader.metaOffset);
        lfFont->woffInfo.metaData = STREAM_readChunk(stream, woffTable->woffHeader.metaLength);
        if(lfFont->woffInfo.metaData == NULL)
            return LF_OUT_OF_MEMORY;
        lfFont->woffInfo.metaDataLen = woffTable->woffHeader.metaLength;
        lfFont->woffInfo.metaDataOrigLen = woffTable->woffHeader.metaOrigLength;

        STREAM_streamSeek(stream, curPos);
    }

    if (woffTable->woffHeader.privLength != 0)
    {
        STREAM_streamSeek(stream, woffTable->woffHeader.privOffset);
        lfFont->woffInfo.privateData = STREAM_readChunk(stream, woffTable->woffHeader.privLength);
        if(lfFont->woffInfo.privateData == NULL)
            return LF_OUT_OF_MEMORY;    // metaData freed in LF_freeFont
        lfFont->woffInfo.privateDataLen = woffTable->woffHeader.privLength;

        STREAM_streamSeek(stream, curPos);
    }

    lfFont->woffInfo.metatDataCompression = eWOFF;

    return LF_ERROR_OK;
}

boolean WOFF_decompress(const BYTE* src, ULONG srcLen, BYTE* dest, ULONG* destLen)
{
    uLongf uDestLen = (uLongf)*destLen;

    int zerror = uncompress(dest, &uDestLen, src, srcLen);
    
    *destLen = (ULONG)uDestLen;
    
    return ((zerror == Z_OK) ? TRUE : FALSE);
}

static void WOFF_cleanSfntTable(sfnt_offset_table* sfntTable)
{
    size_t i;

    for(i = 0; i < sfntTable->record_list.count; ++i)
        free(vector_at(&sfntTable->record_list, i));
    vector_free(&sfntTable->record_list);
    free(sfntTable);
}

// converts the lffont from woff to sfnt
LF_ERROR WOFF_to_SFNT(LF_FONT* lfFont, LF_STREAM* stream)
{
    size_t i, numTables;
    ULONG tableBufferLen;
    LF_ERROR error;
    sfnt_offset_table* sfntTable;
    woff_offset_table *woffTable;
    BYTE* curPos;

    if(lfFont == NULL)
        return LF_INVALID_PARAM;
    if(lfFont->fontType != eLF_WOFF_FONT)
        return LF_BAD_FORMAT;

    woffTable = (woff_offset_table*)lfFont->offset_table.woff;

    if((woffTable == NULL) || (woffTable->woffHeader.signature != 0x774F4646))
        return LF_BAD_FORMAT;

    // allocate a new sfnt offset table
    sfntTable = (sfnt_offset_table*)calloc(1, sizeof(sfnt_offset_table));
    if(sfntTable == NULL)
        return LF_OUT_OF_MEMORY;

    sfntTable->sfntHeader.sfnt_version = woffTable->woffHeader.flavor;
    sfntTable->sfntHeader.numTables = woffTable->woffHeader.numTables;
    ASSERT(sfntTable->sfntHeader.numTables == woffTable->record_list.count);

    // these will be calculated when font is written
    sfntTable->sfntHeader.entrySelector = 0;
    sfntTable->sfntHeader.rangeShift = 0;
    sfntTable->sfntHeader.searchRange = 0;

    // figure out how much space we need for the uncompressed tables
    numTables = woffTable->record_list.count;
    tableBufferLen = 0;

    for(i = 0; i < numTables; ++i)
    {
        ULONG tableLength;
        woff_table_record* record = (woff_table_record*)vector_at(&woffTable->record_list, i);
        if(record)
        {
            tableLength = (record->origLength + 3) & ~3;
            tableBufferLen += tableLength;
        }
    }

    // allocate a buffer which will hold the uncompressed raw data for all of the tables
    if (lfFont->fontData)
        free(lfFont->fontData);

    if (0 == tableBufferLen)        // silence xcode analyzer
    {
        free(sfntTable);
        return LF_BAD_FORMAT;
    }

    lfFont->fontData = (BYTE*)calloc(1, tableBufferLen);
    if(lfFont->fontData == NULL)
    {
        free(sfntTable);
        return LF_OUT_OF_MEMORY;
    }
    lfFont->fontSize = tableBufferLen;

    error = vector_init(&sfntTable->record_list, numTables, 1);
    if(error != LF_ERROR_OK)
    {
        free(lfFont->fontData);
        lfFont->fontData = NULL;
        lfFont->fontSize = 0;
        free(sfntTable);
        return error;
    }

    // loop over tables, uncompress them into the buffer, update new sfnt table
    curPos = lfFont->fontData;
    
    for(i = 0; i < numTables; ++i)
    {
        sfnt_table_record* sfntRecord;
        woff_table_record* record = (woff_table_record*)vector_at(&woffTable->record_list, i);

        sfntRecord = (sfnt_table_record*)calloc(1, sizeof(sfnt_table_record));
        if((sfntRecord == NULL) || (record == NULL))
        {
            if(sfntRecord)
                free(sfntRecord);
            WOFF_cleanSfntTable(sfntTable);
            free(lfFont->fontData);
            lfFont->fontData = NULL;
            lfFont->fontSize = 0;
            return LF_OUT_OF_MEMORY;
        }

        sfntRecord->tag = record->tag;
        sfntRecord->length = record->origLength;
        sfntRecord->checkSum = record->origChecksum;
        sfntRecord->offset = (ULONG)(curPos-lfFont->fontData);

        vector_push_back(&sfntTable->record_list, sfntRecord);

        STREAM_streamSeek(stream, record->offset);

        // check for invalid data
        if ((size_t)(stream->Current - stream->Base + record->compLength) > stream->Length)
        {
            WOFF_cleanSfntTable(sfntTable);
            free(lfFont->fontData);
            lfFont->fontData = NULL;
            lfFont->fontSize = 0;
            return LF_BAD_FORMAT;
        }

        if(record->compLength == record->origLength)
        {
            // not compressed, just copy the data
            memcpy(curPos, stream->Current, record->origLength);
        }
        else
        {
            ULONG destLen = (ULONG)(tableBufferLen - (curPos - lfFont->fontData));                     // init to remaining available space in buffer
            //ULONG destlen = ()
            if(FALSE == WOFF_decompress(stream->Current, record->compLength, curPos, &destLen) ||
               ((destLen != record->origLength)))
            {
                WOFF_cleanSfntTable(sfntTable);
                free(lfFont->fontData);
                lfFont->fontData = NULL;
                lfFont->fontSize = 0;
                return LF_OUT_OF_MEMORY; //todo map to better error?
            }
        }

        curPos += ((record->origLength + 3) & ~3);
    }

    // get rid of the woff offset table
    offset_woff_freeTable(woffTable);

    // switch over to the new sfnt offset table
    lfFont->offset_table.sfnt = sfntTable;
    lfFont->fontType = (sfntTable->sfntHeader.sfnt_version == SIG_CFF) ? eLF_CFF_FONT : eLF_SFNT_FONT;

    return LF_ERROR_OK;
}

void WOFF_destroyOffsetTable(const LF_FONT* lfFont)
{
    woff_offset_table *woffTable = (woff_offset_table*)lfFont->offset_table.woff;

    offset_woff_freeTable(woffTable);
}

static LF_ERROR WOFF_writeData(LF_FONT* lfFont, const LF_WRITE_PARAMS *params, LF_STREAM* stream, woff_offset_table* woffTable)
{
    if(lfFont->woffInfo.metaData != NULL)
    {
        int compLevel = params->woffCompressionLevel;
        if (compLevel == 0)
            compLevel = 1; // according to the spec, the metadata must be compressed.

        if(lfFont->woffInfo.metatDataCompression == eWOFF2)
        {
            size_t bufSize, uncompressedSize;
            BYTE* buf;
            int zerror;

            // convert the data to be zlib compressed

            bufSize = (size_t)(lfFont->woffInfo.metaDataOrigLen + (lfFont->woffInfo.metaDataOrigLen >> 2));

            buf = (BYTE*)malloc(bufSize);
            if(buf == NULL)
                return LF_OUT_OF_MEMORY;

            // decompress with Brotli
            uncompressedSize = bufSize;
            if(FALSE == WOFF2_decompress(lfFont->woffInfo.metaData, lfFont->woffInfo.metaDataLen, buf, &uncompressedSize))
            {
                free(buf);
                return LF_COMPRESSION;
            }

            if(uncompressedSize != lfFont->woffInfo.metaDataOrigLen)
            {
                free(buf);
                return LF_OUT_OF_MEMORY;
            }

            free(lfFont->woffInfo.metaData);
            lfFont->woffInfo.metaData = NULL;

            uLongf compressedLength = (ULONG)compressBound((ULONG)uncompressedSize);
            lfFont->woffInfo.metaData = (BYTE*)malloc(compressedLength);
            if(lfFont->woffInfo.metaData == NULL)
            {
                free(buf);
                return LF_OUT_OF_MEMORY;
            }

            // compress with zlib
            zerror = compress2(lfFont->woffInfo.metaData, &compressedLength, buf, (ULONG)uncompressedSize, compLevel);

            free(buf);

            lfFont->woffInfo.metatDataCompression = eWOFF;
            lfFont->woffInfo.metaDataLen = (ULONG)compressedLength;

            if(zerror != Z_OK)
                return LF_OUT_OF_MEMORY;
        }
        else if(lfFont->woffInfo.metatDataCompression == eUNCOMPRESSED)
        {
            BYTE* buf;
            uLongf compressedLength;
            int zerror;

            compressedLength = (ULONG)compressBound(lfFont->woffInfo.metaDataOrigLen);
            buf = (BYTE*)malloc(compressedLength);
            if(buf == NULL)
                return LF_OUT_OF_MEMORY;

            // compress with zlib
            zerror = compress2(buf, (uLongf*)&compressedLength, lfFont->woffInfo.metaData,
                               lfFont->woffInfo.metaDataOrigLen, compLevel);

            if(zerror != Z_OK)
            {
                free(buf);
                return LF_OUT_OF_MEMORY;
            }
            else
            {
                lfFont->woffInfo.metaDataLen = (ULONG)compressedLength;
                free(lfFont->woffInfo.metaData);
                lfFont->woffInfo.metaData = buf;
                lfFont->woffInfo.metatDataCompression = eWOFF;
            }
        }
        else if(lfFont->woffInfo.metatDataCompression == eUNSET)
            return LF_BAD_FORMAT; // unexpected
    }


    // write meta and private data
    if(lfFont->woffInfo.metaData != NULL)
    {
        woffTable->woffHeader.metaLength = lfFont->woffInfo.metaDataLen;
        woffTable->woffHeader.metaOffset = (ULONG)STREAM_streamPos(stream);
        woffTable->woffHeader.length += lfFont->woffInfo.metaDataLen;
        STREAM_writeChunk(stream,  lfFont->woffInfo.metaData, lfFont->woffInfo.metaDataLen);
    }
    if(lfFont->woffInfo.privateData != NULL)
    {
        ULONG curPos, paddedPos;

        // the private data must be on a 4-byte boundary
        curPos = (ULONG)STREAM_streamPos(stream);
        paddedPos = (curPos + 3) & ~3;

        if(paddedPos > curPos)
        {
            BYTE zero[3] = {0};
            STREAM_writeChunk(stream, zero, (paddedPos-curPos));
            woffTable->woffHeader.length += (paddedPos-curPos);
        }

        woffTable->woffHeader.privLength = lfFont->woffInfo.privateDataLen;
        woffTable->woffHeader.privOffset = (ULONG)STREAM_streamPos(stream);
        STREAM_writeChunk(stream,  lfFont->woffInfo.privateData, lfFont->woffInfo.privateDataLen);
        woffTable->woffHeader.length += lfFont->woffInfo.privateDataLen;
    }

    return LF_ERROR_OK;
}

LF_ERROR WOFF_writeToStream(LF_FONT* lfFont, const LF_WRITE_PARAMS *params, LF_STREAM* stream)
{
    USHORT i, numTables;
    sfnt_offset_table* sfntTable;
    woff_offset_table* woffTable;
    ULONG maxTableLen = 0;

    if ((lfFont == NULL) || (params == NULL) || (stream == NULL))
        return LF_INVALID_PARAM;

    if (params->woffCompressionLevel > 9)
        return LF_INVALID_PARAM;

    if ((lfFont->builtSFNT == NULL) || (lfFont->builtSFNTOffsetTable == NULL))
        return LF_BAD_FORMAT;

    // create a new woff offset table
    woffTable = (woff_offset_table*)calloc(1, sizeof(woff_offset_table));
    if (woffTable == NULL)
        return LF_OUT_OF_MEMORY;

    sfntTable = (sfnt_offset_table*)lfFont->builtSFNTOffsetTable;

    numTables = (USHORT)vector_size(&sfntTable->record_list);

    LF_ERROR error = vector_init(&woffTable->record_list, numTables, 1);
    if (error != LF_ERROR_OK)
    {
        free(woffTable);
        return error;
    }

    // create the woff table records
    for (i = 0; i < numTables; ++i)
    {
        sfnt_table_record* sfntRecord;
        woff_table_record* woffRecord;

        sfntRecord = (sfnt_table_record*)vector_at(&sfntTable->record_list, i);
        if (sfntRecord == NULL)
        {
            offset_woff_freeTable(woffTable);
            return LF_OUT_OF_MEMORY;
        }

        if ((lfFont->fontType == eLF_SFNT_FONT) && (sfntRecord->tag == TAG_CFF))
            continue;
        if ((lfFont->fontType == eLF_CFF_FONT) && TableExcludedFromCFFFont(sfntRecord->tag))
            continue;

        woffRecord = (woff_table_record*)calloc(1, sizeof(woff_table_record));
        if (woffRecord == NULL)
        {
            offset_woff_freeTable(woffTable);
            return LF_OUT_OF_MEMORY;
        }

        woffRecord->tag = sfntRecord->tag;
        // rest of fields left at zero

        vector_push_back(&woffTable->record_list, woffRecord);

        if (sfntRecord->length > maxTableLen)
            maxTableLen = sfntRecord->length;
    }

    //initialize some values in the woff table header
    numTables = (USHORT)vector_size(&woffTable->record_list);

    woffTable->woffHeader.signature = 0x774F4646; // "wOFF"
    woffTable->woffHeader.flavor = sfntTable->sfntHeader.sfnt_version;
    woffTable->woffHeader.length = 44 /*header*/ + (numTables * 20) /*directory (5 longs per entry)*/;
    woffTable->woffHeader.numTables = numTables;
    woffTable->woffHeader.reserved = 0;
    woffTable->woffHeader.totalSfntSize = 12 /*sfnt header*/ + (16 * numTables) /*directory*/;

    woffTable->woffHeader.majorVersion = lfFont->woffInfo.majorVersion;
    woffTable->woffHeader.minorVersion = lfFont->woffInfo.minorVersion;

    woffTable->woffHeader.metaOffset = 0;   // updated later if needed
    woffTable->woffHeader.metaLength = lfFont->woffInfo.metaDataLen;
    woffTable->woffHeader.metaOrigLength = lfFont->woffInfo.metaDataOrigLen;
    woffTable->woffHeader.privLength = lfFont->woffInfo.privateDataLen;
    woffTable->woffHeader.privOffset = 0; // updated later if needed


    //write the initial version of woff header
    offset_woff_writeTable(woffTable, stream);

    if (FALSE == STREAM_ptrIsValid(stream))
    {
        offset_woff_freeTable(woffTable);
        return LF_STREAM_OVERRUN;
    }

    //compress (or not) /write the tables
    {
    BYTE* compressedBuf;
    uLongf tableBufLen, compressedBufLen, compressedBufOrigLen;

    // determine size for our buffers, add extra in case the written tables end up longer than the original due to any processing we did
    // in both the packed and unpakced case, there is a buffer (compressedBuf) to hold the compressed data for each table
    // in the case when the tables are unpacked (subsetting) each table is written to a local stream backed by another buffer (tableBuf)
    tableBufLen = maxTableLen + (maxTableLen >> 1);

    compressedBufLen = compressBound(tableBufLen);
    compressedBufOrigLen = compressedBufLen;

    compressedBuf = (BYTE*)malloc(compressedBufLen);
    if(compressedBuf == NULL)
    {
        offset_woff_freeTable(woffTable);
        return LF_OUT_OF_MEMORY;
    }

    for(i = 0; i < numTables; ++i)
    {
        int zerror;
        sfnt_table_record* sfntRecord;
        woff_table_record* woffRecord;

        woffRecord = (woff_table_record*)vector_at(&woffTable->record_list, i);
        if(woffRecord == NULL)
        {
            offset_woff_freeTable(woffTable);
            free(compressedBuf);
            return LF_BAD_FORMAT;
        }

        // find the corresponding entry in the original sfnt table
        sfntRecord = offset_findRecordEx(sfntTable, woffRecord->tag);
        if(sfntRecord == NULL)
        {
            offset_woff_freeTable(woffTable);
            free(compressedBuf);
            return LF_BAD_FORMAT;
        }

        compressedBufLen = compressedBufOrigLen;        // reset

        if((params->woffCompressionLevel == 0) || (sfntRecord->length < params->woffMinTableSize))
        {
            ; // this table will not be compressed.
        }
        else
        {
            // just offset into sfnt buffer
            zerror = compress2(compressedBuf, &compressedBufLen,
                               ((BYTE*)lfFont->builtSFNT + sfntRecord->offset),
                               sfntRecord->length, params->woffCompressionLevel);
            if(zerror != Z_OK)
            {
                free(compressedBuf);
                offset_woff_freeTable(woffTable);
                return LF_OUT_OF_MEMORY; //todo map to better error?
            }
        }

        // write table data (compressed or not) to the file and update the record
        if(compressedBufLen < sfntRecord->length)
        {
            // compression made it smaller, write compressed buffer to file
            ULONG paddedLen = (ULONG)((compressedBufLen + 3) & ~3);
            ULONG uncompressedPaddedLen = (sfntRecord->length + 3) & ~3;

            if(paddedLen != compressedBufLen)
                memset(compressedBuf + compressedBufLen, 0, 3);           // make sure pad bytes are zero

            STREAM_writeChunk(stream, compressedBuf, paddedLen);

            woffRecord->compLength = (ULONG)compressedBufLen;
            woffRecord->origLength = sfntRecord->length;
            woffRecord->origChecksum = sfntRecord->checkSum;
            woffRecord->offset = woffTable->woffHeader.length;

            woffTable->woffHeader.totalSfntSize += uncompressedPaddedLen;
            woffTable->woffHeader.length += paddedLen;
        }
        else
        {
            // store the data uncompressed
            size_t uncompressedPaddedLen = (sfntRecord->length + 3) & ~3;

            STREAM_writeChunk(stream, (BYTE*)lfFont->builtSFNT + sfntRecord->offset, uncompressedPaddedLen);

            woffRecord->compLength = sfntRecord->length;
            woffRecord->origLength = sfntRecord->length;
            woffRecord->origChecksum = sfntRecord->checkSum;
            woffRecord->offset = woffTable->woffHeader.length;

            woffTable->woffHeader.totalSfntSize += (ULONG)uncompressedPaddedLen;
            woffTable->woffHeader.length += (ULONG)uncompressedPaddedLen;
        }
    }

    free(compressedBuf);

    if (FALSE == STREAM_ptrIsValid(stream))
    {
        offset_woff_freeTable(woffTable);
        return LF_STREAM_OVERRUN;
    }
    }

    if(LF_ERROR_OK != WOFF_writeData(lfFont, params, stream, woffTable))
    {
        // non-fatal?
        DEBUG_LOG_ERROR("Failed to write metadata and private data to font.");
    }

    if (FALSE == STREAM_ptrIsValid(stream))
    {
        offset_woff_freeTable(woffTable);
        return LF_STREAM_OVERRUN;
    }

    // write updated header
    STREAM_streamSeek(stream, 0);
    offset_woff_writeTable(woffTable, stream);

    // Set to end so client can get size
    STREAM_streamSeek(stream, woffTable->woffHeader.length);

    offset_woff_freeTable(woffTable);

    if (FALSE == STREAM_ptrIsValid(stream))
        return LF_STREAM_OVERRUN;

    return LF_ERROR_OK;
}

LF_ERROR WOFF_getMaxSize(LF_FONT* lfFont, const LF_WRITE_PARAMS *params, size_t* size)
{
    LF_ERROR error;
    USHORT numTables;

    error = SFNT_getSFNTSize(lfFont, params, size);
    if(error != LF_ERROR_OK)
        return error;

    numTables = offset_getNumTables(lfFont);

    // *size now has the uncompressed size of all the tables, when they (some of them) are compressed, it will be less

    *size += 44; // header
    *size += numTables * 5 * sizeof(ULONG); // table directory

    if(lfFont->woffInfo.metaData != NULL)
        *size += lfFont->woffInfo.metaDataOrigLen;      // uncompressed size (actual will be less)
    if(lfFont->woffInfo.privateData != NULL)
        *size += lfFont->woffInfo.privateDataLen;

    return error;
}
