// Copyright (C) 2014 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// anchor.c

#include <stdlib.h>
#include "anchor.h"
#include "utils.h"


LF_ERROR Anchor_readTable(anchor_table* table, LF_STREAM* stream)
{
    size_t tableStart = STREAM_streamPos(stream);

    if (table == NULL)
        return LF_BAD_FORMAT;

    memset(table, 0, sizeof(anchor_table));

    table->AnchorFormat = STREAM_readUShort(stream);

    table->XCoordinate = STREAM_readShort(stream);
    table->YCoordinate = STREAM_readShort(stream);

    if (table->AnchorFormat == 1)
    {
        return LF_ERROR_OK;
    }
    else if(table->AnchorFormat == 2)
    {
        table->anchor_format.format_2.AnchorPoint = STREAM_readUShort(stream);
    }
    else if(table->AnchorFormat == 3)
    {
        OFFSET xOffset = STREAM_readOffset(stream);
        OFFSET yOffset = STREAM_readOffset(stream);

        if (xOffset)
        {
            STREAM_streamSeek(stream, tableStart + xOffset);
            DeviceTable_readTable(&table->anchor_format.format_3.XDeviceTable, stream);
        }

        if (yOffset)
        {
            STREAM_streamSeek(stream, tableStart + yOffset);
            DeviceTable_readTable(&table->anchor_format.format_3.YDeviceTable, stream);
        }
    }
    else
    {
        return LF_BAD_FORMAT;
    }

    return LF_ERROR_OK;
}

LF_ERROR Anchor_getTableSize(const anchor_table* table, size_t* tableSize)
{
    *tableSize = sizeof(USHORT) + sizeof(SHORT) * 2;

    if (table->AnchorFormat == 1)
    {
        return LF_ERROR_OK;
    }
    else if(table->AnchorFormat == 2)
    {
        *tableSize += sizeof(USHORT);
    }
    else if(table->AnchorFormat == 3)
    {
        size_t deviceSize = 0;
        *tableSize += (2*sizeof(OFFSET));

        if (table->anchor_format.format_3.XDeviceTable.DeltaFormat != 0)
        {
            DeviceTable_getTableSize(&table->anchor_format.format_3.XDeviceTable, &deviceSize);
            *tableSize += deviceSize;
        }
        if (table->anchor_format.format_3.YDeviceTable.DeltaFormat != 0)
        {
            DeviceTable_getTableSize(&table->anchor_format.format_3.YDeviceTable, &deviceSize);
            *tableSize += deviceSize;
        }
    }
    else
    {
        return LF_BAD_FORMAT;
    }

    return LF_ERROR_OK;
}


LF_ERROR Anchor_buildTable(anchor_table* table, LF_STREAM* stream)
{
    size_t tableStart = STREAM_streamPos(stream);

    STREAM_writeUShort(stream, table->AnchorFormat);
    STREAM_writeShort(stream, table->XCoordinate);
    STREAM_writeShort(stream, table->YCoordinate);

    if (table->AnchorFormat == 1)
    {
        return LF_ERROR_OK;
    }
    else if(table->AnchorFormat == 2)
    {
        STREAM_writeUShort(stream, table->anchor_format.format_2.AnchorPoint);
    }
    else if(table->AnchorFormat == 3)
    {
        OFFSET deviceOffset = (OFFSET)(STREAM_streamPos(stream) - tableStart + (sizeof(OFFSET) * 2));
        size_t xDevicePos = STREAM_streamPos(stream);
        size_t yDevicePos = xDevicePos + sizeof(OFFSET);

        if (table->anchor_format.format_3.XDeviceTable.DeltaFormat > 0)
        {
            STREAM_writeShort(stream, deviceOffset);
            STREAM_streamSeek(stream, tableStart + deviceOffset);
            DeviceTable_buildTable(&table->anchor_format.format_3.XDeviceTable, stream);
            deviceOffset = (OFFSET)STREAM_streamPos(stream) - (OFFSET)tableStart;
        }
        else
        {
            STREAM_writeShort(stream, 0);
        }

        STREAM_streamSeek(stream, yDevicePos);
        if (table->anchor_format.format_3.YDeviceTable.DeltaFormat > 0)
        {
            STREAM_writeShort(stream, deviceOffset);
            STREAM_streamSeek(stream, tableStart + deviceOffset);
            DeviceTable_buildTable(&table->anchor_format.format_3.YDeviceTable, stream);
            deviceOffset = (OFFSET)STREAM_streamPos(stream) - (OFFSET)tableStart;
        }
        else
        {
            STREAM_writeShort(stream, 0);
        }
        STREAM_streamSeek(stream, tableStart + deviceOffset);  // Return with stream at the end of the device tables
    }
    else
    {
        DEBUG_LOG_WARNING("AnchorTable contains an unsupported bad format");
        return LF_BAD_FORMAT;
    }

    return LF_ERROR_OK;
}




LF_ERROR Anchor_freeTable(anchor_table* table)
{
    if (table->AnchorFormat == 3)
    {
        DeviceTable_freeTable(&table->anchor_format.format_3.XDeviceTable);
        DeviceTable_freeTable(&table->anchor_format.format_3.YDeviceTable);
    }

    return LF_ERROR_OK;
}

#ifdef LF_OT_DUMP
static void Anchor_dumpFormat1(const anchor_table* table)
{
    XML_START("Anchor");
    XML_DATA_NODE("XCoord", table->XCoordinate);
    XML_DATA_NODE("YCoord", table->YCoordinate);
    XML_END("Anchor");
}

static void Anchor_dumpFormat2(const anchor_table* table)
{
    XML_START("Anchor");
    XML_DATA_NODE("XCoord", table->XCoordinate);
    XML_DATA_NODE("YCoord", table->YCoordinate);
    XML_DATA_NODE("AnchorPoint", table->anchor_format.format_2.AnchorPoint);
    XML_END("Anchor");
}

static void Anchor_dumpFormat3(anchor_table* table)
{
    XML_START("Anchor");
    XML_DATA_NODE("XCoord", table->XCoordinate);
    XML_DATA_NODE("YCoord", table->YCoordinate);

    if (table->anchor_format.format_3.XDeviceTable.DeltaFormat > 0)
    {
        XML_START("XDeviceTable");
        DeviceTable_dumpTable(&table->anchor_format.format_3.XDeviceTable);
        XML_END("XDeviceTable");
    }
    else
    {
        XML_START("XDeviceTable");
        XML_COMMENT("XDeviceTable is empty", 0);
        XML_END("XDeviceTable");
    }

    if (table->anchor_format.format_3.YDeviceTable.DeltaFormat > 0)
    {
        XML_START("YDeviceTable");
        DeviceTable_dumpTable(&table->anchor_format.format_3.YDeviceTable);
        XML_END("YDeviceTable");
    }
    else
    {
        XML_START("YDeviceTable");
        XML_COMMENT("YDeviceTable is empty", 0);
        XML_END("YDeviceTable");
    }
    XML_END("Anchor");
}

void Anchor_dumpTable(anchor_table* table)
{
    XML_START("AnchorTable");
    if (table)
    {
        XML_DATA_NODE("AnchorFormat", table->AnchorFormat);

        switch (table->AnchorFormat)
        {
        case 1:        Anchor_dumpFormat1(table);                                        break;
        case 2:        Anchor_dumpFormat2(table);                                        break;
        case 3:        Anchor_dumpFormat3(table);                                        break;
        default:       XML_COMMENT("Empty AnchorTable", table->AnchorFormat);            break;
        }
    }
    else
    {
        XML_COMMENT("AnchorTable is null", 0);
    }
    XML_END("AnchorTable");
}
#endif
