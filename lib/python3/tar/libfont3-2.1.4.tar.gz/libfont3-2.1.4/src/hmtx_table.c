// Copyright (C) 2014 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// hmtx_table.c

#include "hmtx_table.h"
#include "hhea_table.h"
#include "maxp_table.h"
#include "glyf_table.h"
#include "cff_table.h"
#include "utils.h"

static void HMTX_cleanupMetricsMap(hmtx_table* table)
{
    size_t i, metricsVectorSize;

    metricsVectorSize = table->metricsVector.count;

    for (i = 0; i < metricsVectorSize; i++)
    {
        longHorMetric* lhm = (longHorMetric *)vector_at(&table->metricsVector, i);
        if (lhm != (longHorMetric *)(intptr_t)HMTX_MARK_REMOVED)
            free(lhm);
    }
    vector_delete(&table->metricsVector);
}   //lint !e429 In the current implementation the table itself is freed subsequent to calls to this function


LF_ERROR HMTX_readTable(LF_FONT* lfFont, const sfnt_table_record* record, LF_STREAM* stream)
{
    if(STREAM_streamSeek(stream, record->offset) == 0)
    {
        if(NULL == map_at(&lfFont->table_map, (void*)TAG_HHEA))
            return LF_TABLE_MISSING;
        if(NULL == map_at(&lfFont->table_map, (void*)TAG_MAXP))
            return LF_TABLE_MISSING;

        USHORT numHMetrics = HHEA_getNumHMetrics(lfFont);
        USHORT numGlyphs = MAXP_getNumGlyphs(lfFont);

        hmtx_table* table = (hmtx_table*)malloc(sizeof(hmtx_table));
        if (table == NULL)
            return LF_OUT_OF_MEMORY;

        // initialize
        table->numHMetrics = 0;
        table->numMetricsCalculated = FALSE;
        table->subsetted = FALSE;
        table->calculatedTableSize = 0;

        if(LF_ERROR_OK != vector_init(&table->metricsVector, numGlyphs, 100))
        {
            free(table);
            return LF_OUT_OF_MEMORY;
        }

        USHORT i, advanceWidthOfLSBList = 0;

        for(i = 0; i < numGlyphs; i++)
        {
            longHorMetric *lhm = (longHorMetric*)malloc(sizeof(longHorMetric));
            if(lhm == NULL)
            {
                HMTX_cleanupMetricsMap(table);
                free(table);
                return LF_OUT_OF_MEMORY;
            }

            if(i < numHMetrics)
                lhm->advanceWidth = STREAM_readUShort(stream);
            else
                lhm->advanceWidth = advanceWidthOfLSBList;

            if(i == numHMetrics-1)
                advanceWidthOfLSBList = lhm->advanceWidth;

            lhm->lsb = STREAM_readShort(stream);

            vector_push_back(&table->metricsVector, (void*)lhm);
        }

        map_insert(&lfFont->table_map, (void*)(intptr_t)record->tag, table);

        return LF_ERROR_OK;
    }

    return LF_INVALID_OFFSET;
}

LF_ERROR HMTX_expandTable(LF_FONT* lfFont, USHORT numGlyphs)
{
    hmtx_table* table = (hmtx_table*)map_at(&lfFont->table_map, (void*)TAG_HMTX);
    if (table == NULL)
        return LF_TABLE_MISSING;

    USHORT origSize = (USHORT)table->metricsVector.count;

    if (origSize >= numGlyphs)
        return LF_INVALID_PARAM;

    LF_ERROR error = vector_resize(&table->metricsVector, numGlyphs);
    if (error != LF_ERROR_OK)
        return error;

    for (size_t i = origSize; i < numGlyphs; i++)
    {
        longHorMetric *lhm = (longHorMetric*)calloc(1, sizeof(longHorMetric));
        if (lhm == NULL)
            return LF_OUT_OF_MEMORY;

        vector_push_back(&table->metricsVector, (void*)lhm);
    }

    return LF_ERROR_OK;
}

LF_ERROR HMTX_setMetric(LF_FONT* lfFont, size_t index, USHORT advanceWidth, SHORT lsb)
{
    hmtx_table* table = (hmtx_table*)map_at(&lfFont->table_map, (void*)TAG_HMTX);
    if (table == NULL)
        return LF_TABLE_MISSING;

    longHorMetric *lhm = vector_at(&table->metricsVector, index);

    lhm->advanceWidth = advanceWidth;
    lhm->lsb = lsb;

    return LF_ERROR_OK;
}

static LF_ERROR HMTX_getNumMetrics(hmtx_table* table, USHORT *numHMetrics)
{
    USHORT index = 0, lastDelta = 0;
    USHORT indexOfLastDelta = 0;
    longHorMetric* lhm;
    boolean first = TRUE;

    if (table->numMetricsCalculated == TRUE)
    {
        *numHMetrics = table->numHMetrics;
        return LF_ERROR_OK;
    }

    // iterate through the current set of metrics and find the last change in
    // advance width, this determines how many Hmetrics there will be.
    // (the keys (glyph ids) are in ascending order)

    for (size_t i = 0; i < table->metricsVector.count; i++)
    {
        lhm = (longHorMetric *)vector_at(&table->metricsVector, i);

        if (lhm && lhm != (longHorMetric *)(intptr_t)HMTX_MARK_REMOVED)
        {
            if (first)
            {
                first = FALSE;
                lastDelta = lhm->advanceWidth;
                index = 0;
                indexOfLastDelta = 0;
            }

            index++;

            if (lhm->advanceWidth != lastDelta)
            {
                lastDelta = lhm->advanceWidth;
                indexOfLastDelta = index;
            }
        }
    }

    if (indexOfLastDelta == 0)
        indexOfLastDelta = 1;   // there must be at least one item in the metrics list

    *numHMetrics = indexOfLastDelta;

    table->numMetricsCalculated = TRUE;
    table->numHMetrics = indexOfLastDelta;

    return LF_ERROR_OK;
}

LF_ERROR HMTX_getTableSize(LF_FONT* lfFont, size_t* tableSize)
{
    USHORT numGlyphs = 0, numHMetrics, numLSBs;

    *tableSize = 0;

    hmtx_table* table = (hmtx_table*)map_at(&lfFont->table_map, (void*)TAG_HMTX);
    if (table == NULL)
        return LF_TABLE_MISSING;

    if (table->calculatedTableSize != 0)
    {
        *tableSize = table->calculatedTableSize;
        return LF_ERROR_OK;
    }

    // Check consistency of MAXP table with this table for the conversion case
    USHORT numMaxpGlyphs = MAXP_getNumGlyphs(lfFont);
    if ((table->subsetted == FALSE) && (numMaxpGlyphs != table->metricsVector.count))
        return LF_BAD_FORMAT;

    // get the number of metrics
    LF_ERROR error = HMTX_getNumMetrics(table, &numHMetrics);
    if (error != LF_ERROR_OK)
        return error;

    for (size_t i = 0; i < table->metricsVector.count; i++)
    {
        longHorMetric* lhm = (longHorMetric*)vector_at(&table->metricsVector, i);

        if (lhm != (longHorMetric *)(intptr_t)HMTX_MARK_REMOVED)
            numGlyphs++;
    }
    numLSBs = numGlyphs - numHMetrics;

    *tableSize = numHMetrics * LONGHORMETRIC_SIZE;
    *tableSize += numLSBs * sizeof(SHORT);

    table->calculatedTableSize = *tableSize;

    return LF_ERROR_OK;
}

LF_ERROR HMTX_removeGlyph(LF_FONT* lfFont, ULONG index)
{
    hmtx_table* table = (hmtx_table*)map_at(&lfFont->table_map, (void*)TAG_HMTX);

    if(table == NULL)
        return LF_TABLE_MISSING;

    table->numMetricsCalculated = FALSE;
    table->subsetted = TRUE;
    table->calculatedTableSize = 0;

    longHorMetric* lhm = (longHorMetric *)vector_at(&table->metricsVector, index);
    if(lhm == NULL)
        return LF_INVALID_INDEX;

    if (lhm != (longHorMetric *)(intptr_t)HMTX_MARK_REMOVED)
    {
        free(lhm);

        vector_set_data(&table->metricsVector, index, (void*)(intptr_t)HMTX_MARK_REMOVED);
    }

    return LF_ERROR_OK;
}

USHORT HMTX_getAdvanceWidth(LF_FONT* lfFont, size_t index)
{
    hmtx_table* table = (hmtx_table*)map_at(&lfFont->table_map, (void*)TAG_HMTX);
    longHorMetric* lhm = (longHorMetric *)vector_at(&table->metricsVector, index);
    return lhm->advanceWidth;
}

UFWORD HMTX_getAdvanceWidthMax(LF_FONT* lfFont)
{
    UFWORD max = 0;
    hmtx_table* table = (hmtx_table*)map_at(&lfFont->table_map, (void*)TAG_HMTX);

    ASSERT(table);

    if (NULL == table)
        return 0;

    for (size_t i = 0; i < table->metricsVector.count; i++)
    {
        longHorMetric* lhm = (longHorMetric *)vector_at(&table->metricsVector, i);

        if (lhm && lhm != (longHorMetric *)(intptr_t)HMTX_MARK_REMOVED)
        {
            if(lhm->advanceWidth > max)
                max = lhm->advanceWidth;
        }
    }

    return max;
}

FWORD HMTX_getAdvanceWidthAvg(LF_FONT* lfFont)
{
    LONG avg = 0;
    size_t count = 0;
    hmtx_table* table = (hmtx_table*)map_at(&lfFont->table_map, (void*)TAG_HMTX);

    ASSERT(table);

    if (NULL == table)
        return 0;

    for (size_t i = 0; i < table->metricsVector.count; i++)
    {
        longHorMetric* lhm = (longHorMetric *)vector_at(&table->metricsVector, i);

        if (lhm && lhm != (longHorMetric *)(intptr_t)HMTX_MARK_REMOVED)
        {
            if (lhm->advanceWidth != 0)
            {
                avg += lhm->advanceWidth;
                count++;
            }
        }
    }

    if (count)
        avg = avg / (LONG)count;
    return (FWORD)avg;
}

// update the left side bearing values and 
// get the minimum left and right sidebearings based on the type of font
LF_ERROR HMTX_updateSidebearings(LF_FONT* lfFont, LF_FONT_TYPE type, 
    FWORD *minlsb, FWORD *minrsb, FWORD *maxadvance)
{
    hmtx_table* table = (hmtx_table*)map_at(&lfFont->table_map, (void*)TAG_HMTX);

    *minlsb = 32767;
    *minrsb = 32767;
    *maxadvance = 0;

    ASSERT(table);

    LF_MAP_ITER* mapIter;
    rb_tree_node* node;

    if (type == eLF_SFNT_FONT)
    {
        glyf_table* glyfTable = (glyf_table*)map_at(&lfFont->table_map, (void*)TAG_GLYF);
        if (glyfTable == NULL)
            return LF_EMPTY_TABLE;

        if (0 == map_size(glyfTable->glyfMap))
            return LF_EMPTY_TABLE;

        mapIter = map_begin(glyfTable->glyfMap);
        if (mapIter == NULL)
            return LF_OUT_OF_MEMORY;

        node = map_next(mapIter);

        glyf* glyf_object = (glyf*)node->data;

        for (size_t i = 0; i < table->metricsVector.count; i++)
        {
            longHorMetric* lhm = (longHorMetric *)vector_at(&table->metricsVector, i);

            if (lhm && lhm != (longHorMetric *)(intptr_t)HMTX_MARK_REMOVED)
            {
                if (glyf_object && glyf_object->numberOfContours != 0)
                {
                    lhm->lsb = glyf_object->xMin;
                    if (lhm->lsb < *minlsb)
                        *minlsb = lhm->lsb;
                    FWORD rsb = (FWORD)(lhm->advanceWidth - lhm->lsb - (glyf_object->xMax - glyf_object->xMin));
                    if (rsb < *minrsb)
                        *minrsb = rsb;
                }

                if (lhm->advanceWidth > *maxadvance)
                    *maxadvance = lhm->advanceWidth;
                node = map_next(mapIter);
                if (node == NULL)
                    break;
                else
                    glyf_object = (glyf*)node->data;
            }
        }
        map_free_iter(mapIter);

    }
    else
    {
        cff_table* cffTable = (cff_table*)map_at(&lfFont->table_map, (void*)TAG_CFF);
        if (cffTable == NULL)
            return LF_EMPTY_TABLE;

        if (cffTable->charStringMap == NULL)
            return LF_BAD_FORMAT;

        size_t j = 0;
        cffAnalyzedCharstring* acs;

        for (size_t i = 0; i < table->metricsVector.count; i++)
        {
            longHorMetric* lhm = (longHorMetric *)vector_at(&table->metricsVector, i);

            if (lhm && lhm != (longHorMetric *)(intptr_t)HMTX_MARK_REMOVED)
            {
                acs = (cffAnalyzedCharstring*)map_at(cffTable->charStringMap, (void*)(intptr_t)j);
                if (acs && (acs->isEmpty == FALSE))
                {
                    if (acs->seacInfo == NULL)
                    {
                        lhm->lsb = (SHORT)(acs->bb.xMin >> 16); //lint !e702
                        if (lhm->lsb < *minlsb)
                            *minlsb = lhm->lsb;
                        FWORD rsb = (FWORD)(lhm->advanceWidth - lhm->lsb - ((acs->bb.xMax - acs->bb.xMin) >> 16)); //lint !e702
                        if (rsb < *minrsb)
                            *minrsb = rsb;
                    }
                    else
                    {
                        // seacs are present only if subsetting a cff font, so the original lsb is valid.
                        if (lhm->lsb < *minlsb)
                            *minlsb = lhm->lsb;
                        // check of rsb not needed since the base character will be checked within this loop
                    }
                }
                if (lhm->advanceWidth > *maxadvance)
                    *maxadvance = lhm->advanceWidth;
                j++;
            }
        }
    }

    return LF_ERROR_OK;
}

USHORT HMTX_getNumHMetrics(LF_FONT* lfFont)
{
    USHORT numHMetrics = 0;
    hmtx_table* table = (hmtx_table*)map_at(&lfFont->table_map, (void*)TAG_HMTX);

    if (table)
        HMTX_getNumMetrics(table, &numHMetrics);

    return numHMetrics;
}

static LF_ERROR HMTX_buildTable(LF_FONT* lfFont, BYTE** tableData, size_t* tableSize)
{
    *tableData = NULL;
    *tableSize = 0;

    hmtx_table* table = (hmtx_table*)map_at(&lfFont->table_map, (void*)TAG_HMTX);
    if (table == NULL)
        return LF_TABLE_MISSING;

    LF_ERROR error = HMTX_getTableSize(lfFont, tableSize);
    if (error != LF_ERROR_OK)
        return error;

    size_t paddedSize = *tableSize;
    *tableData = UTILS_AllocTable(&paddedSize);
    if (*tableData == NULL)
    {
        DEBUG_LOG_ERROR("allocation failure in HMTX_buildTable");
        return LF_OUT_OF_MEMORY;
    }

    LF_STREAM stream;
    STREAM_initMemStream(&stream, *tableData, *tableSize);

    ASSERT(table->numHMetrics >= 1);

    USHORT index = 0;

    for (size_t i = 0; i < table->metricsVector.count; i++)
    {
        longHorMetric* lhm = (longHorMetric *)vector_at(&table->metricsVector, i);

        if (lhm && lhm != (longHorMetric *)(intptr_t)HMTX_MARK_REMOVED)
        {
            if (index < table->numHMetrics)
            {
                STREAM_writeUShort(&stream, lhm->advanceWidth);
                STREAM_writeShort(&stream, lhm->lsb);
            }
            else
            {
                STREAM_writeShort(&stream, lhm->lsb);
            }

            index++;
        }
    }

    return LF_ERROR_OK;
}

LF_ERROR HMTX_writeTable(LF_FONT* lfFont, sfnt_table_record* record, LF_STREAM* stream)
{
    //ULONG paddedLen = 0;
    size_t tableSize;
    BYTE* tableData;

    LF_ERROR error = HMTX_buildTable(lfFont, &tableData, &tableSize);
    if (error != LF_ERROR_OK)
        return error;

    //UTILS_PadTable(&tableData, tableSize, &paddedLen);

    record->checkSum = UTILS_CalcTableChecksum(tableData, tableSize);
    record->length = (ULONG)tableSize;
    record->offset = (ULONG)STREAM_streamPos(stream);

    STREAM_writeChunk(stream, tableData, (tableSize + 3) & ~3);
    free(tableData);

    return LF_ERROR_OK;
}

LF_ERROR HMTX_remapTable(LF_FONT* lfFont, LF_MAP *remap)
{
    hmtx_table* table = (hmtx_table*)map_at(&lfFont->table_map, (void*)TAG_HMTX);
    size_t i, metricsVectorSize;
    USHORT index = 0;

    UNUSED(remap);

    metricsVectorSize = table->metricsVector.count;

    for (i = 0; i < metricsVectorSize; i++)
    {
        longHorMetric* lhm = (longHorMetric *)vector_at(&table->metricsVector, i);

        if (lhm && lhm != (longHorMetric *)(intptr_t)HMTX_MARK_REMOVED)
        {
            if (index != i)
            {
                vector_set_data(&table->metricsVector, index, lhm);
                vector_set_data(&table->metricsVector, i, (void*)(intptr_t)HMTX_MARK_REMOVED);
            }
            index++;
        }
    }

    return LF_ERROR_OK;
}

LF_ERROR HMTX_freeTable(LF_FONT* lfFont)
{
    hmtx_table* table = (hmtx_table*)map_at(&lfFont->table_map, (void*)TAG_HMTX);

    if(table)
    {
        HMTX_cleanupMetricsMap(table);

        free(table);
    }

    return LF_ERROR_OK;
}
