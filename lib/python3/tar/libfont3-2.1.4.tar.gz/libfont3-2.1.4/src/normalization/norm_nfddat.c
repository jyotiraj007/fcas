// Copyright (C) 2014 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// norm_nfddat.c

#include "normalization/norm_nfddat.h"

/* ******************** Begin Script-Generated Code  ******************** */


/************************************************************
 * The following code was generated from:
 *    http://www.unicode.org/Public/UNIDATA/UnicodeData.txt
 * by the Python script:
 *    DecompositionCanonicalTables.py
 * on:
 *    Tue 05 Feb 2013 @ 14:34:25
 ************************************************************/


/* data size:  7086 bytes */
/* index size: 1632 bytes */
/* ---------------------- */
/* Total size: 8718 bytes */


const DecompositionIndexType
decompositionIndex[] =
{
    /* start, length, (table | index) -- table is MS 2 bits, index is LS 14 bits*/
    { 0x0000C0, 0x0017, 0x0000 }, 
    { 0x0000D9, 0x0005, 0x0017 }, 
    { 0x0000E0, 0x0017, 0x001C }, 
    { 0x0000F9, 0x0017, 0x0033 }, 
    { 0x000112, 0x0014, 0x004A }, 
    { 0x000128, 0x0009, 0x005E }, 
    { 0x000134, 0x000B, 0x0067 }, 
    { 0x000143, 0x0006, 0x0072 }, 
    { 0x00014C, 0x0006, 0x0078 }, 
    { 0x000154, 0x0012, 0x007E }, 
    { 0x000168, 0x0017, 0x0090 }, 
    { 0x0001A0, 0x0002, 0x00A7 }, 
    { 0x0001AF, 0x0002, 0x00A9 }, 
    { 0x0001CD, 0x0017, 0x00AB }, 
    { 0x0001E6, 0x000B, 0x00C2 }, 
    { 0x0001F4, 0x0002, 0x00CD }, 
    { 0x0001F8, 0x0024, 0x00CF }, 
    { 0x00021E, 0x0002, 0x00F3 }, 
    { 0x000226, 0x000E, 0x00F5 }, 
    { 0x000340, 0x0005, 0x0103 }, 
    { 0x000374, 0x0001, 0x0108 }, 
    { 0x00037E, 0x0001, 0x0109 }, 
    { 0x000385, 0x000C, 0x010A }, 
    { 0x0003AA, 0x0007, 0x0116 }, 
    { 0x0003CA, 0x0005, 0x011D }, 
    { 0x0003D3, 0x0002, 0x0122 }, 
    { 0x000400, 0x0004, 0x0124 }, 
    { 0x000407, 0x0001, 0x0128 }, 
    { 0x00040C, 0x0003, 0x0129 }, 
    { 0x000419, 0x0001, 0x012C }, 
    { 0x000439, 0x0001, 0x012D }, 
    { 0x000450, 0x0004, 0x012E }, 
    { 0x000457, 0x0001, 0x0132 }, 
    { 0x00045C, 0x0003, 0x0133 }, 
    { 0x000476, 0x0002, 0x0136 }, 
    { 0x0004C1, 0x0002, 0x0138 }, 
    { 0x0004D0, 0x0004, 0x013A }, 
    { 0x0004D6, 0x0002, 0x013E }, 
    { 0x0004DA, 0x0006, 0x0140 }, 
    { 0x0004E2, 0x0006, 0x0146 }, 
    { 0x0004EA, 0x000C, 0x014C }, 
    { 0x0004F8, 0x0002, 0x0158 }, 
    { 0x000622, 0x0005, 0x015A }, 
    { 0x0006C0, 0x0003, 0x015F }, 
    { 0x0006D3, 0x0001, 0x0162 }, 
    { 0x000929, 0x0001, 0x0163 }, 
    { 0x000931, 0x0001, 0x0164 }, 
    { 0x000934, 0x0001, 0x0165 }, 
    { 0x000958, 0x0008, 0x0166 }, 
    { 0x0009CB, 0x0002, 0x016E }, 
    { 0x0009DC, 0x0004, 0x0170 }, 
    { 0x000A33, 0x0001, 0x0174 }, 
    { 0x000A36, 0x0001, 0x0175 }, 
    { 0x000A59, 0x0003, 0x0176 }, 
    { 0x000A5E, 0x0001, 0x0179 }, 
    { 0x000B48, 0x0001, 0x017A }, 
    { 0x000B4B, 0x0002, 0x017B }, 
    { 0x000B5C, 0x0002, 0x017D }, 
    { 0x000B94, 0x0001, 0x017F }, 
    { 0x000BCA, 0x0003, 0x0180 }, 
    { 0x000C48, 0x0001, 0x0183 }, 
    { 0x000CC0, 0x0001, 0x0184 }, 
    { 0x000CC7, 0x0005, 0x0185 }, 
    { 0x000D4A, 0x0003, 0x018A }, 
    { 0x000DDA, 0x0005, 0x018D }, 
    { 0x000F43, 0x0001, 0x0192 }, 
    { 0x000F4D, 0x0001, 0x0193 }, 
    { 0x000F52, 0x0001, 0x0194 }, 
    { 0x000F57, 0x0001, 0x0195 }, 
    { 0x000F5C, 0x0001, 0x0196 }, 
    { 0x000F69, 0x0001, 0x0197 }, 
    { 0x000F73, 0x0006, 0x0198 }, 
    { 0x000F81, 0x0001, 0x019E }, 
    { 0x000F93, 0x0001, 0x019F }, 
    { 0x000F9D, 0x0001, 0x01A0 }, 
    { 0x000FA2, 0x0001, 0x01A1 }, 
    { 0x000FA7, 0x0001, 0x01A2 }, 
    { 0x000FAC, 0x0001, 0x01A3 }, 
    { 0x000FB9, 0x0001, 0x01A4 }, 
    { 0x001026, 0x0001, 0x01A5 }, 
    { 0x001B06, 0x0009, 0x01A6 }, 
    { 0x001B12, 0x0001, 0x01AF }, 
    { 0x001B3B, 0x0003, 0x01B0 }, 
    { 0x001B40, 0x0004, 0x01B3 }, 
    { 0x001E00, 0x009C, 0x01B7 }, 
    { 0x001EA0, 0x005A, 0x0253 }, 
    { 0x001F00, 0x0016, 0x02AD }, 
    { 0x001F18, 0x0006, 0x02C3 }, 
    { 0x001F20, 0x0026, 0x02C9 }, 
    { 0x001F48, 0x0006, 0x02EF }, 
    { 0x001F50, 0x002E, 0x02F5 }, 
    { 0x001F80, 0x003F, 0x0323 }, 
    { 0x001FC1, 0x0013, 0x0362 }, 
    { 0x001FD6, 0x001A, 0x0375 }, 
    { 0x001FF2, 0x000C, 0x038F }, 
    { 0x002000, 0x0002, 0x039B }, 
    { 0x002126, 0x0001, 0x039D }, 
    { 0x00212A, 0x0002, 0x039E }, 
    { 0x00219A, 0x0002, 0x03A0 }, 
    { 0x0021AE, 0x0001, 0x03A2 }, 
    { 0x0021CD, 0x0003, 0x03A3 }, 
    { 0x002204, 0x0001, 0x03A6 }, 
    { 0x002209, 0x0001, 0x03A7 }, 
    { 0x00220C, 0x0001, 0x03A8 }, 
    { 0x002224, 0x0003, 0x03A9 }, 
    { 0x002241, 0x0001, 0x03AC }, 
    { 0x002244, 0x0001, 0x03AD }, 
    { 0x002247, 0x0003, 0x03AE }, 
    { 0x002260, 0x0003, 0x03B1 }, 
    { 0x00226D, 0x0005, 0x03B4 }, 
    { 0x002274, 0x0002, 0x03B9 }, 
    { 0x002278, 0x0002, 0x03BB }, 
    { 0x002280, 0x0002, 0x03BD }, 
    { 0x002284, 0x0002, 0x03BF }, 
    { 0x002288, 0x0002, 0x03C1 }, 
    { 0x0022AC, 0x0004, 0x03C3 }, 
    { 0x0022E0, 0x0004, 0x03C7 }, 
    { 0x0022EA, 0x0004, 0x03CB }, 
    { 0x002329, 0x0002, 0x03CF }, 
    { 0x002ADC, 0x0001, 0x03D1 }, 
    { 0x00304C, 0x0017, 0x03D2 }, 
    { 0x003065, 0x0005, 0x03E9 }, 
    { 0x003070, 0x000E, 0x03EE }, 
    { 0x003094, 0x0001, 0x03FC }, 
    { 0x00309E, 0x0001, 0x03FD }, 
    { 0x0030AC, 0x0017, 0x03FE }, 
    { 0x0030C5, 0x0005, 0x0415 }, 
    { 0x0030D0, 0x000E, 0x041A }, 
    { 0x0030F4, 0x0001, 0x0428 }, 
    { 0x0030F7, 0x0004, 0x0429 }, 
    { 0x0030FE, 0x0001, 0x042D }, 
    { 0x00F900, 0x016C, 0x4000 }, 
    { 0x00FA6C, 0x0001, 0xC000 }, 
    { 0x00FA6D, 0x0062, 0x416C }, 
    { 0x00FACF, 0x0009, 0xC001 }, 
    { 0x00FAD8, 0x0002, 0x41CE }, 
    { 0x00FB1D, 0x0003, 0x042E }, 
    { 0x00FB2A, 0x0025, 0x0431 }, 
    { 0x01109A, 0x0001, 0x8000 }, 
    { 0x01109C, 0x0001, 0x8001 }, 
    { 0x0110AB, 0x0001, 0x8002 }, 
    { 0x01112E, 0x0002, 0x8003 }, 
    { 0x01D15E, 0x0007, 0x8005 }, 
    { 0x01D1BB, 0x0006, 0x800C }, 
    { 0x02F800, 0x0003, 0x41D0 }, 
    { 0x02F803, 0x0001, 0xC00A }, 
    { 0x02F804, 0x0009, 0x41D3 }, 
    { 0x02F80D, 0x0010, 0xC00B }, 
    { 0x02F81D, 0x0017, 0x41DC }, 
    { 0x02F834, 0x0005, 0xC01B }, 
    { 0x02F839, 0x0020, 0x41F3 }, 
    { 0x02F859, 0x0001, 0xC020 }, 
    { 0x02F85A, 0x0006, 0x4213 }, 
    { 0x02F860, 0x0002, 0xC021 }, 
    { 0x02F862, 0x000A, 0x4219 }, 
    { 0x02F86C, 0x0006, 0xC023 }, 
    { 0x02F872, 0x0009, 0x4223 }, 
    { 0x02F87B, 0x0003, 0xC029 }, 
    { 0x02F87E, 0x000B, 0x422C }, 
    { 0x02F889, 0x0010, 0xC02C }, 
    { 0x02F899, 0x000B, 0x4237 }, 
    { 0x02F8A4, 0x0001, 0xC03C }, 
    { 0x02F8A5, 0x0013, 0x4242 }, 
    { 0x02F8B8, 0x0007, 0xC03D }, 
    { 0x02F8BF, 0x000B, 0x4255 }, 
    { 0x02F8CA, 0x0001, 0xC044 }, 
    { 0x02F8CB, 0x0012, 0x4260 }, 
    { 0x02F8DD, 0x0007, 0xC045 }, 
    { 0x02F8E4, 0x0008, 0x4272 }, 
    { 0x02F8EC, 0x0005, 0xC04C }, 
    { 0x02F8F1, 0x0006, 0x427A }, 
    { 0x02F8F7, 0x0005, 0xC051 }, 
    { 0x02F8FC, 0x000A, 0x4280 }, 
    { 0x02F906, 0x0001, 0xC056 }, 
    { 0x02F907, 0x0006, 0x428A }, 
    { 0x02F90D, 0x0005, 0xC057 }, 
    { 0x02F912, 0x0009, 0x4290 }, 
    { 0x02F91B, 0x000D, 0xC05C }, 
    { 0x02F928, 0x000D, 0x4299 }, 
    { 0x02F935, 0x0010, 0xC069 }, 
    { 0x02F945, 0x0008, 0x42A6 }, 
    { 0x02F94D, 0x0009, 0xC079 }, 
    { 0x02F956, 0x0006, 0x42AE }, 
    { 0x02F95C, 0x0010, 0xC082 }, 
    { 0x02F96C, 0x0006, 0x42B4 }, 
    { 0x02F972, 0x000F, 0xC092 }, 
    { 0x02F981, 0x0006, 0x42BA }, 
    { 0x02F987, 0x0004, 0xC0A1 }, 
    { 0x02F98B, 0x000C, 0x42C0 }, 
    { 0x02F997, 0x0001, 0xC0A5 }, 
    { 0x02F998, 0x000C, 0x42CC }, 
    { 0x02F9A4, 0x000E, 0xC0A6 }, 
    { 0x02F9B2, 0x0013, 0x42D8 }, 
    { 0x02F9C5, 0x0008, 0xC0B4 }, 
    { 0x02F9CD, 0x0006, 0x42EB }, 
    { 0x02F9D3, 0x0013, 0xC0BC }, 
    { 0x02F9E6, 0x0007, 0x42F1 }, 
    { 0x02F9ED, 0x0015, 0xC0CF }, 
    { 0x02FA02, 0x0007, 0x42F8 }, 
    { 0x02FA09, 0x0001, 0xC0E4 }, 
    { 0x02FA0A, 0x0006, 0x42FF }, 
    { 0x02FA10, 0x0005, 0xC0E5 }, 
    { 0x02FA15, 0x0008, 0x4305 }, 
    { 0x02FA1D, 0x0001, 0xC0EA }, 
};


const DecompositionDataType0
decompositionData0[] =
{
    /* ---- index: 0 ---- */
    { 0x0041, 0x0300 }, /* 0x00C0 LATIN CAPITAL LETTER A WITH GRAVE                                           */
    { 0x0041, 0x0301 }, /* 0x00C1 LATIN CAPITAL LETTER A WITH ACUTE                                           */
    { 0x0041, 0x0302 }, /* 0x00C2 LATIN CAPITAL LETTER A WITH CIRCUMFLEX                                      */
    { 0x0041, 0x0303 }, /* 0x00C3 LATIN CAPITAL LETTER A WITH TILDE                                           */
    { 0x0041, 0x0308 }, /* 0x00C4 LATIN CAPITAL LETTER A WITH DIAERESIS                                       */
    { 0x0041, 0x030A }, /* 0x00C5 LATIN CAPITAL LETTER A WITH RING ABOVE                                      */
    { 0x0000, 0x0000 }, /* 0x00C6 --- padding ---                                                             */
    { 0x0043, 0x0327 }, /* 0x00C7 LATIN CAPITAL LETTER C WITH CEDILLA                                         */
    { 0x0045, 0x0300 }, /* 0x00C8 LATIN CAPITAL LETTER E WITH GRAVE                                           */
    { 0x0045, 0x0301 }, /* 0x00C9 LATIN CAPITAL LETTER E WITH ACUTE                                           */
    { 0x0045, 0x0302 }, /* 0x00CA LATIN CAPITAL LETTER E WITH CIRCUMFLEX                                      */
    { 0x0045, 0x0308 }, /* 0x00CB LATIN CAPITAL LETTER E WITH DIAERESIS                                       */
    { 0x0049, 0x0300 }, /* 0x00CC LATIN CAPITAL LETTER I WITH GRAVE                                           */
    { 0x0049, 0x0301 }, /* 0x00CD LATIN CAPITAL LETTER I WITH ACUTE                                           */
    { 0x0049, 0x0302 }, /* 0x00CE LATIN CAPITAL LETTER I WITH CIRCUMFLEX                                      */
    { 0x0049, 0x0308 }, /* 0x00CF LATIN CAPITAL LETTER I WITH DIAERESIS                                       */
    { 0x0000, 0x0000 }, /* 0x00D0 --- padding ---                                                             */
    { 0x004E, 0x0303 }, /* 0x00D1 LATIN CAPITAL LETTER N WITH TILDE                                           */
    { 0x004F, 0x0300 }, /* 0x00D2 LATIN CAPITAL LETTER O WITH GRAVE                                           */
    { 0x004F, 0x0301 }, /* 0x00D3 LATIN CAPITAL LETTER O WITH ACUTE                                           */
    { 0x004F, 0x0302 }, /* 0x00D4 LATIN CAPITAL LETTER O WITH CIRCUMFLEX                                      */
    { 0x004F, 0x0303 }, /* 0x00D5 LATIN CAPITAL LETTER O WITH TILDE                                           */
    { 0x004F, 0x0308 }, /* 0x00D6 LATIN CAPITAL LETTER O WITH DIAERESIS                                       */
    /* ---- index: 23 ---- */
    { 0x0055, 0x0300 }, /* 0x00D9 LATIN CAPITAL LETTER U WITH GRAVE                                           */
    { 0x0055, 0x0301 }, /* 0x00DA LATIN CAPITAL LETTER U WITH ACUTE                                           */
    { 0x0055, 0x0302 }, /* 0x00DB LATIN CAPITAL LETTER U WITH CIRCUMFLEX                                      */
    { 0x0055, 0x0308 }, /* 0x00DC LATIN CAPITAL LETTER U WITH DIAERESIS                                       */
    { 0x0059, 0x0301 }, /* 0x00DD LATIN CAPITAL LETTER Y WITH ACUTE                                           */
    /* ---- index: 28 ---- */
    { 0x0061, 0x0300 }, /* 0x00E0 LATIN SMALL LETTER A WITH GRAVE                                             */
    { 0x0061, 0x0301 }, /* 0x00E1 LATIN SMALL LETTER A WITH ACUTE                                             */
    { 0x0061, 0x0302 }, /* 0x00E2 LATIN SMALL LETTER A WITH CIRCUMFLEX                                        */
    { 0x0061, 0x0303 }, /* 0x00E3 LATIN SMALL LETTER A WITH TILDE                                             */
    { 0x0061, 0x0308 }, /* 0x00E4 LATIN SMALL LETTER A WITH DIAERESIS                                         */
    { 0x0061, 0x030A }, /* 0x00E5 LATIN SMALL LETTER A WITH RING ABOVE                                        */
    { 0x0000, 0x0000 }, /* 0x00E6 --- padding ---                                                             */
    { 0x0063, 0x0327 }, /* 0x00E7 LATIN SMALL LETTER C WITH CEDILLA                                           */
    { 0x0065, 0x0300 }, /* 0x00E8 LATIN SMALL LETTER E WITH GRAVE                                             */
    { 0x0065, 0x0301 }, /* 0x00E9 LATIN SMALL LETTER E WITH ACUTE                                             */
    { 0x0065, 0x0302 }, /* 0x00EA LATIN SMALL LETTER E WITH CIRCUMFLEX                                        */
    { 0x0065, 0x0308 }, /* 0x00EB LATIN SMALL LETTER E WITH DIAERESIS                                         */
    { 0x0069, 0x0300 }, /* 0x00EC LATIN SMALL LETTER I WITH GRAVE                                             */
    { 0x0069, 0x0301 }, /* 0x00ED LATIN SMALL LETTER I WITH ACUTE                                             */
    { 0x0069, 0x0302 }, /* 0x00EE LATIN SMALL LETTER I WITH CIRCUMFLEX                                        */
    { 0x0069, 0x0308 }, /* 0x00EF LATIN SMALL LETTER I WITH DIAERESIS                                         */
    { 0x0000, 0x0000 }, /* 0x00F0 --- padding ---                                                             */
    { 0x006E, 0x0303 }, /* 0x00F1 LATIN SMALL LETTER N WITH TILDE                                             */
    { 0x006F, 0x0300 }, /* 0x00F2 LATIN SMALL LETTER O WITH GRAVE                                             */
    { 0x006F, 0x0301 }, /* 0x00F3 LATIN SMALL LETTER O WITH ACUTE                                             */
    { 0x006F, 0x0302 }, /* 0x00F4 LATIN SMALL LETTER O WITH CIRCUMFLEX                                        */
    { 0x006F, 0x0303 }, /* 0x00F5 LATIN SMALL LETTER O WITH TILDE                                             */
    { 0x006F, 0x0308 }, /* 0x00F6 LATIN SMALL LETTER O WITH DIAERESIS                                         */
    /* ---- index: 51 ---- */
    { 0x0075, 0x0300 }, /* 0x00F9 LATIN SMALL LETTER U WITH GRAVE                                             */
    { 0x0075, 0x0301 }, /* 0x00FA LATIN SMALL LETTER U WITH ACUTE                                             */
    { 0x0075, 0x0302 }, /* 0x00FB LATIN SMALL LETTER U WITH CIRCUMFLEX                                        */
    { 0x0075, 0x0308 }, /* 0x00FC LATIN SMALL LETTER U WITH DIAERESIS                                         */
    { 0x0079, 0x0301 }, /* 0x00FD LATIN SMALL LETTER Y WITH ACUTE                                             */
    { 0x0000, 0x0000 }, /* 0x00FE --- padding ---                                                             */
    { 0x0079, 0x0308 }, /* 0x00FF LATIN SMALL LETTER Y WITH DIAERESIS                                         */
    { 0x0041, 0x0304 }, /* 0x0100 LATIN CAPITAL LETTER A WITH MACRON                                          */
    { 0x0061, 0x0304 }, /* 0x0101 LATIN SMALL LETTER A WITH MACRON                                            */
    { 0x0041, 0x0306 }, /* 0x0102 LATIN CAPITAL LETTER A WITH BREVE                                           */
    { 0x0061, 0x0306 }, /* 0x0103 LATIN SMALL LETTER A WITH BREVE                                             */
    { 0x0041, 0x0328 }, /* 0x0104 LATIN CAPITAL LETTER A WITH OGONEK                                          */
    { 0x0061, 0x0328 }, /* 0x0105 LATIN SMALL LETTER A WITH OGONEK                                            */
    { 0x0043, 0x0301 }, /* 0x0106 LATIN CAPITAL LETTER C WITH ACUTE                                           */
    { 0x0063, 0x0301 }, /* 0x0107 LATIN SMALL LETTER C WITH ACUTE                                             */
    { 0x0043, 0x0302 }, /* 0x0108 LATIN CAPITAL LETTER C WITH CIRCUMFLEX                                      */
    { 0x0063, 0x0302 }, /* 0x0109 LATIN SMALL LETTER C WITH CIRCUMFLEX                                        */
    { 0x0043, 0x0307 }, /* 0x010A LATIN CAPITAL LETTER C WITH DOT ABOVE                                       */
    { 0x0063, 0x0307 }, /* 0x010B LATIN SMALL LETTER C WITH DOT ABOVE                                         */
    { 0x0043, 0x030C }, /* 0x010C LATIN CAPITAL LETTER C WITH CARON                                           */
    { 0x0063, 0x030C }, /* 0x010D LATIN SMALL LETTER C WITH CARON                                             */
    { 0x0044, 0x030C }, /* 0x010E LATIN CAPITAL LETTER D WITH CARON                                           */
    { 0x0064, 0x030C }, /* 0x010F LATIN SMALL LETTER D WITH CARON                                             */
    /* ---- index: 74 ---- */
    { 0x0045, 0x0304 }, /* 0x0112 LATIN CAPITAL LETTER E WITH MACRON                                          */
    { 0x0065, 0x0304 }, /* 0x0113 LATIN SMALL LETTER E WITH MACRON                                            */
    { 0x0045, 0x0306 }, /* 0x0114 LATIN CAPITAL LETTER E WITH BREVE                                           */
    { 0x0065, 0x0306 }, /* 0x0115 LATIN SMALL LETTER E WITH BREVE                                             */
    { 0x0045, 0x0307 }, /* 0x0116 LATIN CAPITAL LETTER E WITH DOT ABOVE                                       */
    { 0x0065, 0x0307 }, /* 0x0117 LATIN SMALL LETTER E WITH DOT ABOVE                                         */
    { 0x0045, 0x0328 }, /* 0x0118 LATIN CAPITAL LETTER E WITH OGONEK                                          */
    { 0x0065, 0x0328 }, /* 0x0119 LATIN SMALL LETTER E WITH OGONEK                                            */
    { 0x0045, 0x030C }, /* 0x011A LATIN CAPITAL LETTER E WITH CARON                                           */
    { 0x0065, 0x030C }, /* 0x011B LATIN SMALL LETTER E WITH CARON                                             */
    { 0x0047, 0x0302 }, /* 0x011C LATIN CAPITAL LETTER G WITH CIRCUMFLEX                                      */
    { 0x0067, 0x0302 }, /* 0x011D LATIN SMALL LETTER G WITH CIRCUMFLEX                                        */
    { 0x0047, 0x0306 }, /* 0x011E LATIN CAPITAL LETTER G WITH BREVE                                           */
    { 0x0067, 0x0306 }, /* 0x011F LATIN SMALL LETTER G WITH BREVE                                             */
    { 0x0047, 0x0307 }, /* 0x0120 LATIN CAPITAL LETTER G WITH DOT ABOVE                                       */
    { 0x0067, 0x0307 }, /* 0x0121 LATIN SMALL LETTER G WITH DOT ABOVE                                         */
    { 0x0047, 0x0327 }, /* 0x0122 LATIN CAPITAL LETTER G WITH CEDILLA                                         */
    { 0x0067, 0x0327 }, /* 0x0123 LATIN SMALL LETTER G WITH CEDILLA                                           */
    { 0x0048, 0x0302 }, /* 0x0124 LATIN CAPITAL LETTER H WITH CIRCUMFLEX                                      */
    { 0x0068, 0x0302 }, /* 0x0125 LATIN SMALL LETTER H WITH CIRCUMFLEX                                        */
    /* ---- index: 94 ---- */
    { 0x0049, 0x0303 }, /* 0x0128 LATIN CAPITAL LETTER I WITH TILDE                                           */
    { 0x0069, 0x0303 }, /* 0x0129 LATIN SMALL LETTER I WITH TILDE                                             */
    { 0x0049, 0x0304 }, /* 0x012A LATIN CAPITAL LETTER I WITH MACRON                                          */
    { 0x0069, 0x0304 }, /* 0x012B LATIN SMALL LETTER I WITH MACRON                                            */
    { 0x0049, 0x0306 }, /* 0x012C LATIN CAPITAL LETTER I WITH BREVE                                           */
    { 0x0069, 0x0306 }, /* 0x012D LATIN SMALL LETTER I WITH BREVE                                             */
    { 0x0049, 0x0328 }, /* 0x012E LATIN CAPITAL LETTER I WITH OGONEK                                          */
    { 0x0069, 0x0328 }, /* 0x012F LATIN SMALL LETTER I WITH OGONEK                                            */
    { 0x0049, 0x0307 }, /* 0x0130 LATIN CAPITAL LETTER I WITH DOT ABOVE                                       */
    /* ---- index: 103 ---- */
    { 0x004A, 0x0302 }, /* 0x0134 LATIN CAPITAL LETTER J WITH CIRCUMFLEX                                      */
    { 0x006A, 0x0302 }, /* 0x0135 LATIN SMALL LETTER J WITH CIRCUMFLEX                                        */
    { 0x004B, 0x0327 }, /* 0x0136 LATIN CAPITAL LETTER K WITH CEDILLA                                         */
    { 0x006B, 0x0327 }, /* 0x0137 LATIN SMALL LETTER K WITH CEDILLA                                           */
    { 0x0000, 0x0000 }, /* 0x0138 --- padding ---                                                             */
    { 0x004C, 0x0301 }, /* 0x0139 LATIN CAPITAL LETTER L WITH ACUTE                                           */
    { 0x006C, 0x0301 }, /* 0x013A LATIN SMALL LETTER L WITH ACUTE                                             */
    { 0x004C, 0x0327 }, /* 0x013B LATIN CAPITAL LETTER L WITH CEDILLA                                         */
    { 0x006C, 0x0327 }, /* 0x013C LATIN SMALL LETTER L WITH CEDILLA                                           */
    { 0x004C, 0x030C }, /* 0x013D LATIN CAPITAL LETTER L WITH CARON                                           */
    { 0x006C, 0x030C }, /* 0x013E LATIN SMALL LETTER L WITH CARON                                             */
    /* ---- index: 114 ---- */
    { 0x004E, 0x0301 }, /* 0x0143 LATIN CAPITAL LETTER N WITH ACUTE                                           */
    { 0x006E, 0x0301 }, /* 0x0144 LATIN SMALL LETTER N WITH ACUTE                                             */
    { 0x004E, 0x0327 }, /* 0x0145 LATIN CAPITAL LETTER N WITH CEDILLA                                         */
    { 0x006E, 0x0327 }, /* 0x0146 LATIN SMALL LETTER N WITH CEDILLA                                           */
    { 0x004E, 0x030C }, /* 0x0147 LATIN CAPITAL LETTER N WITH CARON                                           */
    { 0x006E, 0x030C }, /* 0x0148 LATIN SMALL LETTER N WITH CARON                                             */
    /* ---- index: 120 ---- */
    { 0x004F, 0x0304 }, /* 0x014C LATIN CAPITAL LETTER O WITH MACRON                                          */
    { 0x006F, 0x0304 }, /* 0x014D LATIN SMALL LETTER O WITH MACRON                                            */
    { 0x004F, 0x0306 }, /* 0x014E LATIN CAPITAL LETTER O WITH BREVE                                           */
    { 0x006F, 0x0306 }, /* 0x014F LATIN SMALL LETTER O WITH BREVE                                             */
    { 0x004F, 0x030B }, /* 0x0150 LATIN CAPITAL LETTER O WITH DOUBLE ACUTE                                    */
    { 0x006F, 0x030B }, /* 0x0151 LATIN SMALL LETTER O WITH DOUBLE ACUTE                                      */
    /* ---- index: 126 ---- */
    { 0x0052, 0x0301 }, /* 0x0154 LATIN CAPITAL LETTER R WITH ACUTE                                           */
    { 0x0072, 0x0301 }, /* 0x0155 LATIN SMALL LETTER R WITH ACUTE                                             */
    { 0x0052, 0x0327 }, /* 0x0156 LATIN CAPITAL LETTER R WITH CEDILLA                                         */
    { 0x0072, 0x0327 }, /* 0x0157 LATIN SMALL LETTER R WITH CEDILLA                                           */
    { 0x0052, 0x030C }, /* 0x0158 LATIN CAPITAL LETTER R WITH CARON                                           */
    { 0x0072, 0x030C }, /* 0x0159 LATIN SMALL LETTER R WITH CARON                                             */
    { 0x0053, 0x0301 }, /* 0x015A LATIN CAPITAL LETTER S WITH ACUTE                                           */
    { 0x0073, 0x0301 }, /* 0x015B LATIN SMALL LETTER S WITH ACUTE                                             */
    { 0x0053, 0x0302 }, /* 0x015C LATIN CAPITAL LETTER S WITH CIRCUMFLEX                                      */
    { 0x0073, 0x0302 }, /* 0x015D LATIN SMALL LETTER S WITH CIRCUMFLEX                                        */
    { 0x0053, 0x0327 }, /* 0x015E LATIN CAPITAL LETTER S WITH CEDILLA                                         */
    { 0x0073, 0x0327 }, /* 0x015F LATIN SMALL LETTER S WITH CEDILLA                                           */
    { 0x0053, 0x030C }, /* 0x0160 LATIN CAPITAL LETTER S WITH CARON                                           */
    { 0x0073, 0x030C }, /* 0x0161 LATIN SMALL LETTER S WITH CARON                                             */
    { 0x0054, 0x0327 }, /* 0x0162 LATIN CAPITAL LETTER T WITH CEDILLA                                         */
    { 0x0074, 0x0327 }, /* 0x0163 LATIN SMALL LETTER T WITH CEDILLA                                           */
    { 0x0054, 0x030C }, /* 0x0164 LATIN CAPITAL LETTER T WITH CARON                                           */
    { 0x0074, 0x030C }, /* 0x0165 LATIN SMALL LETTER T WITH CARON                                             */
    /* ---- index: 144 ---- */
    { 0x0055, 0x0303 }, /* 0x0168 LATIN CAPITAL LETTER U WITH TILDE                                           */
    { 0x0075, 0x0303 }, /* 0x0169 LATIN SMALL LETTER U WITH TILDE                                             */
    { 0x0055, 0x0304 }, /* 0x016A LATIN CAPITAL LETTER U WITH MACRON                                          */
    { 0x0075, 0x0304 }, /* 0x016B LATIN SMALL LETTER U WITH MACRON                                            */
    { 0x0055, 0x0306 }, /* 0x016C LATIN CAPITAL LETTER U WITH BREVE                                           */
    { 0x0075, 0x0306 }, /* 0x016D LATIN SMALL LETTER U WITH BREVE                                             */
    { 0x0055, 0x030A }, /* 0x016E LATIN CAPITAL LETTER U WITH RING ABOVE                                      */
    { 0x0075, 0x030A }, /* 0x016F LATIN SMALL LETTER U WITH RING ABOVE                                        */
    { 0x0055, 0x030B }, /* 0x0170 LATIN CAPITAL LETTER U WITH DOUBLE ACUTE                                    */
    { 0x0075, 0x030B }, /* 0x0171 LATIN SMALL LETTER U WITH DOUBLE ACUTE                                      */
    { 0x0055, 0x0328 }, /* 0x0172 LATIN CAPITAL LETTER U WITH OGONEK                                          */
    { 0x0075, 0x0328 }, /* 0x0173 LATIN SMALL LETTER U WITH OGONEK                                            */
    { 0x0057, 0x0302 }, /* 0x0174 LATIN CAPITAL LETTER W WITH CIRCUMFLEX                                      */
    { 0x0077, 0x0302 }, /* 0x0175 LATIN SMALL LETTER W WITH CIRCUMFLEX                                        */
    { 0x0059, 0x0302 }, /* 0x0176 LATIN CAPITAL LETTER Y WITH CIRCUMFLEX                                      */
    { 0x0079, 0x0302 }, /* 0x0177 LATIN SMALL LETTER Y WITH CIRCUMFLEX                                        */
    { 0x0059, 0x0308 }, /* 0x0178 LATIN CAPITAL LETTER Y WITH DIAERESIS                                       */
    { 0x005A, 0x0301 }, /* 0x0179 LATIN CAPITAL LETTER Z WITH ACUTE                                           */
    { 0x007A, 0x0301 }, /* 0x017A LATIN SMALL LETTER Z WITH ACUTE                                             */
    { 0x005A, 0x0307 }, /* 0x017B LATIN CAPITAL LETTER Z WITH DOT ABOVE                                       */
    { 0x007A, 0x0307 }, /* 0x017C LATIN SMALL LETTER Z WITH DOT ABOVE                                         */
    { 0x005A, 0x030C }, /* 0x017D LATIN CAPITAL LETTER Z WITH CARON                                           */
    { 0x007A, 0x030C }, /* 0x017E LATIN SMALL LETTER Z WITH CARON                                             */
    /* ---- index: 167 ---- */
    { 0x004F, 0x031B }, /* 0x01A0 LATIN CAPITAL LETTER O WITH HORN                                            */
    { 0x006F, 0x031B }, /* 0x01A1 LATIN SMALL LETTER O WITH HORN                                              */
    /* ---- index: 169 ---- */
    { 0x0055, 0x031B }, /* 0x01AF LATIN CAPITAL LETTER U WITH HORN                                            */
    { 0x0075, 0x031B }, /* 0x01B0 LATIN SMALL LETTER U WITH HORN                                              */
    /* ---- index: 171 ---- */
    { 0x0041, 0x030C }, /* 0x01CD LATIN CAPITAL LETTER A WITH CARON                                           */
    { 0x0061, 0x030C }, /* 0x01CE LATIN SMALL LETTER A WITH CARON                                             */
    { 0x0049, 0x030C }, /* 0x01CF LATIN CAPITAL LETTER I WITH CARON                                           */
    { 0x0069, 0x030C }, /* 0x01D0 LATIN SMALL LETTER I WITH CARON                                             */
    { 0x004F, 0x030C }, /* 0x01D1 LATIN CAPITAL LETTER O WITH CARON                                           */
    { 0x006F, 0x030C }, /* 0x01D2 LATIN SMALL LETTER O WITH CARON                                             */
    { 0x0055, 0x030C }, /* 0x01D3 LATIN CAPITAL LETTER U WITH CARON                                           */
    { 0x0075, 0x030C }, /* 0x01D4 LATIN SMALL LETTER U WITH CARON                                             */
    { 0x00DC, 0x0304 }, /* 0x01D5 LATIN CAPITAL LETTER U WITH DIAERESIS AND MACRON                            */
    { 0x00FC, 0x0304 }, /* 0x01D6 LATIN SMALL LETTER U WITH DIAERESIS AND MACRON                              */
    { 0x00DC, 0x0301 }, /* 0x01D7 LATIN CAPITAL LETTER U WITH DIAERESIS AND ACUTE                             */
    { 0x00FC, 0x0301 }, /* 0x01D8 LATIN SMALL LETTER U WITH DIAERESIS AND ACUTE                               */
    { 0x00DC, 0x030C }, /* 0x01D9 LATIN CAPITAL LETTER U WITH DIAERESIS AND CARON                             */
    { 0x00FC, 0x030C }, /* 0x01DA LATIN SMALL LETTER U WITH DIAERESIS AND CARON                               */
    { 0x00DC, 0x0300 }, /* 0x01DB LATIN CAPITAL LETTER U WITH DIAERESIS AND GRAVE                             */
    { 0x00FC, 0x0300 }, /* 0x01DC LATIN SMALL LETTER U WITH DIAERESIS AND GRAVE                               */
    { 0x0000, 0x0000 }, /* 0x01DD --- padding ---                                                             */
    { 0x00C4, 0x0304 }, /* 0x01DE LATIN CAPITAL LETTER A WITH DIAERESIS AND MACRON                            */
    { 0x00E4, 0x0304 }, /* 0x01DF LATIN SMALL LETTER A WITH DIAERESIS AND MACRON                              */
    { 0x0226, 0x0304 }, /* 0x01E0 LATIN CAPITAL LETTER A WITH DOT ABOVE AND MACRON                            */
    { 0x0227, 0x0304 }, /* 0x01E1 LATIN SMALL LETTER A WITH DOT ABOVE AND MACRON                              */
    { 0x00C6, 0x0304 }, /* 0x01E2 LATIN CAPITAL LETTER AE WITH MACRON                                         */
    { 0x00E6, 0x0304 }, /* 0x01E3 LATIN SMALL LETTER AE WITH MACRON                                           */
    /* ---- index: 194 ---- */
    { 0x0047, 0x030C }, /* 0x01E6 LATIN CAPITAL LETTER G WITH CARON                                           */
    { 0x0067, 0x030C }, /* 0x01E7 LATIN SMALL LETTER G WITH CARON                                             */
    { 0x004B, 0x030C }, /* 0x01E8 LATIN CAPITAL LETTER K WITH CARON                                           */
    { 0x006B, 0x030C }, /* 0x01E9 LATIN SMALL LETTER K WITH CARON                                             */
    { 0x004F, 0x0328 }, /* 0x01EA LATIN CAPITAL LETTER O WITH OGONEK                                          */
    { 0x006F, 0x0328 }, /* 0x01EB LATIN SMALL LETTER O WITH OGONEK                                            */
    { 0x01EA, 0x0304 }, /* 0x01EC LATIN CAPITAL LETTER O WITH OGONEK AND MACRON                               */
    { 0x01EB, 0x0304 }, /* 0x01ED LATIN SMALL LETTER O WITH OGONEK AND MACRON                                 */
    { 0x01B7, 0x030C }, /* 0x01EE LATIN CAPITAL LETTER EZH WITH CARON                                         */
    { 0x0292, 0x030C }, /* 0x01EF LATIN SMALL LETTER EZH WITH CARON                                           */
    { 0x006A, 0x030C }, /* 0x01F0 LATIN SMALL LETTER J WITH CARON                                             */
    /* ---- index: 205 ---- */
    { 0x0047, 0x0301 }, /* 0x01F4 LATIN CAPITAL LETTER G WITH ACUTE                                           */
    { 0x0067, 0x0301 }, /* 0x01F5 LATIN SMALL LETTER G WITH ACUTE                                             */
    /* ---- index: 207 ---- */
    { 0x004E, 0x0300 }, /* 0x01F8 LATIN CAPITAL LETTER N WITH GRAVE                                           */
    { 0x006E, 0x0300 }, /* 0x01F9 LATIN SMALL LETTER N WITH GRAVE                                             */
    { 0x00C5, 0x0301 }, /* 0x01FA LATIN CAPITAL LETTER A WITH RING ABOVE AND ACUTE                            */
    { 0x00E5, 0x0301 }, /* 0x01FB LATIN SMALL LETTER A WITH RING ABOVE AND ACUTE                              */
    { 0x00C6, 0x0301 }, /* 0x01FC LATIN CAPITAL LETTER AE WITH ACUTE                                          */
    { 0x00E6, 0x0301 }, /* 0x01FD LATIN SMALL LETTER AE WITH ACUTE                                            */
    { 0x00D8, 0x0301 }, /* 0x01FE LATIN CAPITAL LETTER O WITH STROKE AND ACUTE                                */
    { 0x00F8, 0x0301 }, /* 0x01FF LATIN SMALL LETTER O WITH STROKE AND ACUTE                                  */
    { 0x0041, 0x030F }, /* 0x0200 LATIN CAPITAL LETTER A WITH DOUBLE GRAVE                                    */
    { 0x0061, 0x030F }, /* 0x0201 LATIN SMALL LETTER A WITH DOUBLE GRAVE                                      */
    { 0x0041, 0x0311 }, /* 0x0202 LATIN CAPITAL LETTER A WITH INVERTED BREVE                                  */
    { 0x0061, 0x0311 }, /* 0x0203 LATIN SMALL LETTER A WITH INVERTED BREVE                                    */
    { 0x0045, 0x030F }, /* 0x0204 LATIN CAPITAL LETTER E WITH DOUBLE GRAVE                                    */
    { 0x0065, 0x030F }, /* 0x0205 LATIN SMALL LETTER E WITH DOUBLE GRAVE                                      */
    { 0x0045, 0x0311 }, /* 0x0206 LATIN CAPITAL LETTER E WITH INVERTED BREVE                                  */
    { 0x0065, 0x0311 }, /* 0x0207 LATIN SMALL LETTER E WITH INVERTED BREVE                                    */
    { 0x0049, 0x030F }, /* 0x0208 LATIN CAPITAL LETTER I WITH DOUBLE GRAVE                                    */
    { 0x0069, 0x030F }, /* 0x0209 LATIN SMALL LETTER I WITH DOUBLE GRAVE                                      */
    { 0x0049, 0x0311 }, /* 0x020A LATIN CAPITAL LETTER I WITH INVERTED BREVE                                  */
    { 0x0069, 0x0311 }, /* 0x020B LATIN SMALL LETTER I WITH INVERTED BREVE                                    */
    { 0x004F, 0x030F }, /* 0x020C LATIN CAPITAL LETTER O WITH DOUBLE GRAVE                                    */
    { 0x006F, 0x030F }, /* 0x020D LATIN SMALL LETTER O WITH DOUBLE GRAVE                                      */
    { 0x004F, 0x0311 }, /* 0x020E LATIN CAPITAL LETTER O WITH INVERTED BREVE                                  */
    { 0x006F, 0x0311 }, /* 0x020F LATIN SMALL LETTER O WITH INVERTED BREVE                                    */
    { 0x0052, 0x030F }, /* 0x0210 LATIN CAPITAL LETTER R WITH DOUBLE GRAVE                                    */
    { 0x0072, 0x030F }, /* 0x0211 LATIN SMALL LETTER R WITH DOUBLE GRAVE                                      */
    { 0x0052, 0x0311 }, /* 0x0212 LATIN CAPITAL LETTER R WITH INVERTED BREVE                                  */
    { 0x0072, 0x0311 }, /* 0x0213 LATIN SMALL LETTER R WITH INVERTED BREVE                                    */
    { 0x0055, 0x030F }, /* 0x0214 LATIN CAPITAL LETTER U WITH DOUBLE GRAVE                                    */
    { 0x0075, 0x030F }, /* 0x0215 LATIN SMALL LETTER U WITH DOUBLE GRAVE                                      */
    { 0x0055, 0x0311 }, /* 0x0216 LATIN CAPITAL LETTER U WITH INVERTED BREVE                                  */
    { 0x0075, 0x0311 }, /* 0x0217 LATIN SMALL LETTER U WITH INVERTED BREVE                                    */
    { 0x0053, 0x0326 }, /* 0x0218 LATIN CAPITAL LETTER S WITH COMMA BELOW                                     */
    { 0x0073, 0x0326 }, /* 0x0219 LATIN SMALL LETTER S WITH COMMA BELOW                                       */
    { 0x0054, 0x0326 }, /* 0x021A LATIN CAPITAL LETTER T WITH COMMA BELOW                                     */
    { 0x0074, 0x0326 }, /* 0x021B LATIN SMALL LETTER T WITH COMMA BELOW                                       */
    /* ---- index: 243 ---- */
    { 0x0048, 0x030C }, /* 0x021E LATIN CAPITAL LETTER H WITH CARON                                           */
    { 0x0068, 0x030C }, /* 0x021F LATIN SMALL LETTER H WITH CARON                                             */
    /* ---- index: 245 ---- */
    { 0x0041, 0x0307 }, /* 0x0226 LATIN CAPITAL LETTER A WITH DOT ABOVE                                       */
    { 0x0061, 0x0307 }, /* 0x0227 LATIN SMALL LETTER A WITH DOT ABOVE                                         */
    { 0x0045, 0x0327 }, /* 0x0228 LATIN CAPITAL LETTER E WITH CEDILLA                                         */
    { 0x0065, 0x0327 }, /* 0x0229 LATIN SMALL LETTER E WITH CEDILLA                                           */
    { 0x00D6, 0x0304 }, /* 0x022A LATIN CAPITAL LETTER O WITH DIAERESIS AND MACRON                            */
    { 0x00F6, 0x0304 }, /* 0x022B LATIN SMALL LETTER O WITH DIAERESIS AND MACRON                              */
    { 0x00D5, 0x0304 }, /* 0x022C LATIN CAPITAL LETTER O WITH TILDE AND MACRON                                */
    { 0x00F5, 0x0304 }, /* 0x022D LATIN SMALL LETTER O WITH TILDE AND MACRON                                  */
    { 0x004F, 0x0307 }, /* 0x022E LATIN CAPITAL LETTER O WITH DOT ABOVE                                       */
    { 0x006F, 0x0307 }, /* 0x022F LATIN SMALL LETTER O WITH DOT ABOVE                                         */
    { 0x022E, 0x0304 }, /* 0x0230 LATIN CAPITAL LETTER O WITH DOT ABOVE AND MACRON                            */
    { 0x022F, 0x0304 }, /* 0x0231 LATIN SMALL LETTER O WITH DOT ABOVE AND MACRON                              */
    { 0x0059, 0x0304 }, /* 0x0232 LATIN CAPITAL LETTER Y WITH MACRON                                          */
    { 0x0079, 0x0304 }, /* 0x0233 LATIN SMALL LETTER Y WITH MACRON                                            */
    /* ---- index: 259 ---- */
    { 0x0300, 0x0000 }, /* 0x0340 COMBINING GRAVE TONE MARK                                                   */
    { 0x0301, 0x0000 }, /* 0x0341 COMBINING ACUTE TONE MARK                                                   */
    { 0x0000, 0x0000 }, /* 0x0342 --- padding ---                                                             */
    { 0x0313, 0x0000 }, /* 0x0343 COMBINING GREEK KORONIS                                                     */
    { 0x0308, 0x0301 }, /* 0x0344 COMBINING GREEK DIALYTIKA TONOS                                             */
    /* ---- index: 264 ---- */
    { 0x02B9, 0x0000 }, /* 0x0374 GREEK NUMERAL SIGN                                                          */
    /* ---- index: 265 ---- */
    { 0x003B, 0x0000 }, /* 0x037E GREEK QUESTION MARK                                                         */
    /* ---- index: 266 ---- */
    { 0x00A8, 0x0301 }, /* 0x0385 GREEK DIALYTIKA TONOS                                                       */
    { 0x0391, 0x0301 }, /* 0x0386 GREEK CAPITAL LETTER ALPHA WITH TONOS                                       */
    { 0x00B7, 0x0000 }, /* 0x0387 GREEK ANO TELEIA                                                            */
    { 0x0395, 0x0301 }, /* 0x0388 GREEK CAPITAL LETTER EPSILON WITH TONOS                                     */
    { 0x0397, 0x0301 }, /* 0x0389 GREEK CAPITAL LETTER ETA WITH TONOS                                         */
    { 0x0399, 0x0301 }, /* 0x038A GREEK CAPITAL LETTER IOTA WITH TONOS                                        */
    { 0x0000, 0x0000 }, /* 0x038B --- padding ---                                                             */
    { 0x039F, 0x0301 }, /* 0x038C GREEK CAPITAL LETTER OMICRON WITH TONOS                                     */
    { 0x0000, 0x0000 }, /* 0x038D --- padding ---                                                             */
    { 0x03A5, 0x0301 }, /* 0x038E GREEK CAPITAL LETTER UPSILON WITH TONOS                                     */
    { 0x03A9, 0x0301 }, /* 0x038F GREEK CAPITAL LETTER OMEGA WITH TONOS                                       */
    { 0x03CA, 0x0301 }, /* 0x0390 GREEK SMALL LETTER IOTA WITH DIALYTIKA AND TONOS                            */
    /* ---- index: 278 ---- */
    { 0x0399, 0x0308 }, /* 0x03AA GREEK CAPITAL LETTER IOTA WITH DIALYTIKA                                    */
    { 0x03A5, 0x0308 }, /* 0x03AB GREEK CAPITAL LETTER UPSILON WITH DIALYTIKA                                 */
    { 0x03B1, 0x0301 }, /* 0x03AC GREEK SMALL LETTER ALPHA WITH TONOS                                         */
    { 0x03B5, 0x0301 }, /* 0x03AD GREEK SMALL LETTER EPSILON WITH TONOS                                       */
    { 0x03B7, 0x0301 }, /* 0x03AE GREEK SMALL LETTER ETA WITH TONOS                                           */
    { 0x03B9, 0x0301 }, /* 0x03AF GREEK SMALL LETTER IOTA WITH TONOS                                          */
    { 0x03CB, 0x0301 }, /* 0x03B0 GREEK SMALL LETTER UPSILON WITH DIALYTIKA AND TONOS                         */
    /* ---- index: 285 ---- */
    { 0x03B9, 0x0308 }, /* 0x03CA GREEK SMALL LETTER IOTA WITH DIALYTIKA                                      */
    { 0x03C5, 0x0308 }, /* 0x03CB GREEK SMALL LETTER UPSILON WITH DIALYTIKA                                   */
    { 0x03BF, 0x0301 }, /* 0x03CC GREEK SMALL LETTER OMICRON WITH TONOS                                       */
    { 0x03C5, 0x0301 }, /* 0x03CD GREEK SMALL LETTER UPSILON WITH TONOS                                       */
    { 0x03C9, 0x0301 }, /* 0x03CE GREEK SMALL LETTER OMEGA WITH TONOS                                         */
    /* ---- index: 290 ---- */
    { 0x03D2, 0x0301 }, /* 0x03D3 GREEK UPSILON WITH ACUTE AND HOOK SYMBOL                                    */
    { 0x03D2, 0x0308 }, /* 0x03D4 GREEK UPSILON WITH DIAERESIS AND HOOK SYMBOL                                */
    /* ---- index: 292 ---- */
    { 0x0415, 0x0300 }, /* 0x0400 CYRILLIC CAPITAL LETTER IE WITH GRAVE                                       */
    { 0x0415, 0x0308 }, /* 0x0401 CYRILLIC CAPITAL LETTER IO                                                  */
    { 0x0000, 0x0000 }, /* 0x0402 --- padding ---                                                             */
    { 0x0413, 0x0301 }, /* 0x0403 CYRILLIC CAPITAL LETTER GJE                                                 */
    /* ---- index: 296 ---- */
    { 0x0406, 0x0308 }, /* 0x0407 CYRILLIC CAPITAL LETTER YI                                                  */
    /* ---- index: 297 ---- */
    { 0x041A, 0x0301 }, /* 0x040C CYRILLIC CAPITAL LETTER KJE                                                 */
    { 0x0418, 0x0300 }, /* 0x040D CYRILLIC CAPITAL LETTER I WITH GRAVE                                        */
    { 0x0423, 0x0306 }, /* 0x040E CYRILLIC CAPITAL LETTER SHORT U                                             */
    /* ---- index: 300 ---- */
    { 0x0418, 0x0306 }, /* 0x0419 CYRILLIC CAPITAL LETTER SHORT I                                             */
    /* ---- index: 301 ---- */
    { 0x0438, 0x0306 }, /* 0x0439 CYRILLIC SMALL LETTER SHORT I                                               */
    /* ---- index: 302 ---- */
    { 0x0435, 0x0300 }, /* 0x0450 CYRILLIC SMALL LETTER IE WITH GRAVE                                         */
    { 0x0435, 0x0308 }, /* 0x0451 CYRILLIC SMALL LETTER IO                                                    */
    { 0x0000, 0x0000 }, /* 0x0452 --- padding ---                                                             */
    { 0x0433, 0x0301 }, /* 0x0453 CYRILLIC SMALL LETTER GJE                                                   */
    /* ---- index: 306 ---- */
    { 0x0456, 0x0308 }, /* 0x0457 CYRILLIC SMALL LETTER YI                                                    */
    /* ---- index: 307 ---- */
    { 0x043A, 0x0301 }, /* 0x045C CYRILLIC SMALL LETTER KJE                                                   */
    { 0x0438, 0x0300 }, /* 0x045D CYRILLIC SMALL LETTER I WITH GRAVE                                          */
    { 0x0443, 0x0306 }, /* 0x045E CYRILLIC SMALL LETTER SHORT U                                               */
    /* ---- index: 310 ---- */
    { 0x0474, 0x030F }, /* 0x0476 CYRILLIC CAPITAL LETTER IZHITSA WITH DOUBLE GRAVE ACCENT                    */
    { 0x0475, 0x030F }, /* 0x0477 CYRILLIC SMALL LETTER IZHITSA WITH DOUBLE GRAVE ACCENT                      */
    /* ---- index: 312 ---- */
    { 0x0416, 0x0306 }, /* 0x04C1 CYRILLIC CAPITAL LETTER ZHE WITH BREVE                                      */
    { 0x0436, 0x0306 }, /* 0x04C2 CYRILLIC SMALL LETTER ZHE WITH BREVE                                        */
    /* ---- index: 314 ---- */
    { 0x0410, 0x0306 }, /* 0x04D0 CYRILLIC CAPITAL LETTER A WITH BREVE                                        */
    { 0x0430, 0x0306 }, /* 0x04D1 CYRILLIC SMALL LETTER A WITH BREVE                                          */
    { 0x0410, 0x0308 }, /* 0x04D2 CYRILLIC CAPITAL LETTER A WITH DIAERESIS                                    */
    { 0x0430, 0x0308 }, /* 0x04D3 CYRILLIC SMALL LETTER A WITH DIAERESIS                                      */
    /* ---- index: 318 ---- */
    { 0x0415, 0x0306 }, /* 0x04D6 CYRILLIC CAPITAL LETTER IE WITH BREVE                                       */
    { 0x0435, 0x0306 }, /* 0x04D7 CYRILLIC SMALL LETTER IE WITH BREVE                                         */
    /* ---- index: 320 ---- */
    { 0x04D8, 0x0308 }, /* 0x04DA CYRILLIC CAPITAL LETTER SCHWA WITH DIAERESIS                                */
    { 0x04D9, 0x0308 }, /* 0x04DB CYRILLIC SMALL LETTER SCHWA WITH DIAERESIS                                  */
    { 0x0416, 0x0308 }, /* 0x04DC CYRILLIC CAPITAL LETTER ZHE WITH DIAERESIS                                  */
    { 0x0436, 0x0308 }, /* 0x04DD CYRILLIC SMALL LETTER ZHE WITH DIAERESIS                                    */
    { 0x0417, 0x0308 }, /* 0x04DE CYRILLIC CAPITAL LETTER ZE WITH DIAERESIS                                   */
    { 0x0437, 0x0308 }, /* 0x04DF CYRILLIC SMALL LETTER ZE WITH DIAERESIS                                     */
    /* ---- index: 326 ---- */
    { 0x0418, 0x0304 }, /* 0x04E2 CYRILLIC CAPITAL LETTER I WITH MACRON                                       */
    { 0x0438, 0x0304 }, /* 0x04E3 CYRILLIC SMALL LETTER I WITH MACRON                                         */
    { 0x0418, 0x0308 }, /* 0x04E4 CYRILLIC CAPITAL LETTER I WITH DIAERESIS                                    */
    { 0x0438, 0x0308 }, /* 0x04E5 CYRILLIC SMALL LETTER I WITH DIAERESIS                                      */
    { 0x041E, 0x0308 }, /* 0x04E6 CYRILLIC CAPITAL LETTER O WITH DIAERESIS                                    */
    { 0x043E, 0x0308 }, /* 0x04E7 CYRILLIC SMALL LETTER O WITH DIAERESIS                                      */
    /* ---- index: 332 ---- */
    { 0x04E8, 0x0308 }, /* 0x04EA CYRILLIC CAPITAL LETTER BARRED O WITH DIAERESIS                             */
    { 0x04E9, 0x0308 }, /* 0x04EB CYRILLIC SMALL LETTER BARRED O WITH DIAERESIS                               */
    { 0x042D, 0x0308 }, /* 0x04EC CYRILLIC CAPITAL LETTER E WITH DIAERESIS                                    */
    { 0x044D, 0x0308 }, /* 0x04ED CYRILLIC SMALL LETTER E WITH DIAERESIS                                      */
    { 0x0423, 0x0304 }, /* 0x04EE CYRILLIC CAPITAL LETTER U WITH MACRON                                       */
    { 0x0443, 0x0304 }, /* 0x04EF CYRILLIC SMALL LETTER U WITH MACRON                                         */
    { 0x0423, 0x0308 }, /* 0x04F0 CYRILLIC CAPITAL LETTER U WITH DIAERESIS                                    */
    { 0x0443, 0x0308 }, /* 0x04F1 CYRILLIC SMALL LETTER U WITH DIAERESIS                                      */
    { 0x0423, 0x030B }, /* 0x04F2 CYRILLIC CAPITAL LETTER U WITH DOUBLE ACUTE                                 */
    { 0x0443, 0x030B }, /* 0x04F3 CYRILLIC SMALL LETTER U WITH DOUBLE ACUTE                                   */
    { 0x0427, 0x0308 }, /* 0x04F4 CYRILLIC CAPITAL LETTER CHE WITH DIAERESIS                                  */
    { 0x0447, 0x0308 }, /* 0x04F5 CYRILLIC SMALL LETTER CHE WITH DIAERESIS                                    */
    /* ---- index: 344 ---- */
    { 0x042B, 0x0308 }, /* 0x04F8 CYRILLIC CAPITAL LETTER YERU WITH DIAERESIS                                 */
    { 0x044B, 0x0308 }, /* 0x04F9 CYRILLIC SMALL LETTER YERU WITH DIAERESIS                                   */
    /* ---- index: 346 ---- */
    { 0x0627, 0x0653 }, /* 0x0622 ARABIC LETTER ALEF WITH MADDA ABOVE                                         */
    { 0x0627, 0x0654 }, /* 0x0623 ARABIC LETTER ALEF WITH HAMZA ABOVE                                         */
    { 0x0648, 0x0654 }, /* 0x0624 ARABIC LETTER WAW WITH HAMZA ABOVE                                          */
    { 0x0627, 0x0655 }, /* 0x0625 ARABIC LETTER ALEF WITH HAMZA BELOW                                         */
    { 0x064A, 0x0654 }, /* 0x0626 ARABIC LETTER YEH WITH HAMZA ABOVE                                          */
    /* ---- index: 351 ---- */
    { 0x06D5, 0x0654 }, /* 0x06C0 ARABIC LETTER HEH WITH YEH ABOVE                                            */
    { 0x0000, 0x0000 }, /* 0x06C1 --- padding ---                                                             */
    { 0x06C1, 0x0654 }, /* 0x06C2 ARABIC LETTER HEH GOAL WITH HAMZA ABOVE                                     */
    /* ---- index: 354 ---- */
    { 0x06D2, 0x0654 }, /* 0x06D3 ARABIC LETTER YEH BARREE WITH HAMZA ABOVE                                   */
    /* ---- index: 355 ---- */
    { 0x0928, 0x093C }, /* 0x0929 DEVANAGARI LETTER NNNA                                                      */
    /* ---- index: 356 ---- */
    { 0x0930, 0x093C }, /* 0x0931 DEVANAGARI LETTER RRA                                                       */
    /* ---- index: 357 ---- */
    { 0x0933, 0x093C }, /* 0x0934 DEVANAGARI LETTER LLLA                                                      */
    /* ---- index: 358 ---- */
    { 0x0915, 0x093C }, /* 0x0958 DEVANAGARI LETTER QA                                                        */
    { 0x0916, 0x093C }, /* 0x0959 DEVANAGARI LETTER KHHA                                                      */
    { 0x0917, 0x093C }, /* 0x095A DEVANAGARI LETTER GHHA                                                      */
    { 0x091C, 0x093C }, /* 0x095B DEVANAGARI LETTER ZA                                                        */
    { 0x0921, 0x093C }, /* 0x095C DEVANAGARI LETTER DDDHA                                                     */
    { 0x0922, 0x093C }, /* 0x095D DEVANAGARI LETTER RHA                                                       */
    { 0x092B, 0x093C }, /* 0x095E DEVANAGARI LETTER FA                                                        */
    { 0x092F, 0x093C }, /* 0x095F DEVANAGARI LETTER YYA                                                       */
    /* ---- index: 366 ---- */
    { 0x09C7, 0x09BE }, /* 0x09CB BENGALI VOWEL SIGN O                                                        */
    { 0x09C7, 0x09D7 }, /* 0x09CC BENGALI VOWEL SIGN AU                                                       */
    /* ---- index: 368 ---- */
    { 0x09A1, 0x09BC }, /* 0x09DC BENGALI LETTER RRA                                                          */
    { 0x09A2, 0x09BC }, /* 0x09DD BENGALI LETTER RHA                                                          */
    { 0x0000, 0x0000 }, /* 0x09DE --- padding ---                                                             */
    { 0x09AF, 0x09BC }, /* 0x09DF BENGALI LETTER YYA                                                          */
    /* ---- index: 372 ---- */
    { 0x0A32, 0x0A3C }, /* 0x0A33 GURMUKHI LETTER LLA                                                         */
    /* ---- index: 373 ---- */
    { 0x0A38, 0x0A3C }, /* 0x0A36 GURMUKHI LETTER SHA                                                         */
    /* ---- index: 374 ---- */
    { 0x0A16, 0x0A3C }, /* 0x0A59 GURMUKHI LETTER KHHA                                                        */
    { 0x0A17, 0x0A3C }, /* 0x0A5A GURMUKHI LETTER GHHA                                                        */
    { 0x0A1C, 0x0A3C }, /* 0x0A5B GURMUKHI LETTER ZA                                                          */
    /* ---- index: 377 ---- */
    { 0x0A2B, 0x0A3C }, /* 0x0A5E GURMUKHI LETTER FA                                                          */
    /* ---- index: 378 ---- */
    { 0x0B47, 0x0B56 }, /* 0x0B48 ORIYA VOWEL SIGN AI                                                         */
    /* ---- index: 379 ---- */
    { 0x0B47, 0x0B3E }, /* 0x0B4B ORIYA VOWEL SIGN O                                                          */
    { 0x0B47, 0x0B57 }, /* 0x0B4C ORIYA VOWEL SIGN AU                                                         */
    /* ---- index: 381 ---- */
    { 0x0B21, 0x0B3C }, /* 0x0B5C ORIYA LETTER RRA                                                            */
    { 0x0B22, 0x0B3C }, /* 0x0B5D ORIYA LETTER RHA                                                            */
    /* ---- index: 383 ---- */
    { 0x0B92, 0x0BD7 }, /* 0x0B94 TAMIL LETTER AU                                                             */
    /* ---- index: 384 ---- */
    { 0x0BC6, 0x0BBE }, /* 0x0BCA TAMIL VOWEL SIGN O                                                          */
    { 0x0BC7, 0x0BBE }, /* 0x0BCB TAMIL VOWEL SIGN OO                                                         */
    { 0x0BC6, 0x0BD7 }, /* 0x0BCC TAMIL VOWEL SIGN AU                                                         */
    /* ---- index: 387 ---- */
    { 0x0C46, 0x0C56 }, /* 0x0C48 TELUGU VOWEL SIGN AI                                                        */
    /* ---- index: 388 ---- */
    { 0x0CBF, 0x0CD5 }, /* 0x0CC0 KANNADA VOWEL SIGN II                                                       */
    /* ---- index: 389 ---- */
    { 0x0CC6, 0x0CD5 }, /* 0x0CC7 KANNADA VOWEL SIGN EE                                                       */
    { 0x0CC6, 0x0CD6 }, /* 0x0CC8 KANNADA VOWEL SIGN AI                                                       */
    { 0x0000, 0x0000 }, /* 0x0CC9 --- padding ---                                                             */
    { 0x0CC6, 0x0CC2 }, /* 0x0CCA KANNADA VOWEL SIGN O                                                        */
    { 0x0CCA, 0x0CD5 }, /* 0x0CCB KANNADA VOWEL SIGN OO                                                       */
    /* ---- index: 394 ---- */
    { 0x0D46, 0x0D3E }, /* 0x0D4A MALAYALAM VOWEL SIGN O                                                      */
    { 0x0D47, 0x0D3E }, /* 0x0D4B MALAYALAM VOWEL SIGN OO                                                     */
    { 0x0D46, 0x0D57 }, /* 0x0D4C MALAYALAM VOWEL SIGN AU                                                     */
    /* ---- index: 397 ---- */
    { 0x0DD9, 0x0DCA }, /* 0x0DDA SINHALA VOWEL SIGN DIGA KOMBUVA                                             */
    { 0x0000, 0x0000 }, /* 0x0DDB --- padding ---                                                             */
    { 0x0DD9, 0x0DCF }, /* 0x0DDC SINHALA VOWEL SIGN KOMBUVA HAA AELA-PILLA                                   */
    { 0x0DDC, 0x0DCA }, /* 0x0DDD SINHALA VOWEL SIGN KOMBUVA HAA DIGA AELA-PILLA                              */
    { 0x0DD9, 0x0DDF }, /* 0x0DDE SINHALA VOWEL SIGN KOMBUVA HAA GAYANUKITTA                                  */
    /* ---- index: 402 ---- */
    { 0x0F42, 0x0FB7 }, /* 0x0F43 TIBETAN LETTER GHA                                                          */
    /* ---- index: 403 ---- */
    { 0x0F4C, 0x0FB7 }, /* 0x0F4D TIBETAN LETTER DDHA                                                         */
    /* ---- index: 404 ---- */
    { 0x0F51, 0x0FB7 }, /* 0x0F52 TIBETAN LETTER DHA                                                          */
    /* ---- index: 405 ---- */
    { 0x0F56, 0x0FB7 }, /* 0x0F57 TIBETAN LETTER BHA                                                          */
    /* ---- index: 406 ---- */
    { 0x0F5B, 0x0FB7 }, /* 0x0F5C TIBETAN LETTER DZHA                                                         */
    /* ---- index: 407 ---- */
    { 0x0F40, 0x0FB5 }, /* 0x0F69 TIBETAN LETTER KSSA                                                         */
    /* ---- index: 408 ---- */
    { 0x0F71, 0x0F72 }, /* 0x0F73 TIBETAN VOWEL SIGN II                                                       */
    { 0x0000, 0x0000 }, /* 0x0F74 --- padding ---                                                             */
    { 0x0F71, 0x0F74 }, /* 0x0F75 TIBETAN VOWEL SIGN UU                                                       */
    { 0x0FB2, 0x0F80 }, /* 0x0F76 TIBETAN VOWEL SIGN VOCALIC R                                                */
    { 0x0000, 0x0000 }, /* 0x0F77 --- padding ---                                                             */
    { 0x0FB3, 0x0F80 }, /* 0x0F78 TIBETAN VOWEL SIGN VOCALIC L                                                */
    /* ---- index: 414 ---- */
    { 0x0F71, 0x0F80 }, /* 0x0F81 TIBETAN VOWEL SIGN REVERSED II                                              */
    /* ---- index: 415 ---- */
    { 0x0F92, 0x0FB7 }, /* 0x0F93 TIBETAN SUBJOINED LETTER GHA                                                */
    /* ---- index: 416 ---- */
    { 0x0F9C, 0x0FB7 }, /* 0x0F9D TIBETAN SUBJOINED LETTER DDHA                                               */
    /* ---- index: 417 ---- */
    { 0x0FA1, 0x0FB7 }, /* 0x0FA2 TIBETAN SUBJOINED LETTER DHA                                                */
    /* ---- index: 418 ---- */
    { 0x0FA6, 0x0FB7 }, /* 0x0FA7 TIBETAN SUBJOINED LETTER BHA                                                */
    /* ---- index: 419 ---- */
    { 0x0FAB, 0x0FB7 }, /* 0x0FAC TIBETAN SUBJOINED LETTER DZHA                                               */
    /* ---- index: 420 ---- */
    { 0x0F90, 0x0FB5 }, /* 0x0FB9 TIBETAN SUBJOINED LETTER KSSA                                               */
    /* ---- index: 421 ---- */
    { 0x1025, 0x102E }, /* 0x1026 MYANMAR LETTER UU                                                           */
    /* ---- index: 422 ---- */
    { 0x1B05, 0x1B35 }, /* 0x1B06 BALINESE LETTER AKARA TEDUNG                                                */
    { 0x0000, 0x0000 }, /* 0x1B07 --- padding ---                                                             */
    { 0x1B07, 0x1B35 }, /* 0x1B08 BALINESE LETTER IKARA TEDUNG                                                */
    { 0x0000, 0x0000 }, /* 0x1B09 --- padding ---                                                             */
    { 0x1B09, 0x1B35 }, /* 0x1B0A BALINESE LETTER UKARA TEDUNG                                                */
    { 0x0000, 0x0000 }, /* 0x1B0B --- padding ---                                                             */
    { 0x1B0B, 0x1B35 }, /* 0x1B0C BALINESE LETTER RA REPA TEDUNG                                              */
    { 0x0000, 0x0000 }, /* 0x1B0D --- padding ---                                                             */
    { 0x1B0D, 0x1B35 }, /* 0x1B0E BALINESE LETTER LA LENGA TEDUNG                                             */
    /* ---- index: 431 ---- */
    { 0x1B11, 0x1B35 }, /* 0x1B12 BALINESE LETTER OKARA TEDUNG                                                */
    /* ---- index: 432 ---- */
    { 0x1B3A, 0x1B35 }, /* 0x1B3B BALINESE VOWEL SIGN RA REPA TEDUNG                                          */
    { 0x0000, 0x0000 }, /* 0x1B3C --- padding ---                                                             */
    { 0x1B3C, 0x1B35 }, /* 0x1B3D BALINESE VOWEL SIGN LA LENGA TEDUNG                                         */
    /* ---- index: 435 ---- */
    { 0x1B3E, 0x1B35 }, /* 0x1B40 BALINESE VOWEL SIGN TALING TEDUNG                                           */
    { 0x1B3F, 0x1B35 }, /* 0x1B41 BALINESE VOWEL SIGN TALING REPA TEDUNG                                      */
    { 0x0000, 0x0000 }, /* 0x1B42 --- padding ---                                                             */
    { 0x1B42, 0x1B35 }, /* 0x1B43 BALINESE VOWEL SIGN PEPET TEDUNG                                            */
    /* ---- index: 439 ---- */
    { 0x0041, 0x0325 }, /* 0x1E00 LATIN CAPITAL LETTER A WITH RING BELOW                                      */
    { 0x0061, 0x0325 }, /* 0x1E01 LATIN SMALL LETTER A WITH RING BELOW                                        */
    { 0x0042, 0x0307 }, /* 0x1E02 LATIN CAPITAL LETTER B WITH DOT ABOVE                                       */
    { 0x0062, 0x0307 }, /* 0x1E03 LATIN SMALL LETTER B WITH DOT ABOVE                                         */
    { 0x0042, 0x0323 }, /* 0x1E04 LATIN CAPITAL LETTER B WITH DOT BELOW                                       */
    { 0x0062, 0x0323 }, /* 0x1E05 LATIN SMALL LETTER B WITH DOT BELOW                                         */
    { 0x0042, 0x0331 }, /* 0x1E06 LATIN CAPITAL LETTER B WITH LINE BELOW                                      */
    { 0x0062, 0x0331 }, /* 0x1E07 LATIN SMALL LETTER B WITH LINE BELOW                                        */
    { 0x00C7, 0x0301 }, /* 0x1E08 LATIN CAPITAL LETTER C WITH CEDILLA AND ACUTE                               */
    { 0x00E7, 0x0301 }, /* 0x1E09 LATIN SMALL LETTER C WITH CEDILLA AND ACUTE                                 */
    { 0x0044, 0x0307 }, /* 0x1E0A LATIN CAPITAL LETTER D WITH DOT ABOVE                                       */
    { 0x0064, 0x0307 }, /* 0x1E0B LATIN SMALL LETTER D WITH DOT ABOVE                                         */
    { 0x0044, 0x0323 }, /* 0x1E0C LATIN CAPITAL LETTER D WITH DOT BELOW                                       */
    { 0x0064, 0x0323 }, /* 0x1E0D LATIN SMALL LETTER D WITH DOT BELOW                                         */
    { 0x0044, 0x0331 }, /* 0x1E0E LATIN CAPITAL LETTER D WITH LINE BELOW                                      */
    { 0x0064, 0x0331 }, /* 0x1E0F LATIN SMALL LETTER D WITH LINE BELOW                                        */
    { 0x0044, 0x0327 }, /* 0x1E10 LATIN CAPITAL LETTER D WITH CEDILLA                                         */
    { 0x0064, 0x0327 }, /* 0x1E11 LATIN SMALL LETTER D WITH CEDILLA                                           */
    { 0x0044, 0x032D }, /* 0x1E12 LATIN CAPITAL LETTER D WITH CIRCUMFLEX BELOW                                */
    { 0x0064, 0x032D }, /* 0x1E13 LATIN SMALL LETTER D WITH CIRCUMFLEX BELOW                                  */
    { 0x0112, 0x0300 }, /* 0x1E14 LATIN CAPITAL LETTER E WITH MACRON AND GRAVE                                */
    { 0x0113, 0x0300 }, /* 0x1E15 LATIN SMALL LETTER E WITH MACRON AND GRAVE                                  */
    { 0x0112, 0x0301 }, /* 0x1E16 LATIN CAPITAL LETTER E WITH MACRON AND ACUTE                                */
    { 0x0113, 0x0301 }, /* 0x1E17 LATIN SMALL LETTER E WITH MACRON AND ACUTE                                  */
    { 0x0045, 0x032D }, /* 0x1E18 LATIN CAPITAL LETTER E WITH CIRCUMFLEX BELOW                                */
    { 0x0065, 0x032D }, /* 0x1E19 LATIN SMALL LETTER E WITH CIRCUMFLEX BELOW                                  */
    { 0x0045, 0x0330 }, /* 0x1E1A LATIN CAPITAL LETTER E WITH TILDE BELOW                                     */
    { 0x0065, 0x0330 }, /* 0x1E1B LATIN SMALL LETTER E WITH TILDE BELOW                                       */
    { 0x0228, 0x0306 }, /* 0x1E1C LATIN CAPITAL LETTER E WITH CEDILLA AND BREVE                               */
    { 0x0229, 0x0306 }, /* 0x1E1D LATIN SMALL LETTER E WITH CEDILLA AND BREVE                                 */
    { 0x0046, 0x0307 }, /* 0x1E1E LATIN CAPITAL LETTER F WITH DOT ABOVE                                       */
    { 0x0066, 0x0307 }, /* 0x1E1F LATIN SMALL LETTER F WITH DOT ABOVE                                         */
    { 0x0047, 0x0304 }, /* 0x1E20 LATIN CAPITAL LETTER G WITH MACRON                                          */
    { 0x0067, 0x0304 }, /* 0x1E21 LATIN SMALL LETTER G WITH MACRON                                            */
    { 0x0048, 0x0307 }, /* 0x1E22 LATIN CAPITAL LETTER H WITH DOT ABOVE                                       */
    { 0x0068, 0x0307 }, /* 0x1E23 LATIN SMALL LETTER H WITH DOT ABOVE                                         */
    { 0x0048, 0x0323 }, /* 0x1E24 LATIN CAPITAL LETTER H WITH DOT BELOW                                       */
    { 0x0068, 0x0323 }, /* 0x1E25 LATIN SMALL LETTER H WITH DOT BELOW                                         */
    { 0x0048, 0x0308 }, /* 0x1E26 LATIN CAPITAL LETTER H WITH DIAERESIS                                       */
    { 0x0068, 0x0308 }, /* 0x1E27 LATIN SMALL LETTER H WITH DIAERESIS                                         */
    { 0x0048, 0x0327 }, /* 0x1E28 LATIN CAPITAL LETTER H WITH CEDILLA                                         */
    { 0x0068, 0x0327 }, /* 0x1E29 LATIN SMALL LETTER H WITH CEDILLA                                           */
    { 0x0048, 0x032E }, /* 0x1E2A LATIN CAPITAL LETTER H WITH BREVE BELOW                                     */
    { 0x0068, 0x032E }, /* 0x1E2B LATIN SMALL LETTER H WITH BREVE BELOW                                       */
    { 0x0049, 0x0330 }, /* 0x1E2C LATIN CAPITAL LETTER I WITH TILDE BELOW                                     */
    { 0x0069, 0x0330 }, /* 0x1E2D LATIN SMALL LETTER I WITH TILDE BELOW                                       */
    { 0x00CF, 0x0301 }, /* 0x1E2E LATIN CAPITAL LETTER I WITH DIAERESIS AND ACUTE                             */
    { 0x00EF, 0x0301 }, /* 0x1E2F LATIN SMALL LETTER I WITH DIAERESIS AND ACUTE                               */
    { 0x004B, 0x0301 }, /* 0x1E30 LATIN CAPITAL LETTER K WITH ACUTE                                           */
    { 0x006B, 0x0301 }, /* 0x1E31 LATIN SMALL LETTER K WITH ACUTE                                             */
    { 0x004B, 0x0323 }, /* 0x1E32 LATIN CAPITAL LETTER K WITH DOT BELOW                                       */
    { 0x006B, 0x0323 }, /* 0x1E33 LATIN SMALL LETTER K WITH DOT BELOW                                         */
    { 0x004B, 0x0331 }, /* 0x1E34 LATIN CAPITAL LETTER K WITH LINE BELOW                                      */
    { 0x006B, 0x0331 }, /* 0x1E35 LATIN SMALL LETTER K WITH LINE BELOW                                        */
    { 0x004C, 0x0323 }, /* 0x1E36 LATIN CAPITAL LETTER L WITH DOT BELOW                                       */
    { 0x006C, 0x0323 }, /* 0x1E37 LATIN SMALL LETTER L WITH DOT BELOW                                         */
    { 0x1E36, 0x0304 }, /* 0x1E38 LATIN CAPITAL LETTER L WITH DOT BELOW AND MACRON                            */
    { 0x1E37, 0x0304 }, /* 0x1E39 LATIN SMALL LETTER L WITH DOT BELOW AND MACRON                              */
    { 0x004C, 0x0331 }, /* 0x1E3A LATIN CAPITAL LETTER L WITH LINE BELOW                                      */
    { 0x006C, 0x0331 }, /* 0x1E3B LATIN SMALL LETTER L WITH LINE BELOW                                        */
    { 0x004C, 0x032D }, /* 0x1E3C LATIN CAPITAL LETTER L WITH CIRCUMFLEX BELOW                                */
    { 0x006C, 0x032D }, /* 0x1E3D LATIN SMALL LETTER L WITH CIRCUMFLEX BELOW                                  */
    { 0x004D, 0x0301 }, /* 0x1E3E LATIN CAPITAL LETTER M WITH ACUTE                                           */
    { 0x006D, 0x0301 }, /* 0x1E3F LATIN SMALL LETTER M WITH ACUTE                                             */
    { 0x004D, 0x0307 }, /* 0x1E40 LATIN CAPITAL LETTER M WITH DOT ABOVE                                       */
    { 0x006D, 0x0307 }, /* 0x1E41 LATIN SMALL LETTER M WITH DOT ABOVE                                         */
    { 0x004D, 0x0323 }, /* 0x1E42 LATIN CAPITAL LETTER M WITH DOT BELOW                                       */
    { 0x006D, 0x0323 }, /* 0x1E43 LATIN SMALL LETTER M WITH DOT BELOW                                         */
    { 0x004E, 0x0307 }, /* 0x1E44 LATIN CAPITAL LETTER N WITH DOT ABOVE                                       */
    { 0x006E, 0x0307 }, /* 0x1E45 LATIN SMALL LETTER N WITH DOT ABOVE                                         */
    { 0x004E, 0x0323 }, /* 0x1E46 LATIN CAPITAL LETTER N WITH DOT BELOW                                       */
    { 0x006E, 0x0323 }, /* 0x1E47 LATIN SMALL LETTER N WITH DOT BELOW                                         */
    { 0x004E, 0x0331 }, /* 0x1E48 LATIN CAPITAL LETTER N WITH LINE BELOW                                      */
    { 0x006E, 0x0331 }, /* 0x1E49 LATIN SMALL LETTER N WITH LINE BELOW                                        */
    { 0x004E, 0x032D }, /* 0x1E4A LATIN CAPITAL LETTER N WITH CIRCUMFLEX BELOW                                */
    { 0x006E, 0x032D }, /* 0x1E4B LATIN SMALL LETTER N WITH CIRCUMFLEX BELOW                                  */
    { 0x00D5, 0x0301 }, /* 0x1E4C LATIN CAPITAL LETTER O WITH TILDE AND ACUTE                                 */
    { 0x00F5, 0x0301 }, /* 0x1E4D LATIN SMALL LETTER O WITH TILDE AND ACUTE                                   */
    { 0x00D5, 0x0308 }, /* 0x1E4E LATIN CAPITAL LETTER O WITH TILDE AND DIAERESIS                             */
    { 0x00F5, 0x0308 }, /* 0x1E4F LATIN SMALL LETTER O WITH TILDE AND DIAERESIS                               */
    { 0x014C, 0x0300 }, /* 0x1E50 LATIN CAPITAL LETTER O WITH MACRON AND GRAVE                                */
    { 0x014D, 0x0300 }, /* 0x1E51 LATIN SMALL LETTER O WITH MACRON AND GRAVE                                  */
    { 0x014C, 0x0301 }, /* 0x1E52 LATIN CAPITAL LETTER O WITH MACRON AND ACUTE                                */
    { 0x014D, 0x0301 }, /* 0x1E53 LATIN SMALL LETTER O WITH MACRON AND ACUTE                                  */
    { 0x0050, 0x0301 }, /* 0x1E54 LATIN CAPITAL LETTER P WITH ACUTE                                           */
    { 0x0070, 0x0301 }, /* 0x1E55 LATIN SMALL LETTER P WITH ACUTE                                             */
    { 0x0050, 0x0307 }, /* 0x1E56 LATIN CAPITAL LETTER P WITH DOT ABOVE                                       */
    { 0x0070, 0x0307 }, /* 0x1E57 LATIN SMALL LETTER P WITH DOT ABOVE                                         */
    { 0x0052, 0x0307 }, /* 0x1E58 LATIN CAPITAL LETTER R WITH DOT ABOVE                                       */
    { 0x0072, 0x0307 }, /* 0x1E59 LATIN SMALL LETTER R WITH DOT ABOVE                                         */
    { 0x0052, 0x0323 }, /* 0x1E5A LATIN CAPITAL LETTER R WITH DOT BELOW                                       */
    { 0x0072, 0x0323 }, /* 0x1E5B LATIN SMALL LETTER R WITH DOT BELOW                                         */
    { 0x1E5A, 0x0304 }, /* 0x1E5C LATIN CAPITAL LETTER R WITH DOT BELOW AND MACRON                            */
    { 0x1E5B, 0x0304 }, /* 0x1E5D LATIN SMALL LETTER R WITH DOT BELOW AND MACRON                              */
    { 0x0052, 0x0331 }, /* 0x1E5E LATIN CAPITAL LETTER R WITH LINE BELOW                                      */
    { 0x0072, 0x0331 }, /* 0x1E5F LATIN SMALL LETTER R WITH LINE BELOW                                        */
    { 0x0053, 0x0307 }, /* 0x1E60 LATIN CAPITAL LETTER S WITH DOT ABOVE                                       */
    { 0x0073, 0x0307 }, /* 0x1E61 LATIN SMALL LETTER S WITH DOT ABOVE                                         */
    { 0x0053, 0x0323 }, /* 0x1E62 LATIN CAPITAL LETTER S WITH DOT BELOW                                       */
    { 0x0073, 0x0323 }, /* 0x1E63 LATIN SMALL LETTER S WITH DOT BELOW                                         */
    { 0x015A, 0x0307 }, /* 0x1E64 LATIN CAPITAL LETTER S WITH ACUTE AND DOT ABOVE                             */
    { 0x015B, 0x0307 }, /* 0x1E65 LATIN SMALL LETTER S WITH ACUTE AND DOT ABOVE                               */
    { 0x0160, 0x0307 }, /* 0x1E66 LATIN CAPITAL LETTER S WITH CARON AND DOT ABOVE                             */
    { 0x0161, 0x0307 }, /* 0x1E67 LATIN SMALL LETTER S WITH CARON AND DOT ABOVE                               */
    { 0x1E62, 0x0307 }, /* 0x1E68 LATIN CAPITAL LETTER S WITH DOT BELOW AND DOT ABOVE                         */
    { 0x1E63, 0x0307 }, /* 0x1E69 LATIN SMALL LETTER S WITH DOT BELOW AND DOT ABOVE                           */
    { 0x0054, 0x0307 }, /* 0x1E6A LATIN CAPITAL LETTER T WITH DOT ABOVE                                       */
    { 0x0074, 0x0307 }, /* 0x1E6B LATIN SMALL LETTER T WITH DOT ABOVE                                         */
    { 0x0054, 0x0323 }, /* 0x1E6C LATIN CAPITAL LETTER T WITH DOT BELOW                                       */
    { 0x0074, 0x0323 }, /* 0x1E6D LATIN SMALL LETTER T WITH DOT BELOW                                         */
    { 0x0054, 0x0331 }, /* 0x1E6E LATIN CAPITAL LETTER T WITH LINE BELOW                                      */
    { 0x0074, 0x0331 }, /* 0x1E6F LATIN SMALL LETTER T WITH LINE BELOW                                        */
    { 0x0054, 0x032D }, /* 0x1E70 LATIN CAPITAL LETTER T WITH CIRCUMFLEX BELOW                                */
    { 0x0074, 0x032D }, /* 0x1E71 LATIN SMALL LETTER T WITH CIRCUMFLEX BELOW                                  */
    { 0x0055, 0x0324 }, /* 0x1E72 LATIN CAPITAL LETTER U WITH DIAERESIS BELOW                                 */
    { 0x0075, 0x0324 }, /* 0x1E73 LATIN SMALL LETTER U WITH DIAERESIS BELOW                                   */
    { 0x0055, 0x0330 }, /* 0x1E74 LATIN CAPITAL LETTER U WITH TILDE BELOW                                     */
    { 0x0075, 0x0330 }, /* 0x1E75 LATIN SMALL LETTER U WITH TILDE BELOW                                       */
    { 0x0055, 0x032D }, /* 0x1E76 LATIN CAPITAL LETTER U WITH CIRCUMFLEX BELOW                                */
    { 0x0075, 0x032D }, /* 0x1E77 LATIN SMALL LETTER U WITH CIRCUMFLEX BELOW                                  */
    { 0x0168, 0x0301 }, /* 0x1E78 LATIN CAPITAL LETTER U WITH TILDE AND ACUTE                                 */
    { 0x0169, 0x0301 }, /* 0x1E79 LATIN SMALL LETTER U WITH TILDE AND ACUTE                                   */
    { 0x016A, 0x0308 }, /* 0x1E7A LATIN CAPITAL LETTER U WITH MACRON AND DIAERESIS                            */
    { 0x016B, 0x0308 }, /* 0x1E7B LATIN SMALL LETTER U WITH MACRON AND DIAERESIS                              */
    { 0x0056, 0x0303 }, /* 0x1E7C LATIN CAPITAL LETTER V WITH TILDE                                           */
    { 0x0076, 0x0303 }, /* 0x1E7D LATIN SMALL LETTER V WITH TILDE                                             */
    { 0x0056, 0x0323 }, /* 0x1E7E LATIN CAPITAL LETTER V WITH DOT BELOW                                       */
    { 0x0076, 0x0323 }, /* 0x1E7F LATIN SMALL LETTER V WITH DOT BELOW                                         */
    { 0x0057, 0x0300 }, /* 0x1E80 LATIN CAPITAL LETTER W WITH GRAVE                                           */
    { 0x0077, 0x0300 }, /* 0x1E81 LATIN SMALL LETTER W WITH GRAVE                                             */
    { 0x0057, 0x0301 }, /* 0x1E82 LATIN CAPITAL LETTER W WITH ACUTE                                           */
    { 0x0077, 0x0301 }, /* 0x1E83 LATIN SMALL LETTER W WITH ACUTE                                             */
    { 0x0057, 0x0308 }, /* 0x1E84 LATIN CAPITAL LETTER W WITH DIAERESIS                                       */
    { 0x0077, 0x0308 }, /* 0x1E85 LATIN SMALL LETTER W WITH DIAERESIS                                         */
    { 0x0057, 0x0307 }, /* 0x1E86 LATIN CAPITAL LETTER W WITH DOT ABOVE                                       */
    { 0x0077, 0x0307 }, /* 0x1E87 LATIN SMALL LETTER W WITH DOT ABOVE                                         */
    { 0x0057, 0x0323 }, /* 0x1E88 LATIN CAPITAL LETTER W WITH DOT BELOW                                       */
    { 0x0077, 0x0323 }, /* 0x1E89 LATIN SMALL LETTER W WITH DOT BELOW                                         */
    { 0x0058, 0x0307 }, /* 0x1E8A LATIN CAPITAL LETTER X WITH DOT ABOVE                                       */
    { 0x0078, 0x0307 }, /* 0x1E8B LATIN SMALL LETTER X WITH DOT ABOVE                                         */
    { 0x0058, 0x0308 }, /* 0x1E8C LATIN CAPITAL LETTER X WITH DIAERESIS                                       */
    { 0x0078, 0x0308 }, /* 0x1E8D LATIN SMALL LETTER X WITH DIAERESIS                                         */
    { 0x0059, 0x0307 }, /* 0x1E8E LATIN CAPITAL LETTER Y WITH DOT ABOVE                                       */
    { 0x0079, 0x0307 }, /* 0x1E8F LATIN SMALL LETTER Y WITH DOT ABOVE                                         */
    { 0x005A, 0x0302 }, /* 0x1E90 LATIN CAPITAL LETTER Z WITH CIRCUMFLEX                                      */
    { 0x007A, 0x0302 }, /* 0x1E91 LATIN SMALL LETTER Z WITH CIRCUMFLEX                                        */
    { 0x005A, 0x0323 }, /* 0x1E92 LATIN CAPITAL LETTER Z WITH DOT BELOW                                       */
    { 0x007A, 0x0323 }, /* 0x1E93 LATIN SMALL LETTER Z WITH DOT BELOW                                         */
    { 0x005A, 0x0331 }, /* 0x1E94 LATIN CAPITAL LETTER Z WITH LINE BELOW                                      */
    { 0x007A, 0x0331 }, /* 0x1E95 LATIN SMALL LETTER Z WITH LINE BELOW                                        */
    { 0x0068, 0x0331 }, /* 0x1E96 LATIN SMALL LETTER H WITH LINE BELOW                                        */
    { 0x0074, 0x0308 }, /* 0x1E97 LATIN SMALL LETTER T WITH DIAERESIS                                         */
    { 0x0077, 0x030A }, /* 0x1E98 LATIN SMALL LETTER W WITH RING ABOVE                                        */
    { 0x0079, 0x030A }, /* 0x1E99 LATIN SMALL LETTER Y WITH RING ABOVE                                        */
    { 0x0000, 0x0000 }, /* 0x1E9A --- padding ---                                                             */
    { 0x017F, 0x0307 }, /* 0x1E9B LATIN SMALL LETTER LONG S WITH DOT ABOVE                                    */
    /* ---- index: 595 ---- */
    { 0x0041, 0x0323 }, /* 0x1EA0 LATIN CAPITAL LETTER A WITH DOT BELOW                                       */
    { 0x0061, 0x0323 }, /* 0x1EA1 LATIN SMALL LETTER A WITH DOT BELOW                                         */
    { 0x0041, 0x0309 }, /* 0x1EA2 LATIN CAPITAL LETTER A WITH HOOK ABOVE                                      */
    { 0x0061, 0x0309 }, /* 0x1EA3 LATIN SMALL LETTER A WITH HOOK ABOVE                                        */
    { 0x00C2, 0x0301 }, /* 0x1EA4 LATIN CAPITAL LETTER A WITH CIRCUMFLEX AND ACUTE                            */
    { 0x00E2, 0x0301 }, /* 0x1EA5 LATIN SMALL LETTER A WITH CIRCUMFLEX AND ACUTE                              */
    { 0x00C2, 0x0300 }, /* 0x1EA6 LATIN CAPITAL LETTER A WITH CIRCUMFLEX AND GRAVE                            */
    { 0x00E2, 0x0300 }, /* 0x1EA7 LATIN SMALL LETTER A WITH CIRCUMFLEX AND GRAVE                              */
    { 0x00C2, 0x0309 }, /* 0x1EA8 LATIN CAPITAL LETTER A WITH CIRCUMFLEX AND HOOK ABOVE                       */
    { 0x00E2, 0x0309 }, /* 0x1EA9 LATIN SMALL LETTER A WITH CIRCUMFLEX AND HOOK ABOVE                         */
    { 0x00C2, 0x0303 }, /* 0x1EAA LATIN CAPITAL LETTER A WITH CIRCUMFLEX AND TILDE                            */
    { 0x00E2, 0x0303 }, /* 0x1EAB LATIN SMALL LETTER A WITH CIRCUMFLEX AND TILDE                              */
    { 0x1EA0, 0x0302 }, /* 0x1EAC LATIN CAPITAL LETTER A WITH CIRCUMFLEX AND DOT BELOW                        */
    { 0x1EA1, 0x0302 }, /* 0x1EAD LATIN SMALL LETTER A WITH CIRCUMFLEX AND DOT BELOW                          */
    { 0x0102, 0x0301 }, /* 0x1EAE LATIN CAPITAL LETTER A WITH BREVE AND ACUTE                                 */
    { 0x0103, 0x0301 }, /* 0x1EAF LATIN SMALL LETTER A WITH BREVE AND ACUTE                                   */
    { 0x0102, 0x0300 }, /* 0x1EB0 LATIN CAPITAL LETTER A WITH BREVE AND GRAVE                                 */
    { 0x0103, 0x0300 }, /* 0x1EB1 LATIN SMALL LETTER A WITH BREVE AND GRAVE                                   */
    { 0x0102, 0x0309 }, /* 0x1EB2 LATIN CAPITAL LETTER A WITH BREVE AND HOOK ABOVE                            */
    { 0x0103, 0x0309 }, /* 0x1EB3 LATIN SMALL LETTER A WITH BREVE AND HOOK ABOVE                              */
    { 0x0102, 0x0303 }, /* 0x1EB4 LATIN CAPITAL LETTER A WITH BREVE AND TILDE                                 */
    { 0x0103, 0x0303 }, /* 0x1EB5 LATIN SMALL LETTER A WITH BREVE AND TILDE                                   */
    { 0x1EA0, 0x0306 }, /* 0x1EB6 LATIN CAPITAL LETTER A WITH BREVE AND DOT BELOW                             */
    { 0x1EA1, 0x0306 }, /* 0x1EB7 LATIN SMALL LETTER A WITH BREVE AND DOT BELOW                               */
    { 0x0045, 0x0323 }, /* 0x1EB8 LATIN CAPITAL LETTER E WITH DOT BELOW                                       */
    { 0x0065, 0x0323 }, /* 0x1EB9 LATIN SMALL LETTER E WITH DOT BELOW                                         */
    { 0x0045, 0x0309 }, /* 0x1EBA LATIN CAPITAL LETTER E WITH HOOK ABOVE                                      */
    { 0x0065, 0x0309 }, /* 0x1EBB LATIN SMALL LETTER E WITH HOOK ABOVE                                        */
    { 0x0045, 0x0303 }, /* 0x1EBC LATIN CAPITAL LETTER E WITH TILDE                                           */
    { 0x0065, 0x0303 }, /* 0x1EBD LATIN SMALL LETTER E WITH TILDE                                             */
    { 0x00CA, 0x0301 }, /* 0x1EBE LATIN CAPITAL LETTER E WITH CIRCUMFLEX AND ACUTE                            */
    { 0x00EA, 0x0301 }, /* 0x1EBF LATIN SMALL LETTER E WITH CIRCUMFLEX AND ACUTE                              */
    { 0x00CA, 0x0300 }, /* 0x1EC0 LATIN CAPITAL LETTER E WITH CIRCUMFLEX AND GRAVE                            */
    { 0x00EA, 0x0300 }, /* 0x1EC1 LATIN SMALL LETTER E WITH CIRCUMFLEX AND GRAVE                              */
    { 0x00CA, 0x0309 }, /* 0x1EC2 LATIN CAPITAL LETTER E WITH CIRCUMFLEX AND HOOK ABOVE                       */
    { 0x00EA, 0x0309 }, /* 0x1EC3 LATIN SMALL LETTER E WITH CIRCUMFLEX AND HOOK ABOVE                         */
    { 0x00CA, 0x0303 }, /* 0x1EC4 LATIN CAPITAL LETTER E WITH CIRCUMFLEX AND TILDE                            */
    { 0x00EA, 0x0303 }, /* 0x1EC5 LATIN SMALL LETTER E WITH CIRCUMFLEX AND TILDE                              */
    { 0x1EB8, 0x0302 }, /* 0x1EC6 LATIN CAPITAL LETTER E WITH CIRCUMFLEX AND DOT BELOW                        */
    { 0x1EB9, 0x0302 }, /* 0x1EC7 LATIN SMALL LETTER E WITH CIRCUMFLEX AND DOT BELOW                          */
    { 0x0049, 0x0309 }, /* 0x1EC8 LATIN CAPITAL LETTER I WITH HOOK ABOVE                                      */
    { 0x0069, 0x0309 }, /* 0x1EC9 LATIN SMALL LETTER I WITH HOOK ABOVE                                        */
    { 0x0049, 0x0323 }, /* 0x1ECA LATIN CAPITAL LETTER I WITH DOT BELOW                                       */
    { 0x0069, 0x0323 }, /* 0x1ECB LATIN SMALL LETTER I WITH DOT BELOW                                         */
    { 0x004F, 0x0323 }, /* 0x1ECC LATIN CAPITAL LETTER O WITH DOT BELOW                                       */
    { 0x006F, 0x0323 }, /* 0x1ECD LATIN SMALL LETTER O WITH DOT BELOW                                         */
    { 0x004F, 0x0309 }, /* 0x1ECE LATIN CAPITAL LETTER O WITH HOOK ABOVE                                      */
    { 0x006F, 0x0309 }, /* 0x1ECF LATIN SMALL LETTER O WITH HOOK ABOVE                                        */
    { 0x00D4, 0x0301 }, /* 0x1ED0 LATIN CAPITAL LETTER O WITH CIRCUMFLEX AND ACUTE                            */
    { 0x00F4, 0x0301 }, /* 0x1ED1 LATIN SMALL LETTER O WITH CIRCUMFLEX AND ACUTE                              */
    { 0x00D4, 0x0300 }, /* 0x1ED2 LATIN CAPITAL LETTER O WITH CIRCUMFLEX AND GRAVE                            */
    { 0x00F4, 0x0300 }, /* 0x1ED3 LATIN SMALL LETTER O WITH CIRCUMFLEX AND GRAVE                              */
    { 0x00D4, 0x0309 }, /* 0x1ED4 LATIN CAPITAL LETTER O WITH CIRCUMFLEX AND HOOK ABOVE                       */
    { 0x00F4, 0x0309 }, /* 0x1ED5 LATIN SMALL LETTER O WITH CIRCUMFLEX AND HOOK ABOVE                         */
    { 0x00D4, 0x0303 }, /* 0x1ED6 LATIN CAPITAL LETTER O WITH CIRCUMFLEX AND TILDE                            */
    { 0x00F4, 0x0303 }, /* 0x1ED7 LATIN SMALL LETTER O WITH CIRCUMFLEX AND TILDE                              */
    { 0x1ECC, 0x0302 }, /* 0x1ED8 LATIN CAPITAL LETTER O WITH CIRCUMFLEX AND DOT BELOW                        */
    { 0x1ECD, 0x0302 }, /* 0x1ED9 LATIN SMALL LETTER O WITH CIRCUMFLEX AND DOT BELOW                          */
    { 0x01A0, 0x0301 }, /* 0x1EDA LATIN CAPITAL LETTER O WITH HORN AND ACUTE                                  */
    { 0x01A1, 0x0301 }, /* 0x1EDB LATIN SMALL LETTER O WITH HORN AND ACUTE                                    */
    { 0x01A0, 0x0300 }, /* 0x1EDC LATIN CAPITAL LETTER O WITH HORN AND GRAVE                                  */
    { 0x01A1, 0x0300 }, /* 0x1EDD LATIN SMALL LETTER O WITH HORN AND GRAVE                                    */
    { 0x01A0, 0x0309 }, /* 0x1EDE LATIN CAPITAL LETTER O WITH HORN AND HOOK ABOVE                             */
    { 0x01A1, 0x0309 }, /* 0x1EDF LATIN SMALL LETTER O WITH HORN AND HOOK ABOVE                               */
    { 0x01A0, 0x0303 }, /* 0x1EE0 LATIN CAPITAL LETTER O WITH HORN AND TILDE                                  */
    { 0x01A1, 0x0303 }, /* 0x1EE1 LATIN SMALL LETTER O WITH HORN AND TILDE                                    */
    { 0x01A0, 0x0323 }, /* 0x1EE2 LATIN CAPITAL LETTER O WITH HORN AND DOT BELOW                              */
    { 0x01A1, 0x0323 }, /* 0x1EE3 LATIN SMALL LETTER O WITH HORN AND DOT BELOW                                */
    { 0x0055, 0x0323 }, /* 0x1EE4 LATIN CAPITAL LETTER U WITH DOT BELOW                                       */
    { 0x0075, 0x0323 }, /* 0x1EE5 LATIN SMALL LETTER U WITH DOT BELOW                                         */
    { 0x0055, 0x0309 }, /* 0x1EE6 LATIN CAPITAL LETTER U WITH HOOK ABOVE                                      */
    { 0x0075, 0x0309 }, /* 0x1EE7 LATIN SMALL LETTER U WITH HOOK ABOVE                                        */
    { 0x01AF, 0x0301 }, /* 0x1EE8 LATIN CAPITAL LETTER U WITH HORN AND ACUTE                                  */
    { 0x01B0, 0x0301 }, /* 0x1EE9 LATIN SMALL LETTER U WITH HORN AND ACUTE                                    */
    { 0x01AF, 0x0300 }, /* 0x1EEA LATIN CAPITAL LETTER U WITH HORN AND GRAVE                                  */
    { 0x01B0, 0x0300 }, /* 0x1EEB LATIN SMALL LETTER U WITH HORN AND GRAVE                                    */
    { 0x01AF, 0x0309 }, /* 0x1EEC LATIN CAPITAL LETTER U WITH HORN AND HOOK ABOVE                             */
    { 0x01B0, 0x0309 }, /* 0x1EED LATIN SMALL LETTER U WITH HORN AND HOOK ABOVE                               */
    { 0x01AF, 0x0303 }, /* 0x1EEE LATIN CAPITAL LETTER U WITH HORN AND TILDE                                  */
    { 0x01B0, 0x0303 }, /* 0x1EEF LATIN SMALL LETTER U WITH HORN AND TILDE                                    */
    { 0x01AF, 0x0323 }, /* 0x1EF0 LATIN CAPITAL LETTER U WITH HORN AND DOT BELOW                              */
    { 0x01B0, 0x0323 }, /* 0x1EF1 LATIN SMALL LETTER U WITH HORN AND DOT BELOW                                */
    { 0x0059, 0x0300 }, /* 0x1EF2 LATIN CAPITAL LETTER Y WITH GRAVE                                           */
    { 0x0079, 0x0300 }, /* 0x1EF3 LATIN SMALL LETTER Y WITH GRAVE                                             */
    { 0x0059, 0x0323 }, /* 0x1EF4 LATIN CAPITAL LETTER Y WITH DOT BELOW                                       */
    { 0x0079, 0x0323 }, /* 0x1EF5 LATIN SMALL LETTER Y WITH DOT BELOW                                         */
    { 0x0059, 0x0309 }, /* 0x1EF6 LATIN CAPITAL LETTER Y WITH HOOK ABOVE                                      */
    { 0x0079, 0x0309 }, /* 0x1EF7 LATIN SMALL LETTER Y WITH HOOK ABOVE                                        */
    { 0x0059, 0x0303 }, /* 0x1EF8 LATIN CAPITAL LETTER Y WITH TILDE                                           */
    { 0x0079, 0x0303 }, /* 0x1EF9 LATIN SMALL LETTER Y WITH TILDE                                             */
    /* ---- index: 685 ---- */
    { 0x03B1, 0x0313 }, /* 0x1F00 GREEK SMALL LETTER ALPHA WITH PSILI                                         */
    { 0x03B1, 0x0314 }, /* 0x1F01 GREEK SMALL LETTER ALPHA WITH DASIA                                         */
    { 0x1F00, 0x0300 }, /* 0x1F02 GREEK SMALL LETTER ALPHA WITH PSILI AND VARIA                               */
    { 0x1F01, 0x0300 }, /* 0x1F03 GREEK SMALL LETTER ALPHA WITH DASIA AND VARIA                               */
    { 0x1F00, 0x0301 }, /* 0x1F04 GREEK SMALL LETTER ALPHA WITH PSILI AND OXIA                                */
    { 0x1F01, 0x0301 }, /* 0x1F05 GREEK SMALL LETTER ALPHA WITH DASIA AND OXIA                                */
    { 0x1F00, 0x0342 }, /* 0x1F06 GREEK SMALL LETTER ALPHA WITH PSILI AND PERISPOMENI                         */
    { 0x1F01, 0x0342 }, /* 0x1F07 GREEK SMALL LETTER ALPHA WITH DASIA AND PERISPOMENI                         */
    { 0x0391, 0x0313 }, /* 0x1F08 GREEK CAPITAL LETTER ALPHA WITH PSILI                                       */
    { 0x0391, 0x0314 }, /* 0x1F09 GREEK CAPITAL LETTER ALPHA WITH DASIA                                       */
    { 0x1F08, 0x0300 }, /* 0x1F0A GREEK CAPITAL LETTER ALPHA WITH PSILI AND VARIA                             */
    { 0x1F09, 0x0300 }, /* 0x1F0B GREEK CAPITAL LETTER ALPHA WITH DASIA AND VARIA                             */
    { 0x1F08, 0x0301 }, /* 0x1F0C GREEK CAPITAL LETTER ALPHA WITH PSILI AND OXIA                              */
    { 0x1F09, 0x0301 }, /* 0x1F0D GREEK CAPITAL LETTER ALPHA WITH DASIA AND OXIA                              */
    { 0x1F08, 0x0342 }, /* 0x1F0E GREEK CAPITAL LETTER ALPHA WITH PSILI AND PERISPOMENI                       */
    { 0x1F09, 0x0342 }, /* 0x1F0F GREEK CAPITAL LETTER ALPHA WITH DASIA AND PERISPOMENI                       */
    { 0x03B5, 0x0313 }, /* 0x1F10 GREEK SMALL LETTER EPSILON WITH PSILI                                       */
    { 0x03B5, 0x0314 }, /* 0x1F11 GREEK SMALL LETTER EPSILON WITH DASIA                                       */
    { 0x1F10, 0x0300 }, /* 0x1F12 GREEK SMALL LETTER EPSILON WITH PSILI AND VARIA                             */
    { 0x1F11, 0x0300 }, /* 0x1F13 GREEK SMALL LETTER EPSILON WITH DASIA AND VARIA                             */
    { 0x1F10, 0x0301 }, /* 0x1F14 GREEK SMALL LETTER EPSILON WITH PSILI AND OXIA                              */
    { 0x1F11, 0x0301 }, /* 0x1F15 GREEK SMALL LETTER EPSILON WITH DASIA AND OXIA                              */
    /* ---- index: 707 ---- */
    { 0x0395, 0x0313 }, /* 0x1F18 GREEK CAPITAL LETTER EPSILON WITH PSILI                                     */
    { 0x0395, 0x0314 }, /* 0x1F19 GREEK CAPITAL LETTER EPSILON WITH DASIA                                     */
    { 0x1F18, 0x0300 }, /* 0x1F1A GREEK CAPITAL LETTER EPSILON WITH PSILI AND VARIA                           */
    { 0x1F19, 0x0300 }, /* 0x1F1B GREEK CAPITAL LETTER EPSILON WITH DASIA AND VARIA                           */
    { 0x1F18, 0x0301 }, /* 0x1F1C GREEK CAPITAL LETTER EPSILON WITH PSILI AND OXIA                            */
    { 0x1F19, 0x0301 }, /* 0x1F1D GREEK CAPITAL LETTER EPSILON WITH DASIA AND OXIA                            */
    /* ---- index: 713 ---- */
    { 0x03B7, 0x0313 }, /* 0x1F20 GREEK SMALL LETTER ETA WITH PSILI                                           */
    { 0x03B7, 0x0314 }, /* 0x1F21 GREEK SMALL LETTER ETA WITH DASIA                                           */
    { 0x1F20, 0x0300 }, /* 0x1F22 GREEK SMALL LETTER ETA WITH PSILI AND VARIA                                 */
    { 0x1F21, 0x0300 }, /* 0x1F23 GREEK SMALL LETTER ETA WITH DASIA AND VARIA                                 */
    { 0x1F20, 0x0301 }, /* 0x1F24 GREEK SMALL LETTER ETA WITH PSILI AND OXIA                                  */
    { 0x1F21, 0x0301 }, /* 0x1F25 GREEK SMALL LETTER ETA WITH DASIA AND OXIA                                  */
    { 0x1F20, 0x0342 }, /* 0x1F26 GREEK SMALL LETTER ETA WITH PSILI AND PERISPOMENI                           */
    { 0x1F21, 0x0342 }, /* 0x1F27 GREEK SMALL LETTER ETA WITH DASIA AND PERISPOMENI                           */
    { 0x0397, 0x0313 }, /* 0x1F28 GREEK CAPITAL LETTER ETA WITH PSILI                                         */
    { 0x0397, 0x0314 }, /* 0x1F29 GREEK CAPITAL LETTER ETA WITH DASIA                                         */
    { 0x1F28, 0x0300 }, /* 0x1F2A GREEK CAPITAL LETTER ETA WITH PSILI AND VARIA                               */
    { 0x1F29, 0x0300 }, /* 0x1F2B GREEK CAPITAL LETTER ETA WITH DASIA AND VARIA                               */
    { 0x1F28, 0x0301 }, /* 0x1F2C GREEK CAPITAL LETTER ETA WITH PSILI AND OXIA                                */
    { 0x1F29, 0x0301 }, /* 0x1F2D GREEK CAPITAL LETTER ETA WITH DASIA AND OXIA                                */
    { 0x1F28, 0x0342 }, /* 0x1F2E GREEK CAPITAL LETTER ETA WITH PSILI AND PERISPOMENI                         */
    { 0x1F29, 0x0342 }, /* 0x1F2F GREEK CAPITAL LETTER ETA WITH DASIA AND PERISPOMENI                         */
    { 0x03B9, 0x0313 }, /* 0x1F30 GREEK SMALL LETTER IOTA WITH PSILI                                          */
    { 0x03B9, 0x0314 }, /* 0x1F31 GREEK SMALL LETTER IOTA WITH DASIA                                          */
    { 0x1F30, 0x0300 }, /* 0x1F32 GREEK SMALL LETTER IOTA WITH PSILI AND VARIA                                */
    { 0x1F31, 0x0300 }, /* 0x1F33 GREEK SMALL LETTER IOTA WITH DASIA AND VARIA                                */
    { 0x1F30, 0x0301 }, /* 0x1F34 GREEK SMALL LETTER IOTA WITH PSILI AND OXIA                                 */
    { 0x1F31, 0x0301 }, /* 0x1F35 GREEK SMALL LETTER IOTA WITH DASIA AND OXIA                                 */
    { 0x1F30, 0x0342 }, /* 0x1F36 GREEK SMALL LETTER IOTA WITH PSILI AND PERISPOMENI                          */
    { 0x1F31, 0x0342 }, /* 0x1F37 GREEK SMALL LETTER IOTA WITH DASIA AND PERISPOMENI                          */
    { 0x0399, 0x0313 }, /* 0x1F38 GREEK CAPITAL LETTER IOTA WITH PSILI                                        */
    { 0x0399, 0x0314 }, /* 0x1F39 GREEK CAPITAL LETTER IOTA WITH DASIA                                        */
    { 0x1F38, 0x0300 }, /* 0x1F3A GREEK CAPITAL LETTER IOTA WITH PSILI AND VARIA                              */
    { 0x1F39, 0x0300 }, /* 0x1F3B GREEK CAPITAL LETTER IOTA WITH DASIA AND VARIA                              */
    { 0x1F38, 0x0301 }, /* 0x1F3C GREEK CAPITAL LETTER IOTA WITH PSILI AND OXIA                               */
    { 0x1F39, 0x0301 }, /* 0x1F3D GREEK CAPITAL LETTER IOTA WITH DASIA AND OXIA                               */
    { 0x1F38, 0x0342 }, /* 0x1F3E GREEK CAPITAL LETTER IOTA WITH PSILI AND PERISPOMENI                        */
    { 0x1F39, 0x0342 }, /* 0x1F3F GREEK CAPITAL LETTER IOTA WITH DASIA AND PERISPOMENI                        */
    { 0x03BF, 0x0313 }, /* 0x1F40 GREEK SMALL LETTER OMICRON WITH PSILI                                       */
    { 0x03BF, 0x0314 }, /* 0x1F41 GREEK SMALL LETTER OMICRON WITH DASIA                                       */
    { 0x1F40, 0x0300 }, /* 0x1F42 GREEK SMALL LETTER OMICRON WITH PSILI AND VARIA                             */
    { 0x1F41, 0x0300 }, /* 0x1F43 GREEK SMALL LETTER OMICRON WITH DASIA AND VARIA                             */
    { 0x1F40, 0x0301 }, /* 0x1F44 GREEK SMALL LETTER OMICRON WITH PSILI AND OXIA                              */
    { 0x1F41, 0x0301 }, /* 0x1F45 GREEK SMALL LETTER OMICRON WITH DASIA AND OXIA                              */
    /* ---- index: 751 ---- */
    { 0x039F, 0x0313 }, /* 0x1F48 GREEK CAPITAL LETTER OMICRON WITH PSILI                                     */
    { 0x039F, 0x0314 }, /* 0x1F49 GREEK CAPITAL LETTER OMICRON WITH DASIA                                     */
    { 0x1F48, 0x0300 }, /* 0x1F4A GREEK CAPITAL LETTER OMICRON WITH PSILI AND VARIA                           */
    { 0x1F49, 0x0300 }, /* 0x1F4B GREEK CAPITAL LETTER OMICRON WITH DASIA AND VARIA                           */
    { 0x1F48, 0x0301 }, /* 0x1F4C GREEK CAPITAL LETTER OMICRON WITH PSILI AND OXIA                            */
    { 0x1F49, 0x0301 }, /* 0x1F4D GREEK CAPITAL LETTER OMICRON WITH DASIA AND OXIA                            */
    /* ---- index: 757 ---- */
    { 0x03C5, 0x0313 }, /* 0x1F50 GREEK SMALL LETTER UPSILON WITH PSILI                                       */
    { 0x03C5, 0x0314 }, /* 0x1F51 GREEK SMALL LETTER UPSILON WITH DASIA                                       */
    { 0x1F50, 0x0300 }, /* 0x1F52 GREEK SMALL LETTER UPSILON WITH PSILI AND VARIA                             */
    { 0x1F51, 0x0300 }, /* 0x1F53 GREEK SMALL LETTER UPSILON WITH DASIA AND VARIA                             */
    { 0x1F50, 0x0301 }, /* 0x1F54 GREEK SMALL LETTER UPSILON WITH PSILI AND OXIA                              */
    { 0x1F51, 0x0301 }, /* 0x1F55 GREEK SMALL LETTER UPSILON WITH DASIA AND OXIA                              */
    { 0x1F50, 0x0342 }, /* 0x1F56 GREEK SMALL LETTER UPSILON WITH PSILI AND PERISPOMENI                       */
    { 0x1F51, 0x0342 }, /* 0x1F57 GREEK SMALL LETTER UPSILON WITH DASIA AND PERISPOMENI                       */
    { 0x0000, 0x0000 }, /* 0x1F58 --- padding ---                                                             */
    { 0x03A5, 0x0314 }, /* 0x1F59 GREEK CAPITAL LETTER UPSILON WITH DASIA                                     */
    { 0x0000, 0x0000 }, /* 0x1F5A --- padding ---                                                             */
    { 0x1F59, 0x0300 }, /* 0x1F5B GREEK CAPITAL LETTER UPSILON WITH DASIA AND VARIA                           */
    { 0x0000, 0x0000 }, /* 0x1F5C --- padding ---                                                             */
    { 0x1F59, 0x0301 }, /* 0x1F5D GREEK CAPITAL LETTER UPSILON WITH DASIA AND OXIA                            */
    { 0x0000, 0x0000 }, /* 0x1F5E --- padding ---                                                             */
    { 0x1F59, 0x0342 }, /* 0x1F5F GREEK CAPITAL LETTER UPSILON WITH DASIA AND PERISPOMENI                     */
    { 0x03C9, 0x0313 }, /* 0x1F60 GREEK SMALL LETTER OMEGA WITH PSILI                                         */
    { 0x03C9, 0x0314 }, /* 0x1F61 GREEK SMALL LETTER OMEGA WITH DASIA                                         */
    { 0x1F60, 0x0300 }, /* 0x1F62 GREEK SMALL LETTER OMEGA WITH PSILI AND VARIA                               */
    { 0x1F61, 0x0300 }, /* 0x1F63 GREEK SMALL LETTER OMEGA WITH DASIA AND VARIA                               */
    { 0x1F60, 0x0301 }, /* 0x1F64 GREEK SMALL LETTER OMEGA WITH PSILI AND OXIA                                */
    { 0x1F61, 0x0301 }, /* 0x1F65 GREEK SMALL LETTER OMEGA WITH DASIA AND OXIA                                */
    { 0x1F60, 0x0342 }, /* 0x1F66 GREEK SMALL LETTER OMEGA WITH PSILI AND PERISPOMENI                         */
    { 0x1F61, 0x0342 }, /* 0x1F67 GREEK SMALL LETTER OMEGA WITH DASIA AND PERISPOMENI                         */
    { 0x03A9, 0x0313 }, /* 0x1F68 GREEK CAPITAL LETTER OMEGA WITH PSILI                                       */
    { 0x03A9, 0x0314 }, /* 0x1F69 GREEK CAPITAL LETTER OMEGA WITH DASIA                                       */
    { 0x1F68, 0x0300 }, /* 0x1F6A GREEK CAPITAL LETTER OMEGA WITH PSILI AND VARIA                             */
    { 0x1F69, 0x0300 }, /* 0x1F6B GREEK CAPITAL LETTER OMEGA WITH DASIA AND VARIA                             */
    { 0x1F68, 0x0301 }, /* 0x1F6C GREEK CAPITAL LETTER OMEGA WITH PSILI AND OXIA                              */
    { 0x1F69, 0x0301 }, /* 0x1F6D GREEK CAPITAL LETTER OMEGA WITH DASIA AND OXIA                              */
    { 0x1F68, 0x0342 }, /* 0x1F6E GREEK CAPITAL LETTER OMEGA WITH PSILI AND PERISPOMENI                       */
    { 0x1F69, 0x0342 }, /* 0x1F6F GREEK CAPITAL LETTER OMEGA WITH DASIA AND PERISPOMENI                       */
    { 0x03B1, 0x0300 }, /* 0x1F70 GREEK SMALL LETTER ALPHA WITH VARIA                                         */
    { 0x03AC, 0x0000 }, /* 0x1F71 GREEK SMALL LETTER ALPHA WITH OXIA                                          */
    { 0x03B5, 0x0300 }, /* 0x1F72 GREEK SMALL LETTER EPSILON WITH VARIA                                       */
    { 0x03AD, 0x0000 }, /* 0x1F73 GREEK SMALL LETTER EPSILON WITH OXIA                                        */
    { 0x03B7, 0x0300 }, /* 0x1F74 GREEK SMALL LETTER ETA WITH VARIA                                           */
    { 0x03AE, 0x0000 }, /* 0x1F75 GREEK SMALL LETTER ETA WITH OXIA                                            */
    { 0x03B9, 0x0300 }, /* 0x1F76 GREEK SMALL LETTER IOTA WITH VARIA                                          */
    { 0x03AF, 0x0000 }, /* 0x1F77 GREEK SMALL LETTER IOTA WITH OXIA                                           */
    { 0x03BF, 0x0300 }, /* 0x1F78 GREEK SMALL LETTER OMICRON WITH VARIA                                       */
    { 0x03CC, 0x0000 }, /* 0x1F79 GREEK SMALL LETTER OMICRON WITH OXIA                                        */
    { 0x03C5, 0x0300 }, /* 0x1F7A GREEK SMALL LETTER UPSILON WITH VARIA                                       */
    { 0x03CD, 0x0000 }, /* 0x1F7B GREEK SMALL LETTER UPSILON WITH OXIA                                        */
    { 0x03C9, 0x0300 }, /* 0x1F7C GREEK SMALL LETTER OMEGA WITH VARIA                                         */
    { 0x03CE, 0x0000 }, /* 0x1F7D GREEK SMALL LETTER OMEGA WITH OXIA                                          */
    /* ---- index: 803 ---- */
    { 0x1F00, 0x0345 }, /* 0x1F80 GREEK SMALL LETTER ALPHA WITH PSILI AND YPOGEGRAMMENI                       */
    { 0x1F01, 0x0345 }, /* 0x1F81 GREEK SMALL LETTER ALPHA WITH DASIA AND YPOGEGRAMMENI                       */
    { 0x1F02, 0x0345 }, /* 0x1F82 GREEK SMALL LETTER ALPHA WITH PSILI AND VARIA AND YPOGEGRAMMENI             */
    { 0x1F03, 0x0345 }, /* 0x1F83 GREEK SMALL LETTER ALPHA WITH DASIA AND VARIA AND YPOGEGRAMMENI             */
    { 0x1F04, 0x0345 }, /* 0x1F84 GREEK SMALL LETTER ALPHA WITH PSILI AND OXIA AND YPOGEGRAMMENI              */
    { 0x1F05, 0x0345 }, /* 0x1F85 GREEK SMALL LETTER ALPHA WITH DASIA AND OXIA AND YPOGEGRAMMENI              */
    { 0x1F06, 0x0345 }, /* 0x1F86 GREEK SMALL LETTER ALPHA WITH PSILI AND PERISPOMENI AND YPOGEGRAMMENI       */
    { 0x1F07, 0x0345 }, /* 0x1F87 GREEK SMALL LETTER ALPHA WITH DASIA AND PERISPOMENI AND YPOGEGRAMMENI       */
    { 0x1F08, 0x0345 }, /* 0x1F88 GREEK CAPITAL LETTER ALPHA WITH PSILI AND PROSGEGRAMMENI                    */
    { 0x1F09, 0x0345 }, /* 0x1F89 GREEK CAPITAL LETTER ALPHA WITH DASIA AND PROSGEGRAMMENI                    */
    { 0x1F0A, 0x0345 }, /* 0x1F8A GREEK CAPITAL LETTER ALPHA WITH PSILI AND VARIA AND PROSGEGRAMMENI          */
    { 0x1F0B, 0x0345 }, /* 0x1F8B GREEK CAPITAL LETTER ALPHA WITH DASIA AND VARIA AND PROSGEGRAMMENI          */
    { 0x1F0C, 0x0345 }, /* 0x1F8C GREEK CAPITAL LETTER ALPHA WITH PSILI AND OXIA AND PROSGEGRAMMENI           */
    { 0x1F0D, 0x0345 }, /* 0x1F8D GREEK CAPITAL LETTER ALPHA WITH DASIA AND OXIA AND PROSGEGRAMMENI           */
    { 0x1F0E, 0x0345 }, /* 0x1F8E GREEK CAPITAL LETTER ALPHA WITH PSILI AND PERISPOMENI AND PROSGEGRAMMENI    */
    { 0x1F0F, 0x0345 }, /* 0x1F8F GREEK CAPITAL LETTER ALPHA WITH DASIA AND PERISPOMENI AND PROSGEGRAMMENI    */
    { 0x1F20, 0x0345 }, /* 0x1F90 GREEK SMALL LETTER ETA WITH PSILI AND YPOGEGRAMMENI                         */
    { 0x1F21, 0x0345 }, /* 0x1F91 GREEK SMALL LETTER ETA WITH DASIA AND YPOGEGRAMMENI                         */
    { 0x1F22, 0x0345 }, /* 0x1F92 GREEK SMALL LETTER ETA WITH PSILI AND VARIA AND YPOGEGRAMMENI               */
    { 0x1F23, 0x0345 }, /* 0x1F93 GREEK SMALL LETTER ETA WITH DASIA AND VARIA AND YPOGEGRAMMENI               */
    { 0x1F24, 0x0345 }, /* 0x1F94 GREEK SMALL LETTER ETA WITH PSILI AND OXIA AND YPOGEGRAMMENI                */
    { 0x1F25, 0x0345 }, /* 0x1F95 GREEK SMALL LETTER ETA WITH DASIA AND OXIA AND YPOGEGRAMMENI                */
    { 0x1F26, 0x0345 }, /* 0x1F96 GREEK SMALL LETTER ETA WITH PSILI AND PERISPOMENI AND YPOGEGRAMMENI         */
    { 0x1F27, 0x0345 }, /* 0x1F97 GREEK SMALL LETTER ETA WITH DASIA AND PERISPOMENI AND YPOGEGRAMMENI         */
    { 0x1F28, 0x0345 }, /* 0x1F98 GREEK CAPITAL LETTER ETA WITH PSILI AND PROSGEGRAMMENI                      */
    { 0x1F29, 0x0345 }, /* 0x1F99 GREEK CAPITAL LETTER ETA WITH DASIA AND PROSGEGRAMMENI                      */
    { 0x1F2A, 0x0345 }, /* 0x1F9A GREEK CAPITAL LETTER ETA WITH PSILI AND VARIA AND PROSGEGRAMMENI            */
    { 0x1F2B, 0x0345 }, /* 0x1F9B GREEK CAPITAL LETTER ETA WITH DASIA AND VARIA AND PROSGEGRAMMENI            */
    { 0x1F2C, 0x0345 }, /* 0x1F9C GREEK CAPITAL LETTER ETA WITH PSILI AND OXIA AND PROSGEGRAMMENI             */
    { 0x1F2D, 0x0345 }, /* 0x1F9D GREEK CAPITAL LETTER ETA WITH DASIA AND OXIA AND PROSGEGRAMMENI             */
    { 0x1F2E, 0x0345 }, /* 0x1F9E GREEK CAPITAL LETTER ETA WITH PSILI AND PERISPOMENI AND PROSGEGRAMMENI      */
    { 0x1F2F, 0x0345 }, /* 0x1F9F GREEK CAPITAL LETTER ETA WITH DASIA AND PERISPOMENI AND PROSGEGRAMMENI      */
    { 0x1F60, 0x0345 }, /* 0x1FA0 GREEK SMALL LETTER OMEGA WITH PSILI AND YPOGEGRAMMENI                       */
    { 0x1F61, 0x0345 }, /* 0x1FA1 GREEK SMALL LETTER OMEGA WITH DASIA AND YPOGEGRAMMENI                       */
    { 0x1F62, 0x0345 }, /* 0x1FA2 GREEK SMALL LETTER OMEGA WITH PSILI AND VARIA AND YPOGEGRAMMENI             */
    { 0x1F63, 0x0345 }, /* 0x1FA3 GREEK SMALL LETTER OMEGA WITH DASIA AND VARIA AND YPOGEGRAMMENI             */
    { 0x1F64, 0x0345 }, /* 0x1FA4 GREEK SMALL LETTER OMEGA WITH PSILI AND OXIA AND YPOGEGRAMMENI              */
    { 0x1F65, 0x0345 }, /* 0x1FA5 GREEK SMALL LETTER OMEGA WITH DASIA AND OXIA AND YPOGEGRAMMENI              */
    { 0x1F66, 0x0345 }, /* 0x1FA6 GREEK SMALL LETTER OMEGA WITH PSILI AND PERISPOMENI AND YPOGEGRAMMENI       */
    { 0x1F67, 0x0345 }, /* 0x1FA7 GREEK SMALL LETTER OMEGA WITH DASIA AND PERISPOMENI AND YPOGEGRAMMENI       */
    { 0x1F68, 0x0345 }, /* 0x1FA8 GREEK CAPITAL LETTER OMEGA WITH PSILI AND PROSGEGRAMMENI                    */
    { 0x1F69, 0x0345 }, /* 0x1FA9 GREEK CAPITAL LETTER OMEGA WITH DASIA AND PROSGEGRAMMENI                    */
    { 0x1F6A, 0x0345 }, /* 0x1FAA GREEK CAPITAL LETTER OMEGA WITH PSILI AND VARIA AND PROSGEGRAMMENI          */
    { 0x1F6B, 0x0345 }, /* 0x1FAB GREEK CAPITAL LETTER OMEGA WITH DASIA AND VARIA AND PROSGEGRAMMENI          */
    { 0x1F6C, 0x0345 }, /* 0x1FAC GREEK CAPITAL LETTER OMEGA WITH PSILI AND OXIA AND PROSGEGRAMMENI           */
    { 0x1F6D, 0x0345 }, /* 0x1FAD GREEK CAPITAL LETTER OMEGA WITH DASIA AND OXIA AND PROSGEGRAMMENI           */
    { 0x1F6E, 0x0345 }, /* 0x1FAE GREEK CAPITAL LETTER OMEGA WITH PSILI AND PERISPOMENI AND PROSGEGRAMMENI    */
    { 0x1F6F, 0x0345 }, /* 0x1FAF GREEK CAPITAL LETTER OMEGA WITH DASIA AND PERISPOMENI AND PROSGEGRAMMENI    */
    { 0x03B1, 0x0306 }, /* 0x1FB0 GREEK SMALL LETTER ALPHA WITH VRACHY                                        */
    { 0x03B1, 0x0304 }, /* 0x1FB1 GREEK SMALL LETTER ALPHA WITH MACRON                                        */
    { 0x1F70, 0x0345 }, /* 0x1FB2 GREEK SMALL LETTER ALPHA WITH VARIA AND YPOGEGRAMMENI                       */
    { 0x03B1, 0x0345 }, /* 0x1FB3 GREEK SMALL LETTER ALPHA WITH YPOGEGRAMMENI                                 */
    { 0x03AC, 0x0345 }, /* 0x1FB4 GREEK SMALL LETTER ALPHA WITH OXIA AND YPOGEGRAMMENI                        */
    { 0x0000, 0x0000 }, /* 0x1FB5 --- padding ---                                                             */
    { 0x03B1, 0x0342 }, /* 0x1FB6 GREEK SMALL LETTER ALPHA WITH PERISPOMENI                                   */
    { 0x1FB6, 0x0345 }, /* 0x1FB7 GREEK SMALL LETTER ALPHA WITH PERISPOMENI AND YPOGEGRAMMENI                 */
    { 0x0391, 0x0306 }, /* 0x1FB8 GREEK CAPITAL LETTER ALPHA WITH VRACHY                                      */
    { 0x0391, 0x0304 }, /* 0x1FB9 GREEK CAPITAL LETTER ALPHA WITH MACRON                                      */
    { 0x0391, 0x0300 }, /* 0x1FBA GREEK CAPITAL LETTER ALPHA WITH VARIA                                       */
    { 0x0386, 0x0000 }, /* 0x1FBB GREEK CAPITAL LETTER ALPHA WITH OXIA                                        */
    { 0x0391, 0x0345 }, /* 0x1FBC GREEK CAPITAL LETTER ALPHA WITH PROSGEGRAMMENI                              */
    { 0x0000, 0x0000 }, /* 0x1FBD --- padding ---                                                             */
    { 0x03B9, 0x0000 }, /* 0x1FBE GREEK PROSGEGRAMMENI                                                        */
    /* ---- index: 866 ---- */
    { 0x00A8, 0x0342 }, /* 0x1FC1 GREEK DIALYTIKA AND PERISPOMENI                                             */
    { 0x1F74, 0x0345 }, /* 0x1FC2 GREEK SMALL LETTER ETA WITH VARIA AND YPOGEGRAMMENI                         */
    { 0x03B7, 0x0345 }, /* 0x1FC3 GREEK SMALL LETTER ETA WITH YPOGEGRAMMENI                                   */
    { 0x03AE, 0x0345 }, /* 0x1FC4 GREEK SMALL LETTER ETA WITH OXIA AND YPOGEGRAMMENI                          */
    { 0x0000, 0x0000 }, /* 0x1FC5 --- padding ---                                                             */
    { 0x03B7, 0x0342 }, /* 0x1FC6 GREEK SMALL LETTER ETA WITH PERISPOMENI                                     */
    { 0x1FC6, 0x0345 }, /* 0x1FC7 GREEK SMALL LETTER ETA WITH PERISPOMENI AND YPOGEGRAMMENI                   */
    { 0x0395, 0x0300 }, /* 0x1FC8 GREEK CAPITAL LETTER EPSILON WITH VARIA                                     */
    { 0x0388, 0x0000 }, /* 0x1FC9 GREEK CAPITAL LETTER EPSILON WITH OXIA                                      */
    { 0x0397, 0x0300 }, /* 0x1FCA GREEK CAPITAL LETTER ETA WITH VARIA                                         */
    { 0x0389, 0x0000 }, /* 0x1FCB GREEK CAPITAL LETTER ETA WITH OXIA                                          */
    { 0x0397, 0x0345 }, /* 0x1FCC GREEK CAPITAL LETTER ETA WITH PROSGEGRAMMENI                                */
    { 0x1FBF, 0x0300 }, /* 0x1FCD GREEK PSILI AND VARIA                                                       */
    { 0x1FBF, 0x0301 }, /* 0x1FCE GREEK PSILI AND OXIA                                                        */
    { 0x1FBF, 0x0342 }, /* 0x1FCF GREEK PSILI AND PERISPOMENI                                                 */
    { 0x03B9, 0x0306 }, /* 0x1FD0 GREEK SMALL LETTER IOTA WITH VRACHY                                         */
    { 0x03B9, 0x0304 }, /* 0x1FD1 GREEK SMALL LETTER IOTA WITH MACRON                                         */
    { 0x03CA, 0x0300 }, /* 0x1FD2 GREEK SMALL LETTER IOTA WITH DIALYTIKA AND VARIA                            */
    { 0x0390, 0x0000 }, /* 0x1FD3 GREEK SMALL LETTER IOTA WITH DIALYTIKA AND OXIA                             */
    /* ---- index: 885 ---- */
    { 0x03B9, 0x0342 }, /* 0x1FD6 GREEK SMALL LETTER IOTA WITH PERISPOMENI                                    */
    { 0x03CA, 0x0342 }, /* 0x1FD7 GREEK SMALL LETTER IOTA WITH DIALYTIKA AND PERISPOMENI                      */
    { 0x0399, 0x0306 }, /* 0x1FD8 GREEK CAPITAL LETTER IOTA WITH VRACHY                                       */
    { 0x0399, 0x0304 }, /* 0x1FD9 GREEK CAPITAL LETTER IOTA WITH MACRON                                       */
    { 0x0399, 0x0300 }, /* 0x1FDA GREEK CAPITAL LETTER IOTA WITH VARIA                                        */
    { 0x038A, 0x0000 }, /* 0x1FDB GREEK CAPITAL LETTER IOTA WITH OXIA                                         */
    { 0x0000, 0x0000 }, /* 0x1FDC --- padding ---                                                             */
    { 0x1FFE, 0x0300 }, /* 0x1FDD GREEK DASIA AND VARIA                                                       */
    { 0x1FFE, 0x0301 }, /* 0x1FDE GREEK DASIA AND OXIA                                                        */
    { 0x1FFE, 0x0342 }, /* 0x1FDF GREEK DASIA AND PERISPOMENI                                                 */
    { 0x03C5, 0x0306 }, /* 0x1FE0 GREEK SMALL LETTER UPSILON WITH VRACHY                                      */
    { 0x03C5, 0x0304 }, /* 0x1FE1 GREEK SMALL LETTER UPSILON WITH MACRON                                      */
    { 0x03CB, 0x0300 }, /* 0x1FE2 GREEK SMALL LETTER UPSILON WITH DIALYTIKA AND VARIA                         */
    { 0x03B0, 0x0000 }, /* 0x1FE3 GREEK SMALL LETTER UPSILON WITH DIALYTIKA AND OXIA                          */
    { 0x03C1, 0x0313 }, /* 0x1FE4 GREEK SMALL LETTER RHO WITH PSILI                                           */
    { 0x03C1, 0x0314 }, /* 0x1FE5 GREEK SMALL LETTER RHO WITH DASIA                                           */
    { 0x03C5, 0x0342 }, /* 0x1FE6 GREEK SMALL LETTER UPSILON WITH PERISPOMENI                                 */
    { 0x03CB, 0x0342 }, /* 0x1FE7 GREEK SMALL LETTER UPSILON WITH DIALYTIKA AND PERISPOMENI                   */
    { 0x03A5, 0x0306 }, /* 0x1FE8 GREEK CAPITAL LETTER UPSILON WITH VRACHY                                    */
    { 0x03A5, 0x0304 }, /* 0x1FE9 GREEK CAPITAL LETTER UPSILON WITH MACRON                                    */
    { 0x03A5, 0x0300 }, /* 0x1FEA GREEK CAPITAL LETTER UPSILON WITH VARIA                                     */
    { 0x038E, 0x0000 }, /* 0x1FEB GREEK CAPITAL LETTER UPSILON WITH OXIA                                      */
    { 0x03A1, 0x0314 }, /* 0x1FEC GREEK CAPITAL LETTER RHO WITH DASIA                                         */
    { 0x00A8, 0x0300 }, /* 0x1FED GREEK DIALYTIKA AND VARIA                                                   */
    { 0x0385, 0x0000 }, /* 0x1FEE GREEK DIALYTIKA AND OXIA                                                    */
    { 0x0060, 0x0000 }, /* 0x1FEF GREEK VARIA                                                                 */
    /* ---- index: 911 ---- */
    { 0x1F7C, 0x0345 }, /* 0x1FF2 GREEK SMALL LETTER OMEGA WITH VARIA AND YPOGEGRAMMENI                       */
    { 0x03C9, 0x0345 }, /* 0x1FF3 GREEK SMALL LETTER OMEGA WITH YPOGEGRAMMENI                                 */
    { 0x03CE, 0x0345 }, /* 0x1FF4 GREEK SMALL LETTER OMEGA WITH OXIA AND YPOGEGRAMMENI                        */
    { 0x0000, 0x0000 }, /* 0x1FF5 --- padding ---                                                             */
    { 0x03C9, 0x0342 }, /* 0x1FF6 GREEK SMALL LETTER OMEGA WITH PERISPOMENI                                   */
    { 0x1FF6, 0x0345 }, /* 0x1FF7 GREEK SMALL LETTER OMEGA WITH PERISPOMENI AND YPOGEGRAMMENI                 */
    { 0x039F, 0x0300 }, /* 0x1FF8 GREEK CAPITAL LETTER OMICRON WITH VARIA                                     */
    { 0x038C, 0x0000 }, /* 0x1FF9 GREEK CAPITAL LETTER OMICRON WITH OXIA                                      */
    { 0x03A9, 0x0300 }, /* 0x1FFA GREEK CAPITAL LETTER OMEGA WITH VARIA                                       */
    { 0x038F, 0x0000 }, /* 0x1FFB GREEK CAPITAL LETTER OMEGA WITH OXIA                                        */
    { 0x03A9, 0x0345 }, /* 0x1FFC GREEK CAPITAL LETTER OMEGA WITH PROSGEGRAMMENI                              */
    { 0x00B4, 0x0000 }, /* 0x1FFD GREEK OXIA                                                                  */
    /* ---- index: 923 ---- */
    { 0x2002, 0x0000 }, /* 0x2000 EN QUAD                                                                     */
    { 0x2003, 0x0000 }, /* 0x2001 EM QUAD                                                                     */
    /* ---- index: 925 ---- */
    { 0x03A9, 0x0000 }, /* 0x2126 OHM SIGN                                                                    */
    /* ---- index: 926 ---- */
    { 0x004B, 0x0000 }, /* 0x212A KELVIN SIGN                                                                 */
    { 0x00C5, 0x0000 }, /* 0x212B ANGSTROM SIGN                                                               */
    /* ---- index: 928 ---- */
    { 0x2190, 0x0338 }, /* 0x219A LEFTWARDS ARROW WITH STROKE                                                 */
    { 0x2192, 0x0338 }, /* 0x219B RIGHTWARDS ARROW WITH STROKE                                                */
    /* ---- index: 930 ---- */
    { 0x2194, 0x0338 }, /* 0x21AE LEFT RIGHT ARROW WITH STROKE                                                */
    /* ---- index: 931 ---- */
    { 0x21D0, 0x0338 }, /* 0x21CD LEFTWARDS DOUBLE ARROW WITH STROKE                                          */
    { 0x21D4, 0x0338 }, /* 0x21CE LEFT RIGHT DOUBLE ARROW WITH STROKE                                         */
    { 0x21D2, 0x0338 }, /* 0x21CF RIGHTWARDS DOUBLE ARROW WITH STROKE                                         */
    /* ---- index: 934 ---- */
    { 0x2203, 0x0338 }, /* 0x2204 THERE DOES NOT EXIST                                                        */
    /* ---- index: 935 ---- */
    { 0x2208, 0x0338 }, /* 0x2209 NOT AN ELEMENT OF                                                           */
    /* ---- index: 936 ---- */
    { 0x220B, 0x0338 }, /* 0x220C DOES NOT CONTAIN AS MEMBER                                                  */
    /* ---- index: 937 ---- */
    { 0x2223, 0x0338 }, /* 0x2224 DOES NOT DIVIDE                                                             */
    { 0x0000, 0x0000 }, /* 0x2225 --- padding ---                                                             */
    { 0x2225, 0x0338 }, /* 0x2226 NOT PARALLEL TO                                                             */
    /* ---- index: 940 ---- */
    { 0x223C, 0x0338 }, /* 0x2241 NOT TILDE                                                                   */
    /* ---- index: 941 ---- */
    { 0x2243, 0x0338 }, /* 0x2244 NOT ASYMPTOTICALLY EQUAL TO                                                 */
    /* ---- index: 942 ---- */
    { 0x2245, 0x0338 }, /* 0x2247 NEITHER APPROXIMATELY NOR ACTUALLY EQUAL TO                                 */
    { 0x0000, 0x0000 }, /* 0x2248 --- padding ---                                                             */
    { 0x2248, 0x0338 }, /* 0x2249 NOT ALMOST EQUAL TO                                                         */
    /* ---- index: 945 ---- */
    { 0x003D, 0x0338 }, /* 0x2260 NOT EQUAL TO                                                                */
    { 0x0000, 0x0000 }, /* 0x2261 --- padding ---                                                             */
    { 0x2261, 0x0338 }, /* 0x2262 NOT IDENTICAL TO                                                            */
    /* ---- index: 948 ---- */
    { 0x224D, 0x0338 }, /* 0x226D NOT EQUIVALENT TO                                                           */
    { 0x003C, 0x0338 }, /* 0x226E NOT LESS-THAN                                                               */
    { 0x003E, 0x0338 }, /* 0x226F NOT GREATER-THAN                                                            */
    { 0x2264, 0x0338 }, /* 0x2270 NEITHER LESS-THAN NOR EQUAL TO                                              */
    { 0x2265, 0x0338 }, /* 0x2271 NEITHER GREATER-THAN NOR EQUAL TO                                           */
    /* ---- index: 953 ---- */
    { 0x2272, 0x0338 }, /* 0x2274 NEITHER LESS-THAN NOR EQUIVALENT TO                                         */
    { 0x2273, 0x0338 }, /* 0x2275 NEITHER GREATER-THAN NOR EQUIVALENT TO                                      */
    /* ---- index: 955 ---- */
    { 0x2276, 0x0338 }, /* 0x2278 NEITHER LESS-THAN NOR GREATER-THAN                                          */
    { 0x2277, 0x0338 }, /* 0x2279 NEITHER GREATER-THAN NOR LESS-THAN                                          */
    /* ---- index: 957 ---- */
    { 0x227A, 0x0338 }, /* 0x2280 DOES NOT PRECEDE                                                            */
    { 0x227B, 0x0338 }, /* 0x2281 DOES NOT SUCCEED                                                            */
    /* ---- index: 959 ---- */
    { 0x2282, 0x0338 }, /* 0x2284 NOT A SUBSET OF                                                             */
    { 0x2283, 0x0338 }, /* 0x2285 NOT A SUPERSET OF                                                           */
    /* ---- index: 961 ---- */
    { 0x2286, 0x0338 }, /* 0x2288 NEITHER A SUBSET OF NOR EQUAL TO                                            */
    { 0x2287, 0x0338 }, /* 0x2289 NEITHER A SUPERSET OF NOR EQUAL TO                                          */
    /* ---- index: 963 ---- */
    { 0x22A2, 0x0338 }, /* 0x22AC DOES NOT PROVE                                                              */
    { 0x22A8, 0x0338 }, /* 0x22AD NOT TRUE                                                                    */
    { 0x22A9, 0x0338 }, /* 0x22AE DOES NOT FORCE                                                              */
    { 0x22AB, 0x0338 }, /* 0x22AF NEGATED DOUBLE VERTICAL BAR DOUBLE RIGHT TURNSTILE                          */
    /* ---- index: 967 ---- */
    { 0x227C, 0x0338 }, /* 0x22E0 DOES NOT PRECEDE OR EQUAL                                                   */
    { 0x227D, 0x0338 }, /* 0x22E1 DOES NOT SUCCEED OR EQUAL                                                   */
    { 0x2291, 0x0338 }, /* 0x22E2 NOT SQUARE IMAGE OF OR EQUAL TO                                             */
    { 0x2292, 0x0338 }, /* 0x22E3 NOT SQUARE ORIGINAL OF OR EQUAL TO                                          */
    /* ---- index: 971 ---- */
    { 0x22B2, 0x0338 }, /* 0x22EA NOT NORMAL SUBGROUP OF                                                      */
    { 0x22B3, 0x0338 }, /* 0x22EB DOES NOT CONTAIN AS NORMAL SUBGROUP                                         */
    { 0x22B4, 0x0338 }, /* 0x22EC NOT NORMAL SUBGROUP OF OR EQUAL TO                                          */
    { 0x22B5, 0x0338 }, /* 0x22ED DOES NOT CONTAIN AS NORMAL SUBGROUP OR EQUAL                                */
    /* ---- index: 975 ---- */
    { 0x3008, 0x0000 }, /* 0x2329 LEFT-POINTING ANGLE BRACKET                                                 */
    { 0x3009, 0x0000 }, /* 0x232A RIGHT-POINTING ANGLE BRACKET                                                */
    /* ---- index: 977 ---- */
    { 0x2ADD, 0x0338 }, /* 0x2ADC FORKING                                                                     */
    /* ---- index: 978 ---- */
    { 0x304B, 0x3099 }, /* 0x304C HIRAGANA LETTER GA                                                          */
    { 0x0000, 0x0000 }, /* 0x304D --- padding ---                                                             */
    { 0x304D, 0x3099 }, /* 0x304E HIRAGANA LETTER GI                                                          */
    { 0x0000, 0x0000 }, /* 0x304F --- padding ---                                                             */
    { 0x304F, 0x3099 }, /* 0x3050 HIRAGANA LETTER GU                                                          */
    { 0x0000, 0x0000 }, /* 0x3051 --- padding ---                                                             */
    { 0x3051, 0x3099 }, /* 0x3052 HIRAGANA LETTER GE                                                          */
    { 0x0000, 0x0000 }, /* 0x3053 --- padding ---                                                             */
    { 0x3053, 0x3099 }, /* 0x3054 HIRAGANA LETTER GO                                                          */
    { 0x0000, 0x0000 }, /* 0x3055 --- padding ---                                                             */
    { 0x3055, 0x3099 }, /* 0x3056 HIRAGANA LETTER ZA                                                          */
    { 0x0000, 0x0000 }, /* 0x3057 --- padding ---                                                             */
    { 0x3057, 0x3099 }, /* 0x3058 HIRAGANA LETTER ZI                                                          */
    { 0x0000, 0x0000 }, /* 0x3059 --- padding ---                                                             */
    { 0x3059, 0x3099 }, /* 0x305A HIRAGANA LETTER ZU                                                          */
    { 0x0000, 0x0000 }, /* 0x305B --- padding ---                                                             */
    { 0x305B, 0x3099 }, /* 0x305C HIRAGANA LETTER ZE                                                          */
    { 0x0000, 0x0000 }, /* 0x305D --- padding ---                                                             */
    { 0x305D, 0x3099 }, /* 0x305E HIRAGANA LETTER ZO                                                          */
    { 0x0000, 0x0000 }, /* 0x305F --- padding ---                                                             */
    { 0x305F, 0x3099 }, /* 0x3060 HIRAGANA LETTER DA                                                          */
    { 0x0000, 0x0000 }, /* 0x3061 --- padding ---                                                             */
    { 0x3061, 0x3099 }, /* 0x3062 HIRAGANA LETTER DI                                                          */
    /* ---- index: 1001 ---- */
    { 0x3064, 0x3099 }, /* 0x3065 HIRAGANA LETTER DU                                                          */
    { 0x0000, 0x0000 }, /* 0x3066 --- padding ---                                                             */
    { 0x3066, 0x3099 }, /* 0x3067 HIRAGANA LETTER DE                                                          */
    { 0x0000, 0x0000 }, /* 0x3068 --- padding ---                                                             */
    { 0x3068, 0x3099 }, /* 0x3069 HIRAGANA LETTER DO                                                          */
    /* ---- index: 1006 ---- */
    { 0x306F, 0x3099 }, /* 0x3070 HIRAGANA LETTER BA                                                          */
    { 0x306F, 0x309A }, /* 0x3071 HIRAGANA LETTER PA                                                          */
    { 0x0000, 0x0000 }, /* 0x3072 --- padding ---                                                             */
    { 0x3072, 0x3099 }, /* 0x3073 HIRAGANA LETTER BI                                                          */
    { 0x3072, 0x309A }, /* 0x3074 HIRAGANA LETTER PI                                                          */
    { 0x0000, 0x0000 }, /* 0x3075 --- padding ---                                                             */
    { 0x3075, 0x3099 }, /* 0x3076 HIRAGANA LETTER BU                                                          */
    { 0x3075, 0x309A }, /* 0x3077 HIRAGANA LETTER PU                                                          */
    { 0x0000, 0x0000 }, /* 0x3078 --- padding ---                                                             */
    { 0x3078, 0x3099 }, /* 0x3079 HIRAGANA LETTER BE                                                          */
    { 0x3078, 0x309A }, /* 0x307A HIRAGANA LETTER PE                                                          */
    { 0x0000, 0x0000 }, /* 0x307B --- padding ---                                                             */
    { 0x307B, 0x3099 }, /* 0x307C HIRAGANA LETTER BO                                                          */
    { 0x307B, 0x309A }, /* 0x307D HIRAGANA LETTER PO                                                          */
    /* ---- index: 1020 ---- */
    { 0x3046, 0x3099 }, /* 0x3094 HIRAGANA LETTER VU                                                          */
    /* ---- index: 1021 ---- */
    { 0x309D, 0x3099 }, /* 0x309E HIRAGANA VOICED ITERATION MARK                                              */
    /* ---- index: 1022 ---- */
    { 0x30AB, 0x3099 }, /* 0x30AC KATAKANA LETTER GA                                                          */
    { 0x0000, 0x0000 }, /* 0x30AD --- padding ---                                                             */
    { 0x30AD, 0x3099 }, /* 0x30AE KATAKANA LETTER GI                                                          */
    { 0x0000, 0x0000 }, /* 0x30AF --- padding ---                                                             */
    { 0x30AF, 0x3099 }, /* 0x30B0 KATAKANA LETTER GU                                                          */
    { 0x0000, 0x0000 }, /* 0x30B1 --- padding ---                                                             */
    { 0x30B1, 0x3099 }, /* 0x30B2 KATAKANA LETTER GE                                                          */
    { 0x0000, 0x0000 }, /* 0x30B3 --- padding ---                                                             */
    { 0x30B3, 0x3099 }, /* 0x30B4 KATAKANA LETTER GO                                                          */
    { 0x0000, 0x0000 }, /* 0x30B5 --- padding ---                                                             */
    { 0x30B5, 0x3099 }, /* 0x30B6 KATAKANA LETTER ZA                                                          */
    { 0x0000, 0x0000 }, /* 0x30B7 --- padding ---                                                             */
    { 0x30B7, 0x3099 }, /* 0x30B8 KATAKANA LETTER ZI                                                          */
    { 0x0000, 0x0000 }, /* 0x30B9 --- padding ---                                                             */
    { 0x30B9, 0x3099 }, /* 0x30BA KATAKANA LETTER ZU                                                          */
    { 0x0000, 0x0000 }, /* 0x30BB --- padding ---                                                             */
    { 0x30BB, 0x3099 }, /* 0x30BC KATAKANA LETTER ZE                                                          */
    { 0x0000, 0x0000 }, /* 0x30BD --- padding ---                                                             */
    { 0x30BD, 0x3099 }, /* 0x30BE KATAKANA LETTER ZO                                                          */
    { 0x0000, 0x0000 }, /* 0x30BF --- padding ---                                                             */
    { 0x30BF, 0x3099 }, /* 0x30C0 KATAKANA LETTER DA                                                          */
    { 0x0000, 0x0000 }, /* 0x30C1 --- padding ---                                                             */
    { 0x30C1, 0x3099 }, /* 0x30C2 KATAKANA LETTER DI                                                          */
    /* ---- index: 1045 ---- */
    { 0x30C4, 0x3099 }, /* 0x30C5 KATAKANA LETTER DU                                                          */
    { 0x0000, 0x0000 }, /* 0x30C6 --- padding ---                                                             */
    { 0x30C6, 0x3099 }, /* 0x30C7 KATAKANA LETTER DE                                                          */
    { 0x0000, 0x0000 }, /* 0x30C8 --- padding ---                                                             */
    { 0x30C8, 0x3099 }, /* 0x30C9 KATAKANA LETTER DO                                                          */
    /* ---- index: 1050 ---- */
    { 0x30CF, 0x3099 }, /* 0x30D0 KATAKANA LETTER BA                                                          */
    { 0x30CF, 0x309A }, /* 0x30D1 KATAKANA LETTER PA                                                          */
    { 0x0000, 0x0000 }, /* 0x30D2 --- padding ---                                                             */
    { 0x30D2, 0x3099 }, /* 0x30D3 KATAKANA LETTER BI                                                          */
    { 0x30D2, 0x309A }, /* 0x30D4 KATAKANA LETTER PI                                                          */
    { 0x0000, 0x0000 }, /* 0x30D5 --- padding ---                                                             */
    { 0x30D5, 0x3099 }, /* 0x30D6 KATAKANA LETTER BU                                                          */
    { 0x30D5, 0x309A }, /* 0x30D7 KATAKANA LETTER PU                                                          */
    { 0x0000, 0x0000 }, /* 0x30D8 --- padding ---                                                             */
    { 0x30D8, 0x3099 }, /* 0x30D9 KATAKANA LETTER BE                                                          */
    { 0x30D8, 0x309A }, /* 0x30DA KATAKANA LETTER PE                                                          */
    { 0x0000, 0x0000 }, /* 0x30DB --- padding ---                                                             */
    { 0x30DB, 0x3099 }, /* 0x30DC KATAKANA LETTER BO                                                          */
    { 0x30DB, 0x309A }, /* 0x30DD KATAKANA LETTER PO                                                          */
    /* ---- index: 1064 ---- */
    { 0x30A6, 0x3099 }, /* 0x30F4 KATAKANA LETTER VU                                                          */
    /* ---- index: 1065 ---- */
    { 0x30EF, 0x3099 }, /* 0x30F7 KATAKANA LETTER VA                                                          */
    { 0x30F0, 0x3099 }, /* 0x30F8 KATAKANA LETTER VI                                                          */
    { 0x30F1, 0x3099 }, /* 0x30F9 KATAKANA LETTER VE                                                          */
    { 0x30F2, 0x3099 }, /* 0x30FA KATAKANA LETTER VO                                                          */
    /* ---- index: 1069 ---- */
    { 0x30FD, 0x3099 }, /* 0x30FE KATAKANA VOICED ITERATION MARK                                              */
    /* ---- index: 1070 ---- */
    { 0x05D9, 0x05B4 }, /* 0xFB1D HEBREW LETTER YOD WITH HIRIQ                                                */
    { 0x0000, 0x0000 }, /* 0xFB1E --- padding ---                                                             */
    { 0x05F2, 0x05B7 }, /* 0xFB1F HEBREW LIGATURE YIDDISH YOD YOD PATAH                                       */
    /* ---- index: 1073 ---- */
    { 0x05E9, 0x05C1 }, /* 0xFB2A HEBREW LETTER SHIN WITH SHIN DOT                                            */
    { 0x05E9, 0x05C2 }, /* 0xFB2B HEBREW LETTER SHIN WITH SIN DOT                                             */
    { 0xFB49, 0x05C1 }, /* 0xFB2C HEBREW LETTER SHIN WITH DAGESH AND SHIN DOT                                 */
    { 0xFB49, 0x05C2 }, /* 0xFB2D HEBREW LETTER SHIN WITH DAGESH AND SIN DOT                                  */
    { 0x05D0, 0x05B7 }, /* 0xFB2E HEBREW LETTER ALEF WITH PATAH                                               */
    { 0x05D0, 0x05B8 }, /* 0xFB2F HEBREW LETTER ALEF WITH QAMATS                                              */
    { 0x05D0, 0x05BC }, /* 0xFB30 HEBREW LETTER ALEF WITH MAPIQ                                               */
    { 0x05D1, 0x05BC }, /* 0xFB31 HEBREW LETTER BET WITH DAGESH                                               */
    { 0x05D2, 0x05BC }, /* 0xFB32 HEBREW LETTER GIMEL WITH DAGESH                                             */
    { 0x05D3, 0x05BC }, /* 0xFB33 HEBREW LETTER DALET WITH DAGESH                                             */
    { 0x05D4, 0x05BC }, /* 0xFB34 HEBREW LETTER HE WITH MAPIQ                                                 */
    { 0x05D5, 0x05BC }, /* 0xFB35 HEBREW LETTER VAV WITH DAGESH                                               */
    { 0x05D6, 0x05BC }, /* 0xFB36 HEBREW LETTER ZAYIN WITH DAGESH                                             */
    { 0x0000, 0x0000 }, /* 0xFB37 --- padding ---                                                             */
    { 0x05D8, 0x05BC }, /* 0xFB38 HEBREW LETTER TET WITH DAGESH                                               */
    { 0x05D9, 0x05BC }, /* 0xFB39 HEBREW LETTER YOD WITH DAGESH                                               */
    { 0x05DA, 0x05BC }, /* 0xFB3A HEBREW LETTER FINAL KAF WITH DAGESH                                         */
    { 0x05DB, 0x05BC }, /* 0xFB3B HEBREW LETTER KAF WITH DAGESH                                               */
    { 0x05DC, 0x05BC }, /* 0xFB3C HEBREW LETTER LAMED WITH DAGESH                                             */
    { 0x0000, 0x0000 }, /* 0xFB3D --- padding ---                                                             */
    { 0x05DE, 0x05BC }, /* 0xFB3E HEBREW LETTER MEM WITH DAGESH                                               */
    { 0x0000, 0x0000 }, /* 0xFB3F --- padding ---                                                             */
    { 0x05E0, 0x05BC }, /* 0xFB40 HEBREW LETTER NUN WITH DAGESH                                               */
    { 0x05E1, 0x05BC }, /* 0xFB41 HEBREW LETTER SAMEKH WITH DAGESH                                            */
    { 0x0000, 0x0000 }, /* 0xFB42 --- padding ---                                                             */
    { 0x05E3, 0x05BC }, /* 0xFB43 HEBREW LETTER FINAL PE WITH DAGESH                                          */
    { 0x05E4, 0x05BC }, /* 0xFB44 HEBREW LETTER PE WITH DAGESH                                                */
    { 0x0000, 0x0000 }, /* 0xFB45 --- padding ---                                                             */
    { 0x05E6, 0x05BC }, /* 0xFB46 HEBREW LETTER TSADI WITH DAGESH                                             */
    { 0x05E7, 0x05BC }, /* 0xFB47 HEBREW LETTER QOF WITH DAGESH                                               */
    { 0x05E8, 0x05BC }, /* 0xFB48 HEBREW LETTER RESH WITH DAGESH                                              */
    { 0x05E9, 0x05BC }, /* 0xFB49 HEBREW LETTER SHIN WITH DAGESH                                              */
    { 0x05EA, 0x05BC }, /* 0xFB4A HEBREW LETTER TAV WITH DAGESH                                               */
    { 0x05D5, 0x05B9 }, /* 0xFB4B HEBREW LETTER VAV WITH HOLAM                                                */
    { 0x05D1, 0x05BF }, /* 0xFB4C HEBREW LETTER BET WITH RAFE                                                 */
    { 0x05DB, 0x05BF }, /* 0xFB4D HEBREW LETTER KAF WITH RAFE                                                 */
    { 0x05E4, 0x05BF }, /* 0xFB4E HEBREW LETTER PE WITH RAFE                                                  */
};


const DecompositionDataType1
decompositionData1[] =
{
    /* ---- index: 0 ---- */
    { 0x8C48 }, /* 0xF900 CJK COMPATIBILITY IDEOGRAPH-F900                                            */
    { 0x66F4 }, /* 0xF901 CJK COMPATIBILITY IDEOGRAPH-F901                                            */
    { 0x8ECA }, /* 0xF902 CJK COMPATIBILITY IDEOGRAPH-F902                                            */
    { 0x8CC8 }, /* 0xF903 CJK COMPATIBILITY IDEOGRAPH-F903                                            */
    { 0x6ED1 }, /* 0xF904 CJK COMPATIBILITY IDEOGRAPH-F904                                            */
    { 0x4E32 }, /* 0xF905 CJK COMPATIBILITY IDEOGRAPH-F905                                            */
    { 0x53E5 }, /* 0xF906 CJK COMPATIBILITY IDEOGRAPH-F906                                            */
    { 0x9F9C }, /* 0xF907 CJK COMPATIBILITY IDEOGRAPH-F907                                            */
    { 0x9F9C }, /* 0xF908 CJK COMPATIBILITY IDEOGRAPH-F908                                            */
    { 0x5951 }, /* 0xF909 CJK COMPATIBILITY IDEOGRAPH-F909                                            */
    { 0x91D1 }, /* 0xF90A CJK COMPATIBILITY IDEOGRAPH-F90A                                            */
    { 0x5587 }, /* 0xF90B CJK COMPATIBILITY IDEOGRAPH-F90B                                            */
    { 0x5948 }, /* 0xF90C CJK COMPATIBILITY IDEOGRAPH-F90C                                            */
    { 0x61F6 }, /* 0xF90D CJK COMPATIBILITY IDEOGRAPH-F90D                                            */
    { 0x7669 }, /* 0xF90E CJK COMPATIBILITY IDEOGRAPH-F90E                                            */
    { 0x7F85 }, /* 0xF90F CJK COMPATIBILITY IDEOGRAPH-F90F                                            */
    { 0x863F }, /* 0xF910 CJK COMPATIBILITY IDEOGRAPH-F910                                            */
    { 0x87BA }, /* 0xF911 CJK COMPATIBILITY IDEOGRAPH-F911                                            */
    { 0x88F8 }, /* 0xF912 CJK COMPATIBILITY IDEOGRAPH-F912                                            */
    { 0x908F }, /* 0xF913 CJK COMPATIBILITY IDEOGRAPH-F913                                            */
    { 0x6A02 }, /* 0xF914 CJK COMPATIBILITY IDEOGRAPH-F914                                            */
    { 0x6D1B }, /* 0xF915 CJK COMPATIBILITY IDEOGRAPH-F915                                            */
    { 0x70D9 }, /* 0xF916 CJK COMPATIBILITY IDEOGRAPH-F916                                            */
    { 0x73DE }, /* 0xF917 CJK COMPATIBILITY IDEOGRAPH-F917                                            */
    { 0x843D }, /* 0xF918 CJK COMPATIBILITY IDEOGRAPH-F918                                            */
    { 0x916A }, /* 0xF919 CJK COMPATIBILITY IDEOGRAPH-F919                                            */
    { 0x99F1 }, /* 0xF91A CJK COMPATIBILITY IDEOGRAPH-F91A                                            */
    { 0x4E82 }, /* 0xF91B CJK COMPATIBILITY IDEOGRAPH-F91B                                            */
    { 0x5375 }, /* 0xF91C CJK COMPATIBILITY IDEOGRAPH-F91C                                            */
    { 0x6B04 }, /* 0xF91D CJK COMPATIBILITY IDEOGRAPH-F91D                                            */
    { 0x721B }, /* 0xF91E CJK COMPATIBILITY IDEOGRAPH-F91E                                            */
    { 0x862D }, /* 0xF91F CJK COMPATIBILITY IDEOGRAPH-F91F                                            */
    { 0x9E1E }, /* 0xF920 CJK COMPATIBILITY IDEOGRAPH-F920                                            */
    { 0x5D50 }, /* 0xF921 CJK COMPATIBILITY IDEOGRAPH-F921                                            */
    { 0x6FEB }, /* 0xF922 CJK COMPATIBILITY IDEOGRAPH-F922                                            */
    { 0x85CD }, /* 0xF923 CJK COMPATIBILITY IDEOGRAPH-F923                                            */
    { 0x8964 }, /* 0xF924 CJK COMPATIBILITY IDEOGRAPH-F924                                            */
    { 0x62C9 }, /* 0xF925 CJK COMPATIBILITY IDEOGRAPH-F925                                            */
    { 0x81D8 }, /* 0xF926 CJK COMPATIBILITY IDEOGRAPH-F926                                            */
    { 0x881F }, /* 0xF927 CJK COMPATIBILITY IDEOGRAPH-F927                                            */
    { 0x5ECA }, /* 0xF928 CJK COMPATIBILITY IDEOGRAPH-F928                                            */
    { 0x6717 }, /* 0xF929 CJK COMPATIBILITY IDEOGRAPH-F929                                            */
    { 0x6D6A }, /* 0xF92A CJK COMPATIBILITY IDEOGRAPH-F92A                                            */
    { 0x72FC }, /* 0xF92B CJK COMPATIBILITY IDEOGRAPH-F92B                                            */
    { 0x90CE }, /* 0xF92C CJK COMPATIBILITY IDEOGRAPH-F92C                                            */
    { 0x4F86 }, /* 0xF92D CJK COMPATIBILITY IDEOGRAPH-F92D                                            */
    { 0x51B7 }, /* 0xF92E CJK COMPATIBILITY IDEOGRAPH-F92E                                            */
    { 0x52DE }, /* 0xF92F CJK COMPATIBILITY IDEOGRAPH-F92F                                            */
    { 0x64C4 }, /* 0xF930 CJK COMPATIBILITY IDEOGRAPH-F930                                            */
    { 0x6AD3 }, /* 0xF931 CJK COMPATIBILITY IDEOGRAPH-F931                                            */
    { 0x7210 }, /* 0xF932 CJK COMPATIBILITY IDEOGRAPH-F932                                            */
    { 0x76E7 }, /* 0xF933 CJK COMPATIBILITY IDEOGRAPH-F933                                            */
    { 0x8001 }, /* 0xF934 CJK COMPATIBILITY IDEOGRAPH-F934                                            */
    { 0x8606 }, /* 0xF935 CJK COMPATIBILITY IDEOGRAPH-F935                                            */
    { 0x865C }, /* 0xF936 CJK COMPATIBILITY IDEOGRAPH-F936                                            */
    { 0x8DEF }, /* 0xF937 CJK COMPATIBILITY IDEOGRAPH-F937                                            */
    { 0x9732 }, /* 0xF938 CJK COMPATIBILITY IDEOGRAPH-F938                                            */
    { 0x9B6F }, /* 0xF939 CJK COMPATIBILITY IDEOGRAPH-F939                                            */
    { 0x9DFA }, /* 0xF93A CJK COMPATIBILITY IDEOGRAPH-F93A                                            */
    { 0x788C }, /* 0xF93B CJK COMPATIBILITY IDEOGRAPH-F93B                                            */
    { 0x797F }, /* 0xF93C CJK COMPATIBILITY IDEOGRAPH-F93C                                            */
    { 0x7DA0 }, /* 0xF93D CJK COMPATIBILITY IDEOGRAPH-F93D                                            */
    { 0x83C9 }, /* 0xF93E CJK COMPATIBILITY IDEOGRAPH-F93E                                            */
    { 0x9304 }, /* 0xF93F CJK COMPATIBILITY IDEOGRAPH-F93F                                            */
    { 0x9E7F }, /* 0xF940 CJK COMPATIBILITY IDEOGRAPH-F940                                            */
    { 0x8AD6 }, /* 0xF941 CJK COMPATIBILITY IDEOGRAPH-F941                                            */
    { 0x58DF }, /* 0xF942 CJK COMPATIBILITY IDEOGRAPH-F942                                            */
    { 0x5F04 }, /* 0xF943 CJK COMPATIBILITY IDEOGRAPH-F943                                            */
    { 0x7C60 }, /* 0xF944 CJK COMPATIBILITY IDEOGRAPH-F944                                            */
    { 0x807E }, /* 0xF945 CJK COMPATIBILITY IDEOGRAPH-F945                                            */
    { 0x7262 }, /* 0xF946 CJK COMPATIBILITY IDEOGRAPH-F946                                            */
    { 0x78CA }, /* 0xF947 CJK COMPATIBILITY IDEOGRAPH-F947                                            */
    { 0x8CC2 }, /* 0xF948 CJK COMPATIBILITY IDEOGRAPH-F948                                            */
    { 0x96F7 }, /* 0xF949 CJK COMPATIBILITY IDEOGRAPH-F949                                            */
    { 0x58D8 }, /* 0xF94A CJK COMPATIBILITY IDEOGRAPH-F94A                                            */
    { 0x5C62 }, /* 0xF94B CJK COMPATIBILITY IDEOGRAPH-F94B                                            */
    { 0x6A13 }, /* 0xF94C CJK COMPATIBILITY IDEOGRAPH-F94C                                            */
    { 0x6DDA }, /* 0xF94D CJK COMPATIBILITY IDEOGRAPH-F94D                                            */
    { 0x6F0F }, /* 0xF94E CJK COMPATIBILITY IDEOGRAPH-F94E                                            */
    { 0x7D2F }, /* 0xF94F CJK COMPATIBILITY IDEOGRAPH-F94F                                            */
    { 0x7E37 }, /* 0xF950 CJK COMPATIBILITY IDEOGRAPH-F950                                            */
    { 0x964B }, /* 0xF951 CJK COMPATIBILITY IDEOGRAPH-F951                                            */
    { 0x52D2 }, /* 0xF952 CJK COMPATIBILITY IDEOGRAPH-F952                                            */
    { 0x808B }, /* 0xF953 CJK COMPATIBILITY IDEOGRAPH-F953                                            */
    { 0x51DC }, /* 0xF954 CJK COMPATIBILITY IDEOGRAPH-F954                                            */
    { 0x51CC }, /* 0xF955 CJK COMPATIBILITY IDEOGRAPH-F955                                            */
    { 0x7A1C }, /* 0xF956 CJK COMPATIBILITY IDEOGRAPH-F956                                            */
    { 0x7DBE }, /* 0xF957 CJK COMPATIBILITY IDEOGRAPH-F957                                            */
    { 0x83F1 }, /* 0xF958 CJK COMPATIBILITY IDEOGRAPH-F958                                            */
    { 0x9675 }, /* 0xF959 CJK COMPATIBILITY IDEOGRAPH-F959                                            */
    { 0x8B80 }, /* 0xF95A CJK COMPATIBILITY IDEOGRAPH-F95A                                            */
    { 0x62CF }, /* 0xF95B CJK COMPATIBILITY IDEOGRAPH-F95B                                            */
    { 0x6A02 }, /* 0xF95C CJK COMPATIBILITY IDEOGRAPH-F95C                                            */
    { 0x8AFE }, /* 0xF95D CJK COMPATIBILITY IDEOGRAPH-F95D                                            */
    { 0x4E39 }, /* 0xF95E CJK COMPATIBILITY IDEOGRAPH-F95E                                            */
    { 0x5BE7 }, /* 0xF95F CJK COMPATIBILITY IDEOGRAPH-F95F                                            */
    { 0x6012 }, /* 0xF960 CJK COMPATIBILITY IDEOGRAPH-F960                                            */
    { 0x7387 }, /* 0xF961 CJK COMPATIBILITY IDEOGRAPH-F961                                            */
    { 0x7570 }, /* 0xF962 CJK COMPATIBILITY IDEOGRAPH-F962                                            */
    { 0x5317 }, /* 0xF963 CJK COMPATIBILITY IDEOGRAPH-F963                                            */
    { 0x78FB }, /* 0xF964 CJK COMPATIBILITY IDEOGRAPH-F964                                            */
    { 0x4FBF }, /* 0xF965 CJK COMPATIBILITY IDEOGRAPH-F965                                            */
    { 0x5FA9 }, /* 0xF966 CJK COMPATIBILITY IDEOGRAPH-F966                                            */
    { 0x4E0D }, /* 0xF967 CJK COMPATIBILITY IDEOGRAPH-F967                                            */
    { 0x6CCC }, /* 0xF968 CJK COMPATIBILITY IDEOGRAPH-F968                                            */
    { 0x6578 }, /* 0xF969 CJK COMPATIBILITY IDEOGRAPH-F969                                            */
    { 0x7D22 }, /* 0xF96A CJK COMPATIBILITY IDEOGRAPH-F96A                                            */
    { 0x53C3 }, /* 0xF96B CJK COMPATIBILITY IDEOGRAPH-F96B                                            */
    { 0x585E }, /* 0xF96C CJK COMPATIBILITY IDEOGRAPH-F96C                                            */
    { 0x7701 }, /* 0xF96D CJK COMPATIBILITY IDEOGRAPH-F96D                                            */
    { 0x8449 }, /* 0xF96E CJK COMPATIBILITY IDEOGRAPH-F96E                                            */
    { 0x8AAA }, /* 0xF96F CJK COMPATIBILITY IDEOGRAPH-F96F                                            */
    { 0x6BBA }, /* 0xF970 CJK COMPATIBILITY IDEOGRAPH-F970                                            */
    { 0x8FB0 }, /* 0xF971 CJK COMPATIBILITY IDEOGRAPH-F971                                            */
    { 0x6C88 }, /* 0xF972 CJK COMPATIBILITY IDEOGRAPH-F972                                            */
    { 0x62FE }, /* 0xF973 CJK COMPATIBILITY IDEOGRAPH-F973                                            */
    { 0x82E5 }, /* 0xF974 CJK COMPATIBILITY IDEOGRAPH-F974                                            */
    { 0x63A0 }, /* 0xF975 CJK COMPATIBILITY IDEOGRAPH-F975                                            */
    { 0x7565 }, /* 0xF976 CJK COMPATIBILITY IDEOGRAPH-F976                                            */
    { 0x4EAE }, /* 0xF977 CJK COMPATIBILITY IDEOGRAPH-F977                                            */
    { 0x5169 }, /* 0xF978 CJK COMPATIBILITY IDEOGRAPH-F978                                            */
    { 0x51C9 }, /* 0xF979 CJK COMPATIBILITY IDEOGRAPH-F979                                            */
    { 0x6881 }, /* 0xF97A CJK COMPATIBILITY IDEOGRAPH-F97A                                            */
    { 0x7CE7 }, /* 0xF97B CJK COMPATIBILITY IDEOGRAPH-F97B                                            */
    { 0x826F }, /* 0xF97C CJK COMPATIBILITY IDEOGRAPH-F97C                                            */
    { 0x8AD2 }, /* 0xF97D CJK COMPATIBILITY IDEOGRAPH-F97D                                            */
    { 0x91CF }, /* 0xF97E CJK COMPATIBILITY IDEOGRAPH-F97E                                            */
    { 0x52F5 }, /* 0xF97F CJK COMPATIBILITY IDEOGRAPH-F97F                                            */
    { 0x5442 }, /* 0xF980 CJK COMPATIBILITY IDEOGRAPH-F980                                            */
    { 0x5973 }, /* 0xF981 CJK COMPATIBILITY IDEOGRAPH-F981                                            */
    { 0x5EEC }, /* 0xF982 CJK COMPATIBILITY IDEOGRAPH-F982                                            */
    { 0x65C5 }, /* 0xF983 CJK COMPATIBILITY IDEOGRAPH-F983                                            */
    { 0x6FFE }, /* 0xF984 CJK COMPATIBILITY IDEOGRAPH-F984                                            */
    { 0x792A }, /* 0xF985 CJK COMPATIBILITY IDEOGRAPH-F985                                            */
    { 0x95AD }, /* 0xF986 CJK COMPATIBILITY IDEOGRAPH-F986                                            */
    { 0x9A6A }, /* 0xF987 CJK COMPATIBILITY IDEOGRAPH-F987                                            */
    { 0x9E97 }, /* 0xF988 CJK COMPATIBILITY IDEOGRAPH-F988                                            */
    { 0x9ECE }, /* 0xF989 CJK COMPATIBILITY IDEOGRAPH-F989                                            */
    { 0x529B }, /* 0xF98A CJK COMPATIBILITY IDEOGRAPH-F98A                                            */
    { 0x66C6 }, /* 0xF98B CJK COMPATIBILITY IDEOGRAPH-F98B                                            */
    { 0x6B77 }, /* 0xF98C CJK COMPATIBILITY IDEOGRAPH-F98C                                            */
    { 0x8F62 }, /* 0xF98D CJK COMPATIBILITY IDEOGRAPH-F98D                                            */
    { 0x5E74 }, /* 0xF98E CJK COMPATIBILITY IDEOGRAPH-F98E                                            */
    { 0x6190 }, /* 0xF98F CJK COMPATIBILITY IDEOGRAPH-F98F                                            */
    { 0x6200 }, /* 0xF990 CJK COMPATIBILITY IDEOGRAPH-F990                                            */
    { 0x649A }, /* 0xF991 CJK COMPATIBILITY IDEOGRAPH-F991                                            */
    { 0x6F23 }, /* 0xF992 CJK COMPATIBILITY IDEOGRAPH-F992                                            */
    { 0x7149 }, /* 0xF993 CJK COMPATIBILITY IDEOGRAPH-F993                                            */
    { 0x7489 }, /* 0xF994 CJK COMPATIBILITY IDEOGRAPH-F994                                            */
    { 0x79CA }, /* 0xF995 CJK COMPATIBILITY IDEOGRAPH-F995                                            */
    { 0x7DF4 }, /* 0xF996 CJK COMPATIBILITY IDEOGRAPH-F996                                            */
    { 0x806F }, /* 0xF997 CJK COMPATIBILITY IDEOGRAPH-F997                                            */
    { 0x8F26 }, /* 0xF998 CJK COMPATIBILITY IDEOGRAPH-F998                                            */
    { 0x84EE }, /* 0xF999 CJK COMPATIBILITY IDEOGRAPH-F999                                            */
    { 0x9023 }, /* 0xF99A CJK COMPATIBILITY IDEOGRAPH-F99A                                            */
    { 0x934A }, /* 0xF99B CJK COMPATIBILITY IDEOGRAPH-F99B                                            */
    { 0x5217 }, /* 0xF99C CJK COMPATIBILITY IDEOGRAPH-F99C                                            */
    { 0x52A3 }, /* 0xF99D CJK COMPATIBILITY IDEOGRAPH-F99D                                            */
    { 0x54BD }, /* 0xF99E CJK COMPATIBILITY IDEOGRAPH-F99E                                            */
    { 0x70C8 }, /* 0xF99F CJK COMPATIBILITY IDEOGRAPH-F99F                                            */
    { 0x88C2 }, /* 0xF9A0 CJK COMPATIBILITY IDEOGRAPH-F9A0                                            */
    { 0x8AAA }, /* 0xF9A1 CJK COMPATIBILITY IDEOGRAPH-F9A1                                            */
    { 0x5EC9 }, /* 0xF9A2 CJK COMPATIBILITY IDEOGRAPH-F9A2                                            */
    { 0x5FF5 }, /* 0xF9A3 CJK COMPATIBILITY IDEOGRAPH-F9A3                                            */
    { 0x637B }, /* 0xF9A4 CJK COMPATIBILITY IDEOGRAPH-F9A4                                            */
    { 0x6BAE }, /* 0xF9A5 CJK COMPATIBILITY IDEOGRAPH-F9A5                                            */
    { 0x7C3E }, /* 0xF9A6 CJK COMPATIBILITY IDEOGRAPH-F9A6                                            */
    { 0x7375 }, /* 0xF9A7 CJK COMPATIBILITY IDEOGRAPH-F9A7                                            */
    { 0x4EE4 }, /* 0xF9A8 CJK COMPATIBILITY IDEOGRAPH-F9A8                                            */
    { 0x56F9 }, /* 0xF9A9 CJK COMPATIBILITY IDEOGRAPH-F9A9                                            */
    { 0x5BE7 }, /* 0xF9AA CJK COMPATIBILITY IDEOGRAPH-F9AA                                            */
    { 0x5DBA }, /* 0xF9AB CJK COMPATIBILITY IDEOGRAPH-F9AB                                            */
    { 0x601C }, /* 0xF9AC CJK COMPATIBILITY IDEOGRAPH-F9AC                                            */
    { 0x73B2 }, /* 0xF9AD CJK COMPATIBILITY IDEOGRAPH-F9AD                                            */
    { 0x7469 }, /* 0xF9AE CJK COMPATIBILITY IDEOGRAPH-F9AE                                            */
    { 0x7F9A }, /* 0xF9AF CJK COMPATIBILITY IDEOGRAPH-F9AF                                            */
    { 0x8046 }, /* 0xF9B0 CJK COMPATIBILITY IDEOGRAPH-F9B0                                            */
    { 0x9234 }, /* 0xF9B1 CJK COMPATIBILITY IDEOGRAPH-F9B1                                            */
    { 0x96F6 }, /* 0xF9B2 CJK COMPATIBILITY IDEOGRAPH-F9B2                                            */
    { 0x9748 }, /* 0xF9B3 CJK COMPATIBILITY IDEOGRAPH-F9B3                                            */
    { 0x9818 }, /* 0xF9B4 CJK COMPATIBILITY IDEOGRAPH-F9B4                                            */
    { 0x4F8B }, /* 0xF9B5 CJK COMPATIBILITY IDEOGRAPH-F9B5                                            */
    { 0x79AE }, /* 0xF9B6 CJK COMPATIBILITY IDEOGRAPH-F9B6                                            */
    { 0x91B4 }, /* 0xF9B7 CJK COMPATIBILITY IDEOGRAPH-F9B7                                            */
    { 0x96B8 }, /* 0xF9B8 CJK COMPATIBILITY IDEOGRAPH-F9B8                                            */
    { 0x60E1 }, /* 0xF9B9 CJK COMPATIBILITY IDEOGRAPH-F9B9                                            */
    { 0x4E86 }, /* 0xF9BA CJK COMPATIBILITY IDEOGRAPH-F9BA                                            */
    { 0x50DA }, /* 0xF9BB CJK COMPATIBILITY IDEOGRAPH-F9BB                                            */
    { 0x5BEE }, /* 0xF9BC CJK COMPATIBILITY IDEOGRAPH-F9BC                                            */
    { 0x5C3F }, /* 0xF9BD CJK COMPATIBILITY IDEOGRAPH-F9BD                                            */
    { 0x6599 }, /* 0xF9BE CJK COMPATIBILITY IDEOGRAPH-F9BE                                            */
    { 0x6A02 }, /* 0xF9BF CJK COMPATIBILITY IDEOGRAPH-F9BF                                            */
    { 0x71CE }, /* 0xF9C0 CJK COMPATIBILITY IDEOGRAPH-F9C0                                            */
    { 0x7642 }, /* 0xF9C1 CJK COMPATIBILITY IDEOGRAPH-F9C1                                            */
    { 0x84FC }, /* 0xF9C2 CJK COMPATIBILITY IDEOGRAPH-F9C2                                            */
    { 0x907C }, /* 0xF9C3 CJK COMPATIBILITY IDEOGRAPH-F9C3                                            */
    { 0x9F8D }, /* 0xF9C4 CJK COMPATIBILITY IDEOGRAPH-F9C4                                            */
    { 0x6688 }, /* 0xF9C5 CJK COMPATIBILITY IDEOGRAPH-F9C5                                            */
    { 0x962E }, /* 0xF9C6 CJK COMPATIBILITY IDEOGRAPH-F9C6                                            */
    { 0x5289 }, /* 0xF9C7 CJK COMPATIBILITY IDEOGRAPH-F9C7                                            */
    { 0x677B }, /* 0xF9C8 CJK COMPATIBILITY IDEOGRAPH-F9C8                                            */
    { 0x67F3 }, /* 0xF9C9 CJK COMPATIBILITY IDEOGRAPH-F9C9                                            */
    { 0x6D41 }, /* 0xF9CA CJK COMPATIBILITY IDEOGRAPH-F9CA                                            */
    { 0x6E9C }, /* 0xF9CB CJK COMPATIBILITY IDEOGRAPH-F9CB                                            */
    { 0x7409 }, /* 0xF9CC CJK COMPATIBILITY IDEOGRAPH-F9CC                                            */
    { 0x7559 }, /* 0xF9CD CJK COMPATIBILITY IDEOGRAPH-F9CD                                            */
    { 0x786B }, /* 0xF9CE CJK COMPATIBILITY IDEOGRAPH-F9CE                                            */
    { 0x7D10 }, /* 0xF9CF CJK COMPATIBILITY IDEOGRAPH-F9CF                                            */
    { 0x985E }, /* 0xF9D0 CJK COMPATIBILITY IDEOGRAPH-F9D0                                            */
    { 0x516D }, /* 0xF9D1 CJK COMPATIBILITY IDEOGRAPH-F9D1                                            */
    { 0x622E }, /* 0xF9D2 CJK COMPATIBILITY IDEOGRAPH-F9D2                                            */
    { 0x9678 }, /* 0xF9D3 CJK COMPATIBILITY IDEOGRAPH-F9D3                                            */
    { 0x502B }, /* 0xF9D4 CJK COMPATIBILITY IDEOGRAPH-F9D4                                            */
    { 0x5D19 }, /* 0xF9D5 CJK COMPATIBILITY IDEOGRAPH-F9D5                                            */
    { 0x6DEA }, /* 0xF9D6 CJK COMPATIBILITY IDEOGRAPH-F9D6                                            */
    { 0x8F2A }, /* 0xF9D7 CJK COMPATIBILITY IDEOGRAPH-F9D7                                            */
    { 0x5F8B }, /* 0xF9D8 CJK COMPATIBILITY IDEOGRAPH-F9D8                                            */
    { 0x6144 }, /* 0xF9D9 CJK COMPATIBILITY IDEOGRAPH-F9D9                                            */
    { 0x6817 }, /* 0xF9DA CJK COMPATIBILITY IDEOGRAPH-F9DA                                            */
    { 0x7387 }, /* 0xF9DB CJK COMPATIBILITY IDEOGRAPH-F9DB                                            */
    { 0x9686 }, /* 0xF9DC CJK COMPATIBILITY IDEOGRAPH-F9DC                                            */
    { 0x5229 }, /* 0xF9DD CJK COMPATIBILITY IDEOGRAPH-F9DD                                            */
    { 0x540F }, /* 0xF9DE CJK COMPATIBILITY IDEOGRAPH-F9DE                                            */
    { 0x5C65 }, /* 0xF9DF CJK COMPATIBILITY IDEOGRAPH-F9DF                                            */
    { 0x6613 }, /* 0xF9E0 CJK COMPATIBILITY IDEOGRAPH-F9E0                                            */
    { 0x674E }, /* 0xF9E1 CJK COMPATIBILITY IDEOGRAPH-F9E1                                            */
    { 0x68A8 }, /* 0xF9E2 CJK COMPATIBILITY IDEOGRAPH-F9E2                                            */
    { 0x6CE5 }, /* 0xF9E3 CJK COMPATIBILITY IDEOGRAPH-F9E3                                            */
    { 0x7406 }, /* 0xF9E4 CJK COMPATIBILITY IDEOGRAPH-F9E4                                            */
    { 0x75E2 }, /* 0xF9E5 CJK COMPATIBILITY IDEOGRAPH-F9E5                                            */
    { 0x7F79 }, /* 0xF9E6 CJK COMPATIBILITY IDEOGRAPH-F9E6                                            */
    { 0x88CF }, /* 0xF9E7 CJK COMPATIBILITY IDEOGRAPH-F9E7                                            */
    { 0x88E1 }, /* 0xF9E8 CJK COMPATIBILITY IDEOGRAPH-F9E8                                            */
    { 0x91CC }, /* 0xF9E9 CJK COMPATIBILITY IDEOGRAPH-F9E9                                            */
    { 0x96E2 }, /* 0xF9EA CJK COMPATIBILITY IDEOGRAPH-F9EA                                            */
    { 0x533F }, /* 0xF9EB CJK COMPATIBILITY IDEOGRAPH-F9EB                                            */
    { 0x6EBA }, /* 0xF9EC CJK COMPATIBILITY IDEOGRAPH-F9EC                                            */
    { 0x541D }, /* 0xF9ED CJK COMPATIBILITY IDEOGRAPH-F9ED                                            */
    { 0x71D0 }, /* 0xF9EE CJK COMPATIBILITY IDEOGRAPH-F9EE                                            */
    { 0x7498 }, /* 0xF9EF CJK COMPATIBILITY IDEOGRAPH-F9EF                                            */
    { 0x85FA }, /* 0xF9F0 CJK COMPATIBILITY IDEOGRAPH-F9F0                                            */
    { 0x96A3 }, /* 0xF9F1 CJK COMPATIBILITY IDEOGRAPH-F9F1                                            */
    { 0x9C57 }, /* 0xF9F2 CJK COMPATIBILITY IDEOGRAPH-F9F2                                            */
    { 0x9E9F }, /* 0xF9F3 CJK COMPATIBILITY IDEOGRAPH-F9F3                                            */
    { 0x6797 }, /* 0xF9F4 CJK COMPATIBILITY IDEOGRAPH-F9F4                                            */
    { 0x6DCB }, /* 0xF9F5 CJK COMPATIBILITY IDEOGRAPH-F9F5                                            */
    { 0x81E8 }, /* 0xF9F6 CJK COMPATIBILITY IDEOGRAPH-F9F6                                            */
    { 0x7ACB }, /* 0xF9F7 CJK COMPATIBILITY IDEOGRAPH-F9F7                                            */
    { 0x7B20 }, /* 0xF9F8 CJK COMPATIBILITY IDEOGRAPH-F9F8                                            */
    { 0x7C92 }, /* 0xF9F9 CJK COMPATIBILITY IDEOGRAPH-F9F9                                            */
    { 0x72C0 }, /* 0xF9FA CJK COMPATIBILITY IDEOGRAPH-F9FA                                            */
    { 0x7099 }, /* 0xF9FB CJK COMPATIBILITY IDEOGRAPH-F9FB                                            */
    { 0x8B58 }, /* 0xF9FC CJK COMPATIBILITY IDEOGRAPH-F9FC                                            */
    { 0x4EC0 }, /* 0xF9FD CJK COMPATIBILITY IDEOGRAPH-F9FD                                            */
    { 0x8336 }, /* 0xF9FE CJK COMPATIBILITY IDEOGRAPH-F9FE                                            */
    { 0x523A }, /* 0xF9FF CJK COMPATIBILITY IDEOGRAPH-F9FF                                            */
    { 0x5207 }, /* 0xFA00 CJK COMPATIBILITY IDEOGRAPH-FA00                                            */
    { 0x5EA6 }, /* 0xFA01 CJK COMPATIBILITY IDEOGRAPH-FA01                                            */
    { 0x62D3 }, /* 0xFA02 CJK COMPATIBILITY IDEOGRAPH-FA02                                            */
    { 0x7CD6 }, /* 0xFA03 CJK COMPATIBILITY IDEOGRAPH-FA03                                            */
    { 0x5B85 }, /* 0xFA04 CJK COMPATIBILITY IDEOGRAPH-FA04                                            */
    { 0x6D1E }, /* 0xFA05 CJK COMPATIBILITY IDEOGRAPH-FA05                                            */
    { 0x66B4 }, /* 0xFA06 CJK COMPATIBILITY IDEOGRAPH-FA06                                            */
    { 0x8F3B }, /* 0xFA07 CJK COMPATIBILITY IDEOGRAPH-FA07                                            */
    { 0x884C }, /* 0xFA08 CJK COMPATIBILITY IDEOGRAPH-FA08                                            */
    { 0x964D }, /* 0xFA09 CJK COMPATIBILITY IDEOGRAPH-FA09                                            */
    { 0x898B }, /* 0xFA0A CJK COMPATIBILITY IDEOGRAPH-FA0A                                            */
    { 0x5ED3 }, /* 0xFA0B CJK COMPATIBILITY IDEOGRAPH-FA0B                                            */
    { 0x5140 }, /* 0xFA0C CJK COMPATIBILITY IDEOGRAPH-FA0C                                            */
    { 0x55C0 }, /* 0xFA0D CJK COMPATIBILITY IDEOGRAPH-FA0D                                            */
    { 0x0000 }, /* 0xFA0E --- padding ---                                                             */
    { 0x0000 }, /* 0xFA0F --- padding ---                                                             */
    { 0x585A }, /* 0xFA10 CJK COMPATIBILITY IDEOGRAPH-FA10                                            */
    { 0x0000 }, /* 0xFA11 --- padding ---                                                             */
    { 0x6674 }, /* 0xFA12 CJK COMPATIBILITY IDEOGRAPH-FA12                                            */
    { 0x0000 }, /* 0xFA13 --- padding ---                                                             */
    { 0x0000 }, /* 0xFA14 --- padding ---                                                             */
    { 0x51DE }, /* 0xFA15 CJK COMPATIBILITY IDEOGRAPH-FA15                                            */
    { 0x732A }, /* 0xFA16 CJK COMPATIBILITY IDEOGRAPH-FA16                                            */
    { 0x76CA }, /* 0xFA17 CJK COMPATIBILITY IDEOGRAPH-FA17                                            */
    { 0x793C }, /* 0xFA18 CJK COMPATIBILITY IDEOGRAPH-FA18                                            */
    { 0x795E }, /* 0xFA19 CJK COMPATIBILITY IDEOGRAPH-FA19                                            */
    { 0x7965 }, /* 0xFA1A CJK COMPATIBILITY IDEOGRAPH-FA1A                                            */
    { 0x798F }, /* 0xFA1B CJK COMPATIBILITY IDEOGRAPH-FA1B                                            */
    { 0x9756 }, /* 0xFA1C CJK COMPATIBILITY IDEOGRAPH-FA1C                                            */
    { 0x7CBE }, /* 0xFA1D CJK COMPATIBILITY IDEOGRAPH-FA1D                                            */
    { 0x7FBD }, /* 0xFA1E CJK COMPATIBILITY IDEOGRAPH-FA1E                                            */
    { 0x0000 }, /* 0xFA1F --- padding ---                                                             */
    { 0x8612 }, /* 0xFA20 CJK COMPATIBILITY IDEOGRAPH-FA20                                            */
    { 0x0000 }, /* 0xFA21 --- padding ---                                                             */
    { 0x8AF8 }, /* 0xFA22 CJK COMPATIBILITY IDEOGRAPH-FA22                                            */
    { 0x0000 }, /* 0xFA23 --- padding ---                                                             */
    { 0x0000 }, /* 0xFA24 --- padding ---                                                             */
    { 0x9038 }, /* 0xFA25 CJK COMPATIBILITY IDEOGRAPH-FA25                                            */
    { 0x90FD }, /* 0xFA26 CJK COMPATIBILITY IDEOGRAPH-FA26                                            */
    { 0x0000 }, /* 0xFA27 --- padding ---                                                             */
    { 0x0000 }, /* 0xFA28 --- padding ---                                                             */
    { 0x0000 }, /* 0xFA29 --- padding ---                                                             */
    { 0x98EF }, /* 0xFA2A CJK COMPATIBILITY IDEOGRAPH-FA2A                                            */
    { 0x98FC }, /* 0xFA2B CJK COMPATIBILITY IDEOGRAPH-FA2B                                            */
    { 0x9928 }, /* 0xFA2C CJK COMPATIBILITY IDEOGRAPH-FA2C                                            */
    { 0x9DB4 }, /* 0xFA2D CJK COMPATIBILITY IDEOGRAPH-FA2D                                            */
    { 0x90DE }, /* 0xFA2E CJK COMPATIBILITY IDEOGRAPH-FA2E                                            */
    { 0x96B7 }, /* 0xFA2F CJK COMPATIBILITY IDEOGRAPH-FA2F                                            */
    { 0x4FAE }, /* 0xFA30 CJK COMPATIBILITY IDEOGRAPH-FA30                                            */
    { 0x50E7 }, /* 0xFA31 CJK COMPATIBILITY IDEOGRAPH-FA31                                            */
    { 0x514D }, /* 0xFA32 CJK COMPATIBILITY IDEOGRAPH-FA32                                            */
    { 0x52C9 }, /* 0xFA33 CJK COMPATIBILITY IDEOGRAPH-FA33                                            */
    { 0x52E4 }, /* 0xFA34 CJK COMPATIBILITY IDEOGRAPH-FA34                                            */
    { 0x5351 }, /* 0xFA35 CJK COMPATIBILITY IDEOGRAPH-FA35                                            */
    { 0x559D }, /* 0xFA36 CJK COMPATIBILITY IDEOGRAPH-FA36                                            */
    { 0x5606 }, /* 0xFA37 CJK COMPATIBILITY IDEOGRAPH-FA37                                            */
    { 0x5668 }, /* 0xFA38 CJK COMPATIBILITY IDEOGRAPH-FA38                                            */
    { 0x5840 }, /* 0xFA39 CJK COMPATIBILITY IDEOGRAPH-FA39                                            */
    { 0x58A8 }, /* 0xFA3A CJK COMPATIBILITY IDEOGRAPH-FA3A                                            */
    { 0x5C64 }, /* 0xFA3B CJK COMPATIBILITY IDEOGRAPH-FA3B                                            */
    { 0x5C6E }, /* 0xFA3C CJK COMPATIBILITY IDEOGRAPH-FA3C                                            */
    { 0x6094 }, /* 0xFA3D CJK COMPATIBILITY IDEOGRAPH-FA3D                                            */
    { 0x6168 }, /* 0xFA3E CJK COMPATIBILITY IDEOGRAPH-FA3E                                            */
    { 0x618E }, /* 0xFA3F CJK COMPATIBILITY IDEOGRAPH-FA3F                                            */
    { 0x61F2 }, /* 0xFA40 CJK COMPATIBILITY IDEOGRAPH-FA40                                            */
    { 0x654F }, /* 0xFA41 CJK COMPATIBILITY IDEOGRAPH-FA41                                            */
    { 0x65E2 }, /* 0xFA42 CJK COMPATIBILITY IDEOGRAPH-FA42                                            */
    { 0x6691 }, /* 0xFA43 CJK COMPATIBILITY IDEOGRAPH-FA43                                            */
    { 0x6885 }, /* 0xFA44 CJK COMPATIBILITY IDEOGRAPH-FA44                                            */
    { 0x6D77 }, /* 0xFA45 CJK COMPATIBILITY IDEOGRAPH-FA45                                            */
    { 0x6E1A }, /* 0xFA46 CJK COMPATIBILITY IDEOGRAPH-FA46                                            */
    { 0x6F22 }, /* 0xFA47 CJK COMPATIBILITY IDEOGRAPH-FA47                                            */
    { 0x716E }, /* 0xFA48 CJK COMPATIBILITY IDEOGRAPH-FA48                                            */
    { 0x722B }, /* 0xFA49 CJK COMPATIBILITY IDEOGRAPH-FA49                                            */
    { 0x7422 }, /* 0xFA4A CJK COMPATIBILITY IDEOGRAPH-FA4A                                            */
    { 0x7891 }, /* 0xFA4B CJK COMPATIBILITY IDEOGRAPH-FA4B                                            */
    { 0x793E }, /* 0xFA4C CJK COMPATIBILITY IDEOGRAPH-FA4C                                            */
    { 0x7949 }, /* 0xFA4D CJK COMPATIBILITY IDEOGRAPH-FA4D                                            */
    { 0x7948 }, /* 0xFA4E CJK COMPATIBILITY IDEOGRAPH-FA4E                                            */
    { 0x7950 }, /* 0xFA4F CJK COMPATIBILITY IDEOGRAPH-FA4F                                            */
    { 0x7956 }, /* 0xFA50 CJK COMPATIBILITY IDEOGRAPH-FA50                                            */
    { 0x795D }, /* 0xFA51 CJK COMPATIBILITY IDEOGRAPH-FA51                                            */
    { 0x798D }, /* 0xFA52 CJK COMPATIBILITY IDEOGRAPH-FA52                                            */
    { 0x798E }, /* 0xFA53 CJK COMPATIBILITY IDEOGRAPH-FA53                                            */
    { 0x7A40 }, /* 0xFA54 CJK COMPATIBILITY IDEOGRAPH-FA54                                            */
    { 0x7A81 }, /* 0xFA55 CJK COMPATIBILITY IDEOGRAPH-FA55                                            */
    { 0x7BC0 }, /* 0xFA56 CJK COMPATIBILITY IDEOGRAPH-FA56                                            */
    { 0x7DF4 }, /* 0xFA57 CJK COMPATIBILITY IDEOGRAPH-FA57                                            */
    { 0x7E09 }, /* 0xFA58 CJK COMPATIBILITY IDEOGRAPH-FA58                                            */
    { 0x7E41 }, /* 0xFA59 CJK COMPATIBILITY IDEOGRAPH-FA59                                            */
    { 0x7F72 }, /* 0xFA5A CJK COMPATIBILITY IDEOGRAPH-FA5A                                            */
    { 0x8005 }, /* 0xFA5B CJK COMPATIBILITY IDEOGRAPH-FA5B                                            */
    { 0x81ED }, /* 0xFA5C CJK COMPATIBILITY IDEOGRAPH-FA5C                                            */
    { 0x8279 }, /* 0xFA5D CJK COMPATIBILITY IDEOGRAPH-FA5D                                            */
    { 0x8279 }, /* 0xFA5E CJK COMPATIBILITY IDEOGRAPH-FA5E                                            */
    { 0x8457 }, /* 0xFA5F CJK COMPATIBILITY IDEOGRAPH-FA5F                                            */
    { 0x8910 }, /* 0xFA60 CJK COMPATIBILITY IDEOGRAPH-FA60                                            */
    { 0x8996 }, /* 0xFA61 CJK COMPATIBILITY IDEOGRAPH-FA61                                            */
    { 0x8B01 }, /* 0xFA62 CJK COMPATIBILITY IDEOGRAPH-FA62                                            */
    { 0x8B39 }, /* 0xFA63 CJK COMPATIBILITY IDEOGRAPH-FA63                                            */
    { 0x8CD3 }, /* 0xFA64 CJK COMPATIBILITY IDEOGRAPH-FA64                                            */
    { 0x8D08 }, /* 0xFA65 CJK COMPATIBILITY IDEOGRAPH-FA65                                            */
    { 0x8FB6 }, /* 0xFA66 CJK COMPATIBILITY IDEOGRAPH-FA66                                            */
    { 0x9038 }, /* 0xFA67 CJK COMPATIBILITY IDEOGRAPH-FA67                                            */
    { 0x96E3 }, /* 0xFA68 CJK COMPATIBILITY IDEOGRAPH-FA68                                            */
    { 0x97FF }, /* 0xFA69 CJK COMPATIBILITY IDEOGRAPH-FA69                                            */
    { 0x983B }, /* 0xFA6A CJK COMPATIBILITY IDEOGRAPH-FA6A                                            */
    { 0x6075 }, /* 0xFA6B CJK COMPATIBILITY IDEOGRAPH-FA6B                                            */
    /* ---- index: 364 ---- */
    { 0x8218 }, /* 0xFA6D CJK COMPATIBILITY IDEOGRAPH-FA6D                                            */
    { 0x0000 }, /* 0xFA6E --- padding ---                                                             */
    { 0x0000 }, /* 0xFA6F --- padding ---                                                             */
    { 0x4E26 }, /* 0xFA70 CJK COMPATIBILITY IDEOGRAPH-FA70                                            */
    { 0x51B5 }, /* 0xFA71 CJK COMPATIBILITY IDEOGRAPH-FA71                                            */
    { 0x5168 }, /* 0xFA72 CJK COMPATIBILITY IDEOGRAPH-FA72                                            */
    { 0x4F80 }, /* 0xFA73 CJK COMPATIBILITY IDEOGRAPH-FA73                                            */
    { 0x5145 }, /* 0xFA74 CJK COMPATIBILITY IDEOGRAPH-FA74                                            */
    { 0x5180 }, /* 0xFA75 CJK COMPATIBILITY IDEOGRAPH-FA75                                            */
    { 0x52C7 }, /* 0xFA76 CJK COMPATIBILITY IDEOGRAPH-FA76                                            */
    { 0x52FA }, /* 0xFA77 CJK COMPATIBILITY IDEOGRAPH-FA77                                            */
    { 0x559D }, /* 0xFA78 CJK COMPATIBILITY IDEOGRAPH-FA78                                            */
    { 0x5555 }, /* 0xFA79 CJK COMPATIBILITY IDEOGRAPH-FA79                                            */
    { 0x5599 }, /* 0xFA7A CJK COMPATIBILITY IDEOGRAPH-FA7A                                            */
    { 0x55E2 }, /* 0xFA7B CJK COMPATIBILITY IDEOGRAPH-FA7B                                            */
    { 0x585A }, /* 0xFA7C CJK COMPATIBILITY IDEOGRAPH-FA7C                                            */
    { 0x58B3 }, /* 0xFA7D CJK COMPATIBILITY IDEOGRAPH-FA7D                                            */
    { 0x5944 }, /* 0xFA7E CJK COMPATIBILITY IDEOGRAPH-FA7E                                            */
    { 0x5954 }, /* 0xFA7F CJK COMPATIBILITY IDEOGRAPH-FA7F                                            */
    { 0x5A62 }, /* 0xFA80 CJK COMPATIBILITY IDEOGRAPH-FA80                                            */
    { 0x5B28 }, /* 0xFA81 CJK COMPATIBILITY IDEOGRAPH-FA81                                            */
    { 0x5ED2 }, /* 0xFA82 CJK COMPATIBILITY IDEOGRAPH-FA82                                            */
    { 0x5ED9 }, /* 0xFA83 CJK COMPATIBILITY IDEOGRAPH-FA83                                            */
    { 0x5F69 }, /* 0xFA84 CJK COMPATIBILITY IDEOGRAPH-FA84                                            */
    { 0x5FAD }, /* 0xFA85 CJK COMPATIBILITY IDEOGRAPH-FA85                                            */
    { 0x60D8 }, /* 0xFA86 CJK COMPATIBILITY IDEOGRAPH-FA86                                            */
    { 0x614E }, /* 0xFA87 CJK COMPATIBILITY IDEOGRAPH-FA87                                            */
    { 0x6108 }, /* 0xFA88 CJK COMPATIBILITY IDEOGRAPH-FA88                                            */
    { 0x618E }, /* 0xFA89 CJK COMPATIBILITY IDEOGRAPH-FA89                                            */
    { 0x6160 }, /* 0xFA8A CJK COMPATIBILITY IDEOGRAPH-FA8A                                            */
    { 0x61F2 }, /* 0xFA8B CJK COMPATIBILITY IDEOGRAPH-FA8B                                            */
    { 0x6234 }, /* 0xFA8C CJK COMPATIBILITY IDEOGRAPH-FA8C                                            */
    { 0x63C4 }, /* 0xFA8D CJK COMPATIBILITY IDEOGRAPH-FA8D                                            */
    { 0x641C }, /* 0xFA8E CJK COMPATIBILITY IDEOGRAPH-FA8E                                            */
    { 0x6452 }, /* 0xFA8F CJK COMPATIBILITY IDEOGRAPH-FA8F                                            */
    { 0x6556 }, /* 0xFA90 CJK COMPATIBILITY IDEOGRAPH-FA90                                            */
    { 0x6674 }, /* 0xFA91 CJK COMPATIBILITY IDEOGRAPH-FA91                                            */
    { 0x6717 }, /* 0xFA92 CJK COMPATIBILITY IDEOGRAPH-FA92                                            */
    { 0x671B }, /* 0xFA93 CJK COMPATIBILITY IDEOGRAPH-FA93                                            */
    { 0x6756 }, /* 0xFA94 CJK COMPATIBILITY IDEOGRAPH-FA94                                            */
    { 0x6B79 }, /* 0xFA95 CJK COMPATIBILITY IDEOGRAPH-FA95                                            */
    { 0x6BBA }, /* 0xFA96 CJK COMPATIBILITY IDEOGRAPH-FA96                                            */
    { 0x6D41 }, /* 0xFA97 CJK COMPATIBILITY IDEOGRAPH-FA97                                            */
    { 0x6EDB }, /* 0xFA98 CJK COMPATIBILITY IDEOGRAPH-FA98                                            */
    { 0x6ECB }, /* 0xFA99 CJK COMPATIBILITY IDEOGRAPH-FA99                                            */
    { 0x6F22 }, /* 0xFA9A CJK COMPATIBILITY IDEOGRAPH-FA9A                                            */
    { 0x701E }, /* 0xFA9B CJK COMPATIBILITY IDEOGRAPH-FA9B                                            */
    { 0x716E }, /* 0xFA9C CJK COMPATIBILITY IDEOGRAPH-FA9C                                            */
    { 0x77A7 }, /* 0xFA9D CJK COMPATIBILITY IDEOGRAPH-FA9D                                            */
    { 0x7235 }, /* 0xFA9E CJK COMPATIBILITY IDEOGRAPH-FA9E                                            */
    { 0x72AF }, /* 0xFA9F CJK COMPATIBILITY IDEOGRAPH-FA9F                                            */
    { 0x732A }, /* 0xFAA0 CJK COMPATIBILITY IDEOGRAPH-FAA0                                            */
    { 0x7471 }, /* 0xFAA1 CJK COMPATIBILITY IDEOGRAPH-FAA1                                            */
    { 0x7506 }, /* 0xFAA2 CJK COMPATIBILITY IDEOGRAPH-FAA2                                            */
    { 0x753B }, /* 0xFAA3 CJK COMPATIBILITY IDEOGRAPH-FAA3                                            */
    { 0x761D }, /* 0xFAA4 CJK COMPATIBILITY IDEOGRAPH-FAA4                                            */
    { 0x761F }, /* 0xFAA5 CJK COMPATIBILITY IDEOGRAPH-FAA5                                            */
    { 0x76CA }, /* 0xFAA6 CJK COMPATIBILITY IDEOGRAPH-FAA6                                            */
    { 0x76DB }, /* 0xFAA7 CJK COMPATIBILITY IDEOGRAPH-FAA7                                            */
    { 0x76F4 }, /* 0xFAA8 CJK COMPATIBILITY IDEOGRAPH-FAA8                                            */
    { 0x774A }, /* 0xFAA9 CJK COMPATIBILITY IDEOGRAPH-FAA9                                            */
    { 0x7740 }, /* 0xFAAA CJK COMPATIBILITY IDEOGRAPH-FAAA                                            */
    { 0x78CC }, /* 0xFAAB CJK COMPATIBILITY IDEOGRAPH-FAAB                                            */
    { 0x7AB1 }, /* 0xFAAC CJK COMPATIBILITY IDEOGRAPH-FAAC                                            */
    { 0x7BC0 }, /* 0xFAAD CJK COMPATIBILITY IDEOGRAPH-FAAD                                            */
    { 0x7C7B }, /* 0xFAAE CJK COMPATIBILITY IDEOGRAPH-FAAE                                            */
    { 0x7D5B }, /* 0xFAAF CJK COMPATIBILITY IDEOGRAPH-FAAF                                            */
    { 0x7DF4 }, /* 0xFAB0 CJK COMPATIBILITY IDEOGRAPH-FAB0                                            */
    { 0x7F3E }, /* 0xFAB1 CJK COMPATIBILITY IDEOGRAPH-FAB1                                            */
    { 0x8005 }, /* 0xFAB2 CJK COMPATIBILITY IDEOGRAPH-FAB2                                            */
    { 0x8352 }, /* 0xFAB3 CJK COMPATIBILITY IDEOGRAPH-FAB3                                            */
    { 0x83EF }, /* 0xFAB4 CJK COMPATIBILITY IDEOGRAPH-FAB4                                            */
    { 0x8779 }, /* 0xFAB5 CJK COMPATIBILITY IDEOGRAPH-FAB5                                            */
    { 0x8941 }, /* 0xFAB6 CJK COMPATIBILITY IDEOGRAPH-FAB6                                            */
    { 0x8986 }, /* 0xFAB7 CJK COMPATIBILITY IDEOGRAPH-FAB7                                            */
    { 0x8996 }, /* 0xFAB8 CJK COMPATIBILITY IDEOGRAPH-FAB8                                            */
    { 0x8ABF }, /* 0xFAB9 CJK COMPATIBILITY IDEOGRAPH-FAB9                                            */
    { 0x8AF8 }, /* 0xFABA CJK COMPATIBILITY IDEOGRAPH-FABA                                            */
    { 0x8ACB }, /* 0xFABB CJK COMPATIBILITY IDEOGRAPH-FABB                                            */
    { 0x8B01 }, /* 0xFABC CJK COMPATIBILITY IDEOGRAPH-FABC                                            */
    { 0x8AFE }, /* 0xFABD CJK COMPATIBILITY IDEOGRAPH-FABD                                            */
    { 0x8AED }, /* 0xFABE CJK COMPATIBILITY IDEOGRAPH-FABE                                            */
    { 0x8B39 }, /* 0xFABF CJK COMPATIBILITY IDEOGRAPH-FABF                                            */
    { 0x8B8A }, /* 0xFAC0 CJK COMPATIBILITY IDEOGRAPH-FAC0                                            */
    { 0x8D08 }, /* 0xFAC1 CJK COMPATIBILITY IDEOGRAPH-FAC1                                            */
    { 0x8F38 }, /* 0xFAC2 CJK COMPATIBILITY IDEOGRAPH-FAC2                                            */
    { 0x9072 }, /* 0xFAC3 CJK COMPATIBILITY IDEOGRAPH-FAC3                                            */
    { 0x9199 }, /* 0xFAC4 CJK COMPATIBILITY IDEOGRAPH-FAC4                                            */
    { 0x9276 }, /* 0xFAC5 CJK COMPATIBILITY IDEOGRAPH-FAC5                                            */
    { 0x967C }, /* 0xFAC6 CJK COMPATIBILITY IDEOGRAPH-FAC6                                            */
    { 0x96E3 }, /* 0xFAC7 CJK COMPATIBILITY IDEOGRAPH-FAC7                                            */
    { 0x9756 }, /* 0xFAC8 CJK COMPATIBILITY IDEOGRAPH-FAC8                                            */
    { 0x97DB }, /* 0xFAC9 CJK COMPATIBILITY IDEOGRAPH-FAC9                                            */
    { 0x97FF }, /* 0xFACA CJK COMPATIBILITY IDEOGRAPH-FACA                                            */
    { 0x980B }, /* 0xFACB CJK COMPATIBILITY IDEOGRAPH-FACB                                            */
    { 0x983B }, /* 0xFACC CJK COMPATIBILITY IDEOGRAPH-FACC                                            */
    { 0x9B12 }, /* 0xFACD CJK COMPATIBILITY IDEOGRAPH-FACD                                            */
    { 0x9F9C }, /* 0xFACE CJK COMPATIBILITY IDEOGRAPH-FACE                                            */
    /* ---- index: 462 ---- */
    { 0x9F43 }, /* 0xFAD8 CJK COMPATIBILITY IDEOGRAPH-FAD8                                            */
    { 0x9F8E }, /* 0xFAD9 CJK COMPATIBILITY IDEOGRAPH-FAD9                                            */
    /* ---- index: 464 ---- */
    { 0x4E3D }, /* 0x2F800 CJK COMPATIBILITY IDEOGRAPH-2F800                                           */
    { 0x4E38 }, /* 0x2F801 CJK COMPATIBILITY IDEOGRAPH-2F801                                           */
    { 0x4E41 }, /* 0x2F802 CJK COMPATIBILITY IDEOGRAPH-2F802                                           */
    /* ---- index: 467 ---- */
    { 0x4F60 }, /* 0x2F804 CJK COMPATIBILITY IDEOGRAPH-2F804                                           */
    { 0x4FAE }, /* 0x2F805 CJK COMPATIBILITY IDEOGRAPH-2F805                                           */
    { 0x4FBB }, /* 0x2F806 CJK COMPATIBILITY IDEOGRAPH-2F806                                           */
    { 0x5002 }, /* 0x2F807 CJK COMPATIBILITY IDEOGRAPH-2F807                                           */
    { 0x507A }, /* 0x2F808 CJK COMPATIBILITY IDEOGRAPH-2F808                                           */
    { 0x5099 }, /* 0x2F809 CJK COMPATIBILITY IDEOGRAPH-2F809                                           */
    { 0x50E7 }, /* 0x2F80A CJK COMPATIBILITY IDEOGRAPH-2F80A                                           */
    { 0x50CF }, /* 0x2F80B CJK COMPATIBILITY IDEOGRAPH-2F80B                                           */
    { 0x349E }, /* 0x2F80C CJK COMPATIBILITY IDEOGRAPH-2F80C                                           */
    /* ---- index: 476 ---- */
    { 0x51F5 }, /* 0x2F81D CJK COMPATIBILITY IDEOGRAPH-2F81D                                           */
    { 0x5203 }, /* 0x2F81E CJK COMPATIBILITY IDEOGRAPH-2F81E                                           */
    { 0x34DF }, /* 0x2F81F CJK COMPATIBILITY IDEOGRAPH-2F81F                                           */
    { 0x523B }, /* 0x2F820 CJK COMPATIBILITY IDEOGRAPH-2F820                                           */
    { 0x5246 }, /* 0x2F821 CJK COMPATIBILITY IDEOGRAPH-2F821                                           */
    { 0x5272 }, /* 0x2F822 CJK COMPATIBILITY IDEOGRAPH-2F822                                           */
    { 0x5277 }, /* 0x2F823 CJK COMPATIBILITY IDEOGRAPH-2F823                                           */
    { 0x3515 }, /* 0x2F824 CJK COMPATIBILITY IDEOGRAPH-2F824                                           */
    { 0x52C7 }, /* 0x2F825 CJK COMPATIBILITY IDEOGRAPH-2F825                                           */
    { 0x52C9 }, /* 0x2F826 CJK COMPATIBILITY IDEOGRAPH-2F826                                           */
    { 0x52E4 }, /* 0x2F827 CJK COMPATIBILITY IDEOGRAPH-2F827                                           */
    { 0x52FA }, /* 0x2F828 CJK COMPATIBILITY IDEOGRAPH-2F828                                           */
    { 0x5305 }, /* 0x2F829 CJK COMPATIBILITY IDEOGRAPH-2F829                                           */
    { 0x5306 }, /* 0x2F82A CJK COMPATIBILITY IDEOGRAPH-2F82A                                           */
    { 0x5317 }, /* 0x2F82B CJK COMPATIBILITY IDEOGRAPH-2F82B                                           */
    { 0x5349 }, /* 0x2F82C CJK COMPATIBILITY IDEOGRAPH-2F82C                                           */
    { 0x5351 }, /* 0x2F82D CJK COMPATIBILITY IDEOGRAPH-2F82D                                           */
    { 0x535A }, /* 0x2F82E CJK COMPATIBILITY IDEOGRAPH-2F82E                                           */
    { 0x5373 }, /* 0x2F82F CJK COMPATIBILITY IDEOGRAPH-2F82F                                           */
    { 0x537D }, /* 0x2F830 CJK COMPATIBILITY IDEOGRAPH-2F830                                           */
    { 0x537F }, /* 0x2F831 CJK COMPATIBILITY IDEOGRAPH-2F831                                           */
    { 0x537F }, /* 0x2F832 CJK COMPATIBILITY IDEOGRAPH-2F832                                           */
    { 0x537F }, /* 0x2F833 CJK COMPATIBILITY IDEOGRAPH-2F833                                           */
    /* ---- index: 499 ---- */
    { 0x53EB }, /* 0x2F839 CJK COMPATIBILITY IDEOGRAPH-2F839                                           */
    { 0x53F1 }, /* 0x2F83A CJK COMPATIBILITY IDEOGRAPH-2F83A                                           */
    { 0x5406 }, /* 0x2F83B CJK COMPATIBILITY IDEOGRAPH-2F83B                                           */
    { 0x549E }, /* 0x2F83C CJK COMPATIBILITY IDEOGRAPH-2F83C                                           */
    { 0x5438 }, /* 0x2F83D CJK COMPATIBILITY IDEOGRAPH-2F83D                                           */
    { 0x5448 }, /* 0x2F83E CJK COMPATIBILITY IDEOGRAPH-2F83E                                           */
    { 0x5468 }, /* 0x2F83F CJK COMPATIBILITY IDEOGRAPH-2F83F                                           */
    { 0x54A2 }, /* 0x2F840 CJK COMPATIBILITY IDEOGRAPH-2F840                                           */
    { 0x54F6 }, /* 0x2F841 CJK COMPATIBILITY IDEOGRAPH-2F841                                           */
    { 0x5510 }, /* 0x2F842 CJK COMPATIBILITY IDEOGRAPH-2F842                                           */
    { 0x5553 }, /* 0x2F843 CJK COMPATIBILITY IDEOGRAPH-2F843                                           */
    { 0x5563 }, /* 0x2F844 CJK COMPATIBILITY IDEOGRAPH-2F844                                           */
    { 0x5584 }, /* 0x2F845 CJK COMPATIBILITY IDEOGRAPH-2F845                                           */
    { 0x5584 }, /* 0x2F846 CJK COMPATIBILITY IDEOGRAPH-2F846                                           */
    { 0x5599 }, /* 0x2F847 CJK COMPATIBILITY IDEOGRAPH-2F847                                           */
    { 0x55AB }, /* 0x2F848 CJK COMPATIBILITY IDEOGRAPH-2F848                                           */
    { 0x55B3 }, /* 0x2F849 CJK COMPATIBILITY IDEOGRAPH-2F849                                           */
    { 0x55C2 }, /* 0x2F84A CJK COMPATIBILITY IDEOGRAPH-2F84A                                           */
    { 0x5716 }, /* 0x2F84B CJK COMPATIBILITY IDEOGRAPH-2F84B                                           */
    { 0x5606 }, /* 0x2F84C CJK COMPATIBILITY IDEOGRAPH-2F84C                                           */
    { 0x5717 }, /* 0x2F84D CJK COMPATIBILITY IDEOGRAPH-2F84D                                           */
    { 0x5651 }, /* 0x2F84E CJK COMPATIBILITY IDEOGRAPH-2F84E                                           */
    { 0x5674 }, /* 0x2F84F CJK COMPATIBILITY IDEOGRAPH-2F84F                                           */
    { 0x5207 }, /* 0x2F850 CJK COMPATIBILITY IDEOGRAPH-2F850                                           */
    { 0x58EE }, /* 0x2F851 CJK COMPATIBILITY IDEOGRAPH-2F851                                           */
    { 0x57CE }, /* 0x2F852 CJK COMPATIBILITY IDEOGRAPH-2F852                                           */
    { 0x57F4 }, /* 0x2F853 CJK COMPATIBILITY IDEOGRAPH-2F853                                           */
    { 0x580D }, /* 0x2F854 CJK COMPATIBILITY IDEOGRAPH-2F854                                           */
    { 0x578B }, /* 0x2F855 CJK COMPATIBILITY IDEOGRAPH-2F855                                           */
    { 0x5832 }, /* 0x2F856 CJK COMPATIBILITY IDEOGRAPH-2F856                                           */
    { 0x5831 }, /* 0x2F857 CJK COMPATIBILITY IDEOGRAPH-2F857                                           */
    { 0x58AC }, /* 0x2F858 CJK COMPATIBILITY IDEOGRAPH-2F858                                           */
    /* ---- index: 531 ---- */
    { 0x58F2 }, /* 0x2F85A CJK COMPATIBILITY IDEOGRAPH-2F85A                                           */
    { 0x58F7 }, /* 0x2F85B CJK COMPATIBILITY IDEOGRAPH-2F85B                                           */
    { 0x5906 }, /* 0x2F85C CJK COMPATIBILITY IDEOGRAPH-2F85C                                           */
    { 0x591A }, /* 0x2F85D CJK COMPATIBILITY IDEOGRAPH-2F85D                                           */
    { 0x5922 }, /* 0x2F85E CJK COMPATIBILITY IDEOGRAPH-2F85E                                           */
    { 0x5962 }, /* 0x2F85F CJK COMPATIBILITY IDEOGRAPH-2F85F                                           */
    /* ---- index: 537 ---- */
    { 0x59EC }, /* 0x2F862 CJK COMPATIBILITY IDEOGRAPH-2F862                                           */
    { 0x5A1B }, /* 0x2F863 CJK COMPATIBILITY IDEOGRAPH-2F863                                           */
    { 0x5A27 }, /* 0x2F864 CJK COMPATIBILITY IDEOGRAPH-2F864                                           */
    { 0x59D8 }, /* 0x2F865 CJK COMPATIBILITY IDEOGRAPH-2F865                                           */
    { 0x5A66 }, /* 0x2F866 CJK COMPATIBILITY IDEOGRAPH-2F866                                           */
    { 0x36EE }, /* 0x2F867 CJK COMPATIBILITY IDEOGRAPH-2F867                                           */
    { 0x36FC }, /* 0x2F868 CJK COMPATIBILITY IDEOGRAPH-2F868                                           */
    { 0x5B08 }, /* 0x2F869 CJK COMPATIBILITY IDEOGRAPH-2F869                                           */
    { 0x5B3E }, /* 0x2F86A CJK COMPATIBILITY IDEOGRAPH-2F86A                                           */
    { 0x5B3E }, /* 0x2F86B CJK COMPATIBILITY IDEOGRAPH-2F86B                                           */
    /* ---- index: 547 ---- */
    { 0x5BFF }, /* 0x2F872 CJK COMPATIBILITY IDEOGRAPH-2F872                                           */
    { 0x5C06 }, /* 0x2F873 CJK COMPATIBILITY IDEOGRAPH-2F873                                           */
    { 0x5F53 }, /* 0x2F874 CJK COMPATIBILITY IDEOGRAPH-2F874                                           */
    { 0x5C22 }, /* 0x2F875 CJK COMPATIBILITY IDEOGRAPH-2F875                                           */
    { 0x3781 }, /* 0x2F876 CJK COMPATIBILITY IDEOGRAPH-2F876                                           */
    { 0x5C60 }, /* 0x2F877 CJK COMPATIBILITY IDEOGRAPH-2F877                                           */
    { 0x5C6E }, /* 0x2F878 CJK COMPATIBILITY IDEOGRAPH-2F878                                           */
    { 0x5CC0 }, /* 0x2F879 CJK COMPATIBILITY IDEOGRAPH-2F879                                           */
    { 0x5C8D }, /* 0x2F87A CJK COMPATIBILITY IDEOGRAPH-2F87A                                           */
    /* ---- index: 556 ---- */
    { 0x5D6E }, /* 0x2F87E CJK COMPATIBILITY IDEOGRAPH-2F87E                                           */
    { 0x5D6B }, /* 0x2F87F CJK COMPATIBILITY IDEOGRAPH-2F87F                                           */
    { 0x5D7C }, /* 0x2F880 CJK COMPATIBILITY IDEOGRAPH-2F880                                           */
    { 0x5DE1 }, /* 0x2F881 CJK COMPATIBILITY IDEOGRAPH-2F881                                           */
    { 0x5DE2 }, /* 0x2F882 CJK COMPATIBILITY IDEOGRAPH-2F882                                           */
    { 0x382F }, /* 0x2F883 CJK COMPATIBILITY IDEOGRAPH-2F883                                           */
    { 0x5DFD }, /* 0x2F884 CJK COMPATIBILITY IDEOGRAPH-2F884                                           */
    { 0x5E28 }, /* 0x2F885 CJK COMPATIBILITY IDEOGRAPH-2F885                                           */
    { 0x5E3D }, /* 0x2F886 CJK COMPATIBILITY IDEOGRAPH-2F886                                           */
    { 0x5E69 }, /* 0x2F887 CJK COMPATIBILITY IDEOGRAPH-2F887                                           */
    { 0x3862 }, /* 0x2F888 CJK COMPATIBILITY IDEOGRAPH-2F888                                           */
    /* ---- index: 567 ---- */
    { 0x5F62 }, /* 0x2F899 CJK COMPATIBILITY IDEOGRAPH-2F899                                           */
    { 0x5F6B }, /* 0x2F89A CJK COMPATIBILITY IDEOGRAPH-2F89A                                           */
    { 0x38E3 }, /* 0x2F89B CJK COMPATIBILITY IDEOGRAPH-2F89B                                           */
    { 0x5F9A }, /* 0x2F89C CJK COMPATIBILITY IDEOGRAPH-2F89C                                           */
    { 0x5FCD }, /* 0x2F89D CJK COMPATIBILITY IDEOGRAPH-2F89D                                           */
    { 0x5FD7 }, /* 0x2F89E CJK COMPATIBILITY IDEOGRAPH-2F89E                                           */
    { 0x5FF9 }, /* 0x2F89F CJK COMPATIBILITY IDEOGRAPH-2F89F                                           */
    { 0x6081 }, /* 0x2F8A0 CJK COMPATIBILITY IDEOGRAPH-2F8A0                                           */
    { 0x393A }, /* 0x2F8A1 CJK COMPATIBILITY IDEOGRAPH-2F8A1                                           */
    { 0x391C }, /* 0x2F8A2 CJK COMPATIBILITY IDEOGRAPH-2F8A2                                           */
    { 0x6094 }, /* 0x2F8A3 CJK COMPATIBILITY IDEOGRAPH-2F8A3                                           */
    /* ---- index: 578 ---- */
    { 0x60C7 }, /* 0x2F8A5 CJK COMPATIBILITY IDEOGRAPH-2F8A5                                           */
    { 0x6148 }, /* 0x2F8A6 CJK COMPATIBILITY IDEOGRAPH-2F8A6                                           */
    { 0x614C }, /* 0x2F8A7 CJK COMPATIBILITY IDEOGRAPH-2F8A7                                           */
    { 0x614E }, /* 0x2F8A8 CJK COMPATIBILITY IDEOGRAPH-2F8A8                                           */
    { 0x614C }, /* 0x2F8A9 CJK COMPATIBILITY IDEOGRAPH-2F8A9                                           */
    { 0x617A }, /* 0x2F8AA CJK COMPATIBILITY IDEOGRAPH-2F8AA                                           */
    { 0x618E }, /* 0x2F8AB CJK COMPATIBILITY IDEOGRAPH-2F8AB                                           */
    { 0x61B2 }, /* 0x2F8AC CJK COMPATIBILITY IDEOGRAPH-2F8AC                                           */
    { 0x61A4 }, /* 0x2F8AD CJK COMPATIBILITY IDEOGRAPH-2F8AD                                           */
    { 0x61AF }, /* 0x2F8AE CJK COMPATIBILITY IDEOGRAPH-2F8AE                                           */
    { 0x61DE }, /* 0x2F8AF CJK COMPATIBILITY IDEOGRAPH-2F8AF                                           */
    { 0x61F2 }, /* 0x2F8B0 CJK COMPATIBILITY IDEOGRAPH-2F8B0                                           */
    { 0x61F6 }, /* 0x2F8B1 CJK COMPATIBILITY IDEOGRAPH-2F8B1                                           */
    { 0x6210 }, /* 0x2F8B2 CJK COMPATIBILITY IDEOGRAPH-2F8B2                                           */
    { 0x621B }, /* 0x2F8B3 CJK COMPATIBILITY IDEOGRAPH-2F8B3                                           */
    { 0x625D }, /* 0x2F8B4 CJK COMPATIBILITY IDEOGRAPH-2F8B4                                           */
    { 0x62B1 }, /* 0x2F8B5 CJK COMPATIBILITY IDEOGRAPH-2F8B5                                           */
    { 0x62D4 }, /* 0x2F8B6 CJK COMPATIBILITY IDEOGRAPH-2F8B6                                           */
    { 0x6350 }, /* 0x2F8B7 CJK COMPATIBILITY IDEOGRAPH-2F8B7                                           */
    /* ---- index: 597 ---- */
    { 0x6422 }, /* 0x2F8BF CJK COMPATIBILITY IDEOGRAPH-2F8BF                                           */
    { 0x63C5 }, /* 0x2F8C0 CJK COMPATIBILITY IDEOGRAPH-2F8C0                                           */
    { 0x63A9 }, /* 0x2F8C1 CJK COMPATIBILITY IDEOGRAPH-2F8C1                                           */
    { 0x3A2E }, /* 0x2F8C2 CJK COMPATIBILITY IDEOGRAPH-2F8C2                                           */
    { 0x6469 }, /* 0x2F8C3 CJK COMPATIBILITY IDEOGRAPH-2F8C3                                           */
    { 0x647E }, /* 0x2F8C4 CJK COMPATIBILITY IDEOGRAPH-2F8C4                                           */
    { 0x649D }, /* 0x2F8C5 CJK COMPATIBILITY IDEOGRAPH-2F8C5                                           */
    { 0x6477 }, /* 0x2F8C6 CJK COMPATIBILITY IDEOGRAPH-2F8C6                                           */
    { 0x3A6C }, /* 0x2F8C7 CJK COMPATIBILITY IDEOGRAPH-2F8C7                                           */
    { 0x654F }, /* 0x2F8C8 CJK COMPATIBILITY IDEOGRAPH-2F8C8                                           */
    { 0x656C }, /* 0x2F8C9 CJK COMPATIBILITY IDEOGRAPH-2F8C9                                           */
    /* ---- index: 608 ---- */
    { 0x65E3 }, /* 0x2F8CB CJK COMPATIBILITY IDEOGRAPH-2F8CB                                           */
    { 0x66F8 }, /* 0x2F8CC CJK COMPATIBILITY IDEOGRAPH-2F8CC                                           */
    { 0x6649 }, /* 0x2F8CD CJK COMPATIBILITY IDEOGRAPH-2F8CD                                           */
    { 0x3B19 }, /* 0x2F8CE CJK COMPATIBILITY IDEOGRAPH-2F8CE                                           */
    { 0x6691 }, /* 0x2F8CF CJK COMPATIBILITY IDEOGRAPH-2F8CF                                           */
    { 0x3B08 }, /* 0x2F8D0 CJK COMPATIBILITY IDEOGRAPH-2F8D0                                           */
    { 0x3AE4 }, /* 0x2F8D1 CJK COMPATIBILITY IDEOGRAPH-2F8D1                                           */
    { 0x5192 }, /* 0x2F8D2 CJK COMPATIBILITY IDEOGRAPH-2F8D2                                           */
    { 0x5195 }, /* 0x2F8D3 CJK COMPATIBILITY IDEOGRAPH-2F8D3                                           */
    { 0x6700 }, /* 0x2F8D4 CJK COMPATIBILITY IDEOGRAPH-2F8D4                                           */
    { 0x669C }, /* 0x2F8D5 CJK COMPATIBILITY IDEOGRAPH-2F8D5                                           */
    { 0x80AD }, /* 0x2F8D6 CJK COMPATIBILITY IDEOGRAPH-2F8D6                                           */
    { 0x43D9 }, /* 0x2F8D7 CJK COMPATIBILITY IDEOGRAPH-2F8D7                                           */
    { 0x6717 }, /* 0x2F8D8 CJK COMPATIBILITY IDEOGRAPH-2F8D8                                           */
    { 0x671B }, /* 0x2F8D9 CJK COMPATIBILITY IDEOGRAPH-2F8D9                                           */
    { 0x6721 }, /* 0x2F8DA CJK COMPATIBILITY IDEOGRAPH-2F8DA                                           */
    { 0x675E }, /* 0x2F8DB CJK COMPATIBILITY IDEOGRAPH-2F8DB                                           */
    { 0x6753 }, /* 0x2F8DC CJK COMPATIBILITY IDEOGRAPH-2F8DC                                           */
    /* ---- index: 626 ---- */
    { 0x688E }, /* 0x2F8E4 CJK COMPATIBILITY IDEOGRAPH-2F8E4                                           */
    { 0x681F }, /* 0x2F8E5 CJK COMPATIBILITY IDEOGRAPH-2F8E5                                           */
    { 0x6914 }, /* 0x2F8E6 CJK COMPATIBILITY IDEOGRAPH-2F8E6                                           */
    { 0x3B9D }, /* 0x2F8E7 CJK COMPATIBILITY IDEOGRAPH-2F8E7                                           */
    { 0x6942 }, /* 0x2F8E8 CJK COMPATIBILITY IDEOGRAPH-2F8E8                                           */
    { 0x69A3 }, /* 0x2F8E9 CJK COMPATIBILITY IDEOGRAPH-2F8E9                                           */
    { 0x69EA }, /* 0x2F8EA CJK COMPATIBILITY IDEOGRAPH-2F8EA                                           */
    { 0x6AA8 }, /* 0x2F8EB CJK COMPATIBILITY IDEOGRAPH-2F8EB                                           */
    /* ---- index: 634 ---- */
    { 0x6B54 }, /* 0x2F8F1 CJK COMPATIBILITY IDEOGRAPH-2F8F1                                           */
    { 0x3C4E }, /* 0x2F8F2 CJK COMPATIBILITY IDEOGRAPH-2F8F2                                           */
    { 0x6B72 }, /* 0x2F8F3 CJK COMPATIBILITY IDEOGRAPH-2F8F3                                           */
    { 0x6B9F }, /* 0x2F8F4 CJK COMPATIBILITY IDEOGRAPH-2F8F4                                           */
    { 0x6BBA }, /* 0x2F8F5 CJK COMPATIBILITY IDEOGRAPH-2F8F5                                           */
    { 0x6BBB }, /* 0x2F8F6 CJK COMPATIBILITY IDEOGRAPH-2F8F6                                           */
    /* ---- index: 640 ---- */
    { 0x6CBF }, /* 0x2F8FC CJK COMPATIBILITY IDEOGRAPH-2F8FC                                           */
    { 0x6CCD }, /* 0x2F8FD CJK COMPATIBILITY IDEOGRAPH-2F8FD                                           */
    { 0x6C67 }, /* 0x2F8FE CJK COMPATIBILITY IDEOGRAPH-2F8FE                                           */
    { 0x6D16 }, /* 0x2F8FF CJK COMPATIBILITY IDEOGRAPH-2F8FF                                           */
    { 0x6D3E }, /* 0x2F900 CJK COMPATIBILITY IDEOGRAPH-2F900                                           */
    { 0x6D77 }, /* 0x2F901 CJK COMPATIBILITY IDEOGRAPH-2F901                                           */
    { 0x6D41 }, /* 0x2F902 CJK COMPATIBILITY IDEOGRAPH-2F902                                           */
    { 0x6D69 }, /* 0x2F903 CJK COMPATIBILITY IDEOGRAPH-2F903                                           */
    { 0x6D78 }, /* 0x2F904 CJK COMPATIBILITY IDEOGRAPH-2F904                                           */
    { 0x6D85 }, /* 0x2F905 CJK COMPATIBILITY IDEOGRAPH-2F905                                           */
    /* ---- index: 650 ---- */
    { 0x6D34 }, /* 0x2F907 CJK COMPATIBILITY IDEOGRAPH-2F907                                           */
    { 0x6E2F }, /* 0x2F908 CJK COMPATIBILITY IDEOGRAPH-2F908                                           */
    { 0x6E6E }, /* 0x2F909 CJK COMPATIBILITY IDEOGRAPH-2F909                                           */
    { 0x3D33 }, /* 0x2F90A CJK COMPATIBILITY IDEOGRAPH-2F90A                                           */
    { 0x6ECB }, /* 0x2F90B CJK COMPATIBILITY IDEOGRAPH-2F90B                                           */
    { 0x6EC7 }, /* 0x2F90C CJK COMPATIBILITY IDEOGRAPH-2F90C                                           */
    /* ---- index: 656 ---- */
    { 0x6FC6 }, /* 0x2F912 CJK COMPATIBILITY IDEOGRAPH-2F912                                           */
    { 0x7039 }, /* 0x2F913 CJK COMPATIBILITY IDEOGRAPH-2F913                                           */
    { 0x701E }, /* 0x2F914 CJK COMPATIBILITY IDEOGRAPH-2F914                                           */
    { 0x701B }, /* 0x2F915 CJK COMPATIBILITY IDEOGRAPH-2F915                                           */
    { 0x3D96 }, /* 0x2F916 CJK COMPATIBILITY IDEOGRAPH-2F916                                           */
    { 0x704A }, /* 0x2F917 CJK COMPATIBILITY IDEOGRAPH-2F917                                           */
    { 0x707D }, /* 0x2F918 CJK COMPATIBILITY IDEOGRAPH-2F918                                           */
    { 0x7077 }, /* 0x2F919 CJK COMPATIBILITY IDEOGRAPH-2F919                                           */
    { 0x70AD }, /* 0x2F91A CJK COMPATIBILITY IDEOGRAPH-2F91A                                           */
    /* ---- index: 665 ---- */
    { 0x737A }, /* 0x2F928 CJK COMPATIBILITY IDEOGRAPH-2F928                                           */
    { 0x738B }, /* 0x2F929 CJK COMPATIBILITY IDEOGRAPH-2F929                                           */
    { 0x3EAC }, /* 0x2F92A CJK COMPATIBILITY IDEOGRAPH-2F92A                                           */
    { 0x73A5 }, /* 0x2F92B CJK COMPATIBILITY IDEOGRAPH-2F92B                                           */
    { 0x3EB8 }, /* 0x2F92C CJK COMPATIBILITY IDEOGRAPH-2F92C                                           */
    { 0x3EB8 }, /* 0x2F92D CJK COMPATIBILITY IDEOGRAPH-2F92D                                           */
    { 0x7447 }, /* 0x2F92E CJK COMPATIBILITY IDEOGRAPH-2F92E                                           */
    { 0x745C }, /* 0x2F92F CJK COMPATIBILITY IDEOGRAPH-2F92F                                           */
    { 0x7471 }, /* 0x2F930 CJK COMPATIBILITY IDEOGRAPH-2F930                                           */
    { 0x7485 }, /* 0x2F931 CJK COMPATIBILITY IDEOGRAPH-2F931                                           */
    { 0x74CA }, /* 0x2F932 CJK COMPATIBILITY IDEOGRAPH-2F932                                           */
    { 0x3F1B }, /* 0x2F933 CJK COMPATIBILITY IDEOGRAPH-2F933                                           */
    { 0x7524 }, /* 0x2F934 CJK COMPATIBILITY IDEOGRAPH-2F934                                           */
    /* ---- index: 678 ---- */
    { 0x771E }, /* 0x2F945 CJK COMPATIBILITY IDEOGRAPH-2F945                                           */
    { 0x771F }, /* 0x2F946 CJK COMPATIBILITY IDEOGRAPH-2F946                                           */
    { 0x771F }, /* 0x2F947 CJK COMPATIBILITY IDEOGRAPH-2F947                                           */
    { 0x774A }, /* 0x2F948 CJK COMPATIBILITY IDEOGRAPH-2F948                                           */
    { 0x4039 }, /* 0x2F949 CJK COMPATIBILITY IDEOGRAPH-2F949                                           */
    { 0x778B }, /* 0x2F94A CJK COMPATIBILITY IDEOGRAPH-2F94A                                           */
    { 0x4046 }, /* 0x2F94B CJK COMPATIBILITY IDEOGRAPH-2F94B                                           */
    { 0x4096 }, /* 0x2F94C CJK COMPATIBILITY IDEOGRAPH-2F94C                                           */
    /* ---- index: 686 ---- */
    { 0x798F }, /* 0x2F956 CJK COMPATIBILITY IDEOGRAPH-2F956                                           */
    { 0x79EB }, /* 0x2F957 CJK COMPATIBILITY IDEOGRAPH-2F957                                           */
    { 0x412F }, /* 0x2F958 CJK COMPATIBILITY IDEOGRAPH-2F958                                           */
    { 0x7A40 }, /* 0x2F959 CJK COMPATIBILITY IDEOGRAPH-2F959                                           */
    { 0x7A4A }, /* 0x2F95A CJK COMPATIBILITY IDEOGRAPH-2F95A                                           */
    { 0x7A4F }, /* 0x2F95B CJK COMPATIBILITY IDEOGRAPH-2F95B                                           */
    /* ---- index: 692 ---- */
    { 0x7D63 }, /* 0x2F96C CJK COMPATIBILITY IDEOGRAPH-2F96C                                           */
    { 0x4301 }, /* 0x2F96D CJK COMPATIBILITY IDEOGRAPH-2F96D                                           */
    { 0x7DC7 }, /* 0x2F96E CJK COMPATIBILITY IDEOGRAPH-2F96E                                           */
    { 0x7E02 }, /* 0x2F96F CJK COMPATIBILITY IDEOGRAPH-2F96F                                           */
    { 0x7E45 }, /* 0x2F970 CJK COMPATIBILITY IDEOGRAPH-2F970                                           */
    { 0x4334 }, /* 0x2F971 CJK COMPATIBILITY IDEOGRAPH-2F971                                           */
    /* ---- index: 698 ---- */
    { 0x43D5 }, /* 0x2F981 CJK COMPATIBILITY IDEOGRAPH-2F981                                           */
    { 0x80B2 }, /* 0x2F982 CJK COMPATIBILITY IDEOGRAPH-2F982                                           */
    { 0x8103 }, /* 0x2F983 CJK COMPATIBILITY IDEOGRAPH-2F983                                           */
    { 0x440B }, /* 0x2F984 CJK COMPATIBILITY IDEOGRAPH-2F984                                           */
    { 0x813E }, /* 0x2F985 CJK COMPATIBILITY IDEOGRAPH-2F985                                           */
    { 0x5AB5 }, /* 0x2F986 CJK COMPATIBILITY IDEOGRAPH-2F986                                           */
    /* ---- index: 704 ---- */
    { 0x8201 }, /* 0x2F98B CJK COMPATIBILITY IDEOGRAPH-2F98B                                           */
    { 0x8204 }, /* 0x2F98C CJK COMPATIBILITY IDEOGRAPH-2F98C                                           */
    { 0x8F9E }, /* 0x2F98D CJK COMPATIBILITY IDEOGRAPH-2F98D                                           */
    { 0x446B }, /* 0x2F98E CJK COMPATIBILITY IDEOGRAPH-2F98E                                           */
    { 0x8291 }, /* 0x2F98F CJK COMPATIBILITY IDEOGRAPH-2F98F                                           */
    { 0x828B }, /* 0x2F990 CJK COMPATIBILITY IDEOGRAPH-2F990                                           */
    { 0x829D }, /* 0x2F991 CJK COMPATIBILITY IDEOGRAPH-2F991                                           */
    { 0x52B3 }, /* 0x2F992 CJK COMPATIBILITY IDEOGRAPH-2F992                                           */
    { 0x82B1 }, /* 0x2F993 CJK COMPATIBILITY IDEOGRAPH-2F993                                           */
    { 0x82B3 }, /* 0x2F994 CJK COMPATIBILITY IDEOGRAPH-2F994                                           */
    { 0x82BD }, /* 0x2F995 CJK COMPATIBILITY IDEOGRAPH-2F995                                           */
    { 0x82E6 }, /* 0x2F996 CJK COMPATIBILITY IDEOGRAPH-2F996                                           */
    /* ---- index: 716 ---- */
    { 0x82E5 }, /* 0x2F998 CJK COMPATIBILITY IDEOGRAPH-2F998                                           */
    { 0x831D }, /* 0x2F999 CJK COMPATIBILITY IDEOGRAPH-2F999                                           */
    { 0x8363 }, /* 0x2F99A CJK COMPATIBILITY IDEOGRAPH-2F99A                                           */
    { 0x83AD }, /* 0x2F99B CJK COMPATIBILITY IDEOGRAPH-2F99B                                           */
    { 0x8323 }, /* 0x2F99C CJK COMPATIBILITY IDEOGRAPH-2F99C                                           */
    { 0x83BD }, /* 0x2F99D CJK COMPATIBILITY IDEOGRAPH-2F99D                                           */
    { 0x83E7 }, /* 0x2F99E CJK COMPATIBILITY IDEOGRAPH-2F99E                                           */
    { 0x8457 }, /* 0x2F99F CJK COMPATIBILITY IDEOGRAPH-2F99F                                           */
    { 0x8353 }, /* 0x2F9A0 CJK COMPATIBILITY IDEOGRAPH-2F9A0                                           */
    { 0x83CA }, /* 0x2F9A1 CJK COMPATIBILITY IDEOGRAPH-2F9A1                                           */
    { 0x83CC }, /* 0x2F9A2 CJK COMPATIBILITY IDEOGRAPH-2F9A2                                           */
    { 0x83DC }, /* 0x2F9A3 CJK COMPATIBILITY IDEOGRAPH-2F9A3                                           */
    /* ---- index: 728 ---- */
    { 0x456B }, /* 0x2F9B2 CJK COMPATIBILITY IDEOGRAPH-2F9B2                                           */
    { 0x8650 }, /* 0x2F9B3 CJK COMPATIBILITY IDEOGRAPH-2F9B3                                           */
    { 0x865C }, /* 0x2F9B4 CJK COMPATIBILITY IDEOGRAPH-2F9B4                                           */
    { 0x8667 }, /* 0x2F9B5 CJK COMPATIBILITY IDEOGRAPH-2F9B5                                           */
    { 0x8669 }, /* 0x2F9B6 CJK COMPATIBILITY IDEOGRAPH-2F9B6                                           */
    { 0x86A9 }, /* 0x2F9B7 CJK COMPATIBILITY IDEOGRAPH-2F9B7                                           */
    { 0x8688 }, /* 0x2F9B8 CJK COMPATIBILITY IDEOGRAPH-2F9B8                                           */
    { 0x870E }, /* 0x2F9B9 CJK COMPATIBILITY IDEOGRAPH-2F9B9                                           */
    { 0x86E2 }, /* 0x2F9BA CJK COMPATIBILITY IDEOGRAPH-2F9BA                                           */
    { 0x8779 }, /* 0x2F9BB CJK COMPATIBILITY IDEOGRAPH-2F9BB                                           */
    { 0x8728 }, /* 0x2F9BC CJK COMPATIBILITY IDEOGRAPH-2F9BC                                           */
    { 0x876B }, /* 0x2F9BD CJK COMPATIBILITY IDEOGRAPH-2F9BD                                           */
    { 0x8786 }, /* 0x2F9BE CJK COMPATIBILITY IDEOGRAPH-2F9BE                                           */
    { 0x45D7 }, /* 0x2F9BF CJK COMPATIBILITY IDEOGRAPH-2F9BF                                           */
    { 0x87E1 }, /* 0x2F9C0 CJK COMPATIBILITY IDEOGRAPH-2F9C0                                           */
    { 0x8801 }, /* 0x2F9C1 CJK COMPATIBILITY IDEOGRAPH-2F9C1                                           */
    { 0x45F9 }, /* 0x2F9C2 CJK COMPATIBILITY IDEOGRAPH-2F9C2                                           */
    { 0x8860 }, /* 0x2F9C3 CJK COMPATIBILITY IDEOGRAPH-2F9C3                                           */
    { 0x8863 }, /* 0x2F9C4 CJK COMPATIBILITY IDEOGRAPH-2F9C4                                           */
    /* ---- index: 747 ---- */
    { 0x46BE }, /* 0x2F9CD CJK COMPATIBILITY IDEOGRAPH-2F9CD                                           */
    { 0x46C7 }, /* 0x2F9CE CJK COMPATIBILITY IDEOGRAPH-2F9CE                                           */
    { 0x8AA0 }, /* 0x2F9CF CJK COMPATIBILITY IDEOGRAPH-2F9CF                                           */
    { 0x8AED }, /* 0x2F9D0 CJK COMPATIBILITY IDEOGRAPH-2F9D0                                           */
    { 0x8B8A }, /* 0x2F9D1 CJK COMPATIBILITY IDEOGRAPH-2F9D1                                           */
    { 0x8C55 }, /* 0x2F9D2 CJK COMPATIBILITY IDEOGRAPH-2F9D2                                           */
    /* ---- index: 753 ---- */
    { 0x911B }, /* 0x2F9E6 CJK COMPATIBILITY IDEOGRAPH-2F9E6                                           */
    { 0x9238 }, /* 0x2F9E7 CJK COMPATIBILITY IDEOGRAPH-2F9E7                                           */
    { 0x92D7 }, /* 0x2F9E8 CJK COMPATIBILITY IDEOGRAPH-2F9E8                                           */
    { 0x92D8 }, /* 0x2F9E9 CJK COMPATIBILITY IDEOGRAPH-2F9E9                                           */
    { 0x927C }, /* 0x2F9EA CJK COMPATIBILITY IDEOGRAPH-2F9EA                                           */
    { 0x93F9 }, /* 0x2F9EB CJK COMPATIBILITY IDEOGRAPH-2F9EB                                           */
    { 0x9415 }, /* 0x2F9EC CJK COMPATIBILITY IDEOGRAPH-2F9EC                                           */
    /* ---- index: 760 ---- */
    { 0x98E2 }, /* 0x2FA02 CJK COMPATIBILITY IDEOGRAPH-2FA02                                           */
    { 0x4B33 }, /* 0x2FA03 CJK COMPATIBILITY IDEOGRAPH-2FA03                                           */
    { 0x9929 }, /* 0x2FA04 CJK COMPATIBILITY IDEOGRAPH-2FA04                                           */
    { 0x99A7 }, /* 0x2FA05 CJK COMPATIBILITY IDEOGRAPH-2FA05                                           */
    { 0x99C2 }, /* 0x2FA06 CJK COMPATIBILITY IDEOGRAPH-2FA06                                           */
    { 0x99FE }, /* 0x2FA07 CJK COMPATIBILITY IDEOGRAPH-2FA07                                           */
    { 0x4BCE }, /* 0x2FA08 CJK COMPATIBILITY IDEOGRAPH-2FA08                                           */
    /* ---- index: 767 ---- */
    { 0x9B12 }, /* 0x2FA0A CJK COMPATIBILITY IDEOGRAPH-2FA0A                                           */
    { 0x9C40 }, /* 0x2FA0B CJK COMPATIBILITY IDEOGRAPH-2FA0B                                           */
    { 0x9CFD }, /* 0x2FA0C CJK COMPATIBILITY IDEOGRAPH-2FA0C                                           */
    { 0x4CCE }, /* 0x2FA0D CJK COMPATIBILITY IDEOGRAPH-2FA0D                                           */
    { 0x4CED }, /* 0x2FA0E CJK COMPATIBILITY IDEOGRAPH-2FA0E                                           */
    { 0x9D67 }, /* 0x2FA0F CJK COMPATIBILITY IDEOGRAPH-2FA0F                                           */
    /* ---- index: 773 ---- */
    { 0x9EBB }, /* 0x2FA15 CJK COMPATIBILITY IDEOGRAPH-2FA15                                           */
    { 0x4D56 }, /* 0x2FA16 CJK COMPATIBILITY IDEOGRAPH-2FA16                                           */
    { 0x9EF9 }, /* 0x2FA17 CJK COMPATIBILITY IDEOGRAPH-2FA17                                           */
    { 0x9EFE }, /* 0x2FA18 CJK COMPATIBILITY IDEOGRAPH-2FA18                                           */
    { 0x9F05 }, /* 0x2FA19 CJK COMPATIBILITY IDEOGRAPH-2FA19                                           */
    { 0x9F0F }, /* 0x2FA1A CJK COMPATIBILITY IDEOGRAPH-2FA1A                                           */
    { 0x9F16 }, /* 0x2FA1B CJK COMPATIBILITY IDEOGRAPH-2FA1B                                           */
    { 0x9F3B }, /* 0x2FA1C CJK COMPATIBILITY IDEOGRAPH-2FA1C                                           */
};


const DecompositionDataType2
decompositionData2[] =
{
    /* ---- index: 0 ---- */
    { 0x011099, 0x0110BA }, /* 0x01109A KAITHI LETTER DDDHA                                                         */
    /* ---- index: 1 ---- */
    { 0x01109B, 0x0110BA }, /* 0x01109C KAITHI LETTER RHA                                                           */
    /* ---- index: 2 ---- */
    { 0x0110A5, 0x0110BA }, /* 0x0110AB KAITHI LETTER VA                                                            */
    /* ---- index: 3 ---- */
    { 0x011131, 0x011127 }, /* 0x01112E CHAKMA VOWEL SIGN O                                                         */
    { 0x011132, 0x011127 }, /* 0x01112F CHAKMA VOWEL SIGN AU                                                        */
    /* ---- index: 5 ---- */
    { 0x01D157, 0x01D165 }, /* 0x01D15E MUSICAL SYMBOL HALF NOTE                                                    */
    { 0x01D158, 0x01D165 }, /* 0x01D15F MUSICAL SYMBOL QUARTER NOTE                                                 */
    { 0x01D15F, 0x01D16E }, /* 0x01D160 MUSICAL SYMBOL EIGHTH NOTE                                                  */
    { 0x01D15F, 0x01D16F }, /* 0x01D161 MUSICAL SYMBOL SIXTEENTH NOTE                                               */
    { 0x01D15F, 0x01D170 }, /* 0x01D162 MUSICAL SYMBOL THIRTY-SECOND NOTE                                           */
    { 0x01D15F, 0x01D171 }, /* 0x01D163 MUSICAL SYMBOL SIXTY-FOURTH NOTE                                            */
    { 0x01D15F, 0x01D172 }, /* 0x01D164 MUSICAL SYMBOL ONE HUNDRED TWENTY-EIGHTH NOTE                               */
    /* ---- index: 12 ---- */
    { 0x01D1B9, 0x01D165 }, /* 0x01D1BB MUSICAL SYMBOL MINIMA                                                       */
    { 0x01D1BA, 0x01D165 }, /* 0x01D1BC MUSICAL SYMBOL MINIMA BLACK                                                 */
    { 0x01D1BB, 0x01D16E }, /* 0x01D1BD MUSICAL SYMBOL SEMIMINIMA WHITE                                             */
    { 0x01D1BC, 0x01D16E }, /* 0x01D1BE MUSICAL SYMBOL SEMIMINIMA BLACK                                             */
    { 0x01D1BB, 0x01D16F }, /* 0x01D1BF MUSICAL SYMBOL FUSA WHITE                                                   */
    { 0x01D1BC, 0x01D16F }, /* 0x01D1C0 MUSICAL SYMBOL FUSA BLACK                                                   */
};


const DecompositionDataType3
decompositionData3[] =
{
    /* ---- index: 0 ---- */
    { 0x0242EE }, /* 0x00FA6C CJK COMPATIBILITY IDEOGRAPH-FA6C                                            */
    /* ---- index: 1 ---- */
    { 0x02284A }, /* 0x00FACF CJK COMPATIBILITY IDEOGRAPH-FACF                                            */
    { 0x022844 }, /* 0x00FAD0 CJK COMPATIBILITY IDEOGRAPH-FAD0                                            */
    { 0x0233D5 }, /* 0x00FAD1 CJK COMPATIBILITY IDEOGRAPH-FAD1                                            */
    { 0x003B9D }, /* 0x00FAD2 CJK COMPATIBILITY IDEOGRAPH-FAD2                                            */
    { 0x004018 }, /* 0x00FAD3 CJK COMPATIBILITY IDEOGRAPH-FAD3                                            */
    { 0x004039 }, /* 0x00FAD4 CJK COMPATIBILITY IDEOGRAPH-FAD4                                            */
    { 0x025249 }, /* 0x00FAD5 CJK COMPATIBILITY IDEOGRAPH-FAD5                                            */
    { 0x025CD0 }, /* 0x00FAD6 CJK COMPATIBILITY IDEOGRAPH-FAD6                                            */
    { 0x027ED3 }, /* 0x00FAD7 CJK COMPATIBILITY IDEOGRAPH-FAD7                                            */
    /* ---- index: 10 ---- */
    { 0x020122 }, /* 0x02F803 CJK COMPATIBILITY IDEOGRAPH-2F803                                           */
    /* ---- index: 11 ---- */
    { 0x02063A }, /* 0x02F80D CJK COMPATIBILITY IDEOGRAPH-2F80D                                           */
    { 0x00514D }, /* 0x02F80E CJK COMPATIBILITY IDEOGRAPH-2F80E                                           */
    { 0x005154 }, /* 0x02F80F CJK COMPATIBILITY IDEOGRAPH-2F80F                                           */
    { 0x005164 }, /* 0x02F810 CJK COMPATIBILITY IDEOGRAPH-2F810                                           */
    { 0x005177 }, /* 0x02F811 CJK COMPATIBILITY IDEOGRAPH-2F811                                           */
    { 0x02051C }, /* 0x02F812 CJK COMPATIBILITY IDEOGRAPH-2F812                                           */
    { 0x0034B9 }, /* 0x02F813 CJK COMPATIBILITY IDEOGRAPH-2F813                                           */
    { 0x005167 }, /* 0x02F814 CJK COMPATIBILITY IDEOGRAPH-2F814                                           */
    { 0x00518D }, /* 0x02F815 CJK COMPATIBILITY IDEOGRAPH-2F815                                           */
    { 0x02054B }, /* 0x02F816 CJK COMPATIBILITY IDEOGRAPH-2F816                                           */
    { 0x005197 }, /* 0x02F817 CJK COMPATIBILITY IDEOGRAPH-2F817                                           */
    { 0x0051A4 }, /* 0x02F818 CJK COMPATIBILITY IDEOGRAPH-2F818                                           */
    { 0x004ECC }, /* 0x02F819 CJK COMPATIBILITY IDEOGRAPH-2F819                                           */
    { 0x0051AC }, /* 0x02F81A CJK COMPATIBILITY IDEOGRAPH-2F81A                                           */
    { 0x0051B5 }, /* 0x02F81B CJK COMPATIBILITY IDEOGRAPH-2F81B                                           */
    { 0x0291DF }, /* 0x02F81C CJK COMPATIBILITY IDEOGRAPH-2F81C                                           */
    /* ---- index: 27 ---- */
    { 0x020A2C }, /* 0x02F834 CJK COMPATIBILITY IDEOGRAPH-2F834                                           */
    { 0x007070 }, /* 0x02F835 CJK COMPATIBILITY IDEOGRAPH-2F835                                           */
    { 0x0053CA }, /* 0x02F836 CJK COMPATIBILITY IDEOGRAPH-2F836                                           */
    { 0x0053DF }, /* 0x02F837 CJK COMPATIBILITY IDEOGRAPH-2F837                                           */
    { 0x020B63 }, /* 0x02F838 CJK COMPATIBILITY IDEOGRAPH-2F838                                           */
    /* ---- index: 32 ---- */
    { 0x0214E4 }, /* 0x02F859 CJK COMPATIBILITY IDEOGRAPH-2F859                                           */
    /* ---- index: 33 ---- */
    { 0x0216A8 }, /* 0x02F860 CJK COMPATIBILITY IDEOGRAPH-2F860                                           */
    { 0x0216EA }, /* 0x02F861 CJK COMPATIBILITY IDEOGRAPH-2F861                                           */
    /* ---- index: 35 ---- */
    { 0x0219C8 }, /* 0x02F86C CJK COMPATIBILITY IDEOGRAPH-2F86C                                           */
    { 0x005BC3 }, /* 0x02F86D CJK COMPATIBILITY IDEOGRAPH-2F86D                                           */
    { 0x005BD8 }, /* 0x02F86E CJK COMPATIBILITY IDEOGRAPH-2F86E                                           */
    { 0x005BE7 }, /* 0x02F86F CJK COMPATIBILITY IDEOGRAPH-2F86F                                           */
    { 0x005BF3 }, /* 0x02F870 CJK COMPATIBILITY IDEOGRAPH-2F870                                           */
    { 0x021B18 }, /* 0x02F871 CJK COMPATIBILITY IDEOGRAPH-2F871                                           */
    /* ---- index: 41 ---- */
    { 0x021DE4 }, /* 0x02F87B CJK COMPATIBILITY IDEOGRAPH-2F87B                                           */
    { 0x005D43 }, /* 0x02F87C CJK COMPATIBILITY IDEOGRAPH-2F87C                                           */
    { 0x021DE6 }, /* 0x02F87D CJK COMPATIBILITY IDEOGRAPH-2F87D                                           */
    /* ---- index: 44 ---- */
    { 0x022183 }, /* 0x02F889 CJK COMPATIBILITY IDEOGRAPH-2F889                                           */
    { 0x00387C }, /* 0x02F88A CJK COMPATIBILITY IDEOGRAPH-2F88A                                           */
    { 0x005EB0 }, /* 0x02F88B CJK COMPATIBILITY IDEOGRAPH-2F88B                                           */
    { 0x005EB3 }, /* 0x02F88C CJK COMPATIBILITY IDEOGRAPH-2F88C                                           */
    { 0x005EB6 }, /* 0x02F88D CJK COMPATIBILITY IDEOGRAPH-2F88D                                           */
    { 0x005ECA }, /* 0x02F88E CJK COMPATIBILITY IDEOGRAPH-2F88E                                           */
    { 0x02A392 }, /* 0x02F88F CJK COMPATIBILITY IDEOGRAPH-2F88F                                           */
    { 0x005EFE }, /* 0x02F890 CJK COMPATIBILITY IDEOGRAPH-2F890                                           */
    { 0x022331 }, /* 0x02F891 CJK COMPATIBILITY IDEOGRAPH-2F891                                           */
    { 0x022331 }, /* 0x02F892 CJK COMPATIBILITY IDEOGRAPH-2F892                                           */
    { 0x008201 }, /* 0x02F893 CJK COMPATIBILITY IDEOGRAPH-2F893                                           */
    { 0x005F22 }, /* 0x02F894 CJK COMPATIBILITY IDEOGRAPH-2F894                                           */
    { 0x005F22 }, /* 0x02F895 CJK COMPATIBILITY IDEOGRAPH-2F895                                           */
    { 0x0038C7 }, /* 0x02F896 CJK COMPATIBILITY IDEOGRAPH-2F896                                           */
    { 0x0232B8 }, /* 0x02F897 CJK COMPATIBILITY IDEOGRAPH-2F897                                           */
    { 0x0261DA }, /* 0x02F898 CJK COMPATIBILITY IDEOGRAPH-2F898                                           */
    /* ---- index: 60 ---- */
    { 0x0226D4 }, /* 0x02F8A4 CJK COMPATIBILITY IDEOGRAPH-2F8A4                                           */
    /* ---- index: 61 ---- */
    { 0x022B0C }, /* 0x02F8B8 CJK COMPATIBILITY IDEOGRAPH-2F8B8                                           */
    { 0x00633D }, /* 0x02F8B9 CJK COMPATIBILITY IDEOGRAPH-2F8B9                                           */
    { 0x0062FC }, /* 0x02F8BA CJK COMPATIBILITY IDEOGRAPH-2F8BA                                           */
    { 0x006368 }, /* 0x02F8BB CJK COMPATIBILITY IDEOGRAPH-2F8BB                                           */
    { 0x006383 }, /* 0x02F8BC CJK COMPATIBILITY IDEOGRAPH-2F8BC                                           */
    { 0x0063E4 }, /* 0x02F8BD CJK COMPATIBILITY IDEOGRAPH-2F8BD                                           */
    { 0x022BF1 }, /* 0x02F8BE CJK COMPATIBILITY IDEOGRAPH-2F8BE                                           */
    /* ---- index: 68 ---- */
    { 0x02300A }, /* 0x02F8CA CJK COMPATIBILITY IDEOGRAPH-2F8CA                                           */
    /* ---- index: 69 ---- */
    { 0x0233C3 }, /* 0x02F8DD CJK COMPATIBILITY IDEOGRAPH-2F8DD                                           */
    { 0x003B49 }, /* 0x02F8DE CJK COMPATIBILITY IDEOGRAPH-2F8DE                                           */
    { 0x0067FA }, /* 0x02F8DF CJK COMPATIBILITY IDEOGRAPH-2F8DF                                           */
    { 0x006785 }, /* 0x02F8E0 CJK COMPATIBILITY IDEOGRAPH-2F8E0                                           */
    { 0x006852 }, /* 0x02F8E1 CJK COMPATIBILITY IDEOGRAPH-2F8E1                                           */
    { 0x006885 }, /* 0x02F8E2 CJK COMPATIBILITY IDEOGRAPH-2F8E2                                           */
    { 0x02346D }, /* 0x02F8E3 CJK COMPATIBILITY IDEOGRAPH-2F8E3                                           */
    /* ---- index: 76 ---- */
    { 0x0236A3 }, /* 0x02F8EC CJK COMPATIBILITY IDEOGRAPH-2F8EC                                           */
    { 0x006ADB }, /* 0x02F8ED CJK COMPATIBILITY IDEOGRAPH-2F8ED                                           */
    { 0x003C18 }, /* 0x02F8EE CJK COMPATIBILITY IDEOGRAPH-2F8EE                                           */
    { 0x006B21 }, /* 0x02F8EF CJK COMPATIBILITY IDEOGRAPH-2F8EF                                           */
    { 0x0238A7 }, /* 0x02F8F0 CJK COMPATIBILITY IDEOGRAPH-2F8F0                                           */
    /* ---- index: 81 ---- */
    { 0x023A8D }, /* 0x02F8F7 CJK COMPATIBILITY IDEOGRAPH-2F8F7                                           */
    { 0x021D0B }, /* 0x02F8F8 CJK COMPATIBILITY IDEOGRAPH-2F8F8                                           */
    { 0x023AFA }, /* 0x02F8F9 CJK COMPATIBILITY IDEOGRAPH-2F8F9                                           */
    { 0x006C4E }, /* 0x02F8FA CJK COMPATIBILITY IDEOGRAPH-2F8FA                                           */
    { 0x023CBC }, /* 0x02F8FB CJK COMPATIBILITY IDEOGRAPH-2F8FB                                           */
    /* ---- index: 86 ---- */
    { 0x023D1E }, /* 0x02F906 CJK COMPATIBILITY IDEOGRAPH-2F906                                           */
    /* ---- index: 87 ---- */
    { 0x023ED1 }, /* 0x02F90D CJK COMPATIBILITY IDEOGRAPH-2F90D                                           */
    { 0x006DF9 }, /* 0x02F90E CJK COMPATIBILITY IDEOGRAPH-2F90E                                           */
    { 0x006F6E }, /* 0x02F90F CJK COMPATIBILITY IDEOGRAPH-2F90F                                           */
    { 0x023F5E }, /* 0x02F910 CJK COMPATIBILITY IDEOGRAPH-2F910                                           */
    { 0x023F8E }, /* 0x02F911 CJK COMPATIBILITY IDEOGRAPH-2F911                                           */
    /* ---- index: 92 ---- */
    { 0x020525 }, /* 0x02F91B CJK COMPATIBILITY IDEOGRAPH-2F91B                                           */
    { 0x007145 }, /* 0x02F91C CJK COMPATIBILITY IDEOGRAPH-2F91C                                           */
    { 0x024263 }, /* 0x02F91D CJK COMPATIBILITY IDEOGRAPH-2F91D                                           */
    { 0x00719C }, /* 0x02F91E CJK COMPATIBILITY IDEOGRAPH-2F91E                                           */
    { 0x0243AB }, /* 0x02F91F CJK COMPATIBILITY IDEOGRAPH-2F91F                                           */
    { 0x007228 }, /* 0x02F920 CJK COMPATIBILITY IDEOGRAPH-2F920                                           */
    { 0x007235 }, /* 0x02F921 CJK COMPATIBILITY IDEOGRAPH-2F921                                           */
    { 0x007250 }, /* 0x02F922 CJK COMPATIBILITY IDEOGRAPH-2F922                                           */
    { 0x024608 }, /* 0x02F923 CJK COMPATIBILITY IDEOGRAPH-2F923                                           */
    { 0x007280 }, /* 0x02F924 CJK COMPATIBILITY IDEOGRAPH-2F924                                           */
    { 0x007295 }, /* 0x02F925 CJK COMPATIBILITY IDEOGRAPH-2F925                                           */
    { 0x024735 }, /* 0x02F926 CJK COMPATIBILITY IDEOGRAPH-2F926                                           */
    { 0x024814 }, /* 0x02F927 CJK COMPATIBILITY IDEOGRAPH-2F927                                           */
    /* ---- index: 105 ---- */
    { 0x024C36 }, /* 0x02F935 CJK COMPATIBILITY IDEOGRAPH-2F935                                           */
    { 0x00753E }, /* 0x02F936 CJK COMPATIBILITY IDEOGRAPH-2F936                                           */
    { 0x024C92 }, /* 0x02F937 CJK COMPATIBILITY IDEOGRAPH-2F937                                           */
    { 0x007570 }, /* 0x02F938 CJK COMPATIBILITY IDEOGRAPH-2F938                                           */
    { 0x02219F }, /* 0x02F939 CJK COMPATIBILITY IDEOGRAPH-2F939                                           */
    { 0x007610 }, /* 0x02F93A CJK COMPATIBILITY IDEOGRAPH-2F93A                                           */
    { 0x024FA1 }, /* 0x02F93B CJK COMPATIBILITY IDEOGRAPH-2F93B                                           */
    { 0x024FB8 }, /* 0x02F93C CJK COMPATIBILITY IDEOGRAPH-2F93C                                           */
    { 0x025044 }, /* 0x02F93D CJK COMPATIBILITY IDEOGRAPH-2F93D                                           */
    { 0x003FFC }, /* 0x02F93E CJK COMPATIBILITY IDEOGRAPH-2F93E                                           */
    { 0x004008 }, /* 0x02F93F CJK COMPATIBILITY IDEOGRAPH-2F93F                                           */
    { 0x0076F4 }, /* 0x02F940 CJK COMPATIBILITY IDEOGRAPH-2F940                                           */
    { 0x0250F3 }, /* 0x02F941 CJK COMPATIBILITY IDEOGRAPH-2F941                                           */
    { 0x0250F2 }, /* 0x02F942 CJK COMPATIBILITY IDEOGRAPH-2F942                                           */
    { 0x025119 }, /* 0x02F943 CJK COMPATIBILITY IDEOGRAPH-2F943                                           */
    { 0x025133 }, /* 0x02F944 CJK COMPATIBILITY IDEOGRAPH-2F944                                           */
    /* ---- index: 121 ---- */
    { 0x02541D }, /* 0x02F94D CJK COMPATIBILITY IDEOGRAPH-2F94D                                           */
    { 0x00784E }, /* 0x02F94E CJK COMPATIBILITY IDEOGRAPH-2F94E                                           */
    { 0x00788C }, /* 0x02F94F CJK COMPATIBILITY IDEOGRAPH-2F94F                                           */
    { 0x0078CC }, /* 0x02F950 CJK COMPATIBILITY IDEOGRAPH-2F950                                           */
    { 0x0040E3 }, /* 0x02F951 CJK COMPATIBILITY IDEOGRAPH-2F951                                           */
    { 0x025626 }, /* 0x02F952 CJK COMPATIBILITY IDEOGRAPH-2F952                                           */
    { 0x007956 }, /* 0x02F953 CJK COMPATIBILITY IDEOGRAPH-2F953                                           */
    { 0x02569A }, /* 0x02F954 CJK COMPATIBILITY IDEOGRAPH-2F954                                           */
    { 0x0256C5 }, /* 0x02F955 CJK COMPATIBILITY IDEOGRAPH-2F955                                           */
    /* ---- index: 130 ---- */
    { 0x02597C }, /* 0x02F95C CJK COMPATIBILITY IDEOGRAPH-2F95C                                           */
    { 0x025AA7 }, /* 0x02F95D CJK COMPATIBILITY IDEOGRAPH-2F95D                                           */
    { 0x025AA7 }, /* 0x02F95E CJK COMPATIBILITY IDEOGRAPH-2F95E                                           */
    { 0x007AEE }, /* 0x02F95F CJK COMPATIBILITY IDEOGRAPH-2F95F                                           */
    { 0x004202 }, /* 0x02F960 CJK COMPATIBILITY IDEOGRAPH-2F960                                           */
    { 0x025BAB }, /* 0x02F961 CJK COMPATIBILITY IDEOGRAPH-2F961                                           */
    { 0x007BC6 }, /* 0x02F962 CJK COMPATIBILITY IDEOGRAPH-2F962                                           */
    { 0x007BC9 }, /* 0x02F963 CJK COMPATIBILITY IDEOGRAPH-2F963                                           */
    { 0x004227 }, /* 0x02F964 CJK COMPATIBILITY IDEOGRAPH-2F964                                           */
    { 0x025C80 }, /* 0x02F965 CJK COMPATIBILITY IDEOGRAPH-2F965                                           */
    { 0x007CD2 }, /* 0x02F966 CJK COMPATIBILITY IDEOGRAPH-2F966                                           */
    { 0x0042A0 }, /* 0x02F967 CJK COMPATIBILITY IDEOGRAPH-2F967                                           */
    { 0x007CE8 }, /* 0x02F968 CJK COMPATIBILITY IDEOGRAPH-2F968                                           */
    { 0x007CE3 }, /* 0x02F969 CJK COMPATIBILITY IDEOGRAPH-2F969                                           */
    { 0x007D00 }, /* 0x02F96A CJK COMPATIBILITY IDEOGRAPH-2F96A                                           */
    { 0x025F86 }, /* 0x02F96B CJK COMPATIBILITY IDEOGRAPH-2F96B                                           */
    /* ---- index: 146 ---- */
    { 0x026228 }, /* 0x02F972 CJK COMPATIBILITY IDEOGRAPH-2F972                                           */
    { 0x026247 }, /* 0x02F973 CJK COMPATIBILITY IDEOGRAPH-2F973                                           */
    { 0x004359 }, /* 0x02F974 CJK COMPATIBILITY IDEOGRAPH-2F974                                           */
    { 0x0262D9 }, /* 0x02F975 CJK COMPATIBILITY IDEOGRAPH-2F975                                           */
    { 0x007F7A }, /* 0x02F976 CJK COMPATIBILITY IDEOGRAPH-2F976                                           */
    { 0x02633E }, /* 0x02F977 CJK COMPATIBILITY IDEOGRAPH-2F977                                           */
    { 0x007F95 }, /* 0x02F978 CJK COMPATIBILITY IDEOGRAPH-2F978                                           */
    { 0x007FFA }, /* 0x02F979 CJK COMPATIBILITY IDEOGRAPH-2F979                                           */
    { 0x008005 }, /* 0x02F97A CJK COMPATIBILITY IDEOGRAPH-2F97A                                           */
    { 0x0264DA }, /* 0x02F97B CJK COMPATIBILITY IDEOGRAPH-2F97B                                           */
    { 0x026523 }, /* 0x02F97C CJK COMPATIBILITY IDEOGRAPH-2F97C                                           */
    { 0x008060 }, /* 0x02F97D CJK COMPATIBILITY IDEOGRAPH-2F97D                                           */
    { 0x0265A8 }, /* 0x02F97E CJK COMPATIBILITY IDEOGRAPH-2F97E                                           */
    { 0x008070 }, /* 0x02F97F CJK COMPATIBILITY IDEOGRAPH-2F97F                                           */
    { 0x02335F }, /* 0x02F980 CJK COMPATIBILITY IDEOGRAPH-2F980                                           */
    /* ---- index: 161 ---- */
    { 0x0267A7 }, /* 0x02F987 CJK COMPATIBILITY IDEOGRAPH-2F987                                           */
    { 0x0267B5 }, /* 0x02F988 CJK COMPATIBILITY IDEOGRAPH-2F988                                           */
    { 0x023393 }, /* 0x02F989 CJK COMPATIBILITY IDEOGRAPH-2F989                                           */
    { 0x02339C }, /* 0x02F98A CJK COMPATIBILITY IDEOGRAPH-2F98A                                           */
    /* ---- index: 165 ---- */
    { 0x026B3C }, /* 0x02F997 CJK COMPATIBILITY IDEOGRAPH-2F997                                           */
    /* ---- index: 166 ---- */
    { 0x026C36 }, /* 0x02F9A4 CJK COMPATIBILITY IDEOGRAPH-2F9A4                                           */
    { 0x026D6B }, /* 0x02F9A5 CJK COMPATIBILITY IDEOGRAPH-2F9A5                                           */
    { 0x026CD5 }, /* 0x02F9A6 CJK COMPATIBILITY IDEOGRAPH-2F9A6                                           */
    { 0x00452B }, /* 0x02F9A7 CJK COMPATIBILITY IDEOGRAPH-2F9A7                                           */
    { 0x0084F1 }, /* 0x02F9A8 CJK COMPATIBILITY IDEOGRAPH-2F9A8                                           */
    { 0x0084F3 }, /* 0x02F9A9 CJK COMPATIBILITY IDEOGRAPH-2F9A9                                           */
    { 0x008516 }, /* 0x02F9AA CJK COMPATIBILITY IDEOGRAPH-2F9AA                                           */
    { 0x0273CA }, /* 0x02F9AB CJK COMPATIBILITY IDEOGRAPH-2F9AB                                           */
    { 0x008564 }, /* 0x02F9AC CJK COMPATIBILITY IDEOGRAPH-2F9AC                                           */
    { 0x026F2C }, /* 0x02F9AD CJK COMPATIBILITY IDEOGRAPH-2F9AD                                           */
    { 0x00455D }, /* 0x02F9AE CJK COMPATIBILITY IDEOGRAPH-2F9AE                                           */
    { 0x004561 }, /* 0x02F9AF CJK COMPATIBILITY IDEOGRAPH-2F9AF                                           */
    { 0x026FB1 }, /* 0x02F9B0 CJK COMPATIBILITY IDEOGRAPH-2F9B0                                           */
    { 0x0270D2 }, /* 0x02F9B1 CJK COMPATIBILITY IDEOGRAPH-2F9B1                                           */
    /* ---- index: 180 ---- */
    { 0x027667 }, /* 0x02F9C5 CJK COMPATIBILITY IDEOGRAPH-2F9C5                                           */
    { 0x0088D7 }, /* 0x02F9C6 CJK COMPATIBILITY IDEOGRAPH-2F9C6                                           */
    { 0x0088DE }, /* 0x02F9C7 CJK COMPATIBILITY IDEOGRAPH-2F9C7                                           */
    { 0x004635 }, /* 0x02F9C8 CJK COMPATIBILITY IDEOGRAPH-2F9C8                                           */
    { 0x0088FA }, /* 0x02F9C9 CJK COMPATIBILITY IDEOGRAPH-2F9C9                                           */
    { 0x0034BB }, /* 0x02F9CA CJK COMPATIBILITY IDEOGRAPH-2F9CA                                           */
    { 0x0278AE }, /* 0x02F9CB CJK COMPATIBILITY IDEOGRAPH-2F9CB                                           */
    { 0x027966 }, /* 0x02F9CC CJK COMPATIBILITY IDEOGRAPH-2F9CC                                           */
    /* ---- index: 188 ---- */
    { 0x027CA8 }, /* 0x02F9D3 CJK COMPATIBILITY IDEOGRAPH-2F9D3                                           */
    { 0x008CAB }, /* 0x02F9D4 CJK COMPATIBILITY IDEOGRAPH-2F9D4                                           */
    { 0x008CC1 }, /* 0x02F9D5 CJK COMPATIBILITY IDEOGRAPH-2F9D5                                           */
    { 0x008D1B }, /* 0x02F9D6 CJK COMPATIBILITY IDEOGRAPH-2F9D6                                           */
    { 0x008D77 }, /* 0x02F9D7 CJK COMPATIBILITY IDEOGRAPH-2F9D7                                           */
    { 0x027F2F }, /* 0x02F9D8 CJK COMPATIBILITY IDEOGRAPH-2F9D8                                           */
    { 0x020804 }, /* 0x02F9D9 CJK COMPATIBILITY IDEOGRAPH-2F9D9                                           */
    { 0x008DCB }, /* 0x02F9DA CJK COMPATIBILITY IDEOGRAPH-2F9DA                                           */
    { 0x008DBC }, /* 0x02F9DB CJK COMPATIBILITY IDEOGRAPH-2F9DB                                           */
    { 0x008DF0 }, /* 0x02F9DC CJK COMPATIBILITY IDEOGRAPH-2F9DC                                           */
    { 0x0208DE }, /* 0x02F9DD CJK COMPATIBILITY IDEOGRAPH-2F9DD                                           */
    { 0x008ED4 }, /* 0x02F9DE CJK COMPATIBILITY IDEOGRAPH-2F9DE                                           */
    { 0x008F38 }, /* 0x02F9DF CJK COMPATIBILITY IDEOGRAPH-2F9DF                                           */
    { 0x0285D2 }, /* 0x02F9E0 CJK COMPATIBILITY IDEOGRAPH-2F9E0                                           */
    { 0x0285ED }, /* 0x02F9E1 CJK COMPATIBILITY IDEOGRAPH-2F9E1                                           */
    { 0x009094 }, /* 0x02F9E2 CJK COMPATIBILITY IDEOGRAPH-2F9E2                                           */
    { 0x0090F1 }, /* 0x02F9E3 CJK COMPATIBILITY IDEOGRAPH-2F9E3                                           */
    { 0x009111 }, /* 0x02F9E4 CJK COMPATIBILITY IDEOGRAPH-2F9E4                                           */
    { 0x02872E }, /* 0x02F9E5 CJK COMPATIBILITY IDEOGRAPH-2F9E5                                           */
    /* ---- index: 207 ---- */
    { 0x028BFA }, /* 0x02F9ED CJK COMPATIBILITY IDEOGRAPH-2F9ED                                           */
    { 0x00958B }, /* 0x02F9EE CJK COMPATIBILITY IDEOGRAPH-2F9EE                                           */
    { 0x004995 }, /* 0x02F9EF CJK COMPATIBILITY IDEOGRAPH-2F9EF                                           */
    { 0x0095B7 }, /* 0x02F9F0 CJK COMPATIBILITY IDEOGRAPH-2F9F0                                           */
    { 0x028D77 }, /* 0x02F9F1 CJK COMPATIBILITY IDEOGRAPH-2F9F1                                           */
    { 0x0049E6 }, /* 0x02F9F2 CJK COMPATIBILITY IDEOGRAPH-2F9F2                                           */
    { 0x0096C3 }, /* 0x02F9F3 CJK COMPATIBILITY IDEOGRAPH-2F9F3                                           */
    { 0x005DB2 }, /* 0x02F9F4 CJK COMPATIBILITY IDEOGRAPH-2F9F4                                           */
    { 0x009723 }, /* 0x02F9F5 CJK COMPATIBILITY IDEOGRAPH-2F9F5                                           */
    { 0x029145 }, /* 0x02F9F6 CJK COMPATIBILITY IDEOGRAPH-2F9F6                                           */
    { 0x02921A }, /* 0x02F9F7 CJK COMPATIBILITY IDEOGRAPH-2F9F7                                           */
    { 0x004A6E }, /* 0x02F9F8 CJK COMPATIBILITY IDEOGRAPH-2F9F8                                           */
    { 0x004A76 }, /* 0x02F9F9 CJK COMPATIBILITY IDEOGRAPH-2F9F9                                           */
    { 0x0097E0 }, /* 0x02F9FA CJK COMPATIBILITY IDEOGRAPH-2F9FA                                           */
    { 0x02940A }, /* 0x02F9FB CJK COMPATIBILITY IDEOGRAPH-2F9FB                                           */
    { 0x004AB2 }, /* 0x02F9FC CJK COMPATIBILITY IDEOGRAPH-2F9FC                                           */
    { 0x029496 }, /* 0x02F9FD CJK COMPATIBILITY IDEOGRAPH-2F9FD                                           */
    { 0x00980B }, /* 0x02F9FE CJK COMPATIBILITY IDEOGRAPH-2F9FE                                           */
    { 0x00980B }, /* 0x02F9FF CJK COMPATIBILITY IDEOGRAPH-2F9FF                                           */
    { 0x009829 }, /* 0x02FA00 CJK COMPATIBILITY IDEOGRAPH-2FA00                                           */
    { 0x0295B6 }, /* 0x02FA01 CJK COMPATIBILITY IDEOGRAPH-2FA01                                           */
    /* ---- index: 228 ---- */
    { 0x029B30 }, /* 0x02FA09 CJK COMPATIBILITY IDEOGRAPH-2FA09                                           */
    /* ---- index: 229 ---- */
    { 0x02A0CE }, /* 0x02FA10 CJK COMPATIBILITY IDEOGRAPH-2FA10                                           */
    { 0x004CF8 }, /* 0x02FA11 CJK COMPATIBILITY IDEOGRAPH-2FA11                                           */
    { 0x02A105 }, /* 0x02FA12 CJK COMPATIBILITY IDEOGRAPH-2FA12                                           */
    { 0x02A20E }, /* 0x02FA13 CJK COMPATIBILITY IDEOGRAPH-2FA13                                           */
    { 0x02A291 }, /* 0x02FA14 CJK COMPATIBILITY IDEOGRAPH-2FA14                                           */
    /* ---- index: 234 ---- */
    { 0x02A600 }, /* 0x02FA1D CJK COMPATIBILITY IDEOGRAPH-2FA1D                                           */
};


/* ******************** End of Script-Generated Code ******************** */
