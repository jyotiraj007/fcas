// Copyright (C) 2014 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// norm_nfd.c


#include "normalization/norm_nfddat.h"
#include "normalization/norm_nrmtxt.h"
#include "normalization/norm_cmb.h"
#include "normalization/norm_nfd.h"
#include "utils.h"

/* Note: as of Unicode 4.0, no char canonically decomposes to more than 4 chars */
#define DECOMPOSITION_STACK_SIZE 4
static LF_ERROR
TsNorm_decomposeCharFully(
    ULONG       origChar,
    TsNormTextObj *outputTextObj,
    LONG      *outputIndex,
    LONG       sourceIndex
)
{
    CHAR stackDepth;
    boolean successfulDecomp;
    ULONG decompChar1;
    ULONG decompChar2;
    ULONG compChar;
    ULONG stack[DECOMPOSITION_STACK_SIZE];
    LF_ERROR result;

    result = LF_ERROR_OK;
    decompChar1 = 0;
    decompChar2 = 0;
    compChar = origChar;
    stackDepth = -1;

    do
    {
        successfulDecomp = TsNorm_decomposeChar(compChar, &decompChar1, &decompChar2);
        if(successfulDecomp)
        {
            if((decompChar2 != 0) && (stackDepth < (DECOMPOSITION_STACK_SIZE - 1)))
            {
                stackDepth++;
                stack[stackDepth] = decompChar2;
            }
            compChar = decompChar1;
        } else if(stackDepth < (DECOMPOSITION_STACK_SIZE - 1))
        {
            stackDepth++;
            stack[stackDepth] = compChar;
        }
    } while(successfulDecomp);

    while(stackDepth >= 0)
    {
        /*lint -save -e644 */ /* tell lint I'm sure the stack will be initialized by now */
        result = outputTextObj->setChar(outputTextObj, *outputIndex, stack[stackDepth], sourceIndex);
        LF_CHECK_RESULT(result);

        /*lint -restore */
        *outputIndex += 1;
        stackDepth--;
    }

    return result;
}



/*lint +fpn*/ /* be sure to check for NULL pointer issues in exported functions */

LF_ERROR
TsNorm_decomposeStringToNFD(
    const TsNormTextObj *inputTextObj,
    LONG       inputStartIndex,
    LONG       inputEndIndex,
    TsNormTextObj *outputTextObj,
    LONG       outputStartIndex,
    LONG       *outputEndIndex
)
{
    LONG outputIndex;
    LONG inputIndex;
    LONG sourceIndex;
    ULONG origChar;
    LF_ERROR result;

    if(inputTextObj == NULL)
        return LF_INVALID_PARAM;
    if(outputTextObj == NULL)
        return LF_INVALID_PARAM;
    if(outputEndIndex == NULL)
        return LF_INVALID_PARAM;

    inputIndex = inputStartIndex;
    outputIndex = outputStartIndex;
    *outputEndIndex = outputStartIndex;

    while(inputIndex <= inputEndIndex)
    {
        result = inputTextObj->getChar(inputTextObj, inputIndex, &origChar, &sourceIndex);
        LF_CHECK_RESULT(result);

        result = TsNorm_decomposeCharFully(origChar, outputTextObj, &outputIndex, sourceIndex);
        LF_CHECK_RESULT(result);

        inputIndex++;
    }
    outputIndex--;

    result = TsNorm_canonicallyReorderCombiningMarks(outputTextObj, outputStartIndex, outputIndex);
    LF_CHECK_RESULT(result);

    *outputEndIndex = outputIndex;

    return result;
}



boolean
TsNorm_decomposeChar(ULONG inputChar, ULONG * pDecompChar1, ULONG * pDecompChar2)
{
    boolean successfulDecomposition;
    LONG lower, middle, upper;
    USHORT tableNum;
    LONG index;

    if(pDecompChar1 == NULL)
        return FALSE;
    if(pDecompChar2 == NULL)
        return FALSE;

    successfulDecomposition = FALSE;

    /* binary search -- do NOT use bsearch() due to issues with Symbian packing of arrays of structs */
    lower = -1;
    upper = TS_NUM_DECOMPOSITION_GROUPS;

    while(lower+1 != upper)
    {
        middle = NORM_INT32_DIV2(lower + upper);
        if(decompositionIndex[middle].start > inputChar)
            upper = middle;
        else
            lower = middle;
    }

    if(lower >= 0)
    {
        if((decompositionIndex[lower].start <= inputChar) &&
           ((decompositionIndex[lower].start + decompositionIndex[lower].length) > inputChar))
        {
            /* found a matching block */
            tableNum = ((decompositionIndex[lower].tableNumAndIndex & 0xC000) >> 14);
            index = ((decompositionIndex[lower].tableNumAndIndex & 0x3FFF) +
                     (inputChar - decompositionIndex[lower].start));
            switch(tableNum)
            {
                case 0:
                    *pDecompChar1 = decompositionData0[index].decompChar1;
                    *pDecompChar2 = decompositionData0[index].decompChar2;
                    break;
                case 1:
                    *pDecompChar1 = decompositionData1[index].decompChar1;
                    *pDecompChar2 = 0;
                    break;
                case 2:
                    *pDecompChar1 = decompositionData2[index].decompChar1;
                    *pDecompChar2 = decompositionData2[index].decompChar2;
                    break;
                case 3:
                    *pDecompChar1 = decompositionData3[index].decompChar1;
                    *pDecompChar2 = 0;
                    break;
                default:
                    /* should never get here */
                    //ASSERT(0); /* Note: Klocwork reports unreacable code here. */
                    ASSERT(tableNum < 4);
                    break;
            }

            if(*pDecompChar1 != 0) /* make sure it is not a padding entry */
                successfulDecomposition = TRUE;
        }
    }

    if(successfulDecomposition == FALSE)
    {
        *pDecompChar1 = 0;
        *pDecompChar2 = 0;
    }
    return successfulDecomposition;
}

/*lint -fpn */ /* turn off checking for NULL pointer issues */
