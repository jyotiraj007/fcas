// Copyright (C) 2014 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// norm_nfc.c

#include <stdlib.h>
#include "data_types.h"
#include "lf_error.h"
#include "normalization/norm_nfcdat.h"
#include "normalization/norm_nrmtxt.h"
#include "normalization/norm_cmb.h"
#include "normalization/norm_nfd.h"

#define  IS_HANGUL_JAMO(c) (((c >= 0x1100) && (c <= 0x11FF)) || ((c >= 0x3130) && (c <= 0x318F)))
#define  IS_HANGUL_SYLLABLE(c) ((c >= 0xAC00) && (c <= 0xD7AF))


static CompositionDataType *
searchForCompChar(USHORT origChar1, USHORT origChar2, USHORT index, USHORT length)
{
    CompositionDataType * pEntry;
    LONG lower, middle, upper;
    BYTE decomp1, decomp2;

    /* look up the characters in the composition table */
    /* binary search -- do NOT use bsearch() due to issues with Symbian packing of arrays of structs */
    lower = index - 1;
    upper = index + length;
    decomp1 = (BYTE)(origChar1 & 0xFF); /* table only stores lower byte */
    decomp2 = (BYTE)(origChar2 & 0xFF); /* table only stores lower byte */
    while(lower+1 != upper)
    {
        middle = NORM_INT32_DIV2(lower + upper);
        if(compositionData[middle].decompChar1 < decomp1)
            lower = middle;
        else if (compositionData[middle].decompChar1 > decomp1)
            upper = middle;
        else if (compositionData[middle].decompChar2 < decomp2)
            lower = middle;
        else
            upper = middle;
    }
    if((upper >= (index + length)) || (compositionData[upper].decompChar1 != decomp1) || (compositionData[upper].decompChar2 != decomp2))
    {
        pEntry = NULL;
    }
    else
    {
        pEntry = (CompositionDataType *)&compositionData[upper];
    }

    return pEntry;
}


static ULONG
composeChars(ULONG origChar1, ULONG origChar2)
{
    ULONG composedChar;
    USHORT block;
    BYTE metaIndex;
    const CompositionIndexType *pCompIdx;
    CompositionDataType *pCompEntry;

    composedChar = 0;

    block = (USHORT)((origChar1 & 0xFFFF00) >> 8);
    metaIndex = compositionMetaIndex[block];
    if(metaIndex != SENTINEL_VALUE){
        pCompIdx = &compositionIndex[metaIndex];
        if((origChar2 & 0xFFFF00) == (ULONG)(pCompIdx->decompChar2Min & 0xFFFF00))
        {
            if((origChar1 >= pCompIdx->decompChar1Min) &&
               (origChar1 <= pCompIdx->decompChar1Max) &&
               (origChar2 >= pCompIdx->decompChar2Min) &&
               (origChar2 <= pCompIdx->decompChar2Max))
            {
                pCompEntry = searchForCompChar((USHORT)origChar1, (USHORT)origChar2, pCompIdx->index, pCompIdx->length);
                if(pCompEntry != NULL)
                {
                    composedChar = pCompEntry->compositeChar;
                }
            }
        }
    }
    return composedChar;
}


static LF_ERROR
composeRun(
    const TsNormTextObj *inputTextObj,
    LONG       inputStartIndex,
    LONG       inputEndIndex,

    TsNormTextObj *outputTextObj,
    LONG      *outputIndex
)
{
    LONG i;
    LONG outputStarterCharIndex;
    ULONG composedChar, composedPair;
    USHORT prevCharClass;
    USHORT currCharClass;
    ULONG currChar;
    LONG starterSourceIndex, trailerSourceIndex;
    LF_ERROR result;

    /*
    D1. A character S is a starter if it has a canonical class of zero in the
    Unicode Character Database.
    */

    if(inputTextObj == NULL)
        return LF_INVALID_PARAM;

    outputStarterCharIndex = *outputIndex;
    result = inputTextObj->getChar(inputTextObj, inputStartIndex, &composedChar, &starterSourceIndex);
    LF_CHECK_RESULT(result);

    prevCharClass = 0;

    *outputIndex += 1;
    for(i = inputStartIndex + 1; i <= inputEndIndex; i++)
    {
        result = inputTextObj->getChar(inputTextObj, i, &currChar, &trailerSourceIndex);
        LF_CHECK_RESULT(result);

        currCharClass = (USHORT)TsNorm_getCombiningClass(currChar);

        /*
        D2. In any character sequence beginning with a starter S, a
        character C is blocked from S if and only if there is some character
        B between S and C, and either B is a starter or it has the same or
        higher combining class as C.
        */
        composedPair = 0;
        if((currCharClass > prevCharClass) || (prevCharClass == 0))
        {
            composedPair = composeChars(composedChar, currChar);
            if(composedPair != 0)
            {
                composedChar = composedPair;
                currCharClass = 0; /* to prevent D2 blocking */
            }
        }
        if(composedPair == 0)
        {
            result = outputTextObj->setChar(outputTextObj, *outputIndex, currChar, trailerSourceIndex);
            LF_CHECK_RESULT(result);

            *outputIndex += 1;
        }
        prevCharClass = currCharClass;
    }
    result = outputTextObj->setChar(outputTextObj, outputStarterCharIndex, composedChar, starterSourceIndex);
    LF_CHECK_RESULT(result);

    return LF_ERROR_OK;
}


static LONG
normalizeCompatibilityJamo(LONG compatibilityJamo)
{
    LONG baseJamo;

    if((compatibilityJamo >= 0x3131) && (compatibilityJamo <= 0x318E))
    {
        baseJamo = (LONG)jamoTable[(compatibilityJamo - 0x3131)];
    }
    else
    {
        baseJamo = (LONG)compatibilityJamo;
    }

    return baseJamo;
}


static LF_ERROR
normalizeHangulJamoIntoHangulSyllables(
    const TsNormTextObj *inputTextObj,
    LONG      *inputIndex,
    LONG       inputEndIndex,
    TsNormTextObj *outputTextObj,
    LONG       outputIndex
)
{
    LONG SBase, LBase, VBase, TBase;
    LONG LCount, VCount, TCount;
    LONG LIndex, VIndex, TIndex;
    LONG charsNormalized;
    LONG char1, char2, char3;
    LONG sourceIndex, unusedSourceIndex;
    ULONG syllable;
    LONG charsLeft;
    LF_ERROR result;

    SBase = 0xAC00;
    LBase = 0x1100;
    VBase = 0x1161;
    TBase = 0x11A7;
    LCount = 19;
    VCount = 21;
    TCount = 28;

    charsNormalized = 1;
    syllable = 0;
    charsLeft = (LONG)inputEndIndex - (LONG)*inputIndex;

    result = inputTextObj->getChar(inputTextObj, *inputIndex, (ULONG*)&char1, &sourceIndex);
    LF_CHECK_RESULT(result);

    if(charsLeft >= 1) /* i.e. at least 2 chars (for LV) left */
    {
        TIndex = 0;

        LIndex = normalizeCompatibilityJamo(char1) - LBase;
        if((LIndex >= 0) && (LIndex <= LCount))
        {
            result = inputTextObj->getChar(inputTextObj, *inputIndex + 1, (ULONG*)&char2, &unusedSourceIndex);
            LF_CHECK_RESULT(result);

            VIndex = normalizeCompatibilityJamo(char2) - VBase;
            if((VIndex >= 0) && (VIndex <= VCount))
            {
                if(charsLeft >= 2) /* i.e. at least 3 chars (for LVT) left */
                {
                    result = inputTextObj->getChar(inputTextObj, *inputIndex + 2, (ULONG*)&char3, &unusedSourceIndex);
                    LF_CHECK_RESULT(result);

                    TIndex = normalizeCompatibilityJamo(char3) - TBase;
                }
                if((TIndex > 0) && (TIndex <= TCount))
                {
                    charsNormalized = 3;
                } else
                {
                    TIndex = 0;
                    charsNormalized = 2;
                }
                syllable = (USHORT)((LIndex * VCount + VIndex) * TCount + TIndex + SBase);
            }
        }
    }
    if(syllable != 0)
    {
        result = outputTextObj->setChar(outputTextObj, outputIndex, syllable, sourceIndex);
    } else
    {
        result = outputTextObj->setChar(outputTextObj, outputIndex, (ULONG)char1, sourceIndex);
    }
    LF_CHECK_RESULT(result);

    *inputIndex += (charsNormalized - 1);

    return LF_ERROR_OK;
}

/*lint +fpn */ /* be sure to check for NULL pointer issues in exported functions */

LF_ERROR
TsNorm_composeStringToNFC(
    const TsNormTextObj *inputTextObj,
    LONG       inputStartIndex,
    LONG       inputEndIndex,

    TsNormTextObj *outputTextObj,
    LONG       outputStartIndex,
    LONG       *outputEndIndex, /* output only, not an input */

    TsNormTextObj *bufferForNFDObj
)
{
    boolean   isGoodStarterIndex;
    boolean   isCombiningLetter;
    boolean   isCompositionExcluded;
    boolean   isProcessingNeeded;
    LONG outputIndex;
    LONG inputIndex;
    ULONG inputChar;
    TsCombClassType inputCharClass;
    LONG outputStarterCharIndex;
    LONG inputStarterCharIndex;
    LONG endOfCombiningCharRunIndex;
    LONG endOfNFDIndex;
    LONG sourceIndex;
    LF_ERROR result;

    if(inputTextObj == NULL)
        return LF_INVALID_PARAM;
    if(outputTextObj == NULL)
        return LF_INVALID_PARAM;
    if(outputEndIndex == NULL)
        return LF_INVALID_PARAM;

    inputIndex = inputStartIndex;
    outputIndex = outputStartIndex;

    *outputEndIndex = 0;

    outputStarterCharIndex = 0;
    inputStarterCharIndex = 0;
    isGoodStarterIndex = FALSE;
    isProcessingNeeded = FALSE;

    result = LF_ERROR_OK;

    while(inputIndex <= inputEndIndex)
    {
        result = inputTextObj->getChar(inputTextObj, inputIndex, &inputChar, &sourceIndex);
        LF_CHECK_RESULT(result);

        TsNorm_getCombiningData(inputChar, &inputCharClass, &isCombiningLetter, &isCompositionExcluded);
        if((inputCharClass != 0) || isCombiningLetter)
        {
            /* it IS a combining mark or a combining letter */
            isProcessingNeeded = TRUE;
        } else
        {
            /* it is NOT a combining mark or a combining letter */
            if(IS_HANGUL_JAMO(inputChar))
            {
                normalizeHangulJamoIntoHangulSyllables(inputTextObj, &inputIndex, inputEndIndex, outputTextObj, outputIndex);
                isGoodStarterIndex = FALSE;
                outputIndex++;
            } else if(IS_HANGUL_SYLLABLE(inputChar))
            {
                //result = outputTextObj->setChar(outputTextObj, outputIndex, inputChar, sourceIndex);
                //LF_CHECK_RESULT(result);

                isGoodStarterIndex = FALSE;
                isProcessingNeeded = FALSE;
                //outputIndex++;
            } else if(isCompositionExcluded)
            {
                inputStarterCharIndex = inputIndex;
                outputStarterCharIndex = outputIndex;
                isGoodStarterIndex = TRUE;
                isProcessingNeeded = TRUE;
            } else
            {
                //result = outputTextObj->setChar(outputTextObj, outputIndex, inputChar, sourceIndex);
                //LF_CHECK_RESULT(result);

                isGoodStarterIndex = TRUE;
                inputStarterCharIndex = inputIndex;
                //outputStarterCharIndex = outputIndex;
                outputStarterCharIndex = outputIndex+1;
                //outputIndex++;
            }
        }
        if(isProcessingNeeded)
        {
            if(isGoodStarterIndex)
            {
                result = TsNorm_findEndOfRunOfCombiningLettersAndMarks(inputTextObj, inputIndex, inputEndIndex, &endOfCombiningCharRunIndex);
                LF_CHECK_RESULT(result);

                result = TsNorm_decomposeStringToNFD(
                    inputTextObj,
                    inputStarterCharIndex,
                    endOfCombiningCharRunIndex,
                    bufferForNFDObj,
                    0, /* NFD start index */
                    &endOfNFDIndex
                );
                LF_CHECK_RESULT(result);

                isGoodStarterIndex = FALSE;
                outputIndex = outputStarterCharIndex;
                composeRun(bufferForNFDObj, 0 /*NFD start index */, endOfNFDIndex, outputTextObj, &outputIndex);
                inputIndex = endOfCombiningCharRunIndex;
            } else
            {
                /* no good starter for combining mark/letter, so just copy it directly */

                /* TS_PRINTF_DEBUG(("WARNING: No good starter for combining mark/letter, copying directly from source:%u to output:%u.\n", sourceIndex, outputIndex)); */
                //result = outputTextObj->setChar(outputTextObj, outputIndex, inputChar, sourceIndex);
                //LF_CHECK_RESULT(result);

                //outputIndex++;

                /* Idea: consider sorting any stray combining marks in place. Note: this is NOT needed for Unicode's NormalizationTest-4.0.0.txt */
            }
            isProcessingNeeded = FALSE;
        }
        inputIndex++;
    }
    outputIndex--;

    *outputEndIndex = outputIndex;

    return result;
}


/*lint -fpn */ /* turn off checking for NULL pointer issues */
