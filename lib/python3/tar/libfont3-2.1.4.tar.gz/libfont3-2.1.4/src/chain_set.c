// Copyright (C) 2014 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// chain_set.c

#include "chain_set.h"
#include "utils.h"
#include "common_table.h"
#include "chain_rule.h"
#include "stream.h"

/* ============================================================================
    @description
        read in a collection of chain_set structures and store them
        in a vector collection.

    @param
        rulesets       :        pointer to a vector collection to hold chain sets.

        numSets        :        the number of sets to read in

        stream         :        pointer to the stream

        baseOffset     :        stream offset to the start of the rule table
                                from which all of the offsets are based upon
                                within this rule.

============================================================================ */
LF_ERROR ChainSets_readRuleSets(LF_VECTOR* chainsets, USHORT numSets, LF_STREAM* stream, ULONG baseOffset)
{
    USHORT      n;
    LF_ERROR    error = LF_ERROR_OK;
    size_t      curOffset, newOffset;

    // loop through all of the chain sets in the stream, and populate them
    for (n = 0; n < numSets; n++)
    {
        chain_set* cs = (chain_set*)calloc(1, sizeof(chain_set));
        if (cs == NULL)
        {
            DEBUG_LOG_ERROR("failed to allocate a chain set");
            return LF_OUT_OF_MEMORY;
        }

        newOffset = STREAM_readOffset(stream) + baseOffset;
        curOffset = STREAM_streamPos(stream);
        STREAM_streamSeek(stream, newOffset);

        error = ChainSet_readRuleSet(cs, stream);
        if (error != LF_ERROR_OK)
        {
            DEBUG_LOG_ERROR("An error occurred reading in ChainSet");
            free(cs);
            ChainSets_freeRuleSets(chainsets);
            return error;
        }

        vector_push_back(chainsets, cs);
        STREAM_streamSeek(stream, curOffset);
    }

    return error;
}

void ChainSets_freeRuleSets(LF_VECTOR* chainsets)
{
    ULONG i = 0;
    while (i < chainsets->count)
    {
        chain_set* cs = (chain_set*)vector_at(chainsets, i++);
        ChainSet_freeRuleSet(cs);
        free(cs);
    }
    vector_delete(chainsets);
}

size_t ChainSets_sizeRuleSets(LF_VECTOR* chainsets)
{
    size_t size = 0;
    USHORT count, n;

    count = UTILS_getCount(chainsets);

    for ( n = 0; n < count; n++)
    {
        chain_set* cs = (chain_set*)vector_at(chainsets, n);
        size += ChainSet_sizeRuleSet(cs);
    }

    return size;
}

#ifdef LF_OT_DUMP
void ChainSets_dumpRuleSets(LF_VECTOR* css)
{
    USHORT count, n;

    count = UTILS_getCount(css);

    for ( n = 0; n < count; n++)
    {
        chain_set* cs = (chain_set*)vector_at(css, n);
        ChainSet_dumpRuleSet(cs);
    }
}
#endif

LF_ERROR ChainSets_removeLookupRecordIndex(LF_VECTOR* css, USHORT lookupIndex, SHORT deltaIndex)
{
    ULONG n;

    for (n = 0; n < css->count; n++)
    {
        chain_set* cs = (chain_set*)vector_at(css, n);
        ChainSet_removeLookupRecordIndex(cs, lookupIndex, deltaIndex);
    }

    return LF_ERROR_OK;
}

size_t ChainSet_buildRuleSet(chain_set* cs, LF_STREAM* stream)
{
    USHORT       n, count;
    size_t        curOffset, baseOffset, arrayOffset;
    LF_VECTOR*   crss = &cs->ChainSet;

    baseOffset = STREAM_streamPos(stream);

    count = UTILS_getCount(crss);
    STREAM_writeUShort(stream, count);

    arrayOffset = STREAM_streamPos(stream);
    for (n = 0; n < count; n++)
    {
        STREAM_writeOffset(stream, 0);
    }

    for (n = 0; n < count; n++)
    {
        chain_rule* cr = (chain_rule*)vector_at(crss, n);

        // populate the OFFSET array ...
        curOffset = STREAM_streamPos(stream);

        STREAM_streamSeek(stream, arrayOffset);
        STREAM_writeOffset(stream, (OFFSET)(curOffset - baseOffset));
        STREAM_streamSeek(stream, curOffset);
        arrayOffset += sizeof(OFFSET);

        // build the chain rule
        ChainRule_buildRule(cr, stream);
    }

    return STREAM_streamPos(stream);
}

LF_ERROR ChainSet_readRuleSet(chain_set* cs, LF_STREAM* stream)
{
    LF_ERROR    error;
    USHORT      n, count;
    size_t      curOffset, newOffset, baseOffset;
    chain_rule* cr = NULL;

    ASSERT(cs);
    ASSERT(stream);

    baseOffset = STREAM_streamPos(stream);
    count = STREAM_readUShort(stream);

    error = vector_init(&cs->ChainSet, count, sizeof(ULONG));
    if (error != LF_ERROR_OK)
        return error;

    for ( n = 0; n < count; n++ )
    {
        cr = (chain_rule*)calloc(1, sizeof(chain_rule));
        if (cr == NULL)
        {
            DEBUG_LOG_ERROR("failed to allocate ChainRule");
            ChainSet_freeRuleSet(cs);
            return LF_OUT_OF_MEMORY;
        }

        newOffset = STREAM_readOffset(stream) + baseOffset;
        curOffset = STREAM_streamPos(stream);
        STREAM_streamSeek(stream, newOffset);

        error = ChainRule_readRule(cr, stream);
        if (error != LF_ERROR_OK)
        {
            ChainSet_freeRuleSet(cs);
            return error;
        }
        vector_push_back(&cs->ChainSet, cr);
        STREAM_streamSeek(stream, curOffset);
    }

    return LF_ERROR_OK;
}

void ChainSet_freeRuleSet(chain_set* cs)
{
    ULONG i = 0;
    while (i < cs->ChainSet.count)
    {
        chain_rule* cr = (chain_rule*)vector_at(&cs->ChainSet, i++);
        ChainRule_freeRule(cr);
        free(cr);
    }
    vector_delete(&cs->ChainSet);
}

size_t ChainSet_sizeRuleSet(chain_set* cs)
{
    USHORT   n;
    size_t    size = 0;
    USHORT   count = UTILS_getCount(&cs->ChainSet);

    size += sizeof(USHORT);                                                // ChainRuleCount
    size += sizeof(OFFSET) * count;                                        // Offset[ChainRuleCount]

    // size of all ChainRules
    for ( n = 0; n < count; n++)
    {
        chain_rule* cr = (chain_rule*)vector_at(&cs->ChainSet, n);
        size += ChainRule_sizeRule(cr);
    }

    return size;
}

#ifdef LF_OT_DUMP
void ChainSet_dumpRuleSet(chain_set* cs)
{
    USHORT    n, count;

    count = UTILS_getCount(&cs->ChainSet);
    DEBUG_LOG_VALUE("ChainSetCount: ", count);
    for (n = 0; n < count; n++)
    {
        chain_rule* cr = (chain_rule*)vector_at(&cs->ChainSet, n);
        if (cr)
        {
            DEBUG_LOG_VALUE("ChainRule Index: ", n);
            ChainRule_dumpRule(cr);
        }
        else
        {
            DEBUG_LOG_VALUE("ChainRule is NULL at Index: ", n);
        }
    }
}
#endif

LF_ERROR ChainSets_pruneRuleSets(LF_VECTOR* css, coverage_table* table, GlyphID glyphid)
{
    USHORT    n = 0;
    USHORT    index = 0;
    USHORT    m;

    while (n < css->count)
    {
        chain_set* cs = (chain_set*)vector_at(css, n);

        m = 0;
        while (m < cs->ChainSet.count)
        {
            chain_rule* cr = (chain_rule*)vector_at(&cs->ChainSet, m);
            LF_ERROR status = ChainRule_searchRule(cr, glyphid, &index);

            if (status == LF_ERROR_OK)
            {
                DEBUG_LOG_VALUE("removing empty ChainRule", m);
                ChainRule_freeRule(cr);
                free(cr);
                vector_erase(&cs->ChainSet, m);
            }
            else
            {
                m++;
            }
        }

        if (cs->ChainSet.count == 0)
        {
            DEBUG_LOG_VALUE("removing empty ChainSet", n);
            ChainSet_freeRuleSet(cs);
            free(cs);
            vector_erase(css, n);

            Coverage_eraseIndex(table, n);
        }
        else
        {
            n++;
        }
    }

    if (css->count == 0)
        return LF_EMPTY_TABLE;

    return LF_ERROR_OK;
}

LF_ERROR ChainSet_remapRulesSets(LF_VECTOR* css, LF_MAP *remap)
{
    USHORT i, numRuleSets;
    LF_ERROR err;

    numRuleSets = (USHORT)vector_size(css);

    for(i = 0; i < numRuleSets; i++)
    {
        USHORT j, numRules;
        chain_set* cs = (chain_set*)vector_at(css, i);

        numRules = (USHORT)vector_size(&cs->ChainSet);

        for(j = 0; j < numRules; j++)
        {
            chain_rule *cr = (chain_rule *)vector_at(&cs->ChainSet, j);

            err = ChainRule_remapRule(cr, remap);
            if (err != LF_ERROR_OK)
                return err;
        }
    }

    return LF_ERROR_OK;
}

LF_ERROR ChainSet_removeLookupRecordIndex(chain_set* cs, USHORT lookupIndex, SHORT deltaIndex)
{
    USHORT i;

    for (i = 0; i < cs->ChainSet.count; i++)
    {
        chain_rule* cr = (chain_rule*)vector_at(&cs->ChainSet, i);
        Common_removeLookupListIndex(&cr->Input.LookupRecords, lookupIndex, deltaIndex);
    }
    return LF_ERROR_OK;
}

LF_ERROR ChainSets_cleanupLookups(LF_VECTOR* css, TABLE_HANDLE hLookup)
{
    ULONG n;
    ULONG i;
    for (n = 0; n < css->count; n++)
    {
        chain_set* cs = (chain_set*)vector_at(css, n);

        for (i = 0; i < cs->ChainSet.count; i++)
        {
            chain_rule* cr = (chain_rule*)vector_at(&cs->ChainSet, i);
            Common_cleanupLookups(&cr->Input.LookupRecords, hLookup);
        }
    }

    return LF_ERROR_OK;
}

LF_ERROR ChainSets_collectGlyphs(LF_VECTOR* css, GlyphList* keepList, TABLE_HANDLE hTable)
{
    LF_ERROR        error = LF_ERROR_OK;
    USHORT          i, j, numChainSets;

    numChainSets = UTILS_getCount(css);

    for (i = 0; i < numChainSets; i++)
    {
        chain_set* cs = (chain_set*)vector_at(css, i);

        for (j = 0; j < cs->ChainSet.count; j++)
        {
            chain_rule* cr = (chain_rule*)vector_at(&cs->ChainSet, j);
            LF_ERROR status = ChainRule_collectGlyphs(cr, keepList, hTable);

            if (status == LF_ADDED_GLYPH)
                error = status;
        }
    }

    return error;
}
