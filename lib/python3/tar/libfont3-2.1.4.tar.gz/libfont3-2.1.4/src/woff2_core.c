// Copyright (C) 2014, 2015, 2017 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// woff2_core.c

#include "decode_api.h" // Note: there is a Klocwork warning here, but this header is used to avoid confusion between multiple decode.h headers.
#include "encode_api.h"
#include "lf_core.h"
#include "utils.h"
#include "woff_core.h"
#include "woff2_core.h"
#include "sfnt_core.h"
#include "glyf_table.h"
#include "maxp_table.h"
#include "table_tags.h"


//structure for the header of the transformed glyf table buffer
typedef struct _trans_glyf_header_
{
    ULONG   version;                // = 0x00000000
    USHORT  numGlyphs;              // Number of glyphs
    USHORT  indexFormat;            // Offset format for loca table, should be consistent with indexToLocFormat of the original head table (see [OFF] specification)
    ULONG   nContourStreamSize;     // Size of nContour stream (a stream of Int16 values)
    ULONG   nPointsStreamSize;      // Size of nPoints stream (a stream of 255UInt16 values)
    ULONG   flagStreamSize;         // Size of flag stream (a stream of UInt8 values)
    ULONG   glyphStreamSize;        // Size of glyph stream (a stream of variable-length encoded values, see description below)
    ULONG   compositeStreamSize;    // Size of composite stream (a stream of variable-length encoded values, see description below)
    ULONG   bboxStreamSize;         // Size of bbox stream (a stream of Int16 values)
    ULONG   instructionStreamSize;  // Size of instruction stream (a stream of UInt8 values)
    BYTE*   bboxBitmap;             // Bitmap indicating explicit bounding boxes
} trans_glyf_header;

enum transStreamType
{
    eContours = 0,
    eNPoints,
    eFlags,
    eGlyph,
    eComposite,
    eBBox,
    eInstructions,
    eNumStreams
};

typedef struct _transformedGlyfInfo_
{
    trans_glyf_header header;
    LF_STREAM* streams[eNumStreams];
} transformedGlyfInfo;

typedef struct _glyf_bbox_
{
    SHORT    xMin;                //Minimum x for coordinate data.
    SHORT    yMin;                //Minimum y for coordinate data.
    SHORT    xMax;                //Maximum x for coordinate data.
    SHORT    yMax;                //Maximum y for coordinate data.
} glyf_bbox;

// structure containing buffers which are reused as the transformed glyf table is being unpacked, allocate based on maxp table info
typedef struct _glyf_scratch_
{
    BYTE*       flags;                  // buffer for flags
    BYTE*       xcoords;                // buffer for x coordinates
    BYTE*       ycoords;                // buffer for y coordinates
    BYTE*       raw;                    // buffer for combined raw glypdata (other than header)
    ULONG       flagsSize;              // number of bytes at flags
    ULONG       xcoordsSize;            // number of bytes at xcoords
    ULONG       ycoordsSize;            // number of bytes at ycoords
    ULONG       rawSize;                // number of bytes at raw
} glyf_scratch_space;

static void WOFF2_cleanupTransformedInfo(const transformedGlyfInfo* glyfInfo);
static void WOFF2_freeScratchSpace(const glyf_scratch_space* ss);

LF_ERROR WOFF2_readOffsetTable(LF_FONT* lfFont, LF_STREAM* stream, int keepFlags)
{
    lfFont->offset_table.woff = offset_woff2_readTable(stream, keepFlags);

    return (lfFont->offset_table.woff2 != NULL) ? LF_ERROR_OK : LF_OUT_OF_MEMORY;
}

LF_ERROR WOFF2_getData(LF_FONT* lfFont, LF_STREAM* stream)
{
    size_t curPos;
    woff2_offset_table *woffTable;

    if(lfFont == NULL)
        return LF_INVALID_PARAM;
    if(lfFont->fontType != eLF_WOFF2_FONT)
        return LF_BAD_FORMAT;

    curPos = STREAM_streamPos(stream);

    woffTable = (woff2_offset_table*)lfFont->offset_table.woff2;

    if((woffTable == NULL) || (woffTable->woffHeader.signature != 0x774F4632))
        return LF_BAD_FORMAT;

    lfFont->woffInfo.majorVersion = woffTable->woffHeader.majorVersion;
    lfFont->woffInfo.minorVersion = woffTable->woffHeader.minorVersion;

    if(woffTable->woffHeader.metaLength != 0)
    {
        STREAM_streamSeek(stream, woffTable->woffHeader.metaOffset);
        lfFont->woffInfo.metaData = STREAM_readChunk(stream, woffTable->woffHeader.metaLength);
        if(lfFont->woffInfo.metaData == NULL)
            return LF_OUT_OF_MEMORY;
        lfFont->woffInfo.metaDataLen = woffTable->woffHeader.metaLength;
        lfFont->woffInfo.metaDataOrigLen = woffTable->woffHeader.metaOrigLength;

        STREAM_streamSeek(stream, curPos);
    }

    if(woffTable->woffHeader.privLength != 0)
    {
        STREAM_streamSeek(stream, woffTable->woffHeader.privOffset);
        lfFont->woffInfo.privateData = STREAM_readChunk(stream, woffTable->woffHeader.privLength);
        if(lfFont->woffInfo.privateData == NULL)
            return LF_OUT_OF_MEMORY;    // metaData freed in LF_freeFont
        lfFont->woffInfo.privateDataLen = woffTable->woffHeader.privLength;

        STREAM_streamSeek(stream, curPos);
    }

    lfFont->woffInfo.metatDataCompression = eWOFF2;

    return LF_ERROR_OK;
}

static LF_ERROR WOFF2_initTransGlyfInfoRead(BYTE *transGlyfBuf, ULONG transformedLength, transformedGlyfInfo* glyfInfo)
{
    USHORT i;
    ULONG totLen, numBBoxBytes;
    BYTE *p;
    LF_STREAM transGlyf;

    if(transformedLength == 0)
        return LF_BAD_FORMAT;

    // init the transformed buffer into a stream
    STREAM_initMemStream(&transGlyf, transGlyfBuf, transformedLength);

    // init the result
    memset(glyfInfo, 0, sizeof(transformedGlyfInfo));

    // parse the header
    glyfInfo->header.version              = STREAM_readFixed(&transGlyf);
    glyfInfo->header.numGlyphs            = STREAM_readUShort(&transGlyf);
    glyfInfo->header.indexFormat          = STREAM_readUShort(&transGlyf);
    glyfInfo->header.nContourStreamSize   = STREAM_readULong(&transGlyf);
    glyfInfo->header.nPointsStreamSize    = STREAM_readULong(&transGlyf);
    glyfInfo->header.flagStreamSize       = STREAM_readULong(&transGlyf);
    glyfInfo->header.glyphStreamSize      = STREAM_readULong(&transGlyf);
    glyfInfo->header.compositeStreamSize  = STREAM_readULong(&transGlyf);
    glyfInfo->header.bboxStreamSize       = STREAM_readULong(&transGlyf);
    glyfInfo->header.instructionStreamSize= STREAM_readULong(&transGlyf);

    // according to the spec, the next thing in the buffer is an array of bytes which is a bitmask indicating
    // which glyphs have explicit bounding boxes, but that is not present in the reference implementation
    //numBBoxBytes = 4 * ((glyfInfo->header.numGlyphs + 31) / 32);
    //glyfHeader.bboxBitmap               = STREAM_readChunk(&transGlyf, numBBoxBytes);

    // check the header info
    if(glyfInfo->header.version != 0)
        return LF_BAD_FORMAT;
    if((glyfInfo->header.indexFormat != 0) && (glyfInfo->header.indexFormat != 1))
        return LF_BAD_FORMAT;

    totLen = glyfInfo->header.nContourStreamSize +  glyfInfo->header.nPointsStreamSize +
             glyfInfo->header.flagStreamSize + glyfInfo->header.glyphStreamSize +
             glyfInfo->header.compositeStreamSize + glyfInfo->header.bboxStreamSize +
             glyfInfo->header.instructionStreamSize;
    totLen += 9*sizeof(ULONG);   // for the header (note that the spec also includes an array for the bounding box bitmask, which is not present in the reference implementation)

    if(totLen > transformedLength)
        return LF_BAD_FORMAT;

    // allocate streams
    for(i = 0; i < eNumStreams; i++)
    {
        glyfInfo->streams[i] = (LF_STREAM*)calloc(1, sizeof(LF_STREAM));
        if(glyfInfo->streams[i] == NULL)
        {
            WOFF2_cleanupTransformedInfo(glyfInfo);
            return LF_OUT_OF_MEMORY;
        }
    }

    // initialize streams
    p = transGlyfBuf;

    // get to beginning of contour stream
    //curPtr += 36 + numBBoxBytes;  // according to spec.
    p += 36;                        // per reference impl.
    STREAM_initMemStream(glyfInfo->streams[eContours], p, glyfInfo->header.nContourStreamSize);

    p += glyfInfo->header.nContourStreamSize;
    STREAM_initMemStream(glyfInfo->streams[eNPoints], p, glyfInfo->header.nPointsStreamSize);

    p += glyfInfo->header.nPointsStreamSize;
    STREAM_initMemStream(glyfInfo->streams[eFlags], p, glyfInfo->header.flagStreamSize);

    p += glyfInfo->header.flagStreamSize;
    STREAM_initMemStream(glyfInfo->streams[eGlyph], p, glyfInfo->header.glyphStreamSize);

    p += glyfInfo->header.glyphStreamSize;
    STREAM_initMemStream(glyfInfo->streams[eComposite], p, glyfInfo->header.compositeStreamSize);

    p += glyfInfo->header.compositeStreamSize;

    // according to the spec, the next thing is the bounding box stream
    //STREAM_initMemStream(glyfInfo->streams[eBBox], p, glyfInfo->header.bboxStreamSize);

    // but the reference implementation writes the bounding box bitmask next
    numBBoxBytes = 4 * ((glyfInfo->header.numGlyphs + 31) / 32);
    STREAM_streamSeek(&transGlyf, (p-transGlyfBuf));
    glyfInfo->header.bboxBitmap = STREAM_readChunk(&transGlyf, numBBoxBytes);
    if(glyfInfo->header.bboxBitmap == NULL)
    {
        WOFF2_cleanupTransformedInfo(glyfInfo);
        return LF_OUT_OF_MEMORY;
    }
    STREAM_initMemStream(glyfInfo->streams[eBBox], (p+numBBoxBytes), glyfInfo->header.bboxStreamSize-numBBoxBytes);

    p += glyfInfo->header.bboxStreamSize;
    STREAM_initMemStream(glyfInfo->streams[eInstructions], p, glyfInfo->header.instructionStreamSize);

    return LF_ERROR_OK;
}

static void WOFF2_cleanupTransformedInfo(const transformedGlyfInfo* glyfInfo)
{
    USHORT i;

    free(glyfInfo->header.bboxBitmap);

    for(i = 0; i < eNumStreams; i++)
        free(glyfInfo->streams[i]);
}

static LF_ERROR WOFF2_allocateScratchSpace(glyf_scratch_space* ss, const maxp_table* maxp)
{
    memset(ss, 0, sizeof(glyf_scratch_space));

    ss->flagsSize = maxp->maxPoints;
    ss->flags = (BYTE*)calloc(maxp->maxPoints, sizeof(BYTE));
    if(ss->flags == NULL)
    {
        WOFF2_freeScratchSpace(ss);
        return LF_OUT_OF_MEMORY;
    }

    ss->xcoordsSize = maxp->maxPoints * 2;
    ss->xcoords = (BYTE*)calloc(maxp->maxPoints * 2, sizeof(BYTE));
    if(ss->xcoords == NULL)
    {
        WOFF2_freeScratchSpace(ss);
        return LF_OUT_OF_MEMORY;
    }

    ss->ycoordsSize = maxp->maxPoints * 2;
    ss->ycoords = (BYTE*)calloc(maxp->maxPoints * 2, sizeof(BYTE));
    if(ss->ycoords == NULL)
    {
        WOFF2_freeScratchSpace(ss);
        return LF_OUT_OF_MEMORY;
    }

    ss->rawSize = sizeof(USHORT) * maxp->maxContours + sizeof(USHORT) +
                  maxp->maxSizeOfInstructions + ss->flagsSize  + ss->xcoordsSize + ss->ycoordsSize;
    ss->raw = (BYTE*)malloc(ss->rawSize);
    if(ss->raw == NULL)
    {
        WOFF2_freeScratchSpace(ss);
        return LF_OUT_OF_MEMORY;
    }

    return LF_ERROR_OK;
}

static void WOFF2_freeScratchSpace(const glyf_scratch_space* ss)
{
    free(ss->xcoords);
    free(ss->ycoords);
    free(ss->raw);
    free(ss->flags);
}

static SHORT WOFF2_withSign(int flag, int baseval)
{
    return (SHORT)((flag & 1) ? baseval : -baseval);
}

static LF_ERROR WOFF2_createGlyfAndLoca(BYTE* transGlyfBuf, ULONG transGlyfLength, ULONG origLength, 
                                        const maxp_table* maxp, BYTE** gylfBuf, ULONG* glyfLen,
                                        BYTE** locaBuf, ULONG* locaLen)
{
    USHORT i;
    ULONG curGlyphOffset = 0;
    LF_ERROR error;
    LF_STREAM glyfStream, locaStream;
    transformedGlyfInfo glyfInfo;
    glyf_bbox curBBox;
    glyf_scratch_space scratch;

    error = WOFF2_initTransGlyfInfoRead(transGlyfBuf, transGlyfLength, &glyfInfo);
    if(error != LF_ERROR_OK)
        return error;

    // calculate size of loca table
    *locaLen = (glyfInfo.header.numGlyphs + 1) * ((glyfInfo.header.indexFormat == 1) ? sizeof(ULONG) : sizeof(USHORT));

    // create streams for the output glyf and loca tables
    //STREAM_createMemStream(&glyfStream, (origLength + (origLength>>3)));  // extra is added here to account for the extra space due to our code 4-byte aligning the glyphs whereas they may not be originally.
    STREAM_createMemStream(&glyfStream, origLength);    // Do not add extra space, as the spec requires that the origLength is sufficient.
    if(glyfStream.Base == NULL)
    {
        WOFF2_cleanupTransformedInfo(&glyfInfo);
        return LF_OUT_OF_MEMORY;
    }

    STREAM_createMemStream(&locaStream, *locaLen);
    if(locaStream.Base == NULL)
    {
        free(glyfStream.Base);
        WOFF2_cleanupTransformedInfo(&glyfInfo);
        return LF_OUT_OF_MEMORY;
    }

    // create scratch space area
    error = WOFF2_allocateScratchSpace(&scratch, maxp);
    if(error != LF_ERROR_OK)
    {
        free(locaStream.Base);
        free(glyfStream.Base);
        WOFF2_cleanupTransformedInfo(&glyfInfo);
        return error;
    }

    // create the glyphs
    for(i = 0; i < glyfInfo.header.numGlyphs; ++i)
    {
        SHORT numContours;
        ULONG glyphSize;
        LF_STREAM glyphRawDataStream;

        glyphSize = 0;
        memset(&curBBox, 0, sizeof(glyf_bbox));

        STREAM_initMemStream(&glyphRawDataStream, scratch.raw, scratch.rawSize);

        // step 1 in spec
        numContours = STREAM_readShort(glyfInfo.streams[eContours]);

        if(numContours == -1)
        {
            // composite glyph
            USHORT flags;
            boolean glyphHasInstructions = FALSE;

            do
            {
                glyphSize += 4; // 2 for flags and 2 for glyph index

                // step 2a of spec
                flags = STREAM_readUShort(glyfInfo.streams[eComposite]);

                STREAM_writeUShort(&glyphRawDataStream, flags);
                STREAM_writeUShort(&glyphRawDataStream, STREAM_readUShort(glyfInfo.streams[eComposite]));           // glyph index

                if((flags & WE_HAVE_INSTRUCTIONS) != 0)
                    glyphHasInstructions = TRUE;

                // step 3a of spec
                if(flags & ARG_1_AND_2_ARE_WORDS)
                {
                    STREAM_writeShort(&glyphRawDataStream, STREAM_readUShort(glyfInfo.streams[eComposite]));        // argument1
                    STREAM_writeShort(&glyphRawDataStream, STREAM_readUShort(glyfInfo.streams[eComposite]));        // argument2

                    glyphSize += 4;
                }
                else
                {
                    STREAM_writeByte(&glyphRawDataStream, (STREAM_readByte(glyfInfo.streams[eComposite])) & 0xFF);  // argument1
                    STREAM_writeByte(&glyphRawDataStream, (STREAM_readByte(glyfInfo.streams[eComposite])) & 0xFF);  // argument2

                    glyphSize += 2;
                }

                if(flags & WE_HAVE_A_SCALE)
                {
                    STREAM_writeShort(&glyphRawDataStream, STREAM_readShort(glyfInfo.streams[eComposite]));         // xscale

                    glyphSize += 2;
                }
                else if(flags & WE_HAVE_AN_X_AND_Y_SCALE)
                {
                    STREAM_writeShort(&glyphRawDataStream, STREAM_readShort(glyfInfo.streams[eComposite]));         // xscale
                    STREAM_writeShort(&glyphRawDataStream, STREAM_readUShort(glyfInfo.streams[eComposite]));        // yscale

                    glyphSize += 4;
                }
                else if(flags & WE_HAVE_A_TWO_BY_TWO)
                {
                    STREAM_writeShort(&glyphRawDataStream, STREAM_readUShort(glyfInfo.streams[eComposite]));        // xscale
                    STREAM_writeShort(&glyphRawDataStream, STREAM_readUShort(glyfInfo.streams[eComposite]));        // scale01
                    STREAM_writeShort(&glyphRawDataStream, STREAM_readUShort(glyfInfo.streams[eComposite]));        // scale10
                    STREAM_writeShort(&glyphRawDataStream, STREAM_readUShort(glyfInfo.streams[eComposite]));        // yscale

                    glyphSize += 8;
                }
            } while(flags & MORE_COMPONENTS);

            if(glyphHasInstructions)
            {
                // step 4a of spec
                USHORT instructionsLength = STREAM_read255UShort(glyfInfo.streams[eGlyph]);
                STREAM_writeUShort(&glyphRawDataStream, instructionsLength);

                STREAM_writeChunk(&glyphRawDataStream, glyfInfo.streams[eInstructions]->Current, instructionsLength);
                glyfInfo.streams[eInstructions]->Current += instructionsLength;

                glyphSize += 2 /* # of instructions */ + instructionsLength;
            }
        }
        else if(numContours > 0)
        {
            // simple glyph
            BYTE repeatCount = 0;
            USHORT j, numPoints = 0, instrLen;
            USHORT flagsBytesNeeded = 0;
            SHORT lastFlag = -1, lastX=0, lastY=0;
            BYTE* curX, *curY;

            curX = scratch.xcoords;
            curY = scratch.ycoords;

            // step 2 of spec
            for(j = 0; j < numContours; j++)
            {
                numPoints += STREAM_read255UShort(glyfInfo.streams[eNPoints]);
                STREAM_writeUShort(&glyphRawDataStream, numPoints-1);
            }

            for(j = 0; j < numPoints; j++)
            {
                BYTE currentFlag = 0, flag, k, numBytes;
                BYTE in[4] = {0};
                SHORT dx, dy;

                flag = STREAM_readByte(glyfInfo.streams[eFlags]); // step 3 of spec

                if((flag & 0x80) == 0)
                    currentFlag |= FLAG_ON_CURVE;

                flag &= 0x7f;

                if(flag < 84)
                    numBytes = 1;
                else if(flag < 120)
                    numBytes = 2;
                else if(flag < 124)
                    numBytes = 3;
                else
                    numBytes = 4;

                for(k = 0; k < numBytes; k++)
                    in[k] = STREAM_readByte(glyfInfo.streams[eGlyph]);

                //lint -e702
                // step 4 of spec
                if(flag < 10)
                {
                    dx = 0;
                    dy = WOFF2_withSign(flag, ((flag & 14) << 7) + in[0]);
                }
                else if(flag < 20)
                {
                    dx = WOFF2_withSign(flag, (((flag - 10) & 14) << 7) + in[0]);
                    dy = 0;
                }
                else if(flag < 84)
                {
                    int b0 = flag - 20;
                    int b1 = in[0];
                    dx = WOFF2_withSign(flag, 1 + (b0 & 0x30) + (b1 >> 4));
                    dy = WOFF2_withSign(flag >> 1, 1 + ((b0 & 0x0c) << 2) + (b1 & 0x0f));
                }
                else if(flag < 120)
                {
                    int b0 = flag - 84;
                    dx = WOFF2_withSign(flag, 1 + ((b0 / 12) << 8) + in[0]);                //lint !e701
                    dy = WOFF2_withSign(flag >> 1, 1 + (((b0 % 12) >> 2) << 8) + in[1]);
                }
                else if(flag < 124)
                {
                    int b2 = in[1];
                    dx = WOFF2_withSign(flag, (in[0] << 4) + (b2 >> 4));
                    dy = WOFF2_withSign(flag >> 1, ((b2 & 0x0f) << 8) + in[2]);
                }
                else
                {
                    dx = WOFF2_withSign(flag, (in[0] << 8) + in[1]);
                    dy = WOFF2_withSign(flag >> 1, (in[2] << 8) + in[3]);
                }

                if(j == 0)
                {
                    curBBox.xMax = curBBox.xMin = dx;
                    curBBox.yMax = curBBox.yMin = dy;
                    lastX = dx;
                    lastY = dy;
                }
                else
                {
                    SHORT x = lastX + dx;
                    SHORT y = lastY + dy;

                    if(x < curBBox.xMin)
                        curBBox.xMin = x;
                    if(x > curBBox.xMax)
                        curBBox.xMax = x;
                    if(y < curBBox.yMin)
                        curBBox.yMin = y;
                    if(y > curBBox.yMax)
                        curBBox.yMax = y;

                    lastX = x;
                    lastY = y;
                }

                if(dx == 0)
                {
                    currentFlag |= FLAG_X_SAME;
                }
                else if(dx > -256 && dx < 256)
                {
                    currentFlag  |= (FLAG_X_SHORT_VECTOR | (dx > 0 ? FLAG_X_SAME : 0));
                    *curX++ = (BYTE)((dx < 0) ? -dx : dx);
                }
                else
                {
                    *curX++ = (BYTE)(dx >> 8);
                    *curX++ = (BYTE)(dx & 0xff);
                }

                if(dy == 0)
                {
                    currentFlag |= FLAG_Y_SAME;
                }
                else if(dy > -256 && dy < 256)
                {
                    currentFlag |= (FLAG_Y_SHORT_VECTOR | (dy > 0 ? FLAG_Y_SAME : 0));
                    *curY++ = (BYTE)((dy < 0) ? -dy : dy);
                }
                else
                {
                    *curY++ = (BYTE)(dy >> 8);
                    *curY++ = (BYTE)(dy & 0xff);
                }
                //lint +e702

                if((currentFlag == lastFlag) && repeatCount != 255)
                {
                    scratch.flags[flagsBytesNeeded - 1] |= FLAG_REPEAT;
                    repeatCount++;
                }
                else
                {
                    if(repeatCount != 0)
                        scratch.flags[flagsBytesNeeded++] = repeatCount;
                    scratch.flags[flagsBytesNeeded++] = currentFlag;
                    repeatCount = 0;
                }

                lastFlag = currentFlag;
            }

            if(repeatCount != 0)
                scratch.flags[flagsBytesNeeded++] = repeatCount;

            instrLen = STREAM_read255UShort(glyfInfo.streams[eGlyph]);  // step 5 of spec
            STREAM_writeUShort(&glyphRawDataStream, instrLen);
            if(instrLen != 0)
            {
                STREAM_writeChunk(&glyphRawDataStream, glyfInfo.streams[eInstructions]->Current, instrLen);  // step 6 of spec
                glyfInfo.streams[eInstructions]->Current += instrLen;
            }

            STREAM_writeChunk(&glyphRawDataStream, scratch.flags, flagsBytesNeeded);
            STREAM_writeChunk(&glyphRawDataStream, scratch.xcoords, curX - scratch.xcoords);
            STREAM_writeChunk(&glyphRawDataStream, scratch.ycoords, curY - scratch.ycoords);

            // calculate the size of the glyf data
            glyphSize = sizeof(USHORT) * numContours/*end points*/ + sizeof(USHORT)/*instr. len*/ + instrLen;

            glyphSize += (ULONG)(flagsBytesNeeded + (curX - scratch.xcoords)  + (curY - scratch.ycoords));
        } // simple glyph

#if 0 // Test code.
        printf("Bounding box of glyph %d:\n", i);
        printf("\t%d %d %d %d\n", curBBox.xMin, curBBox.yMin, curBBox.xMax, curBBox.yMax);
#endif

        // write glyph data to output buffer
        if(glyphSize != 0)
        {
            BYTE pad[3] = {0};
            ULONG totalGlyphSize = glyphSize + GLYF_HEADER_SIZE;
            ULONG paddedGlyphSize = (totalGlyphSize + 3) & ~3;

            STREAM_writeShort(&glyfStream, numContours);
            STREAM_writeShort(&glyfStream, curBBox.xMin);
            STREAM_writeShort(&glyfStream, curBBox.yMin);
            STREAM_writeShort(&glyfStream, curBBox.xMax);
            STREAM_writeShort(&glyfStream, curBBox.yMax);
            STREAM_writeChunk(&glyfStream, scratch.raw, glyphSize);

            if(paddedGlyphSize > totalGlyphSize)
                STREAM_writeChunk(&glyfStream, pad, paddedGlyphSize - totalGlyphSize);
        }

        // write offset to loca buffer
        if(glyfInfo.header.indexFormat == 1)
            STREAM_writeULong(&locaStream, curGlyphOffset);
        else
            STREAM_writeUShort(&locaStream, (USHORT)(curGlyphOffset >> 1));

        if(glyphSize != 0)
            curGlyphOffset += (((glyphSize + GLYF_HEADER_SIZE) + 3) & ~3);
    } // loop over glyphs

    // write last loca value
    if(glyfInfo.header.indexFormat == 1)
        STREAM_writeULong(&locaStream, curGlyphOffset);
    else
        STREAM_writeUShort(&locaStream, (USHORT)(curGlyphOffset >> 1));

    // process bbox stream
    for(i = 0; i < glyfInfo.header.numGlyphs; ++i)
    {
        if(glyfInfo.header.bboxBitmap[i >> 3] & (0x80 >> (i & 7)))
        {
            // the i'th glyph has an explicit bb
            SHORT val;
            ULONG offsetToGlyph;
            BYTE* glyphPtr;

            if(glyfInfo.header.indexFormat == 1)
            {
                offsetToGlyph = *(((ULONG*)(void*)locaStream.Base) + i);
                offsetToGlyph = SWAP_ULONG(offsetToGlyph);
            }
            else
            {
                offsetToGlyph = (ULONG)(*(((USHORT*)(void*)locaStream.Base) + i));
                offsetToGlyph = SWAP_USHORT(offsetToGlyph);
                offsetToGlyph *= 2;
            }

            glyphPtr = glyfStream.Base + offsetToGlyph;

            glyphPtr +=2; // get past the num contours

            val = STREAM_readShort(glyfInfo.streams[eBBox]);       // xMin
            *((SHORT*)(void*)glyphPtr) = SWAP_SHORT(val);
            glyphPtr +=2;

            val = STREAM_readShort(glyfInfo.streams[eBBox]);       // yMin
            *((SHORT*)(void*)glyphPtr) = SWAP_SHORT(val);
            glyphPtr +=2;

            val = STREAM_readShort(glyfInfo.streams[eBBox]);       // xMax
            *((SHORT*)(void*)glyphPtr) = SWAP_SHORT(val);
            glyphPtr +=2;

            val = STREAM_readShort(glyfInfo.streams[eBBox]);       // yMax
            *((SHORT*)(void*)glyphPtr) = SWAP_SHORT(val);
        }
    }

    // assign outputs
    *gylfBuf = glyfStream.Base;
    *glyfLen = (ULONG)STREAM_streamPos(&glyfStream);
    *locaBuf = locaStream.Base;
    ASSERT(*locaLen == STREAM_streamPos(&locaStream));

    // cleanup
    WOFF2_freeScratchSpace(&scratch);
    WOFF2_cleanupTransformedInfo(&glyfInfo);

    return LF_ERROR_OK;
}

static boolean WOFF2_getMAXP(LF_VECTOR* recordList, const BYTE* rawData, maxp_table *maxp)
{
    USHORT i, numTables;
    woff2_table_record* record = NULL;

    numTables = (USHORT)vector_size(recordList);

    if(numTables == 0)
        return FALSE;

    for(i = 0; i < numTables; ++i)
    {
        record = (woff2_table_record*)vector_at(recordList, i);

        if((record != NULL) && (record->tag == TAG_MAXP))
            break;
    }

    ASSERT(i < numTables);      // to check that the maxp table was found
    if((i == numTables) || (record == NULL))
        return FALSE;

    memcpy(maxp, rawData + record->offset, sizeof(maxp_table));

    maxp->version               = SWAP_ULONG( maxp->version);               //lint !e701, !e702
    maxp->numGlyphs             = SWAP_USHORT(maxp->numGlyphs);
    maxp->maxPoints             = SWAP_USHORT(maxp->maxPoints);
    maxp->maxContours           = SWAP_USHORT(maxp->maxContours);
    maxp->maxCompositePoints    = SWAP_USHORT(maxp->maxCompositePoints);
    maxp->maxCompositeContours  = SWAP_USHORT(maxp->maxCompositeContours);
    maxp->maxZones              = SWAP_USHORT(maxp->maxZones);
    maxp->maxTwilightPoints     = SWAP_USHORT(maxp->maxTwilightPoints);
    maxp->maxStorage            = SWAP_USHORT(maxp->maxStorage);
    maxp->maxFunctionDefs       = SWAP_USHORT(maxp->maxFunctionDefs);
    maxp->maxInstructionDefs    = SWAP_USHORT(maxp->maxInstructionDefs);
    maxp->maxStackElements      = SWAP_USHORT(maxp->maxStackElements);
    maxp->maxSizeOfInstructions = SWAP_USHORT(maxp->maxSizeOfInstructions);
    maxp->maxComponentElements  = SWAP_USHORT(maxp->maxComponentElements);
    maxp->maxComponentDepth     = SWAP_USHORT(maxp->maxComponentDepth);

    return TRUE;
}

boolean WOFF2_decompress(const BYTE *compBuf, ULONG compSize, BYTE *dest, size_t *destLen)
{
    int brotliResult = BrotliDecompressBuffer(compSize, compBuf, destLen, dest);

    if ((brotliResult == 0) || (*destLen == 0))
        return FALSE;

    return TRUE;
}

static void WOFF2_cleanSfntTable(sfnt_offset_table* sfntTable)
{
    size_t i;

    for(i = 0; i < sfntTable->record_list.count; ++i)
        free(vector_at(&sfntTable->record_list, i));
    vector_free(&sfntTable->record_list);
    free(sfntTable);
}

// Converts the lfFont from woff2 to sfnt
LF_ERROR WOFF2_to_SFNT(LF_FONT* lfFont, LF_STREAM* stream)
{
    USHORT i;
    LF_ERROR error;
    BYTE* tableDataBlock;
    sfnt_offset_table* sfntTable;
    woff2_offset_table* woffTable;
    size_t uncompressedSize;

    if(lfFont == NULL)
        return LF_INVALID_PARAM;
    if(lfFont->fontType != eLF_WOFF2_FONT)
        return LF_BAD_FORMAT;
    if (stream->Type != eSTREAM_TYPE_MEM)
        return LF_BAD_FORMAT;

    woffTable = (woff2_offset_table*)lfFont->offset_table.woff2;
    ASSERT(woffTable);
    if (NULL == woffTable)
        return LF_BAD_FORMAT;

    // allocate a new sfnt offset table
    sfntTable = (sfnt_offset_table*)calloc(1, sizeof(sfnt_offset_table));
    if(sfntTable == NULL)
        return LF_OUT_OF_MEMORY;

    sfntTable->sfntHeader.sfnt_version = woffTable->woffHeader.flavor;
    sfntTable->sfntHeader.numTables = (USHORT)woffTable->record_list.count;  // this may be less than that specified in the woff2 header
                                                                             // since tables may be skipped when parsing the header

    // these will be calculated when font is written
    sfntTable->sfntHeader.entrySelector = 0;
    sfntTable->sfntHeader.rangeShift = 0;
    sfntTable->sfntHeader.searchRange = 0;

    error = vector_init(&sfntTable->record_list, sfntTable->sfntHeader.numTables, 1);
    if(error != LF_ERROR_OK)
    {
        free(sfntTable);
        return error;
    }

    // allocate a buffer which will hold the uncompressed/untransformed raw data for all of the tables
    // allocating totalSfntSize should be more than enough since we don't actually create an offset table at lfFont->fontData
    lfFont->fontData = (BYTE*)calloc(1, woffTable->woffHeader.totalSfntSize);
    if(lfFont->fontData == NULL)
    {
        vector_free(&sfntTable->record_list);
        free(sfntTable);
        return LF_OUT_OF_MEMORY;
    }
    lfFont->fontSize = woffTable->woffHeader.totalSfntSize;

    // allocate a buffer for the uncompressed data block
    // allocating totalSfntSize should be more than enough since the uncompressed 
    // data does not have an offset table or loca table and the glyf table is transformed (smaller)
    tableDataBlock = (BYTE*)malloc(woffTable->woffHeader.totalSfntSize);
    if(tableDataBlock == NULL)
    {
        free(lfFont->fontData);
        lfFont->fontData = NULL;
        lfFont->fontSize = 0;
        vector_free(&sfntTable->record_list);
        free(sfntTable);
        return LF_OUT_OF_MEMORY;
    }


    // use Brotli decompressor to get the table data block
    uncompressedSize = (size_t)woffTable->woffHeader.totalSfntSize;
    STREAM_streamSeek(stream, woffTable->compressedFontDataOffset);
    if (FALSE == WOFF2_decompress(stream->Current, woffTable->woffHeader.totalCompressedSize, tableDataBlock, &uncompressedSize))
    {
        free(tableDataBlock);
        free(lfFont->fontData);
        lfFont->fontData = NULL;
        lfFont->fontSize = 0;
        vector_free(&sfntTable->record_list);
        free(sfntTable);
        return LF_COMPRESSION;
    }


    {
    BYTE* dstPtr;
    BYTE* glyfBuf = NULL, *locaBuf = NULL;
    USHORT indexOfGlyfTable = 0;
    ULONG glyfLen, locaLen = 0;
    maxp_table maxp;

    // retrieve the maxp table explicitly from the raw data so we can use it's values
    // to preallocate buffers while decoding the transformed glyf table
    if(FALSE == WOFF2_getMAXP(&woffTable->record_list, tableDataBlock,  &maxp))
    {
        free(tableDataBlock);
        free(lfFont->fontData);
        lfFont->fontData = NULL;
        lfFont->fontSize = 0;
        vector_free(&sfntTable->record_list);
        free(sfntTable);
        return LF_BAD_FORMAT;
    }

    // loop over tables
    dstPtr = lfFont->fontData;

    for(i = 0; i < sfntTable->sfntHeader.numTables; ++i)
    {
        BYTE* srcPtr;
        sfnt_table_record* sfntRecord;
        woff2_table_record* woff2record = (woff2_table_record*)vector_at(&woffTable->record_list, i);

        sfntRecord = (sfnt_table_record*)calloc(1, sizeof(sfnt_table_record));
        if((woff2record == NULL) || (sfntRecord == NULL))
        {
            if(sfntRecord)
                free(sfntRecord);
            free(locaBuf);
            free(tableDataBlock);
            WOFF2_cleanSfntTable(sfntTable);
            free(lfFont->fontData);
            lfFont->fontData = NULL;
            lfFont->fontSize = 0;
            return LF_OUT_OF_MEMORY;
        }

        sfntRecord->tag = woff2record->tag;

        srcPtr = tableDataBlock + woff2record->offset;

        if(woff2record->tag == TAG_GLYF)
        {
            // un transform the glyph table
            // the originalLength according to the spec, must be sufficient to decode the glyf table, accounting for possible compression techniques and for
            // going to a table where the glyphs are 4-byte aligned
            error = WOFF2_createGlyfAndLoca(srcPtr, woff2record->transformLength, woff2record->origLength, &maxp, &glyfBuf, &glyfLen, &locaBuf, &locaLen);
            if(error != LF_ERROR_OK)
            {
                free(locaBuf);
                free(sfntRecord);
                free(tableDataBlock);
                WOFF2_cleanSfntTable(sfntTable);
                free(lfFont->fontData);
                lfFont->fontData = NULL;
                lfFont->fontSize = 0;
                return error;
            }

            indexOfGlyfTable = i;

            memcpy(dstPtr, glyfBuf, glyfLen);

            sfntRecord->length = glyfLen;
            sfntRecord->offset = (ULONG)(dstPtr-lfFont->fontData);
            sfntRecord->checkSum = UTILS_CalcTableChecksum(dstPtr, glyfLen);

            dstPtr += (glyfLen + 3) & ~3;

            free(glyfBuf);
        }
        else if(woff2record->tag == TAG_LOCA)
        {
            // according to the spec, the loca table must be right after the glyf table
            //if((indexOfGlyfTable != i-1) || (locaBuf == NULL))
            // but the fonts created by the reference implemeation don't follow that
            if(locaBuf == NULL)
            {
                free(sfntRecord);
                free(tableDataBlock);
                WOFF2_cleanSfntTable(sfntTable);
                free(lfFont->fontData);
                lfFont->fontData = NULL;
                lfFont->fontSize = 0;
                //if(locaBuf) see note above
                //    free(locaBuf);
                return LF_BAD_FORMAT;
            }
            (void)indexOfGlyfTable;

            memcpy(dstPtr, locaBuf, locaLen);

            sfntRecord->length = locaLen;
            sfntRecord->offset = (ULONG)(dstPtr-lfFont->fontData);
            sfntRecord->checkSum = UTILS_CalcTableChecksum(dstPtr, locaLen);

            dstPtr += (locaLen + 3) & ~3;
        }
        else
        {
            memcpy(dstPtr, srcPtr, woff2record->origLength);

            sfntRecord->length = woff2record->origLength;
            sfntRecord->offset = (ULONG)(dstPtr-lfFont->fontData);
            sfntRecord->checkSum = UTILS_CalcTableChecksum(dstPtr, woff2record->origLength);

            dstPtr += (woff2record->origLength + 3) & ~3;
        }

        vector_push_back(&sfntTable->record_list, sfntRecord);
    }

    free(locaBuf);
    }

    // get rid of the woff offset table
    offset_woff2_freeTable(woffTable);

    // switch over to the new sfnt offset table
    lfFont->offset_table.sfnt = sfntTable;
    lfFont->fontType = (sfntTable->sfntHeader.sfnt_version == SIG_CFF) ? eLF_CFF_FONT : eLF_SFNT_FONT;

    free(tableDataBlock);

    return LF_ERROR_OK;
}

static void WOFF2_WriteTriplet(boolean onCurve, SHORT x, SHORT y, LF_STREAM* flagsStr, LF_STREAM* glyphsStr)
{
    int abs_x = (x < 0) ? -x : x;
    int abs_y = (y < 0) ? -y : y;
    int on_curve_bit = onCurve ? 0 : 128;
    int x_sign_bit = (x < 0) ? 0 : 1;
    int y_sign_bit = (y < 0) ? 0 : 1;
    int xy_sign_bits = x_sign_bit + 2 * y_sign_bit;

    //lint -e702
    if(x == 0 && abs_y < 1280)
    {
        STREAM_writeByte(flagsStr, (BYTE)(on_curve_bit + ((abs_y & 0xf00) >> 7) + y_sign_bit));
        STREAM_writeByte(glyphsStr, abs_y & 0xff);
    }
    else if(y == 0 && abs_x < 1280)
    {
        STREAM_writeByte(flagsStr, (BYTE)(on_curve_bit + 10 + ((abs_x & 0xf00) >> 7) + x_sign_bit));
        STREAM_writeByte(glyphsStr, abs_x & 0xff);
    }
    else if(abs_x < 65 && abs_y < 65)
    {
        STREAM_writeByte(flagsStr, (BYTE)(on_curve_bit + 20 +
                                          ((abs_x - 1) & 0x30) +
                                          (((abs_y - 1) & 0x30) >> 2) +
                                          xy_sign_bits));
        STREAM_writeByte(glyphsStr, (((abs_x - 1) & 0xf) << 4) | ((abs_y - 1) & 0xf));
    }
    else if(abs_x < 769 && abs_y < 769)
    {
        STREAM_writeByte(flagsStr, (BYTE)(on_curve_bit + 84 +
                                          12 * (((abs_x - 1) & 0x300) >> 8) +
                                          (((abs_y - 1) & 0x300) >> 6) + xy_sign_bits));
        STREAM_writeByte(glyphsStr, (abs_x - 1) & 0xff);
        STREAM_writeByte(glyphsStr, (abs_y - 1) & 0xff);
    }
    else if(abs_x < 4096 && abs_y < 4096) 
    {
        STREAM_writeByte(flagsStr, (BYTE)(on_curve_bit + 120 + xy_sign_bits));
        STREAM_writeByte(glyphsStr, (BYTE)(abs_x >> 4));
        STREAM_writeByte(glyphsStr, (BYTE)(((abs_x & 0xf) << 4) | (abs_y >> 8)));
        STREAM_writeByte(glyphsStr, abs_y & 0xff);
    }
    else
    {
        STREAM_writeByte(flagsStr, (BYTE)(on_curve_bit + 124 + xy_sign_bits));
        STREAM_writeByte(glyphsStr, (BYTE)(abs_x >> 8));
        STREAM_writeByte(glyphsStr, abs_x & 0xff);
        STREAM_writeByte(glyphsStr, (BYTE)(abs_y >> 8));
        STREAM_writeByte(glyphsStr, abs_y & 0xff);
    }
    //lint +e702
}

static LF_ERROR WOFF2_initTransGlyfInfoWrite(USHORT numGlyphs, ULONG glyfTableLen, transformedGlyfInfo *glyfInfo)
{
    USHORT i;
    ULONG numBBoxBytes;

    memset(glyfInfo, 0, sizeof(transformedGlyfInfo));

    // allocate the streams
    for(i = 0; i < eNumStreams; i++)
    {
        glyfInfo->streams[i] = (LF_STREAM*)calloc(1, sizeof(LF_STREAM));
        if(glyfInfo->streams[i] == NULL)
        {
            WOFF2_cleanupTransformedInfo(glyfInfo);
            return LF_OUT_OF_MEMORY;
        }
    }

    // create the streams.
    // for now, they are mostly created with a given size (which is a lot more than enough space for most of them), which uses more memory than really needed.
    // An alternative is to grow the streams as needed, but that means a lot of reallocs.
    // Could switch some over to grow as neeed, or pass the maxp table into this function to determine more accurate values
    STREAM_createMemStream(glyfInfo->streams[eContours], numGlyphs*2);
    STREAM_createMemStream(glyfInfo->streams[eNPoints], glyfTableLen);
    STREAM_createMemStream(glyfInfo->streams[eFlags], glyfTableLen);
    STREAM_createMemStream(glyfInfo->streams[eGlyph], glyfTableLen);
    STREAM_createMemStream(glyfInfo->streams[eComposite], glyfTableLen);
    STREAM_createMemStream(glyfInfo->streams[eBBox], 0);                        // this will grow on demand
    STREAM_createMemStream(glyfInfo->streams[eInstructions], 0);                // this will grow on demand

    numBBoxBytes = 4 * ((numGlyphs + 31) / 32);
    glyfInfo->header.bboxBitmap = (BYTE*)calloc(1, numBBoxBytes);

    if(glyfInfo->header.bboxBitmap == NULL)
    {
        WOFF2_cleanupTransformedInfo(glyfInfo);
        return LF_OUT_OF_MEMORY;
    }

    return LF_ERROR_OK;
}

static void WOFF2_cleanupStreams(const transformedGlyfInfo *glyfInfo)
{
    free(glyfInfo->streams[eContours]->Base);
    free(glyfInfo->streams[eNPoints]->Base);
    free(glyfInfo->streams[eFlags]->Base);
    free(glyfInfo->streams[eGlyph]->Base);
    free(glyfInfo->streams[eComposite]->Base);
    free(glyfInfo->streams[eBBox]->Base);
    free(glyfInfo->streams[eInstructions]->Base);
}

static LF_ERROR WOFF2_encodeBB(const transformedGlyfInfo* txInfo, const glyf* g, USHORT index)
{
    LF_ERROR error = STREAM_growStream(txInfo->streams[eBBox], 8);
    if(error != LF_ERROR_OK)
        return error;

    txInfo->header.bboxBitmap[index >> 3] |= 0x80 >> (index & 7);

    STREAM_writeUShort(txInfo->streams[eBBox], g->xMin);
    STREAM_writeUShort(txInfo->streams[eBBox], g->yMin);
    STREAM_writeUShort(txInfo->streams[eBBox], g->xMax);
    STREAM_writeUShort(txInfo->streams[eBBox], g->yMax);

    return LF_ERROR_OK;
}

static LF_ERROR WOFF2_transformGlyfTable(USHORT numGlyphs, BYTE* glyfTable, ULONG* glyfTableLen,
                                         const BYTE* locaTable, USHORT* locaFormat,
                                         BYTE** transformed, ULONG *transformedLen)
{
    USHORT i, needToAdjustSize = 0;
    LF_ERROR error;
    LF_STREAM glyfStream;
    transformedGlyfInfo glyfInfo;
    int64_t totalGlyphsSize = 0;

    if(locaTable == NULL)
        return LF_INVALID_PARAM;

    error = WOFF2_initTransGlyfInfoWrite(numGlyphs, *glyfTableLen, &glyfInfo);
    if(error != LF_ERROR_OK)
        return error;

    STREAM_initMemStream(&glyfStream, glyfTable, *glyfTableLen);

    // loop over glyphs
    for(i = 0; i < numGlyphs; ++i)
    {
        ULONG glyfOffset;
        ULONG glyfSize;

        //lint -e{826}
        if(*locaFormat == 1)
        {
            glyfOffset = SWAP_ULONG(((ULONG*)locaTable)[i]);
            glyfSize   = SWAP_ULONG(((ULONG*)locaTable)[i+1]) - glyfOffset;
        }
        else
        {
            glyfOffset = SWAP_USHORT(((USHORT*)locaTable)[i]);
            glyfSize   = SWAP_USHORT(((USHORT*)locaTable)[i+1]) - glyfOffset;
            glyfSize   *= 2;

            totalGlyphsSize += glyfSize;
            if (totalGlyphsSize >= 131072)
                return LF_BAD_FORMAT;
        }

        if(glyfSize % 4 != 0)
            needToAdjustSize++;

        if(glyfSize == 0)
        {
            STREAM_writeUShort(glyfInfo.streams[eContours], 0);
        }
        else
        {
            glyf curGlyf;
            LF_STREAM glyfBlockStream;

            memset(&curGlyf, 0, sizeof(glyf));

            curGlyf.numberOfContours = STREAM_readUShort(&glyfStream);
            curGlyf.xMin = STREAM_readShort(&glyfStream);
            curGlyf.yMin = STREAM_readShort(&glyfStream);
            curGlyf.xMax = STREAM_readShort(&glyfStream);
            curGlyf.yMax = STREAM_readShort(&glyfStream);

            ASSERT(glyfSize > GLYF_HEADER_SIZE);

            curGlyf.glyfSize = glyfSize - GLYF_HEADER_SIZE;
            curGlyf.glyfBlock = STREAM_readChunk(&glyfStream, curGlyf.glyfSize);

            STREAM_initMemStream(&glyfBlockStream, curGlyf.glyfBlock, curGlyf.glyfSize);

            STREAM_writeShort(glyfInfo.streams[eContours], curGlyf.numberOfContours);

            if(curGlyf.numberOfContours == -1)
            {
                USHORT flags;
                boolean glyphHasInstructions = FALSE;

                // composite

                error = WOFF2_encodeBB(&glyfInfo, &curGlyf, i);
                if(error != LF_ERROR_OK)
                {
                    free(curGlyf.glyfBlock);
                    WOFF2_cleanupStreams(&glyfInfo);
                    return error;
                }

                do
                {
                    flags = STREAM_readUShort(&glyfBlockStream);

                    if((flags & WE_HAVE_INSTRUCTIONS) != 0)
                        glyphHasInstructions = TRUE;

                    STREAM_writeUShort(glyfInfo.streams[eComposite], flags);
                    STREAM_writeUShort(glyfInfo.streams[eComposite], STREAM_readUShort(&glyfBlockStream));           // glyph index

                    if(flags & ARG_1_AND_2_ARE_WORDS)
                    {
                        STREAM_writeShort(glyfInfo.streams[eComposite], STREAM_readUShort(&glyfBlockStream));        // argument1
                        STREAM_writeShort(glyfInfo.streams[eComposite], STREAM_readUShort(&glyfBlockStream));        // argument2
                    }
                    else
                    {
                        STREAM_writeByte(glyfInfo.streams[eComposite], (STREAM_readByte(&glyfBlockStream)) & 0xFF);  // argument1
                        STREAM_writeByte(glyfInfo.streams[eComposite], (STREAM_readByte(&glyfBlockStream)) & 0xFF);  // argument2
                    }

                    if(flags & WE_HAVE_A_SCALE)
                    {
                        STREAM_writeShort(glyfInfo.streams[eComposite], STREAM_readShort(&glyfBlockStream));         // xscale
                    }
                    else if(flags & WE_HAVE_AN_X_AND_Y_SCALE)
                    {
                        STREAM_writeShort(glyfInfo.streams[eComposite], STREAM_readShort(&glyfBlockStream));         // xscale
                        STREAM_writeShort(glyfInfo.streams[eComposite], STREAM_readUShort(&glyfBlockStream));        // yscale
                    }
                    else if(flags & WE_HAVE_A_TWO_BY_TWO)
                    {
                        STREAM_writeShort(glyfInfo.streams[eComposite], STREAM_readUShort(&glyfBlockStream));        // xscale
                        STREAM_writeShort(glyfInfo.streams[eComposite], STREAM_readUShort(&glyfBlockStream));        // scale01
                        STREAM_writeShort(glyfInfo.streams[eComposite], STREAM_readUShort(&glyfBlockStream));        // scale10
                        STREAM_writeShort(glyfInfo.streams[eComposite], STREAM_readUShort(&glyfBlockStream));        // yscale
                    }
                } while(flags & MORE_COMPONENTS);


                if(glyphHasInstructions == TRUE)
                {
                    USHORT j, instructionLen = STREAM_readShort(&glyfBlockStream);

                    STREAM_write255UShort(glyfInfo.streams[eGlyph], instructionLen);

                    error = STREAM_growStream(glyfInfo.streams[eInstructions], instructionLen);
                    if(error != LF_ERROR_OK)
                    {
                        free(curGlyf.glyfBlock);
                        WOFF2_cleanupStreams(&glyfInfo);
                        return error;
                    }

                    for(j = 0; j < instructionLen; ++j)
                    {
                        STREAM_writeByte(glyfInfo.streams[eInstructions], STREAM_readByte(&glyfBlockStream));

                        //maybe do
                        //STREAM_writeChunk(glyfInfo.streams[eInstructions], glyfBlockStream.Current, instructionLen);
                    }
                }
            }
            else if(curGlyf.numberOfContours > 0)
            {
                USHORT j, numPoints = 0;
                USHORT endPt = 0, instructionLen, numInContour;
                glyf_bbox simpleBB;

                // simple glyph

                memset(&simpleBB, 0, sizeof(glyf_bbox));

                for(j = 0; j < curGlyf.numberOfContours; j++)
                {
                    endPt = STREAM_readShort(&glyfBlockStream);
                    numInContour = endPt - numPoints + 1;
                    STREAM_write255UShort(glyfInfo.streams[eNPoints], numInContour);
                    numPoints += numInContour;
                }

                if (!STREAM_isValid(glyfBlockStream))
                {
                    free(curGlyf.glyfBlock);
                    WOFF2_cleanupStreams(&glyfInfo);
                    return LF_BAD_FORMAT;
                }

                numPoints = endPt + 1;

                instructionLen = STREAM_readUShort(&glyfBlockStream);

                if(instructionLen > 0)
                {
                    error = STREAM_growStream(glyfInfo.streams[eInstructions], instructionLen);
                    if(error != LF_ERROR_OK)
                    {
                        free(curGlyf.glyfBlock);
                        WOFF2_cleanupStreams(&glyfInfo);
                        return error;
                    }

                    for(j = 0; j < instructionLen; ++j)
                    {
                        STREAM_writeByte(glyfInfo.streams[eInstructions], STREAM_readByte(&glyfBlockStream));
                    }
                    // or
                    //STREAM_writeChunk(glyfInfo.streams[eInstructions], glyfBlockStream.Current, instructionLen);
                }

                {
                // create a couple of temp streams so that the flags, xcoords and ycoords can be read in parallel,
                // instead of allocating temp buffers for them
                BYTE flags = 0, flagRepeatCount = 0;
                SHORT dx = 0, dy = 0;
                SHORT lastX = 0, curX, lastY = 0, curY;
                ULONG startOfFlags, startOfXCoords, startOfYCoords;
                ULONG xCoordsBytesNeeded = 0;
                ULONG flagsBytesNeeded;
                LF_STREAM xCoordsStream, yCoordsStream;

                startOfFlags = (ULONG)STREAM_streamPos(&glyfBlockStream);

                // do a first pass to figure out the start of the xcoords
                for(j = 0; j < numPoints; ++j)
                {
                    if(flagRepeatCount == 0)
                    {
                        flags = STREAM_readByte(&glyfBlockStream);

                        if(flags & FLAG_REPEAT)
                            flagRepeatCount = STREAM_readByte(&glyfBlockStream);
                    }
                    else
                        flagRepeatCount--;
                }

                startOfXCoords = (ULONG)STREAM_streamPos(&glyfBlockStream);
                flagsBytesNeeded = startOfXCoords - startOfFlags;
                STREAM_initMemStream(&xCoordsStream, glyfBlockStream.Base + startOfXCoords, 2*numPoints/*maximum possible size*/);

                // reset
                STREAM_streamSeek(&glyfBlockStream, startOfFlags);
                flagRepeatCount = 0;

                // do a second pass, to figure out how many bytes the x coords take
                for(j = 0; j < numPoints; ++j)
                {
                    if(flagRepeatCount == 0)
                    {
                        flags = STREAM_readByte(&glyfBlockStream);

                        if(flags & FLAG_REPEAT)
                            flagRepeatCount = STREAM_readByte(&glyfBlockStream);
                    }
                    else
                        flagRepeatCount--;

                    if(flags & FLAG_X_SHORT_VECTOR)
                        xCoordsBytesNeeded++;  // consume one byte
                    else
                    {
                        if(flags & FLAG_X_SAME)
                        {
                           ;
                        }
                        else
                            xCoordsBytesNeeded += 2;   //two bytes
                    }
                }

                // reset
                flagRepeatCount = 0;
                STREAM_streamSeek(&glyfBlockStream, startOfFlags);
                startOfYCoords = startOfFlags + flagsBytesNeeded + xCoordsBytesNeeded;
                STREAM_initMemStream(&yCoordsStream, glyfBlockStream.Base + startOfYCoords, curGlyf.glyfSize-startOfYCoords);

                for(j = 0; j < numPoints; ++j)
                {
                    boolean onCurve;

                    if(flagRepeatCount == 0)
                    {
                        flags = STREAM_readByte(&glyfBlockStream);

                        if(flags & FLAG_REPEAT)
                            flagRepeatCount = STREAM_readByte(&glyfBlockStream);
                    }
                    else
                        flagRepeatCount--;

                    onCurve = ((flags & 0x01) != 0) ? TRUE : FALSE;

                    if(flags & FLAG_X_SHORT_VECTOR)
                    {
                        // one byte
                        dx = (STREAM_readByte(&xCoordsStream) & 0xFF);

                        if(!(flags & FLAG_X_SAME))
                            dx = -dx;
                    }
                    else
                    {
                        if(flags & FLAG_X_SAME)
                            dx = 0;
                        else
                            dx = STREAM_readShort(&xCoordsStream); // two bytes
                    }

                    if(flags & FLAG_Y_SHORT_VECTOR)
                    {
                        // one byte
                        dy = (STREAM_readByte(&yCoordsStream) & 0xFF);

                        if(!(flags & FLAG_Y_SAME))
                            dy = -dy;
                    }
                    else
                    {
                        if(flags & FLAG_Y_SAME)
                            dy = 0;
                        else
                            dy = STREAM_readShort(&yCoordsStream);  // two bytes
                    }

                    if(j == 0)
                    {
                        simpleBB.xMax = simpleBB.xMin = dx;
                        simpleBB.yMax = simpleBB.yMin = dy;
                        lastX = dx;
                        lastY = dy;
                    }
                    else
                    {
                        curX = lastX + dx;
                        curY = lastY + dy;

                        if(curX < simpleBB.xMin)
                            simpleBB.xMin = curX;
                        if(curX > simpleBB.xMax)
                            simpleBB.xMax = curX;
                        if(curY < simpleBB.yMin)
                            simpleBB.yMin = curY;
                        if(curY > simpleBB.yMax)
                            simpleBB.yMax = curY;

                        lastX = curX;
                        lastY = curY;
                    }

                    WOFF2_WriteTriplet(onCurve, dx, dy, glyfInfo.streams[eFlags], glyfInfo.streams[eGlyph]);
                }

                if (!STREAM_isValid(xCoordsStream) || !STREAM_isValid(yCoordsStream))
                {
                    free(curGlyf.glyfBlock);
                    WOFF2_cleanupStreams(&glyfInfo);
                    return LF_BAD_FORMAT;
                }

                STREAM_write255UShort(glyfInfo.streams[eGlyph], instructionLen);

                // check the bbox
                if((simpleBB.xMin != curGlyf.xMin) || (simpleBB.xMax != curGlyf.xMax) ||
                   (simpleBB.yMin != curGlyf.yMin) || (simpleBB.yMax != curGlyf.yMax))
                {
                    error = WOFF2_encodeBB(&glyfInfo, &curGlyf, i);
                    if(error != LF_ERROR_OK)
                    {
                        free(curGlyf.glyfBlock);
                        WOFF2_cleanupStreams(&glyfInfo);
                        return error;
                    }
                }
                }
            }
            free(curGlyf.glyfBlock);
        }
    }

    if (needToAdjustSize != 0)
    {
        // it was found that the size of at least one glyph was not 4-byte aligned.
        // the code that decodes woff2 assumes a glyf table with 4-byte aligned glyphs
        // so we need to update the required 'nominal' size of the glyph table so that
        // decoding won't fail
        *glyfTableLen = *glyfTableLen + needToAdjustSize * 2;

        // Check if new glyf table size requires 4 byte offsets
        if ((*locaFormat == 0) && (*glyfTableLen > (0xFFFF << 1)))
        {
            *locaFormat = 1;
        }
    }

    //write the transformed header
    {
    ULONG nContourLen = (ULONG)STREAM_streamPos(glyfInfo.streams[eContours]);
    ULONG nPointsLen = (ULONG)STREAM_streamPos(glyfInfo.streams[eNPoints]);
    ULONG flagsLen = (ULONG)STREAM_streamPos(glyfInfo.streams[eFlags]);
    ULONG glyphsLen = (ULONG)STREAM_streamPos(glyfInfo.streams[eGlyph]);
    ULONG compositesLen = (ULONG)STREAM_streamPos(glyfInfo.streams[eComposite]);
    ULONG bboxLen = (ULONG)STREAM_streamPos(glyfInfo.streams[eBBox]);
    ULONG instructionLen = (ULONG)STREAM_streamPos(glyfInfo.streams[eInstructions]);
    ULONG bbStreamLen =  4 * ((numGlyphs + 31) / 32) + bboxLen;

    LF_STREAM txGlyfStream;

    *transformedLen = 36 /*header */ + nContourLen + nPointsLen + flagsLen + glyphsLen + compositesLen + bbStreamLen + instructionLen;

    // allocate buffer for the resulting transformed table
    *transformed = (BYTE*)calloc(1, *transformedLen);
    if(*transformed == NULL)
    {
        WOFF2_cleanupStreams(&glyfInfo);
        WOFF2_cleanupTransformedInfo(&glyfInfo);
        return LF_OUT_OF_MEMORY;
    }

    STREAM_initMemStream(&txGlyfStream, *transformed, *transformedLen);

    STREAM_writeULong(&txGlyfStream, 0);
    STREAM_writeUShort(&txGlyfStream, numGlyphs);
    STREAM_writeUShort(&txGlyfStream, *locaFormat);
    STREAM_writeULong(&txGlyfStream, nContourLen);
    STREAM_writeULong(&txGlyfStream, nPointsLen);
    STREAM_writeULong(&txGlyfStream, flagsLen);
    STREAM_writeULong(&txGlyfStream, glyphsLen);
    STREAM_writeULong(&txGlyfStream, compositesLen);
    // per the reference implementation
    STREAM_writeULong(&txGlyfStream, bbStreamLen);
    STREAM_writeULong(&txGlyfStream, instructionLen);
    // per the spec
    //STREAM_writeChunk(&txGlyfStream, bboxBytes, numBBoxBytes);

    // copy the data over
    STREAM_writeChunk(&txGlyfStream, glyfInfo.streams[eContours]->Base, nContourLen);
    STREAM_writeChunk(&txGlyfStream, glyfInfo.streams[eNPoints]->Base, nPointsLen);
    STREAM_writeChunk(&txGlyfStream, glyfInfo.streams[eFlags]->Base, flagsLen);
    STREAM_writeChunk(&txGlyfStream, glyfInfo.streams[eGlyph]->Base, glyphsLen);
    STREAM_writeChunk(&txGlyfStream, glyfInfo.streams[eComposite]->Base, compositesLen);
    // per the reference implementation
    STREAM_writeChunk(&txGlyfStream, glyfInfo.header.bboxBitmap, 4 * ((numGlyphs + 31) / 32));
    STREAM_writeChunk(&txGlyfStream, glyfInfo.streams[eBBox]->Base, bboxLen);
    STREAM_writeChunk(&txGlyfStream, glyfInfo.streams[eInstructions]->Base, instructionLen);

    ASSERT(STREAM_streamPos(&txGlyfStream) == *transformedLen);
    }

    WOFF2_cleanupStreams(&glyfInfo);
    WOFF2_cleanupTransformedInfo(&glyfInfo);

    return LF_ERROR_OK;
}

static LF_ERROR WOFF2_writeData(LF_FONT* lfFont, const LF_WRITE_PARAMS *writeParams, LF_STREAM* stream, woff2_offset_table* woffTable)
{
    BYTE zero[3] = {0};
    ULONG paddingAtEnd;
    ULONG paddingBeforePrivData = 0;
    ULONG realLen = (ULONG)STREAM_streamPos(stream);

    ULONG paddedLen = (ULONG)((realLen + 3) & ~3);

    if (paddedLen != realLen)
    {
        for (ULONG i = 0; i < (paddedLen - realLen); i++)
            STREAM_writeByte(stream, 0x0);
    }

    if(lfFont->woffInfo.metaData != NULL)
    {
        if (lfFont->woffInfo.metatDataCompression == eWOFF && lfFont->woffInfo.metaDataOrigLen > 0)
        {
            LF_ERROR ret = LF_OUT_OF_MEMORY;
            ULONG origDataBufSize, uncompressedSize;
            BYTE* origDataBuf;

            // change it to be Brotli compressed
            origDataBufSize = lfFont->woffInfo.metaDataOrigLen + (lfFont->woffInfo.metaDataOrigLen >> 2);   // allocate 1.25x original to be safe

            origDataBuf = (BYTE*)malloc(origDataBufSize);
            if (origDataBuf != NULL)
            {
                // decompress into origDataBuf buffer
                uncompressedSize = origDataBufSize;
                if ((TRUE == WOFF_decompress(lfFont->woffInfo.metaData, lfFont->woffInfo.metaDataLen, origDataBuf, &uncompressedSize)) &&
                    (uncompressedSize == lfFont->woffInfo.metaDataOrigLen))
                {
                    // get rid of original (zlib) compressed buffer
                    free(lfFont->woffInfo.metaData);

                    // allocate 1.5x original to be safe
                    ULONG compBufSize = lfFont->woffInfo.metaDataOrigLen + (lfFont->woffInfo.metaDataOrigLen >> 1);

                    lfFont->woffInfo.metaData = (BYTE*)malloc(compBufSize);
                    if(lfFont->woffInfo.metaData != NULL)
                    {
                        int brotliRes;
                        BrotliParams params;
                        size_t encodedSize = compBufSize;

                        BrotliDefaultParams(&params);

                        params.mode = MODE_TEXT;
                        params.quality = writeParams->woff2CompressionLevel;

                        brotliRes = BrotliCompressBuffer(params, lfFont->woffInfo.metaDataOrigLen, origDataBuf, &encodedSize, lfFont->woffInfo.metaData);
                        if(brotliRes == 1)
                        {
                            lfFont->woffInfo.metaDataLen = (ULONG)encodedSize;
                            lfFont->woffInfo.metatDataCompression = eWOFF2;
                            ret = LF_ERROR_OK;
                        }
                        else
                        {
                            ret = LF_COMPRESSION;
                        }
                    }
                }
                free(origDataBuf);
            }
            if(ret != LF_ERROR_OK)
                return ret;
        }
        else if(lfFont->woffInfo.metatDataCompression ==  eUNCOMPRESSED)
        {
            int brotliRes;
            size_t encodedSize;
            BYTE* compressedBuf, *origBuf;
            BrotliParams params;

            // compress with Brotli
            BrotliDefaultParams(&params);

            params.mode = MODE_TEXT;
            params.quality = writeParams->woff2CompressionLevel;

            encodedSize = lfFont->woffInfo.metaDataOrigLen + (lfFont->woffInfo.metaDataOrigLen >> 3);

            compressedBuf = (BYTE*)malloc(encodedSize);
            if(compressedBuf == NULL)
                return LF_OUT_OF_MEMORY;

            origBuf = lfFont->woffInfo.metaData;

            brotliRes = BrotliCompressBuffer(params, lfFont->woffInfo.metaDataOrigLen, origBuf, &encodedSize, compressedBuf);

            if(brotliRes == 1)
            {
                free(origBuf);
                lfFont->woffInfo.metaData = compressedBuf;
                lfFont->woffInfo.metaDataLen = (ULONG)encodedSize;
                lfFont->woffInfo.metatDataCompression = eWOFF2;
            }
            else
            {
                free(compressedBuf);
                return LF_OUT_OF_MEMORY;
            }
        }
        else if(lfFont->woffInfo.metatDataCompression ==  eUNSET)
            return LF_BAD_FORMAT; // unexpected
    }

    if(lfFont->woffInfo.metaData != NULL)
    {
        woffTable->woffHeader.metaOffset = paddedLen;
        woffTable->woffHeader.metaLength = lfFont->woffInfo.metaDataLen;
        woffTable->woffHeader.metaOrigLength = lfFont->woffInfo.metaDataOrigLen;
        paddedLen += woffTable->woffHeader.metaLength;
    }
    if(lfFont->woffInfo.privateData != NULL)
    {
        woffTable->woffHeader.length = (paddedLen + 3) & ~3;
        paddingBeforePrivData = woffTable->woffHeader.length - paddedLen;
        woffTable->woffHeader.privOffset = woffTable->woffHeader.length;
        woffTable->woffHeader.privLength = lfFont->woffInfo.privateDataLen;
        paddedLen = woffTable->woffHeader.privOffset + woffTable->woffHeader.privLength;
    }

    woffTable->woffHeader.length = (paddedLen + 3) & ~3;
    paddingAtEnd = woffTable->woffHeader.length - paddedLen;

    // write meta data and private data
    if(lfFont->woffInfo.metaData != NULL)
        STREAM_writeChunk(stream, lfFont->woffInfo.metaData, lfFont->woffInfo.metaDataLen);

    if(paddingBeforePrivData)
        STREAM_writeChunk(stream, zero, paddingBeforePrivData);

    if(lfFont->woffInfo.privateData != NULL)
        STREAM_writeChunk(stream, lfFont->woffInfo.privateData, lfFont->woffInfo.privateDataLen);

    if(paddingAtEnd)
        STREAM_writeChunk(stream, zero, paddingAtEnd);

    return LF_ERROR_OK;
}

static boolean WOFF2_checkTableOrdering(LF_FONT* lfFont)
{
    if (lfFont->fontType == eLF_CFF_FONT)
        return TRUE;

    SHORT glyfIndex = -1, headIndex = -1, locaIndex = -1;

    sfnt_offset_table* sfntTable = (sfnt_offset_table*)lfFont->builtSFNTOffsetTable;

    SHORT numTables = (SHORT)vector_size(&sfntTable->record_list);

    for (SHORT i = 0; i < numTables; ++i)
    {
        sfnt_table_record* sfntRecord = (sfnt_table_record*)vector_at(&sfntTable->record_list, i);
        if (sfntRecord)
        {
            if (sfntRecord->tag == TAG_GLYF)
                glyfIndex = i;
            else if (sfntRecord->tag == TAG_HEAD)
                headIndex = i;
            else if (sfntRecord->tag == TAG_LOCA)
                locaIndex = i;
        }
    }

    if ((locaIndex != 1) && (glyfIndex != -1))
    {
        if ((locaIndex < headIndex) || (headIndex < glyfIndex))
            return FALSE;
    }

    return TRUE;
}

LF_ERROR WOFF2_writeToStream(LF_FONT* lfFont, const LF_WRITE_PARAMS *params, LF_STREAM* stream)
{
    USHORT i, numTables;
    sfnt_offset_table* sfntTable;
    woff2_offset_table* woffTable;
    ULONG maxTableLen;
    ULONG tableDataBlockLen;

    UNUSED(params);

    if((lfFont == NULL) || (stream == NULL))
        return LF_INVALID_PARAM;

    if ((lfFont->builtSFNT == NULL) || (lfFont->builtSFNTOffsetTable == NULL))
        return LF_BAD_FORMAT;

    // The code below relies on the glyf, head, and loca tables being in alphabetical order.
    if (FALSE == WOFF2_checkTableOrdering(lfFont))
        return LF_UNSUPPORTED;

    // create a new woff offset table
    woffTable = (woff2_offset_table*)calloc(1, sizeof(woff2_offset_table));
    if(woffTable == NULL)
        return LF_OUT_OF_MEMORY;

    sfntTable = (sfnt_offset_table*)lfFont->builtSFNTOffsetTable;

    numTables = (USHORT)vector_size(&sfntTable->record_list);

    LF_ERROR error = vector_init(&woffTable->record_list, numTables, 1);
    if (error != LF_ERROR_OK)
    {
        free(woffTable);
        return error;
    }

    maxTableLen = 0;
    tableDataBlockLen = 0;

    // create the woff table records
    for(i = 0; i < numTables; ++i)
    {
        sfnt_table_record* sfntRecord;
        woff2_table_record* woffRecord;

        sfntRecord = (sfnt_table_record*)vector_at(&sfntTable->record_list, i);
        if(sfntRecord)
        {
            if ((lfFont->fontType == eLF_SFNT_FONT) && (sfntRecord->tag == TAG_CFF))
                continue;
            if ((lfFont->fontType == eLF_CFF_FONT) && TableExcludedFromCFFFont(sfntRecord->tag))
                continue;

            woffRecord = (woff2_table_record*)calloc(1, sizeof(woff2_table_record));
            if(woffRecord == NULL)
            {
                offset_woff2_freeTable(woffTable);
                return LF_OUT_OF_MEMORY;
            }

            woffRecord->tag = sfntRecord->tag;
            // rest of fields left at zero (flags are determined by func that writes the header)

            vector_push_back(&woffTable->record_list, woffRecord);

            tableDataBlockLen += sfntRecord->length;
            if(sfntRecord->length > maxTableLen)
                maxTableLen = sfntRecord->length;
        }
    }

    if (0 == tableDataBlockLen)                  // silence xcode analyzer
    {
        offset_woff2_freeTable(woffTable);
        return LF_OUT_OF_MEMORY;
    }

    // initialize some values in the woff table header (rest are left at zero for now by the above calloc)
    numTables = (USHORT)vector_size(&woffTable->record_list);

    woffTable->woffHeader.signature = 0x774F4632; // "wOF2"
    woffTable->woffHeader.flavor = sfntTable->sfntHeader.sfnt_version;
    woffTable->woffHeader.numTables = numTables;
    woffTable->woffHeader.totalSfntSize = 12 /*sfnt header*/ + (16 * numTables) /*directory*/;
    woffTable->woffHeader.majorVersion = lfFont->woffInfo.majorVersion;
    woffTable->woffHeader.minorVersion = lfFont->woffInfo.minorVersion;

    // get the data for the tables into a concatenated block, then compress it
    {
    USHORT locaFormat = 0, origLocaFormat = 0;
    ULONG concatenatedTablesLen;
    ULONG locaLength = 0;
    BYTE* tableDataBlock;
    BYTE* curTablePtr;
    BYTE* destPtr;

    // allocate a block to hold the concatenated table data
    // the tableDataBlockLen is a rough estimate of space needed, actual should be less since glyf table will be
    // transformed and the loca is not written at all.
    tableDataBlock = (BYTE*)malloc(tableDataBlockLen);
    if(tableDataBlock == NULL)
    {
        offset_woff2_freeTable(woffTable);
        return LF_OUT_OF_MEMORY;
    }

    concatenatedTablesLen = 0;
    destPtr = tableDataBlock;

    for(i = 0; i < numTables; ++i)
    {
        sfnt_table_record* sfntRecord;
        woff2_table_record* woffRecord;

        woffRecord = (woff2_table_record*)vector_at(&woffTable->record_list, i);
        if(woffRecord == NULL)
        {
            offset_woff2_freeTable(woffTable);
            free(tableDataBlock);
            return LF_BAD_FORMAT;
        }

        // find the corresponding entry in the original sfnt table
        sfntRecord = offset_findRecordEx(sfntTable, woffRecord->tag);
        if(sfntRecord == NULL)
        {
            offset_woff2_freeTable(woffTable);
            free(tableDataBlock);
            return LF_BAD_FORMAT;
        }

        curTablePtr = (BYTE*)lfFont->builtSFNT + sfntRecord->offset;

        if(sfntRecord->tag == TAG_GLYF)
        {
            USHORT numGlyphs;
            BYTE *origLocaPtr, *transformed = NULL;
            ULONG transformedLen = 0, nominalSize;
            sfnt_table_record* locaRecord;

            // we need the number of glyphs, the loca table and the loca format

            locaRecord = offset_findRecordEx(sfntTable, TAG_LOCA);
            if(locaRecord == NULL)
            {
                offset_woff2_freeTable(woffTable);
                free(tableDataBlock);
                return LF_BAD_FORMAT;
            }

            origLocaPtr = (BYTE*)lfFont->builtSFNT + locaRecord->offset;
            locaLength = locaRecord->length;

            BYTE* tablePtr;

            sfnt_table_record* record = offset_findRecordEx(sfntTable, TAG_MAXP);
            if (record == NULL)
            {
                offset_woff2_freeTable(woffTable);
                free(tableDataBlock);
                return LF_BAD_FORMAT;
            }

            tablePtr = (BYTE*)lfFont->builtSFNT + record->offset;

            numGlyphs = SWAP_USHORT(((maxp_table *)(void*)tablePtr)->numGlyphs);

            record = offset_findRecordEx(sfntTable, TAG_HEAD);
            if (record == NULL)
            {
                offset_woff2_freeTable(woffTable);
                free(tableDataBlock);
                return LF_BAD_FORMAT;
            }

            tablePtr = (BYTE*)lfFont->builtSFNT + record->offset;

            locaFormat = SWAP_SHORT((*(SHORT*)(void*)(tablePtr + 50))); // the indexToLocFormat is at bytes 51 and 52 past the start of the table
            origLocaFormat = locaFormat;

            nominalSize = sfntRecord->length;

            // transform the glyf table
            error = WOFF2_transformGlyfTable(numGlyphs, curTablePtr, &nominalSize,
                                             origLocaPtr, &locaFormat, &transformed, &transformedLen);

            if(error != LF_ERROR_OK)
            {
                free(tableDataBlock);
                offset_woff2_freeTable(woffTable);
                return error;
            }

            // copy buffer to table data block
            if(destPtr + transformedLen > tableDataBlock+tableDataBlockLen)
            {
                size_t along = (destPtr - tableDataBlock);
                BYTE* temp = (BYTE*)realloc(tableDataBlock, tableDataBlockLen+transformedLen);
                if(temp == NULL)
                {
                    free(tableDataBlock);
                    offset_woff2_freeTable(woffTable);
                    return LF_OUT_OF_MEMORY;
                }
                tableDataBlock = temp;
                destPtr = tableDataBlock + along;
                tableDataBlockLen += transformedLen;
            }

            memcpy(destPtr, transformed, transformedLen);
            destPtr += transformedLen;

            free(transformed);
            concatenatedTablesLen += transformedLen;
            woffRecord->origLength = nominalSize;
            woffRecord->transformLength = transformedLen;
            woffTable->woffHeader.totalSfntSize += ((nominalSize + 3) & ~3);

            // The spec says that the loca record should be right after the glyf record
            // that would be written here, but the reference code does not do that, so
            // for now it is not done here either.
        }
        else if(sfntRecord->tag == TAG_LOCA)
        {
            woffRecord->transformLength = 0;

            if (origLocaFormat != locaFormat)
            {
                woffRecord->origLength = sfntRecord->length * 2;
                woffTable->woffHeader.totalSfntSize += ((sfntRecord->length*2 + 3) & ~3);
            }
            else
            {
                woffRecord->origLength = sfntRecord->length;
                woffTable->woffHeader.totalSfntSize += ((locaLength + 3) & ~3);
            }
        }
        else
        {
            // copy the raw table data to the table data block
            if(destPtr + sfntRecord->length > tableDataBlock+tableDataBlockLen)
            {
                size_t along = (destPtr - tableDataBlock);
                BYTE* tmp = (BYTE*)realloc(tableDataBlock, tableDataBlockLen + sfntRecord->length);
                if (tmp == NULL)
                {
                    free(tableDataBlock);               //lint !e449
                                                        // Note: Lint reported "Pointer variable 'tableDataBlock' previously deallocated" here.
                                                        // At least on Windows tableDataBlock is not freed within realloc when there is
                                                        // not enough space. Tested this in debugger by reallocating -1. This code was changed to
                                                        // the way it is to address a 'realloc leak' message produced by the Visual Studio analyzer.
                                                        // See also http://stackoverflow.com/questions/1607004/does-realloc-free-the-former-buffer-if-it-fails
                    offset_woff2_freeTable(woffTable);
                    return LF_OUT_OF_MEMORY;
                }
                tableDataBlock = tmp;

                destPtr = tableDataBlock + along;
                tableDataBlockLen += sfntRecord->length;
            }

            memcpy(destPtr, curTablePtr, sfntRecord->length);

            if ((sfntRecord->tag == TAG_HEAD) && (origLocaFormat != locaFormat))
                destPtr[51] = 1;                          // Set the indexToLocFormat to 1

            destPtr += sfntRecord->length;

            concatenatedTablesLen += sfntRecord->length; // not padded

            woffRecord->origLength = sfntRecord->length;

            woffTable->woffHeader.totalSfntSize += ((sfntRecord->length + 3) & ~3);
        }
    }

    // compress the local buffer using Brotli
    {
    int brotliRes;
    BYTE* compressedBuf;
    size_t encodedSize;
    BrotliParams brotliParams;

    BrotliDefaultParams(&brotliParams);

    brotliParams.mode = MODE_FONT;
    brotliParams.quality = params->woff2CompressionLevel;

    // allocate output buffer. The reference code allocates extra space for compressor
    // per the below formula, in case the compressor increases the size required
    compressedBuf = (BYTE*)malloc((ULONG)(1.2 * concatenatedTablesLen + 10240));
    if(compressedBuf == NULL)
    {
        free(tableDataBlock);
        offset_woff2_freeTable(woffTable);
        return LF_OUT_OF_MEMORY;
    }
    encodedSize = concatenatedTablesLen;

    brotliRes = BrotliCompressBuffer(brotliParams, concatenatedTablesLen, tableDataBlock, &encodedSize, compressedBuf);
    if(brotliRes == 0)
    {
        free(compressedBuf);
        free(tableDataBlock);
        offset_woff2_freeTable(woffTable);
        return LF_COMPRESSION;
    }

    woffTable->woffHeader.totalCompressedSize = (ULONG)encodedSize;

    // write header - 1st time to get the size of the header + Table Directory
    STREAM_streamSeek(stream, 0);
    offset_woff2_writeTable(woffTable, stream);

    if(FALSE == STREAM_ptrIsValid(stream))
    {
        free(compressedBuf);
        free(tableDataBlock);
        offset_woff2_freeTable(woffTable);
        return LF_STREAM_OVERRUN;
    }

    // write Brotli data to stream
    STREAM_writeChunk(stream, compressedBuf, encodedSize);

    if(FALSE == STREAM_ptrIsValid(stream))
    {
        free(compressedBuf);
        free(tableDataBlock);
        offset_woff2_freeTable(woffTable);
        return LF_STREAM_OVERRUN;
    }

    // write data (and padding at end)
    error = WOFF2_writeData(lfFont, params, stream, woffTable);
    if ((error != LF_ERROR_OK) || (FALSE == STREAM_ptrIsValid(stream)))
    {
        free(compressedBuf);
        free(tableDataBlock);
        offset_woff2_freeTable(woffTable);
        return error;
    }

    // rewrite updated header
    STREAM_streamSeek(stream, 0);
    offset_woff2_writeTable(woffTable, stream);

    free(compressedBuf);
    }

    free(tableDataBlock);
    }

    STREAM_streamSeek(stream, woffTable->woffHeader.length);

    offset_woff2_freeTable(woffTable);

    if (FALSE == STREAM_ptrIsValid(stream))
        return LF_STREAM_OVERRUN;
    return LF_ERROR_OK;
}

LF_ERROR WOFF2_getMaxSize(LF_FONT* lfFont, const LF_WRITE_PARAMS *params, size_t* size)
{
    USHORT numTables;
    LF_ERROR error;

    error = SFNT_getSFNTSize(lfFont, params, size);
    if(error != LF_ERROR_OK)
        return error;

    numTables = offset_getNumTables(lfFont);

    // *size now has the uncompressed size of all the tables, when they are combined into
    // a block and compressed it will be less

    *size += 48; // header
    *size += numTables * (1 + 4 + 4 + 4); // table directory(assume max for UIntBase128 is 4)

    if(lfFont->woffInfo.metaData != NULL)
        *size += lfFont->woffInfo.metaDataOrigLen;      // uncompressed size (actual will be less)
    if(lfFont->woffInfo.privateData != NULL)
        *size += lfFont->woffInfo.privateDataLen;

    return error;
}
