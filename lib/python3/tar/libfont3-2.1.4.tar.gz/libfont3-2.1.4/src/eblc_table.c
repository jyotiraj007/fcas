// Copyright (C) 2016 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
// eblc_table.c

#include "eblc_table.h"
#include "table_tags.h"
#include "maxp_table.h"
#include "utils.h"

static LF_ERROR EBLC_sortSubtable(LF_VECTOR* indexArray);

LF_ERROR EBLC_readTable(LF_FONT* lfFont, const sfnt_table_record* record, LF_STREAM* stream)
{
    if (record->length == 0)
        return LF_BAD_FORMAT;

    if (STREAM_streamSeek(stream, record->offset) != 0)
        return LF_INVALID_OFFSET;

    eblc_table* table = (eblc_table*)calloc(1, sizeof(eblc_table));
    if (table == NULL)
        return LF_OUT_OF_MEMORY;

    LF_ERROR error = EBLC_parseTable(table, record, stream);
    if (error != LF_ERROR_OK)
        return error;

    map_insert(&lfFont->table_map, (void*)(intptr_t)record->tag, table);

    return LF_ERROR_OK;
}

LF_ERROR EBLC_parseTable(embedded_loc_table* table, const sfnt_table_record* record, LF_STREAM* stream)
{
    table->version = STREAM_readFixed(stream);      // version

    if (!((table->version == 0x00020000) || (table->version == 0x00030000)))
    {
        DEBUG_LOG_ERROR("Incorrect EBLC table version.");
        free(table);
        return LF_UNSUPPORTED;
    }

    table->numSizes = STREAM_readULong(stream);     // number of strikes

    // read in the bitmapSizeTables

    LF_ERROR error = vector_init(&table->bitmapSizeTables, table->numSizes, 4);

    if (error != LF_ERROR_OK)
    {
        free(table);
        return error;
    }

    for (ULONG i = 0; i < table->numSizes; i++)
    {
        bitmap_size_table* bst = (bitmap_size_table*)calloc(1, sizeof(bitmap_size_table));

        if (bst == NULL)
        {
            EBLC_freeStrikes(table);
            vector_free(&table->bitmapSizeTables);
            free(table);
            return LF_OUT_OF_MEMORY;
        }

        bst->indexSubTableArrayOffset = STREAM_readULong(stream);
        bst->indexTablesSize = STREAM_readULong(stream);
        bst->numberOfIndexSubTables = STREAM_readULong(stream);
        bst->colorRef = STREAM_readULong(stream);
        bst->hori.ascender = STREAM_readByte(stream);
        bst->hori.descender = STREAM_readByte(stream);
        bst->hori.widthMax = STREAM_readByte(stream);
        bst->hori.caretSlopeNumerator = STREAM_readByte(stream);
        bst->hori.caretSlopeDenominator = STREAM_readByte(stream);
        bst->hori.caretOffset = STREAM_readByte(stream);
        bst->hori.minOriginSB = STREAM_readByte(stream);
        bst->hori.minAdvanceSB = STREAM_readByte(stream);
        bst->hori.maxBeforeBL = STREAM_readByte(stream);
        bst->hori.minAfterBL = STREAM_readByte(stream);
        bst->hori.pad1 = STREAM_readByte(stream);
        bst->hori.pad2 = STREAM_readByte(stream);
        bst->vert.ascender = STREAM_readByte(stream);
        bst->vert.descender = STREAM_readByte(stream);
        bst->vert.widthMax = STREAM_readByte(stream);
        bst->vert.caretSlopeNumerator = STREAM_readByte(stream);
        bst->vert.caretSlopeDenominator = STREAM_readByte(stream);
        bst->vert.caretOffset = STREAM_readByte(stream);
        bst->vert.minOriginSB = STREAM_readByte(stream);
        bst->vert.minAdvanceSB = STREAM_readByte(stream);
        bst->vert.maxBeforeBL = STREAM_readByte(stream);
        bst->vert.minAfterBL = STREAM_readByte(stream);
        bst->vert.pad1 = STREAM_readByte(stream);
        bst->vert.pad2 = STREAM_readByte(stream);
        bst->startGlyphIndex = STREAM_readUShort(stream);
        bst->endGlyphIndex = STREAM_readUShort(stream);
        bst->ppemX = STREAM_readByte(stream);
        bst->ppemY = STREAM_readByte(stream);
        bst->bitDepth = STREAM_readByte(stream);
        bst->flags = STREAM_readByte(stream);

        error = vector_push_back(&table->bitmapSizeTables, bst);
        if (error != LF_ERROR_OK)
        {
            EBLC_freeStrikes(table);
            vector_free(&table->bitmapSizeTables);
            free(table);
            return LF_OUT_OF_MEMORY;
        }
    }

    // Read in the indexSubTable arrays

    ULONG startOfTable = record->offset;

    for (ULONG i = 0; i < table->numSizes; i++)
    {
        bitmap_size_table* bst = (bitmap_size_table*)vector_at(&table->bitmapSizeTables, i);

        error = vector_init(&bst->indexSubTableArray, bst->numberOfIndexSubTables, 4);
        if (error != LF_ERROR_OK)
        {
            EBLC_freeStrikes(table);
            vector_free(&table->bitmapSizeTables);
            free(table);
            return error;
        }

        ULONG offsetToSubTableArray = startOfTable + bst->indexSubTableArrayOffset;

        STREAM_streamSeek(stream, offsetToSubTableArray);

        // first read in the array
        for (ULONG j = 0; j < bst->numberOfIndexSubTables; j++)
        {
            index_subtable* st = (index_subtable*)calloc(1, sizeof(index_subtable));
            if (st == NULL)
            {
                EBLC_freeStrikes(table);
                vector_free(&table->bitmapSizeTables);
                free(table);
                return LF_OUT_OF_MEMORY;
            }

            map_init(&st->glyphMap, integer_compare);

            st->firstGlyphIndex = STREAM_readUShort(stream);
            st->lastGlyphIndex = STREAM_readUShort(stream);
            st->additionalOffsetToIndexSubtable = STREAM_readULong(stream);

            error = vector_push_back(&bst->indexSubTableArray, st);
            if (error != LF_ERROR_OK)
            {
                EBLC_freeStrikes(table);
                vector_free(&table->bitmapSizeTables);
                free(table);
                return error;
            }
        }

        // then read in the subtables
        for (ULONG j = 0; j < bst->numberOfIndexSubTables; j++)
        {
            index_subtable* st = (index_subtable*)vector_at(&bst->indexSubTableArray, j);

            ULONG offsetToSubTable = offsetToSubTableArray + st->additionalOffsetToIndexSubtable;

            STREAM_streamSeek(stream, offsetToSubTable);

            st->header.indexFormat = STREAM_readUShort(stream);
            st->header.imageFormat = STREAM_readUShort(stream);
            st->header.imageDataOffset = STREAM_readULong(stream);

            st->header.bestWriteFormat = st->header.indexFormat;

            ULONG numGlyphs;

            if (1 == st->header.indexFormat)
            {
                numGlyphs = st->lastGlyphIndex - st->firstGlyphIndex + 1;

                ULONG numSlots = numGlyphs + 1;

                LF_VECTOR tempVect;

                error = vector_init(&tempVect, numSlots, 4);

                if (error == LF_ERROR_OK)
                {
                    for (ULONG k = 0; k < numSlots && (error == LF_ERROR_OK); k++)
                    {
                        ULONG offset = STREAM_readULong(stream);
                        error = vector_push_back(&tempVect, (void*)(intptr_t)offset);
                    }

                    if (error == LF_ERROR_OK)
                    {
                        GlyphID gid = st->firstGlyphIndex;

                        for (ULONG k = 0; k < numGlyphs && (error == LF_ERROR_OK); k++)
                        {
                            index_glyph_info* igi = (index_glyph_info*)malloc(sizeof(index_glyph_info));

                            if (igi != NULL)
                            {
                                ULONG curr = (ULONG)(intptr_t)vector_at(&tempVect, k);
                                ULONG next = (ULONG)(intptr_t)vector_at(&tempVect, k + 1);
                                ULONG len = next - curr;

                                igi->offset = curr;
                                igi->len = len;

                                map_insert(&st->glyphMap, (void*)(intptr_t)gid, igi);
                                gid++;
                            }
                            else
                                error = LF_OUT_OF_MEMORY;
                        }
                    }

                    vector_free(&tempVect);
                }
            }
            else if (2 == st->header.indexFormat)
            {
                st->subtable.fmt2.imageSize = STREAM_readULong(stream);
                st->subtable.fmt2.bigMetrics.height = STREAM_readByte(stream);
                st->subtable.fmt2.bigMetrics.width = STREAM_readByte(stream);
                st->subtable.fmt2.bigMetrics.horiBearingX = STREAM_readByte(stream);
                st->subtable.fmt2.bigMetrics.horiBearingY = STREAM_readByte(stream);
                st->subtable.fmt2.bigMetrics.horiAdvance = STREAM_readByte(stream);
                st->subtable.fmt2.bigMetrics.vertBearingX = STREAM_readByte(stream);
                st->subtable.fmt2.bigMetrics.vertBearingY = STREAM_readByte(stream);
                st->subtable.fmt2.bigMetrics.vertAdvance = STREAM_readByte(stream);

                numGlyphs = st->lastGlyphIndex - st->firstGlyphIndex + 1;
                for (ULONG k = 0; k < numGlyphs && (error == LF_ERROR_OK); k++)
                {
                    index_glyph_info* igi = (index_glyph_info*)malloc(sizeof(index_glyph_info));

                    if (igi != NULL)
                    {
                        igi->offset = k * st->subtable.fmt2.imageSize;
                        igi->len = st->subtable.fmt2.imageSize;

                        map_insert(&st->glyphMap, (void*)(intptr_t)(k + st->firstGlyphIndex), igi);
                    }
                    else
                        error = LF_OUT_OF_MEMORY;
                }
            }
            else if (3 == st->header.indexFormat)
            {
                numGlyphs = st->lastGlyphIndex - st->firstGlyphIndex + 1;
                ULONG numSlots = numGlyphs + 1;

                LF_VECTOR tempVect;

                error = vector_init(&tempVect, numSlots, 4);

                if (error == LF_ERROR_OK)
                {
                    for (ULONG k = 0; k < numSlots && (error == LF_ERROR_OK); k++)
                    {
                        USHORT offset = STREAM_readUShort(stream);
                        error = vector_push_back(&tempVect, (void*)(intptr_t)offset);
                    }

                    if (error == LF_ERROR_OK)
                    {
                        GlyphID gid = st->firstGlyphIndex;

                        for (ULONG k = 0; k < numGlyphs && (error == LF_ERROR_OK); k++)
                        {
                            index_glyph_info* igi = (index_glyph_info*)malloc(sizeof(index_glyph_info));

                            if (igi != NULL)
                            {
                                USHORT curr = (USHORT)(intptr_t)vector_at(&tempVect, k);
                                USHORT next = (USHORT)(intptr_t)vector_at(&tempVect, k + 1);
                                ULONG len = next - curr;

                                igi->offset = curr;
                                igi->len = len;

                                map_insert(&st->glyphMap, (void*)(intptr_t)gid, igi);
                                gid++;
                            }
                            else
                            {
                                error = LF_OUT_OF_MEMORY;
                            }
                        }
                    }

                    vector_free(&tempVect);
                }
            }
            else if (4 == st->header.indexFormat)
            {
                st->subtable.fmt4.numGlyphs = STREAM_readULong(stream);

                code_offset_pair cur, next;

                cur.glyphCode = STREAM_readUShort(stream);
                cur.offset = STREAM_readUShort(stream);

                for (ULONG k = 0; k < st->subtable.fmt4.numGlyphs && (error == LF_ERROR_OK); k++)
                {
                    next.glyphCode = STREAM_readUShort(stream);
                    next.offset = STREAM_readUShort(stream);

                    ULONG diff = next.offset - cur.offset;

                    index_glyph_info* igi = (index_glyph_info*)malloc(sizeof(index_glyph_info));
                    if (igi != NULL)
                    {
                        igi->offset = cur.offset;
                        igi->len = diff;

                        map_insert(&st->glyphMap, (void*)(intptr_t)cur.glyphCode, igi);
                    }
                    else
                        error = LF_OUT_OF_MEMORY;

                    cur.glyphCode = next.glyphCode;
                    cur.offset = next.offset;
                }
            }
            else if (5 == st->header.indexFormat)
            {
                st->subtable.fmt5.imageSize = STREAM_readULong(stream);
                st->subtable.fmt5.bigMetrics.height = STREAM_readByte(stream);
                st->subtable.fmt5.bigMetrics.width = STREAM_readByte(stream);
                st->subtable.fmt5.bigMetrics.horiBearingX = STREAM_readByte(stream);
                st->subtable.fmt5.bigMetrics.horiBearingY = STREAM_readByte(stream);
                st->subtable.fmt5.bigMetrics.horiAdvance = STREAM_readByte(stream);
                st->subtable.fmt5.bigMetrics.vertBearingX = STREAM_readByte(stream);
                st->subtable.fmt5.bigMetrics.vertBearingY = STREAM_readByte(stream);
                st->subtable.fmt5.bigMetrics.vertAdvance = STREAM_readByte(stream);
                st->subtable.fmt5.numGlyphs = STREAM_readULong(stream);

                for (ULONG k = 0; k < st->subtable.fmt5.numGlyphs && (error == LF_ERROR_OK); k++)
                {
                    index_glyph_info* igi = (index_glyph_info*)malloc(sizeof(index_glyph_info));

                    if (igi != NULL)
                    {
                        USHORT glyphID = STREAM_readUShort(stream);

                        igi->offset = k * st->subtable.fmt5.imageSize;
                        igi->len = st->subtable.fmt5.imageSize;
                        map_insert(&st->glyphMap, (void*)(intptr_t)glyphID, igi);
                    }
                    else
                        error = LF_OUT_OF_MEMORY;
                }
            }
            else
                error = LF_BAD_FORMAT;

            if (error != LF_ERROR_OK)
            {
                EBLC_freeStrikes(table);
                vector_free(&table->bitmapSizeTables);
                free(table);
                return error;
            }
        }

        // Now see if the subtables are in ascending order
        index_subtable* first = (index_subtable*)vector_at(&bst->indexSubTableArray, 0);
        USHORT  prevLast = first->lastGlyphIndex;

        for (ULONG j = 1; j < bst->numberOfIndexSubTables; j++)
        {
            index_subtable* st = (index_subtable*)vector_at(&bst->indexSubTableArray, j);

            ASSERT(st->lastGlyphIndex >= st->firstGlyphIndex);

            if (st->firstGlyphIndex < prevLast)
            {
                error = EBLC_sortSubtable(&bst->indexSubTableArray);
                if (error != LF_ERROR_OK)
                {
                    EBLC_freeStrikes(table);
                    vector_free(&table->bitmapSizeTables);
                    free(table);
                    return error;
                }
                break;
            }
            prevLast = st->lastGlyphIndex;
        }
    }

    return LF_ERROR_OK;
} /*lint !e429  This function frees the table pointer upon error, otherwise its content is filled in. */

static LF_ERROR EBLC_sortSubtable(LF_VECTOR* indexArray)
{
    size_t num = vector_size(indexArray);

    if (num == 0)
        return LF_ERROR_OK;

    GlyphID* startList = malloc(num*sizeof(GlyphID));
    if (startList == NULL)
        return LF_OUT_OF_MEMORY;

    for (size_t i = 0; i < num; i++)
    {
        index_subtable* st = (index_subtable*)vector_at(indexArray, i);

        startList[i] = st->firstGlyphIndex;
    }

    UTILS_quicksortGlyphID((USHORT*)startList, 0, (LONG)(num-1));

    for (size_t i = 0; i < num; i++)
    {
        index_subtable* st = (index_subtable*)vector_at(indexArray, i);

        if (st->firstGlyphIndex != startList[i])
        {
            for (size_t j = i+1; j < num; j++)
            {
                index_subtable* st2 = (index_subtable*)vector_at(indexArray, j);

                if (st2->firstGlyphIndex == startList[i])
                {
                    vector_set_data(indexArray, i, st2);
                    vector_set_data(indexArray, j, st);
                    break;
                }
            }
        }
    }

    free(startList);

    return LF_ERROR_OK;
}

LF_ERROR EBLC_internalRemoveGlyph(embedded_loc_table* table, ULONG index)
{
    if (table == NULL)
        return LF_TABLE_MISSING;

    size_t numStrikes = vector_size(&table->bitmapSizeTables);

    for (size_t i = 0; i < numStrikes; i++)
    {
        bitmap_size_table* bst = (bitmap_size_table*)vector_at(&table->bitmapSizeTables, i);

        for (ULONG j = 0; j < bst->numberOfIndexSubTables; j++)
        {
            index_subtable* st = (index_subtable*)vector_at(&bst->indexSubTableArray, j);

            if ((index >= st->firstGlyphIndex) && (index <= st->lastGlyphIndex))
            {
                index_glyph_info* igi = (index_glyph_info*)map_at(&st->glyphMap, (void*)(intptr_t)index);

                if (igi != NULL)
                {
                    free(igi);
                    map_erase(&st->glyphMap, (void*)(intptr_t)index);
                }
            }
        }
    }

    return LF_ERROR_OK;
}

LF_ERROR EBLC_removeGlyph(const LF_FONT* lfFont, ULONG index)
{
    eblc_table* table = (eblc_table*)map_at(&lfFont->table_map, (void*)TAG_EBLC);

    return EBLC_internalRemoveGlyph(table, index);
}

LF_ERROR EBLC_internalRemap(LF_FONT* lfFont, embedded_loc_table* table, LF_MAP *remap)
{
    if (table == NULL)
        return LF_TABLE_MISSING;

    USHORT numOrigGlyphs = MAXP_getNumGlyphs(lfFont);
    USHORT numRemaining = (USHORT)map_size(remap);

    size_t numStrikes = vector_size(&table->bitmapSizeTables);

    for (size_t i = 0; i < numStrikes; i++)
    {
        bitmap_size_table* bst = (bitmap_size_table*)vector_at(&table->bitmapSizeTables, i);

        for (ULONG j = 0; j < bst->numberOfIndexSubTables; j++)
        {
            index_subtable* st = (index_subtable*)vector_at(&bst->indexSubTableArray, j);

            if (0 != map_size(&st->glyphMap))
            {
                LF_MAP* glyphMap = &st->glyphMap;

                LF_MAP_ITER* mapIter = map_begin(glyphMap);
                if (mapIter != NULL)
                {
                    rb_tree_node* node = map_next(mapIter);

                    while (node)
                    {
                        GlyphID gid = (GlyphID)(intptr_t)node->key;

                        if (gid < numOrigGlyphs)
                        {
                            node->key = map_at(remap, node->key);
                        }
                        else
                        {
                            node->key = (void*)(intptr_t)(numRemaining + (gid - numOrigGlyphs));
                        }

                        node = map_next(mapIter);
                    }
                }
                else
                {
                    return LF_OUT_OF_MEMORY;
                }

                map_free_iter(mapIter);
            }
        }
    }

    return LF_ERROR_OK;
}

LF_ERROR EBLC_remapTable(LF_FONT* lfFont, LF_MAP *remap)
{
    eblc_table* table = (eblc_table*)map_at(&lfFont->table_map, (void*)TAG_EBLC);

    return EBLC_internalRemap(lfFont, table, remap);
}

static LF_ERROR EBLC_determineWriteFormat(index_subtable* st)
{
    boolean contiguous = TRUE;

    LF_MAP* glyphMap = &st->glyphMap;

    LF_MAP_ITER* mapIter = map_begin(glyphMap);
    if (mapIter == NULL)
        return LF_OUT_OF_MEMORY;

    GlyphID prev, curr;

    rb_tree_node* node = map_next(mapIter);

    prev = (GlyphID)(intptr_t)node->key;

    prev -= 1;

    while (node)
    {
        curr = (GlyphID)(intptr_t)node->key;

        if (curr != (GlyphID)(prev + 1))
        {
            contiguous = FALSE;
            break;
        }

        prev = curr;

        node = map_next(mapIter);
    }

    map_free_iter(mapIter);

    st->header.bestWriteFormat = st->header.indexFormat;

    switch (st->header.indexFormat)
    {
    case 1:
        if (contiguous == FALSE)
            st->header.bestWriteFormat = 4;
        // TODO -- could check CBDT to see if all metrics are same
        break;
    case 2:
        if (contiguous == FALSE)
            st->header.bestWriteFormat = 5;
        break;
    case 3:
        if (contiguous == FALSE)
            st->header.bestWriteFormat = 4;
        // TODO -- could check CBDT to see if all metrics are same
        break;
    case 4:
        if (contiguous == TRUE)
            st->header.bestWriteFormat = 1;
        break;
    case 5:
        if (contiguous == TRUE)
            st->header.bestWriteFormat = 2;
        break;
    default:
        return LF_BAD_FORMAT;
    }

    return LF_ERROR_OK;
}

static ULONG EBLC_getSubTableSize(index_subtable* st, USHORT format)
{
    size_t size = 2 * sizeof(USHORT) + sizeof(ULONG);  // indexSubHeader

    switch (format)
    {
    case 1:
        size += sizeof(ULONG) * (map_size(&st->glyphMap) + 1);
        break;
    case 2:
        size += sizeof(ULONG);    // image size
        size += sizeofBigGMs;     // metrics
        break;
    case 3:
    {
        size_t numSlots = map_size(&st->glyphMap) + 1;
        size_t sizeSlots = sizeof(USHORT) * numSlots;
        if (sizeSlots % 4 == 0)
            size += sizeSlots;
        else
            size += sizeSlots + sizeof(USHORT);    // to dword align
        break;
    }
    case 4:
        size += sizeof(ULONG);    // numGlyphs
        size += (1 + map_size(&st->glyphMap)) * (2 * sizeof(USHORT)); // (numGlyphs + 1) * codeOffsetPair 
        break;
    case 5:
        size += sizeof(ULONG);    // image size
        size += sizeofBigGMs;     // metrics
        size += sizeof(ULONG);    // numGlyphs

        size_t numGlyphs = map_size(&st->glyphMap);
        size_t sizeofCodeArray = numGlyphs * sizeof(USHORT);

        size += sizeofCodeArray;
        if (sizeofCodeArray % 4 != 0)
            size += sizeof(USHORT);     // to dword align
        break;
    default:
        break;
    }

    return (ULONG)size;
}

static LF_ERROR EBLC_setIndexArraySize(bitmap_size_table* bst)
{
    // Calculate size of index subTable array size for the strike
    size_t numSubTables = vector_size(&bst->indexSubTableArray);

    bst->indexTablesSize = (ULONG)((2 * sizeof(USHORT) + sizeof(ULONG)) * numSubTables); // for the array info

    for (size_t j = 0; j < numSubTables; j++)
    {
        index_subtable* st = (index_subtable*)vector_at(&bst->indexSubTableArray, j);

        LF_ERROR error = EBLC_determineWriteFormat(st);
        if (error != LF_ERROR_OK)
            return error;

        bst->indexTablesSize += EBLC_getSubTableSize(st, st->header.bestWriteFormat);
    }

    return LF_ERROR_OK;
}

static LF_ERROR EBLC_calculate(eblc_table* table)
{
    size_t numStrikes = vector_size(&table->bitmapSizeTables);

    for (size_t i = 0; i < numStrikes; i++)
    {
        bitmap_size_table* bst = (bitmap_size_table*)vector_at(&table->bitmapSizeTables, i);

        size_t numSubTables = vector_size(&bst->indexSubTableArray);

        // Remove empty subTables
        for (int j = (int)numSubTables - 1; j >= 0; j--)
        {
            index_subtable* st = (index_subtable*)vector_at(&bst->indexSubTableArray, j);
            if (TRUE == map_empty(&st->glyphMap))
            {
                free(st);
                vector_erase(&bst->indexSubTableArray, j);
            }
        }
    }

    // Remove empty strikes.
    for (int i = (int)numStrikes - 1; i >= 0; i--)
    {
        bitmap_size_table* bst = (bitmap_size_table*)vector_at(&table->bitmapSizeTables, i);

        if (0 == vector_size(&bst->indexSubTableArray))
        {
            vector_free(&bst->indexSubTableArray);
            free(bst);

            vector_erase(&table->bitmapSizeTables, i);
        }
    }

    // Should not be empty.
    if (0 == vector_size(&table->bitmapSizeTables))
    {
        // All the strikes were empty. This condition should be detected during subsetting and this table removed.
        return LF_BAD_FORMAT;
    }

    // Set min/max GIDs for each subtable and strike and set the array size.
    numStrikes = vector_size(&table->bitmapSizeTables);

    for (size_t i = 0; i < numStrikes; i++)
    {
        GlyphID minGid = 65535;
        GlyphID maxGid = 0;

        bitmap_size_table* bst = (bitmap_size_table*)vector_at(&table->bitmapSizeTables, i);

        size_t numSubTables = vector_size(&bst->indexSubTableArray);

        for (size_t j = 0; j < numSubTables; j++)
        {
            index_subtable* st = (index_subtable*)vector_at(&bst->indexSubTableArray, j);

            GlyphID minGidForRange = 65535;
            GlyphID maxGidForRange = 0;

            LF_MAP_ITER* mapIter = map_begin(&st->glyphMap);

            if (mapIter != NULL)
            {
                rb_tree_node* node = map_next(mapIter);

                while (node)
                {
                    GlyphID gid = (GlyphID)(intptr_t)node->key;

                    if (gid < minGidForRange)
                        minGidForRange = gid;
                    if (gid > maxGidForRange)
                        maxGidForRange = gid;

                    node = map_next(mapIter);
                }
            }
            else
            {
                return LF_OUT_OF_MEMORY;
            }

            map_free_iter(mapIter);

            st->firstGlyphIndex = minGidForRange;
            st->lastGlyphIndex = maxGidForRange;

            if (minGidForRange < minGid)
                minGid = minGidForRange;
            if (maxGidForRange > maxGid)
                maxGid = maxGidForRange;
        }

        bst->startGlyphIndex = minGid;
        bst->endGlyphIndex = maxGid;

        // Set sizeof array into strike info.
        LF_ERROR error = EBLC_setIndexArraySize(bst);
        if (error != LF_ERROR_OK)
        {
            return error;
        }
    }

    return LF_ERROR_OK;
}

LF_ERROR EBLC_internalUpdate(embedded_loc_table* table, embedded_data_table* dataTable)
{
    if ((table == NULL) || (dataTable == NULL))
        return LF_TABLE_MISSING;

    size_t numStrikes = vector_size(&table->bitmapSizeTables);

    for (size_t i = 0; i < numStrikes; i++)
    {
        bitmap_size_table* bst = (bitmap_size_table*)vector_at(&table->bitmapSizeTables, i);

        // See https://developer.apple.com/fonts/TrueType-Reference-Manual/RM06/Chap6bloc.html for
        // what these mean. Note we are using the above defintions, not those at the MFST site.

        BYTE horiWidthMax     =    0;
        CHAR horiMinOriginSB  =  127;
        CHAR horiMinAdvanceSB =  127;
        CHAR horiMaxBeforeBL  = -127;
        CHAR horiMinAfterBL   =  127;
        BYTE vertWidthMax     =    0;
        CHAR vertMinOriginSB  =  127;
        CHAR vertMinAdvanceSB =  127;
        CHAR vertMaxBeforeBL  = -127;
        CHAR vertMinAfterBL   =  127;

        size_t numSubTables = vector_size(&bst->indexSubTableArray);

        for (ULONG j = 0; j < numSubTables; j++)
        {
            index_subtable* st = (index_subtable*)vector_at(&bst->indexSubTableArray, j);

            if (TRUE == map_empty(&st->glyphMap))
                continue;

            if ((1 == st->header.indexFormat) || (3 == st->header.indexFormat) || (4 == st->header.indexFormat))
            {
                // variable metrics
                LF_MAP* glyphMap = (LF_MAP*)vector_at(&dataTable->strikeGlyphMaps, i);

                LF_MAP_ITER* mapIter = map_begin(glyphMap);
                if (mapIter == NULL)
                {
                    return LF_OUT_OF_MEMORY;
                }

                rb_tree_node* node = map_next(mapIter);

                while (node)
                {
                    bitmap_glyph* bmg = (bitmap_glyph*)node->data;

                    if ((17 == bmg->format) || (1 == bmg->format) || (2 == bmg->format) || (8 == bmg->format))
                    {
                        // Small metrics
                        small_glyph_metrics sm;

                        if (17 == bmg->format)
                            sm = bmg->glyph.fmt17.glyphMetrics;
                        else if (1 == bmg->format)
                            sm = bmg->glyph.fmt1.smallMetrics;
                        else if (2 == bmg->format)
                            sm = bmg->glyph.fmt2.smallMetrics;
                        else
                            sm = bmg->glyph.fmt8.smallMetrics;

                        // Since we do not have vertical metrics, the below
                        // follows fontio's way of dealing with that.
                        CHAR hbearingX, hbearingY, hAdv, vbearingX, vbearingY, vAdv;

                        if (bst->flags & sbitFlagHorizontal)
                        {
                            hbearingX = sm.BearingX;
                            hbearingY = sm.BearingY;
                            hAdv = sm.Advance;
                            vbearingX = (CHAR)(-(sm.width / 2));
                            vbearingY = -1;
                            vAdv = (CHAR)(sm.height + 2);
                        }
                        else
                        {
                            hbearingX = (CHAR)1;
                            hbearingY = (CHAR)(sm.height / 2);
                            hAdv = (CHAR)(sm.width + 2);
                            vbearingX = sm.BearingX;
                            vbearingY = sm.BearingY;
                            vAdv = sm.Advance;
                        }

                        // Horizontal
                        if (sm.width > horiWidthMax)
                            horiWidthMax = sm.width;
                        if (hbearingX < horiMinOriginSB)
                            horiMinOriginSB = hbearingX;
                        if ((hAdv - (hbearingX + sm.width)) < horiMinAdvanceSB)
                            horiMinAdvanceSB = (CHAR)(hAdv - (hbearingX + sm.width));
                        if (hbearingY > horiMaxBeforeBL)
                            horiMaxBeforeBL = hbearingY;
                        if ((hbearingY - sm.height) < horiMinAfterBL)
                            horiMinAfterBL = (CHAR)(hbearingY - sm.height);

                        // Vertical
                        if (sm.width > vertWidthMax)
                            vertWidthMax = sm.width;
                        if (vbearingY < vertMinOriginSB)
                            vertMinOriginSB = vbearingY;

                        int tmp = vAdv - (vbearingY + sm.height);
                        if (tmp > 127)
                            tmp = 127;
                        if (tmp < -127)
                            tmp = -127;
                        if (tmp < vertMinAdvanceSB)
                            vertMinAdvanceSB = (CHAR)tmp;

                        if (vbearingX > vertMaxBeforeBL)
                            vertMaxBeforeBL = vbearingX;

                        tmp = vbearingX - sm.width;
                        if (tmp > 127)
                            tmp = 127;
                        if (tmp < -127)
                            tmp = -127;
                        if (tmp < vertMinAfterBL)
                            vertMinAfterBL = (CHAR)tmp;
                    }
                    else if ((18 == bmg->format) || (6 == bmg->format) || (7 == bmg->format) || (9 == bmg->format))
                    {
                        // Big metrics
                        big_glyph_metrics m;

                        if (18 == bmg->format)
                            m = bmg->glyph.fmt18.glyphMetrics;
                        else if (6 == bmg->format)
                            m = bmg->glyph.fmt6.bigMetrics;
                        else if (7 == bmg->format)
                            m = bmg->glyph.fmt7.bigMetrics;
                        else
                            m = bmg->glyph.fmt9.bigMetrics;

                        if (m.width > horiWidthMax)
                            horiWidthMax = m.width;
                        if (m.horiBearingX < horiMinOriginSB)
                            horiMinOriginSB = m.horiBearingX;
                        if ((m.horiAdvance - (m.horiBearingX + m.width)) < horiMinAdvanceSB)
                            horiMinAdvanceSB = (CHAR)(m.horiAdvance - (m.horiBearingX + m.width));
                        if (m.horiBearingY > horiMaxBeforeBL)
                            horiMaxBeforeBL = m.horiBearingY;
                        if ((m.horiBearingY - m.height) < horiMinAfterBL)
                            horiMinAfterBL = (CHAR)(m.horiBearingY - m.height);
                        if (m.width > vertWidthMax)
                            vertWidthMax = m.width;
                        if (m.vertBearingY < vertMinOriginSB)
                            vertMinOriginSB = m.vertBearingY;
                        if ((m.vertAdvance - (m.vertBearingY + m.height)) < vertMinAdvanceSB)
                            vertMinAdvanceSB = (CHAR)(m.vertAdvance - (m.vertBearingY + m.height));
                        if (m.vertBearingX > vertMaxBeforeBL)
                            vertMaxBeforeBL = m.vertBearingX;
                        if ((m.vertBearingX - m.width) < vertMinAfterBL)
                            vertMinAfterBL = (CHAR)(m.vertBearingX - m.width);
                    }
                    else if ((5 == bmg->format) || (19 == bmg->format))
                    {
                        DEBUG_LOG_ERROR("image format not compatible with index format.");
                    }

                    node = map_next(mapIter);
                }

                map_free_iter(mapIter);
            }
            else if ((2 == st->header.indexFormat) || (5 == st->header.indexFormat))
            {
                // constant metrics
                big_glyph_metrics m;

                if (2 == st->header.indexFormat)
                    m = st->subtable.fmt2.bigMetrics;
                else
                    m = st->subtable.fmt5.bigMetrics;

                if (m.width > horiWidthMax)
                    horiWidthMax = m.width;
                if (m.horiBearingX < horiMinOriginSB)
                    horiMinOriginSB = m.horiBearingX;
                if ((m.horiAdvance - (m.horiBearingX + m.width)) < horiMinAdvanceSB)
                    horiMinAdvanceSB = (CHAR)(m.horiAdvance - (m.horiBearingX + m.width));
                if (m.horiBearingY > horiMaxBeforeBL)
                    horiMaxBeforeBL = m.horiBearingY;
                if ((m.horiBearingY - m.height) < horiMinAfterBL)
                    horiMinAfterBL = (CHAR)(m.horiBearingY - m.height);

                if (m.width > vertWidthMax)
                    vertWidthMax = m.width;
                if (m.vertBearingY < vertMinOriginSB)
                    vertMinOriginSB = m.vertBearingY;
                if ((m.vertAdvance - (m.vertBearingY + m.height)) < vertMinAdvanceSB)
                    vertMinAdvanceSB = (CHAR)(m.vertAdvance - (m.vertBearingY + m.height));
                if (m.vertBearingX > vertMaxBeforeBL)
                    vertMaxBeforeBL = m.vertBearingX;
                if ((m.vertBearingX - m.width) < vertMinAfterBL)
                    vertMinAfterBL = (CHAR)(m.vertBearingX - m.width);
            }
            else
            {
                DEBUG_LOG_ERROR("Unknown index format in EBLC_internalUpdate.");
            }
        }

        bst->hori.maxBeforeBL = horiMaxBeforeBL;
        bst->hori.minAdvanceSB = horiMinAdvanceSB;
        bst->hori.minAfterBL = horiMinAfterBL;
        bst->hori.minOriginSB = horiMinOriginSB;
        bst->hori.widthMax = horiWidthMax;

        bst->vert.maxBeforeBL = vertMaxBeforeBL;
        bst->vert.minAdvanceSB = vertMinAdvanceSB;
        bst->vert.minAfterBL = vertMinAfterBL;
        bst->vert.minOriginSB = vertMinOriginSB;
        bst->vert.widthMax = vertWidthMax;
    }

    return LF_ERROR_OK;
}

LF_ERROR EBLC_updateMetrics(LF_FONT* lfFont)
{
    eblc_table* table = (eblc_table*)map_at(&lfFont->table_map, (void*)TAG_EBLC);

    embedded_data_table* dataTable = (embedded_data_table*)map_at(&lfFont->table_map, (void*)TAG_EBDT);

    return EBLC_internalUpdate(table, dataTable);
}

LF_ERROR EBLC_internalGetSize(embedded_loc_table* table, size_t* tableSize)
{
    *tableSize = 0;

    if (table == NULL)
        return LF_TABLE_MISSING;

    if (table->calculatedTableSize != 0)
    {
        *tableSize = table->calculatedTableSize;
        return LF_ERROR_OK;
    }

    LF_ERROR error = EBLC_calculate(table);
    if (error != LF_ERROR_OK)
        return error;

    *tableSize += sizeof(FIXED);     // version
    *tableSize += sizeof(ULONG);     // numsizes

    size_t numStrikes = vector_size(&table->bitmapSizeTables);

    for (size_t i = 0; i < numStrikes; i++)
    {
        bitmap_size_table* bst = (bitmap_size_table*)vector_at(&table->bitmapSizeTables, i);

        *tableSize += sizeofBitmapSizeTable;                // strike info (bitmapSizeTable)
        *tableSize += bst->indexTablesSize;                 // calculated above in EBLC_calculate
    }

    table->calculatedTableSize = (ULONG)*tableSize;

    return LF_ERROR_OK;
}

LF_ERROR EBLC_getTableSize(LF_FONT* lfFont, size_t* tableSize)
{
    eblc_table* table = (eblc_table*)map_at(&lfFont->table_map, (void*)TAG_EBLC);

    return EBLC_internalGetSize(table, tableSize);
}

LF_ERROR EBLC_buildTable(embedded_loc_table*table, embedded_data_table* dataTable, ULONG version, BYTE** tableData, size_t* tableSize)
{
    *tableData = NULL;
    *tableSize = 0;

    LF_ERROR error = EBLC_internalGetSize(table, tableSize);
    if (error != LF_ERROR_OK)
        return error;

    size_t paddedSize = *tableSize;
    *tableData = UTILS_AllocTable(&paddedSize);

    if (*tableData == NULL)
    {
        DEBUG_LOG_ERROR("allocation failure in EBLC_buildTable");
        return LF_OUT_OF_MEMORY;
    }

    LF_STREAM stream;
    STREAM_initMemStream(&stream, *tableData, *tableSize);

    size_t numStrikes = vector_size(&table->bitmapSizeTables);

    STREAM_writeFixed(&stream, version); // Version
    STREAM_writeULong(&stream, (ULONG)numStrikes);

    ULONG offsetIntoDataTable = 0;

    // Data table starts with version
    offsetIntoDataTable += sizeof(FIXED);

    ULONG offsetToSubTableArray = (ULONG)(STREAM_streamPos(&stream) + numStrikes * sizeofBitmapSizeTable);

    // write the bitmapSizeTables
    for (size_t i = 0; i < numStrikes; i++)
    {
        bitmap_size_table* bst = (bitmap_size_table*)vector_at(&table->bitmapSizeTables, i);

        ULONG numSubtables = (ULONG)vector_size(&bst->indexSubTableArray);

        STREAM_writeULong(&stream, offsetToSubTableArray);
        STREAM_writeULong(&stream, bst->indexTablesSize);
        STREAM_writeULong(&stream, numSubtables);
        STREAM_writeULong(&stream, 0x0);
        STREAM_writeByte(&stream, bst->hori.ascender);
        STREAM_writeByte(&stream, bst->hori.descender);
        STREAM_writeByte(&stream, bst->hori.widthMax);
        STREAM_writeByte(&stream, bst->hori.caretSlopeNumerator);
        STREAM_writeByte(&stream, bst->hori.caretSlopeDenominator);
        STREAM_writeByte(&stream, bst->hori.caretOffset);
        STREAM_writeByte(&stream, bst->hori.minOriginSB);
        STREAM_writeByte(&stream, bst->hori.minAdvanceSB);
        STREAM_writeByte(&stream, bst->hori.maxBeforeBL);
        STREAM_writeByte(&stream, bst->hori.minAfterBL);
        STREAM_writeByte(&stream, 0x0);
        STREAM_writeByte(&stream, 0x0);
        STREAM_writeByte(&stream, bst->vert.ascender);
        STREAM_writeByte(&stream, bst->vert.descender);
        STREAM_writeByte(&stream, bst->vert.widthMax);
        STREAM_writeByte(&stream, bst->vert.caretSlopeNumerator);
        STREAM_writeByte(&stream, bst->vert.caretSlopeDenominator);
        STREAM_writeByte(&stream, bst->vert.caretOffset);
        STREAM_writeByte(&stream, bst->vert.minOriginSB);
        STREAM_writeByte(&stream, bst->vert.minAdvanceSB);
        STREAM_writeByte(&stream, bst->vert.maxBeforeBL);
        STREAM_writeByte(&stream, bst->vert.minAfterBL);
        STREAM_writeByte(&stream, 0x0);
        STREAM_writeByte(&stream, 0x0);
        STREAM_writeUShort(&stream, bst->startGlyphIndex);
        STREAM_writeUShort(&stream, bst->endGlyphIndex);
        STREAM_writeByte(&stream, bst->ppemX);
        STREAM_writeByte(&stream, bst->ppemY);
        STREAM_writeByte(&stream, bst->bitDepth);
        STREAM_writeByte(&stream, bst->flags);

        offsetToSubTableArray += bst->indexTablesSize;
    }

    const size_t sizeofIndexArrayItem = 2 * sizeof(USHORT) + sizeof(ULONG);

    // write the strikes
    for (size_t i = 0; i < numStrikes; i++)
    {
        bitmap_size_table* bst = (bitmap_size_table*)vector_at(&table->bitmapSizeTables, i);

        // write the subTable arrays
        size_t numSubTables = vector_size(&bst->indexSubTableArray);

        ULONG additionalOffset = (ULONG)(sizeofIndexArrayItem * numSubTables);

        for (size_t j = 0; j < numSubTables; j++)
        {
            index_subtable* st = (index_subtable*)vector_at(&bst->indexSubTableArray, j);

            STREAM_writeUShort(&stream, st->firstGlyphIndex);
            STREAM_writeUShort(&stream, st->lastGlyphIndex);
            STREAM_writeULong(&stream, additionalOffset);

            additionalOffset += EBLC_getSubTableSize(st, st->header.bestWriteFormat);
        }

        for (size_t j = 0; j < numSubTables; j++)
        {
            index_subtable* st = (index_subtable*)vector_at(&bst->indexSubTableArray, j);

            if (1 == st->header.bestWriteFormat)
            {
                // header
                STREAM_writeUShort(&stream, 1);
                STREAM_writeUShort(&stream, st->header.imageFormat);
                STREAM_writeULong(&stream, offsetIntoDataTable);

                // offset array
                index_glyph_info* igi;

                ULONG offsetToGlyph = 0;

                for (ULONG gid = st->firstGlyphIndex; gid <= st->lastGlyphIndex; gid++)
                {
                    igi = map_at(&st->glyphMap, (void*)(intptr_t)gid);
                    if (igi == NULL)
                    {
                        free(*tableData);
                        return LF_BAD_FORMAT;
                    }

                    STREAM_writeULong(&stream, offsetToGlyph);

                    offsetToGlyph += igi->len;

                    offsetIntoDataTable += igi->len;
                }

                STREAM_writeULong(&stream, offsetToGlyph);
            }
            else if (2 == st->header.bestWriteFormat)
            {
                // header
                STREAM_writeUShort(&stream, 2);
                STREAM_writeUShort(&stream, st->header.imageFormat);
                STREAM_writeULong(&stream, offsetIntoDataTable);

                // image size
                STREAM_writeULong(&stream, st->subtable.fmt2.imageSize);

                // Big metrics
                STREAM_writeByte(&stream, st->subtable.fmt2.bigMetrics.height);
                STREAM_writeByte(&stream, st->subtable.fmt2.bigMetrics.width);
                STREAM_writeByte(&stream, st->subtable.fmt2.bigMetrics.horiBearingX);
                STREAM_writeByte(&stream, st->subtable.fmt2.bigMetrics.horiBearingY);
                STREAM_writeByte(&stream, st->subtable.fmt2.bigMetrics.horiAdvance);
                STREAM_writeByte(&stream, st->subtable.fmt2.bigMetrics.vertBearingX);
                STREAM_writeByte(&stream, st->subtable.fmt2.bigMetrics.vertBearingY);
                STREAM_writeByte(&stream, st->subtable.fmt2.bigMetrics.vertAdvance);

                if ((st->header.imageFormat != 9) && (st->header.imageFormat != 8))
                {
                    // 5 and 19 have been seen
                    offsetIntoDataTable += st->subtable.fmt2.imageSize * (st->lastGlyphIndex - st->firstGlyphIndex + 1);
                }
                else
                {
                    // we need the data table for this, since we don't know how many components
                    // each glyph has.
                    LF_MAP* glyphMap = (LF_MAP*)vector_at(&dataTable->strikeGlyphMaps, i);

                    ULONG numGlyphs = (st->lastGlyphIndex - st->firstGlyphIndex + 1);

                    offsetIntoDataTable += numGlyphs * (sizeofBigGMs + sizeof(USHORT)); // for the metrics and numComponents

                    // Add in the components
                    for (USHORT k = st->firstGlyphIndex; k <= st->lastGlyphIndex; k++)
                    {
                        bitmap_glyph* glyph = (bitmap_glyph*)map_at(glyphMap, (void*)(intptr_t)k);

                        if (glyph != NULL)
                        {
                            ASSERT((glyph->format == 9) || (glyph->format == 8));

                            size_t numComps;

                            if (glyph->format == 9)
                                numComps = vector_size(&glyph->glyph.fmt9.compArray);
                            else
                                numComps = vector_size(&glyph->glyph.fmt8.compArray);

                            offsetIntoDataTable += (ULONG)(numComps * sizeofEbdtComponent);
                        }
                        ASSERT(glyph);
                    }
                }
            }
            else if (3 == st->header.bestWriteFormat)
            {
                // header
                STREAM_writeUShort(&stream, 3);
                STREAM_writeUShort(&stream, st->header.imageFormat);
                STREAM_writeULong(&stream, offsetIntoDataTable);

                // offset array
                USHORT offsetToGlyph = 0;
                index_glyph_info* igi;

                for (USHORT gid = st->firstGlyphIndex; gid <= st->lastGlyphIndex; gid++)
                {
                    igi = map_at(&st->glyphMap, (void*)(intptr_t)gid);
                    if (igi == NULL)
                    {
                        free(*tableData);
                        return LF_BAD_FORMAT;
                    }

                    STREAM_writeUShort(&stream, offsetToGlyph);

                    offsetToGlyph += (USHORT)igi->len;

                    offsetIntoDataTable += igi->len;
                }

                STREAM_writeUShort(&stream, offsetToGlyph);

                // pad to dword align if needed
                size_t sizeOffsetArray = (map_size(&st->glyphMap) + 1) * sizeof(USHORT);
                if (sizeOffsetArray % 4 != 0)
                    STREAM_writeUShort(&stream, 0x0);
            }
            else if (4 == st->header.bestWriteFormat)
            {
                // header
                STREAM_writeUShort(&stream, 4);
                STREAM_writeUShort(&stream, st->header.imageFormat);
                STREAM_writeULong(&stream, offsetIntoDataTable);

                // num glyphs
                ULONG numGlyphs = map_size(&st->glyphMap);
                STREAM_writeULong(&stream, numGlyphs);

                // codeOffsetPair array
                USHORT offsetToGlyph = 0;
                LF_MAP_ITER* mapIter = map_begin(&st->glyphMap);
                if (mapIter != NULL)
                {
                    rb_tree_node* node = map_next(mapIter);

                    while (node)
                    {
                        GlyphID gid = (GlyphID)(intptr_t)node->key;
                        index_glyph_info* igi = (index_glyph_info*)node->data;

                        STREAM_writeUShort(&stream, gid);
                        STREAM_writeUShort(&stream, offsetToGlyph);

                        offsetToGlyph += (USHORT)igi->len;

                        offsetIntoDataTable += igi->len;

                        node = map_next(mapIter);
                    }

                    // for len of last one
                    STREAM_writeUShort(&stream, 0);
                    STREAM_writeUShort(&stream, offsetToGlyph);

                    map_free_iter(mapIter);
                }
                else
                {
                    free(*tableData);
                    return LF_OUT_OF_MEMORY;
                }
            }
            else if (5 == st->header.bestWriteFormat)
            {
                // header
                STREAM_writeUShort(&stream, 5);
                STREAM_writeUShort(&stream, st->header.imageFormat);
                STREAM_writeULong(&stream, offsetIntoDataTable);

                // image size
                STREAM_writeULong(&stream, st->subtable.fmt5.imageSize);

                // big metrics
                STREAM_writeByte(&stream, st->subtable.fmt5.bigMetrics.height);
                STREAM_writeByte(&stream, st->subtable.fmt5.bigMetrics.width);
                STREAM_writeByte(&stream, st->subtable.fmt5.bigMetrics.horiBearingX);
                STREAM_writeByte(&stream, st->subtable.fmt5.bigMetrics.horiBearingY);
                STREAM_writeByte(&stream, st->subtable.fmt5.bigMetrics.horiAdvance);
                STREAM_writeByte(&stream, st->subtable.fmt5.bigMetrics.vertBearingX);
                STREAM_writeByte(&stream, st->subtable.fmt5.bigMetrics.vertBearingY);
                STREAM_writeByte(&stream, st->subtable.fmt5.bigMetrics.vertAdvance);

                // num glyphs
                ULONG numGlyphs = map_size(&st->glyphMap);
                STREAM_writeULong(&stream, numGlyphs);

                // glyph code array
                LF_MAP_ITER* mapIter = map_begin(&st->glyphMap);
                if (mapIter == NULL)
                {
                    free(*tableData);
                    return LF_OUT_OF_MEMORY;
                }

                rb_tree_node* node = map_next(mapIter);

                while (node)
                {
                    GlyphID gid = (GlyphID)(intptr_t)node->key;
                    STREAM_writeUShort(&stream, gid);

                    node = map_next(mapIter);
                }

                map_free_iter(mapIter);

                // pad to dword align if needed
                size_t sizeofCodeArray = numGlyphs * sizeof(USHORT);
                if (sizeofCodeArray % 4 != 0)
                    STREAM_writeUShort(&stream, 0x0);

                offsetIntoDataTable += numGlyphs * st->subtable.fmt5.imageSize;
            }
        }
    }

    return LF_ERROR_OK;
}

LF_ERROR EBLC_writeTable(LF_FONT* lfFont, sfnt_table_record* record, LF_STREAM* stream)
{
    size_t tableSize;
    BYTE* tableData;

    eblc_table* table = (eblc_table*)map_at(&lfFont->table_map, (void*)TAG_EBLC);
    if (table == NULL)
        return LF_TABLE_MISSING;

    embedded_data_table* dataTable = (embedded_data_table*)map_at(&lfFont->table_map, (void*)TAG_EBDT);
    if (dataTable == NULL)
        return LF_TABLE_MISSING;

    LF_ERROR error = EBLC_buildTable(table, dataTable, 0x00020000, &tableData, &tableSize);
    if (error != LF_ERROR_OK)
        return error;

    record->checkSum = UTILS_CalcTableChecksum(tableData, tableSize);
    record->length = (ULONG)tableSize;
    record->offset = (ULONG)STREAM_streamPos(stream);

    STREAM_writeChunk(stream, tableData, (tableSize + 3) & ~3);
    free(tableData);

    return LF_ERROR_OK;
}

void EBLC_freeStrikes(embedded_loc_table* table)
{
    size_t numStrikes = vector_size(&table->bitmapSizeTables);

    for (size_t i = 0; i < numStrikes; i++)
    {
        bitmap_size_table* bst = (bitmap_size_table*)vector_at(&table->bitmapSizeTables, i);

        size_t numSubtables = vector_size(&bst->indexSubTableArray);

        for (ULONG j = 0; j < numSubtables; j++)
        {
            index_subtable* st = (index_subtable*)vector_at(&bst->indexSubTableArray, j);

            LF_MAP_ITER* mapIter = map_begin(&st->glyphMap);
            if (mapIter == NULL)
            {
                return; // there will be memory leaks
            }

            rb_tree_node* node = map_next(mapIter);

            while (node)
            {
                index_glyph_info* igi = (index_glyph_info*)node->data;

                free(igi);

                node = map_next(mapIter);
            }

            map_free_iter(mapIter);

            map_clear(&st->glyphMap);

            free(st);
        }

        vector_free(&bst->indexSubTableArray);

        free(bst);
    }
} /*lint !e429  The table itself is freed by whatever calls this function. */

LF_ERROR EBLC_freeTable(LF_FONT* lfFont)
{
    eblc_table* table = (eblc_table*)map_at(&lfFont->table_map, (void*)TAG_EBLC);

    if (table != NULL)
    {
        EBLC_freeStrikes(table);
        vector_free(&table->bitmapSizeTables);
        free(table);
    }

    return LF_ERROR_OK;
}
