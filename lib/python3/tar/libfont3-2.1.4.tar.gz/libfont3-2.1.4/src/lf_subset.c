// Copyright (C) 2014, 2015, 2016 Monotype Imaging Inc. All rights reserved.
// Confidential information of Monotype Imaging Inc.
/// \file lf_subset.c

#include "lf_subset.h"
#include "keep_table.h"
#include "utils.h"
#include "cblc_table.h"
#include "cbdt_table.h"
#include "cff_table.h"
#include "cmap_table.h"
#include "colr_table.h"
#include "eblc_table.h"
#include "ebdt_table.h"
#include "fmtx_table.h"
#include "gdef_table.h"
#include "gsub_table.h"
#include "glyf_table.h"
#include "gpos_table.h"
#include "gvar_table.h"
#include "hdmx_table.h"
#include "head_table.h"
#include "hhea_table.h"
#include "hmtx_table.h"
#include "kern_table.h"
#include "loca_table.h"
#include "ltsh_table.h"
#include "maxp_table.h"
#include "os2_table.h"
#include "post_table.h"
#include "sbix_table.h"
#include "vhea_table.h"
#include "vmtx_table.h"
#include "feature_table.h"
#include "sfnt_core.h"
#include "normalization/norm_nfc.h"
#include "resources/buildlang.h"


// Bengali
#define        TS_BENGALI_VOWEL_SIGN_O          0x9cb
#define        TS_BENGALI_VOWEL_SIGN_AU         0x9cc

#define        TS_BENGALI_VOWEL_SIGN_E          0x9c7
#define        TS_BENGALI_VOWEL_SIGN_AA         0x9be
#define        TS_BENGALI_AU_LENGTH_MARK        0x9d7

// Devanagari
#define        TS_CHAR_DEVANAGARI_SIGN_HALANT   0x94d
#define        TS_CHAR_DEVANAGARI_LETTER_RA     0x930

#define        TS_CHAR_ZWJ                      0x200d

// Khmer
#define        TS_KHMER_VOWEL_SIGN_OE           0x17be
#define        TS_KHMER_VOWEL_SIGN_YA           0x17bf
#define        TS_KHMER_VOWEL_SIGN_IE           0x17c0
#define        TS_KHMER_VOWEL_SIGN_OO           0x17c4
#define        TS_KHMER_VOWEL_SIGN_AU           0x17c5

#define        TS_KHMER_VOWEL_SIGN_E            0x17c1

// Kannada
#define        TS_KANNADA_VOWEL_SIGN_II         0xcc0
#define        TS_KANNADA_VOWEL_SIGN_EE         0xcc7
#define        TS_KANNADA_VOWEL_SIGN_AI         0xcc8
#define        TS_KANNADA_VOWEL_SIGN_O          0xcca
#define        TS_KANNADA_VOWEL_SIGN_OO         0xccb

#define        TS_KANNADA_VOWEL_SIGN_I          0xcbf
#define        TS_KANNADA_LENGTH_MARK           0xcd5
#define        TS_KANNADA_VOWEL_SIGN_E          0xcc6
#define        TS_KANNADA_VOWEL_SIGN_UU         0xcc2

// Malayalam
#define        TS_MALAYALAM_VOWEL_SIGN_O        0xd4a
#define        TS_MALAYALAM_VOWEL_SIGN_OO       0xd4b
#define        TS_MALAYALAM_VOWEL_SIGN_AU       0xd4c
#define        TS_MALAYALAM_SIGN_VIRAMA         0xd4d

#define        TS_MALAYALAM_VOWEL_SIGN_E        0xd46
#define        TS_MALAYALAM_VOWEL_SIGN_AA       0xd3e
#define        TS_MALAYALAM_VOWEL_SIGN_EE       0xd47
#define        TS_MALAYALAM_AU_LENGTH_MARK      0xd57
#define        TS_MALAYALAM_LETTER_RA           0xd30

// Oriya
#define        TS_ORIYA_VOWEL_SIGN_AI           0xb48
#define        TS_ORIYA_VOWEL_SIGN_O            0xb4b
#define        TS_ORIYA_VOWEL_SIGN_AU           0xb4c

#define        TS_ORIYA_VOWEL_SIGN_E            0xb47
#define        TS_ORIYA_AI_LENGTH_MARK          0xb56
#define        TS_ORIYA_VOWEL_SIGN_AA           0xb3e
#define        TS_ORIYA_AU_LENGTH_MARK          0xb57

// Sinhala
#define        TS_SINHALA_VOWEL_SIGN_EE         0xdda
#define        TS_SINHALA_VOWEL_SIGN_O          0xddc
#define        TS_SINHALA_VOWEL_SIGN_OO         0xddd
#define        TS_SINHALA_VOWEL_SIGN_AU         0xdde

#define        TS_SINHALA_VOWEL_SIGN_E          0xdd9
#define        TS_SINHALA_HALANT                0xdca
#define        TS_SINHALA_VOWEL_SIGN_AA         0xdcf
#define        TS_SINHALA_VOWEL_SIGN_VOCALIC_L  0xddf

// Tamil
#define        TS_TAMIL_VOWEL_SIGN_O            0xbca
#define        TS_TAMIL_VOWEL_SIGN_OO           0xbcb
#define        TS_TAMIL_VOWEL_SIGN_AU           0xbcc

#define        TS_TAMIL_VOWEL_SIGN_E            0xbc6
#define        TS_TAMIL_VOWEL_SIGN_AA           0xbbe
#define        TS_TAMIL_VOWEL_SIGN_EE           0xbc7
#define        TS_TAMIL_AU_LENGTH_MARK          0xbd7

// Telugu
#define        TS_TELUGU_VOWEL_SIGN_AI          0xc48

#define        TS_TELUGU_VOWEL_SIGN_E           0xc46
#define        TS_TELUGU_AI_LENGTH_MARK         0xc56

// Thai
#define        TS_CHAR_THAI_VOWEL_SIGN_SARA_AM  0xe33
#define        TS_CHAR_THAI_NIKKHAHIT           0xe4d
#define        TS_CHAR_THAI_VOWEL_SIGN_SARA_AA  0xe32


// a Unicode matrix that supports extra glyphs that are not represented
// in standard OpenType format and GSUB/GPOS rules.

#define NUM_ADDED_UNICODES  4

static const ULONG addedUnicodes[][NUM_ADDED_UNICODES] =
{
    // Bengali
    { TS_BENGALI_VOWEL_SIGN_O,      TS_BENGALI_VOWEL_SIGN_E,    TS_BENGALI_VOWEL_SIGN_AA,   0 },
    { TS_BENGALI_VOWEL_SIGN_AU,     TS_BENGALI_VOWEL_SIGN_E,    TS_BENGALI_AU_LENGTH_MARK,  0 },

    // Devanagari
    { TS_CHAR_DEVANAGARI_SIGN_HALANT, TS_CHAR_DEVANAGARI_LETTER_RA, TS_CHAR_ZWJ, 0 },

    //Khmer
    { TS_KHMER_VOWEL_SIGN_OE, TS_KHMER_VOWEL_SIGN_E, 0, 0 },
    { TS_KHMER_VOWEL_SIGN_YA, TS_KHMER_VOWEL_SIGN_E, 0, 0 },
    { TS_KHMER_VOWEL_SIGN_IE, TS_KHMER_VOWEL_SIGN_E, 0, 0 },
    { TS_KHMER_VOWEL_SIGN_OO, TS_KHMER_VOWEL_SIGN_E, 0, 0 },
    { TS_KHMER_VOWEL_SIGN_AU, TS_KHMER_VOWEL_SIGN_E, 0, 0 },

    // Kannada
    { TS_KANNADA_VOWEL_SIGN_II, TS_KANNADA_VOWEL_SIGN_I, TS_KANNADA_LENGTH_MARK, 0 },
    { TS_KANNADA_VOWEL_SIGN_EE, TS_KANNADA_VOWEL_SIGN_E, TS_KANNADA_LENGTH_MARK, 0 },
    { TS_KANNADA_VOWEL_SIGN_AI, TS_KANNADA_VOWEL_SIGN_E, TS_KANNADA_LENGTH_MARK, 0 },
    { TS_KANNADA_VOWEL_SIGN_O,  TS_KANNADA_VOWEL_SIGN_E, TS_KANNADA_VOWEL_SIGN_UU, 0 },
    { TS_KANNADA_VOWEL_SIGN_OO, TS_KANNADA_VOWEL_SIGN_E, TS_KANNADA_VOWEL_SIGN_UU, TS_KANNADA_LENGTH_MARK },

    // Malayalam
    { TS_MALAYALAM_VOWEL_SIGN_O, TS_MALAYALAM_VOWEL_SIGN_E, TS_MALAYALAM_VOWEL_SIGN_AA, 0 },
    { TS_MALAYALAM_VOWEL_SIGN_OO, TS_MALAYALAM_VOWEL_SIGN_EE, TS_MALAYALAM_VOWEL_SIGN_AA, 0 },
    { TS_MALAYALAM_VOWEL_SIGN_AU, TS_MALAYALAM_VOWEL_SIGN_E, TS_MALAYALAM_AU_LENGTH_MARK, 0 },
    { TS_MALAYALAM_SIGN_VIRAMA, TS_MALAYALAM_LETTER_RA, 0, 0 },

    // Oriya
    { TS_ORIYA_VOWEL_SIGN_AI, TS_ORIYA_VOWEL_SIGN_E, TS_ORIYA_AI_LENGTH_MARK, 0 },
    { TS_ORIYA_VOWEL_SIGN_O,  TS_ORIYA_VOWEL_SIGN_E, TS_ORIYA_VOWEL_SIGN_AA, 0 },
    { TS_ORIYA_VOWEL_SIGN_AU, TS_ORIYA_VOWEL_SIGN_E, TS_ORIYA_AU_LENGTH_MARK, 0 },

    // Sinhala
    { TS_SINHALA_VOWEL_SIGN_EE, TS_SINHALA_VOWEL_SIGN_E, TS_SINHALA_HALANT, 0  },
    { TS_SINHALA_VOWEL_SIGN_O,  TS_SINHALA_VOWEL_SIGN_E, TS_SINHALA_VOWEL_SIGN_AA, 0  },
    { TS_SINHALA_VOWEL_SIGN_OO, TS_SINHALA_VOWEL_SIGN_E, TS_SINHALA_VOWEL_SIGN_AA, TS_SINHALA_HALANT  },
    { TS_SINHALA_VOWEL_SIGN_AU, TS_SINHALA_VOWEL_SIGN_E, TS_SINHALA_VOWEL_SIGN_VOCALIC_L, 0 },

    // Tamil
    { TS_TAMIL_VOWEL_SIGN_O,  TS_TAMIL_VOWEL_SIGN_E,  TS_TAMIL_VOWEL_SIGN_AA, 0  },
    { TS_TAMIL_VOWEL_SIGN_OO, TS_TAMIL_VOWEL_SIGN_EE, TS_TAMIL_VOWEL_SIGN_AA, 0  },
    { TS_TAMIL_VOWEL_SIGN_AU, TS_TAMIL_VOWEL_SIGN_E,  TS_TAMIL_AU_LENGTH_MARK, 0  },

    // Telugu
    { TS_TELUGU_VOWEL_SIGN_AI, TS_TELUGU_VOWEL_SIGN_E, TS_TELUGU_AI_LENGTH_MARK, 0 },

    // Thai
    { TS_CHAR_THAI_VOWEL_SIGN_SARA_AM, TS_CHAR_THAI_NIKKHAHIT, TS_CHAR_THAI_VOWEL_SIGN_SARA_AA, 0 }
};

static void checkPresentationFormScripts(const ULONG* unicodes, ULONG numUnicodes, boolean* hasArabic, boolean* hasHebrew, boolean* hasThai)
{
    // Arabic range is 0600�06FF 0750�077F 08A0�08FF
    // Hebrew range is 0590�05FF
    // Thai range is 0E00�0E7F

    *hasArabic = *hasHebrew = *hasThai = FALSE;

    const ULONG* uniPtr = unicodes;

    for (ULONG i = 0; i < numUnicodes; i++, uniPtr++)
    {
        if ((*uniPtr >= 0x0600 && *uniPtr <= 0x06FF) || (*uniPtr >= 0x0750 && *uniPtr <= 0x077F) || (*uniPtr >= 0x08A0 && *uniPtr <= 0x08FF))
            *hasArabic = TRUE;
        if (*uniPtr >= 0x0590 && *uniPtr <= 0x05FF)
            *hasHebrew = TRUE;
        if (*uniPtr >= 0x0E00 && *uniPtr <= 0x0E7F)
            *hasThai = TRUE;
    }
}

/* ----------------------------------------------------------------------------
    @desc
        Adds shaped characters into the Unicode feed.  This brings in the
        "Alphabetic Presentation Forms" in the absence of OpenType tables
        like GSUB/GPOS.  Some OS use these characters for "legacy shaping".

        This function will add the Arabic, Hebrew, and Thai presentation
        form Unicodes to the input stream, if the subset contains Unicodes
        from the corresponding script.

    @see also
        http://jira.monotype.com:8080/browse/LIB-91 (and LIB-382)

---------------------------------------------------------------------------- */
static void addAlphabeticPresentationForms(const LF_FONT* lfFont, const ULONG* unicodes, ULONG numUnicodes, LF_MAP* unicodeMap)
{
    sfnt_table_record* gpos_record = offset_findRecord(lfFont, TAG_GPOS);
    sfnt_table_record* gsub_record = offset_findRecord(lfFont, TAG_GSUB);

    if (gpos_record == NULL && gsub_record == NULL)
    {
        int i;
        boolean hasArabic, hasHebrew, hasThai;

        checkPresentationFormScripts(unicodes, numUnicodes, &hasArabic, &hasHebrew, &hasThai);

        if (hasArabic == TRUE)
        {
            // Arabic Presentation Forms A & B blocks
            for (i = 0xFB50; i <= 0xFEFC; i++)
            {
                map_insert(unicodeMap, (void*)(intptr_t)i, (void*)(intptr_t)i);
            }
        }

        if (hasHebrew == TRUE)
        {
            // Hebrew Presentation Forms
            for (i = 0xFB1D; i <= 0xFB4F; i++)
            {
                map_insert(unicodeMap, (void*)(intptr_t)i, (void*)(intptr_t)i);
            }
        }

        if (hasThai == TRUE)
        {
            // Thai Presentation Forms
            for (i = 0xF700; i <= 0xF71D; i++)
            {
                map_insert(unicodeMap, (void*)(intptr_t)i, (void*)(intptr_t)i);
            }
        }
    }
}

/* ----------------------------------------------------------------------------
    @desc
        The space character is always included in the subset. The Unicode
        standard states that Unicode U+00A0 should be used to pad isolated
        diacritics, and U+25CC is commonly used to show an isolated diacritic
        over a dotted circle.

    @see also
        http://jira.monotype.com:8080/browse/LIB-84

---------------------------------------------------------------------------- */
static void addRequiredUnicodes(LF_MAP* unicodeMap)
{
    map_insert(unicodeMap, (void*)0x0020, (void*)0x0020);
    map_insert(unicodeMap, (void*)0x00A0, (void*)0x00A0);
    map_insert(unicodeMap, (void*)0x25CC, (void*)0x25CC);
}

static LF_ERROR preprocessUnicodes(LF_MAP* unicodeMap, ULONG glyph)
{
    size_t i, k, sizeExtra = sizeof(addedUnicodes) / NUM_ADDED_UNICODES / sizeof(ULONG);

    for (i = 0; i < sizeExtra; i++)
    {
        ULONG inputUnicode = addedUnicodes[i][0];

        if (glyph == inputUnicode)
        {
            for (k = 1; k < NUM_ADDED_UNICODES; k++)
            {
                map_insert(unicodeMap, (void*)(intptr_t)addedUnicodes[i][k], (void*)(intptr_t)addedUnicodes[i][k]);
            }
        }
    }

    return LF_ERROR_OK;
}

/* ------------------------------------------------------------------
    @brief
        subsetCollectGlyphs scans the GSUB table and adds any new
        glyphs into the keep table it finds.  It does this by
        referencing the existing keep table and determines which
        rules may require a substitution.

        Once processing of the GSUB table has completed,
        composites that may exist with the newly added glyphs
        (or seac's in the case of cff fonts) are looked for and
        added those as well.

        if the composite adds a new glyph, then the gsub tables
        must again be scanned for additional glyphs.  if the
        no glyphs are further added, the function returns it's
        status

    @param
        font            :       pointer to LF_FONT structure
        keepList        :       pointer to keep list
------------------------------------------------------------------ */
static LF_ERROR subsetCollectGlyphs(LF_FONT* font, GlyphList* keepList)
{
    LF_ERROR error;

    // if the fmtx table is present, the metrics glyph is retained
    GlyphID metricsGlyph;
    if (LF_ERROR_OK == FMTX_getMetricsGlyph(font, &metricsGlyph))
    {
        error = Keep_addGlyph(keepList, metricsGlyph);
        if ((error != LF_ADDED_GLYPH) && (error != LF_ERROR_OK))
        {
            return error;
        }
    }

    do
    {
        // now ... parse the gsub table
        error = GSUB_collectGlyphs(font, keepList);  // this returns ok if there is no gsub table

        if (error == LF_ERROR_OK || error == LF_ADDED_GLYPH)
        {
            // there should be either a glyf table or a cff table at this point
            boolean haveGlyf = map_key_exists(&font->table_map, (void*)TAG_GLYF);
            boolean haveCff = map_key_exists(&font->table_map, (void*)TAG_CFF);
            boolean haveCBDT = map_key_exists(&font->table_map, (void*)TAG_CBDT);
            boolean haveEBDT = map_key_exists(&font->table_map, (void*)TAG_EBDT);
            boolean haveCOLR = map_key_exists(&font->table_map, (void*)TAG_COLR);

            if ((haveGlyf == FALSE) && (haveCff == FALSE) && (haveCBDT == FALSE))
                return LF_BAD_FORMAT;

            if ((haveGlyf == TRUE) && (haveCff == TRUE))
            {
                // use the cff table if that is what the font started with
                if (font->origType == eLF_CFF_FONT)
                    haveGlyf = FALSE;
            }

            if (haveGlyf == TRUE)
            {
                // collect the composites in the glyph table
                error = GLYF_keepGlyphs(font, keepList);
            }
            else if (haveCff == TRUE)
            {
                // collect the seacs in the cff table
                error = CFF__keepGlyphs(font, keepList);
            }

            if (error == LF_ERROR_OK)
            {
                if (haveCBDT)
                    error = CBDT_keepGlyphs(font, keepList);
                if (haveEBDT)
                    error = EBDT_keepGlyphs(font, keepList);
                if (haveCOLR)
                    error = COLR_keepGlyphs(font, keepList);
            }
        }

    } while (error == LF_ADDED_GLYPH);

    return error;
}

static LF_ERROR getSourceCharCB(const TsNormTextObj* textObj, LONG index, ULONG* charData, LONG* sourceIndex)
{
    ULONG* unicodes;

    unicodes = (ULONG*)textObj->text;

    if(index >= textObj->size)
        return LF_INVALID_INDEX;

    *charData = unicodes[index];
    *sourceIndex = index;

    return LF_ERROR_OK;
}

static LF_ERROR dummySetCharCB(TsNormTextObj* textObj, LONG index, ULONG charData, LONG sourceIndex)
{
    /* Dummy function */
    /* the following lines are to clear up compiler/lint warnings only */
    UNUSED(textObj);
    UNUSED(index);
    UNUSED(charData);
    UNUSED(sourceIndex);

    return LF_ERROR_OK;
}

static LF_ERROR SetCharCB(TsNormTextObj *textObj, LONG index, ULONG charData, LONG sourceIndex)
{
    LF_ERROR result = LF_ERROR_OK;

    (void)sourceIndex;

    if(index >= textObj->size)
    {
        ULONG charsToAdd;

        charsToAdd = textObj->growth;
        if((1 + index - textObj->size) > (LONG)charsToAdd)
            charsToAdd = (1 + index - textObj->size);
        result = textObj->increaseSize(textObj, charsToAdd);
    }
    if(result == LF_ERROR_OK)
    {
        ULONG* unicodes = (ULONG*)textObj->text;

        unicodes[index] = charData;
    }

    return result;
}

static LF_ERROR increaseSizeCB(TsNormTextObj *textObj, ULONG charsToAdd)
{
    ULONG* tmp;
    LONG oldSize, newSize;

    oldSize = textObj->size;
    newSize = oldSize + charsToAdd;

    tmp = (ULONG*)realloc(textObj->text, newSize * sizeof(ULONG));

    if(tmp != NULL)
    {
        textObj->text = tmp;
        textObj->size = newSize;
        memset((ULONG*)textObj->text+oldSize, 0, sizeof(ULONG)*(newSize-oldSize));
        return LF_ERROR_OK;
    }
    else
    {
        return LF_OUT_OF_MEMORY;
    }
}

static boolean needToNormalize(ULONG* unicodes, ULONG numUnicodes)
{
    size_t i;
    ULONG* ptr = unicodes;

    for(i = 0; i < numUnicodes; ++i)
    {
        if(*ptr++ > 0x0300)
        {
            // TODO use a trie built from the NFC_QC tables
            return TRUE;
        }
    }

    return FALSE;
}

static LF_ERROR normalizeUnicodes(ULONG* unicodes, ULONG numUnicodes, ULONG** normUnicodes, ULONG* normUnicodeCount)
{
    LF_ERROR error;
    TsNormTextObj inputObj;
    TsNormTextObj outputObj;
    TsNormTextObj tempObj;
    LONG outputEndIndex;
    const LONG growthSpace = 32;

    inputObj.getChar = getSourceCharCB;
    inputObj.growth = 16;
    inputObj.increaseSize = increaseSizeCB;
    inputObj.setChar = dummySetCharCB;
    inputObj.size = numUnicodes;
    inputObj.text = unicodes;

    outputObj.getChar = getSourceCharCB;
    outputObj.growth = 32;
    outputObj.increaseSize = increaseSizeCB;
    outputObj.setChar = SetCharCB;
    outputObj.size = growthSpace;

    outputObj.text = (ULONG*)calloc((growthSpace), sizeof(ULONG));
    if(outputObj.text == NULL)
        return LF_OUT_OF_MEMORY;

    tempObj.getChar = getSourceCharCB;
    tempObj.growth = 32;
    tempObj.increaseSize = increaseSizeCB;
    tempObj.setChar = SetCharCB;
    tempObj.size = numUnicodes + growthSpace;
    tempObj.text =  (ULONG*)malloc((numUnicodes + growthSpace)*sizeof(ULONG));
    if(tempObj.text == NULL)
    {
        free(outputObj.text);
        return LF_OUT_OF_MEMORY;
    }

    error = TsNorm_composeStringToNFC(&inputObj, 0, numUnicodes-1, &outputObj, 0, &outputEndIndex, &tempObj);

    if(error == LF_ERROR_OK)
    {
        *normUnicodes = (ULONG*)outputObj.text;
        *normUnicodeCount = outputEndIndex+1;
    }
    else
    {
        free(outputObj.text);
    }

    free(tempObj.text);

    return error;
}

static void addLanguageUnicodes(LF_MAP* unicodeMap, const LF_SUBSET_PARAMS* params)
{
    ULONG numLang = params->numLang;
    char** listLang = params->listLang;
    ULONG i;

    if (listLang != NULL)
    {
        ULONG numGlyphsIgnored;

        for (i = 0; i < numLang; i++)
        {
            char* lang = listLang[i];
            BuildLang_getRangeTable(lang, unicodeMap, &numGlyphsIgnored);
        }
    }
}

static boolean hasValidLanguageKeys(const LF_SUBSET_PARAMS* params)
{
    boolean retVal = FALSE;

    if ((params->listLang != NULL) && (params->numLang > 0))
    {
        // Check that all the languages/codepages in the list are supported.
        for (size_t i = 0; i < params->numLang; i++)
        {
            char* lang = params->listLang[i];

            if (LF_ERROR_OK == BuildLang_rangeTableExists(lang))
                retVal = TRUE;
            else
            {
                DEBUG_LOG_ERROR("an invalid languge code was requested");
                retVal = FALSE;
                break;
            }
        }
    }
    return retVal;
}

static LF_ERROR createSubsetUnicodeList(const LF_FONT* lfFont, const LF_SUBSET_PARAMS* params,
                                        const ULONG* unicodes, ULONG numUnicodes,
                                        const ULONG* normalizedUnicodes, ULONG numNormalizedUnicodes,
                                        ULONG** subsetUnicodes, ULONG* numSubsetUnicodes)
{
    size_t i;
    LF_MAP unicodeMap;

    *subsetUnicodes = NULL;
    *numSubsetUnicodes = 0;

    map_init(&unicodeMap, integer_compare);

    addRequiredUnicodes(&unicodeMap);

    addAlphabeticPresentationForms(lfFont, unicodes, numUnicodes, &unicodeMap);

    addLanguageUnicodes(&unicodeMap, params);

    for (i = 0; i < numUnicodes; ++i)
    {
        ULONG count = unicodeMap.count;

        map_insert(&unicodeMap, (void*)(intptr_t)unicodes[i], (void*)(intptr_t)unicodes[i]);

        if (unicodeMap.count > count)
        {
            preprocessUnicodes(&unicodeMap, unicodes[i]);
        }
    }

    if ((normalizedUnicodes != NULL) && (numNormalizedUnicodes != 0))
    {
        for (i = 0; i < numNormalizedUnicodes; ++i)
        {
            ULONG count = unicodeMap.count;

            if (normalizedUnicodes[i] == 0)
                continue;

            map_insert(&unicodeMap, (void*)(intptr_t)normalizedUnicodes[i], (void*)(intptr_t)normalizedUnicodes[i]);

            if (unicodeMap.count > count)
                preprocessUnicodes(&unicodeMap, unicodes[i]);
        }
    }

    LF_MAP_ITER* mapIter = map_begin(&unicodeMap);
    if (mapIter == NULL)
        return LF_OUT_OF_MEMORY;

    rb_tree_node* node = map_next(mapIter);
    i = 0;

    *numSubsetUnicodes = unicodeMap.count;

    *subsetUnicodes = (ULONG*)calloc(unicodeMap.count, sizeof(ULONG));
    if (*subsetUnicodes == NULL)
    {
        map_free_iter(mapIter);
        return  LF_OUT_OF_MEMORY;
    }

    while (node)
    {
        (*subsetUnicodes)[i++] = (ULONG)(intptr_t)node->key;
        node = map_next(mapIter);
    }

    map_free_iter(mapIter);
    map_clear(&unicodeMap);

    return LF_ERROR_OK;
}

static LF_ERROR createSubsetGIDList(LF_FONT* lfFont, const ULONG* subsetUnicodes, ULONG numSubsetUnicodes,
                                    GlyphID** subsetGIDs, ULONG* numsubsetGIDs)
{
    *subsetGIDs = (GlyphID*)malloc((numSubsetUnicodes + 3) * sizeof(GlyphID));
    if (*subsetGIDs == NULL)
        return LF_OUT_OF_MEMORY;

    *numsubsetGIDs = numSubsetUnicodes + 3;

    // The first three glyphs are always retained
    (*subsetGIDs)[0] = 0;
    (*subsetGIDs)[1] = 1;           // Note: false report of buffer overrun here with VS2015 analyzer (see https://randomascii.wordpress.com/2011/09/13/analyze-for-visual-studio-the-ugly-part-5/)
    (*subsetGIDs)[2] = 2;

    GlyphID* gidPtr = (*subsetGIDs) + 3;

    // Add the glyphs corresponding to the Unicodes in the subset (duplicates of the first three will be removed later)
    for (size_t i = 0; i < numSubsetUnicodes; ++i)
    {
        LF_ERROR status = CMAP_getGlyphID(lfFont, subsetUnicodes[i], gidPtr++);
        if (status != LF_ERROR_OK)
        {
            free(*subsetGIDs);
            return status;
        }
    }

    return LF_ERROR_OK;
}

static LF_ERROR pruneFeatureTable(LF_FONT* lfFont)
{
    gsub_header* gsubTable = (gsub_header*)map_at(&lfFont->table_map, (void*)TAG_GSUB);
    gpos_header* gposTable = (gpos_header*)map_at(&lfFont->table_map, (void*)TAG_GPOS);

    LF_ERROR error;

    if (gsubTable)
    {
        error = Feature_pruneTable(gsubTable->FeatureList);
        if (error == LF_EMPTY_TABLE)
        {
            DEBUG_LOG("remove all of the GSUB lookup tables");
            GSUB_removeAllTables(lfFont);
        }
    }

    if (gposTable)
    {
        error = Feature_pruneTable(gposTable->FeatureList);
        if (error == LF_EMPTY_TABLE)
        {
            DEBUG_LOG("remove all of the GPOS lookup tables");
            GPOS_removeAllTables(lfFont);
        }
    }

    return LF_ERROR_OK;
}

static void cleanupLookups(LF_FONT* lfFont)
{
    GSUB_cleanupLookups(lfFont);
    GPOS_cleanupLookups(lfFont);

    GSUB_removeUnReferencedLookups(lfFont);
    GPOS_removeUnReferencedLookups(lfFont);
}

static void removeEmptyTables(LF_FONT* lfFont)
{
    sfnt_table_record* record;
    boolean gdefRemoved = FALSE;

    record = offset_findRecord(lfFont, TAG_GDEF);
    if (record)
    {
        if (GDEF_isTableEmpty(lfFont) == LF_EMPTY_TABLE)
        {
            SFNT_removeTable(lfFont, TAG_GDEF);
            map_erase(&lfFont->table_map, (void*)TAG_GDEF);

            gdefRemoved = TRUE;
        }
    }

    // filter out any pruning of the GSUB/GPOS tables
    record = offset_findRecord(lfFont, TAG_GSUB);
    if (record)
    {
        if (GSUB_isTableEmpty(lfFont) == LF_EMPTY_TABLE)
        {
            SFNT_removeTable(lfFont, TAG_GSUB);
            map_erase(&lfFont->table_map, (void*)TAG_GSUB);
        }
        else
        {
            if (gdefRemoved)
                GSUB_updateLookupFlags(lfFont);
        }
    }

    record = offset_findRecord(lfFont, TAG_GPOS);
    if (record)
    {
        if (GPOS_isTableEmpty(lfFont) == LF_EMPTY_TABLE)
        {
            SFNT_removeTable(lfFont, TAG_GPOS);
            map_erase(&lfFont->table_map, (void*)TAG_GPOS);
        }
    }

    record = offset_findRecord(lfFont, TAG_KERN);
    if (record)
    {
        if (KERN_isTableEmpty(lfFont) == LF_EMPTY_TABLE)
        {
            SFNT_removeTable(lfFont, TAG_KERN);
            map_erase(&lfFont->table_map, (void*)TAG_KERN);
        }
        else
        {
            if (gdefRemoved)
                GPOS_updateLookupFlags(lfFont);
        }
    }

    record = offset_findRecord(lfFont, TAG_SBIX);
    if (record)
    {
        if (SBIX_isTableEmpty(lfFont) == LF_EMPTY_TABLE)
        {
            SFNT_removeTable(lfFont, TAG_SBIX);
            map_erase(&lfFont->table_map, (void*)TAG_SBIX);
        }
    }

    record = offset_findRecord(lfFont, TAG_CBDT);
    if (record)
    {
        if (CBDT_isTableEmpty(lfFont) == LF_EMPTY_TABLE)
        {
            SFNT_removeTable(lfFont, TAG_CBDT);
            map_erase(&lfFont->table_map, (void*)TAG_CBDT);

            SFNT_removeTable(lfFont, TAG_CBLC);
            map_erase(&lfFont->table_map, (void*)TAG_CBLC);
        }
    }

    record = offset_findRecord(lfFont, TAG_EBDT);
    if (record)
    {
        if (EBDT_isTableEmpty(lfFont) == LF_EMPTY_TABLE)
        {
            SFNT_removeTable(lfFont, TAG_EBDT);
            map_erase(&lfFont->table_map, (void*)TAG_EBDT);

            SFNT_removeTable(lfFont, TAG_EBLC);
            map_erase(&lfFont->table_map, (void*)TAG_EBLC);
        }
    }

    record = offset_findRecord(lfFont, TAG_COLR);
    if (record)
    {
        if (COLR_isTableEmpty(lfFont) == LF_EMPTY_TABLE)
        {
            SFNT_removeTable(lfFont, TAG_COLR);
            map_erase(&lfFont->table_map, (void*)TAG_COLR);
            // Don't need the CPAL
            SFNT_removeTable(lfFont, TAG_CPAL);
            map_erase(&lfFont->table_map, (void*)TAG_CPAL);
        }
    }

    record = offset_findRecord(lfFont, TAG_GVAR);
    if (record)
    {
        if (GVAR_isTableEmpty(lfFont) == LF_EMPTY_TABLE)
        {
            SFNT_removeTable(lfFont, TAG_GVAR);
            map_erase(&lfFont->table_map, (void*)TAG_GVAR);

            // Can then also get rid of the other variations tables
            SFNT_removeTable(lfFont, TAG_FVAR);
            map_erase(&lfFont->table_map, (void*)TAG_FVAR);
            SFNT_removeTable(lfFont, TAG_CVAR);
            map_erase(&lfFont->table_map, (void*)TAG_CVAR);
            SFNT_removeTable(lfFont, TAG_AVAR);
            map_erase(&lfFont->table_map, (void*)TAG_AVAR);
        }
    }
}

static LF_ERROR checkGlyphTable(const LF_FONT* lfFont, boolean* hasGLYF, boolean* hasCff, boolean* hasCBDT, boolean* hasEBDT)
{
    *hasGLYF = FALSE;
    *hasCff = FALSE;
    *hasCBDT = FALSE;
    *hasEBDT = FALSE;

    if (NULL != map_at(&lfFont->table_map, (void *)(long)TAG_GLYF))
    {
        *hasGLYF = TRUE;
    }
    if (NULL != map_at(&lfFont->table_map, (void *)(long)TAG_CFF))
    {
        *hasCff = TRUE;
    }
    if (NULL != map_at(&lfFont->table_map, (void *)(long)TAG_CBDT))
    {
        *hasCBDT = TRUE;
    }
    if (NULL != map_at(&lfFont->table_map, (void *)(long)TAG_EBDT))
    {
        *hasEBDT = TRUE;
    }

    if ((*hasGLYF == FALSE) && (*hasCff == FALSE) && (*hasCBDT == FALSE))
        return LF_TABLE_MISSING;

    return LF_ERROR_OK;
}

static void pruneOpenTypeTables(LF_FONT* lfFont, const LF_SUBSET_PARAMS* params)
{
    GPOS_pruneLookups(lfFont);
    GSUB_pruneLookups(lfFont);

    if (params->optimize > SUBSET_OPT_NONE)
    {
        // cleanup and prune feature table
        pruneFeatureTable(lfFont);

        if (params->optimize > SUBSET_OPT_REMOVE_EMPTY_FEATURES)
            cleanupLookups(lfFont);
    }
}

static LF_ERROR remapTables(LF_FONT* lfFont, LF_MAP* remap)
{
    LF_MAP_ITER* mapIter = map_begin(remap);
    if (mapIter == NULL)
        return LF_OUT_OF_MEMORY;

    rb_tree_node* node = map_next(mapIter);

    GlyphID newID = 0;

    while (node)
    {
        node->data = (void*)(intptr_t)newID++;
        node = map_next(mapIter);
    }

    map_free_iter(mapIter);

    //CMAP_remapTable(lfFont, &table->remap);  //The cmap table maintains an array which matches the content of remap
    GDEF_remapAll(lfFont, remap);
    //GLYF_remapTable(lfFont, remap);
    GLYF_remapCompositeGlyfs(lfFont, remap);
    CFF__remapTable(lfFont, remap);
    GSUB_remapTable(lfFont, remap);
    GPOS_remapTable(lfFont, remap);
    KERN_remapTable(lfFont, remap);
    HMTX_remapTable(lfFont, remap);     //TODO: the HMTX code also does not use the remap map
    SBIX_remapTable(lfFont, remap);
    CBDT_remapTable(lfFont, remap);
    CBLC_remapTable(lfFont, remap);
    EBDT_remapTable(lfFont, remap);
    EBLC_remapTable(lfFont, remap);
    COLR_remapTable(lfFont, remap);
    GVAR_remapTable(lfFont, remap);
    FMTX_remapTable(lfFont, remap);

    return LF_ERROR_OK;
}

/**
 * @defgroup SUBSETTER Subsetter API
 * @brief Subsetter API Function
 * @{
 */

/**
    Subset a font based on a list of Unicodes to keep.
    @param[in] lfFont parent class
    @param[in] unicodes array of Unicodes to keep
    @param[in] numUnicodes length of Unicodes array
    @param[in] params parameters for controlling the subsetting process
    @see LF_createFont
*/
LF_API LF_ERROR LF_subsetFont(LF_FONT* lfFont, ULONG* unicodes, ULONG  numUnicodes, const LF_SUBSET_PARAMS* params)
{
    LF_ERROR error;

    if ((lfFont == NULL) || (params == NULL))
        return LF_INVALID_PARAM;

    // Font can be subsetted only once
    if (lfFont->isSubsetted == TRUE)
        return LF_UNSUPPORTED;

    // The font may have been written prior to being subset, so remove any built sfnt.
    SFNT_clearSFNT(lfFont);

    // Check to see if client passed any language set(s) in the parameters.
    boolean validLangs = hasValidLanguageKeys(params);

    // There must be either a unicode array or valid language(s) to proceed.
    if (numUnicodes == 0 && validLangs == FALSE)
        return LF_INVALID_PARAM;

    // Tables must be unpacked in order to do a subset.
    if (map_empty(&lfFont->table_map))
    {
        error = SFNT_unpackTables(lfFont);
        if (error != LF_ERROR_OK)
            return error;
    }

    ULONG* normalizedUnicodes = NULL;
    ULONG numNormalizedUnicodes = 0;

    // Apply NFC algorithm if user requested and it is actually needed.
    if ((TRUE == params->normalize) && (TRUE == needToNormalize(unicodes, numUnicodes)))
    {
        error = normalizeUnicodes(unicodes, numUnicodes, &normalizedUnicodes, &numNormalizedUnicodes);
        if (error != LF_ERROR_OK)
            return error;
    }

    // Create a list of Unicodes to be in the subset, including those in the passed in
    // array, those that are in hard-coded language set(s), and others that are required.
    ULONG* subsetUnicodes;
    ULONG  numSubsetUnicodes;

    error = createSubsetUnicodeList(lfFont, params, unicodes, numUnicodes,
                                    normalizedUnicodes, numNormalizedUnicodes,
                                    &subsetUnicodes, &numSubsetUnicodes);

    free(normalizedUnicodes);

    if (error != LF_ERROR_OK)
        return error;

    // Create a list of Glyph IDs which are to be retained (by using the cmap).
    // Glyph IDs 0, 1, and 2 are always retained.
    GlyphID* subsetGIDs;
    ULONG numsubsetGIDs;

    error = createSubsetGIDList(lfFont, subsetUnicodes, numSubsetUnicodes, &subsetGIDs, &numsubsetGIDs);
    if (error != LF_ERROR_OK)
    {
        free(subsetUnicodes);
        return error;
    }

    free(subsetUnicodes);

    GlyphList* keepList = Keep_createGlyphList();
    if (keepList == NULL)
    {
        free(subsetGIDs);
        return LF_OUT_OF_MEMORY;
    }

    error = Keep_populateGlyphList(keepList, subsetGIDs, numsubsetGIDs);
    free(subsetGIDs);
    if (error != LF_ERROR_OK)
    {
        Keep_destroyGlyphList(keepList);
        return error;
    }

    // Add in any other glyphs required by GSUB rules, and components of composites, and
    // for cff input, the base and accent glyphs for glyphs using the seac method.
    error = subsetCollectGlyphs(lfFont, keepList);
    if (error != LF_ERROR_OK)
    {
        Keep_destroyGlyphList(keepList);
        return error;
    }

    USHORT numFontGlyphs = MAXP_getNumGlyphs(lfFont);
    ULONG  numSubsetGlyphs;

    GlyphID* glyphList = Keep_getSortedGlyphIDList(keepList, &numSubsetGlyphs);
    if (glyphList == NULL)
    {
        Keep_destroyGlyphList(keepList);
        return LF_OUT_OF_MEMORY;
    }

    USHORT* glyphs = glyphList;
    ULONG i, numKeptGlyphs = 0;

    // Loop over all the glyphs in the font, and remove from the GPOS and GSUB tables
    // any which are not in the subset.
    for (i = 0; i < numFontGlyphs; i++)
    {
        if (numKeptGlyphs < numSubsetGlyphs && i >= *glyphs)
        {
            glyphs++;
            numKeptGlyphs++;
        }
        else
        {
            GSUB_removeGlyph(lfFont, i);
            GPOS_removeGlyph(lfFont, i);
        }
    }

    // Prune the OpenType tables by removing unreferenced items.
    pruneOpenTypeTables(lfFont, params);

    LF_MAP remap;
    map_init(&remap, integer_compare);
    for (i = 0; i < numFontGlyphs; i++)
        map_insert(&remap, (void*)(intptr_t)i, (void*)(intptr_t)i);


    // Loop over all the glyphs in the font, and remove from tables other than GPOS and GSUB
    // any which are not in the subset.

    boolean hasVHEA, hasVMTX, hasHDMX, hasKERN, hasLTSH, hasHMTX, hasSBIX, hasCOLR, hasGVAR;

    LF_hasTable(lfFont, TAG_VHEA, &hasVHEA);
    LF_hasTable(lfFont, TAG_VMTX, &hasVMTX);
    LF_hasTable(lfFont, TAG_HDMX, &hasHDMX);
    LF_hasTable(lfFont, TAG_KERN, &hasKERN);
    LF_hasTable(lfFont, TAG_LTSH, &hasLTSH);
    LF_hasTable(lfFont, TAG_HMTX, &hasHMTX);
    LF_hasTable(lfFont, TAG_SBIX, &hasSBIX);
    LF_hasTable(lfFont, TAG_COLR, &hasCOLR);
    LF_hasTable(lfFont, TAG_GVAR, &hasGVAR);

    // font must have either glyf or cff and/or CBDT
    boolean hasGLYF, hasCff, hasCBDT, hasEBDT;

    error = checkGlyphTable(lfFont, &hasGLYF, &hasCff, &hasCBDT, &hasEBDT);
    if (error != LF_ERROR_OK)
    {
        map_clear(&remap);
        free(glyphList);
        Keep_destroyGlyphList(keepList);
        return error;
    }

    glyphs = glyphList;
    numKeptGlyphs = 0;

    for (i = 0; i < numFontGlyphs; i++)
    {
        if (numKeptGlyphs < numSubsetGlyphs && i >= *glyphs)
        {
            glyphs++;
            numKeptGlyphs++;
        }
        else
        {
            map_erase(&remap, (void*)(intptr_t)i);

            LOCA_removeGlyph(lfFont, i);
            CMAP_removeGlyph(lfFont, i);
            POST_removeGlyph(lfFont, (GlyphID)i);
            GDEF_removeGlyph(lfFont, (GlyphID)i);
            if (hasGLYF)
                GLYF_removeGlyph(lfFont, i);
            if (hasCff)
                CFF__removeGlyph(lfFont, i);
            if (hasCBDT)
            {
                CBDT_removeGlyph(lfFont, i);
                CBLC_removeGlyph(lfFont, i);
            }
            if (hasCOLR)
                COLR_removeGlyph(lfFont, i);
            if (hasEBDT)
            {
                EBDT_removeGlyph(lfFont, i);
                EBLC_removeGlyph(lfFont, i);
            }
            if (hasHMTX)
                HMTX_removeGlyph(lfFont, i);
            if (hasKERN)
                KERN_removeGlyph(lfFont, i);
            if (hasLTSH)
                LTSH_removeGlyph(lfFont, i);
            if (hasVMTX)
                VMTX_removeGlyph(lfFont, i);
            if (hasHDMX)
                HDMX_removeGlyph(lfFont, i);
            if (hasSBIX)
                SBIX_removeGlyph(lfFont, i);
            if (hasGVAR)
                GVAR_removeGlyph(lfFont, i);
        }
    }

    free(glyphList);
    Keep_destroyGlyphList(keepList);

    // Remove any empty tables.
    removeEmptyTables(lfFont);

    // Update all tables which reference glyph IDs. Remaining glyphs are renumbered 0 through (num glyphs in subset-1).
    error = remapTables(lfFont, &remap);

    map_clear(&remap);

    if (error != LF_ERROR_OK)
        return error;

    lfFont->isSubsetted = TRUE;

    if (hasCBDT)
    {
        // CBDT can be removed
        LF_hasTable(lfFont, TAG_CBDT, &hasCBDT);

        if (!(hasGLYF || hasCff) && !hasCBDT)
        {
            return LF_BAD_FORMAT;                       // no glyphs left
        }
    }
    if (hasEBDT)
    {
        // EBDT can be removed
        LF_hasTable(lfFont, TAG_EBDT, &hasEBDT);

        if (!(hasGLYF || hasCff) && !hasCBDT && !hasEBDT)
        {
            return LF_BAD_FORMAT;                       // no glyphs left
        }
    }

    // Update various tables based on the glyphs remaining in the subset.
    ULONG glyphCountTable = 0x00000000;
    if (hasGLYF)
        glyphCountTable = TAG_GLYF;
    else if (hasCff)
        glyphCountTable = TAG_CFF;

    MAXP_updateTable(lfFont, glyphCountTable, FALSE, FALSE, (boolean)(hasCBDT || hasEBDT));

    if (hasGLYF || hasCff)
    {
        SHORT xMin = 0, yMin = 0, xMax = 0, yMax = 0;

        if (hasGLYF)
            error = GLYF_getBoundingBox(lfFont, &xMin, &yMin, &xMax, &yMax);
        else if (hasCff)
            error = CFF__getBoundingBox(lfFont, &xMin, &yMin, &xMax, &yMax);

        if (error != LF_ERROR_OK)
            return error;

        // Update hmtx side bearings and get min values
        FWORD minlsb, minrsb, maxadvance;

        error = HMTX_updateSidebearings(lfFont, lfFont->fontType, &minlsb, &minrsb, &maxadvance);
        if (error != LF_ERROR_OK)
            return error;

        HEAD_setBoundingBox(lfFont, xMin, yMin, xMax, yMax);
        HHEA_setXMaxExtent(lfFont, xMax);
        HHEA_setLeftSidebearingMin(lfFont, minlsb);
        HHEA_setRightSidebearingMin(lfFont, minrsb);
        HHEA_setAdvanceWidthMax(lfFont, maxadvance);
        HHEA_setNumHMetrics(lfFont, HMTX_getNumHMetrics(lfFont));

        if (hasVHEA && hasVMTX)
        {
            FWORD mintsb, minbsb, maxvadvance, yMaxExtent;
            error = VMTX_updateSidebearings(lfFont, lfFont->fontType, &mintsb, &minbsb, &maxvadvance, &yMaxExtent);
            if (error != LF_ERROR_OK)
                return error;

            VHEA_setAdvanceHeightMax(lfFont, maxvadvance);
            VHEA_setYMaxExtent(lfFont, yMaxExtent);
            VHEA_setTopSidebearingMin(lfFont, mintsb);
            VHEA_setBottomSidebearingMin(lfFont, minbsb);
            VHEA_setVertTypoLineGap(lfFont, 0);
            VHEA_setNumVMetrics(lfFont, VMTX_getNumVMetrics(lfFont));
        }
    }
    if (hasCBDT)
    {
        error = CBLC_updateMetrics(lfFont);
        if (error != LF_ERROR_OK)
            return error;
    }
    if (hasEBDT)
    {
        error = EBLC_updateMetrics(lfFont);
        if (error != LF_ERROR_OK)
            return error;
    }

    USHORT os2Version;
    OS2_getVersion(lfFont, &os2Version);
    if (os2Version < 3)
    {
        error = OS2_upgradeTable(lfFont);
        if (error != LF_ERROR_OK)
            return error;
    }
    else
    {
        OS2_updateHeights(lfFont);
        //OS2_updateMaxContent(lfFont);
    }
    OS2_setAvgCharWidth(lfFont, HMTX_getAdvanceWidthAvg(lfFont));

    USHORT minUni, maxUni;
    error = CMAP_getMinMaxRemappedUnicodes(lfFont, &minUni, &maxUni);
    if (error != LF_ERROR_OK)
        return error;

    OS2_setCharIndex(lfFont, minUni, maxUni);

    return error;
}

/** @} */ // end of SUBSETTER group
